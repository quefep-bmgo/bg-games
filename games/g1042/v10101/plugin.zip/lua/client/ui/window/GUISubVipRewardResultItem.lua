---@class GUISubVipRewardResultItemWindow : IGUIWindow
local GUISubVipRewardResultItemWindow = class("GUISubVipRewardResultItemWindow", IGUIWindow)
---@type SubVipRewardConfig
local SubVipRewardConfig = T(Global, "SubVipRewardConfig")

---@private
function GUISubVipRewardResultItemWindow:ctor(...)
    self.super.ctor(self, "SubVipRewardResultItem.json", ...)
end

---@private
function GUISubVipRewardResultItemWindow:onLoad()
    self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.siIcon = self:getChildWindowByName("SubVipRewardResultItem-Icon", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("SubVipRewardResultItem-Count", GUIType.StaticText)
    self.stName = self:getChildWindowByName("SubVipRewardResultItem-Name", GUIType.StaticText)
    self.siEffect = self:getChildWindowByName("SubVipRewardResultItem-Effect", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUISubVipRewardResultItemWindow:initView()
    self.stCount:SetText()
    self.stName:SetText()
end

---@private
function GUISubVipRewardResultItemWindow:initEvent()

end

---@param data PayActivityRewardConfigData
function GUISubVipRewardResultItemWindow:onDataChanged(data)
    --print(">>>>>>>>>>>>>>>>>>>>>GUISubVipRewardResultItemWindow:onDataChanged",StringUtil.v2s(data))
    SubVipRewardConfig:setRewardImage(self.siIcon, data)
    SubVipRewardConfig:setRewardName(self.stName, data)
    if not data then
        self.llRoot:SetBackImage("set:limited_time_activity.json image:img_frame_quality01")
        self.stCount:SetText("")
        return
    end
    local quality = data.quality or 1
    self.llRoot:SetBackImage("set:limited_time_activity.json image:img_frame_quality0".. quality)
    if data.count > 1 then
        self.stCount:SetText("x" .. data.count)
    else
        self.stCount:SetText("")
    end
end

return GUISubVipRewardResultItemWindow
