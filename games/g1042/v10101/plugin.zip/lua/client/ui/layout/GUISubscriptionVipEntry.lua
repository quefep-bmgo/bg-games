---@class UISubscriptionVipEntryLayout : IGUILayout
local UISubscriptionVipEntryLayout = class("UISubscriptionVipEntryLayout", IGUILayout)

---@private
function UISubscriptionVipEntryLayout:ctor(parent)
	self.super.ctor(self, "SubscriptionVipEntry.json", GUIManager:getMainControl())
end

---@private
function UISubscriptionVipEntryLayout:isDelayLoad()
	return true
end

---@private
function UISubscriptionVipEntryLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UISubscriptionVipEntryLayout:initCreateEvent()

end

---@private
function UISubscriptionVipEntryLayout:onLoad()
	self.btnBtn = self:getChildWindow("SubscriptionVipEntry-Btn", GUIType.Button)
	self.siRedDot = self:getChildWindow("SubscriptionVipEntry-RedDot", GUIType.StaticImage)
	self.stTitle = self:getChildWindow("SubscriptionVipEntry-Title", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UISubscriptionVipEntryLayout:initView()
	self.stTitle:SetText(Lang:getString("vip.entry"))
	self:checkRedDot()
end

---@private
function UISubscriptionVipEntryLayout:initEvent()
	self.btnBtn:registerEvent(GUIEvent.ButtonClick, function()
		UIHelper.showGameGUILayout("GUISubscriptionVip")
		self.siRedDot:SetVisible(false)
		if self:canGetChest() then
			PlayerManager:getClientPlayer():sendPacket({
				pid = "getTreasureChest"
			})
		end
	end)

	self:registerEvent(CEvents.PrivilegeGradeChangeEvent, function()
		self:checkRedDot()
	end)
end

function UISubscriptionVipEntryLayout:onShow()
end

function UISubscriptionVipEntryLayout:canGetChest()
	local Me= PlayerManager:getClientPlayer()
	if not Me:isPrivilegeGrade(1) then
		return false
	end
	if Me.getChestInfo then
		if not Me.getChestInfo[1] or (not Me.getChestInfo[2] and  Me:isPrivilegeGrade(2 )) then
			return true
		else
			return false
		end
	else
		return true
	end
end

function UISubscriptionVipEntryLayout:checkRedDot()
	self.siRedDot:SetVisible(self:canGetChest())
end


return UISubscriptionVipEntryLayout
