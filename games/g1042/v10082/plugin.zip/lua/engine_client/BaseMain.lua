---
--- Created by Jimmy.
--- DateTime: 2018/10/9 0009 15:02
---
function onChatFuncHandler(name, ...)

end

function onNotificationHandler(notificationData)
    local notification = json.decode(notificationData)
    Events.OnNotificationHandlerEvent:invoke(notification)
end

require "engine_base.Base"
require "engine_client.define.CDefine"
require "engine_client.define.GUIDefine"
require "engine_client.util.ClientHelper"
require "engine_client.util.DynamicCast"
require "engine_client.util.MemoryPool"
require "engine_client.util.MsgSender"
require "engine_client.util.PayHelper"
require "engine_client.util.SoundUtil"
require "engine_client.util.Lang"
require "engine_client.util.DressUtil"
SLAXML = require 'engine_client.xml.slaxml'
SLAXDOM = require 'engine_client.xml.slaxdom'
require "engine_client.entity.IEntity"
require "engine_client.entity.EntityCache"
require "engine_client.event.CommonDataEvents"
require "engine_client.event.GameEvents"
require "engine_client.analytics.GameAnalytics"
require "engine_client.analytics.GameAnalyticsCache"
require "engine_client.web.WebService"
require "engine_client.listener.Listener"
require "engine_client.listener.BaseListener"
require "engine_client.data.EngineWorld"
require "engine_client.data.PlayerWallet"
require "engine_client.data.BasePlayer"
require "engine_client.data.BaseProperty"
require "engine_client.ui.UIHelper"
require "engine_client.ui.GUIManager"
require "engine_client.ui.IGUIWindow"
require "engine_client.ui.IGUILayout"
require "engine_client.ui.IGUIDataView"
require "engine_client.ui.IGUIGridView"
require "engine_client.ui.IGUIListView"
require "engine_client.ui.anim.GUISubAnim"
require "engine_client.ui.anim.GUISubAnimScale"
require "engine_client.ui.anim.GUISubAnimAlpha"
require "engine_client.ui.anim.GUISubAnimMove"
require "engine_client.ui.anim.GUIAnim"
require "engine_client.ui.anim.GUIAnimManager"
require "engine_client.ui.adapter.IDataAdapter"
require "engine_client.Game"
require "engine_client.packet.PacketSender"
require "engine_client.packet.PidPacketHandler"
require "engine_client.manager.PlayerManager"
require "engine_client.helper.MaxRecordHelper"
require "engine_client.helper.GMHelper"
require "engine_client.cache.SharePreferences"

BaseListener:init()
WebService:init()

BaseMain = {}
BaseMain.GameType = "g1001"

function BaseMain:setGameType(GameType)
    self.GameType = GameType
end

function BaseMain:getGameType()
    return self.GameType
end

CommonDataEvents:registerCallBack("ServerInfo", function(data)
    PacketSender:init()
    isStaging = data:getBoolParam("isStaging")
    local isChina = data:getBoolParam("isChina")
    local regionId = data:getNumberParam("regionId")
    local gameId = data:getParam("gameId")
    Root.Instance():setChina(isChina)
    Game:setRegionId(regionId)
    Game:setGameId(gameId)
    PacketSender:sendLuaCommonData("RequestServerTime", tostring(os.time()))
end, DataBuilderProcessor)

CommonDataEvents:registerCallBack("SyncPlayerName", function(data)
    local trySetName
    trySetName = function(userId, name, times)
        times = times or 60
        if times <= 0 then
            return
        end
        local user = UserManager.Instance():findUser(userId)
        if user then
            user.userName = name
        else
            LuaTimer:schedule(function()
                trySetName(userId, name, times - 1)
            end, 1000)
        end
    end
    trySetName(data.userId, data.name, 60)
end, JsonBuilderProcessor)

CommonDataEvents:registerCallBack("RequestServerTime", function(serverTs)
    serverTs = tonumber(serverTs)
    local oldOsTime = os.time
    os.time = function(table)
        return oldOsTime(table) + serverTs
    end
end)

require "engine_client.connector.ConnectorCenter"