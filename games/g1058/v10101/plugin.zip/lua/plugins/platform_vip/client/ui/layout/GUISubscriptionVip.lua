---@class UISubscriptionVipLayout : IGUILayout
local UISubscriptionVipLayout = class("UISubscriptionVipLayout", IGUILayout)
---@type table<number, number>
local UserPrivilegeCfg = T(Global, "UserPrivilegeCfg")

---@private
function UISubscriptionVipLayout:ctor(parent)
    self.super.ctor(self, "SubscriptionVip.json", parent)
end

---@private
function UISubscriptionVipLayout:isDelayLoad()
    return true
end

---@private
function UISubscriptionVipLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UISubscriptionVipLayout:initCreateEvent()

end

---@private
function UISubscriptionVipLayout:onLoad()
    self.llContent = self:getChildWindow("SubscriptionVip-Content", GUIType.Layout)
    self.rbTabVip = self:getChildWindow("SubscriptionVip-TabVip", GUIType.RadioButton)
    self.rbTabSubscription = self:getChildWindow("SubscriptionVip-TabSubscription", GUIType.RadioButton)
    self.btnArrow1 = self:getChildWindow("SubscriptionVip-Arrow1", GUIType.Button)
    self.btnArrow2 = self:getChildWindow("SubscriptionVip-Arrow2", GUIType.Button)
    self.stSubTitle = self:getChildWindow("SubscriptionVip-SubTitle", GUIType.StaticText)
    self.llSubTitleLine = self:getChildWindow("SubscriptionVip-SubTitleLine", GUIType.Layout)
    self.btnButton = self:getChildWindow("SubscriptionVip-Button", GUIType.Button)
    self.llList = self:getChildWindow("SubscriptionVip-List", GUIType.Layout)
    self.llItem1 = self:getChildWindow("SubscriptionVip-Item1", GUIType.Layout)
    self.siItemTag1 = self:getChildWindow("SubscriptionVip-ItemTag1", GUIType.StaticImage)
    self.stItemText1 = self:getChildWindow("SubscriptionVip-ItemText1", GUIType.StaticText)
    self.llItem2 = self:getChildWindow("SubscriptionVip-Item2", GUIType.Layout)
    self.siItemTag2 = self:getChildWindow("SubscriptionVip-ItemTag2", GUIType.StaticImage)
    self.stItemText2 = self:getChildWindow("SubscriptionVip-ItemText2", GUIType.StaticText)
    self.llItem3 = self:getChildWindow("SubscriptionVip-Item3", GUIType.Layout)
    self.siItemTag3 = self:getChildWindow("SubscriptionVip-ItemTag3", GUIType.StaticImage)
    self.stItemText3 = self:getChildWindow("SubscriptionVip-ItemText3", GUIType.StaticText)
    self.stTitle = self:getChildWindow("SubscriptionVip-Title", GUIType.StaticText)
    self.btnClose = self:getChildWindow("SubscriptionVip-Close", GUIType.Button)
    self.siVipTag = self:getChildWindow("SubscriptionVip-VipTag", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UISubscriptionVipLayout:initView()
    self.rbTabVip:SetText(Lang:getString("vip.tab.text"))
    self.rbTabSubscription:SetText(Lang:getString("subscription.tab.text"))
    self.rbTabVip:SetSelected(true)
    ---@type GUILayout[]
    self.llItems = { self.llItem1, self.llItem2, self.llItem3 }
    ---@type GUIStaticText[]
    self.stItemTexts = { self.stItemText1, self.stItemText2, self.stItemText3 }
    ---@type GUIStaticImage[]
    self.siItemTags = { self.siItemTag1, self.siItemTag2, self.siItemTag3 }
    self:changeType(VipType.Vip)
end

---@private
function UISubscriptionVipLayout:initEvent()
    self.rbTabVip:registerEvent(GUIEvent.RadioStateChanged, function()
        self:changeType(VipType.Vip)
    end)
    self.rbTabSubscription:registerEvent(GUIEvent.RadioStateChanged, function()
        self:changeType(VipType.Subscription)
    end)
    self.btnArrow1:registerEvent(GUIEvent.ButtonClick, function()
        self:selectGrade(1)
    end)
    self.btnArrow2:registerEvent(GUIEvent.ButtonClick, function()
        self:selectGrade(2)
    end)
    self.btnButton:registerEvent(GUIEvent.ButtonClick, function()
        if self.type == VipType.Subscription then
            if (tonumber(GameAnalyticsCache:getClientInfo().version_code) or 0) > (Platform.isAndroid() and 4631 or 4631) then
                ClientHelper.onRecharge(self.cfg.type)
            else
                UIHelper.showToast(Lang:getString("gui.subscribed.download"))
            end
        else
            ClientHelper.onRecharge(self.cfg.type)
        end
    end)
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
end

function UISubscriptionVipLayout:onShow()
    if self.type == VipType.Vip then
        self:changeType(self.type)
    end
end

function UISubscriptionVipLayout:changeType(type)
    self.type = type
    self.cfg = VipConfig[type]
    self.stTitle:SetText(Lang:getString(self.cfg.title))
    self.grade = nil
    if type == VipType.Vip then
        self.siVipTag:SetVisible(true)
        self.stTitle:SetXPosition({ 0, 115 })
        if PlayerManager:getClientPlayer():isPrivilegeGrade(2) then
            self:selectGrade(2)
        else
            self:selectGrade(1)
        end
    else
        self.siVipTag:SetVisible(false)
        self.stTitle:SetXPosition({ 0, 35 })
        self:selectGrade(1)
    end
end

function UISubscriptionVipLayout:selectGrade(g)
    self.btnArrow1:SetVisible(#self.cfg.grade > 1 and g > 1)
    self.btnArrow2:SetVisible(#self.cfg.grade > 1 and g < #self.cfg.grade)
    self.grade = self.cfg.grade[g] or self.cfg.grade[1]
    self.llContent:SetBackImage(self.grade.styleImg)
    self.llSubTitleLine:SetBackImage(self.grade.lineImg)
    for i, item in pairs(self.llItems) do
        item:SetVisible(i <= #self.grade.items)
        item:SetBackImage(self.grade.itemImg)
    end
    for _, item in pairs(self.siItemTags) do
        item:SetImage(self.grade.itemTagImg)
    end
    for i, text in pairs(self.grade.items) do
        if self.stItemTexts[i] then
            self.stItemTexts[i]:SetTextColor(self.grade.itemTextColor)
            self.stItemTexts[i]:SetText(Lang:getString(text))
        end
    end
    self.btnButton:SetNormalImage(self.grade.buttonImg)
    self.btnButton:SetPushedImage(self.grade.buttonImg)
    self.siVipTag:SetImage(self.grade.vipImg)
    if self.type == VipType.Vip then
        self.stSubTitle:SetText(Lang:format(self.grade.title, UserPrivilegeCfg[g] or "?"))
        if PlayerManager:getClientPlayer():isPrivilegeGrade(self.grade.level) then
            self.btnButton:SetVisible(false)
            self.stSubTitle:SetText(Lang:format("gui.vip.effected.tip" .. g, PlayerManager:getClientPlayer().vipLv))
        else
            self.btnButton:SetVisible(true)
            self.btnButton:SetText(Lang:getString("gui.go.recharge"))
        end
    else
        self.stSubTitle:SetText(Lang:getString(self.grade.title))
        if PlayerManager:getClientPlayer():isVip() then
            self.btnButton:SetVisible(false)
            self.stSubTitle:SetText(Lang:format("gui.subscribed", PlayerManager:getClientPlayer().vipExpireDate or "?-?-?"))
        else
            self.btnButton:SetVisible(true)
            self.btnButton:SetText(Lang:getString("gui.go.subscribe"))
        end
    end
end

return UISubscriptionVipLayout
