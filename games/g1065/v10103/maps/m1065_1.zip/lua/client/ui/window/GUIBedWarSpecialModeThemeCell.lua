---@class GUIBedWarSpecialModeThemeCellWindow : IGUIWindow
local GUIBedWarSpecialModeThemeCellWindow = class("GUIBedWarSpecialModeThemeCellWindow", IGUIWindow)

---@private
function GUIBedWarSpecialModeThemeCellWindow:onLoad()
	self.siIcon = self:getChildWindowByName("BedWarSpecialModeThemeCell-icon", GUIType.StaticImage)
	self.stDetails = self:getChildWindowByName("BedWarSpecialModeThemeCell-details", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarSpecialModeThemeCellWindow:initView()
	self.stDetails:SetText()
end

---@private
function GUIBedWarSpecialModeThemeCellWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		if self.data and not self.data.isShowDetails then
			SpecialModeTopic:updateView()
			CustomDialog.builder()
						.setTitleText("gui.topics.in.this.issue")
						.setContentView(SpecialModeTopic)
						.setHideLeftButton()
						.setHideRightButton()
						.show()
		end
	end)
end

---@param data table
function GUIBedWarSpecialModeThemeCellWindow:onDataChanged(data)
	self.data = data
	if data then
		self.siIcon:SetImage(data.icon)
		self.stDetails:SetText(Lang:getString(data.lang))
		self.stDetails:SetVisible(data.isShowDetails)
	end
end

return GUIBedWarSpecialModeThemeCellWindow
