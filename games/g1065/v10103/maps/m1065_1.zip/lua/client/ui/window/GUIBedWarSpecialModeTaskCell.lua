---@class GUIBedWarSpecialModeTaskCellWindow : IGUIWindow
local GUIBedWarSpecialModeTaskCellWindow = class("GUIBedWarSpecialModeTaskCellWindow", IGUIWindow)
---@type TeamService
local TeamService = T(Global, "TeamService")

---@private
function GUIBedWarSpecialModeTaskCellWindow:onLoad()
	self.siFrame = self:getChildWindowByName("BedWarSpecialModeTaskCell-Frame", GUIType.StaticImage)
	self.stDetails = self:getChildWindowByName("BedWarSpecialModeTaskCell-Details", GUIType.StaticText)
	self.stProgress = self:getChildWindowByName("BedWarSpecialModeTaskCell-Progress", GUIType.StaticText)
	self.btnReceive = self:getChildWindowByName("BedWarSpecialModeTaskCell-Receive", GUIType.Button)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarSpecialModeTaskCellWindow:initView()
	if not self.rewardItem then
		self.rewardItem = self:createItem(self.siFrame)
	end
	self.stDetails:SetText()
end

---@private
function GUIBedWarSpecialModeTaskCellWindow:initEvent()
	self.btnReceive:registerEvent(GUIEvent.ButtonClick, function()
		if self.curTaskId and self.info and self.info.status == Define.TaskStatus.FINISHED then
			PlayerManager:getClientPlayer():sendPacket({
				pid = "C2SReceiveSpecialModeTask",
				activityId = TeamService:getSpecialModeId(),
				taskIds = {self.curTaskId},
			})
		end
	end)
	self:registerEvent(Events.SpecialModeTaskUpdateEvent, function(taskId)
		if taskId == self.curTaskId then
			self:updateTaskProgress()
		end
	end)
end

---@param data table
function GUIBedWarSpecialModeTaskCellWindow:onDataChanged(data)
	self.data = data
	self.curTaskId = nil
	self.info = nil
	self.taskMaxProgress = 0
	self.stProgress:SetVisible(false)
	self.btnReceive:SetVisible(false)
	if data then
		self.curTaskId = data.taskId
		local rewardCfg = TableUtil.copyTable(RewardConfig:getRewardById(data.rewardId))
		rewardCfg.num = rewardCfg.Count
		rewardCfg.numLang = tostring(rewardCfg.Count)
		self.rewardItem:setRewardData(rewardCfg)
		local taskConfig = TaskConfig:getTaskById(data.taskId)
		if taskConfig then
			self.stDetails:SetText(Lang:getString(taskConfig.Desc))
			self.taskMaxProgress = taskConfig.GoalNum or 0
		end
		self:updateTaskProgress()
	end
end

function GUIBedWarSpecialModeTaskCellWindow:updateTaskProgress()
	if not self.data then
		return
	end
	local curPlayer = PlayerManager:getClientPlayer()
	local specialModeId = TeamService:getSpecialModeId()
	local taskConfig = curPlayer:getSpecialModeTaskInfo(specialModeId, self.data.taskId)
	self.stProgress:SetVisible(false)
	self.btnReceive:SetVisible(false)
	if taskConfig then
		self.info = taskConfig
		if self.info.status == Define.TaskStatus.RECEIVED then
			self.btnReceive:SetVisible(true)
			self.btnReceive:SetTouchable(false)
			self.btnReceive:SetEnabled(false)
			self.btnReceive:SetText(Lang:getString("gui_bed_war_hall_task_over"))
	    elseif self.info.status == Define.TaskStatus.PROGRESSING then
			self.stProgress:SetVisible(true)
			self.stProgress:SetText(self.info.progress .. "/" .. self.taskMaxProgress)
		elseif self.info.status == Define.TaskStatus.FINISHED then
			self.btnReceive:SetVisible(true)
			self.btnReceive:SetTouchable(true)
			self.btnReceive:SetEnabled(true)
			self.btnReceive:SetText(Lang:getString("gui_bed_war_hall_task_complete"))
		end
	end
end

function GUIBedWarSpecialModeTaskCellWindow:createItem(parent)
	local item = GUIGameActivityRewardItem.new()
	parent:AddChildWindow(item.root)
	item.root:SetWidth({1, 0})
	item.root:SetHeight({1, 0})
	return item
end

return GUIBedWarSpecialModeTaskCellWindow
