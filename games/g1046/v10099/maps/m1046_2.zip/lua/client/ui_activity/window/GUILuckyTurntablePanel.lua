---@class GUILuckyTurntablePanelWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUILuckyTurntablePanelWindow = class("GUIGameActivityLuckyDiskWindow", GUICommonActivityPanel)

---@private
function GUILuckyTurntablePanelWindow:ctor(...)
    self.super.ctor(self, "LuckyTurntablePanel.json", ...)
end

---@private
function GUILuckyTurntablePanelWindow:onChildLoad()
    self.siBg = self:getChildWindowByName("LuckyTurntablePanel-Bg", GUIType.StaticImage)
    self.siEffect1 = self:getChildWindowByName("LuckyTurntablePanel-Effect1", GUIType.StaticImage)
    self.siEffect2 = self:getChildWindowByName("LuckyTurntablePanel-Effect2", GUIType.StaticImage)
    self.btnHint = self:getChildWindowByName("LuckyTurntablePanel-Hint", GUIType.Button)
    self.stTitle = self:getChildWindowByName("LuckyTurntablePanel-Title", GUIType.StaticText)
    self.siTimeIcon = self:getChildWindowByName("LuckyTurntablePanel-TimeIcon", GUIType.StaticImage)
    self.stTime = self:getChildWindowByName("LuckyTurntablePanel-Time", GUIType.StaticText)
    self.btnClick = self:getChildWindowByName("LuckyTurntablePanel-Click", GUIType.Button)
    self.stClickTxt = self:getChildWindowByName("LuckyTurntablePanel-Click-Txt", GUIType.StaticText)
    self.siClickPriceIcon = self:getChildWindowByName("LuckyTurntablePanel-Click-Price-Icon", GUIType.StaticImage)
    self.stClickPriceTxt = self:getChildWindowByName("LuckyTurntablePanel-Click-Price-Txt", GUIType.StaticText)
    self.siClickPriceLine = self:getChildWindowByName("LuckyTurntablePanel-Click-Price-Line", GUIType.StaticImage)
    self.stCountdown = self:getChildWindowByName("LuckyTurntablePanel-Countdown", GUIType.StaticText)
    self.siMainBg = self:getChildWindowByName("LuckyTurntablePanel-MainBg", GUIType.StaticImage)
    self.awActor = self:getChildWindowByName("LuckyTurntablePanel-Actor", GUIType.ActorWindow)
    self.stItemName = self:getChildWindowByName("LuckyTurntablePanel-ItemName", GUIType.StaticText)
    self.stItemDesc = self:getChildWindowByName("LuckyTurntablePanel-ItemDesc", GUIType.StaticText)
    self.llActorSlideBlock = self:getChildWindowByName("LuckyTurntablePanel-Actor-Slide-Block", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUILuckyTurntablePanelWindow:initView()
    ---@type CLuckyTurntableMgr
    self.mgr = self.mgr
    self.stTitle:SetText(Lang:getString(self.mgr.mainConfig.titleLang))
    self.stClickTxt:SetText(Lang:getString("gui.lucky.disk.click.txt"))

    self.itemsList = {}
    for i = 1, 6 do
        self.itemsList[i] = {
            bg = self:getChildWindowByName("LuckyTurntablePanel-Item" .. i, GUIType.StaticImage),
            light = self:getChildWindowByName("LuckyTurntablePanel-Item" .. i .. "-Light", GUIType.StaticImage),
            icon = self:getChildWindowByName("LuckyTurntablePanel-Item" .. i .. "-Icon", GUIType.StaticImage),
            num = self:getChildWindowByName("LuckyTurntablePanel-Item" .. i .. "-Num", GUIType.StaticText),
            receive = self:getChildWindowByName("LuckyTurntablePanel-Item" .. i .. "-Icon-Receive", GUIType.StaticImage),
            click = self:getChildWindowByName("LuckyTurntablePanel-Item" .. i .. "-Click", GUIType.StaticImage),
        }
        self.itemsList[i].light:SetVisible(false)
        self.itemsList[i].receive:SetVisible(false)
    end
end

---@private
function GUILuckyTurntablePanelWindow:initEvent()
    self.btnHint:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("gui.lucky.turntable.title")
                    .setContentText(Lang:getString("gui.lucky.turntable.text"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self.btnClick:registerEvent(GUIEvent.ButtonClick, function()
        if self.buyLock then
            return
        end
        PayHelper.checkMoney(self.mgr.config.type, self.mgr:getLotteryPrice(), function(success)
            if success then
                self.buyLock = true
                self.mgr:tryBuy()
            end
        end)     .setRechargeFunc(function()
            ClientHelper.onRecharge(1, "activity_lucky_disk_" .. self.mgr.mainConfig.id)
        end)
    end)
    self.mgr:registerCacheChange(function()
        if self:isShow() then
            self.buyLock = false
            self:refreshUI()
        end
    end)
    for index, siItem in pairs(self.itemsList) do
        siItem.click:registerEvent(GUIEvent.Click, function()
            self:updateLeftSide(index)
        end)
    end
end

function GUILuckyTurntablePanelWindow:updateLeftSide(index)
    local rewardList = self.mgr:getRewardCfg()
    if self.mgr.mainConfig.mainRewardId ~= rewardList[index].reward.rewardId then
        local rewardCfg = rewardList[index]
        self.mgr.mainConfig.mainRewardId = rewardCfg.reward.rewardId
        self.stItemName:SetText(Lang:getString(rewardCfg.reward.name))
        self.stItemDesc:SetText(Lang:getString(rewardCfg.reward.desc))
        self.super.showRewardDetail(self)
    end
end

function GUILuckyTurntablePanelWindow:onShow()
    self.super.onShow(self)
    self:refreshUI()
    self.buyLock = false
    self.mgr.mainConfig.mainRewardId = 0
    self:updateLeftSide(1)
end

---@param self GUILuckyTurntablePanelWindow
local function resetItemUI(self)
    for i, item in pairs(self.itemsList) do
        item.bg:SetDrawColor({ 1, 1, 1, 1 })
        item.icon:SetDrawColor({ 1, 1, 1, 1 })
        item.receive:SetVisible(false)
    end
end

function GUILuckyTurntablePanelWindow:refreshUI()
    self.super.refreshUI(self)
    resetItemUI(self)
    for i, cfg in pairs(self.mgr:getRewardCfg()) do
        self.itemsList[i].icon:SetImage(cfg.reward.image)
        self.itemsList[i].num:SetText(cfg.reward.num ~= 1 and cfg.reward.num)
        if i == 4 then
            if cfg.isCore == 2 then
                self.itemsList[i].bg:SetImage("set:game_activity_lucky_disk.json image:img_0_block_4")
            else
                self.itemsList[i].bg:SetImage("set:game_activity_lucky_disk.json image:img_0_block_4_2")
            end
        end
    end
    self.siClickPriceIcon:SetImage(PayHelper.getMoneyIcon(self.mgr.config.type))
    self:updatePriceUI()
end

function GUILuckyTurntablePanelWindow:updatePriceUI()
    local price = self.mgr:getLotteryPrice()
    if price ~= self.mgr.config.price then
        self.siClickPriceIcon:SetXPosition({ 0, -29 })
        self.stClickPriceTxt:SetText(TextFormat.colorYellow .. self.mgr.config.price .. " " .. TextFormat.colorWrite .. price)
        self.siClickPriceLine:SetVisible(true)
        self.stCountdown:SetVisible(false)
    else
        self.siClickPriceIcon:SetXPosition({ 0, -19 })
        self.stClickPriceTxt:SetText(self.mgr.config.price)
        self.siClickPriceLine:SetVisible(false)
        self.stCountdown:SetVisible(true)
    end
end

function GUILuckyTurntablePanelWindow:onTick()
    if not self.stCountdown:IsVisible() then
        return
    end
    if self.mgr:getPlayerCache().lastLotteryDay < DateUtil.getUTCDayStartTime(os.time()) then
        self:updatePriceUI()
    else
        local countdown = DateUtil.getFormatTime(DateUtil.getUTCDayEndTime(os.time()) - os.time())
        self.stCountdown:SetText(Lang:getString("bed_war_new_store_free_goods_refresh") .. countdown)
    end
end

return GUILuckyTurntablePanelWindow
