import os, zipfile, json, sys
import argparse
import subprocess
import re
import csv
import pandas as pd

shopConfig = {}
    
def get_json_data(filePath):
    file = open(filePath, mode = 'r')
    content = json.loads(file.read())
    file.close()
    return content

def check():
    itemRecordMap = {}
    for k, v in shopConfig.items():
        rewardId = v['rewardId']
        groupId = v['groupId']
        newKey = str(rewardId) + "_" + str(groupId)
        if not itemRecordMap.get(newKey):
            itemRecordMap[newKey] = []
        itemRecordMap.get(newKey).append(v)


    print("===============重复项（rewarId和groupId相同）================")
    for k, v in itemRecordMap.items():
        if len(v) > 1:
            strArr = k.split("_")
            print("rewardId :", int(strArr[1]))
            for i in range(len(v)):
                print("     ",v[i])


      

def read_csv():
    filePath = os.path.join(os.getcwd(), "plugins\\activity\RandomStore.csv")
    data = {}
    with open(filePath, encoding='utf-8')as f:
        reader = csv.reader(f)
        headers = next(reader)
        headerData = headers[0].split('\t')
        headers = next(reader)
        headers = next(reader)
        for row in reader:
            rowData = row[0].split("\t")
            data[int(rowData[0])] = {
                headerData[0] : int(rowData[0]),
                headerData[1] : int(rowData[1]),
                headerData[2] : int(rowData[2])
            }
    return data

if __name__ == "__main__":
    shopConfig = read_csv()
    check()
    input("press any key close")