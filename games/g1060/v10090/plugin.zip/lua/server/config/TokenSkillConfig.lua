
TokenSkillConfig = {}
TokenSkillConfig.Skills= {}



function TokenSkillConfig:init(temp)
    --print("TokenSkillConfig:init(temp)")
    for _, Value in pairs(temp) do
        table.insert(self.Skills, {
            Id = tonumber(Value.n_id),
            Name = Value.s_name,
            Desc = Value.s_desc,
            Icon = Value.s_icon,
            Hurt  = tonumber(Value.n_hurt),
            Cd = tonumber(Value.n_cd),
            MoneyType = tonumber(Value.n_moneyType),
            Price = tonumber(Value.n_price),
            --Unlock =  tonumber(Value.n_unlock) or 0, --解锁条件
            skillType =  tonumber(Value.n_skillType) or 0, --技能类型
            skillAnim = Value.s_skillAnim or "", --技能动作
            flySpeed = tonumber(Value.n_flySpeed) or 0, --飞行速度
            --yOffset = tonumber(Value.n_yOffset) or 0, --Y偏移
            flyTime = tonumber(Value.n_flyTime) or 0, --飞行时间
            rotationPitch = tonumber(Value.n_rotationPitch) or 0, --俯仰角
            advancedId = tonumber(Value.n_advancedId) or 0, --解锁的进阶等级
            isHave = tonumber(Value.n_isHave) or 0, --解锁后是否默认拥有
        })
        --print(Value.n_unlock)
    end

end

function TokenSkillConfig:getSkills()
    return self.Skills
end

function TokenSkillConfig:getSkillById(Id)

    for _, Value in pairs(self.Skills) do
        if Value.Id==Id then
            return Value
        end
    end
    return nil
end

function TokenSkillConfig:getSkillHurt(Id)
    for _, Value in pairs(self.Skills) do
        if Value.Id==Id then
            return Value.Hurt
        end
    end
    return GameConfig.damageCoe
end