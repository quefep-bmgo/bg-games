---
--- Created by Jimmy.
--- DateTime: 2018/3/8 0008 12:04
---
StringUtil = {}

---@return string[] | number[]
function StringUtil.split(str, reps, keep_blank, to_number)
    local result = {}
    if str == nil or reps == nil then
        return result
    end

    keep_blank = keep_blank or false
    if keep_blank then
        local startIndex = 1
        while true do
            local lastIndex = string.find(str, reps, startIndex)
            if not lastIndex then
                table.insert(result, string.sub(str, startIndex, string.len(str)))
                break
            end
            table.insert(result, string.sub(str, startIndex, lastIndex - 1))
            startIndex = lastIndex + string.len(reps)
        end
    else
        string.gsub(str, '[^' .. reps .. ']+', function(w)
            table.insert(result, w)
        end)
    end

    to_number = to_number or false
    if to_number then
        for i = 1, #result do
            result[i] = tonumber(result[i])
        end
    end

    return result
end

local function v2s(value, sp, restLevel, ignores)
    ignores = ignores or {}
    local typ = type(value)
    if typ == "string" then
        return '\"' .. value .. '\"'
    elseif typ ~= "table" then
        return tostring(value)
    end
    restLevel = restLevel or 3
    restLevel = restLevel - 1
    if restLevel < 0 then
        return "..."
    end
    local nsp = sp .. "  "
    local tb = {}
    local idxs = {}
    for k, v in ipairs(tb) do
        idxs[k] = true
        if not TableUtil.tableContain(ignores, k) then
            tb[#tb + 1] = "[" .. k .. "] = " .. v2s(v, nsp, restLevel)
        end
    end
    for k, v in pairs(value) do
        if not idxs[k] then
            if not TableUtil.tableContain(ignores, k) then
                k = (type(k) == "string") and ('\"' .. k .. '\"') or tostring(k)
                tb[#tb + 1] = "[" .. k .. "] = " .. v2s(v, nsp, restLevel)
            end
        end
    end
    if not tb[1] then
        return "{}"
    end
    nsp = "\n" .. nsp
    return "{" .. nsp .. table.concat(tb, "," .. nsp) .. "\n" .. sp .. "}";
end

function StringUtil.v2s(value, maxLevel, ignores)
    return v2s(value, "", maxLevel or 3, ignores)
end

function StringUtil.a2s(array)
    local result = "["
    for i, v in pairs(array) do
        if i == #array then
            result = result .. tostring(v)
        else
            result = result .. tostring(v) .. ","
        end
    end
    return result .. "]"
end

function StringUtil.reconstructName(name, colorful)
    if name == nil then
        return ""
    end
    name = name:gsub(TextFormat.colorStart, "")
    name = name:gsub("\n", " ")
    if string.find(name, "&$") and string.find(name, "$&") then
        return name
    end
    if type(colorful) == "string" and #colorful ~= 0 then
        local colors = StringUtil.split(colorful, "-")
        while #name + 1 < #colors do
            table.remove(colors)
        end
        colorful = table.concat(colors, "-")
        name = string.format("&$[%s]$%s$&", colorful, name)
    end
    return name
end

function StringUtil.getRealName(name)
    ---example name = &$[ffca00ff-fbd33fff-cad2ceff-23b8feff-677dffff-ac61ffff-fd15ffff]$vggcddf$&
    if string.find(name, "&$%[") then
        local names = StringUtil.split(name, "$")
        if #names >= 4 then
            table.remove(names, #names)
            table.remove(names, 1)
            table.remove(names, 1)
        end
        local real_name = ""
        for _, short_name in pairs(names) do
            real_name = real_name .. short_name
        end
        return real_name
    end
    return name
end

return StringUtil