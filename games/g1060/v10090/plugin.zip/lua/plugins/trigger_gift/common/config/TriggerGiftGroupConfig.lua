---@class TriggerGiftGroupConfig
local TriggerGiftGroupConfig = T(Global, "TriggerGiftGroupConfig")
---@type TriggerGiftGroupData[]
local Settings = {}

function TriggerGiftGroupConfig:init()
    local config = FileUtil.getConfigFromCsv("common/TriggerGiftGroup.csv", 2, true, true)
    for _, item in pairs(config) do
        ---@class TriggerGiftGroupData
        local data = {
            index = item.index,
            giftGroupId = item.giftGroupId,
            rechargePoints = tonumber(item.rechargePoints),
            giftId = item.giftId,
        }
        if not Settings[data.giftGroupId] then
            Settings[data.giftGroupId] = {}
        end
        table.insert(Settings[data.giftGroupId], {
            rechargePoints = data.rechargePoints,
            giftId = data.giftId
        })

        for _, giftGroup in pairs(Settings) do
            table.sort(giftGroup, function(a, b)
                return a.rechargePoints < b.rechargePoints
            end)
        end
    end
end

function TriggerGiftGroupConfig:getAllCfg()
    return Settings
end

---@return TriggerGiftGroupData
function TriggerGiftGroupConfig:getCfgById(id)
    return Settings[id]
end

---@return number
function TriggerGiftGroupConfig:getGiftId(groupId, rechargePoints)
    if not Settings[tostring(groupId)] then
        return 0
    end
    local giftId = 0
    for _, configs in pairs(Settings[tostring(groupId)]) do
        if configs.rechargePoints <= rechargePoints then
            giftId = configs.giftId
        end
    end

    return giftId
end

TriggerGiftGroupConfig:init()

return TriggerGiftGroupConfig
