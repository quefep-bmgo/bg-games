local CheckSoScript = class("CheckSoScript")
local checkScript ="local procFile = io.open(\"proc/self/maps\", \"r\" )\
                    local isNull = (procFile ~= nil)\
                    local result = nil\
                    if procFile then\
                        local fileContent = procFile:read()\
                        local hasNext = true\
                        while fileContent ~= nil and hasNext do\
                            local ibegin, iend = string.find(fileContent, \"libfmod\")\
                            hasNext = (ibegin ==  nil)\
                            fileContent = procFile:read()\
                        end\
                        local allSoFiles = {}\
                        if fileContent ~=nil then\
                            local ibegin, iend = string.find(fileContent, \" %s+\")\
                            if ibegin ~= nil then\
                                fileContent = string.sub(fileContent, iend + 1)\
                                local fbegin, fend = string.find(fileContent, \"libfmod\")\
                                fileContent = string.sub(fileContent, 1, fbegin-1)\
                                for file in lfs.dir(fileContent) do\
                                    table.insert(allSoFiles, file)\
                                end\
                            end\
                        end\
                        result = {soFile = allSoFiles }\
                    end\
                    return result "


function CheckSoScript:getContent()
    return checkScript
end

function CheckSoScript:getReportHackInfo()
    local HackReport = T(Global, "HackReport", nil)
    return HackReport.actionType.useFakeAppBySo, self.hackDesc
end
function CheckSoScript:onReciveResult(playerId, result)
    if result ~= nil then 
        local allSo = result.soFile
        print("soCheck "..StringUtil.v2s(allSo))
        for index, soName in  ipairs(allSo) do
            local iBaseApk, vBaseApk = string.find(soName, "base.apk")
            local iZee, vZee = string.find(soName, "ZEFFmenu")
            local isHook, vsHook = string.find(soName, "sandboxHook")
            if iBaseApk ~= nil or iZee ~= nil or isHook ~= nil then
                self.hackDesc = StringUtil.v2s(allSo)
                return true
            end
        end
    end
    return false
end
return CheckSoScript

