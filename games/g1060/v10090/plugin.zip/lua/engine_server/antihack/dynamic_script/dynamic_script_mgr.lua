local AntiScriptPlayerStatus = class("AntiScriptPlayerStatus")
AntiScriptPlayerStatus.nextScriptId = 1
AntiScriptPlayerStatus.nextSendTimer = nil

function AntiScriptPlayerStatus:onPlayerSendScript(curId, nextSendTimer)
    self.nextScriptId = curId + 1
    if self.nextSendTimer ~= nil then 
        LuaTimer:cancel(self.nextSendTimer)
    end
    self.nextSendTimer = nextSendTimer
end


---@class DynamicScriptMgr : IConnectorMsgHandler
local DynamicScriptMgr = class("DynamicScriptMgr", require "engine_base.connector.IConnectorMsgInterceptor")

---@type ConnectorCenter
local ConnectorCenter = T(Global, "ConnectorCenter", nil)

local Game2ConnectorMsgType = {
    ExecuteLuaResult = 10103, ---执行Lua代码结果回包数据
}

local Connector2GameMsgType = {
    ExecuteLuaCode = 10102, ---执行Lua代码
}

DynamicScriptMgr.scripts = {}
DynamicScriptMgr.nextScriptId = 1
DynamicScriptMgr.lastScriptId = 1
DynamicScriptMgr.PlyerStatus = {}

local baseCheckLua = "local checkFunc = function() \
                      %s \
                      end  \
                      local excuteRt = checkFunc() \
                      return {sType = %d, sRt = excuteRt} "
                     

function DynamicScriptMgr:init()
    local this = self
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, function(player)
        if PlayerManager:isAIPlayer(player) then
            return
        end
        this:onPlayerLogin(player)
    end)

    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, function(player)
        this:onPlayerLogout(player.userId)
    end)
    self:initScript()
end

function DynamicScriptMgr:initScript()
    self:registerScript(require "engine_server.antihack.dynamic_script.check_so")
end


function DynamicScriptMgr:initMsgFunc()
    self:registerMsgFunc(Game2ConnectorMsgType.ExecuteLuaResult, self.onReceiveExecuteLuaResult)
end


function DynamicScriptMgr:onPlayerLogin(player)
    self.PlyerStatus[player.userId] = AntiScriptPlayerStatus.new()
    self:sendScript(player.userId)
end

function DynamicScriptMgr:onPlayerLogout(playerId)
    local playerStatus = self.PlyerStatus[playerId]
    if playerStatus ~= nil and playerStatus.nextSendTimer ~= nil then
        LuaTimer:cancel(playerStatus.nextSendTimer)
    end
    self.PlyerStatus[playerId] = nil
end

function DynamicScriptMgr:registerScript(script)
    local rt = self.nextScriptId
    self.scripts[self.nextScriptId] = script
    self.lastScriptId = self.nextScriptId
    self.nextScriptId = self.nextScriptId + 1
    return rt
end

function DynamicScriptMgr:sendScript(playerId)
    local sendScriptId = self.PlyerStatus[playerId].nextScriptId
    local script = self.scripts[sendScriptId]
    local scriptContent = script:getContent()
    local sendScript = string.format(baseCheckLua, scriptContent, sendScriptId)
    print(sendScript)
    local this = self
    local nextSendScriptTimer = nil
    if sendScriptId ~= self.lastScriptId then
        nextSendScriptTimer= LuaTimer:schedule(function()
            this:sendScript(playerId) end, 5000, 0)
    end
    self.PlyerStatus[playerId]:onPlayerSendScript(sendScriptId, nextSendScriptTimer)

    local sendData = {}
    sendData.code = sendScript
    ConnectorCenter:onMsgReceive(Connector2GameMsgType.ExecuteLuaCode, { playerId }, json.encode(sendData))
end

function DynamicScriptMgr:onReceiveExecuteLuaResult(_, playerId, data)
    local success, resultBase = pcall(json.decode, data or "{}")
    local result = resultBase["result"]
    if result ~= nil and result.sType ~= nil then 
        local scriptId = result.sType
        local script = self.scripts[scriptId]
        local findHack = script:onReciveResult(playerId, result.sRt)
        if findHack then 
            self:handleHackPlayer(script, playerId)
        end
        local playerStatus = self.PlyerStatus[playerId]
        if playerStatus ~= nil then
            if playerStatus.nextScriptId > self.lastScriptId then
                self.PlyerStatus[playerId] = nil
            end
        end
    end
end

function DynamicScriptMgr:handleHackPlayer(script, playerId)
    local HackReport = T(Global, "HackReport")
    local hackType, hackReason = script:getReportHackInfo()
    HackReport:Report(playerId, hackType, hackReason)
    local player = PlayerManager:getPlayerByUserId(playerId)
    if player then
        CEvents.PlayerCheatEvent:invoke(player.rakssid, 16)
        HostApi.sendGameoverByPlatformUserId(playerId, "cheat detected", 16)
    end
end


---@type ConnectorInterceptor
local ConnectorInterceptor = T(Global, "ConnectorInterceptor", nil)
ConnectorInterceptor:registerInterceptor(T(Global, "ExecuteLuaResultInterceptor", DynamicScriptMgr.new()))