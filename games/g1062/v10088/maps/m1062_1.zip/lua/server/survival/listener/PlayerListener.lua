local PlayerListener = T(Global, "PlayerListener")
---@type SurvivalPlayer
local SurvivalPlayer = require "survival.entity.SurvivalPlayer"
---@type SParachuteCenter
local SParachuteCenter = T(Global, "SParachuteCenter")
---@type SSurvivalPacketSender
local SurvivalPacketSender = T(Global, "SurvivalPacketSender")
---@type ReportValue
local ReportValue = T(Global, "ReportValue")
---@type ReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type GameMsgServer
local GameMsgServer = T(Global, "GameMsgServer")
---@type SParachuteMgr
local SParachuteMgr = T(Global, "ParachuteMgr")

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerAttackedEvent, self.onPlayerHurt)
    BaseListener.registerCallBack(CEvents.PlayerDieEvent, self.onPlayerDied)
    BaseListener.registerCallBack(CEvents.PlayerDieTipEvent, self.onPlayerDiedTip)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)
    BaseListener.registerCallBack(CEvents.PlayerRespawnEvent, self.onPlayerRespawn)

    CEvents.PlayerPickupItemEndEvent:registerCallBack(self.onPlayerPickupItemEnd)
    CEvents.PotionCustomEvent:registerCallBack(self.onPotionCustom)
    CEvents.PlayerInventorySwapItemEvent:registerCallBack(self.onPlayerInventorySwapItem)
    CEvents.EntityDeathDropItemEvent:registerCallBack(self.onEntityDeathDropItem)
    CEvents.PlayerReloadBulletEvent:registerCallBack(self.onPlayerReloadBullet)
end

---@param clientPeer ClientPeer
function PlayerListener.onPlayerLogin(clientPeer)
    if isGameStart then
        return GameOverCode.GameStarted
    end
    if isGameEnd then
        return GameOverCode.GameEnd
    end
    local player = SurvivalPlayer.new(clientPeer)
    player:init()
    HostApi.sendGameStatus(player.rakssid, 1)
    HostApi.sendSetMoveState(player.rakssid, 2)
    ServerReportEvent.player_login(player)
    SParachuteCenter:onPlayerLogin(player)
    return GameOverCode.Success, player
end

---@param player SurvivalPlayer
function PlayerListener.onPlayerLogout(player)
    ServerReportEvent.player_logout(player)
    SParachuteCenter:onPlayerLogout(player)
    if not isGameStart then
        GameInfoManager:clearInfo("PlayerInfo", player.userId)
    end
    if isGameStart and not isGameEnd and player.isLife then
        ReportValue.setValue(player.userId, "die_reason", "logout")
        ReportEvent.reportEvent(player.userId, "survival_die_reason")
    end
end

---@param player SurvivalPlayer
function PlayerListener.onPlayerReady(player)
    HostApi.sendPlaySound(player.rakssid, 10000)
    DbUtil:getPlayerData(player)
    ServerReportEvent.player_ready(player)
    GameInfoManager.Instance():onPlayerReady(player)
    HostApi.setAutoShootEnable(player.rakssid, true)
    return GameConfig.isNightPotion and 43200 or 0
end

---@param hurtValue FloatProxy
function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    if not isGameStart or isGameEnd then
        return false
    end
    ---@type SurvivalPlayer
    local injured = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
    if not injured then
        return false
    end
    if damageType ~= "player.gun.headshot" and damageType ~= "player.gun" then
        if injured.hurtProtect then
            return false
        end
        injured.hurtProtect = true
        LuaTimer:cancel(injured.hurtProtectKey or 0)
        injured.hurtProtectKey = LuaTimer:schedule(function()
            injured.hurtProtect = false
        end, 500)
    end
    ---@type SurvivalPlayer
    local attacker = PlayerManager:getPlayerByPlayerMP(hurtFrom)
    if not attacker then
        ReportValue.setValue(injured.userId, "die_reason", damageType)
        return true
    end
    if injured:isTeammate(attacker) then
        return false
    end
    local armor = 0
    if injured.packetController then
        armor = injured.packetController:getArmorValue()
    end
    hurtValue.value = hurtValue.value * (1 - armor * 0.04)
    SurvivalPacketSender:sendHurtHint(injured, attacker:getPosition())
    ReportValue.setValue(injured.userId, "die_reason", damageType)
    ReportValue.setValue(injured.userId, "die_reason", damageType)
    return true
end

function PlayerListener.onPlayerDiedTip(diePlayer, killPlayer)
    return false
end

function PlayerListener.onPlayerDied(diePlayer, _, killPlayer)
    ---@type SurvivalPlayer
    local dead = PlayerManager:getPlayerByPlayerMP(diePlayer)
    if not dead then
        return true
    end
    if not isGameStart then
        dead:addHealth(10000)
        dead:teleWaitPos()
        return false
    end
    ---@type SurvivalPlayer
    local killer = PlayerManager:getPlayerByPlayerMP(killPlayer)
    if killer then
        killer.info:increaseValue("kill", 1)
        ReportValue.increaseValue(killer.userId, "kill_count", 1)
        ReportValue.increaseMultipleValue(killer.userId, "survival_gun_kill", {
            item_id = killer:getHeldItemId(),
        }, "kill_count", 1)
        GameMsgServer:broadCastKillMsg(killer.userId, dead.userId, 1)
    elseif ReportValue.getValue(dead.userId, "die_reason") == "poison.circle" then
        GameMsgServer:broadCastKillMsg(nil, dead.userId, 1, Define.MessageKillType.Dragon)
    end
    dead.info:increaseValue("die", 1)
    dead:onDie()
    GameMatch:ifGameOver()
    ReportEvent.reportEvent(dead.userId, "survival_die_reason")
    ------@type SBuffManager : IBuffManager
    local SBuffManager = T(Global, "BuffManager")
    SBuffManager:onPlayerDead(dead.userId)
    return true
end

---@param player SurvivalPlayer
function PlayerListener.onPlayerRespawn(player)
    SParachuteCenter:onPlayerRespawn(player)
    player.info:increaseValue("respawnTimes", 1)
    HostApi.setAutoShootEnable(player.rakssid, true)
    if player.packetController then
        player.packetController:onRespawn()
        if player.info:getValue("respawnTimes", true) > 0 then
            for _, itemData in pairs(GameConfig.respawnItemList) do
                player.packetController:pick(itemData.itemId, itemData.count)
            end
        end
    end
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    if not isGameStart then
        return true
    end
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil or player:isParachute() or player:isGlide() or SParachuteMgr:isPlayerInAirplane(player.userId) then
        return true
    end
    local curPos = VectorUtil.newVector3(x, y, z)
    local dis = 0
    local lastPos = ReportValue.getValue(player.userId, "last_pos")
    if lastPos then
        dis = VectorUtil.distanceXZ(lastPos, curPos)
    end
    ReportValue.setValue(player.userId, "last_pos", curPos)
    if dis ~= dis or dis <= -math.huge or dis >= math.huge then
    else
        ReportValue.increaseValue(player.userId, "move_dis", dis)
    end
    return true
end

function PlayerListener.onPotionCustom(entityId, itemId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return true
    end
    if itemId == 514 then
        player:addEffect(8, 45, 5)
        player:removeItem(itemId)
        return false
    end
    return true
end

function PlayerListener.onPlayerPickupItemEnd(rakssid, itemId, itemNum, _, entityId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    player:removeItem(itemId, itemNum)
end

function PlayerListener.onPlayerInventorySwapItem(userId, index1, index2)
    return false
end

function PlayerListener.onEntityDeathDropItem(entityId, damageType)
    return false
end

function PlayerListener.onPlayerReloadBullet(rakssid)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    ReportValue.increaseMultipleValue(player.userId, "survival_item_use", {
        item_id = player:getHeldItemId()
    }, "count", 1)
end

PlayerListener:init()
