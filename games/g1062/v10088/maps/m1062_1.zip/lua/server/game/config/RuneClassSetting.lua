---@class RuneClassSetting
local RuneClassSetting = T(Global, "RuneClassSetting")

local RuneClassMapping = {
    ["SwordRune"] = require "game.rune.SwordRune",
    ["ArrowRune"] = require "game.rune.ArrowRune",
    ["KnockBackRune"] = require "game.rune.KnockBackRune",
    ["SuckBloodRune"] = require "game.rune.SuckBloodRune",
    ["CritRune"] = require "game.rune.CritRune",
    ["SwordFireRune"] = require "game.rune.SwordFireRune",
    ["MaxHpRune"] = require "game.rune.MaxHpRune",
    ["AutoAddHpRune"] = require "game.rune.AutoAddHpRune",
    ["ReduceHurtRune"] = require "game.rune.ReduceHurtRune",
    ["MaxHpWithTimeRune"] = require "game.rune.MaxHpWithTimeRune",
    ["MaxHpWithBeginRune"] = require "game.rune.MaxHpWithBeginRune",
    ["OnDieCountDownRune"] = require "game.rune.OnDieCountDownRune",
    ["OnKillHpRune"] = require "game.rune.OnKillHpRune",
    ["OnKillGoldRune"] = require "game.rune.OnKillGoldRune",
    ["OnKillIronRune"] = require "game.rune.OnKillIronRune",
    ["OnKillWoolRune"] = require "game.rune.OnKillWoolRune",
    ["InitItemRune"] = require "game.rune.InitItemRune",
    ["RespawnItemRune"] = require "game.rune.RespawnItemRune"
}

local ConfigList = {}

function RuneClassSetting:init()
    local runeConfig = FileUtil.getConfigFromCsv("setting/RuneClassSetting.csv", 3)
    for _, config in pairs(runeConfig) do
        local rune = RuneClassMapping[config.Name].new(config)
        rune.id = tonumber(config.Id)
        rune.name = tostring(config.Name)
        rune.level = tonumber(config.Level)
        ConfigList[tonumber(config.Id)] = rune
    end
end

function RuneClassSetting:getRuneById(id)
    return ConfigList[tonumber(id)]
end

RuneClassSetting:init()

