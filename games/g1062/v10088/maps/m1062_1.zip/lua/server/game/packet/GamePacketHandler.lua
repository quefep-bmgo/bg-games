local handler = class("GamePacketHandler", EventObservable)

function handler:init()
    self:registerDataCallBack("SettlementGood", function(fromUserId, toUserId)
        SettlementManager:sendGood(fromUserId, toUserId)
    end)
    self:registerDataCallBack("PushSurveySuccess", function(userId)
        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            SurveyManager:onPlayerPushSurveySuccess(player)
        end
    end)
end

handler:init()