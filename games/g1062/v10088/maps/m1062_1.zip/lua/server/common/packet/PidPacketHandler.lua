---@type SPacketHandlers
local handler = T(Global, "PacketHandlers")
---@type ReportPlayerUtil
local ReportPlayerUtil = T(Global, "ReportPlayerUtil")
---@type ScoreActivityTaskMgr
local ScoreActivityTaskMgr = T(Global, "ScoreActivityTaskMgr")
---@type PropPacketManager
local PropPacketManager = T(Global, "PropPacketManager")

local faceOffset = {
    north = VectorUtil.newVector3(0, 0, 1),
    south = VectorUtil.newVector3(0, 0, -1),
    west = VectorUtil.newVector3(1, 0, 0),
    east = VectorUtil.newVector3(-1, 0, 0),
    bottom = VectorUtil.newVector3(0, -1, 0),
}

-----------------game---------------
---@param self ServerPlayer
function handler.OpenItemStore(self, packet)
    if self.gameDataController then
        self.gameDataController:have_open_item_store()
    end
end

---@param self ServerPlayer
function handler.OpenChatUI(self, packet)
    if self.gameDataController then
        self.gameDataController:have_open_chat()
    end
end

---@param self ServerPlayer
function handler.SendChatMessage(self, packet)
    if self.gameDataController then
        self.gameDataController:have_send_chat()
    end
end

---@param self ServerPlayer
function handler.TryBuyGuideGoods(self, packet)
    local isSuccess, itemId = GameStore:onPlayerBuyGoods(self.userId, packet.goodsId, 1, true)
    return itemId
end

---@param self ServerPlayer
function handler.buildBedProjectBlock(self, packet)
    if not isGameStart then
        return
    end
    local itemId = self:getHeldItemId()
    if itemId == BlockID.LADDER then
        return
    end
    local placeBlockId = itemId
    if placeBlockId > 2000 then
        placeBlockId = placeBlockId - 1000
    end
    local item = Item.getItemById(itemId)
    if not item then
        return
    end

    local class = item:getClassName()
    if class == "ItemBlock" or class == "ItemBlockImp" or class == "ItemCloth" or class == "ItemMultiTextureTile" then
        ---检查该坐标下方是否是床
        for _, value in pairs(faceOffset) do
            if EngineWorld:getBlockId(packet.pos) == 0 and EngineWorld:getBlockId(VectorUtil.add3(packet.pos, value)) == BlockID.BED then
                self:removeItem(itemId, 1)
                EngineWorld:setBlock(packet.pos, placeBlockId)
                return
            end
        end
    end
end

---@param self ServerPlayer
function handler.onCompassNotTarget(self, packet)
    if not isGameStart then
        return
    end
    local minDistance
    local targetPos
    local masterInfo = GameInfoManager:getPlayerInfo(self.userId)
    local players = PlayerManager:getPlayers2()
    local selfPos = self:getPosition()

    for _, player in pairs(players) do
        local playerInfo = GameInfoManager:getPlayerInfo(player.userId)
        if masterInfo:getValue("teamId") ~= playerInfo:getValue("teamId") then
            local dis = VectorUtil.distance(selfPos, player:getPosition())
            if not minDistance or dis < minDistance then
                targetPos = player:getPosition()
                minDistance = dis
            end
        end
    end
    return targetPos
end

---@param self ServerPlayer
function handler.usingHollowBlock(self, packet)
    if self.canUseHollowBlock then
        self:canUseHollowBlock()
    end
end

---@param self ServerPlayer
function handler.setGlideFromClient(self, packet)
    if self.setGlideFromClient then
        self:setGlideFromClient()
    end
end

-----------------hall---------------
---@param self SBasePlayer
function handler.searchPlayerLevelInfo(self, packet)
    self:syncLevelInfo()
end

-----------------common---------------

---@param self SBasePlayer
function handler.GameAnalytics(self, packet)
    local event_map = json.decode(packet.pushData)
    event_map.is_new = self.play_days <= 1
    GameAnalytics:newDesign(self.userId, packet.event, event_map or {})
end

---@param self SBasePlayer
function handler.ClickHotBar(self, packet)
    local slot = packet.index + Define.PROP_INDEX_START
    if slot >= Define.PROP_INDEX_START and slot <= Define.PROP_INDEX_END then
        self.entityPlayerMP:changeCurrentItemInMain(slot)
    else
        LogUtil.logError("pid = ClickHotBar , slot error")
    end
end

---@class EquipPropItemPacketData
---@field pid string
---@field itemId number
---
---@param self SBasePlayer
---@param packet EquipPropItemPacketData
function handler.EquipPropItem(self, packet)
    PropPacketManager:onEquipItem(self, packet.itemId)
end

---@class UnloadPropItemPacketData
---@field pid string
---@field itemId number
---
---@param self SBasePlayer
---@param packet UnloadPropItemPacketData
function handler.UnloadPropItem(self, packet)
    PropPacketManager:onUnloadItem(self, packet.itemId)
end

function handler:UpdateRunningFps(packet)
    self.minute_average_fps = packet.minute_average_fps
    self.minute_max_fps = packet.minute_max_fps
    self.minute_min_fps = packet.minute_min_fps
    self.total_average_fps = packet.total_average_fps
    self.minute_jank = packet.minute_jank
    ServerReportEvent.player_minute_fps(self)
end

function handler:UpdateRunningPing(packet)
    self.minute_average_ping = packet.minute_average_ping
    self.minute_max_ping = packet.minute_max_ping
    self.minute_min_ping = packet.minute_min_ping
    self.total_average_ping = packet.total_average_ping
    ServerReportEvent.player_minute_ping(self)
end

---@param self SBasePlayer
function handler.QualifyingMatchSuccess(self, packet)
    ServerReportEvent.player_match_success(self, packet.matchTime, packet.gameMode)
end

function handler.QualifyingMatchConfirm(self, packet)
    ServerReportEvent.player_match_confirm(self, packet.confirmTime)
end

function handler.QualifyingMatchReady(self, packet)
    ServerReportEvent.player_match_ready(self, packet.readyTime)
end

function handler.RechargeReport(self, packet)
    self.rechargeReportKey = packet.reportKey or ""
end

---@param self SBasePlayer
function handler.ReportPlayer(self, packet)
    ReportPlayerUtil:doReportPlayer(self, packet.userId, packet.reportIds)
end

---@param self SBasePlayer
function handler.ShowOnlineCreditScore(self, packet)
    return self.dailyCreditScore
end

function handler:ScoreActivityReceiveTask(packet)
    ScoreActivityTaskMgr:receiveTaskScore(self, packet.activityId, packet.taskId)
end

function handler.PlayerTicketTipGo(self, packet)
    if packet.type == 1 then
        if Plugins.CallTargetPluginFunc("cable_car", "checkPlayerOnCableCar", self.userId) then
            return
        end
        local param = StringUtil.split(packet.param, ",")
        local pos = VectorUtil.newVector3(tonumber(param[1]), tonumber(param[2]), tonumber(param[3]))
        self:teleportPosWithYaw(pos, tonumber(param[4]))
    end
end

---@param self SBasePlayer
function handler.syncRecordData(self, packet)
    ---@type SRecordUtil
    local SRecordUtil = T(Global, "SRecordUtil")
    local data = json.decode(packet.data)
    SRecordUtil:syncRecordData(self.userId, data)
end

---@param self SBasePlayer
function handler.syncLicensePageTime(self, packet)
    ---@type SGameLicense
    local SGameLicense = T(Global, "SGameLicense")
    SGameLicense:updateLicensePageTime(self, packet.time)
end