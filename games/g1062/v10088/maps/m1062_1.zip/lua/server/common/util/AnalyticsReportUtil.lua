AnalyticsReportUtil = {}

local reportItemList = { 3576, 3578, 1000, 1001, 595, 594, 593, 592, 591, 590, 585, 584, 583, 582, 346 }
local config = FileUtil.getConfigFromCsv("setting/StoreGoods.csv")
local allItemMap = {}
for _, item in pairs(config) do
    local Type = tonumber(item.Type)
    local ItemId = tonumber(item.ItemId)
    if Type == 0 then
        allItemMap[tostring(ItemId)] = 1
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.initNewItemRecord(player)
    player.newItemRecord = {}
    player.oldItemRecord = {}
    for _, itemId in pairs(reportItemList) do
        player.newItemRecord[tostring(itemId)] = {
            buyTimes = 0,
            useTimes = 0
        }
    end
    for itemId, _ in pairs(allItemMap) do
        if player.newItemRecord[tostring(itemId)] == nil then
            player.oldItemRecord[tostring(itemId)] = {
                buyTimes = 0,
                useTimes = 0
            }
        end
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.onPlayerBuyItem(player, itemId, num)
    if player.newItemRecord and player.newItemRecord[tostring(itemId)] then
        --GameAnalytics:newDesign(player.userId, "NewItemBuy", { itemId = itemId })
        player.newItemRecord[tostring(itemId)].buyTimes = player.newItemRecord[tostring(itemId)].buyTimes + num
    end
    if player.oldItemRecord and player.oldItemRecord[tostring(itemId)] then
        --GameAnalytics:newDesign(player.userId, "OldItemBuy", { itemId = itemId })
        player.oldItemRecord[tostring(itemId)].buyTimes = player.oldItemRecord[tostring(itemId)].buyTimes + num
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.onPlayerUseItem(player, itemId)
    if player.newItemRecord and player.newItemRecord[tostring(itemId)] then
        --GameAnalytics:newDesign(player.userId, "NewItemUse", { itemId = itemId })
        player.newItemRecord[tostring(itemId)].useTimes = player.newItemRecord[tostring(itemId)].useTimes + 1
    end
end

local WinTimes = 0
local LoseTimes = 0
---@param player GamePlayer
local function reportSettlementWinOrLose(player, isWin, rank)
    if isWin then
        WinTimes = WinTimes + 1
    else
        LoseTimes = LoseTimes + 1
    end
    print("reportSettlementWinOrLose", player.userId, isWin, rank, WinTimes, LoseTimes)
    if WinTimes > 8 or LoseTimes > 8 then
    end
    for itemId, record in pairs(player.newItemRecord) do
        if record.buyTimes > 0 then
            --GameAnalytics:newDesign(player.userId, "NewItemWinOrLose", { itemId = itemId, isWin = isWin })
        else
            --GameAnalytics:newDesign(player.userId, "NoBuyNewItemWinOrLose", { itemId = itemId, isWin = isWin })
        end
    end
    for itemId, record in pairs(player.oldItemRecord) do
        if record.buyTimes > 0 then
            --GameAnalytics:newDesign(player.userId, "OldItemWinOrLose", { itemId = itemId, isWin = isWin })
        else
            --GameAnalytics:newDesign(player.userId, "NoBuyOldItemWinOrLose", { itemId = itemId, isWin = isWin })
        end
    end
end