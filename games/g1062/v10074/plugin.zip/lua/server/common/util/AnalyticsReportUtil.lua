AnalyticsReportUtil = {}

local printToChat = function(userId, MessageTable)
    for _, msg in pairs(MessageTable) do
        if BaseMain:getGameType() == "g1046" then
            MsgSender.sendMsg(msg, "")
        else
            GamePacketSender:sendBedWarChatToAll(userId, msg)
        end
    end
end

local function getNumRange(rule_list, num)
    local minValue = nil
    for _, maxValue in pairs(rule_list) do
        if num <= maxValue then
            if not minValue then
                return "-" .. maxValue
            end
            return minValue .. "-" .. maxValue
        end
        minValue = maxValue
    end
    minValue = minValue or num or "error"
    return minValue .. "+"
end

local function design(userId, value, parts)
    if isTest then
        local MessageTable = {}
        table.insert(MessageTable, "----------------------report-----------------------------")
        table.insert(MessageTable, "userId : " .. tostring(userId))
        table.insert(MessageTable, "value : " .. tostring(value))
        for i, key in pairs(parts) do
            table.insert(MessageTable, "parts" .. i .. " : " .. tostring(key))
        end
        table.insert(MessageTable, "----------------------end-----------------------------")
        --printToChat(userId, MessageTable)
    end
    table.insert(parts, 1, "VersionForNewItem")
    GameAnalytics:design(userId, value, parts)
end

local reportItemList = { 3576, 3578, 1000, 1001, 595, 594, 593, 592, 591, 590, 585, 584, 583, 582, 346 }
local config = FileUtil.getConfigFromCsv("setting/StoreGoods.csv")
local allItemMap = {}
for _, item in pairs(config) do
    local Type = tonumber(item.Type)
    local ItemId = tonumber(item.ItemId)
    if Type == 0 then
        allItemMap[tostring(ItemId)] = 1
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.initNewItemRecord(player)
    player.newItemRecord = {}
    player.oldItemRecord = {}
    for _, itemId in pairs(reportItemList) do
        player.newItemRecord[tostring(itemId)] = {
            buyTimes = 0,
            useTimes = 0
        }
    end
    for itemId, _ in pairs(allItemMap) do
        if player.newItemRecord[tostring(itemId)] == nil then
            player.oldItemRecord[tostring(itemId)] = {
                buyTimes = 0,
                useTimes = 0
            }
        end
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.onPlayerBuyItem(player, itemId, num)
    if player.newItemRecord and player.newItemRecord[tostring(itemId)] then
        design(player.userId, 1, { "NewItemBuy", itemId })
        GameAnalytics:newDesign(player.userId, "NewItemBuy", { itemId = itemId })
        player.newItemRecord[tostring(itemId)].buyTimes = player.newItemRecord[tostring(itemId)].buyTimes + num
    end
    if player.oldItemRecord and player.oldItemRecord[tostring(itemId)] then
        GameAnalytics:newDesign(player.userId, "OldItemBuy", { itemId = itemId })
        player.oldItemRecord[tostring(itemId)].buyTimes = player.oldItemRecord[tostring(itemId)].buyTimes + num
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.onPlayerUseItem(player, itemId)
    if player.newItemRecord and player.newItemRecord[tostring(itemId)] then
        design(player.userId, 1, { "NewItemUse", itemId })
        GameAnalytics:newDesign(player.userId, "NewItemUse", { itemId = itemId })
        player.newItemRecord[tostring(itemId)].useTimes = player.newItemRecord[tostring(itemId)].useTimes + 1
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.reportDayLogin(player, isNew)
    if BaseMain:getGameType() == "g1046" or not AIManager:isAI(player.rakssid) then
        ---每天只上报一次
        if player.play_day_key ~= DateUtil.getYearDay() then
            design(player.userId, isNew and 1 or 0, { "DayLogin" })
        end

    end
end

function AnalyticsReportUtil.reportGameEnd()
    if BaseMain:getGameType() == "g1046" then
        return
    end
    local player = PlayerManager:getPlayers()[1]
    if player then
        design(player.userId, 1, { "GameEnd" })
    end
end

local WinTimes = 0
local LoseTimes = 0
---@param player GamePlayer
local function reportSettlementWinOrLose(player, isWin, rank)
    print("reportSettlementWinOrLose", player.userId, isWin, rank)
    if isWin then
        WinTimes = WinTimes + 1
    else
        LoseTimes = LoseTimes + 1
    end
    if WinTimes > 8 or LoseTimes > 8 then
        --print("[SCRIPT_EXCEPTION] Times > 8", WinTimes, LoseTimes)
    end
    for itemId, record in pairs(player.newItemRecord) do
        if record.buyTimes > 0 then
            GameAnalytics:newDesign(player.userId, "NewItemWinOrLose", { itemId = itemId, isWin = isWin })
        else
            GameAnalytics:newDesign(player.userId, "NoBuyNewItemWinOrLose", { itemId = itemId, isWin = isWin })
        end
    end
    for itemId, record in pairs(player.oldItemRecord) do
        if record.buyTimes > 0 then
            GameAnalytics:newDesign(player.userId, "OldItemWinOrLose", { itemId = itemId, isWin = isWin })
        else
            GameAnalytics:newDesign(player.userId, "NoBuyOldItemWinOrLose", { itemId = itemId, isWin = isWin })
        end
    end
end

---@param player GamePlayer
local function reportSettlementKill(player, times)
    design(player.userId, tonumber(times), { "SettlementKill" })

    for itemId, record in pairs(player.newItemRecord) do
        if record.buyTimes > 0 then
            design(player.userId, tonumber(times), { "NewItemKillNum", itemId })
        end
    end
end

---@param player GamePlayer
local function reportSettlementDie(player, times)
    design(player.userId, tonumber(times), { "SettlementDie" })

    for itemId, record in pairs(player.newItemRecord) do
        if record.buyTimes > 0 then
            design(player.userId, tonumber(times), { "NewItemDieNum", itemId })
        end
    end
end

---@param player GamePlayer
local function reportSettlementDestroyBed(player, times)
    design(player.userId, times, { "SettlementDestroyBed" })

    for itemId, record in pairs(player.newItemRecord) do
        if record.buyTimes > 0 then
            design(player.userId, tonumber(times), { "NewItemBreakBedNum", itemId })
        end
    end
end

---@param player GamePlayer
local function reportEachRankBuyItem(player, rank)
    for itemId, record in pairs(player.newItemRecord) do
        if record.buyTimes > 0 then
            design(player.userId, 1, { "EachRankBuyItem", rank .. "_" .. itemId })
        end
    end
end

---@param player GamePlayer
local function reportItemKill(player)
    local fishingKill = player.itemKillRecord[tostring(ItemID.FISHING_ROD)] or 0
    local killKey = fishingKill > 5 and "6+" or tostring(fishingKill)
    design(player.userId, 1, { "FishingRodKill", killKey })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportSettlement(player)
    if IsAIGame then
        return
    end
    ---@type PlayerInfo
    local playerInfo = GameInfoManager:getPlayerInfo(player.userId)
    if not playerInfo then
        return
    end
    if player.newItemRecord == nil then
        print("[SCRIPT_EXCEPTION]")
        print(debug.traceback())
        return
    end
    local rank = tonumber(playerInfo:getValue("rank"))
    reportSettlementKill(player, playerInfo:getValue("kill"))
    reportSettlementDie(player, playerInfo:getValue("die"))
    reportSettlementDestroyBed(player, #playerInfo:getValue("destroy_bed"))
    reportSettlementWinOrLose(player, rank <= 8, rank)
    reportEachRankBuyItem(player, rank)
    reportItemKill(player)
    player.newItemRecord = nil
end

---@param player GamePlayer
function AnalyticsReportUtil.reportAlarmWarning(player, time)
    design(player.userId, 1, { "AlarmWarning", getNumRange({ 0, 10, 20, 30 }, tonumber(time)) })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportAlarmDie(player, beKill)
    design(player.userId, 1, { "AlarmDie", beKill and 1 or 0 })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportDoubleResource(player, haveGet)
    design(player.userId, 1, { "DoubleDummyResource", haveGet and 1 or 0 })
end
---@param player GamePlayer
function AnalyticsReportUtil.reportDoubleDummyDie(player, killer)
    if not killer then
        design(player.userId, 1, { "DoubleDummyDie", 0 })
    else
        if killer == player then
            design(player.userId, 1, { "DoubleDummyDie", 2 })
        else
            design(player.userId, 1, { "DoubleDummyDie", 1 })
        end
    end
end

---@param player GamePlayer
function AnalyticsReportUtil.reportDiamondMineDie(player, dieType)
    design(player.userId, 1, { "DiamondMineDie", dieType })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportFrozenClipDie(player, dieType)
    design(player.userId, 1, { "FrozenClipDie", dieType })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportOutOfWorld(player, type)
    design(player.userId, 1, { "OutOfWorld", type })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportEnderDragonKills(player, num)
    design(player.userId, 1, { "EnderDragonKills", num })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportEnderDragonLifeTime(player, time)
    design(player.userId, 1, { "EnderDragonLifeTime", getNumRange({ 0, 10, 20, 30, 40, 50, 60 }, time) })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportEnderDragonBreakBlock(player, num)
    design(player.userId, 1, { "EnderDragonBreakBlock", getNumRange({ 0, 10, 20, 30, 40, 50, 60, 70, 80, 90 }, num) })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportEnderDragonOutOfWorld(player)
    design(player.userId, 1, { "EnderDragonOutOfWorld" })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportWitheredKills(player, num)
    design(player.userId, 1, { "WitheredKills", num })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportWitheredLifeTime(player, time)
    design(player.userId, 1, { "WitheredLifeTime", getNumRange({ 0, 10, 20, 30, 40, 50, 60 }, time) })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportWitheredBreakBlock(player, num)
    design(player.userId, 1, { "WitheredBreakBlock", getNumRange({ 0, 10, 20, 30, 40, 50, 60, 70, 80, 90 }, num) })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportWitheredOutOfWorld(player)
    design(player.userId, 1, { "WitheredOutOfWorld" })
end

---@param player GamePlayer
function AnalyticsReportUtil.reportBackPearlResult(player, isDead)
    design(player.userId, 1, { "BackPearlResult", isDead and 1 or 0 })
end