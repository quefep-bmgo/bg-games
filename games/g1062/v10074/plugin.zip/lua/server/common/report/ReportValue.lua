---@class ServerReportValue
local ValueUtil = {}


---player_login
---player_logout
---player_game_start: map_id
---player_game_end :map_id , is_complete , game_time ,average_fps
---player_minute_fps : map_id, minute , average_fps , nim_fps, max_fps
---server_game_end : map_id , game_time

---@return number
function ValueUtil.ai_game()
    return IsAIGame or false
end

---@return number
function ValueUtil.map_id()
    if GameType == "g1046" then
        return 0
    end
    return GameConfig.mapId
end

---@param player GamePlayer
---@return number
function ValueUtil.game_result_type(player)
    return player.gameResultType or Define.GameResult.QUIT
end

---@return number
function ValueUtil.game_running_second()
    return RewardManager:getGameRunningTime()
end
function ValueUtil.player_running_second(player)
    return os.time() - player.ready_time
end
function ValueUtil.player_running_minute(player)
    return math.floor((os.time() - player.ready_time) / 60)
end
function ValueUtil.minute_average_fps(player)
    return player.minute_average_fps or 0
end
function ValueUtil.minute_nim_fps(player)
    return player.minute_nim_fps or 0
end
function ValueUtil.minute_max_fps(player)
    return player.minute_max_fps or 0
end
function ValueUtil.total_average_fps(player)
    return player.total_average_fps or 0
end

return ValueUtil