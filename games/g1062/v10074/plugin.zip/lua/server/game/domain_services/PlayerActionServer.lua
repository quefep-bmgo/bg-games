---@class PlayerActionServer
local PlayerActionServer = {}

---@param dier GamePlayer
function PlayerActionServer.outOfWold(dier, killer)
    if dier.useHollowBlockTime and os.time() - dier.useHollowBlockTime < 15 then
        AnalyticsReportUtil.reportOutOfWorld(dier, "HollowBlock")
    end
    if dier.useBridgeEggTime and os.time() - dier.useBridgeEggTime < 8 then
        AnalyticsReportUtil.reportOutOfWorld(dier, "BridgeEgg")
    end
end

return PlayerActionServer