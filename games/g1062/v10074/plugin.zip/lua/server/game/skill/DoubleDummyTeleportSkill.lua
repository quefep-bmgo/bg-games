---@class DoubleDummyTeleportSkill : BaseSkill
local DoubleDummyTeleportSkill = class("DoubleDummyTeleportSkill", require "game.skill.BaseSkill")

function DoubleDummyTeleportSkill:doAction()
    local singingTime = tonumber(self.config.param[1])
    if not singingTime then
        return
    end
    ---@type GamePlayer
    local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
    if not self_player then
        return
    end
    self_player:startSinging(singingTime, true, nil, function()
        if self_player.double_dummy then
            self_player.double_dummy:trigger()
        end
    end)
end

return DoubleDummyTeleportSkill