---@class EnderPearlSkill : BaseSkill
local EnderPearlSkill = class("EnderPearlSkill", require "game.skill.BaseSkill")

function EnderPearlSkill:doAction()
    local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
    if self_player then
        self:telePos(self_player)
    end
end

return EnderPearlSkill