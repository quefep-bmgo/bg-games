---@class SnowBallInsectSkill : BaseSkill
local SnowBallInsectSkill = class("TownPortalSkill", require "game.skill.BaseSkill")

function SnowBallInsectSkill:doAction()
    ---@type GamePlayer
    local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
    if not self_player then
        return
    end
    local pos = VectorUtil.newVector3(self.initPos.x, self.initPos.y, self.initPos.z)
    EngineWorld:addSimpleEffect("explosion.effect", pos, self_player:getYaw(), self.duration, 0, 0.5)
    self.initPos.y = math.ceil(self.initPos.y)
    if MonsterManager:createMonster(self.initPos, Define.MonsterType.SnowBallInsect, self_player) then
        self_player:removeItem(self.itemId, 1)
    end
    self.super.doAction(self)
end

function SnowBallInsectSkill:onPlayerEffected(player)
    local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
    if not self_player then
        return
    end
    local yaw = player:getYaw()
    local x = -math.sin(yaw * MathUtil.DEG2RAD)
    local z = math.cos(yaw * MathUtil.DEG2RAD)
    if player.entityPlayerMP ~= nil then
        player.entityPlayerMP:knockBack(player.entityPlayerMP, 0.5, x, z)
    end
    local hurtValue = { value = self.damage }
    if PlayerAttackedEvent:invoke(player, self_player, "player", hurtValue) then
        player:subHealth(hurtValue.value)
    end
end

return SnowBallInsectSkill