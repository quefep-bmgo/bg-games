---@class FireBombSkill : BaseSkill
local FireBombSkill = class("FireBombSkill", require "game.skill.BaseSkill")

function FireBombSkill:doAction()
    local self_player = PlayerManager:getPlayerByUserId(self.creatorUid)
    local entity = EngineWorld:getEntity(self.itemEntityId)
    if not self_player or not entity then
        return
    end
    local pos = VectorUtil.newVector3(self.initPos.x, self.initPos.y, self.initPos.z)
    EngineWorld:getWorld():newExplosion(entity, self_player:getEntityPlayer(), pos, self.damage, true, true, self.duration, self.itemId)
    EngineWorld:addSimpleEffect("explosion.effect", pos, self_player:getYaw(), 1000, 0, 1)
end

return FireBombSkill