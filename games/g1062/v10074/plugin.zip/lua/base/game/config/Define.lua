

Define.PickUpItemMap = {
    [ItemID.INGOT_IRON] = true,
    [ItemID.INGOT_GOLD] = true,
    [ItemID.DIAMOND] = true,
    [ItemID.EMERALD] = true,
}

Define.MonsterType = {
    ServerMonster = 0,
    IronGolem = 1, ---铁傀儡
    SnowBallInsect = 2, ---囊虫
    Alarm = 3,  ---报警器
    DoubleDummy = 4,  ---替身傀儡
    DiamondMine = 5,  ---钻石地雷
    FrozenClip = 6,  ---冰冻夹子
}