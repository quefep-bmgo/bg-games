---示例
S2CLSOpenLottery = IScriptEvent.new()
CommonDataEvents:registerEvent("OpenLottery", S2CLSOpenLottery)

S2CMoveLimitCheck = IScriptEvent.new()
CommonDataEvents:registerEvent("MoveLimitCheck", S2CMoveLimitCheck)