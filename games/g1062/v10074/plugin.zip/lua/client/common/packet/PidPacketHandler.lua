local handler = {}
local observable = EventObservable.new()

observable:registerDataCallBack("pid", function(packetInJson)
    local packet = json.decode(packetInJson)
    local hand_func = handler[packet.pid]
    if hand_func then
        hand_func(PlayerManager:getClientPlayer(), packet)
    end
end)

function handler:AlarmWarning(packet)
    GUIMain:upScreenEffect(tonumber(packet.time))
    GUIBedWarGameTips:showGameTip(Lang:getString("prop.alarm.tip.warning"))
end

function handler:AlarmDisappear(packet)
    GUIBedWarGameTips:showGameTip(Lang:getString("prop.alarm.tip.disappear"))
end

function handler:ShowGameTip(packet)
    GUIBedWarGameTips:showGameTip(Lang:getString(packet.lang))
end

function handler:StartSinging(packet)
    GUIPlayerInfo:startSinging(packet.time or 1)
    GUIPlayerInfo:setSingingIcon(packet.icon or Define.SingingIcon.Teleport)
end

function handler:BreakSinging(packet)
    GUIPlayerInfo:breakSinging()
end

function handler:MountHurt(packet)
    local entityId = EntityCache:getClientId(tonumber(packet.entityId))
    local function setOnHurt(isHurting)
        local entity = EntityCache:getEntity(entityId)
        if not entity then
            return
        end
        entity.entity:setHurting(isHurting)
    end
    setOnHurt(true)
    LuaTimer:schedule(function()
        setOnHurt(false)
    end, 300)
end

function handler:UpdateItemCd(packet)
    GUIPlayerInventory:UpdateItemCd(packet.itemId, packet.totalTime, packet.curTime or packet.totalTime)
end

return handler