---@class GUISlideText : IGUIWindow
local GUISlideText = class("GUISlideText", IGUIWindow)
local count = 0
function GUISlideText:ctor(parent)
    self.super.ctor(self, "SlideText.json", parent)
end

function GUISlideText:onLoad(parent)
    count = count + 1
    local gvDetail = DynamicCast.dynamicCastWindow(GUIType.GridView, self.root)
    gvDetail:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.stText = GUIManager:createGUIWindow(GUIType.StaticText, "SlideText-Text-" .. count)
    self.stText:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 0, 0 })
    gvDetail:AddItem(self.stText)
    parent:AddChildWindow(gvDetail)
end

function GUISlideText:SetFont(font)
    self.stText:SetFont(font)
end

---@param property string
---@param value string
function GUISlideText:SetProperty(property, value)
    self.stText:SetProperty(property, value)
end

---@param lineExtraSpace number
function GUISlideText:SetTextLineExtraSpace(lineExtraSpace)
    self.stText:SetTextLineExtraSpace(lineExtraSpace)
end

---@param text string
---@param default_line_count number
function GUISlideText:SetText(text, default_line_count)
    self.stText:SetText(text)
    local total_height = 0
    if GUIFont.GetTextTotalHigh then
        total_height = self.stText:GetFont():GetTextTotalHigh(self.stText:GetPixelSize().x, text)
    elseif default_line_count then
        local one_line_height = self.stText:GetFont():GetFontHeight(text, 1)
        total_height = one_line_height * default_line_count
    end
    self.stText:SetHeight({ 0, total_height })
end

return GUISlideText
