---@class GUIGameScoreActivityRewardItem10Window : IGUIWindow
local GUIGameScoreActivityRewardItem10Window = class("GUIGameScoreActivityRewardItem10Window", IGUIWindow)

local QualityBgImage = {
	[1] = "set:game_activity_score_10.json image:img_0_itembd_blue",
	[2] = "set:game_activity_score_10.json image:img_0_itembd_purple",
	[3] = "set:game_activity_score_10.json image:img_0_itembd_yellow",
}

---@private
function GUIGameScoreActivityRewardItem10Window:ctor(_, mgr)
	self.super.ctor(self, "GameScoreActivityRewardItem10.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItem10Window:onLoad(mgr)
	self.mgr = mgr
	self.siBg = self:getChildWindowByName("GameScoreActivityRewardItem10-bg", GUIType.StaticImage)
	self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem10-Image", GUIType.StaticImage)
	self.siImageFrame = self:getChildWindowByName("GameScoreActivityRewardItem10-Image-Frame", GUIType.StaticImage)
	self.stCount = self:getChildWindowByName("GameScoreActivityRewardItem10-Count", GUIType.StaticText)
	self.siLimitIcon = self:getChildWindowByName("GameScoreActivityRewardItem10-LimitIcon", GUIType.StaticImage)
	self.stLimit = self:getChildWindowByName("GameScoreActivityRewardItem10-Limit", GUIType.StaticText)
	self.siPrice1Icon = self:getChildWindowByName("GameScoreActivityRewardItem10-Price1Icon", GUIType.StaticImage)
	self.stPrice1 = self:getChildWindowByName("GameScoreActivityRewardItem10-Price1", GUIType.StaticText)
	self.stPlus = self:getChildWindowByName("GameScoreActivityRewardItem10-Plus", GUIType.StaticText)
	self.siPrice2Icon = self:getChildWindowByName("GameScoreActivityRewardItem10-Price2Icon", GUIType.StaticImage)
	self.stPrice2 = self:getChildWindowByName("GameScoreActivityRewardItem10-Price2", GUIType.StaticText)
	self.siMask = self:getChildWindowByName("GameScoreActivityRewardItem10-Mask", GUIType.StaticImage)
	self.siYes = self:getChildWindowByName("GameScoreActivityRewardItem10-Yes", GUIType.StaticImage)
	self.siSelected = self:getChildWindowByName("GameScoreActivityRewardItem10-Selected", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItem10Window:initView()
	self.stPlus:SetText("+")
end

---@private
function GUIGameScoreActivityRewardItem10Window:initEvent()
	self.siBg:registerEvent(GUIEvent.Click, function()
		if not self.data then
			return
		end
		Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
	end)
end

---@param data table
function GUIGameScoreActivityRewardItem10Window:onDataChanged(data)
	self.data = data
	self.siImage:SetImage(data.reward.image)
	if data.reward.numLang ~= "#" then
		self.stCount:SetText("x" .. Lang:getString(data.reward.numLang))
	else
		self.stCount:SetText("")
	end
	self.stPlus:SetVisible(false)
	if data.price <= 0 then
		self.siPrice1Icon:SetVisible(false)
	else
		self.siPrice1Icon:SetVisible(true)
		self.siPrice1Icon:SetImage(PayHelper.getMoneyIcon(data.priceType))
		self.stPrice1:SetText(data.price)
	end
	if data.price2 <= 0 then
		self.siPrice2Icon:SetVisible(false)
	else
		self.siPrice2Icon:SetVisible(true)
		self.siPrice2Icon:SetImage(PayHelper.getMoneyIcon(data.priceType2))
		self.stPrice2:SetText(data.price2)

		if data.price <= 0 then
			self.siPrice2Icon:SetXPosition({0, 5})
		else
			self.stPlus:SetVisible(true)
			local tp1w = self.stPrice1:GetTextWidth()
			local p1w = self.siPrice1Icon:GetWidth()[2]
			local p1p = self.siPrice1Icon:GetXPosition()[2]
			local space = 3
			self.stPlus:SetXPosition({0, tp1w + p1w + p1p + space})
			local tpw = self.stPlus:GetTextWidth()
			local space1 = 12
			self.siPrice2Icon:SetXPosition({0, tpw + tp1w + p1w + p1p + space + space1 })
		end
	end

	if data.limit <= 0 then
		self.siLimitIcon:SetVisible(false)
	else
		self.siLimitIcon:SetVisible(data.limit > 1)
		local limit = self.mgr:getRewardLimit(data)
		if limit > 0 then
			self.stLimit:SetText(limit .. "/" .. data.limit)
			self.siMask:SetVisible(false)
		else
			self.siMask:SetVisible(true)
			self.stLimit:SetText(TextFormat.colorRed .. "0" .. TextFormat.colorWrite .. "/" .. data.limit)
		end
		self.siLimitIcon:SetXPosition({ 0, -self.stLimit:GetTextWidth() - 8 })
	end

	self.siBg:SetImage(QualityBgImage[self.data.quality] or QualityBgImage[1])
	self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)

	self.siImageFrame:SetVisible(false)

	if data.reward.needMask == 1 then
		self.siImageFrame:SetVisible(true)
		self.siImageFrame:SetImage("set:game_activity_score_10.json image:img_9_picframe")
	elseif data.reward.needMask == 2 then
		self.siImageFrame:SetVisible(true)
		self.siImageFrame:SetImage("set:bed_war_3_common_part.json image:edge")
	end
end

return GUIGameScoreActivityRewardItem10Window
