---@class GUIGameScoreActivityPanel10Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameScoreActivityPanel10Window = class("GUIGameScoreActivityPanel10Window", GUICommonActivityPanel)
---@type ScoreActivityConfig
local ScoreActivityConfig = T(Global, "ScoreActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function GUIGameScoreActivityPanel10Window:ctor(...)
	self.super.ctor(self, "GameScoreActivityPanel10.json", ...)
end

---@private
function GUIGameScoreActivityPanel10Window:onChildLoad()
	---@type CScoreActivityMgr
	self.mgr = self.mgr
	self.iconMovePos = 0
	self.iconMoveGap = 2
	self.siBg = self:getChildWindowByName("GameScoreActivityPanel10-Bg", GUIType.StaticImage)
	self.llLeft = self:getChildWindowByName("GameScoreActivityPanel10-Left", GUIType.Layout)
	self.siEffect = self:getChildWindowByName("GameScoreActivityPanel10-Effect", GUIType.StaticImage)
	self.siImage = self:getChildWindowByName("GameScoreActivityPanel10-Image", GUIType.StaticImage)
	self.siImageBack = self:getChildWindowByName("GameScoreActivityPanel10-Image-Back", GUIType.StaticImage)
	self.siImageTop = self:getChildWindowByName("GameScoreActivityPanel10-Image-Top", GUIType.StaticImage)
	self.siImageMask = self:getChildWindowByName("GameScoreActivityPanel10-Image-Mask", GUIType.StaticImage)
	self.btnExchange = self:getChildWindowByName("GameScoreActivityPanel10-Exchange", GUIType.Button)
	self.siDescLayout = self:getChildWindowByName("GameScoreActivityPanel10-DescLayout", GUIType.StaticImage)
	self.siRewardPanel = self:getChildWindowByName("GameScoreActivityPanel10-RewardPanel", GUIType.StaticImage)
	self.llRewardPool = self:getChildWindowByName("GameScoreActivityPanel10-RewardPool", GUIType.Layout)
	self.stRewardTitle = self:getChildWindowByName("GameScoreActivityPanel10-Reward-Title", GUIType.StaticText)
	self.btnRewardGo = self:getChildWindowByName("GameScoreActivityPanel10-Reward-Go", GUIType.Button)
	self.stTitle = self:getChildWindowByName("GameScoreActivityPanel10-Title", GUIType.StaticText)
	self.btnQuestion = self:getChildWindowByName("GameScoreActivityPanel10-Question", GUIType.Button)
	self.siTimeIcon = self:getChildWindowByName("GameScoreActivityPanel10-TimeIcon", GUIType.StaticImage)
	self.stTime = self:getChildWindowByName("GameScoreActivityPanel10-Time", GUIType.StaticText)
	self.llKillBroadCast = self:getChildWindowByName("GameScoreActivityPanel10-KillBroadCast", GUIType.Layout)

	self:initView()
	self:initEvent()
end

---@private
function GUIGameScoreActivityPanel10Window:initView()
	self.btnExchange:SetText(Lang:getString("gui.exchange"))
	self.stRewardTitle:SetText(Lang:getString("score.activity.reward.title"))
	local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
	self.lvRewards = IGUIGridView.new("GameScoreActivityPanel10-Rewards" .. self.activity.activityId, self.llRewardPool)
	self.lvRewards:setConfig(10, 10, 3)
	---@type ScoreActivityReward10Adapter
	self.rewardAdapter = UIHelper.requireAdapter("ScoreActivityReward10Adapter", false, "ui_activity").new()
	self.rewardAdapter:setActivityMgr(self.mgr)
	self.lvRewards:setAdapter(self.rewardAdapter)
	self.rewards = rewards
	self.rewardAdapter:setData(self.rewards)

	---@type GUINewKillBroadCastItem
	self.llNewKillBroadCastItem = UIHelper.newGameGUIWindow("GUINewKillBroadCastItem")
	self.llNewKillBroadCastItem.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.llNewKillBroadCastItem.root:SetVisible(false)
	self.llKillBroadCast:AddChildWindow(self.llNewKillBroadCastItem.root)
	self.llKillBroadCast:SetVisible(false)
end

local function lackOfMoney(self)
	if self.mgr.config.lackTipType ~= 0 then
		CustomDialog.builder()
					.setContentText(Lang:getString("gui_score_lack_money_" .. self.mgr.mainConfig.moneyType))
					.setHideLeftButton()
					.setRightText("gui_score_lack_money_go_tip")
					.setRightClickListener(function()
			if Plugins.CallTargetPluginFunc("cable_car", "checkPlayerOnCableCar", Game:getPlatformUserId()) then
				return
			end
			if self.mgr.config.lackTipType ~= 0 then
				PlayerManager:getClientPlayer():sendPacket({
					pid = "PlayerTicketTipGo",
					type = self.mgr.config.lackTipType,
					param = self.mgr.config.lackTipParam
				})
				GUIGameActivityLayout:hide(true)
			end
		end).show()
	end
end

---@private
function GUIGameScoreActivityPanel10Window:initEvent()
	self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
		if not self.curShowReward then
			return
		end
		if self.mgr:getScore() < self.curShowReward.score then
			CustomDialog.builder()
						.setContentText(Lang:getString("gui.lack.of.score." .. self:getActivityById()))
						.setHideLeftButton()
						.show()
			return
		end
		PayHelper.checkMoney(self.curShowReward.priceType, self.curShowReward.price, function(success)
			if success then
				PayHelper.checkMoney(self.curShowReward.priceType2, self.curShowReward.price2, function(success2)
					if success2 then
						CustomDialog.builder()
									.setContentText(Lang:getString("exchange.activity.buy.tip"))
									.setRightClickListener(function()
							self.mgr:tryGetReward(self.curShowReward.id)
						end)        .show()
					else
						if self.curShowReward.priceType2 == self.mgr.mainConfig.moneyType then
							lackOfMoney(self)
						end
					end
				end)
			else
				if self.curShowReward.priceType == self.mgr.mainConfig.moneyType then
					lackOfMoney(self)
				end
			end
		end)
	end)
	self.btnRewardGo:registerEvent(GUIEvent.ButtonClick, function()
		if self.mgr.config.lackTipType ~= 0 then
			PlayerManager:getClientPlayer():sendPacket({
				pid = "PlayerTicketTipGo",
				type = self.mgr.config.lackTipType,
				param = self.mgr.config.lackTipParam
			})
			GUIGameActivityLayout:hide(true)
		end
	end)
	self.btnQuestion:registerEvent(GUIEvent.ButtonClick, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("score.activity.help.title.10")
					.setContentText(Lang:getString("score.activity.help.content.10"))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)
	self.mgr:registerCacheChange(function()
		if self:isShow() then
			self:refreshUI()
		end
	end)
	self:registerEvent(Events.ShowScoreActivityRewardDetailEvent, function(activityId, data)
		if self:getActivityById() ~= activityId then
			return
		end
		self:showCurRewardDetail(data)
	end)
end

function GUIGameScoreActivityPanel10Window:refreshUI()
	if self.curShowReward then
		self:showCurRewardDetail(self.curShowReward)
	else
		if self.rewardAdapter then
			self.rewardAdapter:notifyDataChange()
		end
	end
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityPanel10Window:showCurRewardDetail(data)
	self.curShowReward = data
	self.llKillBroadCast:SetVisible(false)
	self.llNewKillBroadCastItem:onBroadCastEnd()
	self.siImageMask:SetVisible(false)
	self.btnExchange:SetVisible(true)
	self.btnExchange:SetTextColor({1, 1, 1, 1})
	self.btnExchange:SetEnabled(self.mgr:getRewardLimit(self.curShowReward) > 0)
	if self.mgr:getRewardLimit(self.curShowReward) <= 0 then
		self.btnExchange:SetTextColor({0.7, 0.7, 0.7, 1})
	end
	self.mgr.curShowRewardId = self.curShowReward.id
	if self.rewardAdapter then
		self.rewardAdapter:notifyDataChange()
	end
	local rewardDetail = RewardItemShowDetailConfig:getConfigById(data.reward.showDetailId)
	if not rewardDetail then
		self:setIcon(data.reward)
		self.tvName:SetText(Lang:getString(data.reward.name))
		self.siImage:SetVisible(true)
		self.awActor:SetVisible(false)
		return
	end
	self.tvName:SetText(Lang:getString(rewardDetail.name))
	self.tvRewardDesc:SetText(Lang:getString(rewardDetail.desc))
	self.siImage:SetVisible(rewardDetail.showType == Define.ShowDetailType.Icon)
	self.awActor:SetVisible(rewardDetail.showType == Define.ShowDetailType.Actor)
	if rewardDetail.showType == Define.ShowDetailType.Icon then
		self:setIcon(rewardDetail)
		if data.reward.needMask == 2 then
			self.siImageMask:SetVisible(true)
			self.siImageMask:SetImage("set:bed_war_3_common_part.json image:edge")
		end
	elseif rewardDetail.showType == Define.ShowDetailType.Actor then
		RewardItemShowDetailConfig:showActorSkill(self.awActor, rewardDetail, self.llSlideBlock)
	elseif rewardDetail.showType == Define.ShowDetailType.KillBroadCast then
		self.llKillBroadCast:SetVisible(true)
		local killBroadCastId = rewardDetail.id
		if CustomShopKillBroadCast and CustomShopKillBroadCast.Settings and CustomShopKillBroadCast.Settings[tostring(killBroadCastId)] then
			self.llNewKillBroadCastItem:showForShop(CustomShopKillBroadCast.Settings[tostring(killBroadCastId)])
		end
	end
end

---@param rewardDetail RewardItemShowDetailItem
function GUIGameScoreActivityPanel10Window:setIcon(rewardDetail)
	self.siImage:SetYPosition({ -0.05, self.iconMovePos })
	self.siImage:SetImage("")
	if rewardDetail.scale and rewardDetail.scale ~= "#" then
		UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180, rewardDetail.scale)
		UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180, rewardDetail.scale)
	else
		UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180)
		UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180)
	end
	LuaTimer:cancel(self.iconMoveTimer)
	self.iconMoveTimer = LuaTimer:scheduleTimer(function()
		if math.abs(self.iconMovePos) >= 15 then
			self.iconMoveGap = self.iconMoveGap * -1
		end
		self.iconMovePos = self.iconMovePos + self.iconMoveGap
		self.siImage:SetYPosition({ -0.05, self.iconMovePos })
	end, 100)
	self:addTimer(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel10Window:onHide()
	LuaTimer:cancel(self.iconMoveTimer)
	self.llNewKillBroadCastItem:onBroadCastEnd()
end

function GUIGameScoreActivityPanel10Window:onShow()
	self.btnExchange:SetEnabled(false)
	self.siImage:SetVisible(false)
	self.awActor:SetVisible(false)
	if not self.curShowReward then
		if self.rewards and self.rewards[1] then
			self.curShowReward = self.rewards[1]
		end
	end
	self:showRewardDetail()
	self:refreshUI()
end

function GUIGameScoreActivityPanel10Window:onDestroy()
	LuaTimer:cancel(self.iconMoveTimer or 0)
    RewardItemShowDetailConfig:onWindowHide(self.awActor)
	if self.mgr and self.mgr.registerCacheChange then
		self.mgr:registerCacheChange(nil)
	end
    self.super:onDestroy()
end

function GUIGameScoreActivityPanel10Window:showRewardDetail()
	if self.curShowReward then
		return
	end
	local activity = self.mgr.mainConfig
	local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
	for _, reward in pairs(rewards) do
		if reward.reward and reward.reward.rewardId == activity.mainRewardId then
			self:showCurRewardDetail(reward)
			break
		end
	end
end

return GUIGameScoreActivityPanel10Window
