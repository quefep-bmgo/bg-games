---@class GUIDebrisItemWindow : IGUIWindow
local GUIDebrisItemWindow = class("GUIDebrisItemWindow", IGUIWindow)

---@private
function GUIDebrisItemWindow:ctor(_,mgr)
	self.super.ctor(self, "DebrisItem.json", mgr)
end

---@private
function GUIDebrisItemWindow:onLoad(mgr)
	self.mgr=mgr
	self.siDebrisImage = self:getChildWindowByName("DebrisItem-DebrisImage", GUIType.StaticImage)
	self.stDebrisCount = self:getChildWindowByName("DebrisItem-DebrisCount", GUIType.StaticText)
	self.siDebrisMast = self:getChildWindowByName("DebrisItem-DebrisMast", GUIType.StaticImage)
	self.btnDebrisButton = self:getChildWindowByName("DebrisItem-DebrisButton", GUIType.Button)
	self:initView()
	self:initEvent()
end

---@private
function GUIDebrisItemWindow:initView()

end

---@private
function GUIDebrisItemWindow:initEvent()

end

---@private
function GUIDebrisItemWindow:refreshLangUI()
	self.btnDebrisButton:SetText(Lang:getString("activity.activateButton"))
end

function GUIDebrisItemWindow:addClickEvent(panel)
	self.btnDebrisButton:registerEvent(GUIEvent.ButtonClick, function()
		local activated = self.cache.activated or false
		local count = self.cache.count or 0
		local isActivate = false
		if not activated and count>0 then
			isActivate = true
		end
		panel:DebrisByClick(self.data.debrisId,isActivate)
	end)
end

---@param data table
function GUIDebrisItemWindow:onDataChanged(data)
	self.data=data
	local extends=StringUtil.split( data.extends, "&", true ,true) or {}
	local _top = extends[1] or 0
	local _right = extends[2] or 0
	local _bottom = extends[3] or 0
	local _left = extends[4] or 0
	local _width = math.max(1.0 - _left - _right, 0.1)
	local _height = math.max(1.0 - _top - _bottom, 0.1)
	local width = 1.0 / _width
	local height = 1.0 / _height
	local left = _left * width
	local top = _top * height
	self.siDebrisImage:SetArea({-left,0},{-top,0},{width,0},{height,0})
	self.siDebrisImage:SetImage(data.image)
end

function GUIDebrisItemWindow:onCacheChanged(cache)
	self.cache = self.cache or {}
	local activated = cache.activated or false
	local count = cache.count or 0
	if self.cache.activated ~= activated then
		if activated then
			self.siDebrisImage:SetImage(self.data.image.."_light")
		else
			self.siDebrisImage:SetImage(self.data.image)
		end
	end
	if self.cache.count ~= count then
		self.stDebrisCount:SetText(count)
	end
	self.btnDebrisButton:SetVisible(not activated and count > 0)
	self.cache = TableUtil.copyTable(cache)
end

return GUIDebrisItemWindow
