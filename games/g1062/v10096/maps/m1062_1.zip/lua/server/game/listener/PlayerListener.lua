local PlayerListener = T(Global, "PlayerListener")
---@type GamePlayer
local GamePlayer = require "game.entity.GamePlayer"
---@type PropPacketManager
local PropPacketManager = T(Global, "PropPacketManager")
---@type ReconnectUtil
local ReconnectUtil = T(Global, "ReconnectUtil")
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type GameResourceManager
local GameResourceManager = T(Global, "GameResourceManager")
---@type GameStateReport
local GameStateReport = T(Global, "GameStateReport")
---@type RuneManager
local RuneManager = T(Global, "RuneManager")
---@type PidPacketSender
local PidPacketSender = T(Global, "PidPacketSender")
---@type MapConfig
local MapConfig = T(Global, "MapConfig")

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerAttackedEvent, self.onPlayerHurtForSettlement)
    BaseListener.registerCallBack(CEvents.PlayerDieEvent, self.onPlayerDied)
    BaseListener.registerCallBack(CEvents.PlayerDieTipEvent, self.onPlayerDiedTip)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerUseCommonItemEvent:registerCallBack(self.onPlayerUseCommonItem)
    CEvents.ItemSkillConsumptionItemEvent:registerCallBack(self.onPlayerItemSkillConsumptionItem)
    CEvents.PlayerDropItemEvent:registerCallBack(self.onPlayerDropItem)
    CEvents.PlayerExchangeItemEvent:registerCallBack(self.onPlayerExchangeItem)
    CEvents.PlayerPickupItemEndEvent:registerCallBack(self.onPlayerPickupItemEnd)
    CEvents.PotionCustomEvent:registerCallBack(self.onPotionCustom)
    CEvents.ItemSkillNeedCustomSpeedEvent:registerCallBack(self.onItemSkillNeedCustomSpeed)
    CEvents.KnockBackExtraStrengthEvent:registerCallBack(self.onKnockBackExtraStrength)
    CEvents.PlayerAttackCreatureEvent:registerCallBack(self.onPlayerAttackCreature)
    CEvents.UseFishHookHitEntityEvent:registerCallBack(self.onUseFishHookHitEntity)
    CEvents.OnLaunchArrowEvent:registerCallBack(self.onLaunchArrow)
    CEvents.OnArrowHitEntityEvent:registerCallBack(self.onArrowHitEntity)
    CEvents.OnArrowHitGroundEvent:registerCallBack(self.onArrowHitGround)
    CEvents.InventoryStackChange:registerCallBack(self.onInventoryStackChange)
    CEvents.PlayerChangeItemInHandEvent:registerCallBack(self.onChangeItemInHand)
    CEvents.PlayerCheatEvent:registerCallBack(self.onPlayerCheat)
    CEvents.PlayerMovementInputEvent:registerCallBack(self.onPlayerMovementInput)
    CEvents.PlayerDoAttackEvent:registerCallBack(self.onPlayerDoAttack)
    CEvents.PlayerActionChangeEvent:registerCallBack(self.onPlayerActionChange)
    CEvents.EntityHealthChangeEvent:registerCallBack(self.onEntityHealthChange)
    CEvents.PlayerSendJumpChangedEvent:registerCallBack(self.onPlayerSendJumpChanged)
    CEvents.PlayerSendRotationEvent:registerCallBack(self.onPlayerSendRotation)
    CEvents.PlayerHurtEvent:registerCallBack(self.onPlayerHurtSubHealthEvent)

    Events.PlayerBuyGoodEvent:registerCallBack(self.onPlayerBuyGood)
    Events.PlayerClickMainControlEvent:registerCallBack(self.onPlayerClickMainControl)
    Events.PlayerUseActionEvent:registerCallBack(self.onPlayerUseAction)
    Events.PlayerIntoFollowModeEvent:registerCallBack(self.onPlayerIntoFollowMode)
    Events.PlayerInterrupt:registerCallBack(self.onPlayerInterrupt)
end

function PlayerListener.onPlayerExchangeItem(rakssid, type, itemId, itemMeta, itemNum, bullets, vec3)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    if type == 1 then
        return ItemHelper:canDropItem(player, itemId)
    elseif type == 2 then
        local item = Item.getItemById(itemId)
        if item and item:getClassName() == "ItemSword" then
            player:removeWoodSword()
        end
        return true
    end
end

---@param clientPeer ClientPeer
function PlayerListener.onPlayerLogin(clientPeer)
    if EngineVersionSetting.getEngineVersion() <= 10086 then
        return GameOverCode.GameOver
    end
    local userId = clientPeer:getPlatformUserId()
    ---@type GamePlayer
    local player = ReconnectUtil:findDroppedPlayer(userId)
    if isGameEnd then
        if player then
            player.entityPlayerMP = nil
        end
        return GameOverCode.GameEnd
    end
    if SettlementManager:getPlayerCount() >= PlayerManager:getRoomMaxPlayer() and not SettlementManager:isInGame(userId) then
        if player then
            player.entityPlayerMP = nil
        end
        return GameOverCode.GameEnd
    end
    local attr = GameServer:getRoomManager():getUserAttrInfo(userId)
    local info = GameInfoManager:getPlayerInfo(userId)
    if attr and not info then
        GameInfoManager:newPlayerInfo(userId)
        info = GameInfoManager:getPlayerInfo(userId)
        info:setValue("teamId", attr and attr.team or 1)
    end
    if isGameStart and not info:getBoolValue("isLogin") and clientPeer:getRakssid() > 100 then
        ReconnectUtil:clearGameServerData(userId)
        if player then
            player.entityPlayerMP = nil
        end
        return GameOverCode.GameStarted
    end
    info:setValue("isLogin", true)
    local isReconnect = false
    local logoutPos
    if attr and not attr.isRobot then
        local aiPlayer = AIManager:getAIByUserId(userId)
        if aiPlayer and PlayerManager:getPlayerByUserId(userId) then
            logoutPos = aiPlayer:getPosition()
            aiPlayer:logout(true)
        end
    end
    ---@type GamePlayer
    if not player then
        if info:getValue("rank", true) ~= 0 then
            ---游戏已结束
            return GameOverCode.GameOver
        end
        player = GamePlayer.new(clientPeer)
        player.isReconnect = false
        if logoutPos then
            player.logoutPos = logoutPos
            player:teleportPos(logoutPos)
        end
    else
        isReconnect = true
        player:ctor(clientPeer)
        player.isKeepItem = true
        player:setInventory()
        player.isReconnect = true
        ServerReportEvent.player_reconnect_succ(player)
    end
    player:init()
    SettlementManager:initPlayer(player)
    HostApi.sendGameStatus(player.rakssid, 1)
    HostApi.sendSetMoveState(player.rakssid, 2)
    ServerReportEvent.player_login(player)
    if attr then
        GameServer:getRoomManager():sendUserIn(attr.userId, attr.requestId)
    end
    SettlementManager:addPlayerInfo(player.userId, player.info)
    return GameOverCode.Success, player, nil, nil, (isReconnect and 3000 or -1)
end

---@param player GamePlayer
function PlayerListener.onPlayerLogout(player)
    CreditScoreUtil:onPlayerLogout(player)
    PropPacketManager:onPlayerDied(player)
    if not isGameStart then
        ---游戏没开始，正常退出
        ReconnectUtil:clearGameServerData(player.userId)
        GameStateReport:reportPlayerQuitGame(player)
        local attr = GameServer:getRoomManager():getUserAttrInfo(player.userId)
        if attr then
            GameServer:getRoomManager():sendUserOut(attr.userId, attr.requestId)
        end
        SettlementManager:removePlayerInfo(player)
        GameLottery:removePlayerLotteryInfo(player.userId)
    else
        if player.isLife then
            ReconnectUtil:addDroppedPlayer(player)
        end
    end
    GameMatch:onPlayerQuit(player)
    PlayerCustomInfoUtil:reportOnQuit(player)
    ServerReportEvent.player_logout(player)
    if player.isNew then
        ServerReportEvent.new_player_logout(player)
    end
end

---@param player GamePlayer
local function readyOnGameStart(player)
    if not player.isInitTeamItemFinished and player.team then
        for _, itemId in pairs(player.team.initItems or {}) do
            player:addInitItems(itemId)
        end
    end
    GamePacketSender:sendGameConfig(player)
    if player:checkConnectSuccessPlayerLife() then
        player:onSpawnInGame(Define.INIT_PLAYER_ITEM_TYPE.RECONNECT)
    end
end

---@param player GamePlayer
function PlayerListener.onPlayerReady(player)
    HostApi.sendPlaySound(player.rakssid, GameConfig.bgm or 10000)
    if GameConfig.skybox then
        player:sendPacket({
            pid = "SkyBoxChange",
            skybox = GameConfig.skybox,
        })
    end
    DbUtil:getPlayerData(player)
    player:checkParty()
    if GameConfig.openLotterySwitch == 1 then
        GamePacketSender:sendBedWarOpenLottery(player.rakssid)
    end
    if isGameStart then
        GameResourceManager:synTeamResource(player)
        HostApi.setAllowUseItemStatus(player.rakssid, 1)
    else
        HostApi.setAllowUseItemStatus(player.rakssid, 0)
    end
    GameInfoManager.Instance():onPlayerReady(player)
    if isGameStart then
        readyOnGameStart(player)
    end
    player.info:setValue("lifeStatus", player.isLife)
    GamePacketSender:sendMoveLimitCheck(player.rakssid)
    GameLottery:addPlayerLotteryInfo(player.userId)
    ServerReportEvent.player_ready(player)
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerHurtForSettlement(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---@type GamePlayer
    local needHurt = PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    if needHurt then
        ---@type GamePlayer
        local hurter = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
        ---@type GamePlayer
        local attacker = PlayerManager:getPlayerByPlayerMP(hurtFrom)
        if hurter and attacker then
            SettlementManager:onPlayerHurt(hurtPlayer:getPlatformUserId(), hurtFrom:getPlatformUserId(), hurtValue.value)
            if hurter.gameDataController then
                hurter.gameDataController:have_be_attacked()
            end
            if attacker.gameDataController then
                attacker.gameDataController:have_attack_player()
            end
        else
            SettlementManager:onPlayerHurt(hurtPlayer:getPlatformUserId(), nil, hurtValue.value)
        end
        if hurter and hurter.mount then
            hurter.mount:onHurt(hurtValue.value)
            needHurt = false
        end
    end
    return needHurt
end

function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---@type GamePlayer
    local hurter = PlayerManager:getPlayerByPlayerMP2(hurtPlayer)
    if hurter == nil then
        return false
    end
    if hurter.isInvincible then
        ---无敌时间
        return false
    end

    --- 分类型 受伤保护 cd
    local hurtLockCDKey = "other"
    if hurter.damageType == "counterattack" then
        hurtLockCDKey = "counterattack"
    elseif damageType == "generic" then
        hurtLockCDKey = "generic"
    end
    hurter.hurtLock = hurter.hurtLock or {}
    if hurter.hurtLock[hurtLockCDKey] then
        ---受伤保护时间
        return false
    end
    hurter.hurtLock[hurtLockCDKey] = LuaTimer:schedule(function()
        hurter.hurtLock[hurtLockCDKey] = nil
    end, 250)

    ---@type GamePlayer
    local fromer = PlayerManager:getPlayerByPlayerMP(hurtFrom)
    if fromer ~= nil then
        if damageType == "explosion.player" and fromer.onWithered then
            hurtValue.value = 0
            hurter:subHealth(GameConfig.tntExplosionDamageFactor)
        end
        hurter.damageType = "player"
    end
    if (fromer and AIManager:isAI(fromer.rakssid)) and not AIManager:isAI(hurter.rakssid or 0) then
        hurtValue.value = hurtValue.value * GameConfig.aiDamageCoefficient
    end

    if AIManager:isAI(hurter.rakssid) then
        local ai = AIManager:getAIByRakssid(hurter.rakssid)
        if ai then
            ai:onHurt()
        end
    end
    -- HostApi.log("onPlayerHurt " .. damageType)

    if not isGameStart then
        if damageType == "outOfWorld" then
            hurter:teleWaitPos()
        end
        return false
    end

    if damageType == "fall" then
        local blockId = EngineWorld:getBlockId(VectorUtil.getNegY(hurtPlayer:getPosition()))
        if blockId == 165 then
            return false
        end
        if InventoryUtil:getPlayerHasEquipItem(hurter, Define.ItemId.NinjaShoes) then
            return false
        end
        if InventoryUtil:getPlayerHasEquipItem(hurter, Define.ItemId.NinjaShoes) then
            return false
        end
        if hurter.ignoreOnceFall then
            return false
        end
        hurter.damageType = "fall"
    end

    if damageType == "explosion.player" or damageType == "explosion" then
        hurtValue.value = hurter:subApple(hurtValue.value)
        hurter.damageType = "explosion"
        return true
    end

    if damageType == "outOfWorld" then
        if hurter.isLife == false and hurter.realLife == false then
            hurter:teleWatchPos()
            return false
        end
        hurter.damageType = damageType
        hurtValue.value = hurter:subApple(hurtValue.value)
        hurter.damageType = "outOfWorld"
        return true
    end

    if damageType == "arrow" then
        hurter.damageType = "arrow"
    end

    if damageType == "onFire" then
        hurter.damageType = "onFire"
    end

    if hurtFrom == nil then
        hurtValue.value = hurter:subApple(hurtValue.value)
        return true
    end

    if fromer ~= nil then
        if hurter.team and fromer.team and hurter.team.id == fromer.team.id then
            return false
        end
        CreditScoreUtil:onPlayerActive(fromer)
        RuneManager:onAttack(fromer, hurtValue, damageType, hurter)
    end

    if damageType ~= "fall" and damageType ~= "explosion.player" and damageType ~= "explosion"
            and damageType ~= "outOfWorld" then
        hurter:addCustomEffect("beAttackEffect" .. tostring(hurter.userId), GameConfig.beAttackEffect, GameConfig.beAttackEffectTime * 1000)
    end

    RuneManager:onHurted(hurter, hurtValue)
    --- 计算防御扣血前
    if fromer ~= nil then
        --- 攻击无视护甲的伤害计算
        RuneManager:onCalcSubArmor(fromer, hurtValue, damageType, hurter)
        hurtValue.value = hurtValue.value + (hurter.addHurtValue or 0)
        hurter.addHurtValue = nil
    end
    if hurtValue.value < 1 then
        hurtValue.value = 1
    end
    hurtValue.value = hurter:subApple(hurtValue.value)
    Events.PlayerInterrupt:invoke(hurter.userId)
    print("[" .. hurter.userId ..  "]: hurtValue.value = ".. hurtValue.value)
    return true
end

--- 受到攻击后扣血回调
function PlayerListener.onPlayerHurtSubHealthEvent(hurtPlayer, hurtFrom, damageType, subHealth)
    -----@type GamePlayer
    local hurter = PlayerManager:getPlayerByPlayerMP2(hurtPlayer)
    --
    -----@type GamePlayer
    --local fromer = PlayerManager:getPlayerByPlayerMP(hurtFrom)
    --
    --local value = {value = subHealth}
    --RuneManager:onHurtedSubHealth(hurter, value, damageType, fromer)

    if hurter and hurter.showSuckBloodAndSubHealthMessage then
        hurter:sendPacket({
            pid = "showToast",
            content = "受伤-" .. subHealth
        })
    end
end

function PlayerListener.onPlayerDiedTip(diePlayer, killPlayer)
    return false
end

function PlayerListener.onPlayerDied(diePlayer, _, killPlayer)
    ---@type GamePlayer
    local dier = PlayerManager:getPlayerByPlayerMP2(diePlayer)
    if not dier then
        return true
    end
    PropPacketManager:onPlayerDied(dier)
    if not dier.isLife then
        return true
    end
    if not isGameStart then
        dier:setInventory()
        dier:clearInv()
        RespawnHelper.addRespawnCountdown(dier, 0)
        return true
    end
    dier.lastDieTime = os.time()

    ---@type GamePlayer
    local killer = PlayerManager:getPlayerByPlayerMP(killPlayer)
    if killer then
        killer:onKill(dier)
    end

    dier:clearEffects()
    dier:clearArmorInfo()
    dier:setInventory()
    dier:setEnderInventory()
    LuaTimer:schedule(function()
        dier:teleWatchPos()
    end, 0)
    dier:resetApple()
    dier.curApple = 0
    dier.maxApple = 0
    dier:updateApple()
    dier.deathNum = dier.deathNum + 1
    dier:resetHollowBlock()
    if killer then
        local useItemId = killer:getHeldItemId()
        if not killer.itemKillRecord[tostring(useItemId)] then
            killer.itemKillRecord[tostring(useItemId)] = 0
        end
        killer.itemKillRecord[tostring(useItemId)] = killer.itemKillRecord[tostring(useItemId)] + 1
    end
    if dier.damageType == "outOfWorld" then
        if dier.gameDataController then
            dier.gameDataController:hollow_die_count()
        end
    end
    GameMatch:onPlayerDie(dier)
    dier.multiKill = 0
    dier.info:setValue("lifeStatus", false)
    local ai = AIManager:getAIByRakssid(dier.rakssid)
    if ai ~= nil then
        ai:refreshInv()
        ai.isLife = false
    end
    if dier.backPearTimer ~= 0 and dier.backPearTimer ~= nil then
        LuaTimer:cancel(dier.backPearTimer)
        dier.backPearTimer = 0
    end
    ------@type SBuffManager : IBuffManager
    local SBuffManager = T(Global, "BuffManager")
    SBuffManager:onPlayerDead(dier.userId)
    return true
end

---@param player GamePlayer
function PlayerListener.onPlayerRespawn(player)
    if not isGameStart then
        AddMaxHPPrivilege:onPlayerRespawn(player)
        player:fillInvetory(player.inventory)
        player:teleWaitPos()
        PropPacketManager:onPlayerRespawn(player)
        return GameConfig.isNightPotion and 43200 or 0
    end
    RuneManager:onRespawn(player)
    AddMaxHPPrivilege:onPlayerRespawn(player)
    player:onSpawnInGame(Define.INIT_PLAYER_ITEM_TYPE.RESPAWN)
    player.info:increaseValue("respawnTimes", 1)
    PropPacketManager:onPlayerRespawn(player)
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerUseCommonItem(rakssid, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return
    end
    if itemId >= 467 and itemId <= 471 then
        local pos = player:getPosition()
        if BridgeConfig:buildBridge(itemId, player:getYaw(), VectorUtil.toBlockVector3(pos.x, pos.y - 1, pos.z)) then
            SettlementManager:addBuildScore(player.userId, Define.BuildType.Egg)
        end
    end
    GameStateReport:reportPlayerUseProp(player, itemId)
end

function PlayerListener.onPlayerItemSkillConsumptionItem(rakssid, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return
    end
    player.taskController:packingProgressData(Define.TaskType.Fright.UseProp, itemId, 1)
end

function PlayerListener.onPlayerDropItem(rakssid, itemId, itemMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end
    Events.PlayerInterrupt:invoke(player.userId)
    return ItemHelper:canDropItem(player, itemId)
end
----------------------------------------------------------------------------
-----------------------------  临时  ----------------------------------------
local iceTime = 3
local range = 1
function PlayerListener.changeBlockToIce(old_blockId, position, userId)
    if EngineWorld:getBlockId(position) ~= BlockID.PACKED_ICE then
        EngineWorld:setBlock(position, BlockID.PACKED_ICE)
    end
    LuaTimer:schedule(function()
        if EngineWorld:getBlockId(position) == BlockID.PACKED_ICE then
            local player = PlayerManager:getPlayerByUserId(userId)
            if not player then
                EngineWorld:setBlock(position, old_blockId)
                return
            end
            local newPos = player:getPosition()
            if math.abs(newPos.x - position.x) < range + 1 and
                    math.floor(newPos.y - 0.5) == position.y and
                    math.abs(newPos.z - position.z) < range + 1 then
                PlayerListener.changeBlockToIce(old_blockId, position, userId)
                return
            end
            EngineWorld:setBlock(position, old_blockId)
        end
    end, iceTime * 1000)
end

function PlayerListener.canBeIce(blockId)
    local oldItemId = ItemMapping:getOldItemId(ItemMapping:getOldItemId(blockId))
    if oldItemId == BlockID.OBSIDIAN or oldItemId == BlockID.SLIME then
        return false
    end
    return blockId ~= BlockID.AIR
            and blockId ~= BlockID.PACKED_ICE
            and blockId ~= BlockID.OBSIDIAN
            and blockId ~= BlockID.WATER_MOVING
            and blockId ~= BlockID.WATER_STILL
            and blockId ~= BlockID.FIRE
            and blockId ~= BlockID.WOOL_CARPET
end

---@param player GamePlayer
function PlayerListener.checkSkatingShoes(player, pos)
    if player.equip_iec then
        local cur_block_pos = VectorUtil.toBlockVector3(pos.x, pos.y, pos.z)
        local cur_block_id = EngineWorld:getBlockId(cur_block_pos)
        if cur_block_id == BlockID.FIRE then
            EngineWorld:setBlock(cur_block_pos, BlockID.AIR)
        end
        for i = pos.x - range, pos.x + range do
            for j = pos.z - range, pos.z + range do
                local position = VectorUtil.toBlockVector3(i, pos.y - 1, j)
                local floor_block_id = EngineWorld:getBlockId(position)
                if PlayerListener.canBeIce(floor_block_id) and EngineWorld:isBlockChange(position) then
                    PlayerListener.changeBlockToIce(floor_block_id, position, player.userId)
                end
            end
        end
    end
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return true
    end
    GameStateReport:reportPlayerPosition(player, VectorUtil.newVector3(x, y, z))
    if y <= GameConfig.deathLineY then
        if (isGameStart == false) then
            player:teleWaitPos()
        else
            player.damageType = "outOfWorld"
            player:subHealth(99999)
        end
    end
    if GameResourceManager:onPlayerMove(player, x, y, z) then
        if player.gameDataController then
            player.gameDataController:have_pick_resource_in_point()
        end
    end
    TeamConfig:onPlayerMove(player, x, y, z)
    local curPos = VectorUtil.newVector3(math.floor(x), math.floor(y), math.floor(z))
    if player.gameDataController and player.lastPos then
        if curPos.x ~= player.lastPos.x or curPos.z ~= player.lastPos.z then
            player.gameDataController:move_block_count()
        end
    end
    if player.realLife and movePlayer.onGround == true then
        if player:isGlide() then
            player:resetHollowBlock()
        end
        player.ignoreOnceFall = false
        if not player.lastGroundPos or VectorUtil.hashVector3(curPos) ~= VectorUtil.hashVector3(player.lastGroundPos) then
            player.lastGroundPos = curPos
        end
    end
    PlayerListener.checkSkatingShoes(player, VectorUtil.newVector3(x, y, z))

    local PresureBoardConfig = T(Global, "PresureBoardConfig")
    PresureBoardConfig:onPlayerMove(player)
    player.lastPos = curPos
    return true
end

function PlayerListener.onPlayerMovementInput(rakssid, forward, strafe)
    local player = PlayerManager:getPlayerByRakssid2(rakssid)
    if not player then
        return false
    end
    CreditScoreUtil:onPlayerMoveInput(player)
    GameStateReport:reportPlayerMoveInput(player, forward, strafe)
    return true
end

function PlayerListener.onPlayerPickupItemEnd(rakssid, itemId, itemNum, _, entityId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    GameResourceManager:onPickUpItem(player, entityId, itemId, itemNum)
    ItemHelper:tryChangePickUpItem(player, itemId)
end

function PlayerListener.onPotionCustom(entityId, itemId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return true
    end
    local effect = ItemPotionEffect:getPotionEffect(itemId)
    if not effect then
        return true
    end
    player:addEffect(effect.Type, effect.Duration, effect.Level)
    return false
end

function PlayerListener.onItemSkillNeedCustomSpeed(rakssid, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end

    if ItemID.FLARE_BOMB == itemId then
        return false
    end

    return true
end

function PlayerListener.onKnockBackExtraStrength(hurterEntityId, attackerEntityId, knockBackValue)
    local hurter = PlayerManager:getPlayerByEntityId(hurterEntityId)
    local attacker = PlayerManager:getPlayerByEntityId(attackerEntityId)

    if hurter and attacker then
        knockBackValue.value = knockBackValue.value + tonumber(attacker.info:getValue("runeAddKnockBackValue"))
    end
    return true
end

function PlayerListener.onPlayerUseAction(userId, actionId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    CommonPacketSender:sendUseActionToAll(player:getEntityId(), actionId)
end

function PlayerListener.onPlayerInterrupt(userId)
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    player:breakSinging()
end
function PlayerListener.onPlayerClickMainControl(userId)
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    Events.PlayerInterrupt:invoke(userId)
end

---@param player GamePlayer
function PlayerListener.onPlayerIntoFollowMode(player, follower)
    MapConfig:sendCurSelectMap(player)
    if isGameStart then
        GameResourceManager:synTeamResource(player)
    end
end

function PlayerListener.onPlayerAttackCreature(rakssid, entityId, attackType, position, damage, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    local monster = MonsterManager:getMonster(entityId)
    if monster == nil then
        return false
    end
    return monster:onAttacked(player, damage)
end

function PlayerListener.onUseFishHookHitEntity(anglerId, targetId)
    local angler = PlayerManager:getPlayerByEntityId(anglerId)
    local target = PlayerManager:getPlayerByEntityId(targetId)
    if not target or not angler then
        return true
    end

    if angler.isInvincible or target.isInvincible then
        return false
    end

    local anglerInfo = GameInfoManager:getPlayerInfo(angler.userId)
    local targetInfo = GameInfoManager:getPlayerInfo(target.userId)
    if not anglerInfo or not targetInfo then
        return true
    end

    if anglerInfo:getValue("teamId") == targetInfo:getValue("teamId") then
        return false
    end
    return true
end

function PlayerListener.onLaunchArrow(pos)
    PidPacketSender:broadcastSound(SoundConfig.launchArrow, pos)
end

function PlayerListener.onArrowHitGround(pos)
    if SoundConfig.hitGround ~= -1 then
        PidPacketSender:broadcastSound(SoundConfig.hitGround, pos)
        return false
    end
    return true
end

function PlayerListener.onArrowHitEntity(entityId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return
    end
    PidPacketSender:sendPlaySound(player.rakssid, SoundConfig.hitEntity)
end

function PlayerListener.onInventoryStackChange(rakssid, slot)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player then
        PropPacketManager:updateLuaPacket(player, slot)
        GameStateReport:reportPlayerProps(player, slot)
    end
end

function PlayerListener.onChangeItemInHand(rakssid, _, _)
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return
    end
    if player.gameDataController then
        player.gameDataController:have_hand_item_change()
    end
    GameStateReport:reportPlayerCurrentProp(player)
    return true
end

function PlayerListener.onPlayerCheat(rakssid, code)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return
    end
    ReconnectUtil:clearGameServerData(player.userId)
end

function PlayerListener.onPlayerActionChange(entityPlayerMP, action)
    local player = PlayerManager:getPlayerByPlayerMP2(entityPlayerMP)
    if not player then
        return
    end
    GameStateReport:reportPlayerAction(player, action)
end

function PlayerListener.onEntityHealthChange(entityId, health, maxHealth)
    local player = PlayerManager:getPlayerByEntityId2(entityId)
    if not player then
        return
    end
    GameStateReport:reportPlayerHealth(player, health, maxHealth)
end

function PlayerListener.onPlayerDoAttack(rakssid, targetPlayer, targetPos, distance)
    local attacker = PlayerManager:getPlayerByRakssid2(rakssid)
    if not attacker then
        return
    end
    local target = PlayerManager:getPlayerByPlayerMP2(targetPlayer)
    if not target then
        return
    end
    GameStateReport:reportPlayerAttack(attacker, target.userId, targetPos, distance)
end

function PlayerListener.onPlayerSendJumpChanged(rakssid, isJump)
    if not isJump then
        return
    end
    local player = PlayerManager:getPlayerByRakssid2(rakssid)
    if not player then
        return
    end
    GameStateReport:reportPlayerJump(player)
end

function PlayerListener.onPlayerSendRotation(rakssid, yaw, pitch)
    local player = PlayerManager:getPlayerByRakssid2(rakssid)
    if not player then
        return
    end
    GameStateReport:reportPlayerSendRotation(player, yaw, pitch)
end

PlayerListener:init()