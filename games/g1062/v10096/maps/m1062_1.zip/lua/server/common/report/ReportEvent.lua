---@param userId number userId [player userId]
---@param event number event [event name]
---@param event_map table event_map [eg {key1 = value1,key2 = value2, ...}]
local function newDesign(userId, event, event_map)
    if AIManager and AIManager:isAIByUserId(userId) then
        return
    end
    ---@type ServerPlayer
    local player = PlayerManager:getPlayerByUserId(userId)
    if player then
        event_map.is_new = player.play_days <= 1
    end
    GameAnalytics:newDesign(userId, event, event_map)
end

local config = FileUtil.getConfigFromCsv("setting/StoreGoods.csv", nil, true)
local allItemMap = {}
for _, item in pairs(config) do
    local Type = tonumber(item.Type)
    local ItemId = tonumber(item.ItemId)
    if Type == 0 then
        allItemMap[tostring(ItemId)] = true
    end
end
local BuyItemCache = {}
---@class ServerReportEvent : ReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type ServerReportValue
local ReportValue = require "common.report.ReportValue"

---@param attr UserAttrInfo
---@return number
function ReportEvent.player_attr(attr)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    newDesign(attr.userId, "player_attr", event_map)
end

---@param player ServerPlayer
---@return number
function ReportEvent.player_login(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    player.login_time = os.time()
    player.ready_time = player.login_time
    newDesign(player.userId, "player_login", event_map)
end
---@param player ServerPlayer
---@return number
function ReportEvent.player_ready(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    player.ready_time = os.time()
    newDesign(player.userId, "player_ready", event_map)

    local cache = {}
    for itemId, _ in pairs(allItemMap) do
        cache[tostring(itemId)] = 0
    end
    BuyItemCache[tostring(player.userId)] = cache
    ReportEvent.player_recharge_ready(player)
end


local function getId46Num(player)
    local num = 0
    for i, v in pairs(player.propPacketData) do
        if v.itemId == 46 then
            num = num + v.count
        end
    end
    local inv = player:getInventory()
    for slot = 0, 35 do
        local info = inv:getItemStackInfo(slot)
        if info.id == 46 then
            num = num + info.num
        end
    end
    return num
end

local function getRune10403Num(player)
    return player.runeController:getRuneNumById(10403)
end

function ReportEvent.player_abnormal_data_event(player)
    if GameType == "g1063" or GameType == "g1064" then
        return
    end
    if player.report_abnormal_data_day == os.date("%j", os.time()) then
        return
    end
    local id46Num = getId46Num(player)
    local rune10043Num = getRune10403Num(player)
    if player.yaoshi >= 99999 or id46Num >=10000 or rune10043Num >= 9 then
        ReportEvent.player_abnormal_data(player)
        player.report_abnormal_data_day = os.date("%j", os.time())
    end
end

function ReportEvent.player_abnormal_data(player)
    if player.total_recharge_cube == nil then
        LuaTimer:schedule(function()
            if player.entityPlayerMP then
                ReportEvent.player_abnormal_data(player)
            end
        end, 1000)
        return
    end

    local event_map = {}
    local key_list = {
        "abnormal_yaoshi_num",
        "total_recharge_cube",
        "play_days",
        "id_46_num",
        "rune_10403_num",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end

    newDesign(player.userId, "player_abnormal_data", event_map)
end

---@param player ServerPlayer
---@return number
function ReportEvent.player_recharge_ready(player)
    if player.total_recharge_cube == nil or player.have_cube_order == nil then
        LuaTimer:schedule(function()
            if player.entityPlayerMP then
                ReportEvent.player_recharge_ready(player)
            end
        end, 1000)
        return
    end
    local event_map = {}
    local key_list = {
        "total_recharge_cube",
        "have_cube_order",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_recharge_ready", event_map)
end

function ReportEvent.match_room(player)
    local event_map = {}
    local key_list = {
        "room_id",
        "is_in_team",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "match_time"
    }

    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "match_room", event_map)
end

---@param player ServerPlayer
---@return number
function ReportEvent.player_logout(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_hidden_score",
        "qualifying_score",
        "qualifying_brave_points",
        "qualifying_segment_grade_star",
        "equip_rune_num",
        "equip_rune_level",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_logout", event_map)
end

---@param player ServerPlayer
---@return number
function ReportEvent.player_game_start(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
        "match_id",
        "team_id",
        "is_in_team",
        "ai_count",
        "all_team_average_honor",
        "my_team_average_honor",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "player_waiting_second",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_game_start", event_map)
end

---@param player ServerPlayer
---@return number
function ReportEvent.player_game_end(player)
    local rank = tonumber(player.info:getValue("rank"))
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "robot_type",
        "map_id",
        "game_result_type",
        "player_running_second",
        "game_running_second",
        "player_waiting_second",
        "server_running_second",
        "total_average_fps",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_is_in_pos_match",
        "qualifying_add_qualifying_score",
        "qualifying_add_brave_point",
        "qualifying_is_in_team",
        "qualifying_is_consume_brave_score",
        "qualifying_segment_grade_star",
        "g1008_loser_streak",
        "match_id",
        "is_reconnect",
        "ai_count",
        "all_team_average_honor",
        "my_team_average_honor",
        "team_id",
        "is_in_team"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map["settlement_rank"] = rank
    event_map["registration_time_key"] = player.registrationTimeKey or 0

    local cache = BuyItemCache[tostring(player.userId)]
    if cache then
        local buy_ids = {}
        for itemId, count in pairs(cache) do
            if count > 0 then
                table.insert(buy_ids, tonumber(itemId))
            end
        end
        event_map["item_ids"] = "#" .. table.concat(buy_ids, "#")
    end

    newDesign(player.userId, "player_game_end", event_map)
end

---@return number
function ReportEvent.player_minute_fps(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
        "player_running_minute",
        "minute_average_fps",
        "minute_min_fps",
        "minute_max_fps",
        "total_average_fps",
        "minute_jank",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_minute_fps", event_map)
end

---@return number
function ReportEvent.player_minute_ping(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
        "player_running_minute",
        "minute_average_ping",
        "minute_min_ping",
        "minute_max_ping",
        "total_average_ping",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_minute_ping", event_map)
end

function ReportEvent.server_game_end()
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
        "game_running_second",
        "server_running_second",
        "match_id",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    newDesign(0, "server_game_end", event_map)
end

---@param player ServerPlayer
---@param goodsId number
---@return number
function ReportEvent.buy_custom_goods(player, goodsId)
    newDesign(player.userId, "buy_custom_goods", { goodsId = goodsId })
end

---@param player ServerPlayer
---@param itemId number
---@return number
function ReportEvent.buy_store_item(player, itemId)
    newDesign(player.userId, "buy_store_item", {
        item_id = itemId,
        ai_game = ReportValue.ai_game(player),
        game_mode = ReportValue.game_mode(player),
    })

    local cache = BuyItemCache[tostring(player.userId)]
    if cache and cache[tostring(itemId)] then
        cache[tostring(itemId)] = cache[tostring(itemId)] + 1
    end
end

---@param player ServerPlayer
function ReportEvent.new_player_logout(player)
    local event_map = {}
    local key_list = {
        "consecutive_login_days",
        "segment_score",
        "player_lv",
        "play_times_g1008",
        "win_rate_g1008_d",
        "play_times_g1062",
        "win_rate_g1062_d",
        "play_times_g1061",
        "win_rate_g1061_d",
        "ai_game_times",
        "ai_game_win_rate_d",
        "ai_in_last_1",
        "ai_in_last_3",
        "ai_in_last_5",
        "kill_avg_times_g1008_d",
        "die_avg_times_g1008_d",
        "kill_avg_times_ai_d",
        "die_avg_times_ai_d",
        "avg_play_time_g1008_d",
        "avg_play_time_ai_d",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "new_player_logout", event_map)
end

---@param player ServerPlayer
function ReportEvent.weekly_segment_score(player)
    local event_map = {}
    local key_list = {
        "is_new",
        "weekly_segment_score"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "weekly_segment_score", event_map)
end

---@param player ServerPlayer
function ReportEvent.recharge_success(player, reportKey, productId)
    local event_map = {}
    local key_list = {
        "total_recharge_cube"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.report_key = reportKey
    event_map.recharge_productId = productId
    newDesign(player.userId, "recharge_success", event_map)
end

---@param player SBasePlayer
function ReportEvent.activity_sign_in(player, id)
    local event_map = {}
    local key_list = {
        "cube_count",
        "total_recharge_cube"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.activity_sign_in_id = tonumber(id)
    newDesign(player.userId, "activity_sign_in", event_map)
end

function ReportEvent.qualifying_segment_change(player, isSegmentChange, isRise)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.qualifying_is_big_segment = isSegmentChange
    event_map.qualifying_is_rise = isRise   --- 段位变化，是否上升
    newDesign(player.userId, "qualifying_segment_change", event_map)
end

function ReportEvent.qualifying_quarter_grade_rise(player, gradeRiseTime)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.qualifying_grade_rise_time = gradeRiseTime
    newDesign(player.userId, "qualifying_quarter_grade_rise", event_map)
end

function ReportEvent.qualifying_quarter_Segment_rise(player, segmentRiseTime)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.qualifying_segment_rise_time = segmentRiseTime
    newDesign(player.userId, "qualifying_quarter_Segment_rise", event_map)
end

---@param player SBasePlayer
function ReportEvent.player_match_success(player, match_time, game_mode)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "qualifying_score",
        "server_time",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.match_time = tonumber(match_time)
    event_map.game_mode = tostring(game_mode)
    newDesign(player.userId, "player_match_success", event_map)
end

---@param player SBasePlayer
function ReportEvent.player_match_confirm(player, confirm_time)
    local event_map = {}
    local key_list = {
        "player_lv",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "qualifying_score",
        "server_time",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.confirm_time = tonumber(confirm_time)
    newDesign(player.userId, "player_match_confirm", event_map)
end

---@param player SBasePlayer
function ReportEvent.player_match_ready(player, ready_time)
    local event_map = {}
    local key_list = {
        "player_lv",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "qualifying_score",
        "server_time",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.ready_time = tonumber(ready_time)
    newDesign(player.userId, "player_match_ready", event_map)
end

function ReportEvent.reported_player(userId, report_id)
    local map = {
        report_id = tonumber(report_id),
    }
    newDesign(userId, "reported_player", map)
end

function ReportEvent.receive_qualifying_challenge(player, total_score, reward_score, total_streak)
    local map = {
        challenge_total_score = tonumber(total_score),
        challenge_reward_score = tonumber(reward_score),
        total_streak = tonumber(total_streak),
    }
    newDesign(player.userId, "receive_qualifying_challenge", map)
end

function ReportEvent.receive_qualifying_season_reward(player, reward_id, reward_type, qualifying_quarter, qualifying_grade)
    local map = {
        reward_type = tostring(reward_type),
        qualifying_quarter = tonumber(qualifying_quarter),
        season_reward_id = tonumber(reward_id),
        qualifying_grade = tostring(qualifying_grade)
    }
    newDesign(player.userId, "receive_qualifying_season_reward", map)
end

function ReportEvent.buy_qualifying_season_reward(player, qualifying_quarter, qualifying_grade)
    local map = {
        qualifying_quarter = qualifying_quarter,
        qualifying_grade = tostring(qualifying_grade)
    }
    newDesign(player.userId, "buy_qualifying_season_reward", map)
end

function ReportEvent.license_receive_award(userId, license_id, license_reward_id)
    local map = {
        license_id = tonumber(license_id),
        license_reward_id = tonumber(license_reward_id),
    }
    newDesign(userId, "license_receive_award", map)
end

function ReportEvent.license_page_stay(userId, license_id)
    local map = {
        license_id = tonumber(license_id),
    }
    newDesign(userId, "license_page_stay", map)
end

function ReportEvent.license_lv_change(userId, license_id, license_lv)
    local map = {
        license_id = tonumber(license_id),
        license_lv = tonumber(license_lv),
    }
    newDesign(userId, "license_lv_change", map)
end

function ReportEvent.license_task_complete(userId, license_id, license_task_id)
    local map = {
        license_id = tonumber(license_id),
        license_task_id = tonumber(license_task_id),
    }
    newDesign(userId, "license_task_complete", map)
end

function ReportEvent.activity_task_finish(userId, activity_id, activity_task_id)
    local map = {
        activity_id = tonumber(activity_id),
        activity_task_id = tonumber(activity_task_id),
    }
    newDesign(userId, "activity_task_finish", map)
end

---@param player GamePlayer
---@return number
function ReportEvent.player_waiting_time(player)
    local event_map = {}
    local key_list = {
        "player_waiting_second",
        "match_id",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_waiting_time", event_map)
end

---@param player GamePlayer
---@return number
function ReportEvent.player_reconnect_succ(player)
    local event_map = {}
    local key_list = {
        "is_reconnect",
        "match_id",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_reconnect_succ", event_map)
end

---@param player GamePlayer
---@return number
function ReportEvent.shop_cost(player, shopType, itemId, itemType, itemCount, currencyType, currencyCount, currencyBalance)
    if shopType == 2 and (itemType == GoodsType.Item or itemType == GoodsType.Armor or itemType == GoodsType.Upgrade or itemType == GoodsType.BulletClip) then
        return
    end
    local event_map = {}
    event_map.shop_type = shopType
    event_map.items_change = json.encode({
        item_id = itemId,
        item_type = itemType,
        quantity = itemCount,
    })
    event_map.currency_change = json.encode({
        currency_type = currencyType,
        currency_num = currencyCount,
    })
    event_map.currency_balance = json.encode({
        currency_type = currencyType,
        currency_num = currencyBalance,
    })
    newDesign(player.userId, "shop_cost", event_map)
end

function ReportEvent.buy_month_card(userId, cardId)
    local map = {
        month_card_id = tonumber(cardId),
    }
    newDesign(userId, "buy_month_card", map)
end

ServerReportEvent = ReportEvent
