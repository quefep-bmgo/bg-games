---@class UIGameRewardExchangeLayout : IGUILayout
local UIGameRewardExchangeLayout = class("UIGameRewardExchangeLayout", IGUILayout)

---@private
function UIGameRewardExchangeLayout:ctor(parent)
	self.super.ctor(self, "GameRewardExchange.json", parent)
end

---@private
function UIGameRewardExchangeLayout:isDelayLoad()
	return true
end

---@private
function UIGameRewardExchangeLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGameRewardExchangeLayout:initCreateEvent()

end

---@private
function UIGameRewardExchangeLayout:onLoad()
	self.siWnd = self:getChildWindow("GameRewardExchange-wnd", GUIType.StaticImage)
	self.stTitle = self:getChildWindow("GameRewardExchange-title", GUIType.StaticText)
	self.siTraIcon = self:getChildWindow("GameRewardExchange-tra_icon", GUIType.StaticImage)
	self.llItem1 = self:getChildWindow("GameRewardExchange-item1", GUIType.Layout)
	self.llItem2 = self:getChildWindow("GameRewardExchange-item2", GUIType.Layout)
	self.btnConfirm = self:getChildWindow("GameRewardExchange-confirm", GUIType.Button)
	self.btnClose = self:getChildWindow("GameRewardExchange-close", GUIType.Button)
	self:initView()
	self:initEvent()
end

---@private
function UIGameRewardExchangeLayout:initView()
	self.rewardQueue = {}
	self.stTitle:SetText(Lang:getString("gui.game.reward.exchange"))
	local btnArr = {self.llItem1, self.llItem2}
	self.rewardItems = {}
	for i, v in pairs(btnArr) do
		local rewardItem = GUIGameActivityRewardItem.new(self)
		v:AddChildWindow(rewardItem.root)
		self.rewardItems[i] = rewardItem
	end
	self.isLoaded = true
end

---@private
function UIGameRewardExchangeLayout:initEvent()
	self.btnConfirm:registerEvent(GUIEvent.ButtonClick, function()
		if #self.rewardQueue > 0 then
			self:nextReward()
		else
			self:hide()
		end
	end)
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		if #self.rewardQueue > 0 then
			self:nextReward()
		else
			self:hide()
		end
	end)
end

---@private
function UIGameRewardExchangeLayout:updateView(data)
	local rewardId = data.rewardId
	local targetId = data.targetId

	local reward = PluginMainActivity:getRewardById(rewardId)
	self.rewardItems[1]:setRewardData(reward)
	local target = PluginMainActivity:getRewardById(targetId)
	self.rewardItems[2]:setRewardData(target)
	self.btnConfirm:SetText(Lang:getString(#self.rewardQueue > 0 and "gui.next" or "gui.sure"))
end

---@private
function UIGameRewardExchangeLayout:onShow(data)
	self:updateView(data)
end

---@private
function UIGameRewardExchangeLayout:clickItem(item)
	GUICommonActivityRewardDetail:show(item.reward.showDetailId)
end

---@private
function UIGameRewardExchangeLayout:addQueue(data)
	table.insert(self.rewardQueue, data)
	self.btnConfirm:SetText(Lang:getString("gui.next"))
end

---@private
function UIGameRewardExchangeLayout:nextReward()
	if not self.rewardQueue[1] then
		self:hide()
		return
	end
	local showInfo = self.rewardQueue[1]
	table.remove(self.rewardQueue,1)
	self:updateView(showInfo)
end

return UIGameRewardExchangeLayout
