---@class UIPetChangeSkillContentLayout : IGUILayout
local UIPetChangeSkillContentLayout = class("UIPetChangeSkillContentLayout", IGUILayout)

---@type PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")
---@type PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")

---@private
function UIPetChangeSkillContentLayout:isDelayLoad()
	return true
end

---@private
function UIPetChangeSkillContentLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIPetChangeSkillContentLayout:initCreateEvent()

end

---@private
function UIPetChangeSkillContentLayout:onLoad()
	self.awActorWnd = self:getChildWindow("PetChangeSkillContent-ActorWnd", GUIType.ActorWindow)
	self.siNameBg = self:getChildWindow("PetChangeSkillContent-NameBg", GUIType.StaticImage)
	self.stNameText = self:getChildWindow("PetChangeSkillContent-NameText", GUIType.StaticText)
	self.siLevelBg = self:getChildWindow("PetChangeSkillContent-LevelBg", GUIType.StaticImage)
	self.stLevelText = self:getChildWindow("PetChangeSkillContent-LevelText", GUIType.StaticText)
	self.siSkillDescBg = self:getChildWindow("PetChangeSkillContent-SkillDescBg", GUIType.StaticImage)
	self.stSkillDescTitle = self:getChildWindow("PetChangeSkillContent-SkillDescTitle", GUIType.StaticText)
	self.stSkillDesc = self:getChildWindow("PetChangeSkillContent-SkillDesc", GUIType.StaticText)
	self.btnPreviewBtn = self:getChildWindow("PetChangeSkillContent-PreviewBtn", GUIType.Button)
	self.stPreviewText = self:getChildWindow("PetChangeSkillContent-PreviewText", GUIType.StaticText)
	self.btnOkBtn = self:getChildWindow("PetChangeSkillContent-OkBtn", GUIType.Button)
	self.siMoneyType = self:getChildWindow("PetChangeSkillContent-Money-Type", GUIType.StaticImage)
	self.stPrice = self:getChildWindow("PetChangeSkillContent-Price", GUIType.StaticText)
	self.stOkBtnText = self:getChildWindow("PetChangeSkillContent-OkBtn-Text", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIPetChangeSkillContentLayout:initView()
	self.stSkillDescTitle:SetText(Lang:getString("custom.shop.pet.max.lv.info.desc"))
	self.stPreviewText:SetText(Lang:getString("custom.shop.pet.preview.skill"))
	self.stOkBtnText:SetText(Lang:getString("custom.shop.pet.change.skill"))
end

---@private
function UIPetChangeSkillContentLayout:initEvent()
	self.btnPreviewBtn:registerEvent(GUIEvent.ButtonClick, function()
		GUIPetSkillPreview:show()
	end)

	self.stPreviewText:registerEvent(GUIEvent.ButtonClick, function()
		GUIPetSkillPreview:show()
	end)

	self.btnOkBtn:registerEvent(GUIEvent.ButtonClick, function()
		local player = PlayerManager:getClientPlayer()
		if player and self.petId then
			if not self.buyLock then
				self.buyLock = true
				PetUpgradeShop:onBuyPetRandomSkill(player, self.petId)
			end
		end
	end)

	self:registerEvent(Events.PetChangeSkillSuccess, function(petId, imbueGroupId)
		self.curImbueGroupId = imbueGroupId
		local maxLv = PetLvConfig:getMaxLv(tostring(petId))
		local desc = PetLvConfig:getDesc(petId, maxLv, imbueGroupId)
		self.stSkillDesc:SetText(desc)
	end)

	self:registerEvent(Events.PetRandomSkillResult, function(petId, newImbueGroupId)
		self.buyLock = false
		GUIPetChangeSkillConfirm:show(petId, self.curImbueGroupId, newImbueGroupId)
	end)
end

function UIPetChangeSkillContentLayout:setData(petId)
	self.petId = petId
	local setting = CustomShopPet.Settings[tostring(petId)]
	local goodsCfg = CustomShopConfig:getGoodsConfigBySetting(setting.Id)
	if (GameType == "g1046" and (goodsCfg.Time == -1 or goodsCfg.Time > 0)) then
		self.btnOkBtn:SetEnabled(true)
	else
		self.btnOkBtn:SetEnabled(false)
	end

	local maxLv = PetLvConfig:getMaxLv(tostring(petId))
	local uiScale = PetLvConfig:getUIScale(petId)
	local player = PlayerManager:getClientPlayer()
	if player then
		self.curImbueGroupId = player.randomSkillData[tostring(petId)]
		local desc = PetLvConfig:getDesc(petId, maxLv, self.curImbueGroupId)
		self.awActorWnd:SetActor1(setting.ActorName, "idle", 0)
		self.awActorWnd:SetActorScale(uiScale)
		self.stNameText:SetText(Lang:getString(goodsCfg.Name))
		self.stLevelText:SetText(Lang:getString("custom.shop.pet.max.lv.info.lv")..maxLv)
		self.stSkillDesc:SetText(desc)
	end
	self.siMoneyType:SetImage(PayHelper.getMoneyIcon(Define.Money.PET_SKILL_STONE))
	self.stPrice:SetText(Define.PET_RANDOM_SKILL_PRICE)
end

return UIPetChangeSkillContentLayout
