---@class UIBedWarPassBuyLayout : IGUILayout
local UIBedWarPassBuyLayout = class("UIBedWarPassBuyLayout", IGUILayout)

---@type CGamePass
local CGamePass = T(Global, "CGamePass")

local ItemWidth = 97
local ItemSpace = 13
local colMaxCount = 7

---@private
function UIBedWarPassBuyLayout:ctor(parent)
	self.super.ctor(self, "BedWarPassBuy.json", parent)
end

---@private
function UIBedWarPassBuyLayout:isDelayLoad()
	return true
end

---@private
function UIBedWarPassBuyLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIBedWarPassBuyLayout:initCreateEvent()

end

---@private
function UIBedWarPassBuyLayout:onLoad()
	self.btnMaskClose = self:getChildWindow("BedWarPassBuy-Mask-Close", GUIType.Button)
	self.llContent = self:getChildWindow("BedWarPassBuy-Content", GUIType.Layout)
	self.stTitle = self:getChildWindow("BedWarPassBuy-Title", GUIType.StaticText)
	self.btnClose = self:getChildWindow("BedWarPassBuy-Close", GUIType.Button)
	self.siPriceTitleBg = self:getChildWindow("BedWarPassBuy-Price-Title-bg", GUIType.StaticImage)
	self.stPriceTitleText = self:getChildWindow("BedWarPassBuy-Price-Title-Text", GUIType.StaticText)
	self.siPriceListBg = self:getChildWindow("BedWarPassBuy-Price-List-bg", GUIType.StaticImage)
	self.llPriceListLayout = self:getChildWindow("BedWarPassBuy-Price-List-Layout", GUIType.Layout)
	self.btnBuy = self:getChildWindow("BedWarPassBuy-Buy", GUIType.Button)
	self.stBuyText = self:getChildWindow("BedWarPassBuy-Buy-Text", GUIType.StaticText)
	self.siCubeIcon = self:getChildWindow("BedWarPassBuy-Cube-Icon", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function UIBedWarPassBuyLayout:initView()
	self.stTitle:SetText(Lang:getString("gui_license_big_price_title"))
	self.stPriceTitleText:SetText(Lang:getString("gui_bed_war_pass_get_all_title"))
	self.stBuyText:SetText(Lang:getString("gui_bed_war_pass_get_all_buy_tip"))

	self.gvRewardList = IGUIGridView.new("BedWarPassBuy-List-Layout-Items", self.llPriceListLayout)
	self.gvRewardList:setConfig(ItemSpace, ItemSpace, colMaxCount)

	---@type PassRewardListAdapt
	self.rewardListAdapt = UIHelper.newGameAdapter("PassRewardItemAdapt")
	self.rewardListAdapt:setItemSize(ItemWidth, ItemWidth)
	self.gvRewardList:setAdapter(self.rewardListAdapt)
end

---@private
function UIBedWarPassBuyLayout:initEvent()
	self.btnMaskClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		if self.buyType and self.price then
			PayHelper.checkMoney(CurrencyId.Diamonds, self.price, function(isSuccess)
				if isSuccess then
					CommonPacketSender:sendBedWarPassBuyLicense(self.buyType)
					self:hide()
				end
			end)
		end
	end)
end

function UIBedWarPassBuyLayout:setListLayoutSize(rewardCount)
	local row = math.ceil(rewardCount / colMaxCount)
	local col = rewardCount > colMaxCount and colMaxCount or rewardCount
	self.llPriceListLayout:SetWidth({0, ItemWidth * col + (col - 1) * ItemSpace})
	self.llPriceListLayout:SetHeight({0, ItemWidth * row + (row - 1) * row})
end

function UIBedWarPassBuyLayout:onShow(buyType, price)
	self.buyType = buyType
	self.price = price
	self.btnBuy:SetText(price)
	local rewards = CGamePass:getRewardList()
	local vipItemMap = {}
	local vipItemList = {}
	for i, reward in pairs(rewards) do
		local rewardData = vipItemMap[reward.PayReward]
		if not rewardData then
			rewardData = {}
			rewardData.rewardId = reward.PayReward
			vipItemMap[reward.PayReward] = rewardData
		end
		rewardData.count = (rewardData.count or 0) + reward.PayNum
	end
	for _, v in pairs(vipItemMap) do
		table.insert(vipItemList, v)
	end
	self:setListLayoutSize(#vipItemList)
	self.rewardListAdapt:setData(vipItemList)
end

return UIBedWarPassBuyLayout
