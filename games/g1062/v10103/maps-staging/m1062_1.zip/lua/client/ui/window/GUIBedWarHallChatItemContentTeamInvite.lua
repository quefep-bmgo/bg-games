---@class GUIBedWarHallChatItemContentTeamInviteWindow : IGUIWindow
local GUIBedWarHallChatItemContentTeamInviteWindow = class("GUIBedWarHallChatItemContentTeamInviteWindow", IGUIWindow)
---@type TeamService
local TeamService = T(Global, "TeamService")

---@private
function GUIBedWarHallChatItemContentTeamInviteWindow:ctor(...)
    self.super.ctor(self, "BedWarHallChatItemContentTeamInvite.json", ...)
end

---@private
function GUIBedWarHallChatItemContentTeamInviteWindow:onLoad()
    self.siArrow = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Arrow", GUIType.StaticImage)
    self.stTeamMode = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Team-Mode", GUIType.StaticText)
    self.stTeamDan = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Team-Dan", GUIType.StaticText)
    self.stTeamMsg = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Team-Msg", GUIType.StaticText)
    self.siTeamModeIcon = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Team-Mode-Icon", GUIType.StaticImage)
    self.btnJoinTeamBtn = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Join-Team-Btn", GUIType.Button)
    self.stJoinText = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Join-Text", GUIType.StaticText)
    self.stSegments = self:getChildWindowByName("BedWarHallChatItemContentTeamInvite-Segments", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarHallChatItemContentTeamInviteWindow:initView()
    self.stJoinText:SetText(Lang:getString("gui_chat_item_join_team_text"))
    self.stJoinText:SetWidth({ 0, self.stJoinText:GetTextWidth() })
    self.stSegments:SetText("")
end

---@private
function GUIBedWarHallChatItemContentTeamInviteWindow:initEvent()
    self.btnJoinTeamBtn:registerEvent(GUIEvent.ButtonClick, function()
        if TeamService:sendJoinTeam(self.data.data) then
            GUIBedWarHallChatLayout:hide()
        end
    end)
end

---@param data ChatMsgData
function GUIBedWarHallChatItemContentTeamInviteWindow:onDataChanged(data)
    self.data = data
    if data.sendId == Game:getPlatformUserId() then
        self.siArrow:SetXPosition({ 1, 0 })
        self.siArrow:SetProperty("Rotate", 180)
    end
    local name = Lang:getString(Define.GameModeName[data.data.gameType])
    if data.data.specialModeId then
        local cfg = SpecialMode:getCfgById(data.data.specialModeId)
        if cfg then
            name = Lang:getString(cfg.name)
        end
    end
    local segmentText = ""
    if data.data.gameMode == Define.GameMode.Qualifying then
        name = name .. " - " .. Lang:getString("gui.qualifying.title")
        segmentText = Lang:format("gui.segment.team.invite", Lang:getString("gui.segment.name." .. self.data.data.segment))
    elseif data.data.gameMode == Define.GameMode.Pinnacle then
        name = name .. " - " .. Lang:getString("gui.pinnacle.title")
        segmentText = Lang:format("gui.segment.team.invite", Lang:getString("gui.segment.name." .. self.data.data.segment))
    end
    self.stTeamMode:SetText(name .. "( " .. data.data.memberCount .. " )")
    self.stTeamDan:SetText()
    self.stTeamMsg:SetText(data.data.msg or "")
    self.siTeamModeIcon:SetImage("")
    self.stSegments:SetText(segmentText)
    self.root:SetWidth({ 1, -120 })
    return 116
end

return GUIBedWarHallChatItemContentTeamInviteWindow
