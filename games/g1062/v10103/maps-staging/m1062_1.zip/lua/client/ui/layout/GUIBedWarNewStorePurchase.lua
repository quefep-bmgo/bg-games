---@class UIBedWarNewStorePurchase : IGUILayout
local UIBedWarNewStorePurchase = class("UIBedWarNewStorePurchase", IGUILayout)

---@private
function UIBedWarNewStorePurchase:isDelayLoad()
    return true
end

---@private
function UIBedWarNewStorePurchase:onCreate()
    self:initCreateEvent()
end

---@private
function UIBedWarNewStorePurchase:initCreateEvent()

end

---@private
function UIBedWarNewStorePurchase:onLoad()
    self.btnMask = self:getChildWindow("BedWarNewStorePurchase-Mask", GUIType.Button)
    self.siBg = self:getChildWindow("BedWarNewStorePurchase-Bg", GUIType.StaticImage)
    self.stTitle = self:getChildWindow("BedWarNewStorePurchase-Title", GUIType.StaticText)
    self.stTip = self:getChildWindow("BedWarNewStorePurchase-Tip", GUIType.StaticText)
    self.stCountText = self:getChildWindow("BedWarNewStorePurchase-Count-Text", GUIType.StaticText)
    self.btnClose = self:getChildWindow("BedWarNewStorePurchase-Close", GUIType.Button)
    self.siContent = self:getChildWindow("BedWarNewStorePurchase-Content", GUIType.StaticImage)
    self.siCount = self:getChildWindow("BedWarNewStorePurchase-Count", GUIType.StaticImage)
    self.etInput = self:getChildWindow("BedWarNewStorePurchase-Input", GUIType.Edit)
    self.btnAddOne = self:getChildWindow("BedWarNewStorePurchase-Add-One", GUIType.Button)
    self.btnMinusOne = self:getChildWindow("BedWarNewStorePurchase-Minus-One", GUIType.Button)
    self.btnAddMulti = self:getChildWindow("BedWarNewStorePurchase-Add-Multi", GUIType.Button)
    self.stAddMultiText = self:getChildWindow("BedWarNewStorePurchase-Add-Multi-Text", GUIType.StaticText)
    self.siGoodsDisplay = self:getChildWindow("BedWarNewStorePurchase-Goods-Display", GUIType.StaticImage)
    self.btnBuy = self:getChildWindow("BedWarNewStorePurchase-Buy", GUIType.Button)
    self.siBuyIcon = self:getChildWindow("BedWarNewStorePurchase-Buy-Icon", GUIType.StaticImage)
    self.stBuyText = self:getChildWindow("BedWarNewStorePurchase-Buy-Text", GUIType.StaticText)
    self.siCheck = self:getChildWindow("BedWarNewStorePurchase-check", GUIType.StaticImage)
    self.etInput:SetTouchable(false)

    self.stTitle:SetText(Lang:getString("gui.store.purchase.title"))
    self.stTip:SetText(Lang:getString("gui.store.purchase.tip"))
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarNewStorePurchase:initView()

end

---@private
function UIBedWarNewStorePurchase:initEvent()
    self.btnMask:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        if self.goodsInfo.config.Type == 4 then
            if Plugins.IsLoaded("limit_gift") then
                ---@type CLimitGiftManager
                local CLimitGiftManager = T(Global, "CLimitGiftManager")
                CLimitGiftManager:onGiftTrigger(Define.LimitGiftTriggerType.BuyKeyFail)
            end
        end
        self:hide()
    end)
    self.btnAddOne:registerEvent(GUIEvent.ButtonClick, function()
        self.count = self.count + 1
        if self.goodsInfo.LimitCount ~= -1 then
            self.count = math.min(self.count, self.goodsInfo.LimitCount)
        end
        self:refreshPrice()
    end)
    self.btnMinusOne:registerEvent(GUIEvent.ButtonClick, function()
        self.count = self.count - 1
        self.count = math.max(self.count, 1)
        self:refreshPrice()
    end)
    self.btnAddMulti:registerEvent(GUIEvent.ButtonClick, function()
        self.count = self.count + 10
        if self.goodsInfo.LimitCount ~= -1 then
            self.count = math.min(self.count, self.goodsInfo.LimitCount)
        end
        self:refreshPrice()
    end)
    self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
        ClientStore:onBuyGoods(self.goodsInfo.goodsId, self.count, function(success, tips)
            if success then
                self:hide()
            else
                if self.goodsInfo.config.Type == 4 then
                    if Plugins.IsLoaded("limit_gift") then
                        ---@type CLimitGiftManager
                        local CLimitGiftManager = T(Global, "CLimitGiftManager")
                        CLimitGiftManager:onGiftTrigger(Define.LimitGiftTriggerType.BuyKeyFail)
                    end
                end
                CustomDialog.builder()
                            .setTitleText(Lang:getString("bed_war_new_store_purchase_title"))
                            .setContentText(tips)
                            .show()
            end
        end)
    end)
end

---@param goodsInfo GoodsInfo
function UIBedWarNewStorePurchase:show(goodsInfo)
    self.goodsInfo = goodsInfo
    self.count = 1
    self.super.show(self)

end

function UIBedWarNewStorePurchase:hide()
    self.super.hide(self)
end

function UIBedWarNewStorePurchase:onShow()

    if self.siGoodsDisplay then
        self.siGoodsDisplay:SetImage(self.goodsInfo.config.showDetail.image)
    end

    --- 能否更改数量
    self.siCount:SetVisible(self.goodsInfo.config.CanChangeCount)
    self.stCountText:SetVisible(not self.goodsInfo.config.CanChangeCount)

    --- 花费
    self.etInput:SetText(tostring(self.count * self.goodsInfo.config.Count))
    local config = StoreConfig:getCurrencyConfig(self.goodsInfo.config.CurrencyId)
    if config then
        if config.ItemId > 0 then
            GuiItemStack.showItemIcon(self.siBuyIcon, config.ItemId, 0, "")
        elseif config.RealId > 0 then
            self.siBuyIcon:SetImage(PayHelper.getMoneyIcon(config.RealId))
        else
            self.siBuyIcon:SetImage("")
        end
    else
        self.siBuyIcon:SetImage("")
    end
    self.stBuyText:SetText(self.goodsInfo.config.DiscountPrice * self.count)
    self.stBuyText:SetWidth({ 0, self.stBuyText:GetTextWidth() })
    if self.goodsInfo.config.CountText ~= "#" then
        self.stCountText:SetText(Lang:getString(self.goodsInfo.config.CountText))
    else
        self.stCountText:SetText(Lang:getString("bed_war_new_store_count") .. self.goodsInfo.config.Count)
    end
end

function UIBedWarNewStorePurchase:refreshPrice()
    self.etInput:SetText(math.floor(self.count * self.goodsInfo.config.Count))
    self.stBuyText:SetText(math.floor(self.goodsInfo.config.DiscountPrice * self.count))
    self.stBuyText:SetWidth({ 0, self.stBuyText:GetTextWidth() })
end

return UIBedWarNewStorePurchase
