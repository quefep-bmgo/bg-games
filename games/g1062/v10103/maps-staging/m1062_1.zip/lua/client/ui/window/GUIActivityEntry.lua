---@class GUIActivityEntryWindow : IGUIWindow
local GUIActivityEntryWindow = class("GUIActivityEntryWindow", IGUIWindow)

---@private
function GUIActivityEntryWindow:ctor(...)
	self.super.ctor(self, "ActivityEntry.json", ...)
end

---@private
function GUIActivityEntryWindow:onLoad()
	self.siBg = self:getChildWindowByName("ActivityEntry-Bg", GUIType.StaticImage)
	self.btnEntry = self:getChildWindowByName("ActivityEntry-Entry", GUIType.Button)
	self.stEntryTxt = self:getChildWindowByName("ActivityEntry-EntryTxt", GUIType.StaticText)
	self.llTip = self:getChildWindowByName("ActivityEntry-Tip", GUIType.Layout)
	self.stTipText = self:getChildWindowByName("ActivityEntry-Tip-Text", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIActivityEntryWindow:initView()
	self.stEntryTxt:SetText(Lang:getString("activity.goButton"))
	self.stTipText:SetText(Lang:getString("gui_activity_entry_tip_text"))
end

---@private
function GUIActivityEntryWindow:initEvent()
	self.btnEntry:registerEvent(GUIEvent.ButtonClick, function()
		local activityList = PluginMainActivity:getAllActivity()
		for _, activityMgr in pairs(activityList) do
			if activityMgr.mainConfig.showInLayout == 1 and activityMgr.mainConfig.type == 19 then
				GUINewStore:hide()
				GUIGameActivityLayout:show(activityMgr.mainConfig.id)
				break
			end
		end
	end)
end

---@param data table
function GUIActivityEntryWindow:onDataChanged(data)

end

return GUIActivityEntryWindow
