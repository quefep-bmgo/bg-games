---@class GUIBedWarCustomShopSuitGoodsWindow : IGUIWindow
local GUIBedWarCustomShopSuitGoodsWindow = class("GUIBedWarCustomShopSuitGoodsWindow", IGUIWindow)

local Bg = {
	"set:bed_war_3_dress_store.json image:img_0_suit_leather",
	"set:bed_war_3_dress_store.json image:img_0_suit_iron",
	"set:bed_war_3_dress_store.json image:img_0_suit_gold",
	"set:bed_war_3_dress_store.json image:img_0_suit_diamond",
}

---@private
function GUIBedWarCustomShopSuitGoodsWindow:ctor(...)
	self.super.ctor(self, "BedWarCustomShopSuitGoods.json", ...)
end

---@private
function GUIBedWarCustomShopSuitGoodsWindow:onLoad()
	self.siCounter = self:getChildWindowByName("BedWarCustomShopSuitGoods-Counter", GUIType.StaticImage)
	self.llContent = self:getChildWindowByName("BedWarCustomShopSuitGoods-Content", GUIType.Layout)
	self.stName = self:getChildWindowByName("BedWarCustomShopSuitGoods-Name", GUIType.StaticText)
	self.llGoods = self:getChildWindowByName("BedWarCustomShopSuitGoods-Goods", GUIType.Layout)
	self.siPriceWin = self:getChildWindowByName("BedWarCustomShopSuitGoods-Price", GUIType.StaticImage)
	self.siMoneyIcon = self:getChildWindowByName("BedWarCustomShopSuitGoods-Money-Icon", GUIType.StaticImage)
	self.stPriceTitle = self:getChildWindowByName("BedWarCustomShopSuitGoods-Price-Title", GUIType.StaticText)
	self.stPriceText = self:getChildWindowByName("BedWarCustomShopSuitGoods-Price-Text", GUIType.StaticText)

	self.items = {
		{
			layout = self:getChildWindowByName("BedWarCustomShopSuitGoods-All", GUIType.Layout)
		},
		{
			layout = self:getChildWindowByName("BedWarCustomShopSuitGoods-Part-1", GUIType.Layout)
		},
		{
			layout = self:getChildWindowByName("BedWarCustomShopSuitGoods-Part-2", GUIType.Layout)
		},
		{
			layout = self:getChildWindowByName("BedWarCustomShopSuitGoods-Part-3", GUIType.Layout)
		},
		{
			layout = self:getChildWindowByName("BedWarCustomShopSuitGoods-Part-4", GUIType.Layout)
		}
	}

	self.siLabel = self:getChildWindowByName("BedWarCustomShopSuitGoods-Label", GUIType.StaticImage)
	self.stLabelText = self:getChildWindowByName("BedWarCustomShopSuitGoods-Label_Text", GUIType.StaticText)
	self.stLabelText:SetText(Lang:getString("bed_war_limit_tip"))

	self.llGoods:SetClipChild(true)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarCustomShopSuitGoodsWindow:initView()
	self.stPriceTitle:SetText(Lang:getString("gui_custom_shop_suit_price_title"))
	for i, v in pairs(self.items) do
		v.layout:SetClipChild(true)
		v.item = UIHelper.newGameGUIWindow("GUIBedWarCustomShopSuitItem")
		v.layout:AddChildWindow(v.item.root)
		v.item:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	end
end

---@private
function GUIBedWarCustomShopSuitGoodsWindow:initEvent()

end

---@param data table
function GUIBedWarCustomShopSuitGoodsWindow:onDataChanged(data)
	self.mainGood = data.Items[1]
	self.stName:SetText(Lang:getString(self.mainGood.Name))
	local config = CustomShopSuit.Settings[tostring(self.mainGood.SettingId)]
	local mainGoodUnlock = true
	local price = 0
	for index, good in pairs(data.Items) do
		if not good.IsMain then
			if good.Time == 0 then
				price = price + good.Price1
				mainGoodUnlock = false
			end
			self.items[index].item:onDataChanged(good, config.Type)
		end
	end
	self.mainGood.Price1 = price
	self.items[1].item:onDataChanged(self.mainGood, config.Type)
	if mainGoodUnlock then
		self.items[1].item:setUnlock()
	end
	self.llContent:SetBackImage(Bg[config.Type])
	self.siPriceWin:SetVisible(self.mainGood.ShowPrice and self.mainGood.Price1 > 0)
	self.stPriceText:SetText(self.mainGood.Price1)
	self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(self.mainGood.CoinId1))
	self.siLabel:SetVisible(not self.mainGood.ShowPrice)
end

return GUIBedWarCustomShopSuitGoodsWindow
