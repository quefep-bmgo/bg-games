---@class UITalentLayout : IGUILayout
local UITalentLayout = class("UITalentLayout", IGUILayout)
---@type TalentLayoutConfig
local TalentLayoutConfig = T(Global, "TalentLayoutConfig")
---@type CTalentController
local CTalentController = T(Global, "CTalentController")
---@private
function UITalentLayout:isDelayLoad()
	if GameType == "g1046" then
		return false
	else
		return true
	end
end

---@private
function UITalentLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UITalentLayout:initCreateEvent()
	self:registerEvent(Events.StartGameEvent, function()
		self:hide()
	end)
end

---@private
function UITalentLayout:initEvent()
	self.btnResetBtn:registerEvent(GUIEvent.ButtonClick, function()
		if not CTalentController:isCanResetTalent() then
			--提示玩家没有填天赋可以重置
			return
		end
		CustomDialog.builder()
					.setTitleText("gui.community.title.text")
					.setContentView(GUITalentResetLayout)
					.setRightClickListener(function()
			if CTalentController:isFirstResetTalent() then
				PlayerManager:getClientPlayer():sendPacket({
					pid = "C2SResetTalent"
				})
			else
				PayHelper.checkMoney(Define.Money.DIAMOND, Define.TalentResetPrice, function(canBuy)
					if canBuy then
						PlayerManager:getClientPlayer():sendPacket({
							pid = "C2SResetTalent"
						})
					else
						LuaTimer:scheduleTicker(function()
							PayHelper.checkMoney(Define.Money.DIAMOND, Define.TalentResetPrice, function() end)
						end,1,1)
					end
				end)
			end
		end)        .show()
	end)

	self:registerEvent(Events.TalentUpgradeSuccess, function(talentData, isUnlock)
		if isUnlock then
			SoundUtil.playSound(421)
		else
			SoundUtil.playSound(422)
		end
		self:refreshTotalLevel()
	end)

	self:registerEvent(Events.TalentResetSuccess, function()
		self:refreshTotalLevel()
	end)

	self:registerEvent(Events.TalentShowMask, function(isShow)
		self.llMask:SetVisible(isShow)
	end)
end

---@private
function UITalentLayout:initView()
	self.tvResetBtnText:SetText(Lang:getString("gui.talent.reset"))
	self:refreshTotalLevel()
	self.lhListHor:SetClipChild(false)
end

function UITalentLayout:refreshTotalLevel()
	self.tvTotalLevelText:SetText(Lang:format("gui.talent.level.tips", "▢FFFFFFFF   "..CTalentController:getCurTalentTotalLevel()))
	if self.talentContent then
		self.talentContent:refreshLine()
	end
end

---@private
function UITalentLayout:onLoad()
	self.lhListHor = self:getChildWindow("Talent-ListHor", GUIType.ListHorizontal)
	self.llMoney = self:getChildWindow("Talent-Money", GUIType.Layout)
	self.llMask = self:getChildWindow("Talent-Mask", GUIType.Layout)
	self.btnResetBtn = self:getChildWindow("Talent-ResetBtn", GUIType.Button)
	self.tvResetBtnText = self:getChildWindow("Talent-ResetBtnText", GUIType.StaticText)
	self.tvTotalLevelText = self:getChildWindow("Talent-TotalLevelText", GUIType.StaticText)

	if GameType ~= "g1046" then
		self.btnResetBtn:SetVisible(false)
	end

	self.moneyItems = {}
	---@type GUIListHorizontalLayout
	self.lvMoney = UIHelper.newGameGUIWindow("GUIListHorizontalLayout")
	self.lvMoney:setItemSpace(10)
	self.lvMoney:setHorizontalDir(self.lvMoney.HorizontalDir.Right)
	self.llMoney:AddChildWindow(self.lvMoney.root)

	for _, money in pairs({Define.Money.DIAMOND, Define.Money.TALENT_ESSENCE}) do
		---@type GUICurrency
		local item = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
		item:onDataChanged({ ItemId = 0, RealId = money })
		table.insert(self.moneyItems, item)
		self.lvMoney:addItem(item)
	end

	local talentContent = UIHelper.newGameGUIWindow("GUITalentContent")
	talentContent.root:SetWidth({0, TalentLayoutConfig:getTotalWidth()})
	self.lhListHor:SetWidth({0, TalentLayoutConfig:getTotalWidth()})
	self.lhListHor:AddItem(talentContent.root)
	self.talentContent = talentContent

	---@type GUIBedWarUIReturnControlWindow
	self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.talent.desc00", function()
		self:hide()
	end)
	self.root:AddChildWindow(self.llReturn.root)

	self:initView()
	self:initEvent()
end

function UITalentLayout:onShow()
	ClientReportEvent.open_talent()
	Events.TalentItemRefresh:invoke()
	self:refreshTotalLevel()
end

function UITalentLayout:onTick()
	for _, item in pairs(self.moneyItems) do
		item:onTick()
	end
end

function UITalentLayout:showGrid()
	local TalentPosEdit = T(Global, "TalentPosEdit")
	TalentPosEdit:showGrid(self.talentContent, self.lhListHor, self.root)
end

return UITalentLayout
