---@class UIHallCreateTeamLayout : IGUILayout
local UIHallCreateTeamLayout = class("UIHallCreateTeamLayout", IGUILayout)
---@type TeamService
local TeamService = T(Global, "TeamService")
---@type FastChatConfig
local FastChatConfig = T(Global, "FastChatConfig")
---@type ChatClient
local ChatClient = T(Global, "ChatClient")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type table
local InviteStatusRecord = T(Global, "InviteStatusRecord")

---@private
function UIHallCreateTeamLayout:ctor(parent)
    self.super.ctor(self, "HallCreateTeam.json", parent)
end

---@private
function UIHallCreateTeamLayout:isDelayLoad()
    return true
end

---@private
function UIHallCreateTeamLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIHallCreateTeamLayout:initCreateEvent()
    self:registerEvent(Events.JoinTeamEvent, function()
        if TeamService:isSingleMatch() then
            return
        end
        self:show()
        self:clearTeamChatList()
    end)
end

---@private
function UIHallCreateTeamLayout:onLoad()
    self.llLight = self:getChildWindow("HallCreateTeam-Light", GUIType.Layout)
    self.stInviteCount = self:getChildWindow("HallCreateTeam-Invite-Count", GUIType.StaticText)
    self.llInviteList = self:getChildWindow("HallCreateTeam-Invite-List", GUIType.Layout)
    self.btnInviteRefresh = self:getChildWindow("HallCreateTeam-Invite-Refresh", GUIType.Button)
    self.btnTeamApply = self:getChildWindow("HallCreateTeam-Team-Apply", GUIType.Button)
    self.btnTeamInvite = self:getChildWindow("HallCreateTeam-Team-Invite", GUIType.Button)
    self.btnFriendApply = self:getChildWindow("HallCreateTeam-Friend-Apply", GUIType.Button)
    self.llTeamPlayers = self:getChildWindow("HallCreateTeam-Team-Players", GUIType.Layout)
    self.llTeamChat = self:getChildWindow("HallCreateTeam-Team-Chat", GUIType.Layout)
    self.llWheelChat = self:getChildWindow("HallCreateTeam-Wheel-Chat", GUIType.Layout)
    self.btnFastChat = self:getChildWindow("HallCreateTeam-Fast-Chat", GUIType.Button)
    self.llFastChatList = self:getChildWindow("HallCreateTeam-Fast-Chat-List", GUIType.Layout)
    self.btnCallTeammate = self:getChildWindow("HallCreateTeam-Call-Teammate", GUIType.Button)
    self.btnStartGame = self:getChildWindow("HallCreateTeam-Start-Game", GUIType.Button)
    self.siTeammateInvite = self:getChildWindow("HallCreateTeam-Teammate-Invite", GUIType.StaticImage)
    self.siTeammateInviteYes = self:getChildWindow("HallCreateTeam-Teammate-Invite-Yes", GUIType.StaticImage)
    self.stTeammateInviteText = self:getChildWindow("HallCreateTeam-Teammate-Invite-Text", GUIType.StaticText)

    self:initView()
    self:initEvent()
end

---@private
function UIHallCreateTeamLayout:initView()
    self.btnTeamApply:SetVisible(false)
    self.btnTeamInvite:SetVisible(false)
    self.btnFriendApply:SetVisible(false)

    self.btnStartGame:SetText(Lang:getString("gui.create.team.start"))
    self.stTeammateInviteText:SetText(Lang:getString("gui.create.team.teammate.invite"))
    self.llFastChatList:SetVisible(false)

    local width = math.min(204 * (720 * self.root:GetPixelSize().x) / (1280 * self.root:GetPixelSize().y), 204)
    self.stTeammateInviteText:SetWidth({ 0, width })

    self.lvTeamChatList = IGUIListView.new("HallCreateTeam-Team-Chat-List", self.llTeamChat)
    self.lvTeamChatList:setArea({ 0, 0 }, { 0, 5 }, { 1, 0 }, { 1, -10 })

    local rollMsgWin = UIHelper.newGameGUIWindow("GUIRollMessage").root
    rollMsgWin:SetWidth({ 1, 0 })
    self.llWheelChat:AddChildWindow(rollMsgWin)

    ---@type GUIBedWarUIReturnControlWindow
    self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.create.team.title", function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.leave.team.tip"))
                    .setRightClickListener(function()
            TeamService:sendLeaveTeam()
        end)        .show()
    end)
    self.root:AddChildWindow(self.llReturn.root)

    UIUtils.addRedDot(self.btnTeamApply, Define.RedDotKey.TeamApply, nil, { offset = VectorUtil.newVector2(4, -3), isParentBindVisible = true })
    UIUtils.addRedDot(self.btnFriendApply, Define.RedDotKey.FriendApply, nil, { offset = VectorUtil.newVector2(4, -3), isParentBindVisible = true })
    UIUtils.addRedDot(self.btnTeamInvite, Define.RedDotKey.TeamInvite, nil, { offset = VectorUtil.newVector2(4, -3), isParentBindVisible = true })
end

---@private
function UIHallCreateTeamLayout:initEvent()
    self.btnTeamApply:registerEvent(GUIEvent.ButtonClick, function()
        GUICreateTeamApplyListLayout:showApplyList(Define.ApplyType.TeamApply)
    end)
    self.btnTeamInvite:registerEvent(GUIEvent.ButtonClick, function()
        GUICreateTeamApplyListLayout:showApplyList(Define.ApplyType.TeamInvite)
    end)
    self.btnFriendApply:registerEvent(GUIEvent.ButtonClick, function()
        UIUtils.updateRedDotCount(Define.RedDotKey.FriendApply, 0)
        GUICreateTeamApplyListLayout:showApplyList(Define.ApplyType.FriendApply)
    end)
    self.btnFastChat:registerEvent(GUIEvent.ButtonClick, function()
        self:changeChatListUI(self.llFastChatList:IsVisible())
    end)
    self.btnCallTeammate:registerEvent(GUIEvent.ButtonClick, function()
        local msg = ""
        GUICustomInputContentLayout:setTipText(Lang:getString("gui.call.teammate.tip"))
        GUICustomInputContentLayout:setContentChangeListener(function(content)
            msg = content
        end)
        CustomDialog.builder()
                    .setTitleText("gui.call.teammate.title")
                    .setContentView(GUICustomInputContentLayout)
                    .setRightClickListener(function()
            ChatClient:sendTeamInviteToGroup(msg)
        end)        .show()
    end)
    self.btnStartGame:registerEvent(GUIEvent.ButtonClick, function()
        TeamService:setStartMatch()
        TeamService:sendStartGame()
        self:updateBaseUI()
    end)
    self.siTeammateInvite:registerEvent(GUIEvent.Click, function()
        TeamService:sendTeammateInviteStatus()
    end)
    self.llWheelChat:registerEvent(GUIEvent.Click, function()
        GUIBedWarHallChatLayout:show(Define.ChatTabType.Team)
    end)
    self:registerEvent(Events.LeaveTeamEvent, function()
        self:hide()
        self:clearTeamChatList()
        TableUtil.clearTable(InviteStatusRecord)
    end)
    self:registerEvent(Events.ReceiveChatMsgEvent, function(chatId, data)
        if chatId ~= "team" then
            return
        end
        self:addTeamChatItem(data)
    end)
    self:registerEvent(Events.RejectionTeamInviteEvent, function(userId)
        InviteStatusRecord[userId] = Define.InviteStatus.Rejected
    end)
end

---只有界面打开着才监听的事件
---@private
function UIHallCreateTeamLayout:initOpenEvent()
    self:registerEvent(Events.TeammateInviteStatusEvent, function(enable)
        self.siTeammateInviteYes:SetVisible(enable)
    end)
    self:registerEvent(Events.UserJoinTeamEvent, function(userId)
        self:updateTeamPlayerUI()
        self:addTeamChatItem({
            type = Define.ChatMsgType.TextMsg,
            sendId = userId,
            time = os.time(),
            data = {
                content = Lang:getString("gui.user.join.team")
            },
        })
    end)
    self:registerEvent(Events.UserLeaveTeamEvent, function(userId)
        self:updateTeamPlayerUI()
        self:addTeamChatItem({
            type = Define.ChatMsgType.TextMsg,
            sendId = userId,
            time = os.time(),
            data = {
                content = Lang:getString("gui.user.leave.team")
            },
        })
    end)
    self:registerEvent(Events.TeamOwnerChangeEvent, function()
        self:updateBaseUI()
        self:updateTeamPlayerUI()
    end)
    self:registerEvent(Events.QualifyingMatchStatusUpdateEvent, function(isMatching)
        self:updateBaseUI()
        if isMatching then
            GUICreateTeamApplyListLayout:hide()
        end
    end)
    self:registerEvent(Events.TeamCancelStartGameEvent, function(userId)
        self:addTeamChatItem({
            type = Define.ChatMsgType.TextMsg,
            sendId = userId,
            time = os.time(),
            data = {
                content = Lang:getString("gui.team.cancel.start.game")
            },
        })
        self:updateBaseUI()
    end)
end

---@private
function UIHallCreateTeamLayout:unregisterOpenEvent()
    self:unregisterEvent(Events.TeammateInviteStatusEvent)
    self:unregisterEvent(Events.UserJoinTeamEvent)
    self:unregisterEvent(Events.UserLeaveTeamEvent)
    self:unregisterEvent(Events.TeamOwnerChangeEvent)
    self:unregisterEvent(Events.TeamCancelStartGameEvent)
end

---@private
function UIHallCreateTeamLayout:onHide()
    self:unregisterOpenEvent()
    GUISelectTeamInviteListLayout:hide()
    GUIBedWarQualifyingLayout:hide()
    GUIBedWarSpecialModeLayout:hide()
end

---@private
function UIHallCreateTeamLayout:onShow()
    if TeamService:isSpecialMode() then
        GUIBedWarSpecialModeLayout:show()
        self.root:AddChildWindow(GUIBedWarSpecialModeLayout.root)
    elseif TeamService:isQualifying() then
        GUIBedWarQualifyingLayout:show()
        self.root:AddChildWindow(GUIBedWarQualifyingLayout.root)
    else
        GUISelectTeamInviteListLayout:show(self.root, false)
    end
    self:updateBaseUI()
    self:initOpenEvent()
    self:updateTeamPlayerUI()
    self:initFastChatList()
    self:changeChatListUI(true)
end

---@private
function UIHallCreateTeamLayout:updateBaseUI()
    self.llLight:SetVisible(not TeamService:isQualifying() and not TeamService:isSpecialMode())
    self.siTeammateInviteYes:SetVisible(TeamService.teammateInviteSwitch)
    self.btnTeamApply:SetEnabled(TeamService:isOwner() and not TeamService.isMatching)
    self.btnTeamInvite:SetEnabled(not TeamService.isMatching)
    self.btnStartGame:SetEnabled(TeamService:isOwner() and not TeamService.isMatching)
    self.btnCallTeammate:SetVisible(TeamService:isOwner())
    self.btnCallTeammate:SetEnabled(not TeamService.isMatching)
    self.btnStartGame:SetProperty("TextBorderColor",
            (TeamService:isOwner() and not TeamService.isMatching) and "0.643137 0.270588 0.027451 1" or "0.3333 0.3333 0.3333 1")
    if TeamService:getGameMode() == Define.GameMode.Qualifying then
        self.llReturn:setTitle(Lang:getString("gui.create.team.title") .. "(" .. Lang:getString("gui.qualifying.title") .. ")")
    elseif TeamService:getGameMode() == Define.GameMode.Pinnacle then
        self.llReturn:setTitle(Lang:getString("gui.create.team.title") .. "(" .. Lang:getString("gui.pinnacle.title") .. ")")
    else
        self.llReturn:setTitle("gui.create.team.title")
    end
    self.llReturn:setVisible(not TeamService:isQualifying() and not TeamService:isSpecialMode())
    self.siTeammateInvite:SetVisible(not TeamService:isQualifying() and not TeamService:isSpecialMode())
    if TeamService:isSpecialMode() then
        self.stTeammateInviteText:SetTextColor({ 19 / 255, 22 / 255, 46 / 255, 1 })
        self.root:SetProperty("LayoutBackImage", "set:classic_mode.json image:img_bg")
        self.llTeamChat:SetXPosition({ 0, 120 })
        self.llTeamChat:SetWidth({ 0.335, -120 })
    elseif TeamService:isQualifying() then
        self.stTeammateInviteText:SetTextColor({ 19 / 255, 22 / 255, 46 / 255, 1 })
        self.root:SetProperty("LayoutBackImage", "set:bed_war_2_qualifying_bg.json image:img_0_qualifying01")
        self.llTeamChat:SetXPosition({ 0, 120 })
        self.llTeamChat:SetWidth({ 0.335, -120 })
    else
        self.stTeammateInviteText:SetTextColor({ 121 / 255, 122 / 255, 155 / 255, 1 })
        self.root:SetProperty("LayoutBackImage", "set:bed_war_3_common_part.json image:img_0_friends01")
        self.llTeamChat:SetXPosition({ 0, 44 })
        self.llTeamChat:SetWidth({ 0.335, -44 })
    end
end

---@private
function UIHallCreateTeamLayout:updateTeamPlayerUI()
    if TeamService:isSpecialMode() then
        GUIBedWarSpecialModeLayout:updateTeamPlayerUI()
        if self.lvTeamPlayers then
            self.lvTeamPlayers.root:SetVisible(false)
        end
        return
    end
    if TeamService:isQualifying() then
        GUIBedWarQualifyingLayout:updateTeamPlayerUI()
        if self.lvTeamPlayers then
            self.lvTeamPlayers.root:SetVisible(false)
        end
        return
    end
    if self.lvTeamPlayers == nil then

        self.lvTeamPlayers = IGUIGridView.new("UIBedWarSurveyDesc-Items-List", self.llTeamPlayers)
        --self.lvTeamPlayers = IGUIListView.new("HallCreateTeam-Team-Player-List", self.llTeamPlayers, nil, Orientation.Horizontal)
        self.lvTeamPlayers.root:SetHorizontalAlignment(HorizontalAlignment.Center)
        self.lvTeamPlayers.root:SetVerticalAlignment(VerticalAlignment.Center)
        self.lvTeamPlayers.root:SetClipChild(false)

    end
    self.lvTeamPlayers:clearItems()
    local maxMember =  TeamService:getMaxMember()
    self.lvTeamPlayers.root:SetVisible(true)
    local contentW = self.llTeamPlayers:GetPixelSize().x
    local minWidth = math.min(contentW - 25 * (maxMember - 1), 150 * maxMember)
    local itemScale = nil
    local itemSpace = nil
    local teamPlayerY = nil
    if TeamService:getGameType() == "g1065" then
        itemScale = 0.85
        itemSpace = 5
        teamPlayerY = 0.124722
    else
        itemSpace = math.min((contentW - minWidth) / (maxMember - 1), 100)
        itemScale = 1
        teamPlayerY = 0.184722
    end
    self.llTeamPlayers:SetYPosition({teamPlayerY, 0})
    self.lvTeamPlayers:setConfig(itemSpace, 0, 5)

    if self.lvTeamPlayers:getItemCount() ~= maxMember then
        --self.lvTeamPlayers:setItemSpace(itemSpace)
        self.lvTeamPlayers.root:SetWidth({ 0, math.min(150 * maxMember + itemSpace * (maxMember - 1), contentW) })
    end

    while self.lvTeamPlayers:getItemCount() ~= maxMember do
        if self.lvTeamPlayers:getItemCount() > maxMember then
            self.lvTeamPlayers:removeItem(self.lvTeamPlayers:getItemByIndex(self.lvTeamPlayers:getItemCount()))
        else
            ---@type GUIInTeamPlayerItemWindow
            local window = UIHelper.newGameGUIWindow("GUIInTeamPlayerItem", itemScale)
            self.lvTeamPlayers:addItem(window)
        end
    end
    for i = 1, maxMember do
        ---@type GUIInTeamPlayerItemWindow
        local item = self.lvTeamPlayers:getItemByIndex(i)
        if item then
            local info = TeamService:getTeammateInfo(i)
            item:onDataChanged(info)
        end
    end
end

---@private
function UIHallCreateTeamLayout:initFastChatList()
    if self.lvFastChatList then
        return
    end
    self.lvFastChatList = IGUIListView.new("HallCreateTeam-Fast-Chat-ListView", self.llFastChatList)
    self.lvFastChatList:setArea({ 0, 0 }, { 0, 2 }, { 1, 0 }, { 1, -4 })
    local settings = FastChatConfig:getAllCfg()
    local maxWidth = 0
    for _, setting in pairs(settings) do
        ---@type GUICreateTeamFastChatItemWindow
        local item = UIHelper.newGameGUIWindow("GUICreateTeamFastChatItem", self)
        item:onDataChanged(setting)
        self.lvFastChatList:addItem(item)
        maxWidth = math.max(item.root:GetTextWidth(), maxWidth)
    end
    local width = self.lvFastChatList:getWidth()
    if maxWidth > width then
        self.llFastChatList:SetWidth({ 0, math.min(maxWidth + 20, width * 1.2) })
    end
end

---@private
function UIHallCreateTeamLayout:changeChatListUI(chatListVisible)
    self.llTeamChat:SetVisible(chatListVisible and self.lvTeamChatList:getItemCount() > 0)
    self.llFastChatList:SetVisible(not chatListVisible)
end

---@private
---@param data ChatMsgData
function UIHallCreateTeamLayout:addTeamChatItem(data)
    if data.type == Define.ChatMsgType.None then
        return
    end
    if TeamService:isSpecialMode() then
        GUIBedWarSpecialModeLayout:addTeamChatItem(data)
        return
    end
    if TeamService:isQualifying() then
        GUIBedWarQualifyingLayout:addTeamChatItem(data)
        return
    end
    ---@type GUICreateTeamChatItemWindow
    local item = UIHelper.newGameGUIWindow("GUICreateTeamChatItem", self.llTeamChat:GetPixelSize().x - 20)
    item:onDataChanged(data)
    self.lvTeamChatList:addItem(item)
    while item.root:GetYPosition()[2] + item.root:GetPixelSize().y > self.llTeamChat:GetPixelSize().y do
        self.lvTeamChatList:removeItem(self.lvTeamChatList:getItemByIndex(1))
    end
    self.lvTeamChatList.root:SetScrollOffset(0)
    self:changeChatListUI(not self.llFastChatList:IsVisible())
end

---@private
function UIHallCreateTeamLayout:clearTeamChatList()
    self.lvTeamChatList:clearItems()
end

return UIHallCreateTeamLayout
