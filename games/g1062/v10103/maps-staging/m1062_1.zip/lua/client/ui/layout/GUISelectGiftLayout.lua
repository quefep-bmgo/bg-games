---@class UISelectGiftLayoutLayout : IGUILayout
local UISelectGiftLayoutLayout = class("UISelectGiftLayoutLayout", IGUILayout)
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function UISelectGiftLayoutLayout:ctor(parent)
	self.super.ctor(self, "SelectGiftLayout.json", parent)
end

---@private
function UISelectGiftLayoutLayout:isDelayLoad()
	return true
end

---@private
function UISelectGiftLayoutLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UISelectGiftLayoutLayout:initCreateEvent()

end

---@private
function UISelectGiftLayoutLayout:onLoad()
	self.llBack = self:getChildWindow("SelectGiftLayout-Back", GUIType.Layout)
	self.llBg = self:getChildWindow("SelectGiftLayout-Bg", GUIType.Layout)
	self.stTitle = self:getChildWindow("SelectGiftLayout-Title", GUIType.StaticText)
	self.btnClose = self:getChildWindow("SelectGiftLayout-Close", GUIType.Button)
	self.llListBg = self:getChildWindow("SelectGiftLayout-List-Bg", GUIType.Layout)
	self.btnConfirm = self:getChildWindow("SelectGiftLayout-Confirm", GUIType.Button)
	self.llShow = self:getChildWindow("SelectGiftLayout-Show", GUIType.Layout)
	self.awActor = self:getChildWindow("SelectGiftLayout-Actor", GUIType.ActorWindow)
	self.siImageBg = self:getChildWindow("SelectGiftLayout-Image-Bg", GUIType.StaticImage)
	self.siImage = self:getChildWindow("SelectGiftLayout-Image", GUIType.StaticImage)
	self.stName = self:getChildWindow("SelectGiftLayout-Name", GUIType.StaticText)
	self.stDesc = self:getChildWindow("SelectGiftLayout-Desc", GUIType.StaticText)
	self.llActorSlide = self:getChildWindow("SelectGiftLayout-Actor-Slide", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function UISelectGiftLayoutLayout:initView()
	self.stTitle:SetText(Lang:getString("gui.select.gift.title"))
	self.btnConfirm:SetText(Lang:getString("gui.sure"))

	self.gvRewards = IGUIGridView.new("SelectGiftLayout-Reward-List", self.llListBg)
	self.gvRewards.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.gvRewards.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.gvRewards:setArea({ 0, 0 }, { 0, 0 }, { 1, -30 }, { 1, -30 })
	self.gvRewards:setConfig(12, 12, 5)
	---@type SelectGiftRewardAdapter
	self.rewardItemAdapter = UIHelper.newGameAdapter("SelectGiftRewardAdapter")
	self.rewardItemAdapter:setItemSize(93, 93)
	self.gvRewards:setAdapter(self.rewardItemAdapter)
end

---@private
function UISelectGiftLayoutLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)

	self.btnConfirm:registerEvent(GUIEvent.ButtonClick, function()
		if self.confirmFunc and self.selectId then
			self.confirmFunc(self.selectId)
		end
	end)

	self.llBack:registerEvent(GUIEvent.Click, function()
		self:hide()
	end)

	self:registerEvent(Events.SelectGiftSelectItem, function(id)
		self:setRewardShow(id)
	end)
end

function UISelectGiftLayoutLayout:onShow(id, confirmFunc)
	local config = RewardConfig:getSelectGiftById(id)
	if not config then
		self:hide()
		return
	end
	self.id = id
	self.confirmFunc = confirmFunc
	self:setRewards()
end

function UISelectGiftLayoutLayout:onHide()
	RewardItemShowDetailConfig:onWindowHide(self.awActor)
end

function UISelectGiftLayoutLayout:setRewards()
	local config = RewardConfig:getSelectGiftById(self.id)
	self.rewardItemAdapter:setData(config.rewardIds)
	Events.SelectGiftSelectItem:invoke(config.rewardIds[1])
end

function UISelectGiftLayoutLayout:setRewardShow(id)
	local reward = RewardConfig:getRewardById(id)
	if not reward then
		return
	end
	self.selectId = id
	local detail = reward.ShowDetail
	if detail then
		self.siImage:SetVisible(detail.showType == Define.ShowDetailType.Icon)
		self.awActor:SetVisible(detail.showType == Define.ShowDetailType.Actor)
		self.stName:SetText(Lang:getString(detail.name))
		self.stDesc:SetText(Lang:getString(detail.desc))
		if detail.showType == Define.ShowDetailType.Icon then
			self.siImage:SetImage(detail.image)
		elseif detail.showType == Define.ShowDetailType.Actor then
			RewardItemShowDetailConfig:showActorSkill(self.awActor, detail, self.llActorSlide)
		end
	end
	self.btnConfirm:SetEnabled(not ClientStore:checkHave({ type = "RewardSetting", realId = id }))
end

return UISelectGiftLayoutLayout
