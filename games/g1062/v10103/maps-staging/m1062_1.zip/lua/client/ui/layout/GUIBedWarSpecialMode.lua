---@class UIBedWarSpecialModeLayout : IGUILayout
local UIBedWarSpecialModeLayout = class("UIBedWarSpecialModeLayout", IGUILayout)

---@type TeamService
local TeamService = T(Global, "TeamService")

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

local themeIconSize = 64
local themeIconInterval = 10

local tabType = {
	daily = 1,
	week = 2,
}

local btnTextColor = {
	pushed = { 39 / 255, 45 / 255, 92 / 255, 1 },
	normal = { 175 / 255, 199 / 255, 234 / 255, 1 }
}

local redDotKey = {
	[tabType.daily] = Define.RedDotKey.SpecialModeDailyTask,
	[tabType.week] = Define.RedDotKey.SpecialModeWeekTask
}

local function getCountDownInfo(closeOsTime)
	local txt = ""
	if closeOsTime <= 0 then
		return txt
	end
	local countDown = closeOsTime - os.time()
	if countDown > 86400 then
		local day = math.floor(countDown / 86400)
		local hour = math.floor((countDown % 86400) / 3600)
		txt = day .. "d" .. hour .. "h"
	else
		txt = DateUtil.getFormatTime(countDown)
	end
	return txt
end

---@private
function UIBedWarSpecialModeLayout:ctor(parent)
	self.super.ctor(self, "BedWarSpecialMode.json", parent)
end

---@private
function UIBedWarSpecialModeLayout:isDelayLoad()
	return true
end

---@private
function UIBedWarSpecialModeLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIBedWarSpecialModeLayout:initCreateEvent()

end

---@private
function UIBedWarSpecialModeLayout:onLoad()
	self.llRight = self:getChildWindow("BedWarSpecialMode-Right", GUIType.Layout)
	self.btnQuestion = self:getChildWindow("BedWarSpecialMode-Question", GUIType.Button)
	self.stLastTimeHint = self:getChildWindow("BedWarSpecialMode-LastTime-Hint", GUIType.StaticText)
	self.stLastTime = self:getChildWindow("BedWarSpecialMode-LastTime", GUIType.StaticText)
	self.siLastTimeIcon = self:getChildWindow("BedWarSpecialMode-LastTime-Icon", GUIType.StaticImage)
	--self.btnOpenFriends = self:getChildWindow("BedWarSpecialMode-OpenFriends", GUIType.Button)
	--self.siOpenFriendsIcon = self:getChildWindow("BedWarSpecialMode-OpenFriendsIcon", GUIType.StaticImage)
	self.btnShop = self:getChildWindow("BedWarSpecialMode-Shop", GUIType.Button)

	self.llModeDetails = self:getChildWindow("BedWarSpecialMode-Mode_Details", GUIType.Layout)
	self.stThemeText = self:getChildWindow("BedWarSpecialMode-Theme_Text", GUIType.StaticText)
	self.stThemeText:SetText(Lang:getString("gui.special.mode.theme"))
	self.llThemeList = self:getChildWindow("BedWarSpecialMode-Theme_List", GUIType.Layout)

	self.btnDailyTask = self:getChildWindow("BedWarSpecialMode-Daily_Task", GUIType.Button)
	self.btnWeekTask = self:getChildWindow("BedWarSpecialMode-Week_Task", GUIType.Button)
	self.btnDailyTask:SetText(Lang:getString("bed.war.daily.task"))
	self.btnWeekTask:SetText(Lang:getString("bed.war.week.task"))
	UIUtils.addRedDot(self.btnDailyTask, Define.RedDotKey.SpecialModeDailyTask)
	UIUtils.addRedDot(self.btnWeekTask, Define.RedDotKey.SpecialModeWeekTask)

	self.stTaskRefreshText = self:getChildWindow("BedWarSpecialMode-Task_Refresh_Text", GUIType.StaticText)
	self.stTaskRefreshText:SetText(Lang:getString("gui.daily.task"))
	self.stTaskRefreshCountDown = self:getChildWindow("BedWarSpecialMode-Task_Refresh_Count_Down", GUIType.StaticText)

	self.btnReceiveAll = self:getChildWindow("BedWarSpecialMode-Receive_All", GUIType.Button)
	self.btnReceiveAll:SetText(Lang:getString("gui.one.key.receive"))

	self.llTaskList = self:getChildWindow("BedWarSpecialMode-Task_List", GUIType.Layout)
	self.llMoney = self:getChildWindow("BedWarSpecialMode-Money", GUIType.Layout)

	self:initView()
	self:initEvent()
end

---@private
function UIBedWarSpecialModeLayout:initView()
	---@type GUIBedWarUIReturnControlWindow
	self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.qualifying.title.pos", function()
		CustomDialog.builder()
					.setContentText(Lang:getString("gui.exit.classic.match"))
					.setRightClickListener(function()
			TeamService:sendLeaveTeam()
		end)        .show()
	end)
	self.root:AddChildWindow(self.llReturn.root)

	---@type GUIQualifyingInTeamPlayerItemWindow[]
	self.llPlayers = {}
	local positions = { { 250, 30 }, { 441, -49 }, { 60, -50 }, { 632, -72 } }
	for index = 4, 1, -1 do
		---@type GUIQualifyingInTeamPlayerItemWindow
		local window = UIHelper.newGameGUIWindow("GUIQualifyingInTeamPlayerItem", self)
		window.root:SetXPosition({ 0, positions[index][1] })
		window.root:SetYPosition({ 0, positions[index][2] })
		window.root:SetVerticalAlignment(VerticalAlignment.Center)
		self.root:AddChildWindow(window.root)
		self.llPlayers[index] = window
	end

	self.gvThemeList = IGUIListView.new("BedWarSpecialMode-Theme_List-Gird", self.llThemeList, nil, Orientation.Horizontal)
	self.gvThemeList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.gvThemeList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.gvThemeList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.specialModeThemeCellAdapter = UIHelper.newGameAdapter("BedWarSpecialModeThemeCellAdapter")
	self.specialModeThemeCellAdapter:setItemSize(themeIconSize, themeIconSize)
	self.gvThemeList:setItemSpace(themeIconInterval)
	self.gvThemeList:setAdapter(self.specialModeThemeCellAdapter)

	self.gvTaskList = IGUIGridView.new("BedWarSpecialMode-Task_List-Gird", self.llTaskList)
	self.gvTaskList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.gvTaskList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.gvTaskList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.specialModeTaskCellAdapter = UIHelper.newGameAdapter("BedWarSpecialModeTaskCellAdapter")
	self.gvTaskList:setConfig(0, 10, 1)
	self.gvTaskList:setAdapter(self.specialModeTaskCellAdapter)

	self.stLastTimeHint:SetText(Lang:getString("gui.qualifying.last.time"))
	self.stTaskRefreshText:SetText(Lang:getString("gui.special.mode.task.refresh"))
	self.closeOsTime = 0
	self.curTaskTab = tabType.daily

	---@type GUIListHorizontalLayout
	self.lvMoney = UIHelper.newGameGUIWindow("GUIListHorizontalLayout")
	self.lvMoney:setItemSpace(10)
	self.lvMoney:setHorizontalDir(self.lvMoney.HorizontalDir.Right)
	self.llMoney:AddChildWindow(self.lvMoney.root)

	self.moneyItems = {}
	for _, money in pairs({Define.Money.BED_WAR_COIN}) do
		---@type GUICurrency
		local item = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
		item:onDataChanged({ ItemId = 0, RealId = money })
		table.insert(self.moneyItems, item)
		self.lvMoney:addItem(item)
	end
end

---@private
function UIBedWarSpecialModeLayout:initEvent()
	self.btnQuestion:registerEvent(GUIEvent.ButtonClick, function()
		CustomDialog.builder()
					.setTitleText("gui.special.mode.rule.title")
					.setContentText(Lang:getString("gui.special.mode.rule.content"))
					.setHideLeftButton()
					.setHideRightButton()
					.setContentAlign(HorizontalAlignment.Left)
					.show()
	end)

	--self.btnOpenFriends:registerEvent(GUIEvent.ButtonClick, function()
	--	GUISelectTeamInviteListLayout:show(self.root, true)
	--end)

	self.btnShop:registerEvent(GUIEvent.ButtonClick, function()
		GUISpecialModeShop:show()
	end)

	self.llModeDetails:registerEvent(GUIEvent.Click, function()
		SpecialModeTopic:updateView()
		CustomDialog.builder()
					.setTitleText("gui.topics.in.this.issue")
					.setContentView(SpecialModeTopic)
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)

	self.btnDailyTask:registerEvent(GUIEvent.ButtonClick, function()
		self:updateTaskInfoByTabId(tabType.daily)
	end)

	self.btnWeekTask:registerEvent(GUIEvent.ButtonClick, function()
		self:updateTaskInfoByTabId(tabType.week)
	end)

	self.btnReceiveAll:registerEvent(GUIEvent.ButtonClick, function()
		if self.canReceiveTask and next(self.canReceiveTask) then
			PlayerManager:getClientPlayer():sendPacket({
				pid = "C2SReceiveSpecialModeTask",
				activityId = TeamService:getSpecialModeId(),
				taskIds = self.canReceiveTask,
			})
		end
	end)

	self:registerEvent(Events.SpecialModeTaskUpdateEvent, function(taskId)
		self:updateBtnReceiveAll()
	end)

end

---只有界面打开着才监听的事件
---@private
function UIBedWarSpecialModeLayout:initOpenEvent()
	self:registerEvent(Events.UserJoinTeamEvent, function(userId)
		self:updateTeamPlayerUI()
	end)
	self:registerEvent(Events.UserLeaveTeamEvent, function(userId)
		self:updateTeamPlayerUI()
	end)
	self:registerEvent(Events.TeamOwnerChangeEvent, function()
		self:updateTeamPlayerUI()
	end)
end

---@private
function UIBedWarSpecialModeLayout:unregisterOpenEvent()
	self:unregisterEvent(Events.UserJoinTeamEvent)
	self:unregisterEvent(Events.UserLeaveTeamEvent)
	self:unregisterEvent(Events.TeamOwnerChangeEvent)
end

---@private
function UIBedWarSpecialModeLayout:onTick()
	if self.closeOsTime then
		self.stLastTimeHint:SetVisible(true)
		self.stLastTime:SetVisible(true)
		self.stLastTime:SetText(getCountDownInfo(self.closeOsTime))
		self.stLastTime:SetWidth({ 0, self.stLastTime:GetTextWidth() })
	end

	if self.curTaskTab then
		local endTime = DateUtil.getGreenwichDayLastTime()
		if self.curTaskTab == tabType.week then
			endTime = os.time() + DateUtil.getWeekSeconds() - ((os.time() - DateUtil.getDaySeconds() * 3) % DateUtil.getWeekSeconds())
		end
		self.stTaskRefreshCountDown:SetText(getCountDownInfo(endTime))
	end

	for _, item in pairs(self.moneyItems) do
		item:onTick()
	end
end

function UIBedWarSpecialModeLayout:updateTeamPlayerUI()
	if not self:isLoad() then
		return
	end
	for index = 1, 4 do
		local info = TeamService:getTeammateInfo(index)
		self.llPlayers[index]:onDataChanged(info, index)
	end
end

---@param chatMsg ChatMsgData
function UIBedWarSpecialModeLayout:addTeamChatItem(chatMsg)
	for _, window in pairs(self.llPlayers) do
		window:tryShowChatText(chatMsg)
	end
end

---@private
function UIBedWarSpecialModeLayout:updateView()
	local specialModeId = TeamService:getSpecialModeId()
	local cfg = SpecialMode:getCfgById(specialModeId)
	self.stLastTimeHint:SetVisible(false)
	self.stLastTime:SetVisible(false)
	self.specialModeShopId = 0
	self.cfg = cfg
	if cfg then
		self.llReturn:setTitle(cfg.name)
		self.specialModeShopId = cfg.shopId
		self:updateThemeInfo()
		self:updateModeCountDown(cfg)
	end
	self:updateTaskInfoByTabId(tabType.daily)
end

function UIBedWarSpecialModeLayout:updateModeCountDown(cfg)
	self.closeOsTime = cfg.closeOsDate or 0
end

function UIBedWarSpecialModeLayout:updateThemeInfo()
	local specialModeId = TeamService:getSpecialModeId()
	local info = SpecialMode:getSpecialModeInfo(specialModeId)
	local num = #info
	local totalWidth = num * themeIconSize + (num - 1) * themeIconInterval
	totalWidth = totalWidth > 376 and 376 or totalWidth
	self.llThemeList:SetWidth({ 0, totalWidth })
	self.specialModeThemeCellAdapter:setData(info)
end

function UIBedWarSpecialModeLayout:updateTaskInfoByTabId(tabId)
	self.allTaskGroup = {}
	self.btnReceiveAll:SetTouchable(false)
	self.btnReceiveAll:SetEnabled(false)
	if not self.cfg then
		return
	end
	self.curTaskTab = tabId
	local dImage = tabId == tabType.daily and "set:classic_mode.json image:tab_normal" or "set:classic_mode.json image:tab_click"
	local wImage = tabId == tabType.week and "set:classic_mode.json image:tab_normal" or "set:classic_mode.json image:tab_click"
	local dTextColor = tabId == tabType.daily and btnTextColor.pushed or btnTextColor.normal
	local wTextColor = tabId == tabType.week and btnTextColor.pushed or btnTextColor.normal
	self.btnDailyTask:SetNormalImage(dImage)
	self.btnDailyTask:SetPushedImage(dImage)
	self.btnWeekTask:SetNormalImage(wImage)
	self.btnWeekTask:SetPushedImage(wImage)
	self.btnDailyTask:SetTextColor(dTextColor)
	self.btnWeekTask:SetTextColor(wTextColor)
	local curTaskInfo = {}
	local taskGroup = self.cfg.taskGroup
	self.allTaskGroup = SpecialMode:getTaskByGroup(taskGroup)
	for _, v in pairs(self.allTaskGroup) do
		if v.tabId == tabId then
			table.insert(curTaskInfo, v)
		end
	end
	self.specialModeTaskCellAdapter:setData(curTaskInfo)
	self:updateBtnReceiveAll()
end

function UIBedWarSpecialModeLayout:updateBtnReceiveAll()
	local specialModeId = TeamService:getSpecialModeId()
	local curPlayer = PlayerManager:getClientPlayer()
	local canReceiveAll = false
	self.canReceiveTask = {}
	local redDotInfo = {}
	for _, v in pairs(self.allTaskGroup) do
		local taskConfig = curPlayer:getSpecialModeTaskInfo(specialModeId, v.taskId)
		if not redDotInfo[v.tabId] then
			redDotInfo[v.tabId] = 0
		end
		if taskConfig and taskConfig.status == Define.TaskStatus.FINISHED then
			if v.tabId == self.curTaskTab then
				table.insert(self.canReceiveTask, v.taskId)
				canReceiveAll = true
			end
			redDotInfo[v.tabId] = redDotInfo[v.tabId] + 1
		end
	end
	for tabId, count in pairs(redDotInfo) do
		UIUtils.updateRedDotCount(redDotKey[tabId], count)
	end
	self.btnReceiveAll:SetTouchable(canReceiveAll)
	self.btnReceiveAll:SetEnabled(canReceiveAll)
end

---@private
function UIBedWarSpecialModeLayout:onShow()
	self:initOpenEvent()
	self:updateView()
end

---@private
function UIBedWarSpecialModeLayout:onHide()
	self:unregisterOpenEvent()
end

return UIBedWarSpecialModeLayout
