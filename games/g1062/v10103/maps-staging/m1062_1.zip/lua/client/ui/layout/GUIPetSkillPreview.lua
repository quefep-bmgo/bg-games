---@class UIPetSkillPreviewLayout : IGUILayout
local UIPetSkillPreviewLayout = class("UIPetSkillPreviewLayout", IGUILayout)

---@type PetImbueRandomPoolConfig
local PetImbueRandomPoolConfig = T(Global, "PetImbueRandomPoolConfig")
---@type PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")

---@private
function UIPetSkillPreviewLayout:ctor(parent)
	self.super.ctor(self, "PetSkillPreview.json", parent)
end

---@private
function UIPetSkillPreviewLayout:isDelayLoad()
	return true
end

---@private
function UIPetSkillPreviewLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIPetSkillPreviewLayout:initCreateEvent()

end

---@private
function UIPetSkillPreviewLayout:onLoad()
	self.llPanel = self:getChildWindow("PetSkillPreview-Panel", GUIType.Layout)
	self.llTitle = self:getChildWindow("PetSkillPreview-Title", GUIType.Layout)
	self.stTitleText = self:getChildWindow("PetSkillPreview-Title-Text", GUIType.StaticText)
	self.btnClose = self:getChildWindow("PetSkillPreview-Close", GUIType.Button)
	self.ltMsgList = self:getChildWindow("PetSkillPreview-MsgList", GUIType.List)
	self:initView()
	self:initEvent()
end

---@private
function UIPetSkillPreviewLayout:initView()
	self.stTitleText:SetText(Lang:getString("custom.shop.pet.preview.skill"))
	self:setSkillDesc()
end

---@private
function UIPetSkillPreviewLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

function UIPetSkillPreviewLayout:setSkillDesc()
	local allCfgs = PetImbueRandomPoolConfig:getAllCfgs()
	local dataList = {}
	for i, cfg in pairs(allCfgs) do
		local imbueCfg = PetLvConfig:getPetImbueConfigByGroupId(cfg.imbueGroupId)
		local maxLv = -1 --技能等级从0开始
		for i, v in pairs(imbueCfg.lvCfg) do
			maxLv = maxLv + 1
		end
		local data = {
			isNew = cfg.isNew or 0,
			imbueGroupId = cfg.imbueGroupId,
			quality = imbueCfg.quality,
			maxLv = maxLv
		}
		table.insert(dataList, data)
	end

	table.sort(dataList, function(a, b)
		if a.isNew == b.isNew then
			if a.quality == b.quality then
				return a.imbueGroupId > b.imbueGroupId
			else
				return a.quality > b.quality
			end
		else
			return a.isNew > b.isNew
		end
	end)
	for _, data in pairs(dataList) do
		local uiText = self:createDescText(data.imbueGroupId)
		local _, color, qualityStr, desc = PetLvConfig:getDescByImbueGroupId(data.imbueGroupId, data.maxLv)
		local showStr = string.format("%s·%s %s", color, qualityStr, desc)
		if data.isNew == 1 then
			showStr = showStr.."▢FF00FF00 New!"
		end
		uiText:SetText(showStr)
		self.ltMsgList:AddItem(uiText)
	end
end

function UIPetSkillPreviewLayout:createDescText(id)
	local text = GUIManager:createGUIWindow(GUIType.StaticText, "SkillDesc"..id)
	text:SetWidth({1, 0})
	text:SetHeight({0, 30})
	text:SetWordWrap(true)
	text:SetProperty("TextSelfAdaptHigh", "true")
	return text
end


return UIPetSkillPreviewLayout
