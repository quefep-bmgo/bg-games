---@class UIPetChangeSkillConfirmLayout : IGUILayout
local UIPetChangeSkillConfirmLayout = class("UIPetChangeSkillConfirmLayout", IGUILayout)
---@type PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")
---@type PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")

---@private
function UIPetChangeSkillConfirmLayout:ctor(parent)
	self.super.ctor(self, "PetChangeSkillConfirm.json", parent)

end

---@private
function UIPetChangeSkillConfirmLayout:isDelayLoad()
	return true
end

---@private
function UIPetChangeSkillConfirmLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIPetChangeSkillConfirmLayout:initCreateEvent()

end

---@private
function UIPetChangeSkillConfirmLayout:onLoad()
	self.root:SetLevel(49)
	self.siCloseBg = self:getChildWindow("PetChangeSkillConfirm-Close-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("PetChangeSkillConfirm-Content", GUIType.Layout)
	self.stTop = self:getChildWindow("PetChangeSkillConfirm-Top", GUIType.StaticText)
	self.btnClose = self:getChildWindow("PetChangeSkillConfirm-Close", GUIType.Button)
	self.siArrow = self:getChildWindow("PetChangeSkillConfirm-Arrow", GUIType.StaticImage)
	self.btnCancel = self:getChildWindow("PetChangeSkillConfirm-Cancel", GUIType.Button)
	self.btnSureBtn = self:getChildWindow("PetChangeSkillConfirm-SureBtn", GUIType.Button)
	self.llEffect = self:getChildWindow("PetChangeSkillConfirm-Effect", GUIType.Layout)

	self.SlotUi = {
		{
			slot = self:getChildWindow("PetChangeSkillConfirm-Slot-1", GUIType.StaticImage),
			icon = self:getChildWindow("PetChangeSkillConfirm-Slot-Icon-1", GUIType.StaticImage),
			name = self:getChildWindow("PetChangeSkillConfirm-Slot-Name-1", GUIType.StaticText),
			desc = self:getChildWindow("PetChangeSkillConfirm-Slot-Buff-Desc-1", GUIType.StaticText),
			level = self:getChildWindow("PetChangeSkillConfirm-Slot-LevelText-1", GUIType.StaticText)
		},
		{
			slot = self:getChildWindow("PetChangeSkillConfirm-Slot-2", GUIType.StaticImage),
			icon = self:getChildWindow("PetChangeSkillConfirm-Slot-Icon-2", GUIType.StaticImage),
			name = self:getChildWindow("PetChangeSkillConfirm-Slot-Name-2", GUIType.StaticText),
			desc = self:getChildWindow("PetChangeSkillConfirm-Slot-Buff-Desc-2", GUIType.StaticText),
			level = self:getChildWindow("PetChangeSkillConfirm-Slot-LevelText-2", GUIType.StaticText)
		}
	}
	self:initView()
	self:initEvent()
end

---@private
function UIPetChangeSkillConfirmLayout:initView()
	self.stTop:SetText(Lang:getString("custom.shop.pet.change.skill.title"))
	self.btnCancel:SetText(Lang:getString("custom.shop.pet.change.skill.cancel"))
	self.btnSureBtn:SetText(Lang:getString("custom.shop.pet.change.skill.ok"))
end

---@private
function UIPetChangeSkillConfirmLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
	self.btnCancel:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
	self.btnSureBtn:registerEvent(GUIEvent.ButtonClick, function()
		if self.petId then
			PetUpgradeShop:onSavePetRandomSkill(nil, self.petId)
		end
		self:hide()
	end)
end

function UIPetChangeSkillConfirmLayout:setSlot(index, petId, imbueGroupId)
	local ui = self.SlotUi[index]
	if not ui then
		return
	end
	local goods = CustomShopConfig:getGoodsConfigBySetting(petId)
	ui.icon:SetImage(goods.Image)
	ui.name:SetText(Lang:getString(goods.Name))
	local player = PlayerManager:getClientPlayer()
	if player then
		if not player.petData then
			player.petData = {}
		end
		local lv = player.petData[tostring(petId)] or -1
		local _, color, quality, desc = PetLvConfig:getDesc(petId, lv >= 0 and lv or 0, imbueGroupId)
		local lvStr = "Lv."..(lv >= 0 and lv or 0)
		ui.level:SetText(lvStr)
		ui.desc:SetText(string.format("%s(%s)%s%s", color, quality, lvStr, desc))
	end
end

function UIPetChangeSkillConfirmLayout:showUIEffect()
	self.llEffect:SetVisible(true)
	self.llEffect:SetEffectName("g1008_genius_up.effect")
end

function UIPetChangeSkillConfirmLayout:onShow(petId, oldImbueGroupId, newImbueGroupId)
	self.petId = petId
	self:showUIEffect()
	self:setSlot(1, petId, oldImbueGroupId)
	self:setSlot(2, petId, newImbueGroupId)
end

return UIPetChangeSkillConfirmLayout
