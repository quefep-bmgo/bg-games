---@class UIPetUpgradeContentLayout : IGUILayout
local UIPetUpgradeContentLayout = class("UIPetUpgradeContentLayout", IGUILayout)
---@type PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")
---@type PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")

---@private
function UIPetUpgradeContentLayout:onLoad()
	self.awActor = self:getChildWindow("PetUpgradeContent-Actor", GUIType.ActorWindow)
	self.siCur = self:getChildWindow("PetUpgradeContent-Cur", GUIType.StaticImage)
	self.stCurLv = self:getChildWindow("PetUpgradeContent-Cur-Lv", GUIType.StaticText)
	self.stCurDesc = self:getChildWindow("PetUpgradeContent-Cur-Desc", GUIType.StaticText)
	self.siNext = self:getChildWindow("PetUpgradeContent-Next", GUIType.StaticImage)
	self.stNextLv = self:getChildWindow("PetUpgradeContent-Next-Lv", GUIType.StaticText)
	self.stNextDesc = self:getChildWindow("PetUpgradeContent-Next-Desc", GUIType.StaticText)
	self.siArrow = self:getChildWindow("PetUpgradeContent-Arrow", GUIType.StaticImage)
	self.btnUpgrade = self:getChildWindow("PetUpgradeContent-Upgrade", GUIType.Button)
	self.siMoneyType = self:getChildWindow("PetUpgradeContent-Money-Type", GUIType.StaticImage)
	self.stPrice = self:getChildWindow("PetUpgradeContent-Price", GUIType.StaticText)
	self.llSlide = self:getChildWindow("PetUpgradeContent-Slide")
	self.siEffect = self:getChildWindow("PetUpgradeContent-Effect", GUIType.StaticImage)
	self.stMax = self:getChildWindow("PetUpgradeContent-Max-Text", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function UIPetUpgradeContentLayout:initView()
	self.siEffect:SetVisible(true)
	self.siEffect:PlayEffect1("")
	self.btnUpgrade:SetText(Lang:getString("gui_pet_upgrade_text"))
	self.stMax:SetText(Lang:getString("gui_pet_lv_max_text"))
end

---@private
function UIPetUpgradeContentLayout:initEvent()
	self.btnUpgrade:registerEvent(GUIEvent.ButtonClick, function()
		if not self.petId then
			return
		end
		SoundUtil.playSound(420)
		PetUpgradeShop:onUpgradePet(PlayerManager:getClientPlayer(), self.petId)
	end)

	self.llSlide:registerEvent(GUIEvent.TouchDown, function(events)
		self.awActor:TouchDown(events.position)
	end)

	self.llSlide:registerEvent(GUIEvent.TouchMove, function(events)
		self.awActor:TouchMove(events.position)
	end)

	self:registerDataCallBack("SyncPetLvData", function(data)
		if self:isShow() then
			self:onPetUpgradeSucc()
		end
	end, JsonBuilderProcessor)
end

function UIPetUpgradeContentLayout:onHide()
	self:cancelTimer()
end

function UIPetUpgradeContentLayout:onShow()
	self.siEffect:PlayEffect1("")
end

function UIPetUpgradeContentLayout:playAction(ActorName, uiSkillName, actorRotate,actorXRotate)
	actorRotate = actorRotate or 0
	actorXRotate = actorXRotate or 0
	self.awActor:SetActor1(ActorName, "idle", actorRotate)
	self:addTimer(LuaTimer:schedule(function()
		self.awActor:SetActor1(ActorName, uiSkillName, actorRotate)
		self.awActor:SetRotateY(actorRotate)
		self.awActor:SetRotateX(actorXRotate)
	end, 1))
	self.awActor:SetRotateY(actorRotate)
	self.awActor:SetRotateX(actorXRotate)
end

function UIPetUpgradeContentLayout:setActor(setting)
	self.awActor:SetActor1(setting.ActorName, setting.uiSkillName, 0)
	self.awActor:SetWidth({ 0, 230 * setting.scale })
	self:addTimer(LuaTimer:scheduleTimer(function()
		if not self.awActor:GetActor():getHasInited() then
			return
		end
		local petTime = self.awActor:GetActor():GetSkillTimeLength(setting.uiSkillName)
		local petShowTime = self.awActor:GetActor():GetSkillTimeLength(setting.uiShowSkillName)
		local time = petTime
		if petTime ~= 0 then
			self:cancelTimer()
			if setting.uiShowSkillName ~= "#" then
				self:playAction(setting.ActorName, setting.uiShowSkillName, setting.uiActorRotate, setting.uiActorXRotate)
				self:addTimer(LuaTimer:scheduleTimer(function()
					self:playAction(setting.ActorName, setting.uiSkillName, setting.uiActorRotate, setting.uiActorXRotate)
					self:addTimer(LuaTimer:scheduleTimer(function()
						self:playAction(setting.ActorName, setting.uiSkillName, setting.uiActorRotate, setting.uiActorXRotate)
					end, time))
				end, petShowTime, 1))
			else
				self:playAction(setting.ActorName, setting.uiSkillName, setting.uiActorRotate, setting.uiActorXRotate)
				self:addTimer(LuaTimer:scheduleTimer(function()
					self:playAction(setting.ActorName, setting.uiSkillName, setting.uiActorRotate, setting.uiActorXRotate)
				end, time))
			end
		end
	end, 20, 50))
end

function UIPetUpgradeContentLayout:onPetUpgradeSucc()
	self.siEffect:PlayEffect1("g1008_pet_levelup.effect")
	self:setUpgradeInfo(self.petId, self.curLv + 1)
end

--PetUpgradeContent = buildCustomDialogContent(UIPetUpgradeContentLayout, "PetUpgradeContent.json")

function UIPetUpgradeContentLayout:setUpgradeInfo(petId, curLv)
	if not self:isShow() then
		self:cancelTimer()
		local setting = CustomShopPet:getSetting(petId)
		if setting then
			self:setActor(setting)
		end
	end
	if self.petId == petId and self.curLv == curLv then
		return
	end
	self.petId = petId
	self.curLv = curLv
	local imbueGroupId =  PlayerManager:getClientPlayer().randomSkillData[tostring(petId)] or PetLvConfig:getPetDefaultImbueGroupId(petId)
	local isMax = PetLvConfig:isMaxLv(petId, curLv)
	self.btnUpgrade:SetEnabled(not isMax)
	self.btnUpgrade:SetText(isMax and " " or (curLv >= 0 and Lang:getString("gui_pet_upgrade_text") or Lang:getString("gui_pet_activated_text")))

	self.stCurLv:SetText(curLv >= 0 and "Lv." .. curLv or Lang:getString("gui_pel_lv_unactivated"))
	local cur_desc = PetLvConfig:getDesc(petId, curLv >= 0 and curLv or 0, imbueGroupId)
	self.stCurDesc:SetText(cur_desc)

	self.siArrow:SetVisible(not isMax and curLv >= 0)
	self.siNext:SetVisible(not isMax and curLv >= 0)
	self.siCur:SetXPosition((isMax or curLv < 0) and {0, 0} or {0, 20})
	self.siCur:SetHorizontalAlignment((isMax or curLv < 0) and HorizontalAlignment.Center or HorizontalAlignment.Left)
	self.stMax:SetVisible(isMax)
	self.siMoneyType:SetVisible(not isMax)
	if not isMax then
		local nextLv = curLv + 1
		local nextLvSetting = PetLvConfig:getConfigByLv(petId, nextLv, imbueGroupId)
		self.stPrice:SetText(nextLvSetting.price)
		if curLv >= 0 then
			self.stNextLv:SetText("Lv." .. nextLv)
			local next_desc = PetLvConfig:getDesc(petId, nextLv, imbueGroupId)
			self.stNextDesc:SetText(next_desc)
		end
	end
end

return UIPetUpgradeContentLayout
