local function hideEngineWindow(name)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetXPosition({ 0, 6000 })
    window:SetVisible(false)
end

local function setTouchable(window, visible)
    window:SetTouchable(visible)
    local count = window:GetChildCount()
    if count == 0 then
        return
    end
    for index = 1, count do
        setTouchable(window:GetChildByIndex(index - 1), visible)
    end
end

---@class UIGameMain : IGUILayout
local UIGameMain = class("UIGameMain", IGUILayout)

function UIGameMain:onLoad()
    self.cbShortMessage = self:getChildWindow("BedWarGameMain-MenuList-ShortMessage", GUIType.CheckBox)
    self.siShortMessageMask = self:getChildWindow("BedWarGameMain-MenuList-ShortMessage-mask", GUIType.StaticImage)
    self.btnStore = self:getChildWindow("BedWarGameMain-Store-Btn", GUIType.Button)
    self.btnUpgradeStore = self:getChildWindow("BedWarGameMain-UpgradeStore-Btn", GUIType.Button)
    self.btnKeyLottery = self:getChildWindow("BedWarGameMain-KeyLottery-Btn", GUIType.Button)

    self.ivScreenEffect = self:getChildWindow("BedWarGameMain-Screen-Effect", GUIType.StaticImage)
    self.ivScreenEffect:SetVisible(false)

    self.lyPersonView = self:getChildWindow("BedWarGameMain-PersonView", GUIType.Layout)
    self.siPersonView = self:getChildWindow("BedWarGameMain-PersonView-Image", GUIType.StaticImage)
    self.lyPersonView:SetVisible(true)

    self.btnTriggerGift = self:getChildWindow("BedWarGameMain-Trigger-Gift", GUIType.Button)
    self.btnTriggerGiftBg = self:getChildWindow("BedWarGameMain-Trigger-Gift-Effect-Bg", GUIType.Layout)
    self.btnTriggerGift:SetVisible(false)

    self.btnScoreboard = self:getChildWindow("BedWarGameMain-Scoreboard", GUIType.Button)

    self.stPing = self:getChildWindow("BedWarGameMain-Ping", GUIType.StaticText)
    self.stUserId = self:getChildWindow("BedWarGameMain-UserId", GUIType.StaticText)

    if GameType ~= "g1064" and GameType ~= "g1046" then
        --self.cbShortMessage:SetYPosition({0, 140})
        --self.btnScoreboard:SetYPosition({0, 210})
        self.cbShortMessage:SetVisible(false)
        self.btnScoreboard:SetVisible(false)
    end

    --Plugins.CallTargetPluginFunc("trigger_gift", "setOpenButton", self.btnTriggerGift)
    --UIUtils.addRedDot(self.btnTriggerGift, Define.RedDotKey.TriggerGift, nil, { offset = VectorUtil.newVector2(-6, 14) })

    self:setEngineUIStyle()
    self:register()
    self.btnStore:setRenderInMainScreen()
    if SpecialMode:moduleInfo(Define.ModeLimiterType.TeamUpgrade) then
        self.btnUpgradeStore:setRenderInMainScreen()
        self.btnUpgradeStore:SetVisible(true)
    end
    self.btnKeyLottery:setRenderInMainScreen()
end

function UIGameMain:setEngineUIStyle()
    ClientHelper.putFloatPrefs("PoleControlMaxDistance", 65)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaNormal", 1)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaPress", 1)
    local ivPoleArrow = GUIManager:getWindowByName("Main-PoleControl-Arrow", GUIType.StaticImage)
    ivPoleArrow:SetImage("set:pole.json image:pole_arrow")
    local wMoveState = GUIManager:getWindowByName("Main-MoveState")
    wMoveState:setRenderInMainScreen()
    wMoveState:SetArea(wMoveState:GetXPosition(), wMoveState:GetYPosition(), { 0, 70 }, { 0, 70 })
    local wJumControls = GUIManager:getWindowByName("Main-Jump-Controls")
    wJumControls:setRenderInMainScreen()
    wJumControls:SetArea(wJumControls:GetXPosition(), wJumControls:GetYPosition(), { 0, 138 }, { 0, 377 })
    local btnSkillRelease = GUIManager:getWindowByName("Main-Skill-Release-btn", GUIType.Button)
    btnSkillRelease:SetNormalImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetPushedImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetArea(btnSkillRelease:GetXPosition(), btnSkillRelease:GetYPosition(), { 0, 120 }, { 0, 120 })
    self.btnSkill = btnSkillRelease
    local btnCannon = GUIManager:getWindowByName("Main-Cannon", GUIType.Button)
    btnCannon:SetNormalImage("set:bedwarsmall.json image:btn_0_fort")
    btnCannon:SetPushedImage("set:bedwarsmall.json image:btn_0_fort")
    local ivSneak = GUIManager:getWindowByName("Main-MoveState-Sneak", GUIType.StaticImage)
    ivSneak:SetImage("set:move_state.json image:sneak_circle")
    local btnFly = GUIManager:getWindowByName("Main-Fly", GUIType.Button)
    btnFly:SetNormalImage("set:bedwarsmall.json image:fly")
    btnFly:SetPushedImage("set:bedwarsmall.json image:fly")
    btnFly:SetArea(btnFly:GetXPosition(), btnFly:GetYPosition(), { 0, 70 }, { 0, 70 })
    hideEngineWindow("Main-Player-Exp")
    hideEngineWindow("Main-Chat-Message")
    hideEngineWindow("Main-Gun-Operate-ReloadBtn")

    local bgWatch = GUIManager:getWindowByName("Main-Watch-Battle-Bg", GUIType.StaticImage)
    bgWatch:SetProperty("StretchOffset", "60 10 0 0")
    bgWatch:SetImage("set:bedwar_toolbar.json image:bg_onWatch")
    GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetHeight({ 0, 49 })
    GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetWidth({ 0, 250 })
    GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetArea({ 0, 50 }, { 0, 0 }, { 1, -50 }, { 1, 0 })
    GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetHorizontalAlignment(HorizontalAlignment.Left)
end

function UIGameMain:register()

    self.btnKeyLottery:registerEvent(GUIEvent.ButtonClick, function()
        GUINewLottery:show(true)
    end)

    self.btnStore:registerEvent(GUIEvent.ButtonClick, function()
        if isGameStart then
            GUIStore:show(StoreId.GoodsStore, nil, true)
        --if not isGameStart and GUIStore.showByType then
        --    GUIStore:showByType("lottery")
        --end
        else
            CustomDialog.builder().setContentText(Lang:getString("gui.message.not.start"))
                        .setLeftText("gui_dialog_tip_btn_cancel")
                        .setRightText("gui_dialog_tip_btn_sure")
                        .show()
        end
    end)
    self.btnUpgradeStore:registerEvent(GUIEvent.ButtonClick, function()
        if isGameStart then
            GUIUpgradeStore:show(true)
        else
            CustomDialog.builder().setContentText(Lang:getString("gui.message.not.start"))
                        .setLeftText("gui_dialog_tip_btn_cancel")
                        .setRightText("gui_dialog_tip_btn_sure")
                        .show()
        end
    end)

    --self.btnScoreboard:registerEvent(GUIEvent.ButtonClick, function()
    --    if TeamConfig:getTeamCount() > 4 then
    --        GUISingleScoreboard:show()
    --    else
    --        GUITeamScoreboard:show()
    --    end
    --end)

    --self.cbShortMessage:registerEvent(GUIEvent.CheckStateChanged, function()
    --    if self.cbShortMessage:GetChecked() then
    --        GUICommandList:show(true)
    --    else
    --        GUICommandList:hide()
    --    end
    --end)

    local challenge = self:getChildWindow("BedWarGameMain-Menu-Challenge", GUIEvent.Button)
    if challenge then
        challenge:registerEvent(GUIEvent.ButtonClick, function()
            GUITreasureChallenge:onDataChange(TreasureChallenge.rewardData)
            GUITreasureChallenge:show(true)
        end)
    end

    self.lyPersonView:registerEvent(GUIEvent.Click, function()
        local cruCamera = SystemSettingRecord.defaultCamera
        if cruCamera == 1 then
            GUIBedWarSetting:changeCamera(2)
            SystemSettingRecord.defaultCamera = 2
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective3_normal")
        elseif cruCamera == 2 then
            GUIBedWarSetting:changeCamera(1)
            SystemSettingRecord.defaultCamera = 1
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
        elseif cruCamera == 3 then
            GUIBedWarSetting:changeCamera(1)
            SystemSettingRecord.defaultCamera = 1
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
        end
    end)

    self:registerEvent(Events.ShowFrontPlaceBlockEvent, function()
        if not isGameStart then
            return false
        end
        local heldItemId = Game:getPlayer():getHeldItemId()
        ---过滤有技能的方块
        local skill = SkillConfig:getSkill(heldItemId)
        if skill then
            return false
        end
        ---过滤保护墙和防御
        if heldItemId == 2418 or heldItemId == 2417 then
            return false
        end
        return true
    end)
end

function UIGameMain:upScreenEffect(time)
    self.ivScreenEffect:SetVisible(true)
    self.ivScreenEffect:SetEffectName("g1008_radar_ui.effect")
    LuaTimer:cancel(self.screen_key or 0)
    self.screen_key = LuaTimer:scheduleWithEnd(function()
    end, function()
        self.ivScreenEffect:SetVisible(false)
    end, time * 1000)
end

local function checkOnMount()
    local entityPlayer = PlayerManager:getClientPlayer().Player
    if entityPlayer then
        if entityPlayer:isOnFloatingMount() or entityPlayer:isOnFlyingMount() then
            return true
        end
    end
    return false
end

function UIGameMain:onTick(frameTime)
    GUIPlayerInventory:onTick(frameTime)

    local onMount = checkOnMount()
    GUIBedWarToolBar.btnChangeCamera:SetEnabled(not onMount)
    self.lyPersonView:SetVisible(not onMount)
    self.btnTriggerGiftBg:SetVisible(self.btnTriggerGift:IsVisible())

    local fps = Root.Instance():getFPS()
    local ping = ClientNetwork.Instance():getRaknetPing()
    local text = TextFormat.colorGreen .. "Fps:" .. fps .. "  Ping:" .. ping
    self.stPing:SetText(text)
    self.stUserId:SetText("▢5000FF00UID:" .. Game:getPlatformUserId())
end

function UIGameMain:onCommandCD()
    --self.cbShortMessage:SetTouchable(false)
    GUIBedWarToolBar.cbShortMessage:SetTouchable(false)
    self.siShortMessageMask:SetVisible(true)
    self.siShortMessageMask:setCooldownAnim(true, 1000)

    LuaTimer:schedule(function()
        GUIBedWarToolBar.cbShortMessage:SetTouchable(true)
        --self.cbShortMessage:SetTouchable(true)
        self.siShortMessageMask:SetVisible(false)
    end, 1000)
end

function UIGameMain:cameraChange()
    local cruCamera = Blockman.Instance():getCurrPersonView()
    if cruCamera == 1 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective3_normal")
    elseif cruCamera == 2 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective2_normal")
    elseif cruCamera == 0 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
    end
end

function UIGameMain:showActivityBtn(isShow)

end

return UIGameMain
