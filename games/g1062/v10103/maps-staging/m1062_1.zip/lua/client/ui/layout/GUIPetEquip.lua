---@class UIPetEquipLayout : IGUILayout
local UIPetEquipLayout = class("UIPetEquipLayout", IGUILayout)
---@type PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")
---@type PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")

---@private
function UIPetEquipLayout:ctor(parent)
	self.super.ctor(self, "PetEquip.json", parent)
end

---@private
function UIPetEquipLayout:isDelayLoad()
	return true
end

---@private
function UIPetEquipLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIPetEquipLayout:initCreateEvent()

end

---@private
function UIPetEquipLayout:onLoad()
	self.siCloseBg = self:getChildWindow("PetEquip-Close-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("PetEquip-Content", GUIType.Layout)
	self.stTop = self:getChildWindow("PetEquip-Top", GUIType.StaticText)
	self.btnClose = self:getChildWindow("PetEquip-Close", GUIType.Button)
	self.siSlot1 = self:getChildWindow("PetEquip-Slot-1", GUIType.StaticImage)
	self.siSlotIcon1 = self:getChildWindow("PetEquip-Slot-Icon-1", GUIType.StaticImage)
	self.stSlotName1 = self:getChildWindow("PetEquip-Slot-Name-1", GUIType.StaticText)
	self.stSlotBuffDesc1 = self:getChildWindow("PetEquip-Slot-Buff-Desc-1", GUIType.StaticText)
	self.btnSlotEquip1 = self:getChildWindow("PetEquip-Slot-Equip-1", GUIType.Button)
	self.siSlot2 = self:getChildWindow("PetEquip-Slot-2", GUIType.StaticImage)
	self.siSlotIcon2 = self:getChildWindow("PetEquip-Slot-Icon-2", GUIType.StaticImage)
	self.stSlotName2 = self:getChildWindow("PetEquip-Slot-Name-2", GUIType.StaticText)
	self.stSlotBuffDesc2 = self:getChildWindow("PetEquip-Slot-Buff-Desc-2", GUIType.StaticText)
	self.btnSlotEquip2 = self:getChildWindow("PetEquip-Slot-Equip-2", GUIType.Button)
	self.SlotUi = {
		{
			slot = self:getChildWindow("PetEquip-Slot-1", GUIType.StaticImage),
			icon = self:getChildWindow("PetEquip-Slot-Icon-1", GUIType.StaticImage),
			name = self:getChildWindow("PetEquip-Slot-Name-1", GUIType.StaticText),
			desc = self:getChildWindow("PetEquip-Slot-Buff-Desc-1", GUIType.StaticText)
		},
		{
			slot = self:getChildWindow("PetEquip-Slot-2", GUIType.StaticImage),
			icon = self:getChildWindow("PetEquip-Slot-Icon-2", GUIType.StaticImage),
			name = self:getChildWindow("PetEquip-Slot-Name-2", GUIType.StaticText),
			desc = self:getChildWindow("PetEquip-Slot-Buff-Desc-2", GUIType.StaticText)
		}
	}
	self:initView()
	self:initEvent()
end

---@private
function UIPetEquipLayout:initView()
	self.stTop:SetText(Lang:getString("gui_pet_equip_change_title"))
	self.btnSlotEquip1:SetText(Lang:getString("gui_pet_equip_change_btn"))
	self.btnSlotEquip2:SetText(Lang:getString("gui_pet_equip_change_btn"))
end

---@private
function UIPetEquipLayout:initEvent()
	self.siCloseBg:registerEvent(GUIEvent.Click, function()
		self:hide()
	end)

	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)

	self.btnSlotEquip1:registerEvent(GUIEvent.ButtonClick, function()
		self:onChangeClick(1)
	end)

	self.btnSlotEquip2:registerEvent(GUIEvent.ButtonClick, function()
		self:onChangeClick(2)
	end)
end

function UIPetEquipLayout:onShow(pets, new)
	self:updateUi(pets)
end

function UIPetEquipLayout:updateUi(pets)
	if self.pets and self.pets == pets then
		return
	end
	self.pets = pets
	self:setSlot(1, pets[1])
	self:setSlot(2, pets[2])
end

function UIPetEquipLayout:setSlot(index, petId)
	local ui = self.SlotUi[index]
	if not ui then
		return
	end
	local goods = CustomShopConfig:getGoodsConfigBySetting(petId)
	ui.icon:SetImage(goods.Image)
	ui.name:SetText(Lang:getString(goods.Name))
	local player = PlayerManager:getClientPlayer()
	if player then
		if not player.petData then
			player.petData = {}
		end
		local lv = player.petData[tostring(petId)] or -1
		local desc = PetLvConfig:getDesc(petId, lv >= 0 and lv or 0, player.randomSkillData[tostring(petId)])
		ui.desc:SetText(desc)
	end
end

function UIPetEquipLayout:onChangeClick(index)
	if not self.pets then
		return
	end
	if not PetUpgradeShop:checkCanEquip(PlayerManager:getClientPlayer(), GUICustomShop.curSelectGoods.SettingId, index) then
		CustomDialog.hide()
		CustomDialog.builder()
					.setTitleText("gui_pet_equip_same_imbue_tip_title")
					.setContentText(Lang:getString("gui_pet_equip_same_imbue_tip_text"))
					.setCloseVisible(false)
					.setRightClickListener(function()
			self:equipPet(index)
		end)
		CustomDialog.show()
	else
		self:equipPet(index)
	end
end

function UIPetEquipLayout:equipPet(index)
	local goods = CustomShopConfig:getGoodsConfigBySetting(self.pets[index])
	if goods then
		CustomShop:onUnloadGoods(goods)
		self:addTimer(LuaTimer:schedule(function()
			CustomShop:onEquipGoods(GUICustomShop.curSelectGoods)
			self:hide()
		end, 500))
	end
end

function UIPetEquipLayout:onHide()
	self:cancelTimer()
end

return UIPetEquipLayout
