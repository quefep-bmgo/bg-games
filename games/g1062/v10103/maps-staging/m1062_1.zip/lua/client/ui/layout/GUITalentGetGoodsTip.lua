---@class UITalentGetGoodsTipLayout : IGUILayout
local UITalentGetGoodsTipLayout = class("UITalentGetGoodsTipLayout", IGUILayout)

--奖励Item宽
local ItemWidth = 100
local ItemHeight = 50
local MoveDis = -150
local StartYPos = 96
local animTotalTick = 60
local stayTick = 40

---@private
function UITalentGetGoodsTipLayout:ctor(parent)
	self.super.ctor(self, "TalentGetGoodsTip.json", parent)
	self.itemList = {}
end

---@private
function UITalentGetGoodsTipLayout:isDelayLoad()
	return true
end

---@private
function UITalentGetGoodsTipLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UITalentGetGoodsTipLayout:initCreateEvent()

end

---@private
function UITalentGetGoodsTipLayout:onLoad()
	self.siBg = self:getChildWindow("TalentGetGoodsTip-Bg", GUIType.StaticImage)
	self.stTitle = self:getChildWindow("TalentGetGoodsTip-Title", GUIType.StaticText)
	self.lhItemList = self:getChildWindow("TalentGetGoodsTip-ItemList", GUIType.ListHorizontal)
	self:initView()
	self:initEvent()
end

---@private
function UITalentGetGoodsTipLayout:initView()
	self.stTitle:SetText(Lang:getString(Lang:getString("gui.talent.imbue.reward")))
end

function UITalentGetGoodsTipLayout:createItem(index, icon, num)
	local root = GUIManager:createGUIWindow(GUIType.Layout, 'TalentGetGoodsTip-item-root'..index)
	local itemIcon = GUIManager:createGUIWindow(GUIType.StaticImage, 'TalentGetGoodsTip-item-icon'..index)
	local countText = GUIManager:createGUIWindow(GUIType.StaticText, 'TalentGetGoodsTip-item-text'..index)

	root:SetWidth({0, ItemWidth})
	root:SetHeight({0, ItemHeight})
	itemIcon:SetArea({0, 0}, {0, 0}, {0, 50}, {0, 50})
	itemIcon:SetImage(icon)

	countText:SetArea({0, 55}, {0, 0}, {0, 50}, {0, 50})
	countText:SetTextVertAlign(VerticalAlignment.Center)
	countText:SetText("+"..num)
	countText:SetFont(GUIFontManager:Instance():GetFont("HT18"))
	countText:SetTextColor({0,0,0,1})

	root:AddChildWindow(countText)
	root:AddChildWindow(itemIcon)

	self.lhItemList:AddItem(root)
	self.itemList[#self.itemList + 1] = root
end

function UITalentGetGoodsTipLayout:showReward(rewardList)
	for i, reward in pairs(rewardList) do
		local goods = StoreConfig:getGoodsByItemId(reward.itemId)
		if goods then
			self:createItem(i, goods.showDetail.image, reward.num)
		end
	end
	self.lhItemList:SetWidth({0, #rewardList * ItemWidth})
end

function UITalentGetGoodsTipLayout:playAnim()
	local dt = 0
	local offset = 1 / animTotalTick
	local curY = StartYPos
	local curAlpha = 1
	local curTick = 0
	local endYPos = curY + MoveDis
	self.animTimer = LuaTimer:scheduleTicker(function()
		curTick = curTick + 1
		if curTick > stayTick then
			dt = dt + offset
			curAlpha = curAlpha - offset
			curY = math.max(self:line_lerp(curY, endYPos, dt), endYPos)
			self.siBg:SetYPosition({0, curY })
			self.siBg:SetAlpha(curAlpha)
			if curY <= endYPos then
				LuaTimer:cancel(self.animTimer)
				self.animTimer = nil
				self:hide()
				return
			end
		end
	end, 1, -1)
end

function UITalentGetGoodsTipLayout:line_lerp(val, targetVal, t)
	if t <= 0 then
		return val
	elseif t >= 1 then
		return targetVal
	end
	return t * targetVal + (1 - t) * val
end

---@private
function UITalentGetGoodsTipLayout:initEvent()

end

function UITalentGetGoodsTipLayout:onShow(rewardList)
	self.siBg:SetYPosition({0, StartYPos})
	self.siBg:SetAlpha(1)
	self:showReward(rewardList)
	self:playAnim()
end

function UITalentGetGoodsTipLayout:onHide()
	if self.animTimer then
		LuaTimer:cancel(self.animTimer)
		self.animTimer = nil
	end
end

return UITalentGetGoodsTipLayout
