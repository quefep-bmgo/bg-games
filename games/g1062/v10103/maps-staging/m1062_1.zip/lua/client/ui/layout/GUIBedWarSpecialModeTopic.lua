---@class UIBedWarSpecialModeTopicLayout : IGUILayout
local UIBedWarSpecialModeTopicLayout = class("UIBedWarSpecialModeTopicLayout", IGUILayout)

---@type TeamService
local TeamService = T(Global, "TeamService")

---@private
function UIBedWarSpecialModeTopicLayout:onLoad()
	self.llList = self:getChildWindow("BedWarSpecialModeTopic-List", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function UIBedWarSpecialModeTopicLayout:initView()
	self.gvThemeList = IGUIGridView.new("BedWarSpecialModeTopic-List-Gird", self.llList)
	self.gvThemeList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.gvThemeList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.gvThemeList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.specialModeThemeCellAdapter = UIHelper.newGameAdapter("BedWarSpecialModeThemeCellAdapter")
	self.specialModeThemeCellAdapter:setItemSize(self.llList:GetPixelSize().x, 64)
	self.gvThemeList:setConfig(0, 20, 1)
	self.gvThemeList:setAdapter(self.specialModeThemeCellAdapter)
end

---@private
function UIBedWarSpecialModeTopicLayout:initEvent()

end

---@private
function UIBedWarSpecialModeTopicLayout:updateView()
	local specialModeId = TeamService:getSpecialModeId()
	local info = SpecialMode:getSpecialModeInfo(specialModeId)
	for i, v in pairs(info) do
		v.isShowDetails = true
	end
	self.specialModeThemeCellAdapter:setData(info)
end

return UIBedWarSpecialModeTopicLayout
