---@class UIImbueScreenEffectLayout : IGUILayout
local UIImbueScreenEffectLayout = class("UIImbueScreenEffectLayout", IGUILayout)

---@private
function UIImbueScreenEffectLayout:isDelayLoad()
	return true
end

---@private
function UIImbueScreenEffectLayout:onCreate()
	self:initCreateEvent()
	self.screenEffectWndPool = {}
	self.screenEffectRefData = {}
	self.wndId = 0
end

---@private
function UIImbueScreenEffectLayout:initCreateEvent()
	self:registerEvent(Events.ShowImbueScreenEffect, function(effectData)
		if not self:isShow() then
			self:show(effectData)
		else
			self:setScreenEffect(effectData)
		end
	end)

	self:registerEvent(Events.SetBanClickScreen, function(isBan)
		if self:isShow() then
			self.root:SetTouchable(isBan)
		end
	end)

	self:registerEvent(Events.HideImbueScreenEffect, function(screenEffect)
		self:hideScreenEffect(screenEffect)
	end)
end

---@private
function UIImbueScreenEffectLayout:onLoad()
	self.siEffect = self:getChildWindow("ImbueScreenEffect-Effect", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function UIImbueScreenEffectLayout:initView()

end

---@param effectData table {string screenEffect, bool banOperate}
---@param time number 毫秒
function UIImbueScreenEffectLayout:setScreenEffect(effectData)
	if effectData then
		local screenEffect = effectData.screenEffect
		if screenEffect then
			local refData = self.screenEffectRefData[screenEffect]
			if not refData then
				refData = {
					refCount = 0,
					wnd = nil
				}
				self.screenEffectRefData[screenEffect] = refData
			end
			if refData.wnd == nil then
				local wnd = self:getScreenEffectWnd()
				wnd:SetVisible(true)
				wnd:PlayEffect1("")
				wnd:SetEffectName(screenEffect)
				refData.wnd = wnd
			end
			refData.refCount = (refData.refCount or 0) + 1
		end
	end
end

function UIImbueScreenEffectLayout:hideScreenEffect(screenEffect)
	local refData = self.screenEffectRefData[screenEffect]
	if refData then
		if refData.refCount > 0 then
			refData.refCount = refData.refCount - 1
			if refData.refCount == 0 and refData.wnd then
				local wnd = refData.wnd
				refData.wnd = nil
				wnd:SetEffectName("")
				wnd:SetVisible(false)
				table.insert(self.screenEffectWndPool, wnd)
			end
		end
	end
end

function UIImbueScreenEffectLayout:getScreenEffectWnd()
	if #self.screenEffectWndPool > 0 then
		return table.remove(self.screenEffectWndPool, #self.screenEffectWndPool)
	else
		self.wndId = self.wndId + 1
		local wnd = GUIManager:createGUIWindow(GUIType.StaticImage, 'ImbueScreenEffect-Effect' .. self.wndId)
		wnd:SetVerticalAlignment(VerticalAlignment.Top)
		wnd:SetHorizontalAlignment(HorizontalAlignment.Left)
		wnd:SetXPosition({0.314844,0})
		wnd:SetYPosition({-0.009,0})
		wnd:SetWidth({0.371875,0})
		wnd:SetHeight({0.506278,0})
		wnd:SetVisible(false)
		wnd:SetTouchable(false)
		--wnd:SetBackgroundColor({1,1,1,1})
		self.root:AddChildWindow(wnd)
		return wnd
	end
end

function UIImbueScreenEffectLayout:onShow(effectData)
	self:setScreenEffect(effectData)
end

function UIImbueScreenEffectLayout:onHide()
	for _, refData in pairs(self.screenEffectRefData) do
		if refData.refCount > 0 then
			refData.refCount = 0
			local wnd = refData.wnd
			refData.wnd = nil
			wnd:SetEffectName("")
			wnd:SetVisible(false)
			table.insert(self.screenEffectWndPool, wnd)
		end
	end
	self.root:SetTouchable(false)
end

---@private
function UIImbueScreenEffectLayout:initEvent()

end

return UIImbueScreenEffectLayout
