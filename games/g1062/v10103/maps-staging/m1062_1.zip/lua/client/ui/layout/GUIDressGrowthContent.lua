---@class UIDressGrowthContentLayout : IGUILayout
local UIDressGrowthContentLayout = class("UIDressGrowthContentLayout", IGUILayout)

---@type CustomShopDressGrowthConfig
local CustomShopDressGrowthConfig = T(Global, "CustomShopDressGrowthConfig")

---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

local function GrowthInfoLang(info)
	local str = ""
	if info.type == Define.DressGrowthType.Kill then
		str = Lang:format(info.lang, info.params[1] or 0)
	end
	return str
end

---@private
function UIDressGrowthContentLayout:isDelayLoad()
	return true
end

---@private
function UIDressGrowthContentLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIDressGrowthContentLayout:initCreateEvent()

end

---@private
function UIDressGrowthContentLayout:onLoad()
	self.awActorWnd = self:getChildWindow("DressGrowthContent-ActorWnd", GUIType.ActorWindow)
	self.siNameBg = self:getChildWindow("DressGrowthContent-NameBg", GUIType.StaticImage)
	self.stNameText = self:getChildWindow("DressGrowthContent-NameText", GUIType.StaticText)
	self.siLevelBg = self:getChildWindow("DressGrowthContent-LevelBg", GUIType.StaticImage)
	self.stLevelText = self:getChildWindow("DressGrowthContent-LevelText", GUIType.StaticText)
	self.siCondition = self:getChildWindow("DressGrowthContent-Condition", GUIType.StaticImage)
	self.stConditionText = self:getChildWindow("DressGrowthContent-ConditionText", GUIType.StaticText)
	self.siSkillDescBg = self:getChildWindow("DressGrowthContent-SkillDescBg", GUIType.StaticImage)
	self.stSkillDescTitle = self:getChildWindow("DressGrowthContent-SkillDescTitle", GUIType.StaticText)
	self.stSkillDesc = self:getChildWindow("DressGrowthContent-SkillDesc", GUIType.StaticText)
	self.btnOkBtn = self:getChildWindow("DressGrowthContent-OkBtn", GUIType.Button)
	self.stOkBtnText = self:getChildWindow("DressGrowthContent-OkBtn-Text", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIDressGrowthContentLayout:initView()
	self.stNameText:SetText(Lang:getString(""))
	self.stLevelText:SetText(Lang:getString(""))
	self.stSkillDescTitle:SetText(Lang:getString("custom.shop.pet.max.lv.info.desc"))
	self.stSkillDesc:SetText(Lang:getString(""))
	self.stOkBtnText:SetText(Lang:getString("gui.setting.collimator.sure"))
end

---@private
function UIDressGrowthContentLayout:initEvent()
	self.btnOkBtn:registerEvent(GUIEvent.ButtonClick, function()
		CustomDialog.hide()
	end)
end

function UIDressGrowthContentLayout:setData(dressId)
	self.dressId = dressId
	local dress = CustomShopDress.Settings[tostring(dressId)]
	local goodsCfg = CustomShopConfig:getGoodsConfigBySetting(dress.Id)
	local GrowthInfo = CustomShopDressGrowthConfig:getDressMaxGrowthInfoByItemId(dress.ItemId)

	local player = PlayerManager:getClientPlayer()
	if player and GrowthInfo then
		local reward = RewardItemShowDetailConfig:getConfigById(goodsCfg.ShowDetailId)
		self:setActor(reward)
		self.stNameText:SetText(Lang:getString(goodsCfg.Name))
		self.stLevelText:SetText(Lang:getString("custom.shop.pet.max.lv.info.lv")..GrowthInfo.lv)
		self.stSkillDesc:SetText(GrowthInfoLang(GrowthInfo))
		self.stConditionText:SetText(Lang:getString("custom.shop.dress.growth.tip."..GrowthInfo.type))
	end
end

function UIDressGrowthContentLayout:setActor(reward)
	if not reward or reward.actor == "#" then
		return
	end
	RewardItemShowDetailConfig:showActorSkill(self.awActorWnd, reward)
end

function UIDressGrowthContentLayout:onDestroy()
	RewardItemShowDetailConfig:onWindowHide(self.awActorWnd)
	self.super:onDestroy()
end

return UIDressGrowthContentLayout
