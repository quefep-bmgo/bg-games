---@class UISpecialModeShopLayout : IGUILayout
local UISpecialModeShopLayout = class("UISpecialModeShopLayout", IGUILayout)
---@type SpecialModeShopConfig
local SpecialModeShopConfig = T(Global, "SpecialModeShopConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function UISpecialModeShopLayout:isDelayLoad()
	return true
end

---@private
function UISpecialModeShopLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UISpecialModeShopLayout:initCreateEvent()
	self:registerEvent(Events.SpecialModeShopSelectItem, function(shopData)
		self:showCurRewardDetail(shopData)
	end)
end

---@private
function UISpecialModeShopLayout:onLoad()
	self.siItemMsgBg = self:getChildWindow("SpecialModeShop-ItemMsgBg", GUIType.StaticImage)
	self.stItemName = self:getChildWindow("SpecialModeShop-ItemName", GUIType.StaticText)
	self.stItemDesc = self:getChildWindow("SpecialModeShop-ItemDesc", GUIType.StaticText)
	self.btnExchangeBtn = self:getChildWindow("SpecialModeShop-ExchangeBtn", GUIType.Button)
	self.siCurrencyIcon = self:getChildWindow("SpecialModeShop-CurrencyIcon", GUIType.StaticImage)
	self.stPriceText = self:getChildWindow("SpecialModeShop-PriceText", GUIType.StaticText)
	self.stExchangeBtnText = self:getChildWindow("SpecialModeShop-ExchangeBtnText", GUIType.StaticText)
	self.llItemShowContent = self:getChildWindow("SpecialModeShop-ItemShowContent", GUIType.Layout)
	self.siItemIcon = self:getChildWindow("SpecialModeShop-ItemIcon", GUIType.StaticImage)
	self.awItemActor = self:getChildWindow("SpecialModeShop-ItemActor", GUIType.ActorWindow)
	self.llActorClickArea = self:getChildWindow("SpecialModeShop-ActorClickArea", GUIType.Layout)
	self.siRightBg = self:getChildWindow("SpecialModeShop-RightBg", GUIType.StaticImage)
	self.llShopContent = self:getChildWindow("SpecialModeShop-ShopContent", GUIType.Layout)
	self.llShopList = self:getChildWindow("SpecialModeShop-ShopList", GUIType.Layout)
	self.siMoneyContent = self:getChildWindow("SpecialModeShop-MoneyContent", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function UISpecialModeShopLayout:initView()
	self.iconMovePos = 0
	self.iconMoveGap = 2
	---@type GUIBedWarUIReturnControlWindow
	self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.classic.mode.shop.title", function()
		self:hide()
	end)
	self.root:AddChildWindow(self.llReturn.root)

	self.moneyItems = {}
	---@type GUIListHorizontalLayout
	self.lvMoney = UIHelper.newGameGUIWindow("GUIListHorizontalLayout")
	self.lvMoney:setItemSpace(10)
	self.lvMoney:setHorizontalDir(self.lvMoney.HorizontalDir.Right)
	self.lvMoney.root:SetYPosition({0, 5})
	self.siMoneyContent:AddChildWindow(self.lvMoney.root)

	for _, money in pairs({Define.Money.DIAMOND, Define.Money.BED_WAR_COIN}) do
		---@type GUICurrency
		local item = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
		item:onDataChanged({ ItemId = 0, RealId = money })
		table.insert(self.moneyItems, item)
		self.lvMoney:addItem(item)
	end

	self.gvShopList = IGUIGridView.new("ShopListContent-Visitors-List", self.llShopList)
	self.gvShopList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.gvShopList:setConfig(10, 10, 3)

	---@type SpecialModeShopItemAdapter
	self.shopItemAdapter = UIHelper.requireAdapter("SpecialModeShopItemAdapter", false, "ui_activity").new()
	self.shopItemAdapter:setItemSize(130, 130)
	self.gvShopList:setAdapter(self.shopItemAdapter)

	self.stExchangeBtnText:SetText(Lang:getString("gui.exchange"))
end

---@private
function UISpecialModeShopLayout:initEvent()
	self.btnExchangeBtn:registerEvent(GUIEvent.ButtonClick, function()
		if self.curSelectShopData then
			local consumeData = self.curSelectShopData.consumeData
			local curMoney = PlayerWallet.getMoneyByCoinId(consumeData.moneyType)
			if curMoney < consumeData.count then
				CustomDialog.builder()
					.setContentText(Lang:getString("gui.lack.of.score.1007"))
					.setHideLeftButton()
					.show()
				return
			end
			PlayerManager:getClientPlayer():sendPacket({
				pid = "ToActivityPacket",
				activityId = self.mgr.mainConfig.id,
				shopId = self.curSelectShopData.id,
				funcName = "tryBuyShop"
			})
		end
	end)
end

function UISpecialModeShopLayout:onShow()
	local activity = PluginMainActivity:getActivityByClass("CSpecialModeShopMgr")
	if activity[1] then
		self.mgr = activity[1]
		self.mgr:registerCacheChange(function()
			self:onCacheChanged(self.mgr:getPlayerCache())
		end)
		self.shopItemAdapter:setActivityMgr(self.mgr)
		self.shopItemAdapter:setData(SpecialModeShopConfig:getShopListCfg(self.mgr.config.group))
		self:onCacheChanged(self.mgr:getPlayerCache())
		self.shopItemAdapter:select(1)
	end
end

function UISpecialModeShopLayout:showCurRewardDetail(shopData)
	self.curSelectShopData = shopData
	local rewardId = shopData.rewardData.rewardId
	local rewardCfg = CommonActivityConfig:getRewardById(rewardId)
	local rewardDetail = RewardItemShowDetailConfig:getConfigById(rewardCfg.showDetailId)
	self.stItemName:SetText(Lang:getString(rewardDetail.name))
	self.stItemDesc:SetText(Lang:getString(rewardDetail.desc))
	self.siItemIcon:SetVisible(rewardDetail.showType == Define.ShowDetailType.Icon)
	self.awItemActor:SetVisible(rewardDetail.showType == Define.ShowDetailType.Actor)
	if self.llNewKillBroadCastItem then
		self.llNewKillBroadCastItem.root:SetVisible(rewardDetail.showType == Define.ShowDetailType.KillBroadCast)
		self.llNewKillBroadCastItem:onBroadCastEnd()
	end
	if self.llNewKillEffectItem then
		self.llNewKillEffectItem.root:SetVisible(rewardDetail.showType == Define.ShowDetailType.KillEffect)
		self.llNewKillEffectItem:onDataChanged()
	end
	if rewardDetail.showType == Define.ShowDetailType.Icon then
		self:setIcon(rewardDetail)
		self.llActorClickArea:SetVisible(false)
	elseif rewardDetail.showType == Define.ShowDetailType.Actor then
		self.llActorClickArea:SetVisible(true)
		RewardItemShowDetailConfig:showActorSkill(self.awItemActor, rewardDetail, self.llActorClickArea)
	elseif rewardDetail.showType == Define.ShowDetailType.KillBroadCast then
		if not self.llNewKillBroadCastItem then
			---@type GUINewKillBroadCastItem
			self.llNewKillBroadCastItem = UIHelper.newGameGUIWindow("GUINewKillBroadCastItem")
			self.llNewKillBroadCastItem.root:SetArea({ 0, 0 }, { 0, 0 }, { 0, 300 }, { 0, 120 })
			self.llNewKillBroadCastItem.root:SetHorizontalAlignment(HorizontalAlignment.Center)
			self.llNewKillBroadCastItem.root:SetVerticalAlignment(VerticalAlignment.Center)
			self.llItemShowContent:AddChildWindow(self.llNewKillBroadCastItem.root)
		end
		local cfg = CustomShopKillBroadCast.Settings[tostring(rewardDetail.id)]
		self.llNewKillBroadCastItem:showForShop(cfg)
	elseif rewardDetail.showType == Define.ShowDetailType.KillEffect then
		if not self.llNewKillEffectItem then
			---@type GUINewKillEffectItem
			self.llNewKillEffectItem = UIHelper.newGameGUIWindow("GUINewKillEffectItem")
			self.llNewKillEffectItem.root:SetArea({ 0, 0 }, { 0, 0 }, { 0, 350 }, { 0, 350 })
			self.llNewKillEffectItem.root:SetHorizontalAlignment(HorizontalAlignment.Center)
			self.llNewKillEffectItem.root:SetVerticalAlignment(VerticalAlignment.Center)
			self.llItemShowContent:AddChildWindow(self.llNewKillEffectItem.root)
		end
		local cfg = CustomShopKillEffect.Settings[tostring(rewardDetail.id)]
		self.llNewKillEffectItem:onDataChanged(cfg)
	end
	self:refreshExchangeBtn()
end

function UISpecialModeShopLayout:refreshExchangeBtn()
	local isCanBuy = true
	if not self.curSelectShopData then
		isCanBuy = false
	else
		local rewardCfg = CommonActivityConfig:getRewardById(self.curSelectShopData.rewardData.rewardId)
		local isHave = self.mgr:checkHave(rewardCfg)
		local buyCount = self.mgr:getShopBuyCount(self.curSelectShopData.id)
		if isHave then
			isCanBuy = false
		else
			local sec = self.mgr:getShopUnlockTime(self.curSelectShopData.id)
			local isLock = sec > 0
			if isLock then
				isCanBuy = false
			else
				isCanBuy = buyCount < self.curSelectShopData.limitBuy
			end
		end
		local consumeData = self.curSelectShopData.consumeData
		self.stPriceText:SetText(consumeData.count)
		self.siCurrencyIcon:SetText(PayHelper.getMoneyIcon(consumeData.moneyType))
	end
	self.btnExchangeBtn:SetEnabled(isCanBuy)
	if isCanBuy then
		self.btnExchangeBtn:SetTextColor({ 1, 1, 1, 1 })
		self.btnExchangeBtn:SetProperty("TextBorder", "true")
	else
		self.btnExchangeBtn:SetTextColor({ 95 / 255, 114 / 255, 150 / 255, 1 })
		self.btnExchangeBtn:SetProperty("TextBorder", "false")
	end
end

function UISpecialModeShopLayout:setIcon(rewardDetail)
	self.siItemIcon:SetYPosition({ 0, self.iconMovePos })
	self.siItemIcon:SetImage(rewardDetail.image)
	if rewardDetail.scale and rewardDetail.scale ~= "#" then
		UIHelper:setImageAdjustSize(self.siItemIcon, rewardDetail.image, 180, 180, rewardDetail.scale)
	else
		UIHelper:setImageAdjustSize(self.siItemIcon, rewardDetail.image, 180, 180)
	end
	LuaTimer:cancel(self.iconMoveTimer)
	self.iconMoveTimer = LuaTimer:scheduleTimer(function()
		if math.abs(self.iconMovePos) >= 15 then
			self.iconMoveGap = self.iconMoveGap * -1
		end
		self.iconMovePos = self.iconMovePos + self.iconMoveGap
		self.siItemIcon:SetYPosition({ 0, self.iconMovePos })
	end, 100)
	self:addTimer(self.iconMoveTimer)
end

---持久化数据改变
function UISpecialModeShopLayout:onCacheChanged(cache)
	self.shopItemAdapter:onCacheChanged()
	self:refreshExchangeBtn()
end

function UISpecialModeShopLayout:onTick()
	for _, item in pairs(self.moneyItems) do
		item:onTick()
	end
end

function UISpecialModeShopLayout:onHide()
	if self.mgr then
		self.mgr:registerCacheChange(nil)
	end
	RewardItemShowDetailConfig:onWindowHide(self.awItemActor)
	if self.iconMoveTimer then
		LuaTimer:cancel(self.iconMoveTimer)
		self.iconMoveTimer = nil
	end
end

return UISpecialModeShopLayout
