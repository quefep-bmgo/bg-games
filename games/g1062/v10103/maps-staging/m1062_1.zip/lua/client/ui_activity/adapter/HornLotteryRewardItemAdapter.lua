
---@class HornLotteryRewardItemAdapter : IDataAdapter
local HornLotteryRewardItemAdapter = class("HornLotteryRewardItemAdapter", IDataAdapter)

function HornLotteryRewardItemAdapter:setItemSize(width, height)
    self.width = width
    self.height = height
end

function HornLotteryRewardItemAdapter:getJsonName()
    return "GameHornLotteryRewardItem.json"
end

function HornLotteryRewardItemAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIGameHornLotteryRewardItem", false, "ui_activity")
end

function HornLotteryRewardItemAdapter:getItemWidth()
    return { 0, self.width }
end

function HornLotteryRewardItemAdapter:getItemHeight()
    return { 0, self.height }
end

function HornLotteryRewardItemAdapter:setMgr(mgr)
    self.mgr = mgr
end

---创建item
function HornLotteryRewardItemAdapter:createNewItem()
    local class = self:getWindowClass()
    local item = class.new(self:getJsonName(), self.mgr)
    item:setWidth(self:getItemWidth())
    item:setHeight(self:getItemHeight())
    return item
end

return HornLotteryRewardItemAdapter