---@class GUICreateTeamInviteItemWindow : IGUIWindow
local GUICreateTeamInviteItemWindow = class("GUICreateTeamInviteItemWindow", IGUIWindow)
---@type TeamService
local TeamService = T(Global, "TeamService")

---@private
function GUICreateTeamInviteItemWindow:ctor(...)
    self.super.ctor(self, "CreateTeamInviteItem.json", ...)
end

---@private
function GUICreateTeamInviteItemWindow:onLoad()
    self.stTip = self:getChildWindowByName("CreateTeamInviteItem-Tip", GUIType.StaticText)
    self.llHeader = self:getChildWindowByName("CreateTeamInviteItem-Header", GUIType.Layout)
    self.siSex = self:getChildWindowByName("CreateTeamInviteItem-Sex", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("CreateTeamInviteItem-Name", GUIType.StaticText)
    self.btnRejection = self:getChildWindowByName("CreateTeamApplyItem-Rejection", GUIType.Button)
    self.btnOK = self:getChildWindowByName("CreateTeamApplyItem-OK", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function GUICreateTeamInviteItemWindow:initView()
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
    self.btnRejection:SetText(Lang:getString("gui.button.rejection"))
    self.btnOK:SetText(Lang:getString("gui.button.ok"))
end

---@private
function GUICreateTeamInviteItemWindow:initEvent()
    self.btnRejection:registerEvent(GUIEvent.ButtonClick, function()
        TeamService:sendRejectionInvite(self.data.userId, self.data.teamId, self.data.regionId)
        TeamService:changeTeamInviteOperate(self.data, Define.TeamInviteOperate.Rejection)
        self:onDataChanged(self.data)
    end)
    self.btnOK:registerEvent(GUIEvent.ButtonClick, function()
        if TeamService:sendJoinTeam(self.data.teamId, self.data.token, self.data.regionId, self.data.engineVersion) then
            TeamService:changeTeamInviteOperate(self.data, Define.TeamInviteOperate.Agree)
            GUICreateTeamInviteListLayout:hide()
        end
    end)
end

---@param data TeamInviteData
function GUICreateTeamInviteItemWindow:onDataChanged(data)
    self.data = data
    if data.info then
        self.winHead:setUserInfo(data.info)
        self.siSex:SetImage(Define.SexIcon[data.info.sex] or Define.SexIcon[Define.SexType.Boy])
        self.stName:SetText(data.info.name)
    end
    self.stTip:SetText(Lang:getString(Define.GameModeName[data.gameType]))
    if data.operate == Define.TeamInviteOperate.None then
        self.btnOK:SetVisible(true)
        self.btnRejection:SetEnabled(true)
        self.btnRejection:SetText(Lang:getString("gui.button.rejection"))
        self.btnRejection:SetProperty("TextBorderColor", "0.34902 0.486275 0.592157 1")
    elseif data.operate == Define.TeamInviteOperate.Agree then
        self.btnOK:SetVisible(false)
        self.btnRejection:SetEnabled(false)
        self.btnRejection:SetText(Lang:getString("gui_friend_already_agree"))
        self.btnRejection:SetProperty("TextBorderColor", "0.8 0.8 0.8 1")
    else
        self.btnOK:SetVisible(false)
        self.btnRejection:SetEnabled(false)
        self.btnRejection:SetText(Lang:getString("gui_friend_already_refuse"))
        self.btnRejection:SetProperty("TextBorderColor", "0.8 0.8 0.8 1")
    end
end

function GUICreateTeamInviteItemWindow:onDestroy()
    if self.winHead then
        self.winHead:destroy()
    end
end

return GUICreateTeamInviteItemWindow
