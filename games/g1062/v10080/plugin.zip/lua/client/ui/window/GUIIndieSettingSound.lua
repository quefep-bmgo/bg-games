---@class GUIIndieSettingSound : IGUIWindow
local GUIIndieSettingSound = class("GUIIndieSettingSound", IGUIWindow)

local CheckTextColor = {
    Select = { 39 / 255, 45 / 255, 92 / 255, 1 },
    Normal = { 122 / 255, 121 / 255, 141 / 255, 1 },
}

function GUIIndieSettingSound:ctor()
    self.super.ctor(self, "BedWarIndieSettingSound.json")
end
function GUIIndieSettingSound:onLoad()
    self.bgSlider = self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Slider", GUIType.Slider)
    self.bgSliderText = self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Slider-Text", GUIType.StaticText)
    self.effectSlider = self:getChildWindowByName("BedWarIndieSettingSound-Effect-Slider", GUIType.Slider)
    self.effectSliderText = self:getChildWindowByName("BedWarIndieSettingSound-Effect-Slider-Text", GUIType.StaticText)
    self.bgBox = self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Open", GUIType.CheckBox)
    self.effectBox = self:getChildWindowByName("BedWarIndieSettingSound-Effect-Open", GUIType.CheckBox)

    self:getChildWindowByName("BedWarIndieSettingSound-Title", GUIType.StaticText):SetText(Lang:getString("gui.setting.sound.title"))
    self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.music.title"))
    self:getChildWindowByName("BedWarIndieSettingSound-BackGround", GUIType.StaticText):SetText(Lang:getString("gui.setting.music.volume"))
    self:getChildWindowByName("BedWarIndieSettingSound-Effect-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.effect.title"))
    self:getChildWindowByName("BedWarIndieSettingSound-Effect", GUIType.StaticText):SetText(Lang:getString("gui.setting.effect.volume"))
    self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Off-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.off"))
    self:getChildWindowByName("BedWarIndieSettingSound-BackGround-On-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.on"))
    self:getChildWindowByName("BedWarIndieSettingSound-Effect-Off-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.off"))
    self:getChildWindowByName("BedWarIndieSettingSound-Effect-On-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.on"))

    self.bgGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
    self.soundGroup = RadioBoxGroup.new(SoundConfig.switchSetting)

    self:register()
end

function GUIIndieSettingSound:register()
    self.bgGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Open", GUIType.CheckBox), function(checked)
        self:openBackGroundMusic(checked)
        local offText = self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarIndieSettingSound-BackGround-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
        offText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        SystemSettingRecord.defaultBackGroundSwitch = self.bgGroup:getCurIndex()
        onSaveSetting()
    end)
    self.bgGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Close", GUIType.CheckBox), function(checked)
        self:openBackGroundMusic(not checked)
        local offText = self:getChildWindowByName("BedWarIndieSettingSound-BackGround-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarIndieSettingSound-BackGround-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        offText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)

        SystemSettingRecord.defaultBackGroundSwitch = self.bgGroup:getCurIndex()
        onSaveSetting()
    end)

    self.soundGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingSound-Effect-Open", GUIType.CheckBox), function(checked)
        self:openEffect(checked)
        local offText = self:getChildWindowByName("BedWarIndieSettingSound-Effect-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarIndieSettingSound-Effect-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
        offText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        SystemSettingRecord.defaultEffectSwitch = self.soundGroup:getCurIndex()
        onSaveSetting()
    end)
    self.soundGroup:addCheckBox(self:getChildWindowByName("BedWarIndieSettingSound-Effect-Close", GUIType.CheckBox), function(checked)
        self:openEffect(not checked)
        local offText = self:getChildWindowByName("BedWarIndieSettingSound-Effect-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarIndieSettingSound-Effect-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        offText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
        SystemSettingRecord.defaultEffectSwitch = self.soundGroup:getCurIndex()
        onSaveSetting()
    end)

    self.bgSlider:registerEvent(GUIEvent.TouchMove, function()
        self:refreshBackGround()

    end)

    self.bgSlider:registerEvent(GUIEvent.TouchDown, function()
        self:refreshBackGround()
    end)

    self.effectSlider:registerEvent(GUIEvent.TouchMove, function()
        self:refreshEffect()
    end)

    self.effectSlider:registerEvent(GUIEvent.TouchDown, function()
        self:refreshEffect()
    end)
end

function GUIIndieSettingSound:openBackGroundMusic(open)
    SoundSystem.Instance():setBackgroundMusicSwitch(open)
end

function GUIIndieSettingSound:openEffect(open)
    ClientHelper.putBoolPrefs("SoundEffectSwitch", open)
end

function GUIIndieSettingSound:refreshEffect(progress)
    local curProgress = progress or self.effectSlider:GetProgress()
    if progress then
        self.effectSlider:SetProgress(progress)
    end

    self.effectSliderText:SetText(math.floor(curProgress * 10))
    self.effectSliderText:SetXPosition({curProgress, -25})
    self.effectSlider:SetHeaderImage(math.floor(curProgress * 10) / 10 == GUIBedWarIndieSettingLayout.defaultSetting.defaultEffectVolume
            and "set:bed_war_3_button.json image:btn_0_settings01"
            or "set:bed_war_3_button.json image:btn_0_settings")
    SoundSystem.Instance():setEffectsVolume(curProgress)
    SystemSettingRecord.defaultEffectVolume = curProgress
    onSaveSetting()
end

function GUIIndieSettingSound:refreshBackGround(progress)
    local curProgress = progress or self.bgSlider:GetProgress()
    if progress then
        self.bgSlider:SetProgress(progress)
    end
    self.bgSliderText:SetText(math.floor(curProgress * 10))
    self.bgSliderText:SetXPosition({curProgress, -25})
    self.bgSlider:SetHeaderImage(math.floor(curProgress * 10) / 10 == GUIBedWarIndieSettingLayout.defaultSetting.defaultBackGroundVolume
            and "set:bed_war_3_button.json image:btn_0_settings01"
            or "set:bed_war_3_button.json image:btn_0_settings")
    SoundSystem.Instance():setBackgroundMusicVolume(curProgress)
    SystemSettingRecord.defaultBackGroundVolume = curProgress
    onSaveSetting()
end

return GUIIndieSettingSound