---@class UIHallCreateTeamLayout : IGUILayout
local UIHallCreateTeamLayout = class("UIHallCreateTeamLayout", IGUILayout)
---@type TeamService
local TeamService = T(Global, "TeamService")
---@type FriendManager
local FriendManager = T(Global, "FriendManager")
---@type TribeManager
local TribeManager = T(Global, "TribeManager")
---@type RecentPlayManager
local RecentPlayManager = T(Global, "RecentPlayManager")
---@type FastChatConfig
local FastChatConfig = T(Global, "FastChatConfig")
---@type ChatClient
local ChatClient = T(Global, "ChatClient")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type table
local InviteStatusRecord = T(Global, "InviteStatusRecord")

---@class HallCreateTeamInviteTab
---@field window GUICheckBox
---@field type number

local InviteListType = {
    Friend = 1,
    Tribe = 2,
    RecentPlay = 3,
}

---@private
function UIHallCreateTeamLayout:ctor(parent)
    self.super.ctor(self, "HallCreateTeam.json", parent)
end

---@private
function UIHallCreateTeamLayout:onLoad()
    self.stInviteCount = self:getChildWindow("HallCreateTeam-Invite-Count", GUIType.StaticText)
    self.cbInviteTabFriend = self:getChildWindow("HallCreateTeam-Invite-Tab-Friend", GUIType.CheckBox)
    self.cbInviteTabTribe = self:getChildWindow("HallCreateTeam-Invite-Tab-Tribe", GUIType.CheckBox)
    self.cbInviteTabRecent = self:getChildWindow("HallCreateTeam-Invite-Tab-Recent", GUIType.CheckBox)
    self.llInviteList = self:getChildWindow("HallCreateTeam-Invite-List", GUIType.Layout)
    self.btnInviteRefresh = self:getChildWindow("HallCreateTeam-Invite-Refresh", GUIType.Button)
    self.btnTeamApply = self:getChildWindow("HallCreateTeam-Team-Apply", GUIType.Button)
    self.btnTeamInvite = self:getChildWindow("HallCreateTeam-Team-Invite", GUIType.Button)
    self.btnFriendApply = self:getChildWindow("HallCreateTeam-Friend-Apply", GUIType.Button)
    self.llTeamPlayers = self:getChildWindow("HallCreateTeam-Team-Players", GUIType.Layout)
    self.llTeamChat = self:getChildWindow("HallCreateTeam-Team-Chat", GUIType.Layout)
    self.llWheelChat = self:getChildWindow("HallCreateTeam-Wheel-Chat", GUIType.Layout)
    self.btnFastChat = self:getChildWindow("HallCreateTeam-Fast-Chat", GUIType.Button)
    self.llFastChatList = self:getChildWindow("HallCreateTeam-Fast-Chat-List", GUIType.Layout)
    self.btnCallTeammate = self:getChildWindow("HallCreateTeam-Call-Teammate", GUIType.Button)
    self.btnStartGame = self:getChildWindow("HallCreateTeam-Start-Game", GUIType.Button)
    self.siTeammateInvite = self:getChildWindow("HallCreateTeam-Teammate-Invite", GUIType.StaticImage)
    self.siTeammateInviteYes = self:getChildWindow("HallCreateTeam-Teammate-Invite-Yes", GUIType.StaticImage)
    self.stTeammateInviteText = self:getChildWindow("HallCreateTeam-Teammate-Invite-Text", GUIType.StaticText)
    self.llNoFriendTip = self:getChildWindow("HallCreateTeam-No-Friend-Tip", GUIType.Layout)
    self.stNoFriendTipText = self:getChildWindow("HallCreateTeam-No-Friend-Tip-Text", GUIType.StaticText)

    self:initView()
    self:initEvent()
end

---@private
function UIHallCreateTeamLayout:initView()
    self.btnTeamApply:SetVisible(false)
    self.btnTeamInvite:SetVisible(false)
    self.btnFriendApply:SetVisible(false)

    ---@type HallCreateTeamInviteTab[]
    self.inviteTabs = {}
    table.insert(self.inviteTabs, { window = self.cbInviteTabFriend, type = InviteListType.Friend })
    table.insert(self.inviteTabs, { window = self.cbInviteTabTribe, type = InviteListType.Tribe })
    table.insert(self.inviteTabs, { window = self.cbInviteTabRecent, type = InviteListType.RecentPlay })
    ---@type HallCreateTeamInviteTab
    self.curInviteTab = nil
    self:changeInviteTab(self.cbInviteTabFriend)

    self.cbInviteTabFriend:SetText(Lang:getString("gui.chat.friend"))
    self.cbInviteTabTribe:SetText(Lang:getString("gui.chat.tribe"))
    self.cbInviteTabRecent:SetText(Lang:getString("gui.chat.recent"))
    self.btnStartGame:SetText(Lang:getString("gui.create.team.start"))
    self.stTeammateInviteText:SetText(Lang:getString("gui.create.team.teammate.invite"))
    self.stNoFriendTipText:SetText(Lang:getString("gui.no.friend.tip"))
    self.llFastChatList:SetVisible(false)
    self.llNoFriendTip:SetVisible(false)
    local width = math.min(204 * (720 * self.root:GetPixelSize().x) / (1280 * self.root:GetPixelSize().y), 204)
    self.stTeammateInviteText:SetWidth({ 0, width })

    self.lvTeamChatList = IGUIListView.new("HallCreateTeam-Team-Chat-List", self.llTeamChat)
    self.lvTeamChatList:setArea({ 0, 0 }, { 0, 5 }, { 1, 0 }, { 1, -10 })

    local rollMsgWin = UIHelper.newGameGUIWindow("GUIRollMessage").root
    rollMsgWin:SetWidth({ 1, 0 })
    self.llWheelChat:AddChildWindow(rollMsgWin)

    ---@type GUIBedWarUIReturnControlWindow
    local llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.create.team.title", function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.leave.team.tip"))
                    .setRightClickListener(function()
            TeamService:sendLeaveTeam()
        end)        .show()
    end)
    self.root:AddChildWindow(llReturn.root)

    UIUtils.addRedDot(self.btnTeamApply, Define.RedDotKey.TeamApply, nil, { offset = VectorUtil.newVector2(4, -3), isParentBindVisible = true })
    UIUtils.addRedDot(self.btnFriendApply, Define.RedDotKey.FriendApply, nil, { offset = VectorUtil.newVector2(4, -3), isParentBindVisible = true })
    UIUtils.addRedDot(self.btnTeamInvite, Define.RedDotKey.TeamInvite, nil, { offset = VectorUtil.newVector2(4, -3), isParentBindVisible = true })
end

---@private
function UIHallCreateTeamLayout:initEvent()
    for _, inviteTab in pairs(self.inviteTabs) do
        inviteTab.window:registerEvent(GUIEvent.CheckStateChanged, function()
            if not inviteTab.window:GetChecked() then
                return
            end
            self:changeInviteTab(inviteTab.window)
        end)
    end
    self.btnInviteRefresh:registerEvent(GUIEvent.ButtonClick, function()
        self:refreshInviteList()
    end)
    self.btnTeamApply:registerEvent(GUIEvent.ButtonClick, function()
        GUICreateTeamApplyListLayout:showApplyList(Define.ApplyType.TeamApply)
    end)
    self.btnTeamInvite:registerEvent(GUIEvent.ButtonClick, function()
        GUICreateTeamApplyListLayout:showApplyList(Define.ApplyType.TeamInvite)
    end)
    self.btnFriendApply:registerEvent(GUIEvent.ButtonClick, function()
        UIUtils.updateRedDotCount(Define.RedDotKey.FriendApply, 0)
        GUICreateTeamApplyListLayout:showApplyList(Define.ApplyType.FriendApply)
    end)
    self.btnFastChat:registerEvent(GUIEvent.ButtonClick, function()
        self:changeChatListUI(self.llFastChatList:IsVisible())
    end)
    self.btnCallTeammate:registerEvent(GUIEvent.ButtonClick, function()
        local msg = ""
        GUICustomInputContentLayout:setTipText(Lang:getString("gui.call.teammate.tip"))
        GUICustomInputContentLayout:setContentChangeListener(function(content)
            msg = content
        end)
        CustomDialog.builder()
                    .setTitleText("gui.call.teammate.title")
                    .setContentView(GUICustomInputContentLayout)
                    .setRightClickListener(function()
            ChatClient:sendTeamInviteToGroup(msg)
        end)        .show()
    end)
    self.btnStartGame:registerEvent(GUIEvent.ButtonClick, function()
        TeamService:setStartMatch()
        TeamService:sendStartGame()
        self:updateBaseUI()
    end)
    self.siTeammateInvite:registerEvent(GUIEvent.Click, function()
        TeamService:sendTeammateInviteStatus()
    end)
    self.llWheelChat:registerEvent(GUIEvent.Click, function()
        GUIBedWarHallChatLayout:show(Define.ChatTabType.Team)
    end)
    self:registerEvent(Events.JoinTeamEvent, function()
        self:show()
        self:clearTeamChatList()
    end)
    self:registerEvent(Events.LeaveTeamEvent, function()
        self:hide()
        self:clearTeamChatList()
        TableUtil.clearTable(InviteStatusRecord)
    end)
    self:registerEvent(Events.ReceiveChatMsgEvent, function(chatId, data)
        if chatId ~= "team" then
            return
        end
        self:addTeamChatItem(data)
    end)
    self:registerEvent(Events.RejectionTeamInviteEvent, function(userId)
        InviteStatusRecord[userId] = Define.InviteStatus.Rejected
    end)
end

---只有界面打开着才监听的事件
---@private
function UIHallCreateTeamLayout:initOpenEvent()
    self:registerEvent(Events.TeammateInviteStatusEvent, function(enable)
        self.siTeammateInviteYes:SetVisible(enable)
        self:updateInviteList()
    end)
    self:registerEvent(Events.UserJoinTeamEvent, function(userId)
        self:updateTeamPlayerUI()
        self:updateInviteList()
        self:addTeamChatItem({
            type = Define.ChatMsgType.TextMsg,
            sendId = userId,
            time = os.time(),
            data = {
                content = Lang:getString("gui.user.join.team")
            },
        })
    end)
    self:registerEvent(Events.UserLeaveTeamEvent, function(userId)
        InviteStatusRecord[userId] = Define.InviteStatus.Invite
        self:updateTeamPlayerUI()
        self:updateInviteList()
        self:addTeamChatItem({
            type = Define.ChatMsgType.TextMsg,
            sendId = userId,
            time = os.time(),
            data = {
                content = Lang:getString("gui.user.leave.team")
            },
        })
    end)
    self:registerEvent(Events.FinishLoadFriendDataEvent, function()
        if self.curInviteTab and self.curInviteTab.type == InviteListType.Friend then
            self:updateInviteList()
        end
    end)
    self:registerEvent(Events.FinishLoadTribeMemberEvent, function()
        if self.curInviteTab and self.curInviteTab.type == InviteListType.Tribe then
            self:updateInviteList()
        end
    end)
    self:registerEvent(Events.FinishLoadRecentPlayEvent, function()
        if self.curInviteTab and self.curInviteTab.type == InviteListType.RecentPlay then
            self:updateInviteList()
        end
    end)
    self:registerEvent(Events.TeamOwnerChangeEvent, function()
        self:updateBaseUI()
        self:updateTeamPlayerUI()
    end)
    self:registerEvent(Events.TeamCancelStartGameEvent, function(userId)
        self:addTeamChatItem({
            type = Define.ChatMsgType.TextMsg,
            sendId = userId,
            time = os.time(),
            data = {
                content = Lang:getString("gui.team.cancel.start.game")
            },
        })
        self:updateBaseUI()
    end)
end

---@private
function UIHallCreateTeamLayout:unregisterOpenEvent()
    self:unregisterEvent(Events.TeammateInviteStatusEvent)
    self:unregisterEvent(Events.UserJoinTeamEvent)
    self:unregisterEvent(Events.UserLeaveTeamEvent)
    self:unregisterEvent(Events.FinishLoadFriendDataEvent)
    self:unregisterEvent(Events.FinishLoadTribeMemberEvent)
    self:unregisterEvent(Events.FinishLoadRecentPlayEvent)
    self:unregisterEvent(Events.TeamOwnerChangeEvent)
    self:unregisterEvent(Events.TeamCancelStartGameEvent)
end

---@private
function UIHallCreateTeamLayout:onTick(frameTime)
    ---@param item GUITeamInvitePlayerItemWindow
    for _, item in pairs(self.lvInviteList.items) do
        item:onTick()
    end
end

---@private
function UIHallCreateTeamLayout:onHide()
    self:unregisterOpenEvent()
end

---@private
function UIHallCreateTeamLayout:onShow()
    self:refreshInviteList()
    self:updateBaseUI()
    self:initOpenEvent()
    self:updateTeamPlayerUI()
    self:updateInviteList()
    self:initFastChatList()
    self:changeChatListUI(true)
    if Game.EnableIndie then
        if ClientHelper.getBoolForKey("isNewEquipment", false) and ClientHelper.getStringForKey("NewEquipmentStep", "4") == Define.NewEquipmentStep.IntoHall then
            ClientHelper.dataReport("bw_funnel_2_" .. Define.FunnelPathMap[TeamService.gameType], "")
            ClientHelper.putStringForKey("NewEquipmentStep", Define.NewEquipmentStep.CreateTeam)
        end
        if TeamService:isOwner() and ClientHelper.getStringForKey("CreateTeamFunnelStep", "0") == Define.CreateTeamFunnelStep.ClickStart then
            if ClientHelper.getBoolForKey("isNewEquipment", false) then
                ClientHelper.dataReport("bw_create_team", "")
            else
                ClientHelper.dataReport("bw_old_create_team", "")
            end
            ClientHelper.putStringForKey("CreateTeamFunnelStep", Define.CreateTeamFunnelStep.CreateTeam)
        end
    end
end

---@private
function UIHallCreateTeamLayout:updateBaseUI()
    self.siTeammateInviteYes:SetVisible(TeamService.teammateInviteSwitch)
    self.btnTeamApply:SetEnabled(TeamService:isOwner())
    self.btnStartGame:SetEnabled(TeamService:isOwner() and not TeamService.isMatching)
    self.btnCallTeammate:SetVisible(TeamService:isOwner())
    self.btnStartGame:SetProperty("TextBorderColor",
            (TeamService:isOwner() and not TeamService.isMatching) and "0.643137 0.270588 0.027451 1" or "0.3333 0.3333 0.3333 1")
end

---@private
function UIHallCreateTeamLayout:refreshInviteList()
    if self.curInviteTab.type == InviteListType.Friend then
        FriendManager.LoadFriendData()
    elseif self.curInviteTab.type == InviteListType.Tribe then
        TribeManager.LoadTribeMembers()
    elseif self.curInviteTab.type == InviteListType.RecentPlay then
        RecentPlayManager.RefreshPlayersData()
    end
end

---@private
function UIHallCreateTeamLayout:changeInviteTab(checkedTab)
    for _, inviteTab in pairs(self.inviteTabs) do
        if inviteTab.window == checkedTab then
            self.curInviteTab = inviteTab
            inviteTab.window:SetTouchable(false)
            inviteTab.window:SetChecked(true)
            inviteTab.window:SetProperty("Font", "HT20")
            inviteTab.window:SetProperty("TextRenderOffset", "0 -5")
            inviteTab.window:SetProperty("BtnTextColor", "0.152941 0.176471 0.360784 1")
        else
            inviteTab.window:SetTouchable(true)
            inviteTab.window:SetChecked(false)
            inviteTab.window:SetProperty("Font", "HT16")
            inviteTab.window:SetProperty("TextRenderOffset", "0 -2")
            inviteTab.window:SetProperty("BtnTextColor", "0.686275 0.780392 0.917647 1")
        end
    end
    self:updateInviteList()
end

---@private
function UIHallCreateTeamLayout:updateTeamPlayerUI()
    if self.lvTeamPlayers == nil then
        self.lvTeamPlayers = IGUIListView.new("HallCreateTeam-Team-Player-List", self.llTeamPlayers, nil, Orientation.Horizontal)
        self.lvTeamPlayers.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    end

    local contentW = self.llTeamPlayers:GetPixelSize().x
    local minWidth = math.min(contentW - 25 * (TeamService:getMaxMember() - 1), 150 * TeamService:getMaxMember())
    local itemSpace = math.min((contentW - minWidth) / (TeamService:getMaxMember() - 1), 100)
    if self.lvTeamPlayers:getItemCount() ~= TeamService:getMaxMember() then
        self.lvTeamPlayers:setItemSpace(itemSpace)
        self.lvTeamPlayers.root:SetWidth({ 0, math.min(150 * TeamService:getMaxMember() + itemSpace * (TeamService:getMaxMember() - 1), contentW) })
    end

    while self.lvTeamPlayers:getItemCount() ~= TeamService:getMaxMember() do
        if self.lvTeamPlayers:getItemCount() > TeamService:getMaxMember() then
            self.lvTeamPlayers:removeItem(self.lvTeamPlayers:getItemByIndex(self.lvTeamPlayers:getItemCount()))
        else
            ---@type GUIInTeamPlayerItemWindow
            local window = UIHelper.newGameGUIWindow("GUIInTeamPlayerItem")
            window:setWidth({ 0, 132 })
            self.lvTeamPlayers:addItem(window)
        end
    end
    for i = 1, TeamService:getMaxMember() do
        ---@type GUIInTeamPlayerItemWindow
        local item = self.lvTeamPlayers:getItemByIndex(i)
        if item then
            local info = TeamService:getTeammateInfo(i)
            item:onDataChanged(info)
        end
    end
end

function UIHallCreateTeamLayout:updateInviteList()
    if self.lvInviteList == nil then
        self.lvInviteList = IGUIListView.new("HallCreateTeam-Invite-Players", self.llInviteList)
        ---@type TeamInvitePlayerAdapter
        self.inviteListAdapter = UIHelper.newGameAdapter("TeamInvitePlayerAdapter")
        self.lvInviteList:setAdapter(self.inviteListAdapter)
        self.inviteListAdapter:setBottomCall(function()
            if self.curInviteTab.type == InviteListType.Friend then
                FriendManager.LoadMoreFriend()
            end
        end)
    end
    if not self.curInviteTab then
        self:changeInviteTab(self.cbInviteTabFriend)
        return
    end
    local userIds = {}
    ---@type UserInfo[]
    local userInfoList = {}
    local userCount = 0
    if self.curInviteTab.type == InviteListType.Friend then
        userIds = FriendManager.GetFriends()
        userCount = FriendManager.GetTotalFriendCount()
    elseif self.curInviteTab.type == InviteListType.Tribe then
        userIds = TribeManager.GetMembers()
        userCount = #userIds
    elseif self.curInviteTab.type == InviteListType.RecentPlay then
        userIds = RecentPlayManager.GetPlayers()
        userCount = #userIds
    end
    for _, userId in pairs(userIds) do
        if userId ~= Game:getPlatformUserId() then
            table.insert(userInfoList, UserInfoCache:GetCache(userId))
        end
    end
    table.sort(userInfoList, function(info1, info2)
        if info1.status ~= info2.status then
            return info1.status < info2.status
        end
        local record1 = InviteStatusRecord[info1.userId] or Define.InviteStatus.Invite
        local record2 = InviteStatusRecord[info2.userId] or Define.InviteStatus.Invite
        if record1 ~= record2 then
            return record1 < record2
        end
        return info1.userId < info2.userId
    end)
    self.inviteListAdapter:setData(userInfoList)
    local onlineCount = 0
    for _, userInfo in pairs(userInfoList) do
        if userInfo.status ~= Define.UserStatus.Offline then
            onlineCount = onlineCount + 1
        end
    end
    self.llNoFriendTip:SetVisible(self.curInviteTab.type == InviteListType.Friend and userCount <= 0)
    self.stInviteCount:SetText(string.format("  " .. self.curInviteTab.window:GetText() .. ": %s/%s", onlineCount, userCount))
end

---@private
function UIHallCreateTeamLayout:initFastChatList()
    if self.lvFastChatList then
        return
    end
    self.lvFastChatList = IGUIListView.new("HallCreateTeam-Fast-Chat-ListView", self.llFastChatList)
    self.lvFastChatList:setArea({ 0, 0 }, { 0, 2 }, { 1, 0 }, { 1, -4 })
    local settings = FastChatConfig:getAllCfg()
    local maxWidth = 0
    for _, setting in pairs(settings) do
        ---@type GUICreateTeamFastChatItemWindow
        local item = UIHelper.newGameGUIWindow("GUICreateTeamFastChatItem", self)
        item:onDataChanged(setting)
        self.lvFastChatList:addItem(item)
        maxWidth = math.max(item.root:GetTextWidth(), maxWidth)
    end
    local width = self.lvFastChatList:getWidth()
    if maxWidth > width then
        self.llFastChatList:SetWidth({ 0, math.min(maxWidth + 20, width * 1.2) })
    end
end

---@private
function UIHallCreateTeamLayout:changeChatListUI(chatListVisible)
    self.llTeamChat:SetVisible(chatListVisible and self.lvTeamChatList:getItemCount() > 0)
    self.llFastChatList:SetVisible(not chatListVisible)
end

---@private
---@param data ChatMsgData
function UIHallCreateTeamLayout:addTeamChatItem(data)
    if data.type == Define.ChatMsgType.None then
        return
    end
    ---@type GUICreateTeamChatItemWindow
    local item = UIHelper.newGameGUIWindow("GUICreateTeamChatItem", self.llTeamChat:GetPixelSize().x - 20)
    item:onDataChanged(data)
    self.lvTeamChatList:addItem(item)
    while item.root:GetYPosition()[2] + item.root:GetPixelSize().y > self.llTeamChat:GetPixelSize().y do
        self.lvTeamChatList:removeItem(self.lvTeamChatList:getItemByIndex(1))
    end
    self.lvTeamChatList.root:SetScrollOffset(0)
    self:changeChatListUI(not self.llFastChatList:IsVisible())
end

---@private
function UIHallCreateTeamLayout:clearTeamChatList()
    self.lvTeamChatList:clearItems()
end

return UIHallCreateTeamLayout
