---@class UIBedWarPictureFrameShopLayout : IGUILayout
local UIBedWarPictureFrameShopLayout = class("UIBedWarPictureFrameShopLayout", IGUILayout)
---@type HeadFrameConfig
local HeadFrameConfig = T(Global, "HeadFrameConfig")
---@type HeadFrameShopConfig
local HeadFrameShopConfig = T(Global, "HeadFrameShopConfig")
---@type ClientHeadFrameShop
local HeadFrameShop = T(Global, "HeadFrameShop")

---@private
function UIBedWarPictureFrameShopLayout:ctor(parent)
	self.super.ctor(self, "BedWarPictureFrameShop.json", parent)
end

---@private
function UIBedWarPictureFrameShopLayout:onLoad()
	self.llBack = self:getChildWindow("BedWarHallPictureFrameShop-Back", GUIType.Layout)
	self.siBg = self:getChildWindow("BedWarHallPictureFrameShop-Bg", GUIType.StaticImage)
	self.stTitle = self:getChildWindow("BedWarHallPictureFrameShop-Title", GUIType.StaticText)
	self.siTitleLine = self:getChildWindow("BedWarHallPictureFrameShop-Title-Line", GUIType.StaticImage)
	self.llContent = self:getChildWindow("BedWarHallPictureFrameShop-Content", GUIType.Layout)
	self.llInfo = self:getChildWindow("BedWarHallPictureFrameShop-Info", GUIType.Layout)
	self.siInfoIcon = self:getChildWindow("BedWarHallPictureFrameShop-Info-Icon", GUIType.StaticImage)
	self.siCur = self:getChildWindow("BedWarHallPictureFrameShop-Cur", GUIType.StaticImage)
	self.stName = self:getChildWindow("BedWarHallPictureFrameShop-Name", GUIType.StaticText)
	self.btnUse = self:getChildWindow("BedWarHallPictureFrameShop-Use", GUIType.Button)
	self.stWay = self:getChildWindow("BedWarHallPictureFrameShop-Way", GUIType.StaticText)
	self.btnClose = self:getChildWindow("BedWarHallPictureFrameShop-Close", GUIType.Button)
	self.siPrice = self:getChildWindow("BedWarHallPictureFrameShop-Price", GUIType.StaticImage)
	self.siMoneyIcon = self:getChildWindow("BedWarHallPictureFrameShop-Money-Icon", GUIType.StaticImage)
	self.stPriceText = self:getChildWindow("BedWarHallPictureFrameShop-Price-Text", GUIType.StaticText)
	self.siCanNotBuyBg = self:getChildWindow("BedWarHallPictureFrameShop-Can-Not-Buy", GUIType.StaticImage)
	self.stCanNotBuy = self:getChildWindow("BedWarHallPictureFrameShop-Can-Not-Buy-Text", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function UIBedWarPictureFrameShopLayout:initView()
	self.stTitle:SetText(Lang:getString("gui_picture_frame_title_text"))
	self.stCanNotBuy:SetText(Lang:getString("gui_picture_frame_can_not_buy"))

	self.lvFrameList = IGUIGridView.new("BedWarHallPictureFrameShop-Frame-List", self.llContent)
	self.lvFrameList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, -15 }, { 1, -15 })
	self.lvFrameList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvFrameList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvFrameList:setConfig(20, 20, 4)
	self.lvFrameList.root:SetClipChild(false)
	self.llContent:SetClipChild(true)
	---@type BedWarHeadItemAdapter
	self.frameAdapter = UIHelper.newGameAdapter("BedWarHeadItemAdapter")
	local itemWidth = (self.lvFrameList.root:GetPixelSize().x - 60) /  4
	self.frameAdapter:setItemSize(itemWidth, itemWidth)
	self.lvFrameList:setAdapter(self.frameAdapter)
	local configs = HeadFrameShopConfig:getShopConfigs()
	self.frameAdapter:setData(configs)

	---@type GUIBedWarHeadFrameItem
	self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHeadFrameItem")
	self.winHead.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.siCur:AddChildWindow(self.winHead.root)
	self.winHead:setCanNotBeSelect()

	self.curSelectItem = configs[1]
end

---@private
function UIBedWarPictureFrameShopLayout:initEvent()
	self.btnUse:registerEvent(GUIEvent.ButtonClick, function()
		self:onBtnClick()
	end)

	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		GUIBedWarPictureFrameShopLayout:hide()
	end)

	self.llBack:registerEvent(GUIEvent.Click, function()
		GUIBedWarPictureFrameShopLayout:hide()
	end)

	self:registerEvent(Events.HeadFrameItemSelectEvent, function(id)
		self:onSelectItemChange(id)
	end)
end

---@param id number
function UIBedWarPictureFrameShopLayout:onSelectItemChange(id)
	---@type HeadFrameShopItem
	local config = HeadFrameShopConfig:getShopConfigById(id)
	if not config then
		return
	end
	self.curSelectItem = config
	self.winHead:onDataChanged(config)
	local reward = RewardConfig.findRewardById(config.RewardId)
	self.stName:SetText(Lang:getString(reward and reward.Name or "gui_head_frame_default_name"))
	self.stWay:SetText(Lang:getString(reward and reward.Desc or "gui_head_frame_default_desc"))

	self:setBtnStatus(config)
end

function UIBedWarPictureFrameShopLayout:updateListUI()
	if self.curSelectItem then
		self:setBtnStatus(self.curSelectItem)
	end
end

---@param config HeadFrameShopItem
function UIBedWarPictureFrameShopLayout:setBtnStatus(config)
	self.siPrice:SetVisible(false)
	self.siCanNotBuyBg:SetVisible(false)
	if config.Default then
		local isEquip = HeadFrameShop.curHeadFrame == 0
		self.btnUse:SetVisible(not isEquip)
		if not isEquip then
			self.btnUse:SetText(Lang:getString("gui_equip"))
		end
		return
	end
	self.btnUse:SetVisible(config.CanBuy)
	self.btnUse:SetText(config.CanBuy and Lang:getString("gui_buy_text") or "")
	local reward = RewardConfig.findRewardById(config.RewardId)
	if not reward then
		self.btnUse:SetVisible(false)
		return
	end
	local isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
	self.siCanNotBuyBg:SetVisible(not config.CanBuy and not isOwn)
	self.stCanNotBuy:SetText(Lang:getString(config.GetWayDesc or "gui_picture_frame_can_not_buy"))
	self.siPrice:SetVisible(config.CanBuy and not isOwn)
	if isOwn then
		self.btnUse:SetVisible(reward.RewardId ~= HeadFrameShop.curHeadFrame)
		self.btnUse:SetText(Lang:getString(reward.RewardId ~= HeadFrameShop.curHeadFrame and "gui_equip" or ""))
	else
		self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(config.CoinId))
		self.stPriceText:SetText(config.Price)
	end
end

function UIBedWarPictureFrameShopLayout:onBtnClick()
	if self.curSelectItem.Default then
		local isEquip = HeadFrameShop.curHeadFrame == 0
		if not isEquip then
			HeadFrameShop:onEquipGoods(self.curSelectItem)
		end
		return
	end
	local reward = RewardConfig.findRewardById(self.curSelectItem.RewardId)
	local isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
	if isOwn then
		if reward.RewardId ~= HeadFrameShop.curHeadFrame then
			HeadFrameShop:onEquipGoods(self.curSelectItem)
		end
	else
		if self.curSelectItem.CanBuy then
			HeadFrameShop:onBuyGoods(self.curSelectItem)
		end
	end
end

function UIBedWarPictureFrameShopLayout:getCurSelectId()
	return self.curSelectItem.Id or 0
end

function UIBedWarPictureFrameShopLayout:onShow()
	if not self.firstInit then
		Events.HeadFrameItemSelectEvent:invoke(self.curSelectItem.Id)
		self.firstInit = true
	end
end

return UIBedWarPictureFrameShopLayout
