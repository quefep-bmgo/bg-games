---@class GUICommunitySharing
local UICommunitySharing = class("GUICommunitySharing", IGUILayout)

function UICommunitySharing:onLoad()
    self.tvContentText = self:getChildWindow("CommunitySharing-Content-Text", GUIType.StaticText)
    self.tvShareText = self:getChildWindow("CommunitySharing-Share-Text", GUIType.StaticText)
    self.llMain = self:getChildWindow("CommunitySharing", GUIType.Layout)
    self.btnCopy = self:getChildWindow("CommunitySharing-Copy-Btn", GUIType.Button)
    self.btnClose = self:getChildWindow("CommunitySharing-Close-Btn", GUIType.Button)

    self:initRegister()
end

function UICommunitySharing:setText(data)
    self.tvContentText:SetText(Lang:getString(data.contentLangKey))
    self.tvShareText:SetText(data.copyTextKey)
    self.btnCopy:SetText(Lang:getString("gui.copy.btn"))
end

function UICommunitySharing:initRegister()
    self.llMain:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)
    self.btnCopy:registerEvent(GUIEvent.ButtonClick, function()
        PlayerManager:getClientPlayer():sendPacket({
            pid = "GameAnalytics",
            event = "Community_Copy",
        })
        ClientHelper.onSetClipboard(self.tvShareText:GetText())
        GUIBedWarGameTips:showGameTip(Lang:getString("gui.copy.success"))
        self:hide()
    end)

    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
end

return UICommunitySharing