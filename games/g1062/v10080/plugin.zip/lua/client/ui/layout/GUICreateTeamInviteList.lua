---@class UICreateTeamInviteListLayout : IGUILayout
local UICreateTeamInviteListLayout = class("UICreateTeamInviteListLayout", IGUILayout)
---@type TeamService
local TeamService = T(Global, "TeamService")

---@private
function UICreateTeamInviteListLayout:ctor(parent)
    self.super.ctor(self, "CreateTeamInviteList.json", parent)
end

---@private
function UICreateTeamInviteListLayout:onLoad()
    self.llContent = self:getChildWindow("CreateTeamInviteList-Content", GUIType.Layout)
    self.stTitle = self:getChildWindow("CreateTeamInviteList-Title", GUIType.StaticText)
    self.siClose = self:getChildWindow("CreateTeamInviteList-Close", GUIType.StaticImage)
    self.siNotTip = self:getChildWindow("CreateTeamInviteList-Not-Tip", GUIType.StaticImage)
    self.siNotTipYes = self:getChildWindow("CreateTeamInviteList-Not-Tip-Yes", GUIType.StaticImage)
    self.stNotTipText = self:getChildWindow("CreateTeamInviteList-Not-Tip-Text", GUIType.StaticText)
    self.siNotReceive = self:getChildWindow("CreateTeamInviteList-Not-Receive", GUIType.StaticImage)
    self.siNotReceiveYes = self:getChildWindow("CreateTeamInviteList-Not-Receive-Yes", GUIType.StaticImage)
    self.stNotReceiveText = self:getChildWindow("CreateTeamInviteList-Not-Receive-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UICreateTeamInviteListLayout:initView()
    self.stTitle:SetText(Lang:getString("gui.team.invite.list"))
    self.stNotTipText:SetText(Lang:getString("gui.not.tip.team.invite"))
    self.stNotReceiveText:SetText(Lang:getString("gui.not.receive.team.invite"))

    self.lvInviteList = IGUIListView.new("CreateTeamInviteList-List", self.llContent)
    self.lvInviteList:setArea({ 0, 22 }, { 0, 76 }, { 1, -44 }, { 1, -165 })
    self.lvInviteList:setItemSpace(8)
    ---@type CreateTeamInviteAdapter
    self.inviteListAdapter = UIHelper.newGameAdapter("CreateTeamInviteAdapter")
    self.lvInviteList:setAdapter(self.inviteListAdapter)
end

---@private
function UICreateTeamInviteListLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)
    self.siNotTip:registerEvent(GUIEvent.Click, function()
        self.siNotTipYes:SetVisible(not self.siNotTipYes:IsVisible())
        TeamService:setNotTipInvite(self.siNotTipYes:IsVisible())
    end)
    self.siNotReceive:registerEvent(GUIEvent.Click, function()
        self.siNotReceiveYes:SetVisible(not self.siNotReceiveYes:IsVisible())
        TeamService:setNotReceiveInvite(self.siNotReceiveYes:IsVisible())
    end)
    self:registerEvent(Events.ReceiveTeamInviteEvent, function()
        if TeamService:isInTeam(Game:getPlatformUserId()) then
            return
        end
        if GUIHallCreateTeamLayout:isShow() then
            return
        end
        if self:isShow() then
            self:hide()
        end
        self:show()
    end)
end

function UICreateTeamInviteListLayout:isShowAnim()
    return false
end

function UICreateTeamInviteListLayout:onShow()
    local inviteList = TeamService:getInviteList(true)
    self.inviteListAdapter:setData(inviteList)
    self.inviteListAdapter:setScrollOffset(0)
    LuaTimer:cancel(self.showTimer)
    self.showTimer = LuaTimer:schedule(function()
        self:hide()
    end, 30000)
end

return UICreateTeamInviteListLayout
