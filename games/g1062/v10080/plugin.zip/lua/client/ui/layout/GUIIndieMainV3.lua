---@class ButtonData
---@field icon string
---@field text string
---@field textColor table
---@field uiJson string
---@field rdKey string

---@type ButtonData[]
local LeftButtonMap = {
    {
        icon = "set:bed_war_3_icon.json image:img_0_shop",
        text = "gui_str_app_shop_shop",
        textColor = { 240 / 255, 164 / 255, 40 / 255, 1 },
        uiJson = "BedWarStore.json",
        reportKey = Define.ReportIndieMainButtonClick.Shop,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_performance",
        text = "bed.war.custom.shop",
        textColor = { 240 / 255, 164 / 255, 40 / 255, 1 },
        uiJson = "BedWarCustomShop.json",
        reportKey = Define.ReportIndieMainButtonClick.Skin,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_sweepstakes",
        text = "gui.main.activity.txt",
        textColor = { 240 / 255, 164 / 255, 40 / 255, 1 },
        uiJson = "GameActivityLayout.json",
        rdKey = Define.RedDotKey.GameActivity,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_avatar",
        text = "gui.head.frame.shop.txt",
        textColor = { 240 / 255, 164 / 255, 40 / 255, 1 },
        uiJson = "BedWarPictureFrameShop.json",
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_symbols",
        text = "gui.game.rule.txt",
        uiJson = "BedWarRune.json",
        reportKey = Define.ReportIndieMainButtonClick.Rune,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_treasure_chest",
        text = "gui.box.chest.txt",
        uiJson = "BoxLottery.json",
        reportKey = Define.ReportIndieMainButtonClick.Chest,
    }
}

---@type ButtonData[]
local RightButtonMap = {
    {
        icon = "set:bed_war_3_icon.json image:img_0_announcement",
        uiJson = "VersionNotice.json",
        rdKey = Define.RedDotKey.VersionNotice,
        reportKey = Define.ReportIndieMainButtonClick.VersionNotice,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_sign_in",
        uiJson = "BedWarDailySignIn.json",
        rdKey = Define.RedDotKey.CheckIn,
        reportKey = Define.ReportIndieMainButtonClick.SignIn,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_free",
        uiJson = "BedWarActivity.json",
        rdKey = Define.RedDotKey.OldActivity,
        reportKey = Define.ReportIndieMainButtonClick.OldActivity,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_the_challenge",
        uiJson = "TreasureChallenge.json",
        rdKey = Define.RedDotKey.Challenge,
        reportKey = Define.ReportIndieMainButtonClick.Challenge,
    },
    {
        icon = "set:bed_war_3_icon.json image:img_0_leaderboard",
        uiJson = "BedWarSeasonRank.json",
        reportKey = Define.ReportIndieMainButtonClick.SeasonRank,
    }
}

local custom_max_row = 2
local custom_max_column = 2
---@type ActivityPageData[]
local pageConfigs = require "common.config.ActivityPageConfig"

---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type TeamService
local TeamService = T(Global, "TeamService")

---@class UIIndieMainV3Layout : IGUILayout
local UIIndieMainV3Layout = class("UIIndieMainV3Layout", IGUILayout)

---@private
function UIIndieMainV3Layout:ctor(parent)
    self.super.ctor(self, "IndieMainV3.json", parent)
end

---@private
function UIIndieMainV3Layout:onLoad()
    self.siBg = self:getChildWindow("IndieMainV3-Bg", GUIType.StaticImage)
    self.llControl = self:getChildWindow("IndieMainV3-Control", GUIType.Layout)
    self.siToolbar = self:getChildWindow("IndieMainV3-Toolbar", GUIType.StaticImage)
    self.btnSetting = self:getChildWindow("IndieMainV3-Setting", GUIType.Button)
    self.btnSkin = self:getChildWindow("IndieMainV3-Skin", GUIType.Button)
    self.btnFriend = self:getChildWindow("IndieMainV3-Friend", GUIType.Button)
    self.btnMail = self:getChildWindow("IndieMainV3-Mail", GUIType.Button)
    self.siCube = self:getChildWindow("IndieMainV3-Cube", GUIType.StaticImage)
    self.btnCubeAdd = self:getChildWindow("IndieMainV3-Cube-Add", GUIType.Button)
    self.stCubeNum = self:getChildWindow("IndieMainV3-Cube-Num", GUIType.StaticText)
    self.siKey = self:getChildWindow("IndieMainV3-Key", GUIType.StaticImage)
    self.btnKeyAdd = self:getChildWindow("IndieMainV3-Key-Add", GUIType.Button)
    self.stKeyNum = self:getChildWindow("IndieMainV3-Key-Num", GUIType.StaticText)
    self.btnRecharge = self:getChildWindow("IndieMainV3-Recharge", GUIType.Button)
    self.stRechargeText = self:getChildWindow("IndieMainV3-Recharge-Text", GUIType.StaticText)
    self.llLeftButton = self:getChildWindow("IndieMainV3-Left-Button", GUIType.Layout)
    self.llRightButton = self:getChildWindow("IndieMainV3-Right-Button", GUIType.Layout)
    self.llRightButtonLayout = self:getChildWindow("IndieMainV3-Right-Button-Layout", GUIType.Layout)
    self.llActivityLayout = self:getChildWindow("IndieMainV3-Activity-Layout", GUIType.Layout)
    self.llPlayerInfo = self:getChildWindow("IndieMainV3-Player-Info", GUIType.Layout)
    self.stPlayerName = self:getChildWindow("IndieMainV3-Player-Name", GUIType.StaticText)
    self.siVip = self:getChildWindow("IndieMainV3-Vip", GUIType.StaticImage)
    self.stLevel = self:getChildWindow("IndieMainV3-Level", GUIType.StaticText)
    self.llPlayerHead = self:getChildWindow("IndieMainV3-Player-Head", GUIType.Layout)
    self.llPrivilegeList = self:getChildWindow("IndieMainV3-Privilege-List", GUIType.Layout)
    self.siStoreGoods = self:getChildWindow("IndieMainV3-Store-Goods", GUIType.StaticImage)
    self.awPlayer = self:getChildWindow("IndieMainV3-Player", GUIType.ActorWindow)
    self.awPet = self:getChildWindow("IndieMainV3-Pet", GUIType.ActorWindow)
    self.llHorn = self:getChildWindow("IndieMainV3-Horn", GUIType.Layout)
    self.siHornTextBg = self:getChildWindow("IndieMainV3-Horn-Text-Bg", GUIType.StaticImage)
    self.stHornText = self:getChildWindow("IndieMainV3-Horn-Text", GUIType.StaticText)
    self.llHornEffect = self:getChildWindow("IndieMainV3-Horn-Effect", GUIType.Layout)
    self.llMessageLayout = self:getChildWindow("IndieMainV3-Message-Layout", GUIType.Layout)
    self.btnTeamInvite = self:getChildWindow("IndieMainV3-Team-Invite", GUIType.Button)
    self.llMode = self:getChildWindow("IndieMainV3-Mode", GUIType.Layout)
    self.btnStartGame = self:getChildWindow("IndieMainV3-StartGame", GUIType.Button)
    self.btnPacket = self:getChildWindow("IndieMainV3-Packet", GUIType.Button)
    self.llModeSelect = self:getChildWindow("IndieMainV3-Mode-Select", GUIType.Layout)
    self.stModeSelectText = self:getChildWindow("IndieMainV3-Mode-Select-Text", GUIType.StaticText)
    self.siModeSelectIcon = self:getChildWindow("IndieMainV3-Mode-Select-Icon", GUIType.StaticImage)
    self.llSelectLayout = self:getChildWindow("IndieMainV3-Select-Layout", GUIType.Layout)
    self.llModeSelectClose = self:getChildWindow("IndieMainV3-Mode-Select-Close", GUIType.Layout)
    self.stClassicMode = self:getChildWindow("IndieMainV3-ClassicMode", GUIType.StaticText)
    self.stDoubleMode = self:getChildWindow("IndieMainV3-DoubleMode", GUIType.StaticText)
    self.stSoloMode = self:getChildWindow("IndieMainV3-SoloMode", GUIType.StaticText)
    ---@type GUIBedWarHead
    self.headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
    self.headItem:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.headItem:setReportKey(Define.ReportIndieMainButtonClick.Head)
    self.llPlayerHead:AddChildWindow(self.headItem.root)

    self.btnRecharge:SetVisible(false)

    local rollMsgWin = UIHelper.newGameGUIWindow("GUIRollMessage").root
    rollMsgWin:SetWidth({ 1, 0 })
    self.llMessageLayout:AddChildWindow(rollMsgWin)

    self.leftButtonList = {}
    for _, buttonData in pairs(LeftButtonMap) do
        local window = self:addButton(buttonData, self.llLeftButton)
        if buttonData.uiJson == "GameActivityLayout.json" then
            self.btnGameActivity = window
        end
    end
    self:refreshButtonLayout(self.llLeftButton)
    for _, buttonData in pairs(RightButtonMap) do
        self:addButton(buttonData, self.llRightButtonLayout)
    end
    self:refreshButtonLayout(self.llRightButtonLayout)
    self.llRightButton:SetHeight({ 0, self.llRightButtonLayout:GetPixelSize().y + 20 })

    self.btnTriggerGift = self:getChildWindow("IndieMainV3-Trigger-Gift", GUIType.Button)
    Plugins.CallTargetPluginFunc("trigger_gift", "setOpenButton", self.btnTriggerGift)
    --UIUtils.addRedDot(self.btnTriggerGift, Define.RedDotKey.TriggerGift, nil, { offset = VectorUtil.newVector2(-6, 14) })

    ---@type GUIWindow[]
    self.privilegeItemList = {}
    for index, goods in pairs(StoreConfig:getPrivilegeGoods()) do
        local window = GUIManager:createGUIWindow(GUIType.StaticImage, "IndieMainV3-Privilege-" .. index)
        window:SetImage(goods.Image)
        window:SetProperty("Material", "CullBackLinear")
        window:SetArea({ 0, 34 * (index - 1) }, { 0, 0 }, { 0, 32 }, { 0, 32 })
        self.llPrivilegeList:AddChildWindow(window)
        self.privilegeItemList[goods.ItemId] = window
    end

    self:initView()
    self:initEvent()
    self:initActivityPage()
    self:onUpdatePlayerModel()
    self:selectMode("g1008", self.stClassicMode:GetText())
    self:showActivityBtn(false)
end

function UIIndieMainV3Layout:onTick(frameTime)
    local count = PlayerWallet.getMoneyByCoinId(Define.Money.DIAMOND)
    self.stCubeNum:SetText(tostring(count))

    for privilegeId, window in pairs(self.privilegeItemList) do
        window:SetGrayMask(Privilege.getPrivilegeTime(privilegeId) <= 0)
    end
end

---@param layout GUIWindow
function UIIndieMainV3Layout:refreshButtonLayout(layout)
    local count = layout:GetChildCount()
    local index = 0
    local totalHeight = 0
    for i = 1, count do
        local window = layout:GetChildByIndex(i - 1)
        if window:IsVisible() then
            index = index + 1
            window:SetYPosition({ 0, 52 * (index - 1) })
        end
        totalHeight = 52 * (index - 1) + window:GetPixelSize().y
    end
    layout:SetHeight({ 0, totalHeight })
end

---@param data ButtonData
---@param layout GUIWindow
function UIIndieMainV3Layout:addButton(data, layout)
    ---@type GUIIndieMainV3ButtonWindow
    local buttonItem = UIHelper.newGameGUIWindow("GUIIndieMainV3Button")
    buttonItem:onDataChanged(data)
    layout:AddChildWindow(buttonItem.root)
    return buttonItem.root
end

---@private
function UIIndieMainV3Layout:initView()
    self.stRechargeText:SetText(Lang:getString("gui.sumrecharge.txt"))
    self.stHornText:SetText(Lang:getString("gui_bed_war_license_title"))
    self.stClassicMode:SetText(Lang:getString("gui.mode.classic"))
    self.stDoubleMode:SetText(Lang:getString("gui.mode.double"))
    self.stSoloMode:SetText(Lang:getString("gui.mode.solo"))
    self.btnStartGame:SetText(Lang:getString("gui.create.team.start"))

    UIUtils.addRedDot(self.btnTeamInvite, Define.RedDotKey.TeamInvite, nil, { offset = VectorUtil.newVector2(4, -3), isParentBindVisible = true })
    UIUtils.addRedDot(self.btnFriend, Define.RedDotKey.FriendApply, nil, { offset = VectorUtil.newVector2(4, -3) })
    UIUtils.addRedDot(self.llMessageLayout, Define.RedDotKey.ChatMsgTab .. "friend", nil, { offset = VectorUtil.newVector2(4, -3) })
    UIUtils.addRedDot(self.btnStartGame, Define.RedDotKey.ClassicMode)
    UIUtils.addRedDot(self.siHornTextBg, Define.RedDotKey.License, nil, { offset = VectorUtil.newVector2(4, -3) })
    UIUtils.updateRedDotCount(Define.RedDotKey.License, 1)
end

function UIIndieMainV3Layout:initActivityPage()
    if #pageConfigs == 0 then
        self.llActivityLayout:SetVisible(false)
    else
        local itemWidth = self.llActivityLayout:GetPixelSize().x
        for index, pageConfig in pairs(pageConfigs) do
            local window = GUIManager:createGUIWindow(GUIType.StaticImage, "IndieMainV3-Activity-Image-" .. index)
            local imageset = pageConfig.imageset
            local image = "set:" .. imageset .. ".json image:publicity"
            UIHelper:setImageAdjustSize(window, UIUtils.GetLangImage(image), 9999, 9999)
            window:registerEvent(GUIEvent.Click, function()
                SoundUtil.clickUI()
                CEvents.ShowPluginLayoutEvent:invoke(pageConfig.uiJson, pageConfig.uiParams)
                ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Activity)
            end)
            window:setMaterial(20001)
            window:SetVerticalAlignment(VerticalAlignment.Bottom)
            pageConfig.window = window
            self.llActivityLayout:AddChildWindow(window)
        end
        self:selectActivityPage(1)
        LuaTimer:scheduleTimer(function()
            self:selectActivityPage(self.cur_page_index % #pageConfigs + 1)
        end, 5000)
    end
end

function UIIndieMainV3Layout:selectActivityPage(page_index)
    self.cur_page_index = page_index
    for index, pageConfig in pairs(pageConfigs) do
        pageConfig.window:SetVisible(index == page_index)
    end
end

---@private
function UIIndieMainV3Layout:initEvent()
    self.btnSetting:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        GUIBedWarIndieSettingLayout:show()
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Setting)
    end)
    self.btnSkin:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_DRESS)
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Dress)
    end)
    self.btnFriend:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        GUIFriends:show()
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Friend)
    end)
    self.btnMail:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_EMAIL)
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Mail)
    end)
    self.btnCubeAdd:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ClientHelper.onRecharge(1, "indie_main")
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.CubeAdd)
    end)
    self.btnKeyAdd:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        GUIStore:show(StoreId.CubeStore, 8)
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.KeyAdd)
    end)
    self.btnRecharge:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ReportUtil.reportClickFirstRecharge(GUISumRechargeLayout.currentId)
        GUISumRechargeLayout:show()
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Recharge)
    end)
    self.btnTeamInvite:registerEvent(GUIEvent.ButtonClick, function()
        GUICreateTeamInviteListLayout:show()
    end)
    self.btnStartGame:registerEvent(GUIEvent.ButtonClick, function()
        self:startGame()
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.StartGame)
    end)
    self.btnPacket:registerEvent(GUIEvent.ButtonClick, function()
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.ItemPacket)
        GUIPropPacket:openPacket(true)
    end)
    self.llHorn:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        GUILicense:show()
        CommonPacketSender:sendPlayerOpenLicense()
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Horn)
    end)
    local item_wight = 1 / custom_max_column
    local item_height = 1 / custom_max_row
    for row = 1, custom_max_row do
        for column = 1, custom_max_column do
            local window = GUIManager:createGUIWindow(GUIType.Layout, "IndieMainV3-Store-Goods-" .. row .. "-" .. column)
            window:SetArea({ item_wight * (column - 1), 0 }, { item_height * (row - 1), 0 }, { item_wight, 0 }, { item_height, 0 })
            self.siStoreGoods:AddChildWindow(window)
            window:registerEvent(GUIEvent.Click, function()
                self:clickCustomGoods(row, column)
            end)
        end
    end
    self.llMessageLayout:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        GUIBedWarHallChatLayout:show(Define.ChatTabType.Lang)
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Chat)
    end)
    self.stModeSelectText:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self.llSelectLayout:SetVisible(true)
        self.siModeSelectIcon:SetProperty("Rotate", "0")
    end)
    self.stClassicMode:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self:selectMode("g1008", self.stClassicMode:GetText())
        ClientReportEvent.click_Mode_button(Define.ReportIndieModeButtonClick.Classic)
    end)
    self.stDoubleMode:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self:selectMode("g1062", self.stDoubleMode:GetText())
        ClientReportEvent.click_Mode_button(Define.ReportIndieModeButtonClick.Double)
    end)
    self.stSoloMode:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self:selectMode("g1061", self.stSoloMode:GetText())
        ClientReportEvent.click_Mode_button(Define.ReportIndieModeButtonClick.Solo)
    end)
    self.llModeSelectClose:registerEvent(GUIEvent.Click, function()
        self.llSelectLayout:SetVisible(false)
        self.siModeSelectIcon:SetProperty("Rotate", "180")
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.ModeSelect)
    end)
    self.llPrivilegeList:registerEvent(GUIEvent.Click, function()
        GUIStore:show(StoreId.CubeStore, 9)
        ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick.Privilege)
    end)

    self:registerDataCallBack("HallInfo", function(data)
        self:onHallInfoUpdate(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("ShowSumRecharge", function(data)
        local id = data:getParam("Id")
        local config = SumRechargeConfig:getSumRecharge(id)
        if config then
            self.btnRecharge:SetVisible(true)
        else
            self.btnRecharge:SetVisible(false)
        end
    end, DataBuilderProcessor)

    self:registerEvent(CEvents.GameActionTriggerEvent, function(_type, params)
        if _type == CDefine.GameActionType.GAME_ACTION_REFRESH_DRESS then
            self:onUpdatePlayerModel()
        end
    end)

    self:registerEvent(CEvents.HideRechargeEvent, function()
        self.btnCubeAdd:SetVisible(false)
    end)
end

function UIIndieMainV3Layout:clickCustomGoods(row, column)
    GUICustomShop:show(true)
    local seasonConfig = LicenseConfig:getSeasonConfigBySeason(GUILicense.seasonDate)
    if not seasonConfig then
        return
    end
    local showMap = seasonConfig.ShowCustomGoods
    local index = (row - 1) * custom_max_column + column
    local goodsId = showMap[index]
    GUICustomShop:openCustomShopByGoodsId(goodsId)
    ClientReportEvent.click_main_button(Define.ReportIndieMainButtonClick["Helmets" .. tostring(index)])
end

---@param seasonDate number
function UIIndieMainV3Layout:onSeasonUpdate(seasonDate)
    local seasonConfig = LicenseConfig:getSeasonConfigBySeason(seasonDate)
    if seasonConfig then
        self.siStoreGoods:SetImage(seasonConfig.ShowCustomImage)
        self.llHornEffect:SetEffectName(seasonConfig.ShowHornEffect)
    end
end

function UIIndieMainV3Layout:onUpdatePlayerModel()
    self.awPlayer:SetActorByUserId(Game:getPlatformUserId(), 0, true)
end

function UIIndieMainV3Layout:onHallInfoUpdate(data)
    local level = data:getNumberParam("level")
    local key = data:getNumberParam("key")
    self.stLevel:SetText("LV." .. tostring(level))
    self.stKeyNum:SetText(tostring(key))

    local user = UserManager.Instance():findUser(PlayerManager:getClientPlayer().userId)
    self.stPlayerName:SetText(user.userName)
    self.stPlayerName:SetWidth({ 0, self.stPlayerName:GetTextWidth() })

    self:onUserUpdate(Game:getPlatformUserId())
end

function UIIndieMainV3Layout:onUserUpdate(userId)
    local userInfo = UserInfoCache:GetCache(userId)
    if not userInfo or not userInfo.picUrl then
        LuaTimer:schedule(function()
            self:onUserUpdate(userId)
        end, 50)
        return
    end

    self.headItem:setUserInfo(userInfo)
    UIHelper:setImageAdjustSize(self.siVip, Define.VipIcon[userInfo.vip] or "",
            999, 28)
end

function UIIndieMainV3Layout:selectMode(gameType, text)
    self.cur_game_type = gameType
    self.llSelectLayout:SetVisible(false)
    self.siModeSelectIcon:SetProperty("Rotate", "180")
    self.stModeSelectText:SetText(text)
end

function UIIndieMainV3Layout:startGame()
    if self.cur_game_type == "g1061" then
        if GUIBedWarHallToolBar:getPlayerLevel() >= 3 then
            self.btnStartGame:SetEnabled(false)
            GamePacketSender:sendBedWarStartGame("g1061")
            Game:resetGame("g1061")
            LuaTimer:cancel(self.lockKey or 0)
            self.lockKey = LuaTimer:schedule(function()
                self.btnStartGame:SetEnabled(true)
            end, 5000)
        else
            GUICustomDialog:showLevelLimit(3)
        end
    else
        TeamService:sendCreateTeam(self.cur_game_type)
    end
end

function UIIndieMainV3Layout:showActivityBtn(isShow)
    if self.btnGameActivity:IsVisible() ~= isShow then
        self.btnGameActivity:SetVisible(isShow)
        self:refreshButtonLayout(self.llLeftButton)
    end
end

function UIIndieMainV3Layout:isMainControl()
    return true
end

return UIIndieMainV3Layout
