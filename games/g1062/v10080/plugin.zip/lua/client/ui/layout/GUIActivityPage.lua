---@class UIActivityPageLayout : IGUILayout
local UIActivityPageLayout = class("UIActivityPageLayout", IGUILayout)
---@type ActivityPageData[]
local configs = {}
for _, pageData in pairs(require "common.config.ActivityPageConfig") do
    table.insert(configs, pageData)
end

if #configs == 0 then
    return false
end

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

function UIActivityPageLayout:ctor()
    self.super.ctor(self, "ActivityPage.json")
end

function UIActivityPageLayout:onLoad()
    self.siBG = self:getChildWindow("ActivityPage-BG", GUIType.StaticImage)
    self.stText = self:getChildWindow("ActivityPage-Text", GUIType.StaticImage)
    self.stText1 = self:getChildWindow("ActivityPage-Text-1", GUIType.StaticImage)
    self.btnClose = self:getChildWindow("ActivityPage-Close", GUIType.Button)
    self.btnOpen = self:getChildWindow("ActivityPage-Open", GUIType.Button)
    self.stOpenText = self:getChildWindow("ActivityPage-Open-Text", GUIType.StaticText)
    self:initView()
end

function UIActivityPageLayout:initView()
    self.siBG:registerEvent(GUIEvent.Click, function()
        if #configs > 0 then
            CEvents.ShowPluginLayoutEvent:invoke(self.cur_page.uiJson, self.cur_page.uiParams)
        else
            GUIManager:addShowQueue(GUIManager:getLayout(self.cur_page.uiJson), 2, { self.cur_page.uiParams })
        end
        self:nextPage()
        ClientReportEvent.click_activity_page_button(Define.ReportIndieActivityButtonClick.Open)
    end)

    self.btnOpen:registerEvent(GUIEvent.ButtonClick, function()
        if #configs > 0 then
            CEvents.ShowPluginLayoutEvent:invoke(self.cur_page.uiJson, self.cur_page.uiParams)
        else
            GUIManager:addShowQueue(GUIManager:getLayout(self.cur_page.uiJson), 2, { self.cur_page.uiParams })
        end
        self:nextPage()
        ClientReportEvent.click_activity_page_button(Define.ReportIndieActivityButtonClick.Open)
    end)

    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:nextPage()
        ClientReportEvent.click_activity_page_button(Define.ReportIndieActivityButtonClick.Close)
    end)
end

function UIActivityPageLayout:nextPage()
    if #configs == 0 then
        self:hide()
        return
    end
    self.cur_page = configs[1]
    table.remove(configs, 1)

    self.btnOpen:SetVisible(false)
    self.siBG:SetTouchable(true)

    UIHelper:setImageAdjustSize(self.siBG, "set:" .. self.cur_page.imageset .. ".json image:bg", 9999, 9999)
    UIHelper:setImageAdjustSize(self.stText, UIUtils.GetLangImage("set:" .. self.cur_page.imageset .. ".json image:text"), 9999, 9999)
    UIHelper:setImageAdjustSize(self.stText1, UIUtils.GetLangImage("set:" .. self.cur_page.imageset .. ".json image:text1"), 9999, 9999)
    self.stText:SetVisible(self.stText:GetHeight()[1] == 0)
    self.stText:SetXPosition({ 0, self.cur_page.textOffset[1] })
    self.stText:SetYPosition({ 0, self.cur_page.textOffset[2] })
    self.stText1:SetVisible(self.stText1:GetHeight()[1] == 0)
    self.stText1:SetXPosition({ 0, self.cur_page.text1Offset[1] })
    self.stText1:SetYPosition({ 0, self.cur_page.text1Offset[2] })
    self.btnClose:SetArea({ 0, self.cur_page.closeOffset[1] }, { 0, self.cur_page.closeOffset[2] }, { 0, 30 }, { 0, 30 })
    self.siBG:SetXPosition({ 0, self.cur_page.bgOffset[1] })
    self.siBG:SetYPosition({ 0, self.cur_page.bgOffset[2] })
    if self.cur_page.openLang ~= "#" then
        self.btnOpen:SetXPosition({ 0, self.cur_page.openOffset[1] })
        self.btnOpen:SetYPosition({ 0, self.cur_page.openOffset[2] })
        self.stOpenText:SetText(Lang:getString(self.cur_page.openLang))
        self.btnOpen:SetVisible(true)
        self.siBG:SetTouchable(false)
    end
end

function UIActivityPageLayout:onShow()
    self:nextPage()
end

return UIActivityPageLayout
