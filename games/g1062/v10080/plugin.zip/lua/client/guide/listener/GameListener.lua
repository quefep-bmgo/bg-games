GameListener = {}

---@type GuideUtil
local GuideUtil = T(Global, "GuideUtil")

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
    BaseListener.registerCallBack(CEvents.GameMainTickEvent, function()
        local players = PlayerManager:getPlayers()
        for _, player in pairs(players) do
            player:onUpdate()
        end
        if GuideUtil and GuideUtil["onTick"] then
            GuideUtil:onTick()
        end
    end)

    CommonDataEvents:registerCallBack("BedWarToolBarVisible", function(data)
        Events.BedWarToolBarEvent:invoke(data)
    end, DataBuilderProcessor)
end

function GameListener.onGameReady()
    BaseGameConfig:init()
    GameConfig:loadConfig()
    --CustomSceneConfig:gameReady()
    require "ui.GUIFactory"
    if Game.isOpenGM and Game:isOpenGM() then
        require "game.data.GMBedWar"
        require "common.data.GMBedWarCommon"
    end
    ClientHelper.putFloatPrefs("BowPullingSpeedMultiplier", GameConfig.bowSpeedMultiplier)
    ClientHelper.putFloatPrefs("BowPullingFOVMultiplier", GameConfig.bowFOVMultiplier)
end

