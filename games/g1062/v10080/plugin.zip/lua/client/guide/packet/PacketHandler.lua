---@type CBasePlayer
local handler = T(Global, "PacketHandlers")
---@type ClientGuideManager
local GuideManager = T(Global, "GuideManager")
---@type GuideUtil
local GuideUtil = T(Global, "GuideUtil")

function handler:SyncGuideNodeId(packet)
    GuideManager:buildGuideList(packet.guideNodeId)
end

function handler:onPlayerKillGuideAI(packet)
    LogUtil.log("[handler] onPlayerKillGuideAI" , LogUtil.LogLevel.Info)
    GuideUtil:onPlayerKillGuideAI()
end

function handler:doClientFireBombSkill(packet)
    EngineWorld:addSimpleEffect("explosion.effect", packet.pos, packet.yaw, 1000, 0, 1)
    LuaTimer:scheduleTimer(function()
        GuideUtil:breakLocalBed()
    end, 100, 1)
end

function handler:onGuideEnd(packet)
    GuideUtil:onGuideEnd()
end