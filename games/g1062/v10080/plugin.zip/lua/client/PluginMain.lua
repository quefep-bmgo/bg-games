require "common.web.BedWarWeb"
if Platform.isWindow() then
    require "PCKeyboard"
end

---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
    if BaseMain:getGameType() == "g1046" then
        require "hall.BedWarClient"
    elseif BaseMain:getGameType() == "g1063" then
        require "guide.BedWarClient"
    else
        require "game.BedWarClient"
    end
    BedWarClient.onGameInit()
    local deviation = 3 -- 辉光的宽度
    local intensity = 2.6 --- 辉光的强度
    local saturation = 1.0 --  辉光颜色对场景的影响 (0-1.0)
    Blockman.Instance():setBlockBloomOption(deviation, intensity, saturation)
    -- 起床因为一些特殊原因禁掉了场景辉光，方块辉光不受影响
    Blockman.Instance():setBloomEnable(false)
    ClientHelper.putStringPrefs("RechargeGameType", "g1008")
    ClientHelper.putBoolPrefs("IsShowItemDurability", true)

    local oldRecharge = ClientHelper.onRecharge
    function ClientHelper.onRecharge(type, reportKey)
        ReportEvent.recharge_open(reportKey or "sum_recharge")
        PlayerManager:getClientPlayer():sendPacket({
            pid = "RechargeReport",
            reportKey = reportKey
        })
        oldRecharge(type)
    end
end)
