local handler = class("CommonPacketHandler", EventObservable)

function handler:init()
    self:registerDataCallBack("UseActionSuccess", function(data)
        self.onOtherPlayerUseAction(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("MoneyCount", function(data)
        local type = data:getNumberParam("type")
        local count = data:getNumberParam("count")
        PlayerWallet:setMoneyCount(type, count)
    end, DataBuilderProcessor)

    self:registerDataCallBack("FakeDiamondsNum", function(data)
        local num = data:getNumberParam("num")
        PlayerWallet:setMoneyCount(Define.Money.FAKE_DIAMOND, num)
    end, DataBuilderProcessor)

    self:registerDataCallBack("TransformDress", function(data)
        self.onTransformOldDress(data)
    end, JsonBuilderProcessor)

    self:registerDataCallBack("BedWarShowReward", function(data)
        self.onShowReward(data)
    end, JsonBuilderProcessor)
end

function handler.onOtherPlayerUseAction(data)
    local serverId = data:getNumberParam("serverId")
    local actionId = data:getNumberParam("actionId")
    local otherPlayer = PlayerManager:getPlayerByServerId(serverId)

    local entityRender = EntityRenderManager.Instance()
    if not entityRender then
        return
    end
    if otherPlayer and otherPlayer.userId ~= PlayerManager:getClientPlayer().userId then
        local config = ActionEmojiConfig:getConfig(actionId)
        if config then
            otherPlayer:setPlayerActionName(tostring(config.name))
            otherPlayer:setUpperAction1(1012)
        end
    end
end

function handler.onTransformOldDress(data)
    local oldChipInfo = data.oldChipInfo
    local newChipCount = data.newChipCount
    if #oldChipInfo > 0 and newChipCount > 0 then
        TransformChipContent:setTransformData(oldChipInfo, newChipCount)
        PopUpWindows.builder()
                    .setTitleText("TransformChip_Title")
                    .setContentView(TransformChipContent)
                    .show()
    end
end

function handler.onShowReward(data)
    local result = {}
    for rewardId, count in pairs(data or {}) do
        if count ~= 0 then
            local rewardConfig = RewardConfig.findRewardById(rewardId)
            if rewardConfig then
                table.insert(result, { Image = rewardConfig.Image, Name = rewardConfig.Name, Count = count })
            else
                local good = CustomShopConfig:getGoodsConfig(rewardId)
                if good then
                    table.insert(result, { Image = good.Image, Name = good.Name, Count = count })
                end
            end
        end
    end

    GUIRewardResult:onShowRewardsTip(result,true)
end

handler:init()