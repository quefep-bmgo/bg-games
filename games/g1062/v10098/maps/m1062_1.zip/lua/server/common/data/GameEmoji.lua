---@class GameEmoji
GameEmoji = {}
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")

function GameEmoji:init()
    EventObservable:registerDataCallBack("BuyEmoji", function(userId, emojiId)
        local player = PlayerManager:getPlayerByUserId(userId)
        if not player then
            return
        end
        self:onBuyEmoji(player, emojiId)
    end)
end

function GameEmoji:setDBData(player, data)
    player.emojiData = data
    self:syncPlayerEmojiData(player)
end

function GameEmoji:onBuyEmoji(player, emojiId)
    emojiId = tostring(emojiId)
    local cfg = EmojiConfig:getCfgById(emojiId)
    if not cfg then
        return
    end
    if player.emojiData[emojiId] then
        self:syncPlayerEmojiData(player)
        return
    end
    local moneyType = cfg.moneyType
    local price = cfg.price
    PayHelper.payMoneySync(player, emojiId, moneyType, price, function()
        player.emojiData[emojiId] = emojiId
        self:syncPlayerEmojiData(player)
    end)
end

function GameEmoji:syncPlayerEmojiData(player, emojiId)
    local data = TableUtil.copyTable(player.emojiData)
    data.redDotId = emojiId
    CommonPacketSender:sendGameEmojiData(player.rakssid, data)
end

function GameEmoji:getEmojiByRewardId(player, rewardId)
    local cfg = EmojiConfig:getCfgByRewardId(rewardId)
    if not cfg then
        return false
    end
    local id = tostring(cfg.id)
    if player.emojiData[id] then
        return true
    end
    player.emojiData[id] = id
    self:syncPlayerEmojiData(player, id)
end

GameEmoji:init()