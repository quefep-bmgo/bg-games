---
---
DoubleKeyPrivilege = {}

function DoubleKeyPrivilege:init(config)
    self.id = tonumber(config.Id)
end

function DoubleKeyPrivilege:onPlayerBuy(player)
    if GameType == "g1046" then
        return
    end
    if player.alreadyReward then
        player.rewardKey = player.rewardKey or 0
        player.baseRewardKey = player.baseRewardKey or 0
        player:addYaoShi(player.baseRewardKey, Define.GetKeySource.Reward)
        player.rewardKey = player.rewardKey + player.baseRewardKey
        local data = {key = player.rewardKey, addKey = player.baseRewardKey}
        GamePacketSender:sendBedWarDoubleKeySummary(player.rakssid, data)
    end
end

function DoubleKeyPrivilege:onPlayerReward(player)
    return Privilege.checkHavePrivilege(player, self.id)
end