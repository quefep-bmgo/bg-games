local PlayerListener = T(Global, "PlayerListener")
---@type ServerGuideManager
local GuideManager = T(Global, "GuideManager")
---@type GameResourceManager
local GameResourceManager = T(Global, "GameResourceManager")
---@type SPidPacketSender
local PidPacketSender = T(Global, "PidPacketSender")
---@type GuidePlayer
local GuidePlayer = require "guide.entity.GuidePlayer"

local TrackerGroupIndex = 1000

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerRespawnEvent, self.onPlayerRespawn)
    BaseListener.registerCallBack(CEvents.PlayerAttackedEvent, self.onPlayerHurtForSettlement)
    BaseListener.registerCallBack(CEvents.PlayerDieEvent, self.onPlayerDied)
    BaseListener.registerCallBack(CEvents.PlayerDieTipEvent, self.onPlayerDiedTip)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerUseCommonItemEvent:registerCallBack(self.onPlayerUseCommonItem)
    CEvents.PlayerDropItemEvent:registerCallBack(self.onPlayerDropItem)
    CEvents.PlayerExchangeItemEvent:registerCallBack(self.onPlayerExchangeItem)
    CEvents.PlayerPickupItemEndEvent:registerCallBack(self.onPlayerPickupItemEnd)
    CEvents.PotionCustomEvent:registerCallBack(self.onPotionCustom)
    CEvents.ItemSkillNeedCustomSpeedEvent:registerCallBack(self.onItemSkillNeedCustomSpeed)
    CEvents.KnockBackExtraStrengthEvent:registerCallBack(self.onKnockBackExtraStrength)
    CEvents.PlayerAttackCreatureEvent:registerCallBack(self.onPlayerAttackCreature)
    CEvents.UseFishHookHitEntityEvent:registerCallBack(self.onUseFishHookHitEntity)
    CEvents.OnLaunchArrowEvent:registerCallBack(self.onLaunchArrow)
    CEvents.OnArrowHitEntityEvent:registerCallBack(self.onArrowHitEntity)
    CEvents.OnArrowHitGroundEvent:registerCallBack(self.onArrowHitGround)
    CEvents.WrongMoveEvent:registerCallBack(self.WrongMoveEvent)
end

function PlayerListener:WrongMoveEvent(entityId, pos)
    return true
end

function PlayerListener.onPlayerExchangeItem(rakssid, type, itemId, itemMeta, itemNum, bullets, vec3)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    if type == 1 then
        return ItemHelper:canDropItem(player, itemId)
    elseif type == 2 then
        local item = Item.getItemById(itemId)
        if item and item:getClassName() == "ItemSword" then
            player:removeWoodSword()
        end
        return true
    end
end

function PlayerListener.onPlayerLogin(clientPeer)
    if EngineVersionSetting.getEngineVersion() <= 10086 then
        return GameOverCode.GameOver
    end
    local player = GuidePlayer.new(clientPeer)
    if AIManager:isAIByUserId(player.userId) then
        GuideManager:onGuideAILogin(player)
    else
        TrackerGroupIndex = TrackerGroupIndex + 1
        player.entityPlayerMP:setIntProperty("TrackerGroupId", TrackerGroupIndex)
        LogUtil.log("[PlayerListener] onPlayerLogin   AIPlayer.userId: " .. tostring(player.userId).. "  TrackerGroupIndex: "..TrackerGroupIndex, LogUtil.LogLevel.Info)
    end
    player:init()
    HostApi.sendGameStatus(player.rakssid, 1)
    ServerReportEvent.player_login(player)
    return GameOverCode.Success, player
end

function PlayerListener.onPlayerLogout(player)
    GuideManager:onPlayerLogout(player)
    GameInfoManager:clearInfo("PlayerInfo", player.userId)
end

function PlayerListener.onPlayerReady(player)
    HostApi.sendPlaySound(player.rakssid, 10000)
    DbUtil:getPlayerData(player)
    player:checkParty()

    if GameConfig.openLotterySwitch == 1 then
        GamePacketSender:sendBedWarOpenLottery(player.rakssid)
    end

    HostApi.setAllowUseItemStatus(player.rakssid, 1)
    GameInfoManager.Instance():onPlayerReady(player)
    player.info:setValue("lifeStatus", true)
    GamePacketSender:sendMoveLimitCheck(player.rakssid)
    ServerReportEvent.player_ready(player)
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerHurtForSettlement(hurtPlayer, hurtFrom, damageType, hurtValue)
    local needHurt = PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    if needHurt then
        local hurter = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
        if hurter and hurter.mount then
            hurter.mount:onHurt(hurtValue.value)
            needHurt = false
        end
    end
    return needHurt
end

function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---@type GamePlayer
    local hurter = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
    if hurter == nil then
        return false
    end
    if hurter.isInvincible then
        ---无敌时间
        return false
    end
    if hurter.hurtLock then
        ---受伤保护时间
        return false
    end
    hurter.hurtLock = LuaTimer:schedule(function()
        hurter.hurtLock = nil
    end, 250)
    ---@type GamePlayer
    local fromer = PlayerManager:getPlayerByPlayerMP(hurtFrom)
    if fromer ~= nil then
        if damageType == "explosion.player" and fromer.onWithered then
            hurtValue.value = 0
            hurter:subHealth(GameConfig.tntExplosionDamageFactor)
        end
        hurter.damageType = "player"
    end
    if (fromer and AIManager:isAI(fromer.rakssid)) and not AIManager:isAI(hurter.rakssid or 0) then
        hurtValue.value = hurtValue.value * GameConfig.aiDamageCoefficient
    end

    if AIManager:isAI(hurter.rakssid) then
        local ai = AIManager:getAIByRakssid(hurter.rakssid)
        if ai then
            ai:onHurt()
        end
    end

    if damageType == "outOfWorld" then
        return false
    end

    if damageType == "fall" then
        local blockId = EngineWorld:getBlockId(VectorUtil.getNegY(hurtPlayer:getPosition()))
        if blockId == 0 or blockId == 165 then
            return false
        end
        if InventoryUtil:getPlayerHasEquipItem(hurter, Define.ItemId.NinjaShoes) then
            return false
        end
        if InventoryUtil:getPlayerHasEquipItem(hurter, Define.ItemId.NinjaShoes) then
            return false
        end
        if hurter.ignoreOnceFall then
            return false
        end
        hurter.damageType = "fall"
    end

    if damageType == "explosion.player" or damageType == "explosion" then
        hurtValue.value = hurter:subApple(hurtValue.value)
        hurter.damageType = "explosion"
        return true
    end

    if damageType == "arrow" then
        hurter.damageType = "arrow"
    end

    if damageType == "onFire" then
        hurter.damageType = "onFire"
    end

    if hurtFrom == nil then
        hurtValue.value = hurter:subApple(hurtValue.value)
        return true
    end

    if fromer ~= nil then
        if hurter.team and fromer.team and hurter.team.id == fromer.team.id then
            return false
        end
    end

    if damageType ~= "fall" and damageType ~= "explosion.player" and damageType ~= "explosion"
            and damageType ~= "outOfWorld" then
        hurter:addCustomEffect("beAttackEffect" .. tostring(hurter.userId), GameConfig.beAttackEffect, GameConfig.beAttackEffectTime * 1000)
    end

    if hurtValue.value < 1 then
        hurtValue.value = 1
    end
    hurtValue.value = hurter:subApple(hurtValue.value)
    return true
end

function PlayerListener.onPlayerDiedTip(diePlayer, killPlayer)
    return false
end

function PlayerListener.onPlayerDied(diePlayer, _, killPlayer)
    ---@type GamePlayer
    local dier = PlayerManager:getPlayerByPlayerMP(diePlayer)
    if not dier then
        return true
    end

    dier:setInventory()
    dier:clearInv()

    local ai = AIManager:getAIByRakssid(dier.rakssid)
    if ai ~= nil then
        ---玩家击杀机器人
        local killer = PlayerManager:getPlayerByPlayerMP(killPlayer)
        if not GuideManager:onPlayerKillGuideAI(killer) then
            RespawnHelper.addRespawnCountdown(dier, 0)
        end
    else
        RespawnHelper.addRespawnCountdown(dier, 0)
    end

    return true
end

function PlayerListener.onPlayerRespawn(player)
    player:fillInvetory(player.inventory)
    player:onSpawnInGame()

    local ai = AIManager:getAIByRakssid(player.rakssid)
    if ai ~= nil then
        GuideManager:onAIRespawn(player)
    end

    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerUseCommonItem(rakssId, itemId)

    local player = PlayerManager:getPlayerByRakssid(rakssId)
    if player == nil then
        return
    end

    if itemId >= 467 and itemId <= 471 then
        local pos = player:getPosition()
        if BridgeConfig:buildBridge(itemId, player:getYaw(), VectorUtil.toBlockVector3(pos.x, pos.y - 1, pos.z)) then
            SettlementManager:addBuildScore(player.userId, Define.BuildType.Egg)
        end
    end
end

function PlayerListener.onPlayerDropItem(rakssid, itemId, itemMeta)
    return false
end
----------------------------------------------------------------------------
-----------------------------  临时  ----------------------------------------
local iceTime = 3
local range = 1
function PlayerListener.changeBlockToIce(old_blockId, position, userId)
    if EngineWorld:getBlockId(position) ~= BlockID.PACKED_ICE then
        EngineWorld:setBlock(position, BlockID.PACKED_ICE)
    end
    LuaTimer:schedule(function()
        if EngineWorld:getBlockId(position) == BlockID.PACKED_ICE then
            local player = PlayerManager:getPlayerByUserId(userId)
            if not player then
                EngineWorld:setBlock(position, old_blockId)
                return
            end
            local newPos = player:getPosition()
            if math.abs(newPos.x - position.x) < range + 1 and
                    math.floor(newPos.y - 0.5) == position.y and
                    math.abs(newPos.z - position.z) < range + 1 then
                PlayerListener.changeBlockToIce(old_blockId, position, userId)
                return
            end
            EngineWorld:setBlock(position, old_blockId)
        end
    end, iceTime * 1000)
end

function PlayerListener.canBeIce(blockId)
    return blockId ~= BlockID.AIR
            and blockId ~= BlockID.PACKED_ICE
            and blockId ~= BlockID.OBSIDIAN
            and blockId ~= BlockID.WATER_MOVING
            and blockId ~= BlockID.WATER_STILL
            and blockId ~= BlockID.FIRE
            and blockId ~= BlockID.WOOL_CARPET
end
---@param player GamePlayer
function PlayerListener.checkSkatingShoes(player, pos)
    if player.equip_iec then
        local cur_block_pos = VectorUtil.toBlockVector3(pos.x, pos.y, pos.z)
        local cur_block_id = EngineWorld:getBlockId(cur_block_pos)
        if cur_block_id == BlockID.FIRE then
            EngineWorld:setBlock(cur_block_pos, BlockID.AIR)
        end
        for i = pos.x - range, pos.x + range do
            for j = pos.z - range, pos.z + range do
                local position = VectorUtil.toBlockVector3(i, pos.y - 1, j)
                local floor_block_id = EngineWorld:getBlockId(position)
                if PlayerListener.canBeIce(floor_block_id) and EngineWorld:isBlockChange(position) then
                    PlayerListener.changeBlockToIce(floor_block_id, position, player.userId)
                end
            end
        end
    end
end
-----------------------------  临时  ----------------------------------------
----------------------------------------------------------------------------
function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return true
    end

    if y <= GameConfig.deathLineY then
        local ai = AIManager:getAIByRakssid(player.rakssid)
        if ai == nil then
            GuideManager:onPlayerOutOfWorld(player)
        end
    end
    return true
end

function PlayerListener.onPlayerPickupItemEnd(rakssid, itemId, itemNum, _, entityId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    GameResourceManager:onPickUpItem(player, entityId, itemId, itemNum)
    ItemHelper:tryChangePickUpItem(player, itemId)
end

function PlayerListener.onPotionCustom(entityId, itemId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return true
    end
    local effect = ItemPotionEffect:getPotionEffect(itemId)
    if not effect then
        return true
    end
    player:addEffect(effect.Type, effect.Duration, effect.Level)
    return false
end

function PlayerListener.onItemSkillNeedCustomSpeed(rakssid, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end

    if ItemID.FLARE_BOMB == itemId then
        return false
    end

    return true
end

function PlayerListener.onKnockBackExtraStrength(hurterEntityId, attackerEntityId, knockBackValue)

end

function PlayerListener.onPlayerAttackCreature(rakssid, entityId, attackType, position, damage, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    local monster = MonsterManager:getMonster(entityId)
    if monster == nil then
        return false
    end
    return monster:onAttacked(player, damage)
end

function PlayerListener.onUseFishHookHitEntity(anglerId, targetId)
    local angler = PlayerManager:getPlayerByEntityId(anglerId)
    local target = PlayerManager:getPlayerByEntityId(targetId)
    if not target or not angler then
        return true
    end
    local anglerInfo = GameInfoManager:getPlayerInfo(angler.userId)
    local targetInfo = GameInfoManager:getPlayerInfo(target.userId)
    if not anglerInfo or not targetInfo then
        return true
    end

    if anglerInfo:getValue("teamId") == targetInfo:getValue("teamId") then
        return false
    end
    return true
end

function PlayerListener.onLaunchArrow(pos)
    PidPacketSender:broadcastSound(SoundConfig.launchArrow, pos)
end

function PlayerListener.onArrowHitGround(pos)
    if SoundConfig.hitGround ~= -1 then
        PidPacketSender:broadcastSound(SoundConfig.hitGround, pos)
        return false
    end
    return true
end

function PlayerListener.onArrowHitEntity(entityId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return
    end
    PidPacketSender:sendPlaySound(player.rakssid, SoundConfig.hitEntity)
end

PlayerListener:init()