---@type CBasePlayer
local handler = T(Global, "PacketHandlers")
---@type ServerGuideManager
local GuideManager = T(Global, "GuideManager")

function handler:onGuidePickUpItem(packet)
    self:tryAddItem(packet.itemId, packet.count)
end

function handler:onCompleteGuideNode(packet)
    GuideManager:onPlayerCompleteGuideNode(self, packet.nodeId)
end

function handler:RequestNewGuideAI(packet)
    GuideManager:RequestNewGuideAI(self, packet.param)
end

function handler:guideAIMove(packet)
    GuideManager:guideAIMove(self, VectorUtil.str2Vector3(packet.pos, ":"))
end

function handler:disableAIRespawn(packet)
    GuideManager:disableAIRespawn(self)
end

function handler:skipGuide(packet)
    GuideManager:onPlayerSkip(self)
end

function handler:onDoGuideReport(packet)
    local event_map = {}
    event_map.node_id = tonumber(packet.node_id)
    event_map.progress_id = tonumber(packet.progress_id)
    GameAnalytics:newDesign(self.userId, "server_complete_guide", event_map)
end