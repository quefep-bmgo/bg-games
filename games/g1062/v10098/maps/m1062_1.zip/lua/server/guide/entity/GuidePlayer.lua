---@type ServerPlayer
local ServerPlayer = require "common.entity.ServerPlayer"
---@class GuidePlayer : ServerPlayer
local GuidePlayer = class("GuidePlayer", ServerPlayer)
---@type ServerGuideManager
local GuideManager = T(Global, "GuideManager")

---@type SBuffManager
local SBuffManager = T(Global, "BuffManager")

function GuidePlayer:init()
    ServerPlayer.init(self)
    self.curGuideNodeId = 0

    ---@type GameTeam
    self.team = nil
    self.teamId = self.dynamicAttr.team

    self:initStaticAttr(0)

    self.multiKill = 0
    self.lastKillTime = 0
    self.kills = 0
    self.killAIs = 0
    self.isLife = true
    self.realLife = true
    self.standTime = 0
    self.deathNum = 0
    self.initLevel = 1

    self.isKeepItem = false
    self.curApple = 0
    self.maxApple = 0
    self.inventory = {}
    self.enderInventory = {}

    self.privilegeCard = {}
    self.chest_integral = 0
    self.chests = {}
    self.init_exp = false

    self.limit_item = {}

    self.isRespawn = true
    self.isStartMinute = true
    self.isRewardDoubleKey = false
    self.isPartyUser = false

    self.license_season = 0
    self.license_buy = 0
    self.license_exp = 0
    self.license_level = 1
    self.get_free_reward = {}
    self.get_pay_reward = {}
    self.exchange_reward = {}
    self.refresh_times = 1
    self.license_week_exp = 0
    self.license_week = 0
    self.free_upgrade_time = 0
    self.show_effect_task = {}

    self.pass_season = 0
    self.pass_buy = 0
    self.pass_exp = 0
    self.pass_level = 1
    self.get_pass_free_reward = {}
    self.get_pass_pay_reward = {}
    self.pass_exchange_reward = {}
    self.pass_week_exp = 0
    self.pass_week = 0
    self.pass_free_upgrade_time = 0
    self.show_pass_effect_task = {}

    self.challenges = {}
    self.needNewChallengeTip = false
    self.changeTaskId = -1
    self.challenge_ad = false

    self.addSpeed = 0

    self.banCureBuff = false
    self.useHollowBlock = false
    ---@type DoubleDummy
    self.double_dummy = nil

    self.useHollowBlockTime = nil
    self.useBridgeEggTime = nil
    self.itemKillRecord = {}

    self.placeBlockNumByButton = 0
    self.placeBlockNum = 0
    self.old_lv_info = {}
    self.registrationTimeKey = 0
    self.propED = {}
    self.dragonEggTime = {}
    self.extraShield = 0
    self.curExtraShield = 0
    self.extraFireBallDamage = {}
    self.extraAppleArmor = 0
    self.extraAppleAddHp = 0
    self.extraInvincibleTime = 0

    self:setFoodLevel(20)
    self:setFlyWing(true, GameConfig.glideMoveAddition, GameConfig.glideDropResistance)
end

function GuidePlayer:initDBDataFinished()
    if self.play_days == 0 then
        self.registrationTimeKey = os.time()
    end
    GuideManager:onPlayerReady(self)
    --self:changeClothes("custom_hat", 0)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
    ServerPlayer.initDBDataFinished(self)
end

function GuidePlayer:onSpawnInGame()
    self.isRespawn = true
    self.damageType = nil
    self.info:setValue("lifeStatus", true)
    self.lastGroundPos = nil
    self:fillEnderInvetory(self.enderInventory)
    if self.isKeepItem then
        self:fillInvetory(self.inventory)
        ReportUtil.reportRespawnByCube(self)
    end
    local ai = AIManager:getAIByRakssid(self.rakssid)
    if ai ~= nil then
        ai:onRespawn()
    end
    CustomShopCloth:onPlayerRespawn(self)
    self:addCustomEffect("InvincibleEffect" .. tostring(self.userId), GameConfig.InvincibleEffect, GameConfig.invincibleTime * 1000)
    self.isInvincible = true
    LuaTimer:schedule(function()
        self.isInvincible = false
    end, GameConfig.invincibleTime * 1000)
end

function GuidePlayer:checkParty()
    local manager = GameServer:getRoomManager()
    if manager:isUserAttrExisted(self.userId) then
        local attr = manager:getUserAttrInfo(self.userId)
        self.isPartyUser = attr.privateParty
    end
    if self.isPartyUser then
        GamePacketSender:sendBedWarKeyAdDeadSummary(self.rakssid, 0)
    end
end

function GuidePlayer:buildShowName()
    local nameList = {}
    local disName = self.name
    PlayerIdentityCache:buildNameList(self, nameList, disName)
    return nameList
end

function GuidePlayer:getDisplayName()
    if self.team ~= nil then
        return self.team:getDisplayName(self:getLanguage()) .. TextFormat.colorWrite .. self.name
    else
        return self.name
    end
end

function GuidePlayer:getTeamColorName()
    if self.team ~= nil then
        return self.team:getTeamColor() .. self.name
    else
        return self.name
    end
end

function GuidePlayer:getTeamId()
    if self.team ~= nil then
        return self.team.id
    end
    return self.teamId
end

function GuidePlayer:teleWatchPos()
    self:setAllowFlying(true)
    HostApi.sendSetFlying(self.rakssid)
    local vec = VectorUtil.newVector3(GameConfig.watchPoint[1], GameConfig.watchPoint[2], GameConfig.watchPoint[3])
    self:setPositionAndRotation(vec, tonumber(GameConfig.watchPoint[4]), tonumber(GameConfig.watchPoint[5]))

    if self.entityPlayerMP then
        self.entityPlayerMP:setPositionAndUpdate(tonumber(GameConfig.watchPoint[1]), tonumber(GameConfig.watchPoint[2]), tonumber(GameConfig.watchPoint[3]))
    end
end

function GuidePlayer:onLogout()
    SettlementManager:subPlayer(self)

    if self.isLife then
        self.isLife = false
        if self.team ~= nil then
            self.team:subPlayer()
        end
    end
end

function GuidePlayer:onDie()
    if self.isLife then
        self.isLife = false
        self.realLife = false
    end
end

function GuidePlayer:onUseCustomProp(propId)
    local extraHp = AppPropConfig:getRewardHp(propId)
    self.info:increaseValue("addHpFixedValue", extraHp)
    self:changeMaxHealth(self:getTotalMaxHp())
end

function GuidePlayer:onQuit()

end

function GuidePlayer:fillInvetory(inventory)
    self:clearInv()
    if inventory == nil then
        return
    end
    local items = inventory.item or {}
    for _, item in pairs(items) do
        if item.id > 0 and item.id < 10000 then
            self:tryAddItem(item.id, item.num)
        end
    end
    local armors = inventory.armor or {}
    for _, armor in pairs(armors) do
        if armor.id > 0 and armor.id < 10000 then
            self:tryAddItem(armor.id, armor.num)
        end
    end
    local guns = inventory.gun or {}
    for _, gun in pairs(guns) do
        if gun.id > 0 and gun.id < 10000 then
            self:tryAddItem(gun.id, gun.num)
        end
    end
end

function GuidePlayer:setInventory()
    local inv = self:getInventory()
    if not inv then
        return
    end
    self.inventory = InventoryUtil:getPlayerInventoryInfo(self)
    local hotbarFlag = {}
    for index, stack in pairs(self.inventory.item) do
        self.inventory.item[index].hotBarIndex = 1000
        for hotbarIndex = 0, 8 do
            local data = inv:getHotBarInventory(hotbarIndex)
            if data and hotbarFlag[hotbarIndex] == nil and data.id == stack.id
                    and data.num == stack.num and data.meta == stack.meta then
                hotbarFlag[hotbarIndex] = true
                self.inventory.item[index].hotBarIndex = hotbarIndex
                break
            end
        end
    end
    table.sort(self.inventory.item, function(a, b)
        if a.hotBarIndex ~= b.hotBarIndex then
            return a.hotBarIndex < b.hotBarIndex
        end
    end)
end

function GuidePlayer:fillEnderInvetory(enderInv)
    if enderInv == nil then
        return
    end
    local slot = 0
    local items = enderInv.item or {}
    for _, item in pairs(items) do
        if item.id > 0 and item.id < 10000 then
            self:addItemToEnderChest(slot, item.id, item.num, item.meta, item.enchantList)
            slot = slot + 1
        end
    end
end

function GuidePlayer:setEnderInventory()
    local inv = self:getEnderInventory()
    if not inv then
        return
    end
    self.enderInventory = InventoryUtil:getPlayerEnderInventoryInfo(self)
    for index, stack in pairs(self.enderInventory.item) do
        if inv then
            self.enderInventory.item[index].enchantList = ItemEnchantment:getItemEnchantmentList(inv, stack.stackIndex)
        end
    end
end

function GuidePlayer:addMaxApple(apple)
    self.maxApple = self.maxApple + apple
    self.curApple = self.maxApple
    self:updateApple()
end

function GuidePlayer:addApple(apple)
    self.curApple = self.curApple + apple
    self.curApple = math.min(self.curApple, self.maxApple)
    self:updateApple()
end

function GuidePlayer:subApple(damage)
    if self.curApple == nil or self.curApple <= 0 then
        return damage
    end
    if self.curApple - damage > 0 then
        self.curApple = self.curApple - damage
        self:updateApple()
        return 0
    else
        local result = damage - self.curApple
        self.curApple = 0
        self.maxApple = 0
        self:updateApple()
        return result
    end
end

function GuidePlayer:updateApple()
    if self.entityPlayerMP == nil then
        return
    end
    self.entityPlayerMP:changeApple(math.ceil(self.curApple), self.maxApple)
end

function GuidePlayer:hasSameArmor(itemId)
    local inv = self:getInventory()
    local index = inv:getArmorSlotById(itemId)
    if index >= 100 and index < 104 then
        local info = inv:getItemStackInfo(index)
        return info.id ~= 0
    end
    return false
end

function GuidePlayer:hasSameTool(itemId)
    local item = Item.getItemById(itemId)
    if not item then
        return false
    end
    local inv = self:getInventory()
    local class = item:getClassName()
    if class == "ItemPickaxe" or class == "ItemAxe" or class == "ItemShears" then
        for index = 1, 36 do
            local info = inv:getItemStackInfo(index - 1)
            if info.id ~= 0 then
                local _item = Item.getItemById(info.id)
                if _item then
                    local _class = _item:getClassName()
                    if _class == class then
                        return true
                    end
                end
            end
        end
    end
    return false
end

function GuidePlayer:initItem()

end

function GuidePlayer:addInitItems(newItemId)

end

function GuidePlayer:addGuideItems(initItems)
    --TODO
    ---初始化物品
    for _, itemStr in ipairs(initItems) do
        local item = StringUtil.split(itemStr, ",", false, true)
        self:tryAddItem(item[1], item[2], nil, nil, item[3])
    end
end

function GuidePlayer:tryItemId2DressId(itemId)
    local oldItemId = ItemMapping:getOldItemId(itemId) ---获取原始ItemId
    local dressId = self.equip_dress[tostring(oldItemId)] or itemId ---原始ItemId映射成装扮Id
    local newItemId = ItemMapping:getItemIdByDressId(itemId, dressId) ---装扮ID转换成真正的ItemId
    return newItemId
end

function GuidePlayer:addEnchantItem(itemId, count, damage, enchantList, stackIndex)
    count = itemId == ItemID.INGOT_IRON and math.ceil(count / 8) or count
    itemId = itemId == ItemID.INGOT_IRON and ItemID.INGOT_GOLD or itemId
    if enchantList and #enchantList > 0 then
        self:addEnchantmentsItem(itemId, count, damage, enchantList)
    else
        self:addItem(itemId, count, damage, nil, nil, stackIndex)
    end
end

function GuidePlayer:removeWoodSword()
    self:removeItem(ItemID.SWORD_WOOD, 1)
    local itemId = self:tryItemId2DressId(ItemID.SWORD_WOOD)
    self:removeItem(itemId, 1)
end

function GuidePlayer:tryAddItem(itemId, count, damage, enchantList, stackIndex)
    damage = damage or 0
    local item = Item.getItemById(itemId)
    if not item then
        ---尝试添加自定义方块
        itemId = self:tryItemId2DressId(itemId)
        self:addEnchantItem(itemId, count, damage, enchantList, stackIndex)
        return
    end
    if itemId == BlockID.CLOTH then
        itemId = self:getClothBlockId()
    end
    if itemId == ItemID.DOUBLE_DUMMY then
        itemId = self:getDoubleDummyId()
    end
    local class = item:getClassName()
    if class == "ItemBlock" and itemId > 2000 then
        ---自定义方块需要-1000
        itemId = self:tryItemId2DressId(itemId - 1000)
    else
        itemId = self:tryItemId2DressId(itemId)
    end
    if class == "ItemArmor" then
        self:tryEquipArmor(itemId, damage, enchantList)
    elseif class == "ItemPickaxe" or class == "ItemAxe" then
        self:tryAddToolItem(itemId, count, damage, enchantList, class, stackIndex)
    elseif class == "ItemSword" then
        self:removeWoodSword()
        ---删除木剑
        --enchantList = FireSwordPrivilege:onPlayerGetSword(self, enchantList)
        --enchantList = SwordItemGain:onPlayerGetSword(self, enchantList)
        self.info:setValue(class, itemId)
        self:addEnchantItem(itemId, count, damage, enchantList, stackIndex)
    elseif class == "ItemBow" then
        self.info:setValue(class, itemId)
        self:addEnchantItem(itemId, count, damage, enchantList, stackIndex)
    elseif class == "ItemShears" then
        ---检测是否有剪刀
        self:addEnchantItem(itemId, count, damage, enchantList, stackIndex)
    elseif class == "ItemGun" then
        self:addGunItem(itemId, 1, 0, 1000)
    else
        ---蓝色羊毛
        if itemId == 35 then
            damage = 11
        end
        self:addEnchantItem(itemId, count, damage, enchantList, stackIndex)
    end
end

function GuidePlayer:tryAddToolItem(itemId, count, damage, enchantList, class, stackIndex)
    ---工具类型的道具需要替换原来旧的道具
    local oldItemId = tonumber(self.info:getValue(class))
    if oldItemId ~= 0 then
        self:removeItem(oldItemId, count)
    end
    self.info:setValue(class, itemId)
    self:addEnchantItem(itemId, count, damage, enchantList, stackIndex)
end

function GuidePlayer:tryEquipArmor(itemId, damage, enchantList)
    local inv = self:getInventory()
    local index = inv:getArmorSlotById(itemId)
    enchantList = enchantList or {}
    if index > 100 then
        ---只针对衣服，裤子，鞋子
        self.info:setValue("ItemArmor" .. index, itemId)
        if index == 103 then
            self.equip_iec = itemId == 1000
            self.entityPlayerMP:setBoolProperty("ignoreFire", self.equip_iec)
            self:equipNinjaShoes(itemId == Define.ItemId.NinjaShoes)
        end
    end
    --enchantList = ArmorItemGain:onPlayerGetArmor(self, enchantList)
    self.entityPlayerMP:replaceArmorItemWithEnchant(itemId, 1, damage, enchantList)
end
function GuidePlayer:equipNinjaShoes(isEquip)
    self:setSpeedAddition(isEquip and GameConfig.NinjaShoesSpeedLevel or 0)
    CommonPacketSender:sendIsEquipNinjaShoes(self.rakssid, isEquip)
end

function GuidePlayer:clearArmorInfo()
    self.info:setValue("ItemSword", 0)
    self.info:setValue("ItemBow", 0)
    self.info:setValue("ItemArmor101", 0)
    self.info:setValue("ItemArmor102", 0)
    self.info:setValue("ItemArmor103", 0)
end

function GuidePlayer:getClothBlockId()
    if self.team then
        return self.team.clothBlockId
    end
    return BlockID.CLOTH
end

function GuidePlayer:getDoubleDummyId()
    if self.team then
        return self.team.doubleDummyId
    end
    return ItemID.DOUBLE_DUMMY
end

function GuidePlayer:subHealth(damage, fromMount)
    local value = self:subApple(damage)
    if value == 0 then
        return
    end
    if not fromMount and self.mount then
        self.mount:onHurt(value)
        return
    end
    return self.entityPlayerMP:heal(-value)
end

function GuidePlayer:changeSpeed(speed)
    self.addSpeed = self.addSpeed + speed
    self.entityPlayerMP:setSpeedAdditionLevel(self.addSpeed)
end

function GuidePlayer:recordGameResult(resultType)
    if not self.last_game_record then
        ---没有 拉成功DB数据
        return
    end

    table.insert(self.last_game_record, 1, resultType)
    table.remove(self.last_game_record, Define.GameRecordSaveCount + 1)
    self.game_start_times = self.game_start_times + 1
    self.gameResultType = resultType
    ServerReportEvent.player_game_end(self)
    if resultType == Define.GameResult.QUIT then
        return
    end
    ReportUtil.reportSettlementResult(self)
    self.game_complete_times = self.game_complete_times + 1
    if resultType == Define.GameResult.WIN then
        self.game_victory_times = self.game_victory_times + 1
    end
end

function GuidePlayer:canUseHollowBlock()
    if SBuffManager:checkBuff(self.userId, Define.BuffId.LockHollowBlock) then
        return
    end
    local num = self:getItemNumById(590)
    if num == 0 then
        return
    end

    SBuffManager:addBuff(self.userId, Define.BuffId.LockHollowBlock)
    self:usingHollowBlock()
end

function GuidePlayer:resetHollowBlock()
    if self.useHollowBlock then
        self.entityPlayerMP:setInTheAirCheatCheck(true)
        self.useHollowBlock = false
        self.info:setValue("isGliding", false)
        self:endSinging()
    end
end

function GuidePlayer:usingHollowBlock()
    local position = self:getPosition()

    self:setGlide(false)
    self.info:setValue("isGliding", true)
    self.useHollowBlock = true
    self.useHollowBlockTime = os.time()
    local dest = GameConfig.startGlideHeight - position.y + 10
    local totle = 0
    local motion = 0
    while (true) do
        motion = ((motion / 0.98) + 0.08) / 0.98

        totle = totle + motion
        if totle >= dest then
            break
        end
    end

    self.entityPlayerMP:setInTheAirCheatCheck(false)
    self:sendPacket({
        pid = "BedWarPlayerMotion",
        motion = VectorUtil.newVector3(0, motion, 0)
    })

    self:removeItem(590, 1)
end

function GuidePlayer:startSinging(singingTime, isCanBreak, icon, successCallBack)
    self:sendPacket({
        pid = "StartSinging",
        time = singingTime,
        icon = icon,
    })
    LuaTimer:cancel(self.singingKey or 0)
    self.singingKey = LuaTimer:schedule(function()
        self.singingKey = 0
        if successCallBack then
            successCallBack()
        end
    end, singingTime)
    if not isCanBreak then
        self.singingKey = 0
    end
end

function GuidePlayer:breakSinging()
    if self.singingKey == 0 then
        return
    end
    LuaTimer:cancel(self.singingKey or 0)
    self.singingKey = 0
    self:endSinging()
end

function GuidePlayer:endSinging()
    self:sendPacket({
        pid = "BreakSinging",
    })
end

function GuidePlayer:teleportPos(position)
    if self:ifOnMount() then
        return
    end
    self.super.teleportPos(self, position)
end

function GuidePlayer:teleportInitPos(position, yaw)
    if self:ifOnMount() then
        return
    end
    self.initPos = position or self.initPos
    self.initYaw = yaw or self.initYaw or 0
    if self.initPos then
        self:teleportPosWithYaw(self.initPos, self.initYaw)
    end
end

return GuidePlayer

--endregion
