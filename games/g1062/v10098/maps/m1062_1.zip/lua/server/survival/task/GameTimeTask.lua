local CGameTimeTask = class("GameTimeTask", ITask)

function CGameTimeTask:onTick(ticks)
    GameMatch:ifGameOver()
end

GameTimeTask = CGameTimeTask.new(GameMatch.Status.GameRunning)

return GameTimeTask
