local BlockListener = {}

function BlockListener:init()
    CEvents.BlockBreakEvent:registerCallBack(self.onBlockBreak)
    CEvents.PlayerPlaceBlockEvent:registerCallBack(self.onBlockPlace)
    CEvents.BlockTNTExplodeEvent:registerCallBack(self.onBlockTNTExplode)
end

function BlockListener.onBlockBreak(rakssid, blockId, vec3)
    return false
end

function BlockListener.onBlockPlace(rakssid, itemId, meta, toPlacePos)
    return false
end

function BlockListener.onBlockTNTExplode(entityId, pos, attr)
    attr.isBreakBlock = false
    return false
end

BlockListener:init()
