local handler = class("GamePacketHandler", EventObservable)

function handler:init()
    self:registerDataCallBack("ReceiveLvUpReward", self.onReceiveLvUpReward)
end

function handler.onReceiveLvUpReward(userId, lv)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    player:receiveLvUpReward(tonumber(lv))
end

handler:init()