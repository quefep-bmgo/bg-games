---@class CannonConfig
local CannonConfig = T(Global, "CannonConfig")
local Cannons = {}

function CannonConfig:Init()
    local configs = FileUtil.getConfigFromCsv("setting/CannonConfig.csv", 2, true)
    for _, config in pairs(configs) do
        local cannon = {}
        cannon.Id = config.Id
        cannon.ActorName = config.ActorName ~= '#' and config.ActorName or nil
        cannon.ActorBeginPosX = tonumber(config.ActorBeginPosX)
        cannon.ActorBeginPosY = tonumber(config.ActorBeginPosY)
        cannon.ActorBeginPosZ = tonumber(config.ActorBeginPosZ)
        cannon.FallOnPosX = tonumber(config.FallOnPosX)
        cannon.FallOnPosY = tonumber(config.FallOnPosY)
        cannon.FallOnPosZ = tonumber(config.FallOnPosZ)
        table.insert(Cannons, cannon)
    end
    CannonConfig:prepareCannons()
end

function CannonConfig:prepareCannons()
    for i, v in pairs(Cannons) do
        local beginPos = VectorUtil.newVector3(v.ActorBeginPosX, v.ActorBeginPosY, v.ActorBeginPosZ)
        local fallOnPos = VectorUtil.newVector3(v.FallOnPosX, v.FallOnPosY, v.FallOnPosZ)
        EngineWorld:getWorld():addActorCannon(beginPos, fallOnPos, v.ActorName, "", "", 5.0)
    end
end

CannonConfig:Init()

return CannonConfig