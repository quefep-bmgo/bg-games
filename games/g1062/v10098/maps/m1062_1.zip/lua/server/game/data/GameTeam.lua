---
--- Created by Jimmy.
--- DateTime: 2017/10/19 0019 15:36
---
---@class GameTeam
local GameTeam = class("GameTeam")
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")
---@type GameResourceManager
local GameResourceManager = T(Global, "GameResourceManager")
---@type GameStateReport
local GameStateReport = T(Global, "GameStateReport")
---@type GameMsgServer
local GameMsgServer = T(Global, "GameMsgServer")

local BlockBuildPos = {
    top = VectorUtil.newVector3(0, 1, 0),
    east = VectorUtil.newVector3(1, 0, 0),
    south = VectorUtil.newVector3(-1, 0, 0),
    west = VectorUtil.newVector3(0, 0, 1),
    north = VectorUtil.newVector3(0, 0, -1)
}

function GameTeam:ctor(config, color)
    self.id = config.id or 0
    self.name = config.name or "Red"
    self.initPos = config.initPos or VectorUtil.ZERO
    self.initYaw = config.initYaw or 0
    self.bedPos = config.bedPos or { VectorUtil.ZERO }
    self.resourcePointId = config.resourcePointId
    self.color = color or TextFormat.colorRed
    self.storeLv = 1
    self.initItems = config.initItems
    self.clothBlockId = config.clothBlockId or BlockID.CLOTH
    self.doubleDummyId = config.doubleDummyId or ItemID.DOUBLE_DUMMY
    self.isHaveBed = true
    self.curPlayers = 0
    self.bedBuildPos = {}

    ---@type GamePlayer[]
    self.playerList = {}
    self:initHPArea()

    GameInfoManager:newTeamInfo(tostring(config.id))
    ---@type TeamInfo
    self.info = GameInfoManager:getTeamInfo(config.id)
    GameResourceManager:newTeamResource(config.resourcePointId)
    self:initBedBuildPos()
end

function GameTeam:initHPArea()
    local startPos = HotSpringConfig:getStartPos(self.id)
    local endPos = HotSpringConfig:getEndPos(self.id)
    self.hpArea = IArea.new()
    self.hpArea:initByPos(startPos, endPos)
end

function GameTeam:isInHpArea(player)
    local pos = player:getPosition()
    return self.hpArea:inArea(pos)
end

function GameTeam:upgradeIron()
    GameResourceManager:UpgradeResource(self.resourcePointId)
end

function GameTeam:isPlayerExist(player)
    return self.playerList[tostring(player.userId)] ~= nil
end

function GameTeam:hasRealPlayer()
    for _, player in pairs(self.playerList) do
        if not PlayerManager:isAIPlayer(player) then
            return true
        end
    end
    return false
end

function GameTeam:addPlayer(player)
    self.playerList[tostring(player.userId)] = player
    self.curPlayers = TableUtil.getTableSize(self.playerList)
end

function GameTeam:subPlayer(userId)
    self.playerList[tostring(userId)] = nil
    self.curPlayers = TableUtil.getTableSize(self.playerList)
    if not isGameStart then
        return
    end
    if self:getCurPlayerCount() <= 0 then
        self.isHaveBed = false
        local players = PlayerManager:getPlayers()
        for _, player in pairs(players) do
            GameMsgServer:sendSystemTipToPlayer(player.userId, Messages:msgTeamFail(self:getDisplayName(player:getLanguage())))
        end
    end
end

function GameTeam:getTeamAverageHonor()
    local _, avgScore = QualifyingHelper:getTeamQualifyingScore(self.id)
    return avgScore
end

function GameTeam:isDeath()
    return self:getCurPlayerCount() <= 0
end

function GameTeam:getCurPlayerCount()
    local count = 0
    for _, player in pairs(self.playerList) do
        if player.isLife then
            count = count + 1
        end
    end
    return count
end

function GameTeam:getRealLifePlayerCount()
    local count = 0
    for _, player in pairs(self.playerList) do
        if player.realLife then
            count = count + 1
        end
    end
    self.info:setValue("liveCount", count)
    return count
end

function GameTeam:destroyBed(destroyer)
    self.isHaveBed = false
    self.info:setValue("isHaveBed", "0")
    ---@param player GamePlayer
    for _, player in pairs(PlayerManager:getPlayers()) do
        if player.teamId == self.id and player.gameDataController then
            player.gameDataController:have_bed_destroyed()
        end
    end
    HostApi.sendBedDestroy(self.id)
    GameStateReport:reportTeamBedDestroy(self.id)
end

function GameTeam:getDisplayName(lang)
    return self.color .. "[" .. MultiLanTipSetting.getMessageToLua(lang, tonumber(self.name), "") .. "]"
end

function GameTeam:getTeamColor()
    return self.color
end

function GameTeam:initBedBuildPos()
    for _, bedPos in pairs(self.bedPos) do
        for _, buildPos in pairs(BlockBuildPos) do
            local pos = VectorUtil.add3(bedPos, buildPos)
            table.insert(self.bedBuildPos, pos)
        end
    end
end

function GameTeam:isPosInBedBuildPos(pos)
    for _, bedBuildPos in pairs(self.bedBuildPos) do
        if VectorUtil.equal(bedBuildPos, pos) then
            return true
        end
    end
    return false
end

return GameTeam