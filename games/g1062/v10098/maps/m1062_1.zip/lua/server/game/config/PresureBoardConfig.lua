---@class PresureBoardConfig
local PresureBoardConfig = T(Global, "PresureBoardConfig")
local PresureBoardId = 72
PresureBoardConfig.configs = {}
PresureBoardConfig.exsitBoard = {}

local function EncodeVector3(vc3)
    local vc3i = VectorUtil.toVector3i(vc3)
    return VectorUtil.encodeVec3i(vc3i)
end

function PresureBoardConfig:isPresureItemId(itemId)
    return self.configs[itemId] ~= nil 
end

--- 压力板配置，不同的压力板配置用不同的ID来区分
function PresureBoardConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/PresureBoardConfig.csv", 2, true)
    for _, config in pairs(configs) do
        print("PresureBoardConfig "..StringUtil.v2s(config))
        local boardConfig = {}
        boardConfig.id = tonumber(config.ItemId)
        boardConfig.launchingHeight = tonumber(config.LaunchingHeight)
        boardConfig.hardNess = tonumber(config.HardNess)
        boardConfig.coolDown = tonumber(config.CoolDown)
        self.configs[boardConfig.id] = boardConfig
        print("PresureBoardConfig "..StringUtil.v2s(self.configs))
    end

    CEvents.BlockCanHarvestEvent:registerCallBack(function (blockId)
        if blockId == PresureBoardId then
            return false
        end
        return true
    end
    )

    local this = self
    CEvents.BlockBreakEvent:registerCallBack(function (rakssid, blockId, pos)
        this:onBlockDestroy(rakssid, blockId, pos)
        return true
    end)

    CEvents.BlockChangeEvent:registerCallBack(function (pos, blockId, meta)
        this:onBlockChange(pos, blockId, meta)
        return true
    end)

    CEvents.EntityItemSpawnEvent:registerCallBack(function (itemId, itemMeta, behavior, discard)
        return this:onItemSpawn(itemId, itemMeta, behavior, discard)
    end
    )

end

---- 记录压力板 等玩家站上之后 触发逻辑
function PresureBoardConfig:tryAddPresureBoard(player, itemId, pos)
    local useBoard = self.configs[itemId]
    local checkPos1 = VectorUtil.newVector3(pos.x, pos.y, pos.z)
    local checkResult1 = self.exsitBoard[EncodeVector3(checkPos1)]---如果当前位置已有压力板就不允许放置。

    local checkPos = VectorUtil.newVector3(pos.x, pos.y-1, pos.z)
    local checkResult = self.exsitBoard[EncodeVector3(checkPos)]---如果当前位置之下已有压力板就不允许放置。
    if useBoard ~= nil and checkResult1 == nil and checkResult == nil then 
        self.exsitBoard[EncodeVector3(pos)] = {id = itemId, pos = pos, lastUseTime = 0}
        LogUtil.logInfo("tryAddPresureBoard: "..StringUtil.v2s(pos).. "checkpos: "..StringUtil.v2s(checkPos))
        EngineWorld:setBlock(pos, PresureBoardId, 0)
        player:removeItem(itemId, 1)
    end
end

--- 删除掉底下没有block的压力板
function PresureBoardConfig:onBlockDestroy(rakssid, blockId, pos)
    local checkPos = VectorUtil.newVector3(pos.x, pos.y+1, pos.z)
    local checkResult = self.exsitBoard[EncodeVector3(checkPos)]
    if checkResult ~= nil then 
        EngineWorld:setBlockToAir(checkPos)
        self.exsitBoard[EncodeVector3(checkPos)] = nil
    end

    local checkPos2 = VectorUtil.newVector3(pos.x, pos.y, pos.z)
    local checkResult2 = self.exsitBoard[EncodeVector3(checkPos2)]
    if checkResult2 ~= nil then 
        self.exsitBoard[EncodeVector3(checkPos2)] = nil
    end
end

-- block 因为TNT 等原因爆炸导致改变
function PresureBoardConfig:onBlockChange(pos, blockId, meta)
    local checkPos = VectorUtil.newVector3(pos.x, pos.y, pos.z)
    local checkResult = self.exsitBoard[EncodeVector3(checkPos)]
    if checkResult ~= nil and blockId ~= PresureBoardId then
        EngineWorld:setBlockToAir(checkPos)
        self.exsitBoard[EncodeVector3(checkPos)] = nil
    end
end

function PresureBoardConfig:onItemSpawn(itemId, itemMeta, behavior, discard)
    if itemId == PresureBoardId then
        return false
    end
    return true
end

function PresureBoardConfig:JumpMotion(maxHeight)
    local height = maxHeight
    local vTemp = 0.0
    local vSum = 0.0
    local times = 0
    while vSum < height do
        vTemp = vTemp / 0.98 + 0.08
        vSum = vSum + vTemp
        vTemp = vTemp / 0.98
        times = times + 1
    end
    return times,  VectorUtil.newVector3(0.0, vTemp, 0.0)
end

--- 弹起走上来的玩家
function PresureBoardConfig:onPlayerMove(player)
    local playerMP =player:getEntityPlayer()
    local pos = playerMP:getBottomPos()
    local findBoard = self.exsitBoard[EncodeVector3(pos)]
    if findBoard ~= nil then
        local boardConfig = self.configs[findBoard.id]
        if  Root.Instance():getCurrentTime() - findBoard.lastUseTime > boardConfig.coolDown then 
            findBoard.lastUseTime = Root.Instance():getCurrentTime()
            local boardConfig = self.configs[findBoard.id]
            local height = boardConfig.launchingHeight
            local times, motion = self:JumpMotion(height)
            HostApi.doThrow(player:getEntityId(), pos,  0.0, 270.0, motion.y, times)
            player.entityPlayerMP:setInTheAirCheatCheck(false)
            LuaTimer:scheduleTimer(function()
                player.entityPlayerMP:setInTheAirCheatCheck(true)
            end, times*50, 1)
            EngineWorld:setBlockToAir(pos)
            self.exsitBoard[EncodeVector3(pos)] = nil --- 策划调整需求 压力板弹一次就销毁。但是先保持上面的 冷却时间逻辑。
        end
    end
end
return PresureBoardConfig