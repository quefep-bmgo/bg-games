local handler = class("GamePacketHandler", EventObservable)

---@type SPacketHandlers
local PacketHandlers = T(Global, "PacketHandlers")

function handler:init()
    self:registerDataCallBack("SettlementGood", function(fromUserId, toUserId)
        SettlementManager:sendGood(fromUserId, toUserId)
    end)
    self:registerDataCallBack("PushSurveySuccess", function(userId)
        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            SurveyManager:onPlayerPushSurveySuccess(player)
        end
    end)
    self:registerDataCallBack("C2SSaveGoodsShortcutList", function(userId, shortcutList)
        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            player.goodsShortcutList = json.decode(shortcutList) or {}
        end
    end)
end

function PacketHandlers:C2SOperateExitGame(packet)
    for _, player in pairs(PlayerManager:getPlayers()) do
        if player.userId ~= self.userId then
            player:sendPacket({
                pid = "S2COperateExitGame",
                userId = self.userId
            })
        end
    end
end

handler:init()