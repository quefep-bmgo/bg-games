---@class SRecordUtil
local SRecordUtil = T(Global, "SRecordUtil")
local RecordKey = {
    AttackDis = "attackDis",
    AttackFrequency = "attackFrequency",
    MoveDis = "moveDis",
    FloatTime = "floatTime"
}

---@private
function SRecordUtil:init()
    self.recordData = {}
end

function SRecordUtil:syncRecordData(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    self.recordData[tostring(userId)] = data
end

---@param player GamePlayer
function SRecordUtil:onPlayerLogout(player)
    local data = self.recordData[tostring(player.userId)] or {}
    if TableUtil.isEmpty(data) then
        return
    end
    self:reportAttackDis(player)
    self:reportAttackFrequency(player)
    self:reportMoveDis(player)
    self:reportFloatTime(player)
end

function SRecordUtil:reportAttackDis(player)
    local data = self.recordData[tostring(player.userId)][RecordKey.AttackDis]
    if not data or TableUtil.isEmpty(data) then
        return
    end
    for dis, times in pairs(data) do
        ReportUtil.reportAttackDis(player, dis, times)
    end
end

function SRecordUtil:reportAttackFrequency(player)
    local data = self.recordData[tostring(player.userId)][RecordKey.AttackFrequency]
    if not data or TableUtil.isEmpty(data) then
        return
    end
    for frequency, times in pairs(data) do
        ReportUtil.reportAttackFrequency(player, frequency, times)
    end
end

function SRecordUtil:reportMoveDis(player)
    local data = self.recordData[tostring(player.userId)][RecordKey.MoveDis]
    if not data or data <= 0 then
        return
    end
    ReportUtil.reportMoveDis(player, math.floor(data))
end

function SRecordUtil:reportFloatTime(player)
    local data = self.recordData[tostring(player.userId)][RecordKey.FloatTime]
    if not data or data <= 0 then
        return
    end
    ReportUtil.reportFloatTime(player, data)
end

SRecordUtil:init()