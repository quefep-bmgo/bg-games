---@type GameMsgServer
local GameMsgServer = T(Global, "GameMsgServer")
---@class GameOverTask
local CGameOverTask = class("GameOverTask", ITask)

function CGameOverTask:onTick(ticks)

    if (ticks >= GameConfig.gameOverTime) then
        self:stop()
        return
    end

    local seconds = GameConfig.gameOverTime - ticks;

    if seconds <= 10 and seconds > 0 then
        MsgSender.sendBottomTips(3, IMessages:msgCloseServerTimeHint(seconds, IMessages.UNIT_SECOND, false))
        if seconds <= 3 then
            HostApi.sendPlaySound(0, 12);
        else
            HostApi.sendPlaySound(0, 11);
        end
    end

end

function CGameOverTask:start()
    SecTimer.startTimer(self.timer)
    GameMsgServer:sendSystemTipToAll(IMessages:msgCloseServerTimeHint(GameConfig.gameOverTime, IMessages.UNIT_SECOND, false))
end

function CGameOverTask:stop()
    GameMatch:cleanPlayer()
    SecTimer.stopTimer(self.timer)
end

GameOverTask = CGameOverTask.new(GameMatch.Status.GameOver)

return GameOverTask
