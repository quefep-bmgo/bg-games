---@type GameDataController
local GameDataController = require "game.data.GameDataController"
---@type ServerPlayer
local ServerPlayer = require "common.entity.ServerPlayer"
---@class GamePlayer : ServerPlayer
local GamePlayer = class("GamePlayer", ServerPlayer)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type SRankUtil
local SRankUtil = T(Global, "SRankUtil")
---@type PropPacketManager
local PropPacketManager = T(Global, "PropPacketManager")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")
---@type ScoreActivityTaskMgr
local ScoreActivityTaskMgr = T(Global, "ScoreActivityTaskMgr")
---@type SGameLicense
local SGameLicense = T(Global, "SGameLicense")
---@type SGamePass
local SGamePass = T(Global, "SGamePass")
---@type GameModeUtil
local GameModeUtil = T(Global, "GameModeUtil")
---@type GameStateReport
local GameStateReport = T(Global, "GameStateReport")
---@type RuneManager
local RuneManager = T(Global, "RuneManager")
---@type SRecordUtil
local SRecordUtil = T(Global, "SRecordUtil")
---@type TurntableActivityTaskMgr
local TurntableActivityTaskMgr = T(Global, "TurntableActivityTaskMgr")
---@type SPidPacketSender
local PidPacketSender = T(Global, "PidPacketSender")
---@type GameMsgServer
local GameMsgServer = T(Global, "GameMsgServer")
---@type PuzzleActivityTaskMgr
local PuzzleActivityTaskMgr = T(Global, "PuzzleActivityTaskMgr")
---@type PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")
---@type SBuffManager
local SBuffManager = T(Global, "BuffManager")
---@type ImbueManager
local ImbueManager = T(Global, "ImbueManager")
---@type TalentHelper
local TalentHelper = T(Global, "TalentHelper")

function GamePlayer:init()
    ServerPlayer.init(self)
    if self.teamId == nil then
        ---@type GameTeam
        self.team = nil
        self.teamId = self.info:getValue("teamId", true)
        self.isLife = true
        self.realLife = true
        self.initItems = {}
        self.itemKillRecord = {}
        self.multiKill = 0
        self.lastKillTime = 0
        self.kills = 0
        self.killAIs = 0
        self.standTime = 0
        self.deathNum = 0
        self.initLevel = 1
        self.curApple = 0
        self.maxApple = 0
        self.useHollowBlockTime = nil
        self.useBridgeEggTime = nil
        self.placeBlockNumByButton = 0
        self.placeBlockNum = 0
        self.addSpeed = 0
        self.inventory = {}
        self.enderInventory = {}
        ReportManager:reportUserEnter(self.userId)
    end
    self.isDisconnect = false
    self.isShowSuitInHall = false
    self.noShowSuitChangeTip = false
    self.lastEquipSuitRecord = {}

    self:initStaticAttr(0)

    self.privilegeCard = {}
    self.chest_integral = 0
    self.chests = {}

    self.limit_item = {}

    self.isRespawn = true
    self.isStartMinute = true
    self.isRewardDoubleKey = false
    self.isPartyUser = false

    self.license_season = 0
    self.license_buy = 0
    self.license_exp = 0
    self.license_level = 1
    self.get_free_reward = {}
    self.get_pay_reward = {}
    self.exchange_reward = {}
    self.refresh_times = 1
    self.license_week_exp = 0
    self.license_week = 0
    self.free_upgrade_time = 0
    self.show_effect_task = {}

    self.pass_season = 0
    self.pass_buy = 0
    self.pass_exp = 0
    self.pass_level = 1
    self.get_pass_free_reward = {}
    self.get_pass_pay_reward = {}
    self.pass_exchange_reward = {}
    self.pass_week_exp = 0
    self.pass_week = 0
    self.pass_free_upgrade_time = 0
    self.show_pass_effect_task = {}

    self.challenges = {}
    self.needNewChallengeTip = false
    self.changeTaskId = -1
    self.challenge_ad = false

    self.banCureBuff = false
    self.useHollowBlock = false
    ---@type DoubleDummy
    self.double_dummy = nil

    self.battleRecord = nil
    self.curGuideNodeId = 0

    self.isNew = false
    self.consecutiveLoginDays = 1
    self.newBattleRecord = {}
    self.aiGameRecord = {}
    self.lastFiveRecord = {}

    self.rechargeReportKey = ""

    self.firstLogin = false

    self.singleGameUseItemRecord = {}
    self.old_lv_info = {}

    self.passPageTime = 0
    self.licensePageTime = 0
    self.registrationTimeKey = 0

    self.propED = {}
    self.dragonEggTime = {}
    self.extraShield = 0
    self.curExtraShield = 0
    self.extraFireBallDamage = {}
    self.extraAppleArmor = 0
    self.extraAppleAddHp = 0
    self.extraInvincibleTime = 0

    self:setFoodLevel(20)
    self:initTeam()
    self:teleWaitPos()
    self:setFlyWing(true, GameConfig.glideMoveAddition, GameConfig.glideDropResistance)
    self.taskController = GameTaskController.new(self)
end

function GamePlayer:onPlayerLogout()
    self.clientPeer = nil
    self.isReady = false
    ReportManager:onPlayerLogout(self)
    SRecordUtil:onPlayerLogout(self)
end

function GamePlayer:getRespawnPos()
    if self.team then
        return self.team.initPos
    end
    return self.super.getRespawnPos(self)
end

function GamePlayer:initDBDataFinished()
    CreditScoreUtil:onPlayerLogin(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TALENT_ESSENCE, self.talent_essence)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.PET_CANDY, self.pet_candy)
    local oldHp = self:getHealth()
    --基础属性
    self:initPlayerAttribute()
    Privilege.syncPrivilegeTime(self)
    AddMaxHPPrivilege:onPlayerRespawn(self)
    PetUpgradeShop:syncPetLvData(self)
    CustomShop:transformOldDress(self)
    CustomShop:transformOldBlockSkin(self)
    CustomShop:onSyncPlayerAllGoods(self)
    TreasureChallenge:onPlayerReady(self)
    if not self.info:getBoolValue("playerInitImbue") then
        Plugins.CallTargetPluginFunc("imbue", "clearPlayerCurImbue", self.userId)
        RuneManager:clearPlayerCurRune(self.userId)
        RuneManager:onPlayerInitRune(self)
        Plugins.CallTargetPluginFunc("imbue", "onPlayerInitImbue", self)
        self.info:setValue("playerInitImbue", "true")
    end
    if oldHp < 20 then
        self:setHealth(oldHp)
    end
    self:initItem(Define.INIT_PLAYER_ITEM_TYPE.INIT_DB)
    self.taskController:init()
    TreasureChallenge:refreshChallengeTask(self)
    ScoreActivityTaskMgr:initPlayerTask(self)
    TurntableActivityTaskMgr:initPlayerTask(self)
    PuzzleActivityTaskMgr:initPlayerTask(self)
    SGameLicense:updatePlayerData(self)
    SGamePass:updatePlayerData(self)
    if self.play_days == 0 then
        self.isNew = true
        self.registrationTimeKey = os.time()
    end
    if tonumber(self.play_week_key) < tonumber(DateUtil.getYearWeek()) then
        SRankUtil:clearWeeklyData(self)
        self.play_week_key = DateUtil.getYearWeek()
    end
    if tonumber(self.play_day_key) < tonumber(DateUtil.getYearDay()) then
        if tonumber(self.play_day_key) ~= 0 and self.isNew then
            if tonumber(DateUtil.getYearDay()) - tonumber(self.play_day_key) > 1 then
                self.isNew = false
            else
                self.consecutiveLoginDays = self.consecutiveLoginDays + 1
            end
        end
        self.firstLogin = true
        self.play_days = self.play_days + 1
        self.day_play_times = 0
        self.day_play_time = 0
        self.play_day_key = DateUtil.getYearDay()
        self.taskController:packingProgressData(Define.TaskType.GrowUp.DailyLogin, nil, 1)
        TreasureChallenge:resetTreasureAd(self)
        CreditScoreUtil:addLoginCreditScore(self)
        self.dailyOnlineTime = 0
        self.dailyCreditScore = 0
        self.noShowSuitChangeTip = false
        self.licensePageTime = 0
        self.passPageTime = 0
    end
    self.initLevel = self.level
    GamePacketSender:sendBedWarPlayerLevel(self.rakssid, self.level)
    if #self.chests == 0 then
        GameChestLottery:initChestLotteryData(self)
    end
    GameChestLottery:syncChestLotteryData(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
    --self:changeClothes("custom_hat", 0)
    SurveyManager:onPlayerLogin(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
    if AIManager:isAI(self.rakssid) == false then
        Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level, 0)
        SRankUtil:initBattleRecord(self)
        self:checkOverdueDiamondConsumeRecord()
    end
    if isGameStart then
        self:setShowName(self:buildShowName())
    end
    SRankUtil:reportKeyRank(self.userId, self.yaoshi)
    SRankUtil:calculateCustomRankData(self)
    SGameLicense:syncLicensePageTime(self)
    SGamePass:syncPassPageTime(self)
    SRankUtil:reportHornNumRank(self.userId, self.had_horn)
    SRankUtil:reportChipNumRank(self.userId, self.commonChip)
    SRankUtil:calculateChestRankData(self)
    GameStateReport:reportPlayerInit(self)
    self:sendPacket({
        pid = "syncCustomGameSetting",
        data = self.customGameSetting
    })
    ServerPlayer.initDBDataFinished(self)
    self:updateApple()
    Plugins.CallTargetPluginFunc("imbue", "setPlayerInitImbueFinish", self)
    self:changeMaxHealth(self:getTotalMaxHp())
    self:getPlatformPurchase()

    if not AIManager:isAI(self.rakssid) then
        TalentHelper:reportLoginTalentLevelData(self)
        GamePacketSender:sendGoodsShortcutList(self.rakssid, self.goodsShortcutList)
    end
end

function GamePlayer:initPlayerAttribute()
    self.info:setValue("bedWarAttackCD", GameConfig.bedWarAttackCD)
    self.info:setValue("initBowAttackSpeed", GameConfig.bowAttackSpeed)
    self.entityPlayerMP:setFloatProperty("ArrowSpeedScale",GameConfig.arrowSpeedScale)
    self:changeMaxHealth(GameConfig.defaultHp or 20)
end

---检查玩家连接成功后是否真实活着
function GamePlayer:checkConnectSuccessPlayerLife()
    if not self.isLife then
        SettlementManager:sendSingleSettlement(self, isGameEnd)
    end
    if self.realLife then
        if self:isDead() then
            return false
        end
    else
        if self:isDead() then
            self.entityPlayerMP:rebirth(self.rakssid, self.userId, StringUtil.getRealName(self.name), self.team.initPos)
        end
        self:subHealth(10000)
        return false
    end
    return true
end

function GamePlayer:onSpawnInGame(initItemType)
    if not self.isLife then
        return
    end
    if not PlayerManager:isAIPlayer(self) and self.game_start_times and self.game_start_times < 5 then
        if self.gameDataController == nil then
            self.gameDataController = GameDataController.new(self)
        else
            self.gameDataController:have_respawn()
        end
    end
    self:teleInitPos()
    self.damageType = nil
    self.lastGroundPos = nil
    self.isRespawn = true
    self.info:setValue("lifeStatus", true)
    self:fillEnderInvetory(self.enderInventory)
    local isKeepItem = self.isKeepItem
    self:initItem(initItemType)
    self.logoutPos = nil
    local ai = AIManager:getAIByRakssid(self.rakssid)
    if ai ~= nil then
        ai:onRespawn()
    end
    CustomShopCloth:onPlayerRespawn(self)
    CustomShopFootprint:onPlayerRespawn(self)
    GameStore:checkAllUpgradeGoods(self, initItemType, isKeepItem)
    local invincibleTime = GameConfig.invincibleTime + (self.extraInvincibleTime or 0)
    self:addCustomEffect("InvincibleEffect" .. tostring(self.userId), GameConfig.InvincibleEffect, invincibleTime * 1000)
    self.isInvincible = true
    LuaTimer:schedule(function()
        self.isInvincible = false
    end, invincibleTime * 1000)
end

function GamePlayer:addExp(exp)
    local cur_max, is_max = ServerPlayer.addExp(self, exp)
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level, 0)
    return cur_max, is_max
end

function GamePlayer:getLevelInfo()
    local lv = self.level or 1
    local cur_exp = self.cur_exp or 0
    local max_exp, is_max = ExpConfig:getMaxExp(self.level)
    return lv, cur_exp, max_exp, is_max
end

function GamePlayer:syncLevelInfo()
    local lv, cur_exp, max_exp, is_max = self:getLevelInfo()

    local params = {
        level = lv,
        curExp = cur_exp,
        maxExp = max_exp,
        isMax = is_max,
    }
    local data = DataBuilder.new():fromTable(params):getData()
    PacketSender:sendLuaCommonData(self.rakssid, "LevelInfo", data)
end

function GamePlayer:checkParty()
    local manager = GameServer:getRoomManager()
    if manager:isUserAttrExisted(self.userId) then
        local attr = manager:getUserAttrInfo(self.userId)
        self.isPartyUser = attr.privateParty
    end
    if self.isPartyUser then
        GamePacketSender:sendBedWarKeyAdDeadSummary(self.rakssid, 0)
    end
end

function GamePlayer:buildShowName()
    local nameList = {}
    local disName, vipInfo = string.match(self.name, "(.*)(%[S=.*])")
    if not disName then
        disName = self.name
    end


    ---@type GameTeam
    local team = GameMatch.Teams[self:getDisplayTeamId()]
    if team ~= nil then
        if BaseMain:isChina() then
            disName = disName .. team:getDisplayName("zh_CN")
        else
            disName = disName .. team:getDisplayName("en_US")
        end
    end
    if vipInfo then
        disName = disName .. vipInfo
    end
    PlayerIdentityCache:buildNameList(self, nameList, disName)
    return nameList
end

function GamePlayer:getDisplayName()
    self.name = string.gsub(self.name, "#", "")
    if self.team ~= nil then
        return self.team:getDisplayName(self:getLanguage()) .. TextFormat.colorWrite .. self.name
    else
        return self.name
    end
end

function GamePlayer:getTeamColorName()
    self.name = string.gsub(self.name, "#", "")
    if self.team ~= nil then
        return self.team:getTeamColor() .. self.name
    else
        return self.name
    end
end

function GamePlayer:initTeam()
    local teamId = self.info:getValue("teamId", true)
    if teamId ~= 0 then
        self.teamId = teamId
    end
    for _, team in pairs(GameMatch.Teams) do
        if team.id == self.teamId then
            self.team = team
            break
        end
    end
    if self.team then
        self.teamId = self.team.id
        self.dynamicAttr.team = self.teamId
    else
        self.teamId = math.max(1, self.teamId)
        self.dynamicAttr.team = self.teamId
        self.team = GameMatch.Teams[self.teamId]
    end
    if self.isLife then
        self.team:addPlayer(self)
    end
    self.info:setValue("teamId", self.teamId)
    local respawnPos = VectorUtil.newVector3i(self.team.initPos.x, self.team.initPos.y, self.team.initPos.z)
    self:setRespawnPos(respawnPos)
    self.team.info:addPlayer(self.userId)
    self.entityPlayerMP:setTeamId(self.teamId)
end

function GamePlayer:getTeamId()
    if self.team ~= nil then
        return self.team.id
    end
    return self.teamId
end

function GamePlayer:teleInitPos()
    self.realLife = self.isLife
    if self.logoutPos then
        return
    end
    if self.team ~= nil and self.team.initPos ~= nil then
        self:teleportPosWithYaw(self.team.initPos, self.team.initYaw or 0)
    end
end

function GamePlayer:teleWaitPos()
    if isGameStart then
        self:teleInitPos()
        return
    end
    if self.logoutPos then
        return
    end
    local randomPos = MathUtil:randomDoubleInCircle(GameConfig.waitPos, GameConfig.initPosRange)
    if self:checkReady() then
        self:teleportPos(randomPos)
    else
        self:teleportPosWithYaw(randomPos, GameConfig.waitYaw)
    end
end

function GamePlayer:teleWatchPos()
    self:setAllowFlying(true)
    HostApi.sendSetFlying(self.rakssid)
    local vec = VectorUtil.newVector3(GameConfig.watchPoint[1], GameConfig.watchPoint[2], GameConfig.watchPoint[3])
    self:setPositionAndRotation(vec, tonumber(GameConfig.watchPoint[4]), tonumber(GameConfig.watchPoint[5]))

    if self.entityPlayerMP then
        self.entityPlayerMP:setPositionAndUpdate(tonumber(GameConfig.watchPoint[1]), tonumber(GameConfig.watchPoint[2]), tonumber(GameConfig.watchPoint[3]))
    end
end

function GamePlayer:onLogout()
    self.logoutTime = os.time()
    local time = os.time() - self.login_time
    self.day_play_time = self.day_play_time + time
    if self.isPartyUser then
        self.appIntegral = 0
    end
    if self:ifOnMount() and self.mount then
        self.mount:onDead()
    end
    self.isDisconnect = true
    if self.realLife then
        self:setInventory()
        self:setEnderInventory()
        self.isKeepItem = true
        if isGameStart and self:checkReady() then
            self.logoutPos = self:getPosition()
        end
    end
    if isGameEnd or self.alreadyReward then
        if not AIManager:isAI(self.rakssid) then
            ReportUtil.reportPlaceBlock(self)
        end
    else
        if not self.realLife and not self.team.isHaveBed then
            ---购买复活中退出游戏判为死亡
            self:onDie()
        end
        GameMatch:ifGameOver()
    end
end

---@param dier GamePlayer
function GamePlayer:onKill(dier)
    self.kills = self.kills + 1
    self.appIntegral = self.appIntegral + 1

    if AIManager:isAI(dier.rakssid) == true then
        self.killAIs = self.killAIs + 1
    end

    if self.multiKill == 0 then
        self.multiKill = 1
    else
        if os.time() - self.lastKillTime <= 30 then
            self.multiKill = self.multiKill + 1
        else
            self.multiKill = 1
        end
    end

    if self:ifOnMount() and self.mount then
        self.mount:onKillPlayer()
    end
    ---@param _player GamePlayer
    for _, _player in pairs(PlayerManager:getPlayers()) do
        if _player ~= dier and _player.teamId == dier.teamId and _player.gameDataController then
            _player.gameDataController:have_teammate_killed()
        end
    end

    if dier.gameDataController then
        dier.gameDataController:have_died()
        dier.gameDataController:die_count()
    end

    if self.gameDataController then
        self.gameDataController:kill_player_count()
    end
    SettlementManager:onPlayerDied(dier.userId, self.userId, self.multiKill)
    self.lastKillTime = os.time()
    RuneManager:onKill(self)
    Plugins.CallTargetPluginFunc("imbue", "onKill", self)
    SBuffManager:onKill(self.userId)
    self:onKillRestoreHp()
    self:onKillGetIron()
    self:updateBattleInfo({ kill = 1 })
end

function GamePlayer:onDestroyBed(team)
    GameMsgServer:sendSystemTipToTeam(team.id, Messages:msgBedHasBreak())
    local players = PlayerManager:getPlayers()
    for _, _player in pairs(players) do
        GameMsgServer:sendSystemTipToPlayer(_player.userId, Messages:breakBedTip(self:getTeamColorName(), team:getDisplayName(_player:getLanguage())))
        if _player.teamId == self.teamId then
            PidPacketSender:sendPlaySound(_player.rakssid, SoundConfig.breakOtherBed)
        end
    end

    local destroy_bed = self.info:getValue("destroy_bed")
    self.taskController:packingProgressData(Define.TaskType.Fright.DestroyBed, nil, 1)
    Plugins.CallTargetPluginFunc("personal_title", "tryUpdateTask", self, {
        action = "destroyBed",
        count = 1,
    })
    self.info:setValue("destroy_bed", destroy_bed .. team.id)
    self:updateBattleInfo({ bed = 1 })
end

function GamePlayer:onDie()
    if self.isLife then
        self.isLife = false
        self.realLife = false
        self.team:subPlayer(self.userId)
        SettlementManager:onPlayerLose(self)
        HostApi.sendPlaySound(self.rakssid, 10002)
        SurveyManager:onGameEnd(self)
        if AIManager:isAI(self.rakssid) == true then
            AITeamManager:onAIDie(self)
        else
            if self.gameDataController then
                self.gameDataController:have_weed_out()
            end
        end
        ---@param _player GamePlayer
        for _, _player in pairs(PlayerManager:getPlayers()) do
            if _player ~= self and _player.teamId == self.teamId then
                if _player.gameDataController then
                    _player.gameDataController:have_teammate_weed_out()
                end
            end
        end
    end
end

function GamePlayer:onUseCustomProp(propId)
    local extraHp = AppPropConfig:getRewardHp(propId)
    self.info:increaseValue("addHpFixedValue", extraHp)
    self:changeMaxHealth(self:getTotalMaxHp())
end

function GamePlayer:onQuit()
    if not PlayerManager:isAIPlayer(self) and self:checkReady() then
        SRankUtil:reportKeyConsumeRank(self.userId, self.keyConsume)
        SRankUtil:reportDiamondConsumeRank(self.userId, self.diamondConsume)
    end
    if self.isReport then
        return
    end
    self.isReport = true
    local isCount = RewardManager:isUserRewardFinish(self.userId) and 1 or 0
    ReportManager:reportUserData(self.userId, self.info:getValue("kill", true), self.info:getValue("rank", true), isCount)
end

function GamePlayer:fillInvetory(inventory)
    self:clearInv()
    if inventory == nil then
        return
    end
    local items = inventory.item or {}
    for _, item in pairs(items) do
        if item.id > 0 and item.id < 10000 then
            self:tryAddItem(item.id, item.num, nil, item.enchantList)
        end
    end
    local armors = inventory.armor or {}
    for _, armor in pairs(armors) do
        if armor.id > 0 and armor.id < 10000 then
            self:tryAddItem(armor.id, armor.num, nil, armor.enchantList)
        end
    end
    local guns = inventory.gun or {}
    for _, gun in pairs(guns) do
        if gun.id > 0 and gun.id < 10000 then
            self:tryAddItem(gun.id, gun.num, nil, gun.enchantList)
        end
    end
end

function GamePlayer:setInventory()
    local inv = self:getInventory()
    if not inv then
        return
    end
    self.inventory = InventoryUtil:getPlayerInventoryInfo(self, nil, 36)
    local hotbarFlag = {}
    for index, stack in pairs(self.inventory.item) do
        self.inventory.item[index].hotBarIndex = 1000
        for hotbarIndex = 0, 8 do
            local data = inv:getHotBarInventory(hotbarIndex)
            if data and hotbarFlag[hotbarIndex] == nil and data.id == stack.id
                    and data.num == stack.num and data.meta == stack.meta then
                hotbarFlag[hotbarIndex] = true
                self.inventory.item[index].hotBarIndex = hotbarIndex
                break
            end
        end
    end
    table.sort(self.inventory.item, function(a, b)
        if a.hotBarIndex ~= b.hotBarIndex then
            return a.hotBarIndex < b.hotBarIndex
        end
    end)
end

function GamePlayer:setEnderInventory()
    local inv = self:getEnderInventory()
    if not inv then
        return
    end
    self.enderInventory = InventoryUtil:getPlayerEnderInventoryInfo(self)
    for index, stack in pairs(self.enderInventory.item) do
        if inv then
            self.enderInventory.item[index].enchantList = ItemEnchantment:getItemEnchantmentList(inv, stack.stackIndex)
        end
    end
end

function GamePlayer:addMaxApple(apple)
    self.maxApple = self.maxApple + apple
    self.curApple = self.maxApple
    self:updateApple()
end

function GamePlayer:addApple(apple)
    self.curApple = self.curApple + apple
    self.curApple = math.min(self.curApple, self.maxApple)
    self:updateApple()
end

function GamePlayer:subApple(damage)
    if self.curApple == nil or self.curApple <= 0 then
        return damage
    end
    if self.curApple - damage > 0 then
        self.curApple = self.curApple - damage
        self:updateApple()
        return 0
    else
        local result = damage - self.curApple
        self.curApple = 0
        self.maxApple = 0
        self:updateApple()
        return result
    end
end

function GamePlayer:updateApple()
    if self.entityPlayerMP == nil then
        return
    end
    local max = self.curExtraShield > 0 and self.extraShield + self.maxApple or self.maxApple
    self.entityPlayerMP:changeApple(math.ceil(self.curApple + self.curExtraShield), max)
end

function GamePlayer:resetApple()

    for hash, timeId in pairs(LogicListener.goldAppleAddHpTimeId) do
        local findHash = string.find(hash, tostring(self.userId))
        if findHash ~= nil and findHash > 0 then
            if timeId ~= nil then
                LuaTimer:cancel(timeId)
                timeId = nil
            end
            LogicListener.goldAppleAddHpTimeId[hash] = nil
            break
        end
    end

    for hash, timeId in pairs(LogicListener.goldAppleTimeId) do
        local findHash = string.find(hash, tostring(self.userId))
        if findHash ~= nil and findHash > 0 then
            if timeId ~= nil then
                LuaTimer:cancel(timeId)
                timeId = nil
            end
            LogicListener.goldAppleTimeId[hash] = nil
            break
        end
    end

    for hash, timeId in pairs(LogicListener.goldAppleFreshTimeId) do
        local findHash = string.find(hash, tostring(self.userId))
        if findHash ~= nil and findHash > 0 then
            if timeId ~= nil then
                LuaTimer:cancel(timeId)
                timeId = nil
            end
            LogicListener.goldAppleFreshTimeId[hash] = nil
            break
        end
    end
end

function GamePlayer:hasAdvancedSword()
    local oldItemId = ItemMapping:getOldItemId(tonumber(self.info:getValue("ItemSword")))
    local goods = StoreConfig:getGoodsByItemId(oldItemId)
    if goods and goods.Level > 1 then
        return true
    end
    return false
end

function GamePlayer:hasSameArmor(itemId)
    local inv = self:getInventory()
    local index = inv:getArmorSlotById(itemId)
    if index >= 100 and index < 104 then
        local info = inv:getItemStackInfo(index)
        return info.id ~= 0
    end
    return false
end

function GamePlayer:hasSameTool(itemId)
    local item = Item.getItemById(itemId)
    if not item then
        return false
    end
    local inv = self:getInventory()
    local class = item:getClassName()
    if class == "ItemPickaxe" or class == "ItemAxe" or class == "ItemShears" then
        for index = 1, 36 do
            local info = inv:getItemStackInfo(index - 1)
            if info.id ~= 0 then
                local _item = Item.getItemById(info.id)
                if _item then
                    local _class = _item:getClassName()
                    if _class == class then
                        return true
                    end
                end
            end
        end
    end
    return false
end

--- 物品降级
function GamePlayer:reduceItemGrade(itemId)
    local oldItemId = ItemMapping:getOldItemId(itemId)
    local goods = StoreConfig:getGoodsByItemId(oldItemId)
    if goods then
        local prevLevel = math.max(goods.Level - 1, 1)
        if prevLevel > 0 then
            local nextGoods = StoreConfig:getUpgradeGoods(oldItemId, prevLevel)
            if nextGoods then
                self:tryAddItem(nextGoods.ItemId, 1)
                return true
            end
        end
    end
end

---工具降级
function GamePlayer:reduceToolsGrade(toolItemId)
    local oldItemId = ItemMapping:getOldItemId(toolItemId)
    local goods = StoreConfig:getGoodsByItemId(oldItemId)
    if goods then
        local prevLevel = goods.Level - 1
        if prevLevel > 0 then
            local nextGoods = StoreConfig:getUpgradeGoods(oldItemId, prevLevel)
            if nextGoods then
                self:tryAddItem(nextGoods.ItemId, 1)
                return true
            end
        end
    end
end

---防具降级
function GamePlayer:reduceArmorsGrade(armorItemId)
    local oldItemId = ItemMapping:getOldItemId(armorItemId)
    local goods = StoreConfig:getGoodsByItemId(oldItemId)
    if goods and goods.Level > 0 then
        local prevLevel = goods.Level - 1
        if prevLevel > 0 then
            local nextGoods = StoreConfig:getUpgradeGoods(oldItemId, prevLevel)
            if nextGoods then
                self:tryAddItem(nextGoods.ItemId, 1)
                return true
            end
        end
    end
end

---复活的时候初始化物品数据，做添加默认物品 和 防具工具的降级处理
function GamePlayer:respawnInitItem(inventory)
    if inventory == nil then
        return
    end
    local showReduceTips = false
    local items = inventory.item or {}
    for _, item in pairs(items) do
        if item.id > 0 and item.id < 10000 then
            if ItemHelper:isItemTools(item.id) then
                ---工具降级
                if self:reduceItemGrade(item.id) then
                    showReduceTips = true
                end
            elseif ItemHelper:isCurrencyItem(item.id) then
                ---货币重新添加
                self:tryAddItem(item.id, item.num)
            elseif ItemHelper:isItemWeapon(item.id) then
                ---武器降级
                if self:reduceItemGrade(item.id) then
                    showReduceTips = true
                end
            end
        end
    end
    local armors = inventory.armor or {}
    for _, armor in pairs(armors) do
        if armor.id > 0 and armor.id < 10000 then
            ---防具降级
            if self:reduceArmorsGrade(armor.id) then
                showReduceTips = true
            end
        end
    end

    ---添加默认物品，如果部位有冲突则不添加
    self:addDefaultInitItem()
    --GameMsgServer:sendSystemTipToPlayer(self.userId, Messages:msgItemDecreaseLevel())
end

function GamePlayer:addDefaultInitItem(initItemType)
    self:removeWoodSword()
    for _, itemId in ipairs(self.initItems) do
        if not self:hasSameArmor(itemId) and not self:hasSameTool(itemId) then
            local needAdd = true
            if (itemId == ItemID.SWORD_WOOD and self:hasAdvancedSword()) or ItemID.BOW == itemId or ItemID.FISHING_ROD == itemId then
                needAdd = false
            end
            if needAdd then
                self:tryAddItem(itemId, 1)
            end
        end
    end
end

function GamePlayer:initItem(initItemType)
    if self.isKeepItem then
        PropPacketManager:onPlayerDied(self)
        self:fillInvetory(self.inventory)
        PropPacketManager:onPlayerRespawn(self)
        self.entityPlayerMP:inventoryForceUpdate()
        self.entityPlayerMP:markInventoryDirty()
        if self.gameDataController then
            self.gameDataController:have_respawn_with_cube()
        end
    else
        if isGameStart then
            if initItemType == Define.INIT_PLAYER_ITEM_TYPE.RESPAWN then
                self:respawnInitItem(self.inventory)
            else
                self:addDefaultInitItem(initItemType)
            end
            self:setInventory()
        else
            self:tryAddItem(ItemID.SWORD_WOOD, 1)
        end
    end
    self.isKeepItem = false
end

function GamePlayer:tryItemId2DressId(itemId)
    local oldItemId = ItemMapping:getOldItemId(itemId) ---获取原始ItemId
    local newItemId, dressId
    if oldItemId == ItemID.HELMET_LEATHER then
        dressId = CustomShopSuit:getSuitableHeadDressId(self)
        if dressId == oldItemId then
            dressId = itemId
        end
    else
        dressId = self.equip_dress[tostring(oldItemId)] or itemId ---原始ItemId映射成装扮Id
    end
    newItemId = ItemMapping:getItemIdByDressId(itemId, dressId) ---装扮ID转换成真正的ItemId
    return newItemId
end

function GamePlayer:addEnchantItem(itemId, count, damage, enchantList)
    count = itemId == ItemID.INGOT_IRON and math.ceil(count / 8) or count
    itemId = itemId == ItemID.INGOT_IRON and ItemID.INGOT_GOLD or itemId
    if enchantList and #enchantList > 0 then
        self:addEnchantmentsItem(itemId, count, damage, enchantList)
    else
        self:addItem(itemId, count, damage)
    end
end

function GamePlayer:removeWoodSword()
    self:removeItem(ItemID.SWORD_WOOD, 1)
    local itemId = self:tryItemId2DressId(ItemID.SWORD_WOOD)
    self:removeItem(itemId, 1)
end

function GamePlayer:tryAddItem(itemId, count, damage, enchantList)
    if itemId == ItemID.INGOT_IRON then
        itemId = ItemID.INGOT_GOLD
        count = math.ceil(count / 8)
    end
    SurveyManager:onPlayerGetItem(self, itemId)
    ---@type DragonEggConfig
    local DragonEggConfig = T(Global, "DragonEggConfig")
    damage, count = DragonEggConfig:onAddItemToPlayer(self, itemId, count, damage)
    damage = damage or 0

    --print("===== try addItem ", self.userId, itemId, count, damage, enchantList)
    --LogUtil.pv(enchantList)
    --print(debug.traceback(""))

    local item = Item.getItemById(itemId)
    if not item then
        ---尝试添加自定义方块
        itemId = self:tryItemId2DressId(itemId)
        self:addEnchantItem(itemId, count, damage, enchantList)
        return
    end
    if itemId == BlockID.CLOTH then
        itemId = self:getClothBlockId()
    end
    if itemId == ItemID.DOUBLE_DUMMY then
        itemId = self:getDoubleDummyId()
    end
    local class = item:getClassName()
    if class == "ItemBlock" and itemId > 2000 then
        ---自定义方块需要-1000
        itemId = self:tryItemId2DressId(itemId - 1000)
    else
        itemId = self:tryItemId2DressId(itemId)
    end
    if class == "ItemArmor" then
        self:tryEquipArmor(itemId, damage, enchantList)
    elseif class == "ItemPickaxe" or class == "ItemAxe" then
        enchantList = ToolItemGain:onPlayerGetTool(self, enchantList)
        self:tryUpgradeItem(itemId, count, damage, enchantList, class)
    elseif class == "ItemSword" then
        --self:removeWoodSword()
        ---删除木剑
        enchantList = FireSwordPrivilege:onPlayerGetSword(self, enchantList)
        enchantList = SwordItemGain:onPlayerGetSword(self, enchantList)
        --self.info:setValue(class, itemId)
        self:tryUpgradeItem(itemId, count, damage, enchantList, class)
    elseif class == "ItemBow" or class == "ItemFishingRod" then
        --self.info:setValue(class, itemId)
        self:tryUpgradeItem(itemId, count, damage, enchantList, class)
    elseif class == "ItemShears" then
        ---检测是否有剪刀
        if self:getInventory():getItemNum(itemId) <= 0 then
            enchantList = ToolItemGain:onPlayerGetTool(self, enchantList)
            self:addEnchantItem(itemId, count, damage, enchantList)
        end
    elseif class == "ItemGun" then
        self:addGunItem(itemId, 1, 0, 1000)
    else
        self:addEnchantItem(itemId, count, damage, enchantList)
    end
    return itemId
end

--function GamePlayer:tryAddToolItem(itemId, count, damage, enchantList, class)
--    ---工具类型的道具需要替换原来旧的道具
--    local oldItemId = tonumber(self.info:getValue(class))
--    if oldItemId ~= 0 then
--        self:removeItem(oldItemId, count)
--    end
--    self.info:setValue(class, itemId)
--    self:addEnchantItem(itemId, count, damage, enchantList)
--end

function GamePlayer:tryUpgradeItem(itemId, count, damage, enchantList, class)
    ---升级类型的道具需要替换原来旧的同类型物品
    local oldItemId = tonumber(self.info:getValue(class))
    if oldItemId ~= 0 then
        self:removeItem(oldItemId, count)
    end
    self.info:setValue(class, itemId)
    self:addEnchantItem(itemId, count, damage, enchantList)
end

function GamePlayer:tryEquipArmor(itemId, damage, enchantList)
    local inv = self:getInventory()
    local index = inv:getArmorSlotById(itemId)
    enchantList = enchantList or {}
    if index >= 100 then
        ---只针对衣服，裤子，鞋子
        self.info:setValue("ItemArmor" .. index, itemId)
        if index == 103 then
            self.equip_iec = itemId == 1000
            self.entityPlayerMP:setBoolProperty("ignoreFire", self.equip_iec)
            self:equipNinjaShoes(itemId == Define.ItemId.NinjaShoes)
        end
        if index == 100 then
            self.info:setValue("IsHideFace", false)
            local oldItemId = ItemMapping:getOldItemId(itemId)
            local headId = self.equip_dress[tostring(oldItemId)]
            if headId then
                local dress = CustomShopDress:getSettingByItemId(headId)
                self.info:setValue("IsHideFace", dress and dress.IsHideFace == 1 or false)
            end
        end
    end
    enchantList = ArmorItemGain:onPlayerGetArmor(self, enchantList)
    self.entityPlayerMP:replaceArmorItemWithEnchant(itemId, 1, damage, enchantList)
    if index == 101 then
        if not PlayerManager:isAIPlayer(self) then
            CustomShopSuit:onChestChange(self, itemId)
        end
    end
    GameStateReport:reportPlayerDefense(self)
end
function GamePlayer:equipNinjaShoes(isEquip)
    self:setSpeedAddition(isEquip and GameConfig.NinjaShoesSpeedLevel or 0)
    CommonPacketSender:sendIsEquipNinjaShoes(self.rakssid, isEquip)
end

function GamePlayer:addInitItems(newItemId)
    for _, itemId in pairs(self.initItems) do
        if itemId == newItemId then
            return
        end
    end
    table.insert(self.initItems, newItemId)
end

function GamePlayer:clearArmorInfo()
    self.info:setValue("ItemSword", 0)
    self.info:setValue("ItemBow", 0)
    self.info:setValue("ItemFishingRod", 0)
    self.info:setValue("ItemArmor101", 0)
    self.info:setValue("ItemArmor102", 0)
    self.info:setValue("ItemArmor103", 0)
end

function GamePlayer:getClothBlockId()
    if self.team then
        return self.team.clothBlockId
    end
    return BlockID.CLOTH
end

function GamePlayer:getDoubleDummyId()
    if self.team then
        return self.team.doubleDummyId
    end
    return ItemID.DOUBLE_DUMMY
end

function GamePlayer:subHealth(damage, fromMount)
    local value = self:subApple(damage)
    if value == 0 then
        return
    end
    if not fromMount and self.mount then
        self.mount:onHurt(value)
        return
    end
    return self.entityPlayerMP:heal(-value)
end

function GamePlayer:changeSpeed(speed, sceneSpeed)
    sceneSpeed = sceneSpeed or 0
    self.addSpeed = self.addSpeed + speed
    self.entityPlayerMP:setSpeedAdditionLevel(self.addSpeed + sceneSpeed)
end

function GamePlayer:recordGameResult(resultType)
    if QualifyingHelper.inQualifyingGame then
        self.taskController:packingProgressData(Define.TaskType.Fright.Qualifying, nil, 1)
    end
    PlayerCustomInfoUtil:reportGameTimes(self)
    if not self.last_game_record then
        ---没有 拉成功DB数据
        return
    end

    if self.isNew then
        self:recordNewBattleInfo()
    end

    self:reportBattleInfo(resultType == Define.GameResult.QUIT)

    table.insert(self.last_game_record, 1, resultType)
    if #self.last_game_record > Define.GameRecordSaveCount then
        table.remove(self.last_game_record)
    end

    self.day_play_times = self.day_play_times + 1
    self.game_start_times = self.game_start_times + 1
    self.gameResultType = resultType
    if self.gameDataController then
        self.gameDataController:report_end()
    end
    ServerReportEvent.player_game_end(self)
    self.game_start_times = self.game_start_times + 1
    if resultType == Define.GameResult.QUIT then
        if self.gameDataController then
            self.gameDataController:have_escape()
        end
        ---@param _player GamePlayer
        for _, _player in pairs(PlayerManager:getPlayers()) do
            if _player ~= self and _player.teamId == self.teamId then
                if _player.gameDataController then
                    _player.gameDataController:have_teammate_escape()
                end
            end
        end
        return
    end
    self.game_complete_times = self.game_complete_times + 1
    if not self.isNegative then
        Plugins.CallTargetPluginFunc("activity", "triggerCondition", self, Define.ConditionType.CompleteGame)
        if GameModeUtil:getGameMode() == Define.GameMode.Qualifying then
            Plugins.CallTargetPluginFunc("activity", "triggerCondition", self, Define.ConditionType.CompleteQualifyingGame)
        end
    end
    if resultType == Define.GameResult.WIN then
        self.game_victory_times = self.game_victory_times + 1
    end

    local isWin = self.info:getBoolValue("isWin")
    if isWin and not self.isNegative then
        Plugins.CallTargetPluginFunc("activity", "triggerCondition", self, Define.ConditionType.WinGame)
        if GameModeUtil:getGameMode() == Define.GameMode.Qualifying then
            Plugins.CallTargetPluginFunc("activity", "triggerCondition", self, Define.ConditionType.WinQualifyingGame)
        end
    end

    table.insert(self.trigger_gift_game_record, 1, { result = resultType, time = os.time() })
    if #self.trigger_gift_game_record > Define.TriggerGiftGameRecordSaveCount then
        table.remove(self.trigger_gift_game_record)
    end
end

function GamePlayer:canUseHollowBlock()
    self.freeHollowBlock = false
    Plugins.CallTargetPluginFunc("imbue", "onUseHollowBlock", self)
    if not self.freeHollowBlock then
        local num = self:getItemNumById(590)
        if num == 0 then
            return
        end
    end
    self:usingHollowBlock()
end

function GamePlayer:resetHollowBlock()
    if self.useHollowBlock then
        self.entityPlayerMP:setInTheAirCheatCheck(true)
        self.useHollowBlock = false
        HostApi.setAllowUseItemStatus(self.rakssid, 1)
        self.info:setValue("isGliding", false)
        self:endSinging()
        self:sendPacket({
            pid = "resetHollowBlock"
        })
    end
end

function GamePlayer:setGlideFromClient()
    if not self.useHollowBlock then
        self:sendPacket({
            pid = "resetHollowBlock"
        })
        return
    end
    self:setGlide(true)
    self.ignoreOnceFall = true
    self:startSinging(GameConfig.glideDuration * 1000, false, Define.SingingIcon.HollowBlock)
    LuaTimer:cancel(self.cancelGlideKey or 0)
    self.cancelGlideKey = LuaTimer:schedule(function(userId)
        ---@type GamePlayer
        local c_player = PlayerManager:getPlayerByUserId(userId)
        if c_player then
            c_player:setGlide(false)
            c_player:resetHollowBlock()
        end
    end, GameConfig.glideDuration * 1000, nil, tostring(self.userId))
end

function GamePlayer:usingHollowBlock()
    self:setGlide(false)
    self.info:setValue("isGliding", true)
    HostApi.setAllowUseItemStatus(self.rakssid, 0)
    self.useHollowBlock = true
    self.useHollowBlockTime = os.time()

    if not self.freeHollowBlock then
        self:removeItem(590, 1)
    end
end

function GamePlayer:startSinging(singingTime, isCanBreak, icon, successCallBack)
    self:sendPacket({
        pid = "StartSinging",
        time = singingTime,
        icon = icon,
    })
    LuaTimer:cancel(self.singingKey or 0)
    self.singingKey = LuaTimer:schedule(function()
        self.singingKey = 0
        if successCallBack then
            successCallBack()
        end
    end, singingTime)
    if not isCanBreak then
        self.singingKey = 0
    end
end

function GamePlayer:breakSinging()
    if self.singingKey == 0 then
        return
    end
    LuaTimer:cancel(self.singingKey or 0)
    self.singingKey = 0
    self:endSinging()
end

function GamePlayer:endSinging()
    self:sendPacket({
        pid = "BreakSinging",
    })
end

function GamePlayer:teleportPos(position)
    if self:ifOnMount() then
        return
    end
    self.super.teleportPos(self, position)
end

local WinLimit = {
    g1008 = 8,
    g1061 = 4,
    g1062 = 8
}
function GamePlayer:reportBattleInfo(isQuit)
    local updateInfo = {}
    local playerInfo = GameInfoManager:getPlayerInfo(self.userId)
    if not playerInfo or not self.battleRecord then
        return
    end
    local type = QualifyingHelper.inQualifyingGame and "qualifying" or GameType
    local rank = tonumber(playerInfo:getValue("rank"))
    local isWin = rank > 0 and rank <= WinLimit[GameType]
    updateInfo.play = isQuit and 0 or 1
    updateInfo.win = (not isQuit and isWin) and 1 or 0
    updateInfo.comboWin = (not isQuit and isWin) and 1 or 0

    self:updateBattleInfo(updateInfo, true)

    local info = self.battleRecord[type]
    if not isQuit then
        local score = SRankUtil:win2Score(info.win, info.play)
        SRankUtil:reportWinRank(self.userId, score)
    end
    if isWin then
        SRankUtil:reportWinTimesRank(self.userId, info.win)
    end
    SRankUtil:reportWinningRank(self.userId, info.comboWin.max)
    SRankUtil:reportKillRank(self.userId, info.kill)
    SRankUtil:reportDestroyBedRank(self.userId, info.bed)
end

function GamePlayer:updateBattleInfo(data, needReportCustomInfo)
    if not self.battleRecord then
        return
    end
    local type = QualifyingHelper.inQualifyingGame and "qualifying" or GameType
    if not self.battleRecord[type] then
        self.battleRecord[type] = {
            win = 0,
            play = 0,
            kill = 0,
            bed = 0,
            comboWin = {
                max = 0,
                cur = 0
            }
        }
    end
    for key, value in pairs(data) do
        if self.battleRecord[type][key] then
            if key == "comboWin" then
                local comboWinInfo = self.battleRecord[type][key]
                comboWinInfo.cur = value == 0 and 0 or comboWinInfo.cur + 1
                comboWinInfo.max = math.max(comboWinInfo.max, comboWinInfo.cur)
                self.battleRecord[type][key] = comboWinInfo
            else
                self.battleRecord[type][key] = self.battleRecord[type][key] + value
            end
        end
    end
    if needReportCustomInfo then
        PlayerCustomInfoUtil:reportCustomInfo(self.userId, "string", Define.PlayerCustomInfo.BattleRecord, json.encode(self.battleRecord), "2")
    end
    return true
end

function GamePlayer:checkTriggerGift(gameRecord)
    local winTimes = 0
    local loseTimes = 0
    local playTimes = 0

    for index, record in pairs(gameRecord) do
        if index == 1 and record.result ~= Define.GameResult.WIN then
            break
        end
        if record.result == Define.GameResult.WIN then
            winTimes = winTimes + 1
        else
            break
        end
    end

    for index, record in pairs(gameRecord) do
        if index == 1 and record.result ~= Define.GameResult.LOSE then
            break
        end
        if record.result == Define.GameResult.LOSE then
            loseTimes = loseTimes + 1
        else
            break
        end
    end

    for _, record in pairs(gameRecord) do
        if os.time() - record.time < Define.TriggerGiftContinuePlayTime then
            playTimes = playTimes + 1
        else
            break
        end
    end
end

function GamePlayer:recordNewBattleInfo()
    local playerInfo = GameInfoManager:getPlayerInfo(self.userId)
    if not playerInfo then
        return
    end
    local rank = tonumber(playerInfo:getValue("rank"))
    local isWin = rank > 0 and rank <= WinLimit[GameType]
    local updateInfo = {
        kill = self.kills,
        die = tonumber(playerInfo:getValue("die")),
        time = RewardManager:getGameRunningTime(),
        play = 1,
        win = isWin and 1 or 0
    }

    if #self.lastFiveRecord >= 5 then
        table.remove(self.lastFiveRecord, #self.lastFiveRecord)
    end
    table.insert(self.lastFiveRecord, 1, IsAIGame)
    self:updateNewBattleInfo(updateInfo)
end

function GamePlayer:updateNewBattleInfo(data)
    if IsAIGame then
        for key, value in pairs(data) do
            self.aiGameRecord[key] = self.aiGameRecord[key] and self.aiGameRecord[key] + value or value
        end
    else
        if not self.newBattleRecord[GameType] then
            self.newBattleRecord[GameType] = {}
        end
        for key, value in pairs(data) do
            self.newBattleRecord[GameType][key] = self.newBattleRecord[GameType][key] and self.newBattleRecord[GameType][key] + value or value
        end
    end
end

function GamePlayer:updateDailyLastRecord()
    if not self.battleRecord then
        return
    end
    local type = QualifyingHelper.inQualifyingGame and "qualifying" or GameType
    if not self.battleRecord[type] then
        self.battleRecord[type] = {
            win = 0,
            play = 0,
            kill = 0,
            bed = 0,
            comboWin = {
                max = 0,
                cur = 0
            }
        }
    end
    self.battleRecord[type].lastRecord = {
        win = self.battleRecord[type].win,
        play = self.battleRecord[type].play
    }
    PlayerCustomInfoUtil:reportCustomInfo(self.userId, "string", Define.PlayerCustomInfo.BattleRecord, json.encode(self.battleRecord), "2")
end

--- imbue 相关
function GamePlayer:getCurativeRate()
    local subReplyLv = self.subReplyLv or 0
    local subReplyFire = self.subReplyFire or 0
    local hpCurativeRate = self.info:getValue("hpCurativeRate", true)
    return 1 + hpCurativeRate - math.min(subReplyLv + subReplyFire, 0.8)
end

function GamePlayer:getDamageBonus(damageType)
    Plugins.CallTargetPluginFunc("imbue", "setExtraDamageBonus", self, damageType)
    local extraDamageBonus = self.extraDamageBonus or 0
    self.extraDamageBonus = 0
    local damageBonus = self.info:getValue("commonDamageBonus", true)
    if damageType == "player" then
        damageBonus = damageBonus + self.info:getValue("meleeDamageBonus", true)
    elseif damageType == "arrow" then
        damageBonus = damageBonus + self.info:getValue("arrowDamageBonus", true)
    end
    damageBonus = damageBonus + extraDamageBonus
    return damageBonus
end

function GamePlayer:getDamageFixedValue(damageType)
    local damageFixedValue = self.info:getValue("commonDamageFixedValue", true)
    if damageType == "player" then
        damageFixedValue = damageFixedValue + self.info:getValue("meleeDamageFixedValue", true) + self.info:getValue("buffMeleeDamageFixedValue", true)
    elseif damageType == "arrow" then
        damageFixedValue = damageFixedValue + self.info:getValue("arrowDamageFixedValue", true)
    end
    return damageFixedValue
end

function GamePlayer:getPiercingArmor(damageType)
    local piercingArmor = self.info:getValue("commonPiercingArmor", true)
    if damageType == "player" then
        piercingArmor = piercingArmor + self.info:getValue("meleePiercingArmor", true)
    elseif damageType == "arrow" then
        piercingArmor = piercingArmor + self.info:getValue("arrowPiercingArmor", true)
    end
    return piercingArmor
end

function GamePlayer:getAddKnockBackValue(hurter)
    local addKnockBackValue = self.info:getValue("commonAddKnockBackRate", true)
    if hurter.damageType == "player" then
        addKnockBackValue = addKnockBackValue + self.info:getValue("meleeAddKnockBackRate", true)
    elseif hurter.damageType == "arrow" then
        addKnockBackValue = addKnockBackValue + self.info:getValue("arrowAddKnockBackRate", true)
    end
    addKnockBackValue = addKnockBackValue - hurter.info:getValue("subKnockBackValue", true)
    return addKnockBackValue
end

function GamePlayer:getReduceHurt()
    Plugins.CallTargetPluginFunc("imbue", "setExtraReduceHurt", self)
    local extraReduceHurt = self.extraReduceHurt or 0
    local reduceHurt = self.info:getValue("commonReduceHurt", true) + extraReduceHurt
    self.extraReduceHurt = 0
    return reduceHurt
end

function GamePlayer:getAddArmorValue()
    local addArmorValue = self.info:getValue("addArmorValue", true)
    return addArmorValue
end

function GamePlayer:getAddedCrit(damageType)
    local addedCrit = self.info:getValue("commonAddedCrit", true)
    if damageType == "player" then
        addedCrit = addedCrit + self.info:getValue("meleeAddedCrit", true)
    elseif damageType == "arrow" then
        addedCrit = addedCrit + self.info:getValue("arrowAddedCrit", true)
    end
    return addedCrit
end

function GamePlayer:checkWhetherCrit(damageType)
    local crit = false
    if damageType == "explosion.player" or damageType == "explosion" then
        return crit
    end
    local random_num = HostApi.random("crit", 1, 10000)
    local critExtraHurtPro = GameConfig.critExtraHurtPro
    critExtraHurtPro = critExtraHurtPro + self:getAddedCrit(damageType)
    if random_num <= critExtraHurtPro then
        crit = true
    end
    return crit
end

function GamePlayer:getCritDamageFactor(hurter, damageType)
    local critDamage = GameConfig.critDamageFactor + self.info:getValue("commonCritDamage", true)
    if damageType == "player" then
        critDamage = critDamage + self.info:getValue("meleeCritDamage", true)
    elseif damageType == "arrow" then
        critDamage = critDamage + self.info:getValue("arrowCritDamage", true)
    end
    critDamage = critDamage - hurter.info:getValue("subCritDamage", true)
    if critDamage < 1 then
        critDamage = 1
    end
    return critDamage
end

function GamePlayer:checkParry()
    local success = false
    local random_num = HostApi.random("parry", 1, 10000)
    local parryPro = GameConfig.parryPro
    parryPro = parryPro + self.info:getValue("incrtParry", true)
    if random_num <= parryPro then
        success = true
    end
    return success
end

function GamePlayer:getParryDamageFactor()
    local subDamageFactor = GameConfig.parrySubDamageFactor
    subDamageFactor = subDamageFactor + self.info:getValue("incrParrySubDamage", true)
    return subDamageFactor
end


function GamePlayer:getSuckBloodRate(damageType)
    local suckBlood = self.info:getValue("commonSuckBlood", true)
    if damageType == "player" then
        suckBlood = suckBlood + self.info:getValue("meleeSuckBlood", true)
    elseif damageType == "arrow" then
        suckBlood = suckBlood + self.info:getValue("arrowSuckBlood", true)
    end
    return suckBlood
end

function GamePlayer:onBloodsuckingByHurtValue(hurtValue, damageType)
    local rate = self:getSuckBloodRate(damageType)
    if rate > 0 and not self.banCureBuff then
        local suckBloodValue = hurtValue * rate
        local subReplyLv = self:getCurativeRate()
        local addHp = suckBloodValue * subReplyLv
        self:addHealth(addHp)

        if self and self.showSuckBloodAndSubHealthMessage then
            self:sendPacket({
                pid = "showToast",
                content = "吸血+" .. addHp
            })
        end
    end
end

function GamePlayer:onKillRestoreHp()
    local restoreHpRate = self.info:getValue("killRestoreHpRate", true)
    if restoreHpRate > 0 and not self.banCureBuff then
        local maxHp = self:getMaxHealth()
        local restoreHp = maxHp * restoreHpRate
        local subReplyLv = self:getCurativeRate()
        local addHp = restoreHp * subReplyLv
        self:addHealth(addHp)
    end
end

function GamePlayer:onKillGetIron()
    local ironNum = self.info:getValue("killGetIron", true)
    if ironNum > 0 then
        self:addItem(ItemID.INGOT_GOLD, ironNum)
    end
end

function GamePlayer:subExtraShield(damage)
    if self.curExtraShield > 0 then
        if self.curExtraShield - damage > 0 then
            self.curExtraShield = self.curExtraShield - damage
            ImbueManager:setImbueCache(self.userId, "curExtraShield", self.curExtraShield)
            self:updateApple()
            return 0
        else
            local result = damage - self.curExtraShield
            self.curExtraShield = 0
            ImbueManager:setImbueCache(self.userId, "curExtraShield", self.curExtraShield)
            self:updateApple()
            return result
        end
    end
    return damage
end

function GamePlayer:joinDamageFormula(attacker, damageType, hurtValue)
    local result = 0
    local damageFixedValueResult = 0
    if damageType == "fall" then
        local initHurtValue = hurtValue - 1
        if initHurtValue <= 0 then
            return result
        end
        local lessFallVal = self.info:getValue("lessFallVal", true)
        result = initHurtValue * math.max(( 1 - lessFallVal), 0)
        return result
    end

    ---百分比免伤
    local reduceHurt = self:getReduceHurt()
    --print("----reduceHurt--",reduceHurt)
    ---格挡减伤
    local subDamageFactor = 0
    if self:checkParry() then
        subDamageFactor = self:getParryDamageFactor()
        Plugins.CallTargetPluginFunc("imbue", "onPlayerParry", self)
    end
    --print('---subDamageFactor-',subDamageFactor)
    ---
    ---防御值
    local armorValue = self:getCurArmorValue()
    --print('----armorValue--',armorValue)
    ---
    ---
    local piercingArmor = 0
    local damageBonus = 0
    local critDamageFactor = 1
    local imbueDamage = 0
    local hurtValueProxy = {}
    local damageFixedValue = 0
    if damageType == "explosion" or damageType == "explosion.player" then
        if self == attacker then ---自己的爆炸免伤30%
            hurtValue = hurtValue * ( 1 - 0.3 )
        end
        hurtValueProxy.value = hurtValue
        RuneManager:onHurted(self, hurtValueProxy)
        hurtValue = hurtValueProxy.value
    else
        hurtValueProxy.value = hurtValue
        if attacker then
            RuneManager:onAttack(attacker, hurtValueProxy, damageType, self)
            RuneManager:onHurted(self, hurtValueProxy)
            hurtValue = hurtValueProxy.value
            ---百分比增伤
            damageBonus = attacker:getDamageBonus(damageType)
            --print('--damageBonus----',damageBonus)
            ---
            ---固定值增伤
            damageFixedValue = attacker:getDamageFixedValue(damageType) or 0
            ---
            ---百分比穿甲
            piercingArmor = attacker:getPiercingArmor(damageType)
            RuneManager:onCalcSubArmor(attacker, hurtValueProxy, damageType, self)
            piercingArmor = piercingArmor + (hurtValueProxy.addArmourPiercing or 0)
            attacker.addArmourPiercing = 0
            --print('--piercingArmor----',piercingArmor)
            ---
            ---暴击
            local isCrit = attacker:checkWhetherCrit(damageType)
            --print('--isCrit----',isCrit)
            if isCrit then
                critDamageFactor = attacker:getCritDamageFactor(self, damageType)
                --print('--critDamageFactor----',critDamageFactor)
            end
            ---
            ---主动触发有伤害的天赋，避免无敌机制出现
            imbueDamage = Plugins.CallTargetPluginFunc("imbue", "onGetImbueDamage", attacker.userId, self, damageType)

            ---受击特效
            if damageType ~= "outOfWorld" then
                local effectKey = "beAttackEffect"..tostring(self.userId)
                if isCrit then
                    self:addCustomEffect(effectKey, "g1008_hit_1.effect", GameConfig.beAttackEffectTime * 1000)
                else
                    self:addCustomEffect(effectKey, GameConfig.beAttackEffect, GameConfig.beAttackEffectTime * 1000)
                end
            end
        end
    end


    --- injuryAbatement 伤害减免 = 防御力 * （1 - 破甲率） / （防御力 * （1 - 破甲率） + 100）
    --- result 最终伤害 = 伤害 * （ 1 - 最终减伤 ） * （ 1 - 格挡减伤） * （ 1 - 减伤率 ） * （ 1 + 增伤率 ） * （ 暴击加成 ）
    local injuryAbatement = armorValue * math.max((1 - piercingArmor), 0) / (armorValue * math.max((1 - piercingArmor), 0) + 100)
    result = hurtValue * math.max((1 - injuryAbatement), 0) * math.max((1 - subDamageFactor), 0) * math.max((1 - reduceHurt), 0) * (1 + damageBonus) * critDamageFactor
    damageFixedValueResult = damageFixedValue * math.max((1 - injuryAbatement), 0) * math.max((1 - subDamageFactor), 0) * math.max((1 - reduceHurt), 0)
    result = result + imbueDamage + damageFixedValueResult
    result = self:subExtraShield(result)
    result = self:subApple(result)
    if result > 0 then
        self:recordDamageReportData(attacker, damageType, result)
        if self.showAttackAndSubHealthMessage then
            self:sendPacket({
                pid = "showToast",
                isCenter = true,
                content = "受伤-" ..
                        " 防".. self:fixGMShowNum(armorValue)..
                        " 穿甲".. self:fixGMShowNum(piercingArmor)..
                        " 格挡减伤:".. self:fixGMShowNum(subDamageFactor)..
                        " 减伤率:".. self:fixGMShowNum(reduceHurt)..
                        " 伤减:".. self:fixGMShowNum(injuryAbatement)..
                        " 增伤:".. self:fixGMShowNum(damageBonus)..
                        " 暴击加成:".. self:fixGMShowNum(critDamageFactor)..
                        " 伤害:".. self:fixGMShowNum(hurtValue)..
                        " 天赋伤害:".. self:fixGMShowNum(imbueDamage)..
                        " 固伤:"..self:fixGMShowNum(damageFixedValue)..
                        " 最终伤害:".. self:fixGMShowNum(result),
                time = 10000
            })
        end
        if attacker and attacker.showAttackAndSubHealthMessage then
            attacker:sendPacket({
                pid = "showToast",
                isCenter = true,
                content = "造成-" ..
                        " 防".. self:fixGMShowNum(armorValue)..
                        " 穿甲".. self:fixGMShowNum(piercingArmor)..
                        " 格挡减伤:".. self:fixGMShowNum(subDamageFactor)..
                        " 减伤率:".. self:fixGMShowNum(reduceHurt)..
                        " 伤减:".. self:fixGMShowNum(injuryAbatement)..
                        " 增伤:".. self:fixGMShowNum(damageBonus)..
                        " 暴击加成:".. self:fixGMShowNum(critDamageFactor)..
                        " 伤害:".. self:fixGMShowNum(hurtValue)..
                        " 天赋伤害:".. self:fixGMShowNum(imbueDamage)..
                        " 固伤:"..self:fixGMShowNum(damageFixedValue)..
                        " 最终伤害:".. self:fixGMShowNum(result),
                time = 10000
            })
        end
    end
    return result
end

function GamePlayer:fixGMShowNum(num)
    local x, y = math.modf(num)
    if y == 0 then
        return x
    else
        return string.format("%.2f", num)
    end
end

function GamePlayer:getEquipArmorItemIds()
    local inv = self:getInventory()
    local itemIds = {}
    for index = 100, 103 do
        local info = inv:getItemStackInfo(index)
        if info.id > 0 then
            table.insert(itemIds, ItemMapping:getOldItemId(info.id))
        end
    end
    return itemIds
end

function GamePlayer:getCurArmorValue()
    local curArmorValue = 0
    curArmorValue = self:getAddArmorValue()
    local itemIds = self:getEquipArmorItemIds()
    local totalArmorValue = 0
    for _, id in pairs(itemIds) do
        totalArmorValue = totalArmorValue + ItemHelper:getArmorValueByItemId(id)
    end
    curArmorValue = curArmorValue + totalArmorValue
    return curArmorValue
end

function GamePlayer:getCurAttackDamage()
    local attackDamage = GameConfig.baseDamage
    local heldItemId = self:getHeldItemId()
    if heldItemId then
        attackDamage = attackDamage + ItemHelper:getDamageValueByItemId(ItemMapping:getOldItemId(heldItemId))
    end
    return attackDamage
end

function GamePlayer:updateEquipImbues()
    local itemIds = StoreConfig:getEquipArmorGoodsImbueIds(self)
    Plugins.CallTargetPluginFunc("imbue", "loadSpecialImbues", self, "armor", itemIds)
end

function GamePlayer:updateHandImbues()
    local heldItemId = self:getHeldItemId()
    local itemIds = {}
    if heldItemId then
        local oldItemId = ItemMapping:getOldItemId(heldItemId)
        local levelGroup = StoreConfig:getItemLevelGroup(oldItemId)
        if levelGroup then
            local goods = StoreConfig:getUpgradeGoodsCurGoods(self, levelGroup)
            if goods then
                itemIds = goods.ImbueList
            end
        else
            itemIds = StoreConfig:getGoodsImbueIdsByItemId(oldItemId)
        end
    end
    Plugins.CallTargetPluginFunc("imbue", "loadSpecialImbues", self, "heldItem", itemIds)
end

function GamePlayer:showIronConversion(ironNum)
    self:sendPacket({
        pid = "SyncIronConversion",
        data = {
            iron = ironNum,
            page = 3
        }
    })
end

function GamePlayer:getTotalMaxHp()
    local defaultHp = GameConfig.defaultHp or 20
    local addHpPercentage = self.info:getValue("addHpPercentage", true)
    local addHpFixedValue = self.info:getValue("addHpFixedValue", true)
    local buffAddHpFixedValue = self.info:getValue("buffAddHpFixedValue", true)
    local totalHp = (1 + addHpPercentage) * defaultHp + addHpFixedValue + buffAddHpFixedValue
    return totalHp
end

function GamePlayer:getDamageRecordDamageReportData()
    if not self.damageReportData then
        self.damageReportData = {
            weaponDamageMap = {},
            weaponAttackCountMap = {},
            damageTime = 0
        }
    end
    return self.damageReportData
end

function GamePlayer:recordDamageReportData(attacker, damageType, damage)
    if not attacker then
        return
    end
    local damageReportData = self:getDamageRecordDamageReportData()
    local attackItemKey = attacker:getHandItemKey(attacker, damageType)
    damageReportData.attackItemKey = attackItemKey
    damageReportData.damageTime = os.time()

    local attackDamageReportData = attacker:getDamageRecordDamageReportData()
    attackDamageReportData.weaponDamageMap[attackItemKey] = (attackDamageReportData.weaponDamageMap[attackItemKey] or 0) + damage
    attackDamageReportData.weaponAttackCountMap[attackItemKey] = (attackDamageReportData.weaponAttackCountMap[attackItemKey] or 0) + 1
end

function GamePlayer:getHandItemKey(attacker, damageType)
    local level = nil
    local itemKey = ""
    local heldItemId = attacker:getHeldItemId()
    if heldItemId then
        if damageType == "arrow" then
            local oldItemId = ItemMapping:getOldItemId(heldItemId)
            local levelGroup = StoreConfig:getItemLevelGroup(oldItemId)
            if levelGroup then
                local goods = StoreConfig:getUpgradeGoodsCurGoods(self, levelGroup)
                if goods then
                    level = goods.Level
                end
            end
        end
        if level then
            itemKey = heldItemId.."Lv"..level
        else
            itemKey = heldItemId
        end
        return itemKey
    end
end

function GamePlayer:reportDeadDamageData()
    if PlayerManager:isAIPlayer(self) then
        return
    end
    local damageReportData = self:getDamageRecordDamageReportData()
    local deathWeaponKey = nil
    if os.time() - damageReportData.damageTime < 10 then
        deathWeaponKey = damageReportData.attackItemKey
    else
        deathWeaponKey = "fall"
    end
    ServerReportEvent.death_by_weapon(self, deathWeaponKey)
end

function GamePlayer:reportWeaponDamageCount()
    if PlayerManager:isAIPlayer(self) then
        return
    end
    local damageReportData = self:getDamageRecordDamageReportData()
    ServerReportEvent.weapon_damage_count(self, damageReportData.weaponAttackCountMap)
end

function GamePlayer:reportAllWeaponTotalDamage()
    if PlayerManager:isAIPlayer(self) then
        return
    end
    if not self.reportTotalDamage then
        self.reportTotalDamage = true
        local damageReportData = self:getDamageRecordDamageReportData()
        ServerReportEvent.all_weapon_total_damage(self, damageReportData.weaponDamageMap)
    end
end


return GamePlayer

--endregion
