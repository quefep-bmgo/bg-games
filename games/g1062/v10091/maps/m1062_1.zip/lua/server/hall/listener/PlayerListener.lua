local PlayerListener = T(Global, "PlayerListener")
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type HallPlayer
local HallPlayer = require "hall.entity.HallPlayer"

function PlayerListener:init()

    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerAttackedEvent, self.onPlayerHurt)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)
    BaseListener.registerCallBack(CEvents.PlayerDynamicAttrEvent, self.onDynamicAttrInit)

    CEvents.PlayerExchangeItemEvent:registerCallBack(self.onPlayerExchangeItem)
    CEvents.PlayerUseInitSpawnPositionEvent:registerCallBack(self.onPlayerUseInitSpawnPosition)
    CEvents.SendGuideInfoEvent:registerCallBack(self.onSendGuideInfo)
    CEvents.PlayerDropItemEvent:registerCallBack(function()
        return false
    end)
    CEvents.ToolDurableEvent:registerCallBack(function()
        return false
    end)
    Events.PlayerUseActionEvent:registerCallBack(self.onPlayerUseAction)
end

function PlayerListener.onDynamicAttrInit(attr)
    if Platform.isLinux() and attr.isTest then
        return
    end
    if attr.followEnterType ~= 2 then
        ReportEvent.player_attr(attr)
    end
end

function PlayerListener.onPlayerExchangeItem()
    return false
end

function PlayerListener.onPlayerUseInitSpawnPosition(userId, pos, yaw)
    local randomPos = MathUtil:randomDoubleInCircle(GameConfig.waitPos, GameConfig.initPosRange)
    if yaw then
        yaw.value = GameConfig.waitYaw
    end
    pos.x = math.floor(randomPos.x)
    pos.y = math.floor(randomPos.y)
    pos.z = math.floor(randomPos.z)
end

function PlayerListener.onPlayerLogin(clientPeer)
    if EngineVersionSetting.getEngineVersion() <= 10086 then
        return GameOverCode.GameOver
    end
    local player = HallPlayer.new(clientPeer)
    player:init()
    ServerReportEvent.player_login(player)
    return GameOverCode.Success, player, 1
end

---@param player HallPlayer
function PlayerListener.onPlayerLogout(player)
    CreditScoreUtil:onPlayerLogout(player)
    player:reportRankOnQuit()
    if player.isNew then
        ServerReportEvent.new_player_logout(player)
    end
    PlayerCustomInfoUtil:reportOnQuit(player)
    GameMatch:onPlayerQuit(player)
    GameInfoManager:clearInfo("PlayerInfo", player.userId)
    ServerReportEvent.player_logout(player)
end

---@param player HallPlayer
function PlayerListener.onPlayerReady(player)
    DbUtil:getPlayerData(player)
    HostApi.setDisarmament(player.rakssid, true)
    GameInfoManager.Instance():onPlayerReady(player)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:msgGameName()))
    AddMaxHPPrivilege:onPlayerRespawn(player)
    ServerReportEvent.player_ready(player)
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    return false
end

---@param movePlayer EntityPlayerMP
function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return true
    end
    if y <= GameConfig.deathLineY then
        player:teleportPos(GameConfig.waitPos)
    end
    return true
end

function PlayerListener.onSendGuideInfo(rakssid, guideId, guideStatus)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    local guide = { Id = guideId, Status = guideStatus }
    GameGuide:updateStatus(player, guide)
end

function PlayerListener.onPlayerStartGame(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local _ = builder:getParam("gameType")
end

function PlayerListener.onPlayerUseAction(userId, actionId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    CommonPacketSender:sendUseActionToAll(player:getEntityId(), actionId)
end

PlayerListener:init()
