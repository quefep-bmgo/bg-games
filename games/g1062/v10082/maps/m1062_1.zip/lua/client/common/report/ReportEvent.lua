---@param event number event [event name]
---@param event_map table event_map [eg {key1 = value1,key2 = value2, ...}]
local function newDesign(event, event_map)
    GameAnalytics:newDesign(event, event_map)
end

---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@param buttonId number
function ReportEvent.click_activity_page_button(buttonId)
    newDesign("click_activity_page_button", { buttonId = buttonId })
end

---@param buttonId number
function ReportEvent.click_main_button(buttonId)
    newDesign("click_main_button", { buttonId = buttonId })
end

---@param buttonId number
function ReportEvent.click_Mode_button(buttonId)
    newDesign("click_Mode_button", { buttonId = buttonId })
end

---@param buttonId number
function ReportEvent.click_chat_button(buttonId)
    newDesign("click_chat_button", { buttonId = buttonId })
end

---@param type number
function ReportEvent.send_chat_text(type)
    newDesign("send_chat_text", { text_type = type })
end

---@param type number
function ReportEvent.send_chat_emoji(type)
    newDesign("send_chat_emoji", { emoji_type = type })
end

function ReportEvent.click_activity_button()
    newDesign("click_activity_button", {
        total_recharge_cube = PlayerManager:getClientPlayer().total_recharge_cube or 0,
    })
end

function ReportEvent.click_activity_tab(activity_id)
    newDesign("click_activity_tab", {
        total_recharge_cube = PlayerManager:getClientPlayer().total_recharge_cube or 0,
        activity_id = tonumber(activity_id)
    })
end

function ReportEvent.click_activity_lucky_detail(activity_id)
    newDesign("click_activity_lucky_detail", {
        total_recharge_cube = PlayerManager:getClientPlayer().total_recharge_cube or 0,
        activity_id = tonumber(activity_id)
    })
end

function ReportEvent.click_activity_blind_detail(activity_id, box_id)
    newDesign("click_activity_blind_detail", {
        total_recharge_cube = PlayerManager:getClientPlayer().total_recharge_cube or 0,
        activity_id = tonumber(activity_id),
        activity_box_id = tonumber(box_id)
    })
end

function ReportEvent.stay_activity_tab(activity_id, stay_time)
    newDesign("stay_activity_tab", {
        total_recharge_cube = PlayerManager:getClientPlayer().total_recharge_cube or 0,
        activity_id = tonumber(activity_id),
        activity_stay_time = tonumber(stay_time)
    })
end

function ReportEvent.recharge_open(reportKey)
    newDesign("recharge_open", {
        total_recharge_cube = PlayerManager:getClientPlayer().total_recharge_cube or 0,
        report_key = reportKey
    })
end

function ReportEvent.lack_of_money_dialog(reportKey)
    newDesign("lack_of_money_dialog", {
        total_recharge_cube = PlayerManager:getClientPlayer().total_recharge_cube or 0,
        report_key = reportKey
    })
end

function ReportEvent.complete_guide(node_id, progress_id)
    newDesign("complete_guide", { node_id = tonumber(node_id), progress_id = tonumber(progress_id) })
end

ClientReportEvent = ReportEvent
