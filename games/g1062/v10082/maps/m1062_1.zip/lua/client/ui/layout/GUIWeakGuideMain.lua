---@class UIWeakGuideMainLayout : IGUILayout
local UIWeakGuideMainLayout = class("UIWeakGuideMainLayout", IGUILayout)
---@type WeakGuideControl
local WeakGuideControl = T(Global, "WeakGuideControl")

local PosGuideSize = {
    x = 109,
    y = 116
}
local CurPosGuideScale = 1
local onEnlargeScaleTip = false
local enlargeScaleChangeTimes = 20

---@private
function UIWeakGuideMainLayout:ctor()
    self.super.ctor(self, "WeakGuideMain.json")
end

---@private
function UIWeakGuideMainLayout:onLoad()
    self.llPosGuide = self:getChildWindow("WeakGuideMain-PosGuide", GUIType.Layout)
    self.siPosGuideBg = self:getChildWindow("WeakGuideMain-PosGuide-Bg", GUIType.StaticImage)
    self.siPosGuideTop = self:getChildWindow("WeakGuideMain-PosGuide-Top", GUIType.StaticImage)
    self.siPosGuideBottom = self:getChildWindow("WeakGuideMain-PosGuide-Bottom", GUIType.StaticImage)
    self.siPosGuideLeft = self:getChildWindow("WeakGuideMain-PosGuide-Left", GUIType.StaticImage)
    self.siPosGuideRight = self:getChildWindow("WeakGuideMain-PosGuide-Right", GUIType.StaticImage)
    self.stPosGuideText = self:getChildWindow("WeakGuideMain-PosGuide-Text", GUIType.StaticText)
    self.siPosGuideIcon = self:getChildWindow("WeakGuideMain-PosGuide-Icon", GUIType.StaticImage)

    self.llShopGuide = self:getChildWindow("WeakGuideMain-ShopGuide", GUIType.Layout)
    self.siShopGuide1Bg = self:getChildWindow("WeakGuideMain-ShopGuide-1-Bg", GUIType.StaticImage)
    self.siShopGuide1Icon = self:getChildWindow("WeakGuideMain-ShopGuide-1-Icon", GUIType.StaticImage)
    self.siShopGuide1MoneyIcon = self:getChildWindow("WeakGuideMain-ShopGuide-1-Money-Icon", GUIType.StaticImage)
    self.siShopGuide1Price = self:getChildWindow("WeakGuideMain-ShopGuide-1-Price", GUIType.StaticText)
    self.siShopGuide1Num = self:getChildWindow("WeakGuideMain-ShopGuide-1-Num", GUIType.StaticText)
    self.siShopGuide1Effect = self:getChildWindow("WeakGuideMain-ShopGuide-1-Effect", GUIType.StaticImage)
    self.siShopGuide2Bg = self:getChildWindow("WeakGuideMain-ShopGuide-2-Bg", GUIType.StaticImage)
    self.siShopGuide2Icon = self:getChildWindow("WeakGuideMain-ShopGuide-2-Icon", GUIType.StaticImage)
    self.siShopGuide2MoneyIcon = self:getChildWindow("WeakGuideMain-ShopGuide-2-Money-Icon", GUIType.StaticImage)
    self.siShopGuide2Price = self:getChildWindow("WeakGuideMain-ShopGuide-2-Price", GUIType.StaticText)
    self.siShopGuide2Num = self:getChildWindow("WeakGuideMain-ShopGuide-2-Num", GUIType.StaticText)

    self.llShopGuideDesc = self:getChildWindow("WeakGuideMain-ShopGuide-Desc", GUIType.Layout)
    self.stShopName = self:getChildWindow("WeakGuideMain-Shop-Name", GUIType.StaticText)
    self.siShopIcon = self:getChildWindow("WeakGuideMain-Shop-Icon", GUIType.StaticImage)
    self.stShopDesc = self:getChildWindow("WeakGuideMain-Shop-Desc", GUIType.StaticText)

    self.siShopGuideBuyEffect = self:getChildWindow("WeakGuideMain-ShopGuide-Buy-Effect", GUIType.StaticImage)
    self.siBLockGuideClickEffect = self:getChildWindow("WeakGuideMain-BLockGuide-Click-Effect", GUIType.StaticImage)
    self.siPosGuideEffect = self:getChildWindow("WeakGuideMain-PosGuide-Effect", GUIType.StaticImage)

    self.llPosGuide:SetVisible(false)
    self.llShopGuideDesc:SetVisible(false)
    self.siShopGuide1Bg:SetVisible(false)
    self.siShopGuide2Bg:SetVisible(false)
    self.siShopGuideBuyEffect:SetVisible(false)
    self.siBLockGuideClickEffect:SetVisible(false)
    self.siPosGuideEffect:SetVisible(false)

    self.root:SetLevel(51)
    self:initView()
    self:initEvent()
end

---@private
function UIWeakGuideMainLayout:initView()
    self.stPosGuideText:SetText(Lang:getString(""))
end

---@private
function UIWeakGuideMainLayout:initEvent()
    self.siShopGuide1Bg:registerEvent(GUIEvent.Click, function()
        self:onClickShopGuide(self.siShopGuide1Bg, 1)
    end)
    self.siShopGuide2Bg:registerEvent(GUIEvent.Click, function()
        self:onClickShopGuide(self.siShopGuide2Bg, 2)
    end)

    self.siShopGuide1Bg:registerEvent(GUIEvent.LongTouchStart, function()
        self:onLongTouchShopGuide(1)
    end)
    self.siShopGuide2Bg:registerEvent(GUIEvent.LongTouchStart, function()
        self:onLongTouchShopGuide(2)
    end)

    self.siShopGuide1Bg:registerEvent(GUIEvent.LongTouchEnd, function()
        self.llShopGuideDesc:SetVisible(false)
    end)
    self.siShopGuide2Bg:registerEvent(GUIEvent.LongTouchEnd, function()
        self.llShopGuideDesc:SetVisible(false)
    end)

    self.siShopGuide1Bg:registerEvent(GUIEvent.Release, function()
        self.llShopGuideDesc:SetVisible(false)
    end)
    self.siShopGuide2Bg:registerEvent(GUIEvent.Release, function()
        self.llShopGuideDesc:SetVisible(false)
    end)
end

------------------------ 坐标引导 --------------------------------
---@param screenPos Vector2
---@param direction number
---@param scale number
function UIWeakGuideMainLayout:setPosWeakGuidePos(screenPos, direction, scale)
    LuaTimer:cancel(self.changeGuidePosKey)
    CurPosGuideScale = scale
    if not onEnlargeScaleTip then
        self.siPosGuideBg:SetWidth({ 0, PosGuideSize.x * CurPosGuideScale })
        self.siPosGuideBg:SetHeight({ 0, PosGuideSize.y * CurPosGuideScale })
    end

    self.siPosGuideBg:SetXPosition({ screenPos.x - 0.5, 0 })
    self.siPosGuideBg:SetYPosition({ screenPos.y - 0.5, 0 })

    self.siPosGuideTop:SetVisible(false)
    self.siPosGuideBottom:SetVisible(false)
    self.siPosGuideLeft:SetVisible(false)
    self.siPosGuideRight:SetVisible(false)
    self.stPosGuideText:SetVisible(false)
    if direction == Define.Direction.Top then
        self.siPosGuideTop:SetVisible(true)
    elseif direction == Define.Direction.Bottom then
        self.siPosGuideBottom:SetVisible(true)
    elseif direction == Define.Direction.Left then
        self.siPosGuideLeft:SetVisible(true)
    elseif direction == Define.Direction.Right then
        self.siPosGuideRight:SetVisible(true)
    else
        self.stPosGuideText:SetVisible(true)
    end
end

function UIWeakGuideMainLayout:setPosWeakGuide(icon, tip, effect)
    if effect and #effect > 7 then
        self.siPosGuideEffect:SetEffectName(effect)
        self.siPosGuideEffect:SetVisible(true)
    else
        self.siPosGuideEffect:SetVisible(false)
    end
    LuaTimer:cancel(self.changeGuidePosKey)
    self.stPosGuideText:SetText(Lang:getString(tip))
    self.siPosGuideIcon:SetImage(icon)
    self.llPosGuide:SetVisible(true)
end

function UIWeakGuideMainLayout:hidePosWeakGuidePos()
    LuaTimer:cancel(self.changeGuidePosKey)
    self.llPosGuide:SetVisible(false)
end

function UIWeakGuideMainLayout:enlargeScaleTip()
    LuaTimer:cancel(self.changePosGuideScaleKey)
    onEnlargeScaleTip = true
    local times = 1
    self.changePosGuideScaleKey = LuaTimer:scheduleTimer(function()
        local scale = math.sin((times) / enlargeScaleChangeTimes * math.pi) * 0.6
        self.siPosGuideBg:SetWidth({ 0, PosGuideSize.x * (CurPosGuideScale + scale) })
        self.siPosGuideBg:SetHeight({ 0, PosGuideSize.y * (CurPosGuideScale + scale) })

        if times == enlargeScaleChangeTimes then
            onEnlargeScaleTip = false
        end
        times = times + 1
    end, 30, enlargeScaleChangeTimes)
end

------------------------ 商店引导 --------------------------------

---设置商店引导数据
---@param data ShopWeakGuideData[]
function UIWeakGuideMainLayout:setShopGuideData(data)
    if data[1] then
        self.siShopGuide1Bg:SetVisible(true)
        local goods = StoreConfig:getGoodsById(data[1].goodsId)
        if #goods.showDetail.image > 10 then
            self.siShopGuide1Icon:SetRenderAsBlock(false)
            self.siShopGuide1Icon:SetImage(goods.showDetail.image)
        else
            if goods.ItemId > 0 then
                GuiItemStack.showItemIcon(self.siShopGuide1Icon, goods.ItemId, 0, "")
            else
                self.siShopGuide1Icon:SetRenderAsBlock(false)
                self.siShopGuide1Icon:SetImage("")
            end
        end

        self.siShopGuide1Price:SetText(goods.Price)
        self.siShopGuide1Num:SetText(goods.Count)

        local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
        if currency then
            if currency.ItemId > 0 then
                GuiItemStack.showItemIcon(self.siShopGuide1MoneyIcon, currency.ItemId, 0, "")
            elseif currency.RealId > 0 then
                self.siShopGuide1MoneyIcon:SetImage(PayHelper.getMoneyIcon(currency.RealId))
            else
                self.siShopGuide1MoneyIcon:SetImage("")
            end
        else
            self.siShopGuide1MoneyIcon:SetImage("")
        end
    else
        self.siShopGuide1Bg:SetVisible(false)
    end

    if data[2] then
        self.siShopGuide2Bg:SetVisible(true)
        local goods = StoreConfig:getGoodsById(data[2].goodsId)
        if #goods.showDetail.image > 10 then
            self.siShopGuide2Icon:SetRenderAsBlock(false)
            self.siShopGuide2Icon:SetImage(goods.showDetail.image)
        else
            if goods.ItemId > 0 then
                GuiItemStack.showItemIcon(self.siShopGuide2Icon, goods.ItemId, 0, "")
            else
                self.siShopGuide2Icon:SetRenderAsBlock(false)
                self.siShopGuide2Icon:SetImage("")
            end
        end

        self.siShopGuide2Price:SetText(goods.Price)
        self.siShopGuide2Num:SetText(goods.Count)

        local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
        if currency then
            if currency.ItemId > 0 then
                GuiItemStack.showItemIcon(self.siShopGuide2MoneyIcon, currency.ItemId, 0, "")
            elseif currency.RealId > 0 then
                self.siShopGuide2MoneyIcon:SetImage(PayHelper.getMoneyIcon(currency.RealId))
            else
                self.siShopGuide2MoneyIcon:SetImage("")
            end
        else
            self.siShopGuide2MoneyIcon:SetImage("")
        end
    else
        self.siShopGuide2Bg:SetVisible(false)
    end
end

---点击引导购买商品
---@param startWindow GUIWindow
---@param index number
function UIWeakGuideMainLayout:onClickShopGuide(startWindow, index)
    local fun = function(itemId)
        LuaTimer:scheduleTimer(function()
            self:onBuyShopGuideItemSuccess(itemId, startWindow)
        end, 100, 1)
    end

    WeakGuideControl:onTryBuyGuideGoods(index, fun)
end

---购买成功，播放购买成功动画
---@param itemId number
---@param startWindow GUIWindow
function UIWeakGuideMainLayout:onBuyShopGuideItemSuccess(itemId, startWindow)
    if self.siShopGuideBuyEffect:IsVisible() then
        return
    end

    --local startArea = startWindow:GetRenderArea()
    --local startPos = {
    --    x = (startArea[1] + startArea[3]) / 2 - 34,
    --    y = (startArea[2] + startArea[4]) / 2 - 68
    --}

    local slotIndex = 0
    ---@type InventoryPlayer
    local inv = Game:getPlayer():getInventory()
    for i = 0, 8 do
        local itemStackInfo = inv:getHotBarInventory(i)
        local slotItemId = itemStackInfo.id
        local item = Item.getItemById(slotItemId)
        if item then
            local class = item:getClassName()
            if class == "ItemBlockImp" and slotItemId > 2000 then
                slotItemId = slotItemId - 1000
            end
        end

        if slotItemId == itemId then
            slotIndex = i
            break
        end
    end

    local endWindow
    if slotIndex == 0 then
        endWindow = self:getChildWindow("Main-ToggleInventoryButton", GUIType.StaticImage)
    else
        local slotTable = self:getChildWindow("Main-VisibleBar-SlotTable", GUIType.SlotTable)
        endWindow = slotTable:GetItemSlot(0, slotIndex)
    end

    local endArea = endWindow:GetRenderArea()
    local endPos = {
        x = (endArea[1] + endArea[3]) / 2 - 34,
        y = (endArea[2] + endArea[4]) / 2 - 68
    }

    self.siShopGuideBuyEffect:SetXPosition({ 0, endPos.x })
    self.siShopGuideBuyEffect:SetYPosition({ 0, endPos.y })

    self.siShopGuideBuyEffect:SetVisible(true)
    self.siShopGuideBuyEffect:SetEffectName("g1008_ui_guide_light_4.effect")
    self.siShopGuideBuyEffect:PlayEffect()

    LuaTimer:cancel(self.buyEffectKey)
    self.buyEffectKey = LuaTimer:scheduleTimer(function()
        self.siShopGuideBuyEffect:SetVisible(false)
    end, 1300, 1)

    --local function getInterpolation(startPos, endPos, times)
    --    local middlePos = {
    --        x = startPos. x + (endPos.x - startPos.x) / 100 * times,
    --        y = startPos. y + (endPos.y - startPos.y) / 100 * times
    --    }
    --    return middlePos
    --end

    --self.siShopGuideBuyEffect:SetEffectName("g1008_ui_guide_light_4.effect")
    --LuaTimer:scheduleTimer(function()
    --    self.siShopGuideBuyEffect:SetEffectName("g1008_ui_guide_light_3.effect")
    --    local times = 1
    --    local maxTimes = 140
    --    LuaTimer:cancel(self.moveBuyEffectKey)
    --
    --    self.moveBuyEffectKey = LuaTimer:scheduleTimer(function()
    --        if times <= 100 then
    --            local middlePos = getInterpolation(startPos, endPos, times)
    --            self.siShopGuideBuyEffect:SetXPosition({ 0, middlePos.x })
    --            self.siShopGuideBuyEffect:SetYPosition({ 0, middlePos.y })
    --        end
    --
    --        if times == 110 and times < maxTimes then
    --            self.siShopGuideBuyEffect:SetEffectName("g1008_ui_guide_light_2.effect")
    --        end
    --
    --        if times >= maxTimes then
    --            self.siShopGuideBuyEffect:SetEffectName("")
    --            self.siShopGuideBuyEffect:SetVisible(false)
    --        end
    --        times = times + 1
    --    end, 8, maxTimes)
    --end, 250, 1)
end

---引导点击快捷栏
function UIWeakGuideMainLayout:showGuideClickHotBarCloth()
    if self.siBLockGuideClickEffect:IsVisible() then
        return
    end
    local slotIndex = 0
    ---@type InventoryPlayer
    local inv = Game:getPlayer():getInventory()
    for i = 0, 8 do
        local itemStackInfo = inv:getHotBarInventory(i)
        local slotItemId = itemStackInfo.id
        local item = Item.getItemById(slotItemId)
        if item then
            local class = item:getClassName()
            if class == "ItemBlockImp" and slotItemId > 2000 then
                slotItemId = slotItemId - 1000
            end
        end
        slotItemId = ItemMapping:getOldItemId(slotItemId)
        if slotItemId == BlockID.CLOTH then
            slotIndex = i
            break
        end
    end
    if slotIndex == 0 then
        return
    end

    local slotTable = self:getChildWindow("Main-VisibleBar-SlotTable", GUIType.SlotTable)
    local endWindow = slotTable:GetItemSlot(0, slotIndex)

    local endArea = endWindow:GetRenderArea()
    local endPos = {
        x = (endArea[1] + endArea[3]) / 2 - 34,
        y = (endArea[2] + endArea[4]) / 2 - 68
    }

    self.siBLockGuideClickEffect:SetXPosition({ 0, endPos.x })
    self.siBLockGuideClickEffect:SetYPosition({ 0, endPos.y })

    self.siBLockGuideClickEffect:SetVisible(true)
    self.siBLockGuideClickEffect:SetEffectName("g1008_ui_guide_light_4.effect")
    self.siBLockGuideClickEffect:PlayEffect()
end

---引导点击快捷栏
function UIWeakGuideMainLayout:hideGuideClickHotBar()
    self.siBLockGuideClickEffect:SetVisible(false)
end

---引导点击快捷栏
function UIWeakGuideMainLayout:isGuideClickHotBar()
    return  self.siBLockGuideClickEffect:IsVisible()
end

function UIWeakGuideMainLayout:onLongTouchShopGuide(index)
    local data = WeakGuideControl:getGuideGoodsByIndex(index)
    local goods = StoreConfig:getGoodsById(data.goodsId)
    self.stShopName:SetText(Lang:getString(goods.Name))
    self.stShopDesc:SetText(Lang:getString(goods.Desc))
    local High = self.stShopDesc:GetTextStringHigh()
    self.llShopGuideDesc:SetHeight({ 0, 95 + High })
    if #goods.Image > 10 then
        self.siShopIcon:SetRenderAsBlock(false)
        self.siShopIcon:SetImage(goods.Image)
    else
        if goods.ItemId > 0 then
            GuiItemStack.showItemIcon(self.siShopIcon, goods.ItemId, 0, "")
        else
            self.siShopIcon:SetRenderAsBlock(false)
            self.siShopIcon:SetImage("")
        end
    end

    self.llShopGuideDesc:SetVisible(true)
end

return UIWeakGuideMainLayout
