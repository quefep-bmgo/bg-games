---@class GUINumberItem : IGUIWindow
local GUINumberItem = class("GUINumberItem", IGUIWindow)

--映射数字图集名
local numberStr = "set:bed_war_number.json image:"

function GUINumberItem:ctor(number, numStr)
    self.numStr = numStr or numberStr
    self.number = number
    self.super.ctor(self, "NumberItem.json")
end

function GUINumberItem:onLoad()
    self.ivNumber = DynamicCast.dynamicCastWindow(GUIType.StaticImage, self.root)
    self.ivNumber:setMaterial(20001)
    self.ivNumber:SetImage(self.numStr .. self.number)
end

return GUINumberItem