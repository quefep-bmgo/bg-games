---@class GUICreditScoreLevelItemWindow : IGUIWindow
local GUICreditScoreLevelItemWindow = class("GUICreditScoreLevelItemWindow", IGUIWindow)

---@private
function GUICreditScoreLevelItemWindow:ctor(...)
    self.super.ctor(self, "CreditScoreLevelItem.json", ...)
end

---@private
function GUICreditScoreLevelItemWindow:onLoad()
    self.siNormalBg = self:getChildWindowByName("CreditScoreLevelItem-Normal-Bg", GUIType.StaticImage)
    self.siSelectBg = self:getChildWindowByName("CreditScoreLevelItem-Select-Bg", GUIType.StaticImage)
    self.siSelectIcon = self:getChildWindowByName("CreditScoreLevelItem-Select-Icon", GUIType.StaticImage)
    self.siLevelBg = self:getChildWindowByName("CreditScoreLevelItem-Level-Bg", GUIType.StaticImage)
    self.siLevelIcon = self:getChildWindowByName("CreditScoreLevelItem-Level-Icon", GUIType.StaticImage)
    self.stLevelText = self:getChildWindowByName("CreditScoreLevelItem-Level-Text", GUIType.StaticText)
    self.stScoreText = self:getChildWindowByName("CreditScoreLevelItem-Score-Text", GUIType.StaticText)
    self.siRewardKeyBg = self:getChildWindowByName("CreditScoreLevelItem-Reward-Key-Bg", GUIType.StaticImage)
    self.siRewardKey = self:getChildWindowByName("CreditScoreLevelItem-Reward-Key", GUIType.StaticImage)
    self.stRewardKeyText = self:getChildWindowByName("CreditScoreLevelItem-Reward-Key-Text", GUIType.StaticText)
    self.siRewardExpBg = self:getChildWindowByName("CreditScoreLevelItem-Reward-Exp-Bg", GUIType.StaticImage)
    self.siRewardExp = self:getChildWindowByName("CreditScoreLevelItem-Reward-Exp", GUIType.StaticImage)
    self.stRewardExpText = self:getChildWindowByName("CreditScoreLevelItem-Reward-Exp-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUICreditScoreLevelItemWindow:initView()
    self.siSelectBg:SetVisible(false)
end

---@private
function GUICreditScoreLevelItemWindow:initEvent()

end

---@param data CreditScoreData
function GUICreditScoreLevelItemWindow:onDataChanged(data)
    self.siLevelIcon:SetImage(data.icon)
    self.stLevelText:SetText(data.level)
    self.stScoreText:SetText(data.scoreInterval[1] .. "~" .. data.scoreInterval[2])
    if data.keyBuff < 0 then
        self.stRewardKeyText:SetTextColor(Color.RED)
        self.stRewardKeyText:SetText(data.keyBuff .. "key")
    else
        self.stRewardKeyText:SetTextColor(Color.WHITE)
        self.stRewardKeyText:SetText("+" .. data.keyBuff .. "key")
    end
    self.stRewardExpText:SetText("x" .. data.expBuff .. "exp")

    local userInfo = UserInfoCache:GetCache(data.curUserId)
    if not userInfo then
        return
    end

    local curCreditScore = userInfo[Define.PlayerCustomInfo.CreditScore] or Define.CreditScore.InitCreditScore
    if curCreditScore < Define.CreditScore.LowerLimit then
        curCreditScore = Define.CreditScore.LowerLimit
    elseif curCreditScore > Define.CreditScore.UpperLimit then
        curCreditScore = Define.CreditScore.UpperLimit
    end

    if curCreditScore >= data.scoreInterval[1] and curCreditScore <= data.scoreInterval[2] then
        self.siSelectBg:SetVisible(true)
        self.siNormalBg:SetVisible(false)
        self.stScoreText:SetTextColor({ 254 / 255, 255 / 255, 184 / 255, 1 })
    else
        self.siSelectBg:SetVisible(false)
        self.siNormalBg:SetVisible(true)
        self.stScoreText:SetTextColor({ 51 / 255, 59 / 255, 74 / 255, 1 })
    end
end

return GUICreditScoreLevelItemWindow
