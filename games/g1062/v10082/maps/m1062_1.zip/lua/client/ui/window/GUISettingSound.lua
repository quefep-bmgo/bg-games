---@class GUISettingSound : IGUIWindow
local GUISettingSound = class("GUISettingSound", IGUIWindow)

local CheckTextColor = {
    Select = { 39 / 255, 45 / 255, 92 / 255, 1 },
    Normal = { 122 / 255, 121 / 255, 141 / 255, 1 },
}

function GUISettingSound:ctor()
    self.super.ctor(self, "BedWarSettingSound.json")
end
function GUISettingSound:onLoad()
    self.bgSlider = self:getChildWindowByName("BedWarSettingSound-BackGround-Slider", GUIType.Slider)
    self.bgSliderText = self:getChildWindowByName("BedWarSettingSound-BackGround-Slider-Text", GUIType.StaticText)
    self.effectSlider = self:getChildWindowByName("BedWarSettingSound-Effect-Slider", GUIType.Slider)
    self.effectSliderText = self:getChildWindowByName("BedWarSettingSound-Effect-Slider-Text", GUIType.StaticText)
    self.bgBox = self:getChildWindowByName("BedWarSettingSound-BackGround-Open", GUIType.CheckBox)
    self.effectBox = self:getChildWindowByName("BedWarSettingSound-Effect-Open", GUIType.CheckBox)

    self:getChildWindowByName("BedWarSettingSound-Title", GUIType.StaticText):SetText(Lang:getString("gui.setting.sound.title"))
    self:getChildWindowByName("BedWarSettingSound-BackGround-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.music.title"))
    self:getChildWindowByName("BedWarSettingSound-BackGround", GUIType.StaticText):SetText(Lang:getString("gui.setting.music.volume"))
    self:getChildWindowByName("BedWarSettingSound-Effect-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.effect.title"))
    self:getChildWindowByName("BedWarSettingSound-Effect", GUIType.StaticText):SetText(Lang:getString("gui.setting.effect.volume"))
    self:getChildWindowByName("BedWarSettingSound-BackGround-Off-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.off"))
    self:getChildWindowByName("BedWarSettingSound-BackGround-On-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.on"))
    self:getChildWindowByName("BedWarSettingSound-Effect-Off-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.off"))
    self:getChildWindowByName("BedWarSettingSound-Effect-On-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.on"))

    self.bgGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
    self.soundGroup = RadioBoxGroup.new(SoundConfig.switchSetting)

    self:register()
end

function GUISettingSound:register()
    self.bgGroup:addCheckBox(self:getChildWindowByName("BedWarSettingSound-BackGround-Open", GUIType.CheckBox), function(checked)
        self:openBackGroundMusic(checked)
        local offText = self:getChildWindowByName("BedWarSettingSound-BackGround-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarSettingSound-BackGround-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
        offText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        SystemSettingRecord.defaultBackGroundSwitch = self.bgGroup:getCurIndex()
        onSaveSetting()
    end)
    self.bgGroup:addCheckBox(self:getChildWindowByName("BedWarSettingSound-BackGround-Close", GUIType.CheckBox), function(checked)
        self:openBackGroundMusic(not checked)
        local offText = self:getChildWindowByName("BedWarSettingSound-BackGround-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarSettingSound-BackGround-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        offText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)

        SystemSettingRecord.defaultBackGroundSwitch = self.bgGroup:getCurIndex()
        onSaveSetting()
    end)

    self.soundGroup:addCheckBox(self:getChildWindowByName("BedWarSettingSound-Effect-Open", GUIType.CheckBox), function(checked)
        self:openEffect(checked)
        local offText = self:getChildWindowByName("BedWarSettingSound-Effect-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarSettingSound-Effect-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
        offText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        SystemSettingRecord.defaultEffectSwitch = self.soundGroup:getCurIndex()
        onSaveSetting()
    end)
    self.soundGroup:addCheckBox(self:getChildWindowByName("BedWarSettingSound-Effect-Close", GUIType.CheckBox), function(checked)
        self:openEffect(not checked)
        local offText = self:getChildWindowByName("BedWarSettingSound-Effect-Off-Text", GUIType.StaticText)
        local onText = self:getChildWindowByName("BedWarSettingSound-Effect-On-Text", GUIType.StaticText)
        onText:SetTextColor(checked and CheckTextColor.Normal or CheckTextColor.Select)
        offText:SetTextColor(checked and CheckTextColor.Select or CheckTextColor.Normal)
        SystemSettingRecord.defaultEffectSwitch = self.soundGroup:getCurIndex()
        onSaveSetting()
    end)

    self.bgSlider:registerEvent(GUIEvent.TouchMove, function()
        self:refreshBackGround()

    end)

    self.bgSlider:registerEvent(GUIEvent.TouchDown, function()
        self:refreshBackGround()
    end)

    self.effectSlider:registerEvent(GUIEvent.TouchMove, function()
        self:refreshEffect()
    end)

    self.effectSlider:registerEvent(GUIEvent.TouchDown, function()
        self:refreshEffect()
    end)
end

function GUISettingSound:openBackGroundMusic(open)
    SoundSystem.Instance():setBackgroundMusicSwitch(open)
end

function GUISettingSound:openEffect(open)
    ClientHelper.putBoolPrefs("SoundEffectSwitch", open)
end

function GUISettingSound:refreshEffect(progress)
    local curProgress = progress or self.effectSlider:GetProgress()
    if progress then
        self.effectSlider:SetProgress(progress)
    end

    self.effectSliderText:SetText(math.floor(curProgress * 10))
    self.effectSliderText:SetXPosition({curProgress, -25})
    self.effectSlider:SetHeaderImage(math.floor(curProgress * 10) / 10 == GUIBedWarSetting.defaultSetting.defaultEffectVolume
            and "set:bed_war_3_button.json image:btn_0_settings01"
            or "set:bed_war_3_button.json image:btn_0_settings")
    SoundSystem.Instance():setEffectsVolume(curProgress)
    SystemSettingRecord.defaultEffectVolume = curProgress
    onSaveSetting()
end

function GUISettingSound:refreshBackGround(progress)
    local curProgress = progress or self.bgSlider:GetProgress()
    if progress then
        self.bgSlider:SetProgress(progress)
    end
    self.bgSliderText:SetText(math.floor(curProgress * 10))
    self.bgSliderText:SetXPosition({curProgress, -25})
    self.bgSlider:SetHeaderImage(math.floor(curProgress * 10) / 10 == GUIBedWarSetting.defaultSetting.defaultBackGroundVolume
            and "set:bed_war_3_button.json image:btn_0_settings01"
            or "set:bed_war_3_button.json image:btn_0_settings")
    SoundSystem.Instance():setBackgroundMusicVolume(curProgress)
    SystemSettingRecord.defaultBackGroundVolume = curProgress
    onSaveSetting()
end

return GUISettingSound