---@class GUISceneEditItemWindow : IGUIWindow
local GUISceneEditItemWindow = class("GUISceneEditItemWindow", IGUIWindow)

---@private
function GUISceneEditItemWindow:ctor(...)
	self.super.ctor(self, "SceneEditItem.json", ...)
end

---@private
function GUISceneEditItemWindow:onLoad()
	self:initView()
	self:initEvent()
end

---@private
function GUISceneEditItemWindow:initView()
	self.tvItem = self:getChildWindowByName("GUISceneEditItem", GUIType.StaticText)
end

---@private
function GUISceneEditItemWindow:initEvent()
	self.tvItem:registerEvent(GUIEvent.Click, function()
		if self.data.func ~= "" then
			local params = TableUtil.copyTable(self.data.params or {})
			table.insert(params, self.tvItem)
			GMHelper:callCommand(self.data.func, unpack(params))
		end
	end)
end

---@param data table
function GUISceneEditItemWindow:onDataChanged(data)
	self.data = data
	if self.data.func == "" then
		self.tvItem:SetBackgroundColor(Color.TRANS)
	end
	self.tvItem:SetText(data.name)
end

return GUISceneEditItemWindow
