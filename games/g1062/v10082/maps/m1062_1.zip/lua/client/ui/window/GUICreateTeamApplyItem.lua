---@class GUICreateTeamApplyItemWindow : IGUIWindow
local GUICreateTeamApplyItemWindow = class("GUICreateTeamApplyItemWindow", IGUIWindow)

function GUICreateTeamApplyItemWindow:ctor(...)
	self.super.ctor(self, "CreateTeamApplyItem.json", ...)
end

function GUICreateTeamApplyItemWindow:onLoad()
	self.llHead = self:getChildWindowByName("CreateTeamApplyItem-Head", GUIType.Layout)
	self.stName = self:getChildWindowByName("CreateTeamApplyItem-Name", GUIType.StaticText)
	self.siHonorIcon = self:getChildWindowByName("CreateTeamApplyItem-Honor-Icon", GUIType.StaticImage)
	self.stHonorText = self:getChildWindowByName("CreateTeamApplyItem-Honor-Text", GUIType.StaticText)
	self.btnRejection = self:getChildWindowByName("CreateTeamApplyItem-Rejection", GUIType.Button)
	self.btnOK = self:getChildWindowByName("CreateTeamApplyItem-OK", GUIType.Button)
	self:initView()
	self:initEvent()
end

function GUICreateTeamApplyItemWindow:initView()
	---@type GUIBedWarHead
	self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHead:GetPixelSize().x)
	self.llHead:AddChildWindow(self.winHead.root)
	self.btnRejection:SetText(Lang:getString("gui.button.rejection"))
	self.btnOK:SetText(Lang:getString("gui.button.ok"))
end

function GUICreateTeamApplyItemWindow:initEvent()
	self.btnRejection:registerEvent(GUIEvent.ButtonClick, function()
		if self.rejectionCallback then
			self.rejectionCallback()
		end
	end)
	self.btnOK:registerEvent(GUIEvent.ButtonClick, function()
		if self.okCallback then
			self.okCallback()
		end
	end)
end

---@param data UserInfo
function GUICreateTeamApplyItemWindow:onDataChanged(data)
	self.stName:SetText(data.name)
	self.winHead:setUserInfo(data)
	local cache = UserInfoCache:GetCache(data.userId)
	QualifyingTool.setQualifyingSegmentInListUI(self.siHonorIcon, self.stHonorText, cache.qualifyingData)
end

function GUICreateTeamApplyItemWindow:setRejectionCallback(callback)
	self.rejectionCallback = callback
end

function GUICreateTeamApplyItemWindow:setOKCallback(callback)
	self.okCallback = callback
end

return GUICreateTeamApplyItemWindow
