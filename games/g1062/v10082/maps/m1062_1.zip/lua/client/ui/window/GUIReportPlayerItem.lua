---@class GUIReportPlayerItemWindow : IGUIWindow
local GUIReportPlayerItemWindow = class("GUIReportPlayerItemWindow", IGUIWindow)

---@private
function GUIReportPlayerItemWindow:ctor(...)
    self.super.ctor(self, "ReportPlayerItem.json", ...)
end

---@private
function GUIReportPlayerItemWindow:onLoad()
    self.siTeam = self:getChildWindowByName("ReportPlayerItem-Team", GUIType.StaticImage)
    self.siLine = self:getChildWindowByName("ReportPlayerItem-Line", GUIType.StaticImage)
    self.llHeader = self:getChildWindowByName("ReportPlayerItem-Header", GUIType.Layout)
    self.stName = self:getChildWindowByName("ReportPlayerItem-Name", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIReportPlayerItemWindow:initView()
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
end

---@private
function GUIReportPlayerItemWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if self.playerInfo then
            ReportPlayerContentLayout:setPlayerInfo(self.playerInfo)
        end
    end)
end

---@param playerInfo PlayerInfo
function GUIReportPlayerItemWindow:onDataChanged(playerInfo)
    self.playerInfo = playerInfo
    local cache = UserInfoCache:GetCache(playerInfo.infoKey)
    if cache then
        self.winHead:setUserInfo(cache)
        self.stName:SetText(cache.nickName)
    else
        self.winHead:setUserInfo({
            picUrl = playerInfo:getValue("picUrl"),
            userId = tonumber(playerInfo.infoKey),
        })
        self.stName:SetText(playerInfo:getValue("userName"))
    end
    local config = TeamGUIInfo.getTeamGUI(playerInfo:getValue("teamId") or "1")
    if config then
        self.siTeam:SetImage(config.tab_icon)
    else
        self.siTeam:SetImage("set:bed_war_battle_info.json image:tab_red")
    end
end

return GUIReportPlayerItemWindow
