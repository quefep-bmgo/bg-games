---@class GUIVisitorsInfoItemWindow : IGUIWindow
local GUIVisitorsInfoItemWindow = class("GUIVisitorsInfoItemWindow", IGUIWindow)

function GUIVisitorsInfoItemWindow:ctor(...)
    self.super.ctor(self, "VisitorsInfoItem.json", ...)
end

function GUIVisitorsInfoItemWindow:onLoad()
    self.llHeadShot = self:getChildWindowByName("VisitorsInfoItem-Head-Shot", GUIType.Layout)
    self.stName = self:getChildWindowByName("VisitorsInfoItem-Name", GUIType.StaticText)
    self.siSex = self:getChildWindowByName("VisitorsInfoItem-Sex", GUIType.StaticImage)
    self.siRank = self:getChildWindowByName("VisitorsInfoItem-Rank", GUIType.StaticImage)
    self.stRankName = self:getChildWindowByName("VisitorsInfoItem-Rank-Name", GUIType.StaticText)
    self.stTime = self:getChildWindowByName("VisitorsInfoItem-Time", GUIType.StaticText)
    self:initView()
end

function GUIVisitorsInfoItemWindow:initView()
    ---@type GUIBedWarHead
    self.headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
    self.headItem:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.llHeadShot:AddChildWindow(self.headItem.root)
end

---@param data BedWarUserInfo
function GUIVisitorsInfoItemWindow:onDataChanged(data)
    local visitorInfo = UserInfoCache:GetCache(data.visitorId)
    if not visitorInfo then
        return
    end
    self.headItem:setUserInfo(visitorInfo)
    self.stName:SetText(visitorInfo.name)
    self.siSex:SetImage(Define.SexIcon[visitorInfo.sex])
    QualifyingTool.setQualifyingSegmentInListUI(self.siRank, self.stRankName, visitorInfo.rank)
    if data.day == 0 then
        self.stTime:SetText(Lang:getString("gui.personal.visitors.0day"))
    else
        self.stTime:SetText(data.day .. Lang:getString("gui.personal.visitors.time"))
    end
end

return GUIVisitorsInfoItemWindow
