---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@class GUIIndieMainV3ButtonWindow : IGUIWindow
local GUIIndieMainV3ButtonWindow = class("GUIIndieMainV3ButtonWindow", IGUIWindow)

---@private
function GUIIndieMainV3ButtonWindow:ctor(...)
    self.super.ctor(self, "IndieMainV3Button.json", ...)
end

---@private
function GUIIndieMainV3ButtonWindow:onLoad()
    self.openUI = ""
    self.siIcon = self:getChildWindowByName("IndieMainV3Button-Icon", GUIType.StaticImage)
    self.stText = self:getChildWindowByName("IndieMainV3Button-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIIndieMainV3ButtonWindow:initView()
end

---@private
function GUIIndieMainV3ButtonWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        if self.openFunc and type(self.openFunc) == "function" then
            self.openFunc()
        else
            GUIManager:showWindowByName(self.openUI)
        end
        if self.reportKey then
            ClientReportEvent.click_main_button(self.reportKey)
        end
        if self.openUI == "GameActivityLayout.json" then
            ClientReportEvent.click_activity_button()
        end
    end)
end

function GUIIndieMainV3ButtonWindow:setRightButton()
    self.siIcon:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.root:SetArea({ 0, 0 }, { 0, 0 }, { 0, 40 }, { 0, 40 })
    self.root:SetBackgroundColor(Color.TRANS)
    self.stText:SetVisible(false)
end

---@param data ButtonData
function GUIIndieMainV3ButtonWindow:onDataChanged(data)
    self.openUI = data.uiJson or ""
    self.openFunc = data.uiFunc
    self.siIcon:SetImage(data.icon)
    self.reportKey = data.reportKey
    if data.text then
        self.stText:SetTextColor(data.textColor or Color.WHITE)
        self.stText:SetText(Lang:getString(data.text))
        self.root:SetWidth({ 0, 65 + self.stText:GetTextWidth() })
    else
        self:setRightButton()
    end
    if data.rdKey then
        UIUtils.addRedDot(self.root, data.rdKey, nil, { offset = VectorUtil.newVector2(4, -3) })
    end
end

return GUIIndieMainV3ButtonWindow
