---@class GUIBedWarChatBubbleWindow : IGUIWindow
local GUIBedWarChatBubbleWindow = class("GUIBedWarChatBubbleWindow", IGUIWindow)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")

---@private
function GUIBedWarChatBubbleWindow:ctor(...)
    self.super.ctor(self, "BedWarChatBubble.json", ...)
end

---@private
function GUIBedWarChatBubbleWindow:onLoad()
    self.llBubble = self:getChildWindowByName("BedWarChatBubble", GUIType.Layout)
    self.llBubble:SetLevel(100)
    self.stText = self:getChildWindowByName("BedWarChatBubble-Text", GUIType.StaticText)
    self.siEmoji = self:getChildWindowByName("BedWarChatBubble-Emoji", GUIType.StaticImage)
end

---@param chatMsg ChatMsgData
function GUIBedWarChatBubbleWindow:onDataChanged(chatMsg)
    if chatMsg.type == Define.ChatMsgType.CustomMsg and chatMsg.data.content.type == Define.CustomChatMsgType.EmojiMsg then
        self.stText:SetVisible(false)
        self.siEmoji:SetVisible(true)
        self.llBubble:SetWidth({ 0, 100 })
        self.llBubble:SetHeight({ 0, 115 })
        self.siEmoji:SetImage(chatMsg.data.content.emojiData)
    else
        local text = ChatClient:chatMsgToString(chatMsg, TextFormat.colorBlack, true)
        local width = math.min(200, math.max(self.stText:GetFont():GetTextExtent(text, 1) + 25, 90))
        self.llBubble:SetWidth({ 0, width })
        self.stText:SetVisible(true)
        self.siEmoji:SetVisible(false)
        self.stText:SetText(text)
        self.llBubble:SetHeight({ 0, math.max(62, self.stText:GetTextHeight() + 30) })
    end
end

return GUIBedWarChatBubbleWindow
