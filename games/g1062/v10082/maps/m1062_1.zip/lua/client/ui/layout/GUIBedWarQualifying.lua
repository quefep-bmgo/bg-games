---@class UIBedWarQualifyingLayout : IGUILayout
local UIBedWarQualifyingLayout = class("UIBedWarQualifyingLayout", IGUILayout)
---@type TeamService
local TeamService = T(Global, "TeamService")
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
---@type QualifyingSeasonChallengeRewardConfig
local QualifyingSeasonChallengeRewardConfig = T(Global, "QualifyingSeasonChallengeRewardConfig")

---@private
function UIBedWarQualifyingLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifying.json", parent)
end

---@private
function UIBedWarQualifyingLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingLayout:onLoad()
    self.llBravePoints = self:getChildWindow("BedWarQualifying-Brave-Points", GUIType.Layout)
    self.btnRank = self:getChildWindow("BedWarQualifying-Rank", GUIType.Button)
    self.btnHistoryInfo = self:getChildWindow("BedWarQualifying-History-Info", GUIType.Button)
    self.llRight = self:getChildWindow("BedWarQualifying-Right", GUIType.Layout)
    self.btnQuestion = self:getChildWindow("BedWarQualifying-Question", GUIType.Button)
    self.stLastTimeHint = self:getChildWindow("BedWarQualifying-LastTime-Hint", GUIType.StaticText)
    self.stLastTime = self:getChildWindow("BedWarQualifying-LastTime", GUIType.StaticText)
    self.llHonor = self:getChildWindow("BedWarQualifying-Honor", GUIType.Layout)
    self.stHint = self:getChildWindow("BedWarQualifying-Hint", GUIType.StaticText)
    self.stHint2 = self:getChildWindow("BedWarQualifying-Hint2", GUIType.StaticText)
    self.btnOpenFriends = self:getChildWindow("BedWarQualifying-OpenFriends", GUIType.Button)
    self.llSeasonChallenge = self:getChildWindow("BedWarQualifying-Season-Challenge", GUIType.Layout)
    self.pbSeasonChallengeProgress = self:getChildWindow("BedWarQualifying-Season-Challenge-Progress", GUIType.ProgressBar)
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarQualifyingLayout:initView()
    ---@type GUIBedWarUIReturnControlWindow
    self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.qualifying.title.pos", function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.exit.qualifying.match"))
                    .setRightClickListener(function()
            TeamService:sendLeaveTeam()
        end)        .show()
    end)
    self.root:AddChildWindow(self.llReturn.root)

    ---@class QualifyingSeasonChallengeRewardView
    ---@field icon GUIStaticImage
    ---@field text GUIStaticText
    ---@type QualifyingSeasonChallengeRewardView[]
    self.seasonChallengeRewards = { {}, {}, {} }
    for index, rewardView in pairs(self.seasonChallengeRewards) do
        rewardView.icon = self:getChildWindow("BedWarQualifying-Season-Challenge-Reward" .. index, GUIType.StaticImage)
        rewardView.text = self:getChildWindow("BedWarQualifying-Season-Challenge-Reward-Text" .. index, GUIType.StaticText)
    end
    self.pbSeasonChallengeProgress:SetProgress(0)

    ---@type GUIQualifyingInTeamPlayerItemWindow[]
    self.llPlayers = {}
    local positions = { { 250, 30 }, { 441, -49 }, { 60, -100 }, { 632, -162 } }
    for index = 4, 1, -1 do
        ---@type GUIQualifyingInTeamPlayerItemWindow
        local window = UIHelper.newGameGUIWindow("GUIQualifyingInTeamPlayerItem", self)
        window.root:SetXPosition({ 0, positions[index][1] })
        window.root:SetYPosition({ 0, positions[index][2] })
        window.root:SetVerticalAlignment(VerticalAlignment.Center)
        self.root:AddChildWindow(window.root)
        self.llPlayers[index] = window
    end
    self.stHint:SetText(Lang:getString("gui.qualifying.sub.star.effecting.hint"))
    self.stHint:SetVisible(false)
end

---@private
function UIBedWarQualifyingLayout:initEvent()
    self.btnRank:registerEvent(GUIEvent.ButtonClick, function()
        GUIBedWarHallRankLayout:show(Define.RankKey.QualifyingRank, Define.RankSubType.Global)
    end)
    self.btnHistoryInfo:registerEvent(GUIEvent.ButtonClick, function()
        GUIBedWarQualifyingHistoryLayout:show()
    end)
    self.btnQuestion:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui.qualifying.rule.title")
                    .setContentText(Lang:getString("gui.qualifying.rule.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .setContentAlign(HorizontalAlignment.Left)
                    .show()
    end)
    self.llSeasonChallenge:registerEvent(GUIEvent.Click, function()
        GUIBedWarQualifyingSeasonChallengeLayout:show()
    end)
    self.btnOpenFriends:registerEvent(GUIEvent.ButtonClick, function()
        GUISelectTeamInviteListLayout:show(self.root, true)
    end)
    self:registerEvent(Events.SyncQualifyingDataEvent, function()
        if not self:isShow() then
            return
        end
        self:updateBaseUI()
    end)
end

---只有界面打开着才监听的事件
---@private
function UIBedWarQualifyingLayout:initOpenEvent()
    self:registerEvent(Events.UserJoinTeamEvent, function(userId)
        self:updateTeamPlayerUI()
    end)
    self:registerEvent(Events.UserLeaveTeamEvent, function(userId)
        self:updateTeamPlayerUI()
    end)
    self:registerEvent(Events.TeamOwnerChangeEvent, function()
        self:updateTeamPlayerUI()
    end)
end

---@private
function UIBedWarQualifyingLayout:unregisterOpenEvent()
    self:unregisterEvent(Events.UserJoinTeamEvent)
    self:unregisterEvent(Events.UserLeaveTeamEvent)
    self:unregisterEvent(Events.TeamOwnerChangeEvent)
end

---@private
function UIBedWarQualifyingLayout:onShow()
    self:initOpenEvent()
    self:initBravePoints()
    self:initHonorRank()
    self:updateBaseUI()
    self:setQualifyingWaitMatchUI()
end

---@private
function UIBedWarQualifyingLayout:onHide()
    self:unregisterOpenEvent()
    Events.ShowBackQualifyingEvent:invoke(TeamService:isInTeam(Game:getPlatformUserId()))
end

---@private
function UIBedWarQualifyingLayout:initBravePoints()
    if self.wBravePoints then
        return
    end
    ---@type GUIBedWarQualifyingBravePointsWindow
    self.wBravePoints = UIHelper.newGameGUIWindow("GUIBedWarQualifyingBravePoints")
    self.wBravePoints:setInQualifying()
    self.llBravePoints:AddChildWindow(self.wBravePoints.root)
end

function UIBedWarQualifyingLayout:onTick(frameTime)
    self.wBravePoints.root:SetXPosition({ 0, 150 })
end

---@private
function UIBedWarQualifyingLayout:initHonorRank()
    if self.wHonorRank then
        return
    end
    ---@type GUIBedWarQualifyingSegmentWindow
    self.wHonorRank = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegment", self.llHonor)
    self.wHonorRank:setClickListener(function()
        GUIBedWarQualifyingSegmentIntroductionLayout:show()
    end)
end

---@private
function UIBedWarQualifyingLayout:updateBaseUI()
    WebService:GetQualifyingSegmentConfig(function(_)
        local qualifyingData = CQualifyingController:getQualifyingData()
        if not qualifyingData then
            return
        end
        self.wHonorRank:onDataChanged(qualifyingData)
        self.wBravePoints:onDataChanged(qualifyingData)
        local timeRemaining = qualifyingData.timeRemaining / 1000
        local day = math.floor(timeRemaining / 86400)
        local hour = math.floor((timeRemaining % 86400) / 3600)
        self.stLastTime:SetText(Lang:format("gui.qualifying.last.time.format", day, hour))
        self.stLastTime:SetWidth({ 0, self.stLastTime:GetTextWidth() })
        self.stLastTimeHint:SetText(Lang:getString("gui.qualifying.last.time"))
        if CQualifyingController:isInPosMatch() then
            self.llReturn:setTitle("gui.qualifying.title.pos")
            self.stHint2:SetVisible(true)
            self.stHint2:SetText(Lang:format("gui.qualifying.in.pos.match", CQualifyingController:getPosMatchCount()))
        else
            self.llReturn:setTitle(Lang:getString("gui.qualifying.title") .. ("S" .. qualifyingData.quarter))
            local setting = QualifyingTool.getSubStarBravePointSetting(qualifyingData.segment, qualifyingData.grade)
            self.stHint:SetVisible(CQualifyingController:getBravePoint() >= setting[1])
            self.stHint2:SetVisible(false)
        end
        self:setSeasonChallengeRewards()
    end)
end

function UIBedWarQualifyingLayout:updateTeamPlayerUI()
    if not self:isLoad() then
        return
    end
    for index = 1, 4 do
        local info = TeamService:getTeammateInfo(index)
        self.llPlayers[index]:onDataChanged(info, index)
    end
end

function UIBedWarQualifyingLayout:setSeasonChallengeRewards()
    local qualifyingData = CQualifyingController:getQualifyingData()
    local items = QualifyingSeasonChallengeRewardConfig:getCfgBySeason(qualifyingData.quarter)
    if not items then
        return
    end
    local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
    ---@type QualifyingSeasonChallengeRewardData[]
    local rewards = {}
    if #items <= 3 then
        rewards = items
    else
        for i, item in pairs(items) do
            if item.Score >= score then
                if i == 1 then
                    table.insert(rewards, items[i + 2])
                    table.insert(rewards, items[i + 1])
                    table.insert(rewards, items[i])
                elseif i == #items then
                    table.insert(rewards, items[i])
                    table.insert(rewards, items[i - 1])
                    table.insert(rewards, items[i - 2])
                else
                    table.insert(rewards, items[i + 1])
                    table.insert(rewards, items[i])
                    table.insert(rewards, items[i - 1])
                end
                break
            end
        end
        if #rewards == 0 then
            table.insert(rewards, items[#items])
            table.insert(rewards, items[#items - 1])
            table.insert(rewards, items[#items - 2])
        end
    end
    for index, reward in pairs(rewards) do
        local cfg = RewardConfig.findRewardById(reward.RewardId)
        if cfg then
            self.seasonChallengeRewards[index].icon:SetImage(cfg.ShowDetail.image)
            self.seasonChallengeRewards[index].text:SetText(reward.Score or 0)
        end
    end
    local length = rewards[1].Score - rewards[#rewards].Score
    local curLength = score - rewards[#rewards].Score
    local progress = math.max(0, 0.08 + (curLength / length) * 0.84)
    self.pbSeasonChallengeProgress:SetProgress(progress)
end

---@param chatMsg ChatMsgData
function UIBedWarQualifyingLayout:addTeamChatItem(chatMsg)
    for _, window in pairs(self.llPlayers) do
        window:tryShowChatText(chatMsg)
    end
end

function UIBedWarQualifyingLayout:setQualifyingWaitMatchUI()
    if self.wWaitMatch == nil then
        ---@type GUIBedWarQualifyingWaitMatchWindow
        self.wWaitMatch = UIHelper.newGameGUIWindow("GUIBedWarQualifyingWaitMatch", {})
        self.wWaitMatch.root:SetVerticalAlignment(VerticalAlignment.Bottom)
        self.wWaitMatch.root:SetXPosition({ 0.35, 0 })
        self.wWaitMatch.root:SetYPosition({ 0, -110 })
        self.wWaitMatch:setCancelListener(function()
            TeamService:sendCancelStartGame()
            self:updateBaseUI()
        end)
        self.root:AddChildWindow(self.wWaitMatch.root)
    end
end

return UIBedWarQualifyingLayout
