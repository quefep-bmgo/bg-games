---@class UIBedWarQualifyingSeasonChallengeLayout : IGUILayout
local UIBedWarQualifyingSeasonChallengeLayout = class("UIBedWarQualifyingSeasonChallengeLayout", IGUILayout)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
---@type QualifyingSeasonChallengeRewardConfig
local QualifyingSeasonChallengeRewardConfig = T(Global, "QualifyingSeasonChallengeRewardConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

local ShowType = {
    Icon = 1,
    Actor = 2
}

---@private
function UIBedWarQualifyingSeasonChallengeLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingSeasonChallenge.json", parent)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:onLoad()
    self.maxShowScore = 99999999
    self.iconMovePos = 0
    self.iconMoveGap = 2
    self.btnQuestion = self:getChildWindow("BedWarQualifyingSeasonChallenge-Question", GUIType.Button)
    self.awActor = self:getChildWindow("BedWarQualifyingSeasonChallenge-Actor", GUIType.ActorWindow)
    self.llActorTouch = self:getChildWindow("BedWarQualifyingSeasonChallenge-ActorTouch", GUIType.Layout)
    self.llRewardLayout = self:getChildWindow("BedWarQualifyingSeasonChallenge-Reward-Layout", GUIType.Layout)
    self.stScoreText = self:getChildWindow("BedWarQualifyingSeasonChallenge-Score-Text", GUIType.StaticText)
    self.stScore = self:getChildWindow("BedWarQualifyingSeasonChallenge-Score", GUIType.StaticText)
    self.stHint = self:getChildWindow("BedWarQualifyingSeasonChallenge-Hint", GUIType.StaticText)
    self.llRewardContent = self:getChildWindow("BedWarQualifyingSeasonChallenge-Reward-Content", GUIType.Layout)
    self.pbScoreLine = self:getChildWindow("BedWarQualifyingSeasonChallenge-ScoreLine", GUIType.ProgressBar)
    self.siImage = self:getChildWindow("BedWarQualifyingSeasonChallenge-Image", GUIType.StaticImage)
    self.siImageBack = self:getChildWindow("BedWarQualifyingSeasonChallenge-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindow("BedWarQualifyingSeasonChallenge-Image-Top", GUIType.StaticImage)
    self.llDesc = self:getChildWindow("BedWarQualifyingSeasonChallenge-Desc", GUIType.Layout)
    self.tvDescName = self:getChildWindow("BedWarQualifyingSeasonChallenge-Desc-Name", GUIType.StaticText)
    self.tvDescText = self:getChildWindow("BedWarQualifyingSeasonChallenge-Desc-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:initView()
    self.stScoreText:SetText(Lang:getString("gui.qualifying.challenge.score"))
    self.stScore:SetText("0")
    self.stHint:SetText(Lang:getString("gui.qualifying.challenge.score.hint"))
    ---@type GUIBedWarUIReturnControlWindow
    self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.qualifying.season.challenge", function()
        self:hide()
    end)
    self.root:AddChildWindow(self.llReturn.root)
    self.siImage:SetVisible(false)
    self.llDesc:SetVisible(false)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:initEvent()
    self.btnQuestion:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui.qualifying.challenge.rule.title")
                    .setContentText(Lang:getString("gui.qualifying.challenge.rule.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .setContentAlign(HorizontalAlignment.Left)
                    .show()
    end)
    self:registerEvent(Events.UpdateChallengeReceiveRecordEvent, function()
        if not self:isShow() or not self.rewardAdapter then
            return
        end
        self.rewardAdapter:notifyDataChange()
        self.stScore:SetText(CQualifyingController:getChallengeScore(Define.GameMode.Qualifying))
        local qualifyingData = CQualifyingController:getQualifyingData()
        if not qualifyingData then
            return
        end
        local items = QualifyingSeasonChallengeRewardConfig:getCfgBySeason(qualifyingData.quarter)
        self:updateScoreLineUI(items)
    end)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:onShow()
    self.stScore:SetText(math.min(self.maxShowScore, CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)))
    self:initRewardList()
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:initRewardList()
    if self.lvRewardList ~= nil then
        if #self.rewardAdapter.data > 0 then
            local endReward = self.rewardAdapter.data[#self.rewardAdapter.data]
            self.lvRewardList:getItemByIndex(1):setSelectId(endReward.Id)
            self:showRewardDetail(endReward.ShowDetailId)
        end
        return
    end
    self.lvRewardList = IGUIListView.new("BedWarQualifyingSeasonChallenge-Reward-List", self.llRewardContent, nil, Orientation.Horizontal)
    ---@type BedWarQualifyingSeasonChallengeRewardAdapter
    self.rewardAdapter = UIHelper.newGameAdapter("BedWarQualifyingSeasonChallengeRewardAdapter")
    self.lvRewardList:setAdapter(self.rewardAdapter)
    local qualifyingData = CQualifyingController:getQualifyingData()
    if not qualifyingData then
        return
    end
    local items = QualifyingSeasonChallengeRewardConfig:getCfgBySeason(qualifyingData.quarter)
    self.rewardAdapter:setData(items)
    self.curOffset = 0
    self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
        if self.curOffset == args.offset then
            return
        end
        self.curOffset = args.offset
        self:updateScoreLineUI(items)
    end)
    if #items > 0 then
        self.maxShowScore = items[#items].Score
        self.lvRewardList:getItemByIndex(1):setSelectId(items[#items].Id)
        self:showRewardDetail(items[#items].ShowDetailId)
    end
    self.stScore:SetText(math.min(self.maxShowScore, CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)))
    self.pbScoreLine:SetWidth({ 0, self.lvRewardList:getItemCount() * 153 })
    self:updateScoreLineUI(items)
end

---@private
---@param items QualifyingSeasonChallengeRewardData[]
function UIBedWarQualifyingSeasonChallengeLayout:updateScoreLineUI(items)
    self.pbScoreLine:SetXPosition({ 0, math.min(self.curOffset, 0) })
    local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
    if score == 0 then
        self.pbScoreLine:SetProgress(0)
        return
    end
    local count = #items
    local percent = 1 / count
    local progress = -percent / 2
    if self.curOffset > 0 then
        progress = progress + (self.curOffset / 153) * percent
    end
    for i, item in pairs(items) do
        if item.Score <= score then
            progress = progress + percent
        else
            if i == 1 then
                progress = progress + (score / item.Score) * percent
            else
                local pre = items[i - 1]
                progress = progress + ((score - pre.Score) / (item.Score - pre.Score)) * percent
            end
            break
        end
    end
    self.pbScoreLine:SetProgress(progress)
end

function UIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(rewardDetailId)
    local reward = RewardItemShowDetailConfig:getConfigById(rewardDetailId)
    if not reward then
        self:hide()
        return
    end
    self.llDesc:SetVisible(true)
    self.tvDescName:SetText(Lang:getString(reward.name))
    self.tvDescText:SetText(Lang:getString(reward.desc))
    self.siImage:SetVisible(reward.showType == ShowType.Icon)
    self.awActor:SetVisible(reward.showType == ShowType.Actor)
    if reward.showType == ShowType.Icon then
        self:setIcon(reward)
    elseif reward.showType == ShowType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, reward, self.llActorTouch)
    end
    self.rewardAdapter:notifyDataChange()
end

function UIBedWarQualifyingSeasonChallengeLayout:setIcon(reward)
    self.siImage:SetYPosition({ -0.11, self.iconMovePos })
    if reward.scale and reward.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageTop, reward.image, 200, 200, reward.scale)
        UIHelper:setImageAdjustSize(self.siImageBack, reward.image, 200, 200, reward.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageTop, reward.image, 200, 200)
        UIHelper:setImageAdjustSize(self.siImageBack, reward.image, 200, 200)
    end

    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ -0.11, self.iconMovePos })
    end, 100)
end

function UIBedWarQualifyingSeasonChallengeLayout:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

return UIBedWarQualifyingSeasonChallengeLayout
