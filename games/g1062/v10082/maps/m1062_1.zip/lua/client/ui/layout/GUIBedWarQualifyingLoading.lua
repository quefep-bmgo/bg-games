---@class UIBedWarQualifyingLoadingLayout : IGUILayout
---@field super IGUILayout
local UIBedWarQualifyingLoadingLayout = class("UIBedWarQualifyingLoadingLayout", IGUILayout)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

---@private
function UIBedWarQualifyingLoadingLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingLoading.json", parent)
end

---@private
function UIBedWarQualifyingLoadingLayout:onLoad()
    self.root:SetLevel(49)
    self.siCenter = self:getChildWindow("BedWarQualifyingLoading-Center", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarQualifyingLoadingLayout:initView()

end

function UIBedWarQualifyingLoadingLayout:show(userTeam, gameId)
    if GameType ~= "g1008" then
        return
    end
    if ClientHelper.getStringForKey("CurPlayGameId", "") == gameId then
        return
    end
    ClientHelper.putStringForKey("CurPlayGameId", gameId)
    local userIds = UserManager.Instance():getAllUser()
    PlayerCustomInfoUtil:getPlayerListCustomInfo(userIds, function()
        self.super.show(self, userTeam, gameId)
    end)
end

---@private
function UIBedWarQualifyingLoadingLayout:initEvent()
    self:registerEvent(Events.StartGameEvent, function(userTeam, gameId)
        self:show(userTeam, gameId)
    end)
end

function UIBedWarQualifyingLoadingLayout:onShow(userTeam)
    ---@type GUIWindow
    self:initPlayers(userTeam)
    self.root:SetAlpha(1)
    self.siCenter:PlayEffect1("g1008_ui_VS.effect")
    local leftTimes, rightTimes = 0, 0
    for teamId, players in pairs(self.teams) do
        for _, player in pairs(players) do
            local item = self.items[player.userId]
            if item then
                local isRight = teamId % 2 == 0
                if isRight then
                    rightTimes = rightTimes + 1
                else
                    leftTimes = leftTimes + 1
                end
                item:startShowAnim(isRight, isRight and rightTimes or leftTimes)
            end
        end
    end
    LuaTimer:scheduleTicker(function()
        local alpha = 1
        LuaTimer:scheduleTickerWithEnd(function()
            alpha = alpha - 0.05
            self.root:SetAlpha(alpha)
        end, function()
            GUIManager:destroyGUIWindow(self.root)
        end, 1, 20)
    end, 80, 1)
end

function UIBedWarQualifyingLoadingLayout:initPlayers(userTeam)
    if GameType ~= "g1008" then
        return
    end
    if self.root:GetChildCount() > 1 then
        return
    end
    GUIImagesetManager.Instance():CreateFromFile("bed_war_2_qualifying_loading.json")
    GUIImagesetManager.Instance():CreateFromFile("bed_war_2_qualifying_history.json")
    ---@type GUIBedWarQualifyingLoadingPlayerWindow[]
    self.items = {}
    self.teams = {}
    local userIds = UserManager.Instance():getAllUser()
    for _, userId in pairs(userIds) do
        local cache = UserInfoCache:GetCache(userId)
        if cache then
            local teamId = userTeam[tostring(userId)] or 1
            self.teams[teamId] = self.teams[teamId] or {}
            table.insert(self.teams[teamId], cache)
        end
    end
    for teamId, players in pairs(self.teams) do
        for index, player in pairs(players) do
            ---@type GUIBedWarQualifyingLoadingPlayerWindow
            local item = UIHelper.newGameGUIWindow("GUIBedWarQualifyingLoadingPlayer")
            item.root:SetVerticalAlignment(VerticalAlignment.Center)
            local dir = (teamId <= 2 and -1 or 1)
            local pos = dir == -1 and (4 - index) or (index - 1)
            local yPos = (50 + pos * 72) * dir
            item:setArea({ 0, 0 }, { 0, yPos }, { 0, 356 }, { 0, 60 })
            item:onDataChanged(player.userId, teamId)
            self.items[player.userId] = item
            self.root:AddChildWindow(item.root)
        end
    end
end

function UIBedWarQualifyingLoadingLayout:onDestroy()
    self.items = {}
    self.teams = nil
end

return UIBedWarQualifyingLoadingLayout
