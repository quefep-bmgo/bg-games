---@class GUICreateTeamFastChatItemWindow : IGUIWindow
local GUICreateTeamFastChatItemWindow = class("GUICreateTeamFastChatItemWindow", IGUIWindow)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")

---@param parent UIHallCreateTeamLayout
function GUICreateTeamFastChatItemWindow:ctor(parent, ...)
    self.super.ctor(self, "CreateTeamFastChatItem.json", ...)
    self.parent = parent
end

function GUICreateTeamFastChatItemWindow:onLoad()
    self.tvText = self:getChildWindowByName("CreateTeamFastChatItem", GUIType.StaticText)
    self:initEvent()
end

function GUICreateTeamFastChatItemWindow:initEvent()
    self.tvText:registerEvent(GUIEvent.Click, function()
        ChatClient:sendTextMsgToTeam("[lang]" .. self.data.lang)
        self.parent:changeChatListUI(true)
    end)
end

---@param data FastChatSettingData
function GUICreateTeamFastChatItemWindow:onDataChanged(data)
    self.data = data
    self.tvText:SetText(Lang:getString(data.lang))
end

return GUICreateTeamFastChatItemWindow
