---@class GUIReportItemWindow : IGUIWindow
local GUIReportItemWindow = class("GUIReportItemWindow", IGUIWindow)

---@private
function GUIReportItemWindow:ctor(...)
    self.super.ctor(self, "ReportItem.json", ...)
end

---@private
function GUIReportItemWindow:onLoad()
    self.siSelectBg = self:getChildWindowByName("ReportItem-SelectBg", GUIType.StaticImage)
    self.siSelect = self:getChildWindowByName("ReportItem-Select", GUIType.StaticImage)
    self.stLang = self:getChildWindowByName("ReportItem-Lang", GUIType.StaticText)
    self:initEvent()
end

---@private
function GUIReportItemWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if ReportPlayerContentLayout:containReportId(self.reportId) then
            ReportPlayerContentLayout:removeReportId(self.reportId)
        else
            ReportPlayerContentLayout:addReportId(self.reportId)
        end
    end)
end

---@param reportId number
function GUIReportItemWindow:onDataChanged(reportId)
    self.reportId = reportId
    self.stLang:SetText(Lang:getString("gui.report.item." .. reportId))
    if ReportPlayerContentLayout then
        self.siSelect:SetVisible(ReportPlayerContentLayout:containReportId(reportId))
    else
        self.siSelect:SetVisible(false)
    end
end

return GUIReportItemWindow
