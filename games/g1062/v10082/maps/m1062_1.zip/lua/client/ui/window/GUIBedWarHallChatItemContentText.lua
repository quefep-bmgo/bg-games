---@class GUIBedWarHallChatItemContentTextWindow : IGUIWindow
local GUIBedWarHallChatItemContentTextWindow = class("GUIBedWarHallChatItemContentTextWindow", IGUIWindow)

---@private
function GUIBedWarHallChatItemContentTextWindow:ctor(...)
    self.super.ctor(self, "BedWarHallChatItemContentText.json", ...)
end

---@private
function GUIBedWarHallChatItemContentTextWindow:onLoad()
    self.stText = self:getChildWindowByName("BedWarHallChatItemContentText-Text", GUIType.StaticText)
    self.siArrow = self:getChildWindowByName("BedWarHallChatItemContentText-Arrow", GUIType.StaticImage)
end

---@param data ChatMsgData
function GUIBedWarHallChatItemContentTextWindow:onDataChanged(data)
    if data.sendId == Game:getPlatformUserId() then
        self.siArrow:SetXPosition({ 1, 0 })
        self.siArrow:SetProperty("Rotate", 180)
    end
    self.stText:SetText(data.data.content)
    ---@type number 消息总宽度
    local width = self.stText:GetTextWidth()
    ---@type number 消息总高度（换行后），最小取46
    local height = math.max(self.stText:GetTextHeight() + 16, 46)
    if width < self.stText:GetPixelSize().x then
        self.root:SetWidth({ 0, width + 35 })
    end
    self.root:SetHeight({ 0, height })
    return height
end

return GUIBedWarHallChatItemContentTextWindow
