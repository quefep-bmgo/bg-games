---@class UIIndieMainV3ClickLayout : IGUILayout
local UIIndieMainV3ClickLayout = class("UIIndieMainV3ClickLayout", IGUILayout)

---@private
function UIIndieMainV3ClickLayout:ctor(parent)
    self.super.ctor(self, "IndieMainV3Click.json", parent)
end

---@private
function UIIndieMainV3ClickLayout:onLoad()
    self.llClick = self:getChildWindow("IndieMainV3Click-Click", GUIType.Layout)
    self.llEffect = self:getChildWindow("IndieMainV3Click-Effect", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function UIIndieMainV3ClickLayout:initView()

end

---@private
function UIIndieMainV3ClickLayout:initEvent()
    ---@param point Vector2
    self:registerEvent(CEvents.GUISystemTouchDown, function(point)
        self:showEffect(point.x, point.y)
    end)
end

function UIIndieMainV3ClickLayout:showEffect(x, y)
    self.llClick:SetArea({ 0, x }, { 0, y }, { 0, 0 }, { 0, 0 })
    self.llEffect:SetEffectName("")
    self.llEffect:SetEffectName("img_0_click.effect")
end

function UIIndieMainV3ClickLayout:isMainControl()
    return true
end

return UIIndieMainV3ClickLayout
