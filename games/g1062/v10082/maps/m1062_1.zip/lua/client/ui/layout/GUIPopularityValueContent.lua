---@class UIPopularityValueContentLayout : IGUILayout
local UIPopularityValueContentLayout = class("UIPopularityValueContentLayout", IGUILayout)

function UIPopularityValueContentLayout:ctor(name, parent)
    self.super.ctor(self, name, parent)
end

function UIPopularityValueContentLayout:onLoad()
    self.llData = self:getChildWindow("PopularityValueContent-Data", GUIType.Layout)
    self.siCurValueIcon = self:getChildWindow("PopularityValueContent-CurValue-Icon", GUIType.StaticImage)
    self.stCurValue = self:getChildWindow("PopularityValueContent-CurValue-Value", GUIType.StaticText)
    self.stFansValue = self:getChildWindow("PopularityValueContent-Fans-Value", GUIType.StaticText)
    self.stFansDesc = self:getChildWindow("PopularityValueContent-Fans-Desc", GUIType.StaticText)
    self.stLikeValue = self:getChildWindow("PopularityValueContent-Like-Value", GUIType.StaticText)
    self.stLikeDesc = self:getChildWindow("PopularityValueContent-Like-Desc", GUIType.StaticText)
    self.stBlackOutValue = self:getChildWindow("PopularityValueContent-BlackOut-Value", GUIType.StaticText)
    self.stBlackOutDesc = self:getChildWindow("PopularityValueContent-BlackOut-Desc", GUIType.StaticText)
    self.stDesc = self:getChildWindow("PopularityValueContent-Desc", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

function UIPopularityValueContentLayout:initView()
    self.stFansDesc:SetText(Lang:getString("gui.personal.popularity.fans"))
    self.stLikeDesc:SetText(Lang:getString("gui.personal.popularity.like"))
    self.stBlackOutDesc:SetText(Lang:getString("gui.personal.popularity.blackout"))
    self.stDesc:SetText(Lang:getString("gui.personal.popularity.desc"))
end

function UIPopularityValueContentLayout:initEvent()

end

---@param data BedWarUserInfo
function UIPopularityValueContentLayout:setData(data)
    if not data then
        return
    end
    self.stCurValue:SetText((data.pageLike or 0) + (data.fansNum or 0) + 100)
    self.stFansValue:SetText(data.fansNum or 0)
    self.stLikeValue:SetText(data.pageLike or 0)
    self.stBlackOutValue:SetText(data.blackOut or 0)
end

---@type UIPopularityValueContentLayout
PopularityValueContentLayout = buildPopUpWindowsContent(UIPopularityValueContentLayout, "PopularityValueContent.json")

return UIPopularityValueContentLayout
