---@class GUICommunitySharing : IGUILayout
local UICommunitySharing = class("GUICommunitySharing", IGUILayout)

function UICommunitySharing:onLoad()
    self.tvContentText = self:getChildWindow("CommunitySharing-Content-Text", GUIType.StaticText)
    self.tvShareText = self:getChildWindow("CommunitySharing-Share-Text", GUIType.StaticText)
    self.llMain = self:getChildWindow("CommunitySharing", GUIType.Layout)
    self.btnCopy = self:getChildWindow("CommunitySharing-Copy-Btn", GUIType.Button)
    self.btnClose = self:getChildWindow("CommunitySharing-Close-Btn", GUIType.Button)

    self:initRegister()
end

---@param data CommunitySharingData
function UICommunitySharing:setText(data)
    self.version = data.version
    self.tvContentText:SetText(Lang:getString(data.contentLangKey))
    self.tvShareText:SetText(data.copyTextKey)
    self.btnCopy:SetText(Lang:getString("Jump"))

    local cacheJson = ClientHelper.getStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_GUISharing", "{}")
    if string.sub(cacheJson, 1, 1) == "{" then
        self.cache = json.decode(cacheJson)
    end
    if self.cache.version ~= data.version then
        self.cache = {
            version = data.version,
            showDayKey = 0,
        }
    end
    if self.cache.showDayKey ~= DateUtil.getYearDay() then
        if not self.cache.clickCopy then
            GUIManager:addShowQueue(self)
        end
        self.cache.showDayKey = DateUtil.getYearDay()
        ClientHelper.putStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_GUISharing", json.encode(self.cache))
    end
end

function UICommunitySharing:initRegister()
    self.llMain:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)
    self.btnCopy:registerEvent(GUIEvent.ButtonClick, function()
        self.cache.clickCopy = true
        ClientHelper.putStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_GUISharing", json.encode(self.cache))
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_JUMP_WEB, self.tvShareText:GetText())
        GUIBedWarGameTips:showGameTip(Lang:getString("gui.copy.success"))
        self:hide()
    end)

    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
end

return UICommunitySharing