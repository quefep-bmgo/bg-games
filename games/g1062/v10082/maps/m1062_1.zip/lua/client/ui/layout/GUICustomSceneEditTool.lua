---@class UICustomSceneEditTool : IGUILayout
local UICustomSceneEditTool = class("UICustomSceneEditTool", IGUILayout)

local Items = {}

---@private
function UICustomSceneEditTool:ctor(parent)
    self.super.ctor(self, "CustomSceneEditTool.json", parent)
end

---@private
function UICustomSceneEditTool:isDelayLoad()
    return true
end

---@private
function UICustomSceneEditTool:onLoad()
    self.llCommon = self:getChildWindow("CustomSceneEditTool-Common", GUIType.Layout)
    self.btnNext = self:getChildWindow("CustomSceneEditTool-Next", GUIType.Button)
    self.btnUp = self:getChildWindow("CustomSceneEditTool-Up", GUIType.Button)
    self.btnDel = self:getChildWindow("CustomSceneEditTool-Del", GUIType.Button)
    self.btnSave = self:getChildWindow("CustomSceneEditTool-Save", GUIType.Button)
    self.btnSelect = self:getChildWindow("CustomSceneEditTool-Select", GUIType.Button)
    self.btnClose = self:getChildWindow("CustomSceneEditTool-Close", GUIType.Button)
    self.btnHide = self:getChildWindow("CustomSceneEditTool-Hide", GUIType.Button)
    self:initView()
    self:initEvent()

    self.page = 1
end

---@private
function UICustomSceneEditTool:initView()
    local llContent = self:getChildWindow("CustomSceneEditTool-Fun")
    self.gvItems = IGUIGridView.new("CustomSceneEditTool-Items-List", llContent)
    self.gvItems:setArea({ 0, 10.0 }, { 0, 0 }, { 1.0, 0 }, { 1.0, 0 })
    self.gvItems.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.gvItems:setConfig(10, 10, 2)
    local itemW = (self.gvItems:getWidth() - 30) / 2
    ---@type GMItemAdapter
    self.adapter = UIHelper.newGameAdapter("SceneEditItemAdapter")
    self.adapter:setItemSize(itemW, 37)
    self.gvItems:setAdapter(self.adapter)
end

---@private
function UICustomSceneEditTool:initEvent()
    self.btnDel:registerEvent(GUIEvent.ButtonClick, function()
        GMHelper:deleteConfig()
    end)
    self.btnSave:registerEvent(GUIEvent.ButtonClick, function()
        GMHelper:saveConfig()
    end)
    self.btnSelect:registerEvent(GUIEvent.ButtonClick, function()
        GMHelper:SelectedRecent()
    end)

    self.btnNext:registerEvent(GUIEvent.ButtonClick, function()
        self.page = (self.page + 1) % #Items
        if self.page == 0 then
            self.page = #Items
        end
        self.adapter:setData(Items[self.page])
    end)
    self.btnUp:registerEvent(GUIEvent.ButtonClick, function()
        if self.page > 1 then
            self.page = self.page - 1
        else
            self.page = #Items
        end
        self.adapter:setData(Items[self.page])
    end)

    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnHide:registerEvent(GUIEvent.ButtonClick, function()
        local curXPos = self.root:GetXPosition()
        if curXPos[2] == 0 then
            self.root:SetXPosition({ 0, -300 })
            self.btnHide:SetRotate(180)
        else
            self.root:SetXPosition({ 0, 0 })
            self.btnHide:SetRotate(0)
        end
    end)
end

---@private
function UICustomSceneEditTool:onShow()
    if #Items > 0 then
        self.adapter:setData(Items[1])
    end
end

---@private
---@param item_name string
---@param func_name string
function UICustomSceneEditTool:addItem(item_name, func_name, ...)
    local curPage = #Items
    if curPage == 0 then
        Items[1] = {}
        curPage = 1
    end

    if (item_name == "" and func_name == "") then
        curPage = curPage + 1
        Items[curPage] = {}
        return
    end

    if #Items[curPage] >= 24 then
        curPage = curPage + 1
        Items[curPage] = {}
    end

    table.insert(Items[curPage], { name = item_name, func = func_name, params = { ... } })
end

UICustomSceneEditTool:addItem("新建特效", "newSimpleEffect")
UICustomSceneEditTool:addItem("新建图片", "newSimpleImage")
UICustomSceneEditTool:addItem("新建Npc", "newActorNpc")
UICustomSceneEditTool:addItem("新建场景文字", "addWallText")

UICustomSceneEditTool:addItem("x轴+1", "movePosition", 1, 0, 0)
UICustomSceneEditTool:addItem("x轴-1", "movePosition", -1, 0, 0)
UICustomSceneEditTool:addItem("y轴+1", "movePosition", 0, 1, 0)
UICustomSceneEditTool:addItem("y轴-1", "movePosition", 0, -1, 0)
UICustomSceneEditTool:addItem("z轴+0.1", "movePosition", 0, 0, 0.1)
UICustomSceneEditTool:addItem("z轴-0.1", "movePosition", 0, 0, -0.1)
UICustomSceneEditTool:addItem("x轴+0.1", "movePosition", 0.1, 0, 0)
UICustomSceneEditTool:addItem("x轴-0.1", "movePosition", -0.1, 0, 0)
UICustomSceneEditTool:addItem("y轴+0.1", "movePosition", 0, 0, 0.1, 0)
UICustomSceneEditTool:addItem("y轴-0.1", "movePosition", 0, -0.1, 0)
UICustomSceneEditTool:addItem("z轴+1", "movePosition", 0, 0, 1)
UICustomSceneEditTool:addItem("z轴-1", "movePosition", 0, 0, -1)

UICustomSceneEditTool:addItem("yaw值+10", "changeYaw", 10)
UICustomSceneEditTool:addItem("yaw值-10", "changeYaw", -10)
UICustomSceneEditTool:addItem("yaw值+1", "changeYaw", 1)
UICustomSceneEditTool:addItem("yaw值-1", "changeYaw", -1)
UICustomSceneEditTool:addItem("比例+1", "changeScale", 1)
UICustomSceneEditTool:addItem("比例-1", "changeScale", -1)
UICustomSceneEditTool:addItem("比例+0.1", "changeScale", 0.1)
UICustomSceneEditTool:addItem("比例-0.1", "changeScale", -0.1)

UICustomSceneEditTool:addItem("NPC点击事件", "addActorNpcClickEvent")
UICustomSceneEditTool:addItem("NPC设置名字", "addHeadText")
UICustomSceneEditTool:addItem("Npc设置飞行", "setEntityFly")

return UICustomSceneEditTool
