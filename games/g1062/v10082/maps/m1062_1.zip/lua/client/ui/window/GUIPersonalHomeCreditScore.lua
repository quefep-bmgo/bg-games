---@class GUIPersonalHomeCreditScoreWindow : IGUIWindow
local GUIPersonalHomeCreditScoreWindow = class("GUIPersonalHomeCreditScoreWindow", IGUIWindow)
---@type CreditScoreConfig
local CreditScoreConfig = T(Global, "CreditScoreConfig")

---@private
function GUIPersonalHomeCreditScoreWindow:ctor(...)
    self.super.ctor(self, "PersonalHomeCreditScore.json", ...)
end

---@private
function GUIPersonalHomeCreditScoreWindow:onLoad()
    self.llCurrentLevel = self:getChildWindowByName("PersonalHomeCreditScore-Current-Level", GUIType.Layout)
    self.siCurrentLevelStage = self:getChildWindowByName("PersonalHomeCreditScore-Current-Level-Stage", GUIType.StaticImage)
    self.siCurrentLevelBg = self:getChildWindowByName("PersonalHomeCreditScore-Current-Level-Bg", GUIType.StaticImage)
    self.siCurrentLevelLevel = self:getChildWindowByName("PersonalHomeCreditScore-Current-Level-Level", GUIType.StaticImage)
    self.stCurrentLevelDesc = self:getChildWindowByName("PersonalHomeCreditScore-Current-Level-desc", GUIType.StaticText)
    self.siScoreBg = self:getChildWindowByName("PersonalHomeCreditScore-Score-Bg", GUIType.StaticImage)
    self.llLevelList = self:getChildWindowByName("PersonalHomeCreditScore-Level-List", GUIType.Layout)
    self.btnDescBt = self:getChildWindowByName("PersonalHomeCreditScore-Desc-Bt", GUIType.Button)
    self.stDescText = self:getChildWindowByName("PersonalHomeCreditScore-Desc-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
    self:initItemList()
end

---@private
function GUIPersonalHomeCreditScoreWindow:initView()
    self.stCurrentLevelDesc:SetText(Lang:getString("gui.credit.score.text"))
    self.stDescText:SetText(Lang:getString("gui.credit.score.desc"))
end

---@private
function GUIPersonalHomeCreditScoreWindow:initItemList()
    if self.lvCreditScoreList then
        return
    end
    self.lvCreditScoreList = IGUIListView.new("PersonalHomeCreditScore-CreditScore-List", self.llLevelList, nil, Orientation.Horizontal)
    self.lvCreditScoreList:setItemSpace(12)
    self.lvCreditScoreList.root:SetItemWidth(670)
    ---@type CreditScoreLevelAdapter
    self.creditScoreAdapter = UIHelper.newGameAdapter("CreditScoreLevelAdapter")
    self.lvCreditScoreList:setAdapter(self.creditScoreAdapter)
    self.lvCreditScoreList.root:SetClipChild(true)
    self.lvCreditScoreList.root:SetAllowScroll(false)
    self.creditScoreConfig = TableUtil.copyTable(CreditScoreConfig:getAllCfg())
end

---@private
function GUIPersonalHomeCreditScoreWindow:initEvent()
    self.btnDescBt:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui.credit.score.rule")
                    .setContentText(Lang:getString("gui.credit.score.rule.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .setContentAlign(HorizontalAlignment.Left)
                    .show()
    end)
end

function GUIPersonalHomeCreditScoreWindow:initData(userId)
    local userInfo = UserInfoCache:GetCache(userId)
    if not userInfo then
        return
    end

    local curCreditScore = userInfo[Define.PlayerCustomInfo.CreditScore] or Define.CreditScore.InitCreditScore
    if curCreditScore < Define.CreditScore.LowerLimit then
        curCreditScore = Define.CreditScore.LowerLimit
    elseif curCreditScore > Define.CreditScore.UpperLimit then
        curCreditScore = Define.CreditScore.UpperLimit
    end

    local curConfig = CreditScoreConfig:getCfgByCreditScore(curCreditScore)
    self.siCurrentLevelLevel:SetImage(curConfig.icon)

    local ScoreLen = string.len(tostring(curCreditScore))
    local totalWidth = 26 * ScoreLen + 8 * (ScoreLen - 1)
    if self.siScoreBg:GetChildCount() > ScoreLen then
        for i = self.siScoreBg:GetChildCount(), (ScoreLen + 1), -1 do
            GUIManager:getWindowByName("PersonalHomeCreditScore-Score-" .. tostring(i), GUIType.StaticImage):SetVisible(false)
        end
    end
    for i = 1, ScoreLen do
        local image = GUIManager:getWindowByName("PersonalHomeCreditScore-Score-" .. tostring(i), GUIType.StaticImage)
        if not image then
            image = GUIManager:createGUIWindow(GUIType.StaticImage, "PersonalHomeCreditScore-Score-" .. tostring(i))
            image:SetHorizontalAlignment(HorizontalAlignment.Left)
            image:SetVerticalAlignment(VerticalAlignment.Center)
            image:SetWidth({ 0, 26 })
            self.siScoreBg:AddChildWindow(image)
        end
        image:SetVisible(true)
        image:SetArea({ 0, (266 - totalWidth) / 2 + (i - 1) * 34 }, { 0, 0 }, { 0, 26 }, { 0, 44 })
        image:SetImage("set:trigger_gift.json image:img_0_gift_discount" .. tostring(string.sub(tostring(curCreditScore), i, i)))
    end

    for _, config in pairs(self.creditScoreConfig) do
        config.curUserId = userId
    end
    self.creditScoreAdapter:setData(self.creditScoreConfig)
end

return GUIPersonalHomeCreditScoreWindow
