---@class GUIBedWarHallChatItemContentEmojiWindow : IGUIWindow
local GUIBedWarHallChatItemContentEmojiWindow = class("GUIBedWarHallChatItemContentEmojiWindow", IGUIWindow)

---@private
function GUIBedWarHallChatItemContentEmojiWindow:ctor(...)
    self.super.ctor(self, "BedWarHallChatItemContentEmoji.json", ...)
end

---@private
function GUIBedWarHallChatItemContentEmojiWindow:onLoad()
    self.siImage = DynamicCast.dynamicCastWindow(GUIType.StaticImage, self.root)
end

---@param data ChatMsgData
function GUIBedWarHallChatItemContentEmojiWindow:onDataChanged(data)
    if data.sendId == Game:getPlatformUserId() then
        self.siImage:SetXPosition({ 0, -18 })
    end
    self.siImage:SetImage(data.data.content.emojiData)
end

return GUIBedWarHallChatItemContentEmojiWindow
