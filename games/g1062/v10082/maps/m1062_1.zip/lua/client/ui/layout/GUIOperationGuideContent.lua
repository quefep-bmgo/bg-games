---@class UIOperationGuideContentLayout : IGUILayout
local UIOperationGuideContentLayout = class("UIOperationGuideContentLayout", IGUILayout)

local OperationType = 0

---@private
function UIOperationGuideContentLayout:ctor(name, parent)
    self.super.ctor(self, "OperationGuideContent.json", parent)
end

---@private
function UIOperationGuideContentLayout:onLoad()
    self.cbButton = self:getChildWindow("OperationGuideContent-Button", GUIType.CheckBox)
    self.cbFlexible = self:getChildWindow("OperationGuideContent-Flexible", GUIType.CheckBox)
    self.stButtonText = self:getChildWindow("OperationGuideContent-Button-Text", GUIType.StaticText)
    self.stFlexibleText = self:getChildWindow("OperationGuideContent-Flexible-Text", GUIType.StaticText)
    self.siButtonSelect = self:getChildWindow("OperationGuideContent-Button-Select", GUIType.StaticImage)
    self.siFlexibleSelect = self:getChildWindow("OperationGuideContent-Flexible-Select", GUIType.StaticImage)
    self.siButtonSelectEffect = self:getChildWindow("OperationGuideContent-Button-Select-Effect", GUIType.StaticImage)
    self.siFlexibleSelectEffect = self:getChildWindow("OperationGuideContent-Flexible-Select-Effect", GUIType.StaticImage)
    self.btnSure = self:getChildWindow("OperationGuideContent-Sure", GUIType.Button)

    self.siButtonSelect:SetVisible(false)
    self.siFlexibleSelect:SetVisible(false)
    self.siButtonSelectEffect:SetVisible(false)
    self.siFlexibleSelectEffect:SetVisible(false)

    self.opGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
    self:initView()
    self:initEvent()
end

---@private
function UIOperationGuideContentLayout:initView()
    self.stButtonText:SetText(Lang:getString("gui.guide.operation.button"))
    self.stFlexibleText:SetText(Lang:getString("gui.guide.operation.flexible"))
    self.btnSure:SetText(Lang:getString("gui_dialog_tip_btn_sure"))
end

---@private
function UIOperationGuideContentLayout:initEvent()
    self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
        if OperationType == 0 then
            return
        elseif OperationType == Define.ControlType.Button then
            Blockman.Instance().m_gameSettings.usePole = 0
            SystemSettingRecord.defaultOperation = 0
            PopUpWindows.hide()
        elseif OperationType == Define.ControlType.Flexible then
            Blockman.Instance().m_gameSettings.usePole = 2
            SystemSettingRecord.defaultOperation = 2
            PopUpWindows.hide()
        end
        onSaveSetting()
    end)

    self.opGroup:addCheckBox(self.cbButton, function(checked)
        OperationType = Define.ControlType.Button
        self.siButtonSelect:SetVisible(true)
        self.siFlexibleSelect:SetVisible(false)
        self.siButtonSelectEffect:SetVisible(true)
        self.siFlexibleSelectEffect:SetVisible(false)
    end)

    self.opGroup:addCheckBox(self.cbFlexible, function(checked)
        OperationType = Define.ControlType.Flexible
        self.siButtonSelect:SetVisible(false)
        self.siFlexibleSelect:SetVisible(true)
        self.siButtonSelectEffect:SetVisible(false)
        self.siFlexibleSelectEffect:SetVisible(true)
    end)

    self.opGroup:selectIndex(1)
end

---@type UIOperationGuideContentLayout
GuideOperationContent = buildPopUpWindowsContent(UIOperationGuideContentLayout, "OperationGuideContent.json")

return UIOperationGuideContentLayout
