---@class GUIDressShowItemWindow : IGUIWindow
local GUIDressShowItemWindow = class("GUIDressShowItemWindow", IGUIWindow)

---@private
function GUIDressShowItemWindow:ctor(...)
	self.super.ctor(self, "DressShowItem.json", ...)
end

---@private
function GUIDressShowItemWindow:onLoad()
	self.siIcon = self:getChildWindowByName("DressShowItem-Icon", GUIType.StaticImage)
end

---@param dressId number
function GUIDressShowItemWindow:onDataChanged(dressId)
	local goods = CustomShopConfig:getGoodsConfig(dressId)
	if goods then
		self.siIcon:SetImage(goods.Image)
	end
end

return GUIDressShowItemWindow
