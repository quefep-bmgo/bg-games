---@class GUICreateTeamChatItemWindow : IGUIWindow
local GUICreateTeamChatItemWindow = class("GUICreateTeamChatItemWindow", IGUIWindow)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")
---@type TeamService
local TeamService = T(Global, "TeamService")

function GUICreateTeamChatItemWindow:ctor(width, ...)
    self.super.ctor(self, "CreateTeamChatItem.json", ...)
    self.width = width
    self:setWidth({ 0, width })
end

function GUICreateTeamChatItemWindow:onLoad()
    self.tvText = self:getChildWindowByName("CreateTeamChatItem", GUIType.StaticText)
end

---@param data ChatMsgData
function GUICreateTeamChatItemWindow:onDataChanged(data)
    local text = ChatClient:chatMsgToString(data, TeamService:isQualifying() and "▢FF13162E" or nil)
    self.tvText:SetText(text)
    local high = self.tvText:GetTextHeight()
    self.tvText:SetHeight({ 0, high })
end

return GUICreateTeamChatItemWindow
