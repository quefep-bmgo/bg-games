---@class UITransformChipContentLayout : IGUILayout
local UITransformChipContentLayout = class("UITransformChipContentLayout", IGUILayout)

function UITransformChipContentLayout:ctor(name, parent)
    self.super.ctor(self, name, parent)
end

function UITransformChipContentLayout:onLoad()
    self.llOldChipLayout = self:getChildWindow("TransformChipContent-OldChipLayout", GUIType.Layout)
    self.llNewChip = self:getChildWindow("TransformChipContent-NewChip", GUIType.Layout)
    self.siNewChipIcon = self:getChildWindow("TransformChipContent-NewChip-Icon", GUIType.StaticImage)
    self.stNewChipNum = self:getChildWindow("TransformChipContent-NewChip-Num", GUIType.StaticText)
    self.btnClose = self:getChildWindow("TransformChipContent-Close", GUIType.Button)
    self.stCloseText = self:getChildWindow("TransformChipContent-Close-Text", GUIType.StaticText)
    self.stTip = self:getChildWindow("TransformChipContent-Tip", GUIType.StaticText)

    self.gvGoodsList = IGUIGridView.new("TransformChipContent-OldChip-List", self.llOldChipLayout)
    self.gvGoodsList.root:SetArea({ 0, 12 }, { 0, 7 }, { 1, -28 }, { 1, -28 })
    self.gvGoodsList:setConfig(10, 10, 4)
    ---@type OldChipAdapter
    self.goodsAdapter = UIHelper.newGameAdapter("OldChipAdapter")
    self.goodsAdapter:setItemSize(86, 93)
    self.gvGoodsList:setAdapter(self.goodsAdapter)

    self:initView()
    self:initEvent()
end

function UITransformChipContentLayout:initView()
    self.stCloseText:SetText(Lang:getString("TransformChip_OK"))
    self.stTip:SetText(Lang:getString("TransformChip_Tip"))
end

function UITransformChipContentLayout:initEvent()
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        PopUpWindows.hide()
    end)
end

function UITransformChipContentLayout:setTransformData(oldChipInfo, newChipCount)
    local chipList = {}
    for _, info in pairs(oldChipInfo) do
        ---@type DressStoreConfig
        local config = DressStoreConfig:findStoreDressByItemId(info.dressId)
        if config then
            local showInfo = {
                image = config.ChipImg,
                count = info.count
            }
            table.insert(chipList, showInfo)
        end
    end
    self.goodsAdapter:setData(chipList)
    self.stNewChipNum:SetText(newChipCount)
end

---@type UITransformChipContentLayout
TransformChipContent = buildPopUpWindowsContent(UITransformChipContentLayout, "TransformChipContent.json")

return UITransformChipContentLayout
