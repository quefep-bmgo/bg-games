---@class UIGoodsDetailContentLayout : IGUILayout
local UIGoodsDetailContentLayout = class("UIGoodsDetailContentLayout", IGUILayout)

local ChipPrice = 2

function UIGoodsDetailContentLayout:ctor(name, parent)
    self.super.ctor(self, name, parent)
end

function UIGoodsDetailContentLayout:onLoad()
    self.siContent = self:getChildWindow("GoodsDetailContent-Content", GUIType.StaticImage)
    self.siImage = self:getChildWindow("GoodsDetailContent-Image", GUIType.StaticImage)
    self.stName = self:getChildWindow("GoodsDetailContent-Name", GUIType.StaticText)
    self.llPriceLayout = self:getChildWindow("GoodsDetailContent-Price-Layout", GUIType.Layout)
    self.btnLeftButton = self:getChildWindow("GoodsDetailContent-Left-Button", GUIType.Button)
    self.siLeftIcon = self:getChildWindow("GoodsDetailContent-Left-Icon", GUIType.StaticImage)
    self.stLeftBuy = self:getChildWindow("GoodsDetailContent-Left-Buy", GUIType.StaticText)
    self.llLeftPriceBg = self:getChildWindow("GoodsDetailContent-Left-Price-Bg", GUIType.Layout)
    self.siLeftPriceIcon = self:getChildWindow("GoodsDetailContent-Left-Price-Icon", GUIType.StaticImage)
    self.stLeftPriceText = self:getChildWindow("GoodsDetailContent-Left-Price-Text", GUIType.StaticText)
    self.btnRightButton = self:getChildWindow("GoodsDetailContent-Right-Button", GUIType.Button)
    self.siRightIcon = self:getChildWindow("GoodsDetailContent-Right-Icon", GUIType.StaticImage)
    self.stRightBuy = self:getChildWindow("GoodsDetailContent-Right-Buy", GUIType.StaticText)
    self.llRightPriceBg = self:getChildWindow("GoodsDetailContent-Right-Price-Bg", GUIType.Layout)
    self.siRightPriceIcon = self:getChildWindow("GoodsDetailContent-Right-Price-Icon", GUIType.StaticImage)
    self.stRightPriceText = self:getChildWindow("GoodsDetailContent-Right-Price-Text", GUIType.StaticText)
    self.btnCentreButton = self:getChildWindow("GoodsDetailContent-Centre-Button", GUIType.Button)
    self.stCentreText = self:getChildWindow("GoodsDetailContent-Centre-Text", GUIType.StaticText)
    self.siActor = self:getChildWindow("GoodsDetailContent-Actor", GUIType.ActorWindow)
    self.llActorLayout = self:getChildWindow("GoodsDetailContent-Actor-Content", GUIType.Layout)

    self.stLeftBuy:SetText(Lang:getString("shop_btn_buy"))
    self.stRightBuy:SetText(Lang:getString("shop_btn_buy"))
    self.stCentreText:SetText(Lang:getString("custom.shop.equip.immediate"))

    self.siActor:SetActor1("g1008_skin.actor", "idle", 0)

    self:initEvent()
end

function UIGoodsDetailContentLayout:initEvent()
    self.btnLeftButton:registerEvent(GUIEvent.ButtonClick, function()
        self:onTryBuy(self.coinId2, self.price2)
    end)

    self.btnRightButton:registerEvent(GUIEvent.ButtonClick, function()
        self:onTryBuy(self.coinId1, self.price1)
    end)

    self.btnCentreButton:registerEvent(GUIEvent.ButtonClick, function()
        self:onClickCentreButton()
    end)
end

function UIGoodsDetailContentLayout:onTick()
    self.siActor:SetRotateY(self.siActor:GetRotateY() + 1)
end

---@param goods CustomShopGoodsData
function UIGoodsDetailContentLayout:setGoodsBuyInfo(goods, image, name, coinId1, price1, coinId2, price2)
    local type = CustomShopConfig:getGoodsType(goods)
    if type == CustomGoodsType.Bow or type == CustomGoodsType.Axe or type == CustomGoodsType.Sword or
            type == CustomGoodsType.HelMet or type == CustomGoodsType.PickAxe then
        local dressConfig = CustomShopDress.Settings[tostring(goods.Id)]
        self.siActor:UseBodyPart("body", string.gsub(dressConfig.MeshName, ".mesh", ""))
        self.siActor:SetWidth({ 0, 150 * dressConfig.WidthScale })
        self.siActor:SetYPosition({ 0, dressConfig.YPos })
        self.llActorLayout:SetVisible(true)
        self.siContent:SetVisible(false)
    else
        self.siImage:SetImage(image)
        self.stName:SetText(Lang:getString(name))
        self.llActorLayout:SetVisible(false)
        self.siContent:SetVisible(true)
    end

    self.goods = goods
    self.price1 = price1
    self.coinId1 = coinId1
    self.price2 = price2
    self.coinId2 = coinId2

    self.stRightPriceText:SetText(price1)
    self.siRightIcon:SetImage(PayHelper.getMoneyIcon(coinId1))
    self.siRightPriceIcon:SetImage(PayHelper.getMoneyIcon(coinId1))

    self.llPriceLayout:SetVisible(true)
    self.btnCentreButton:SetVisible(false)
    self.btnLeftButton:SetVisible(false)
    self.btnRightButton:SetVisible(true)
    self.btnRightButton:SetArea({ 0, 0 }, { 0, 0 }, { 0, 218 }, { 0, 68 })

    if coinId2 and coinId2 ~= "#" and price2 then
        self.stLeftPriceText:SetText(price2)
        self.siLeftIcon:SetImage(PayHelper.getMoneyIcon(coinId2))
        self.siLeftPriceIcon:SetImage(PayHelper.getMoneyIcon(coinId2))
        self.btnLeftButton:SetVisible(true)
        self.btnRightButton:SetArea({ 0, 140 }, { 0, 0 }, { 0, 218 }, { 0, 68 })
    end
end

---@param goods CustomShopGoodsData
function UIGoodsDetailContentLayout:setGoodsShowInfo(goods)
    self.goods = goods
    local type = CustomShopConfig:getGoodsType(goods)
    if type == CustomGoodsType.Bow or type == CustomGoodsType.Axe or type == CustomGoodsType.Sword or
            type == CustomGoodsType.HelMet or type == CustomGoodsType.PickAxe then
        local dressConfig = CustomShopDress.Settings[tostring(goods.Id)]
        self.siActor:UseBodyPart("body", string.gsub(dressConfig.MeshName, ".mesh", ""))
        self.siActor:SetWidth({ 0, 150 * dressConfig.WidthScale })
        self.siActor:SetYPosition({ 0, dressConfig.YPos })
        self.llActorLayout:SetVisible(true)
        self.siContent:SetVisible(false)
    else
        self.siImage:SetImage(goods.Image)
        self.stName:SetText(Lang:getString(goods.Name))
        self.llActorLayout:SetVisible(false)
        self.siContent:SetVisible(true)
    end
    self.llPriceLayout:SetVisible(true)
    self.btnCentreButton:SetVisible(true)
    self.btnLeftButton:SetVisible(false)
    self.btnRightButton:SetVisible(false)
    self.stRightPriceText:SetText("custom.shop.equip.immediate")
end

function UIGoodsDetailContentLayout:onClickCentreButton()
    CustomShop:onEquipGoods(self.goods)
    PopUpWindows.hide()
end

function UIGoodsDetailContentLayout:onTryBuy(coinId, price)
    PayHelper.checkMoney(coinId, price, function(canBuy)
        if canBuy then
            CustomShop:onBuyGoods(self.goods, coinId) --去购买
        else
            if coinId == Define.Money.KEY then
                PopUpWindows.hide()
            elseif coinId == Define.Money.COMMON_CHIP then
                PopUpWindows.hide()
                local lackNum = price - PlayerWallet.getMoneyByCoinId(Define.Money.COMMON_CHIP)
                if lackNum > 0 then
                    local useKeyBuyChip = function()
                        if PlayerWallet.getMoneyByCoinId(Define.Money.KEY) > lackNum * ChipPrice then
                            CommonPacketSender:sendBuyGoodsWithChipAndKey(self.goods.Id)
                        else
                            PopUpWindows.hide()
                            GUIStore:show(StoreId.CubeStore, StoreTabId.Key)
                        end
                    end

                    CustomDialog.builder()
                                .setTitleText("shop_btn_buy")
                                .setContentText(Lang:getTipString(1046055, tostring(lackNum) .. "\t" .. tostring(lackNum * ChipPrice)))
                                .setHideLeftButton()
                                .setRightText("shop_btn_buy")
                                .setRightClickListener(useKeyBuyChip)
                                .show()
                end
            end
        end
    end)
end

---@type UIGoodsDetailContentLayout
GoodsDetailContent = buildPopUpWindowsContent(UIGoodsDetailContentLayout, "GoodsDetailContent.json")

return UIGoodsDetailContentLayout