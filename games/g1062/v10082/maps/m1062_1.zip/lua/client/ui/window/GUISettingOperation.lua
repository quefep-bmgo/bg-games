---@class GUISettingOperation : IGUIWindow
local GUISettingOperation = class("GUISettingOperation", IGUIWindow)

local CheckTextColor = {
    Normal = { 39 / 255, 45 / 255, 92 / 255, 1 },
    Select = { 129 / 255, 243 / 255, 234 / 255, 1 },
}

local GUI_MIN_SIZE = 0.5
local GUI_MAX_SIZE = 1.0

function GUISettingOperation:ctor()
    self.super.ctor(self, "BedWarSettingOperation.json")
end

function GUISettingOperation:onLoad()
    self.poleMove = GUIManager:getWindowByName("Main-PoleControl-Move")
    self.poleControl = GUIManager:getWindowByName("Main-PoleControl")
    self.poleBG = GUIManager:getWindowByName("Main-PoleControl-BG", GUIType.StaticImage)
    self.poleWidth = self.poleControl:GetPixelSize().x
    self.poleHeight = self.poleControl:GetPixelSize().y

    self.size = self:getChildWindowByName("BedWarSettingOperation-Size-Slider", GUIType.Slider)
    self.sizeText = self:getChildWindowByName("BedWarSettingOperation-Size-Slider-Text", GUIType.StaticText)
    self.siControlIcon = self:getChildWindowByName("BedWarSettingOperation-Control", GUIType.StaticImage)
    self.siJumpIcon = self:getChildWindowByName("BedWarSettingOperation-Jump", GUIType.StaticImage)

    self:getChildWindowByName("BedWarSettingOperation-Detail", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.toggle"))
    self:getChildWindowByName("BedWarSettingOperation-Button-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.button"))
    self:getChildWindowByName("BedWarSettingOperation-Jump-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.Jump"))
    self:getChildWindowByName("BedWarSettingOperation-Flexed-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.flexed"))
    self:getChildWindowByName("BedWarSettingOperation-Flexible-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.pole.flexible"))
    self:getChildWindowByName("BedWarSettingOperation-Size", GUIType.StaticText):SetText(Lang:getString("gui.setting.gui.size"))

    self.opGroup = RadioBoxGroup.new(SoundConfig.switchSetting)
    self:register()

    LuaTimer:schedule(function()
        local ivButton = self:getChildWindowByName("BedWarSettingOperation-Button-Img")
        local width = math.min(ivButton:GetPixelSize().x, 156)
        ivButton:SetWidth({ 0, width })
        ivButton:SetHeight({ 0, width })
        local ivFlexible = self:getChildWindowByName("BedWarSettingOperation-Flexible-Img")
        width = math.min(ivFlexible:GetPixelSize().x, 166)
        ivFlexible:SetWidth({ 0, width })
        ivFlexible:SetHeight({ 0, width })
        local ivFlexed = self:getChildWindowByName("BedWarSettingOperation-Flexed-Img")
        width = math.min(ivFlexed:GetPixelSize().x, 168)
        ivFlexed:SetWidth({ 0, width })
        ivFlexed:SetHeight({ 0, width })
    end, 100)
end
function GUISettingOperation:register()
    self.opGroup:addCheckBox(self:getChildWindowByName("BedWarSettingOperation-Button-Box", GUIType.CheckBox), function(checked)
        local check = self:getChildWindowByName("BedWarSettingOperation-Button-Check", GUIType.StaticImage)
        local text = self:getChildWindowByName("BedWarSettingOperation-Button-Text", GUIType.StaticText)
        if checked then
            self.curControl = Define.ControlType.Button
            Blockman.Instance().m_gameSettings.usePole = 0
            ClientHelper.putBoolPrefs("UseCenterJumpButton", false)
            self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type1")
            self:refreshSize(self.size:GetProgress())
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
            text:SetTextColor(CheckTextColor.Select)
            LuaTimer:schedule(function()
                SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
                onSaveSetting()
            end, 0)
        else
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
            text:SetTextColor(CheckTextColor.Normal)
        end
    end)

    self.opGroup:addCheckBox(self:getChildWindowByName("BedWarSettingOperation-Flexed-Box", GUIType.CheckBox), function(checked)
        local check = self:getChildWindowByName("BedWarSettingOperation-Flexed-Check", GUIType.StaticImage)
        local text = self:getChildWindowByName("BedWarSettingOperation-Flexed-Text", GUIType.StaticText)
        if checked then
            self.curControl = Define.ControlType.Flexed
            self.poleMove:SetArea({ 0, 50 }, { 0, -70 }, { 0, self.poleWidth }, { 0, self.poleHeight })
            self.poleBG:SetImage("set:pole.json image:pole_bg")
            self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type5")
            self.siControlIcon:SetHeight({0, self.poleHeight})
            self.siControlIcon:SetWidth({0, self.poleWidth})
            Blockman.Instance().m_gameSettings.usePole = 1
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
            text:SetTextColor(CheckTextColor.Select)
            LuaTimer:schedule(function()
                SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
                onSaveSetting()
            end, 0)
        else
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
            text:SetTextColor(CheckTextColor.Normal)
        end
    end)

    self.opGroup:addCheckBox(self:getChildWindowByName("BedWarSettingOperation-Flexible-Box", GUIType.CheckBox), function(checked)
        local check = self:getChildWindowByName("BedWarSettingOperation-Flexible-Check", GUIType.StaticImage)
        local text = self:getChildWindowByName("BedWarSettingOperation-Flexible-Text", GUIType.StaticText)
        if checked then
            self.curControl = Define.ControlType.Flexible
            self.poleMove:SetArea({ 0, 0 }, { 0, 0 }, { 0, self.poleWidth * 1.8 }, { 0, self.poleHeight * 2.0 })
            self.poleBG:SetImage("set:pole.json image:pole_bg_2")
            Blockman.Instance().m_gameSettings.usePole = 2
            self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type4")
            self.siControlIcon:SetHeight({0, self.poleHeight})
            self.siControlIcon:SetWidth({0, self.poleWidth})
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
            text:SetTextColor(CheckTextColor.Select)
            LuaTimer:schedule(function()
                SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
                onSaveSetting()
            end, 0)
        else
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
            text:SetTextColor(CheckTextColor.Normal)
        end
    end)

    self.opGroup:addCheckBox(self:getChildWindowByName("BedWarSettingOperation-Jump-Box", GUIType.CheckBox), function(checked)
        local check = self:getChildWindowByName("BedWarSettingOperation-Jump-Check", GUIType.StaticImage)
        local text = self:getChildWindowByName("BedWarSettingOperation-Jump-Text", GUIType.StaticText)
        if checked then
            self.curControl = Define.ControlType.Jump
            Blockman.Instance().m_gameSettings.usePole = 0
            ClientHelper.putBoolPrefs("UseCenterJumpButton", true)
            self.siControlIcon:SetImage("set:bedwar_setting.json image:operation_type2")
            self:refreshSize(self.size:GetProgress())
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected04")
            text:SetTextColor(CheckTextColor.Select)
            LuaTimer:schedule(function()
                SystemSettingRecord.defaultOperation = self.opGroup:getCurIndex()
                onSaveSetting()
            end, 0)
        else
            check:SetImage("set:bed_war_3_setting.json image:img_0_selected03")
            text:SetTextColor(CheckTextColor.Normal)
        end
    end)

    self.size:registerEvent(GUIEvent.TouchDown, function()
        self:refreshSize()
    end)

    self.size:registerEvent(GUIEvent.TouchMove, function()
        self:refreshSize()
    end)
end

function GUISettingOperation:refreshSize(progress)
    local curProgress = progress or self.size:GetProgress()
    if progress then
        self.size:SetProgress(progress)
    end
    local size = GUI_MIN_SIZE + (GUI_MAX_SIZE - GUI_MIN_SIZE) * curProgress
    if self.curControl == Define.ControlType.Button or self.curControl == Define.ControlType.Jump then
        self.siControlIcon:SetHeight({0, 300 * size})
        self.siControlIcon:SetWidth({0, 300 * size})
    end
    self.siJumpIcon:SetHeight({0, 300 * 0.382 * size})
    self.siJumpIcon:SetWidth({0, 300 * 0.382 * size})
    local rat = math.floor(curProgress * 10) / 10
    self.sizeText:SetText(rat)
    self.size:SetHeaderImage(rat == GUIBedWarSetting.defaultSetting.defaultButtonSize
            and "set:bed_war_3_button.json image:btn_0_settings01"
            or "set:bed_war_3_button.json image:btn_0_settings")
    self.sizeText:SetXPosition({curProgress, -25})
    Blockman.Instance().m_gameSettings.playerActivityGuiSize = size
    SystemSettingRecord.defaultButtonSize = curProgress
    onSaveSetting()
end

return GUISettingOperation