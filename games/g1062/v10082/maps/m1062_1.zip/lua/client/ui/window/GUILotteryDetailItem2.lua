---@class GUILotteryDetailItem2 : IGUIWindow
local GUILotteryDetailItem2 = class("BedWarLotteryDetailItem", IGUIWindow)

function GUILotteryDetailItem2:onLoad()

    self.ivSelect = self:getChildWindow(1, GUIType.StaticImage)
    self.ivEnchantBackGround = self:getChildWindow(2, GUIType.StaticImage)
    self.ivImage = self:getChildWindow(3, GUIType.StaticImage)

end

function GUILotteryDetailItem2:init(i)
    self.index = i
    self.itemId = nil
end

function GUILotteryDetailItem2:setRewardImage(rewardId)
    local reward = LotteryConfig.findRewardById(rewardId)
    if #reward then
        self.itemId = rewardId
        self.ivImage:SetImage(tostring(reward.Image))
        if reward.IsEnchant == 1 then
            self.ivEnchantBackGround:SetVisible(true)
        end
    end 
end

function GUILotteryDetailItem2:SelectReward(rewardId)
    if rewardId == self.itemId then
        self.ivSelect:SetVisible(true)
    end
end

function GUILotteryDetailItem2:onNotSelected()
    self.ivSelect:SetVisible(false)
end

return GUILotteryDetailItem2