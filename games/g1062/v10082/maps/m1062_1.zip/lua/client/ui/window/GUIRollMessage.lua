---@class GUIRollMessageWindow : IGUIWindow
local GUIRollMessageWindow = class("GUIRollMessageWindow", IGUIWindow)

---@type ChatClient
local ChatClient = T(Global, "ChatClient")

function GUIRollMessageWindow:ctor(...)
    self.super.ctor(self, "RollMessage.json", ...)
end

function GUIRollMessageWindow:onLoad()
    self.siTypeTextBg = self:getChildWindowByName("RollMessage-Type-Text-Bg", GUIType.StaticImage)
    self.stTypeText = self:getChildWindowByName("RollMessage-Type-Text", GUIType.StaticText)
    self.stMessage = self:getChildWindowByName("RollMessage-Message", GUIType.StaticText)
    self:initView()
    self:initEvent()
    LuaTimer:scheduleTimer(function()
        self:updateMessage()
    end, 2000)
end

function GUIRollMessageWindow:initView()
    local text = Lang:getString("gui.message.type.all")
    self.stTypeText:SetText(text)
    local width = self.stTypeText:GetTextWidth() + 20
    self.siTypeTextBg:SetWidth({ 0, width })
    self.stMessage:SetArea({ 0, 22 + width }, { 0, 0 }, { 1, -33 - width }, { 1, 0 })
    self.stMessage:SetText("")
end

function GUIRollMessageWindow:initEvent()

end

function GUIRollMessageWindow:updateMessage()
    ChatClient:getLangGroupMsgCache(nil, function(chatMsgList)
        if #chatMsgList == 0 then
            return
        end
        local chatMsg = chatMsgList[#chatMsgList]
        if chatMsg then
            self.stMessage:SetText(ChatClient:chatMsgToString(chatMsg), TextFormat.colorWrite)
        end
    end)
end

return GUIRollMessageWindow
