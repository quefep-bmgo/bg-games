---@class GUIGuideClickItemWindow : IGUIWindow
local GUIGuideClickItemWindow = class("GUIGuideClickItemWindow", IGUIWindow)
---@type ClientGuideManager
local GuideManager = T(Global, "GuideManager")

local ArrowImage = {
    "set:bed_war_3_guide.json image:img_0_line_lefttop",
    "set:bed_war_3_guide.json image:img_0_line_leftbottom",
    "set:bed_war_3_guide.json image:img_0_line_righttop",
    "set:bed_war_3_guide.json image:img_0_line_rightbottom",
}

---@private
function GUIGuideClickItemWindow:ctor(params, ...)
    self.super.ctor(self, "GuideClickItem.json", params, ...)
end

---@private
function GUIGuideClickItemWindow:onLoad(params)
    self.siLeft = self:getChildWindowByName("GuideClickItem-Left", GUIType.StaticImage)
    self.siRight = self:getChildWindowByName("GuideClickItem-Right", GUIType.StaticImage)
    self.siTop = self:getChildWindowByName("GuideClickItem-Top", GUIType.StaticImage)
    self.siBottom = self:getChildWindowByName("GuideClickItem-Bottom", GUIType.StaticImage)
    self.btnButton = self:getChildWindowByName("GuideClickItem-Button", GUIType.Button)
    self.siEffect = self:getChildWindowByName("GuideClickItem-Effect", GUIType.StaticImage)
    self.siEffectClick = self:getChildWindowByName("GuideClickItem-Effect-Click", GUIType.StaticImage)
    self.siArrow = self:getChildWindowByName("GuideClickItem-Arrow", GUIType.StaticImage)
    self.siTextBg = self:getChildWindowByName("GuideClickItem-Text-Bg", GUIType.StaticImage)
    self.stText = self:getChildWindowByName("GuideClickItem-Text", GUIType.StaticText)

    self.siLeft:SetTouchParent(false)
    self.siRight:SetTouchParent(false)
    self.siTop:SetTouchParent(false)
    self.siBottom:SetTouchParent(false)
    self.siEffect:SetTouchParent(false)
    self.siEffectClick:SetTouchParent(false)

    self.siArrow:SetVisible(false)
    self.moveTimes = 0

    self.params = params
    self:initView(params)
    self:initEvent()
end

---@private
---@param params string
function GUIGuideClickItemWindow:initView(params)
    self.params = params
    self.targetWindow = self:getTargetWindow(params[1])

    if not self.targetWindow:IsVisibleInScreen() then
        GuideManager:onCompleteFinishEvent(Define.GuideFinishEvent.ClickButton, self.params[1])
        return
    end

    GUISystem.Instance():GetRootWindow():AddChildWindow(self.root)
    --self.root:SetAlwaysOnTop(true)
    --self.root:SetLevel(2)

    local area = self.targetWindow:GetRenderArea()
    self.siLeft:SetArea({ 0, 0 }, { 0, area[2] }, { 0, area[1] }, { 0, area[4] - area[2] })
    self.siRight:SetArea({ 0, area[3] }, { 0, area[2] }, { 1, 0 }, { 0, area[4] - area[2] })
    self.siTop:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 0, area[2] })
    self.siBottom:SetArea({ 0, 0 }, { 0, area[4] }, { 1, 0 }, { 0, 760 - area[4] })
    self.btnButton:SetArea({ 0, area[1] }, { 0, area[2] }, { 0, area[3] - area[1] }, { 0, area[4] - area[2] })

    if params[2] and params[3] then
        self.siArrow:SetVisible(true)
        self.siArrow:SetImage(ArrowImage[tonumber(params[2])])
        if tonumber(params[2]) == Define.GuideArrowDir.LeftTop then
            self.siArrow:SetXPosition({ 0, area[3] })
            self.siArrow:SetYPosition({ 0, area[2] + (area[4] - area[2]) / 2 })
            self.siTextBg:SetHorizontalAlignment(HorizontalAlignment.Left)
            self.siTextBg:SetVerticalAlignment(VerticalAlignment.Top)
            --self.siTextBg:SetXPosition({ 0, 81 })
        elseif tonumber(params[2]) == Define.GuideArrowDir.LeftBottom then
            self.siArrow:SetXPosition({ 0, area[3] })
            self.siArrow:SetYPosition({ 0, area[2] + (area[4] - area[2]) / 2 - 40 })
            self.siTextBg:SetHorizontalAlignment(HorizontalAlignment.Left)
            self.siTextBg:SetVerticalAlignment(VerticalAlignment.Bottom)
            self.siTextBg:SetXPosition({ 0, 81 })
        elseif tonumber(params[2]) == Define.GuideArrowDir.RightTop then
            self.siArrow:SetXPosition({ 0, area[1] - 89 })
            self.siArrow:SetYPosition({ 0, area[2] + (area[4] - area[2]) / 2 })
            self.siTextBg:SetHorizontalAlignment(HorizontalAlignment.Right)
            self.siTextBg:SetVerticalAlignment(VerticalAlignment.Top)
            self.siTextBg:SetXPosition({ 0, -81 })
        elseif tonumber(params[2]) == Define.GuideArrowDir.RightBottom then
            self.siArrow:SetXPosition({ 0, area[1] - 89 })
            self.siArrow:SetYPosition({ 0, area[2] + (area[4] - area[2]) / 2 - 40 })
            self.siTextBg:SetHorizontalAlignment(HorizontalAlignment.Right)
            self.siTextBg:SetVerticalAlignment(VerticalAlignment.Bottom)
            self.siTextBg:SetXPosition({ 0, -81 })
        end

        self.stText:SetText(Lang:getString(params[3]))
        local Width = self.stText:GetFont():GetTextExtent(self.stText:GetText(), 1)
        if Width > 440 then
            self.siTextBg:SetWidth({ 0, 470 })
            self.siTextBg:SetHeight({ 0, 101 })
            self.stText:SetText(Lang:getString(params[3]))
        else
            self.siTextBg:SetWidth({ 0, Width + 30 })
            self.siTextBg:SetHeight({ 0, 76 })
        end
    end

    if params[4] and params[4] == "1" then
        self:hideMasking()
    else
        Blockman.Instance():enableBreakCurrentScreenMoveTouch(true)
    end
end

---@private
function GUIGuideClickItemWindow:initEvent()
    if self.params and self.params[1] == "Main-PoleControl" then
        self.siLeft:SetBackgroundColor({ 255 / 255, 255 / 255, 255 / 255, 0 })
        self.siRight:SetBackgroundColor({ 255 / 255, 255 / 255, 255 / 255, 0 })
        self.siTop:SetBackgroundColor({ 255 / 255, 255 / 255, 255 / 255, 0 })
        self.siBottom:SetBackgroundColor({ 255 / 255, 255 / 255, 255 / 255, 0 })
        self.siEffect:SetVisible(false)
        self.siEffectClick:SetEffectName("g1008_effect_ui_OperationsGuide_arrow.effect")
        self.realTargetWindow = self:getTargetWindow("Main-PoleControl-Move")
        local type = self.realTargetWindow:GetWindowType()
        local window = DynamicCast.dynamicCastWindow(type, self.realTargetWindow)
        self.root:SetEnabled(false)
        self.btnButton:SetEnabled(false)

        window:registerEvent(GUIEvent.TouchMove, function()
            self.moveTimes = self.moveTimes + 1
            if self.moveTimes == 10 then
                Blockman.Instance():enableBreakCurrentScreenMoveTouch(false)
                LuaTimer:scheduleTimer(function()
                    LuaTimer:scheduleTimer(function()
                        GuideManager:onCompleteFinishEvent(Define.GuideFinishEvent.ClickButton, self.params[1])
                    end, 1, 1)
                    if self.root then
                        GUISystem.Instance():GetRootWindow():RemoveChildWindow1(self.root)
                    end
                end, 100, 1)
            end
        end)

        window:registerEvent(GUIEvent.Release, function()
            Blockman.Instance():enableBreakCurrentScreenMoveTouch(false)
            LuaTimer:scheduleTimer(function()
                GuideManager:onCompleteFinishEvent(Define.GuideFinishEvent.ClickButton, self.params[1])
            end, 1, 1)
            if self.root then
                GUISystem.Instance():GetRootWindow():RemoveChildWindow1(self.root)
            end
        end)
    else
        self.btnButton:registerEvent(GUIEvent.ButtonClick, function()
            local type = self.targetWindow:GetWindowType()
            local area = self.targetWindow:GetRenderArea()
            local window = DynamicCast.dynamicCastWindow(type, self.targetWindow)
            Blockman.Instance():enableBreakCurrentScreenMoveTouch(false)
            if type == "CheckBox" then
                window:SetChecked(true)
                LuaTimer:scheduleTimer(function()
                    GuideManager:onCompleteFinishEvent(Define.GuideFinishEvent.ClickButton, self.params[1])
                end, 1, 1)
                GUISystem.Instance():GetRootWindow():RemoveChildWindow1(self.root)
            else
                window:TouchDown(VectorUtil.newVector2(area[3] - area[1], area[4] - area[2]))
                LuaTimer:scheduleTimer(function()
                    window:TouchUp(VectorUtil.newVector2(area[3] - area[1], area[4] - area[2]))
                    LuaTimer:scheduleTimer(function()
                        GuideManager:onCompleteFinishEvent(Define.GuideFinishEvent.ClickButton, self.params[1])
                    end, 1, 1)
                    GUISystem.Instance():GetRootWindow():RemoveChildWindow1(self.root)
                end, 100, 1)
            end
        end)
    end

    self.siLeft:registerEvent(GUIEvent.Click, function()
        self:showTipEffect()
    end)
    self.siRight:registerEvent(GUIEvent.Click, function()
        self:showTipEffect()
    end)
    self.siTop:registerEvent(GUIEvent.Click, function()
        self:showTipEffect()
    end)
    self.siBottom:registerEvent(GUIEvent.Click, function()
        self:showTipEffect()
    end)
end

function GUIGuideClickItemWindow:showTipEffect()
    self.siEffect:SetEffectName("g1008_xinshouyindao_shousuokuang.effect")
    LuaTimer:cancel(self.changeEffect)
    self.changeEffect = LuaTimer:scheduleTimer(function()
        self.siEffect:SetEffectName("g1008_xinshouyindao_kuosankuang.effect")
    end, 500, 1)
end

function GUIGuideClickItemWindow:hideMasking()
    self.siLeft:SetVisible(false)
    self.siRight:SetVisible(false)
    self.siTop:SetVisible(false)
    self.siBottom:SetVisible(false)
    self.root:SetTouchable(false)
end

function GUIGuideClickItemWindow:getTargetWindow(param)
    local params = StringUtil.split(param, "+")
    local targetWindow = GUIManager:getWindowByName(table.remove(params, 1))
    local type = targetWindow:GetWindowType()
    targetWindow = DynamicCast.dynamicCastWindow(GUIType[type], targetWindow)

    if params and #params > 0 then
        for _, index in pairs(params) do
            if type == "GridView" then
                targetWindow = targetWindow:GetItem(tonumber(index))
            else
                targetWindow = targetWindow:GetChildByIndex(tonumber(index))
            end
        end
    end
    return targetWindow
end

return GUIGuideClickItemWindow
