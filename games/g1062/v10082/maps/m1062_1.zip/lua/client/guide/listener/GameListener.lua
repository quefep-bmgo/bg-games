GameListener = {}

---@type GuideUtil
local GuideUtil = T(Global, "GuideUtil")

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
    BaseListener.registerCallBack(CEvents.GameMainTickEvent, function()
        if GuideUtil and GuideUtil["onTick"] then
            GuideUtil:onTick()
        end
    end)

    CommonDataEvents:registerCallBack("BedWarToolBarVisible", function(data)
        Events.BedWarToolBarEvent:invoke(data)
    end, DataBuilderProcessor)
end

function GameListener.onGameReady()
    BaseGameConfig:init()
    GameConfig:loadConfig()
    --CustomSceneConfig:gameReady()
    require "ui.GUIFactory"
    require "game.data.GMBedWar"
    ClientHelper.putFloatPrefs("BowPullingSpeedMultiplier", GameConfig.bowSpeedMultiplier)
    ClientHelper.putFloatPrefs("BowPullingFOVMultiplier", GameConfig.bowFOVMultiplier)
end

