---@class GUIGameScoreActivityTaskItemWindow : IGUIWindow
local GUIGameScoreActivityTaskItemWindow = class("GUIGameScoreActivityTaskItemWindow", IGUIWindow)

---@private
---@param parent GUIGameScoreActivityPanelWindow
function GUIGameScoreActivityTaskItemWindow:ctor(parent)
    self.parent = parent
    self.super.ctor(self, "GameScoreActivityTaskItem.json")
end

---@private
function GUIGameScoreActivityTaskItemWindow:onLoad()
    self.progress = 0
    self.status = Define.TaskStatus.PROGRESSING
    self.siBg = self:getChildWindowByName("GameScoreActivityTaskItem-Bg", GUIType.StaticImage)
    self.siRight = self:getChildWindowByName("GameScoreActivityTaskItem-Right", GUIType.StaticImage)
    self.siTaskIcon = self:getChildWindowByName("GameScoreActivityTaskItem-TaskIcon", GUIType.StaticImage)
    self.stTaskProgress = self:getChildWindowByName("GameScoreActivityTaskItem-TaskProgress", GUIType.StaticText)
    self.siMask = self:getChildWindowByName("GameScoreActivityTaskItem-Mask", GUIType.StaticImage)
    self.siMaskYes = self:getChildWindowByName("GameScoreActivityTaskItem-MaskYes", GUIType.StaticImage)
    self.siScoreIcon = self:getChildWindowByName("GameScoreActivityTaskItem-ScoreIcon", GUIType.StaticImage)
    self.stScore = self:getChildWindowByName("GameScoreActivityTaskItem-Score", GUIType.StaticText)
    self.stDesc = self:getChildWindowByName("GameScoreActivityTaskItem-Desc", GUIType.StaticText)
    self.taskBgColor = { 0.298039, 0.380392, 0.537255, 1 }
    self:initEvent()
end

---@private
function GUIGameScoreActivityTaskItemWindow:initEvent()
    self.siRight:registerEvent(GUIEvent.Click, function()
        if self.status == Define.TaskStatus.RECEIVED then
            self.parent:changeTaskPanel()
            return
        end
        if self.status == Define.TaskStatus.FINISHED then
            PlayerManager:getClientPlayer():sendPacket({
                pid = "ScoreActivityReceiveTask",
                activityId = self.parent:getActivityById(),
                taskId = self.taskId,
            })
        else
            self.parent:changeTaskPanel()
        end
    end)
end

---@param data TaskSettingData
function GUIGameScoreActivityTaskItemWindow:onDataChanged(data)
    self.data = data
    self.taskId = data.Id
    self.siTaskIcon:SetImage(data.Image)
    self.stScore:SetText(data.Reward)
    self.stDesc:SetText(Lang:getString(data.Desc))
    self.stTaskProgress:SetText(math.min(data.GoalNum, self.progress) .. "/" .. data.GoalNum)
    if self.status == Define.TaskStatus.RECEIVED then
        self.siMask:SetVisible(true)
        self.siMaskYes:SetVisible(true)
    else
        self.siMask:SetVisible(false)
        self.siMaskYes:SetVisible(false)
    end
    if self.parent.isTaskPanelOpen then
        self.siBg:SetBackgroundColor(self.taskBgColor)
    else
        self.siBg:SetBackgroundColor({ 0, 0, 0, 0 })
    end
end

function GUIGameScoreActivityTaskItemWindow:setUIStyle(scoreIcon, scoreIconSize, taskBgIcon, taskBgIconSize, taskBgColor)
    self.taskBgColor = taskBgColor
    self.siScoreIcon:SetImage(scoreIcon)
    self.siScoreIcon:SetWidth({ 0, scoreIconSize.x })
    self.siScoreIcon:SetHeight({ 0, scoreIconSize.y })
    self.siRight:SetImage(taskBgIcon)
    self.siMask:SetImage(taskBgIcon)
    self.siRight:SetWidth({ 0, taskBgIconSize.x })
    self.siMask:SetWidth({ 0, taskBgIconSize.x })
    self.siRight:SetHeight({ 0, taskBgIconSize.y })
    self.siMask:SetHeight({ 0, taskBgIconSize.y })
end

function GUIGameScoreActivityTaskItemWindow:setTaskInfo(progress, status)
    self.progress = progress
    self.status = status
    self:updateUI()
end

function GUIGameScoreActivityTaskItemWindow:updateUI()
    if self.data then
        self:onDataChanged(self.data)
    end
end

return GUIGameScoreActivityTaskItemWindow
