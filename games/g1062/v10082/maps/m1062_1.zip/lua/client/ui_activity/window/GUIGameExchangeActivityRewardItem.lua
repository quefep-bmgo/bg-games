---@class GUIGameExchangeActivityRewardItemWindow : IGUIWindow
local GUIGameExchangeActivityRewardItemWindow = class("GUIGameExchangeActivityRewardItemWindow", IGUIWindow)

local QualityBgImage = {
    [1] = "set:game_activity_score_2.json image:img_0_itembd_blue",
    [2] = "set:game_activity_score_2.json image:img_0_itembd_purple",
    [3] = "set:game_activity_score_2.json image:img_0_itembd_yellow",
}

---@private
function GUIGameExchangeActivityRewardItemWindow:ctor(_, mgr)
    self.super.ctor(self, "GameExchangeActivityRewardItem.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameExchangeActivityRewardItemWindow:onLoad(mgr)
    self.mgr = mgr
    self.siBg = self:getChildWindowByName("GameExchangeActivityRewardItem", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameExchangeActivityRewardItem-Image", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("GameExchangeActivityRewardItem-Count", GUIType.StaticText)
    self.siLimitIcon = self:getChildWindowByName("GameExchangeActivityRewardItem-LimitIcon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("GameExchangeActivityRewardItem-Limit", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("GameExchangeActivityRewardItem-Score", GUIType.StaticText)
    self.stPriceAdd = self:getChildWindowByName("GameExchangeActivityRewardItem-Add", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("GameExchangeActivityRewardItem-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameExchangeActivityRewardItem-Price", GUIType.StaticText)
    self.llMask = self:getChildWindowByName("GameExchangeActivityRewardItem-Mask", GUIType.Layout)
    self.siSelected = self:getChildWindowByName("GameExchangeActivityRewardItem-Selected", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameExchangeActivityRewardItemWindow:initView()
    self.stPriceAdd:SetText("+")
end

---@private
function GUIGameExchangeActivityRewardItemWindow:initEvent()
    self.siBg:registerEvent(GUIEvent.Click, function()
        if not self.data then
            return
        end
        Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
    end)
end

---@param data ScoreActivityRewardData
function GUIGameExchangeActivityRewardItemWindow:onDataChanged(data)
    self.data = data
    self.siImage:SetImage(data.reward.image)
    if data.reward.numLang ~= "#" then
        self.stCount:SetText("x" .. Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    self.stScore:SetText(data.score)
    if data.price <= 0 then
        self.siPriceIcon:SetVisible(false)
        self.stPriceAdd:SetVisible(false)
    else
        self.stPriceAdd:SetVisible(true)
        self.siPriceIcon:SetVisible(true)
        local width = self.stScore:GetTextWidth()
        self.stPriceAdd:SetXPosition({ 0, 32 + width })
        self.siPriceIcon:SetXPosition({ 0, 52 + width })
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
        self.stPrice:SetText(data.price)
    end
    if data.limit <= 0 then
        self.siLimitIcon:SetVisible(false)
    else
        self.siLimitIcon:SetVisible(data.limit > 1)
        local limit = self.mgr:getRewardLimit(data)
        if limit > 0 then
            self.stLimit:SetText(limit .. "/" .. data.limit)
            self.llMask:SetVisible(false)
        else
            self.llMask:SetVisible(true)
            self.stLimit:SetText(TextFormat.colorRed .. "0" .. TextFormat.colorWrite .. "/" .. data.limit)
        end
        self.siLimitIcon:SetXPosition({ 0, -self.stLimit:GetTextWidth() - 8 })
    end
    self.siBg:SetImage(QualityBgImage[self.data.quality] or QualityBgImage[1])
    self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)
end

return GUIGameExchangeActivityRewardItemWindow
