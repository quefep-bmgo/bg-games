require "common.BedWarServer"

BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
    require "common.listener.PluginListener"
    require "common.report.ReportEvent"
    if GameType == "g1046" then
        require "hall.BedWarServer"
    elseif GameType == "g1063" then
        require "guide.BedWarServer"
    else
        require "game.BedWarServer"
    end
    BedWarServer.onGameInit(config)
    ---@type SConnectorCenter
    local SConnectorCenter = T(Global, "ConnectorCenter")
    SConnectorCenter:start()
end)