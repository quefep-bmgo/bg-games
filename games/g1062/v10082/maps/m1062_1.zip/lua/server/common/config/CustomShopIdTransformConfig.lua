---@class CustomShopIdTransformConfig
local CustomShopIdTransformConfig = T(Global, "CustomShopIdTransformConfig")
---@type CustomShopIdTransformData[]
local Settings = {}

function CustomShopIdTransformConfig:init()
	local config = FileUtil.getConfigFromCsv("setting/CustomShopIdTransform.csv")
	for _, item in pairs(config) do
		---@class CustomShopIdTransformData
		local data = {
			oldId = item.oldId,
			newId = item.newId,
		}
		Settings[data.oldId] = data.newId
	end
end

function CustomShopIdTransformConfig:getAllCfg()
	return Settings
end

---@return CustomShopIdTransformData
function CustomShopIdTransformConfig:getCfgById(oldId)
	return Settings[tostring(oldId)]
end

CustomShopIdTransformConfig:init()
