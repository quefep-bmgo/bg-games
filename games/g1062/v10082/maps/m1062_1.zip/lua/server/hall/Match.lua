---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:10
---
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")

GameMatch = {}

function GameMatch:initMatch()
    GameTimeTask:start()
    TreasureChallenge:setSeasonRefreshTimer()
end

function GameMatch:onTick(ticks)

end

function GameMatch:onPlayerQuit(player)
    TreasureChallenge:onPlayerLogout(player)
    QualifyingHelper:onPlayerLogout(player)
end

function GameMatch:isGameStart()
    return false
end

return GameMatch