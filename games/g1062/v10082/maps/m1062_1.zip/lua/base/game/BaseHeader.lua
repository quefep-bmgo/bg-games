require "game.config.Area"
require "game.config.BaseGameConfig"
require "game.data.BaseMessage"