---
--- Created by Jimmy.
--- DateTime: 2017/10/20 0020 14:49
---
local Teams = {}
local TeamAreas = {}

TeamConfig = {}

local function initTeams(teams)
    for _, item in pairs(teams) do
        if tonumber(GameConfig.mapId) == tonumber(item.mapId) then
            local id = tonumber(item.id)
            Teams[id] = {}
            Teams[id].id = id
            Teams[id].name = tostring(item.name)

            local initPos = StringUtil.split(tostring(item.initPos), ",")
            Teams[id].initPos = VectorUtil.newVector3i(initPos[1], initPos[2], initPos[3])
            Teams[id].initYaw = item.initYaw or 0
            Teams[id].resourcePointId = item.resourcePointId

            Teams[id].bedPos = {}
            if item.bedPos then
                local bedPos = StringUtil.split(tostring(item.bedPos), "#")
                local pos1 = StringUtil.split(tostring(bedPos[1]), ",")
                local pos2 = StringUtil.split(tostring(bedPos[2]), ",")
                Teams[id].bedPos[1] = VectorUtil.newVector3(pos1[1], pos1[2], pos1[3])
                Teams[id].bedPos[2] = VectorUtil.newVector3(pos2[1], pos2[2], pos2[3])
            else
                Teams[id].bedPos[1] = VectorUtil.newVector3i(item.bedStartPosX, item.bedStartPosY, item.bedStartPosZ)
                Teams[id].bedPos[2] = VectorUtil.newVector3i(item.bedEndPosX, item.bedEndPosY, item.bedEndPosZ)
            end

            if isClient then
                local bedBlock = cBlockManager.cGetBlockById(BlockID.BED)
                if bedBlock then
                    bedBlock:setPositionValue(Teams[id].bedPos[1], id - 1)
                    bedBlock:setPositionValue(Teams[id].bedPos[2], id - 1)
                end
            end

            Teams[id].bedYaw = tonumber(item.bedYaw or 0)
            Teams[id].schemeticGroupId = tonumber(item.schemeticGroupId or 0)
            Teams[id].clothBlockId = tonumber(item.clothBlockId or 35)
            Teams[id].doubleDummyId = tonumber(item.doubleDummyId or ItemID.DOUBLE_DUMMY)
            local cannotPlaceBlockArea = {}
            if item.cannotPlaceBlock then
                local cannotPlacePos = StringUtil.split(tostring(item.cannotPlaceBlock), "#")
                cannotPlaceBlockArea[1] = StringUtil.split(tostring(cannotPlacePos[1]), ",")
                cannotPlaceBlockArea[2] = StringUtil.split(tostring(cannotPlacePos[2]), ",")
            else
                cannotPlaceBlockArea[1] = {}
                cannotPlaceBlockArea[1][1] = tonumber(item.cannotPlaceBlockStartPosX)
                cannotPlaceBlockArea[1][2] = tonumber(item.cannotPlaceBlockStartPosY)
                cannotPlaceBlockArea[1][3] = tonumber(item.cannotPlaceBlockStartPosZ)
                cannotPlaceBlockArea[2] = {}
                cannotPlaceBlockArea[2][1] = tonumber(item.cannotPlaceBlockEndPosX)
                cannotPlaceBlockArea[2][2] = tonumber(item.cannotPlaceBlockEndPosY)
                cannotPlaceBlockArea[2][3] = tonumber(item.cannotPlaceBlockEndPosZ)
            end

            TeamAreas[id] = Area.new(cannotPlaceBlockArea)
            Teams[id].playerInArea = {}
            Teams[id].initItems = StringUtil.split(tostring(item.initItems), "#", false, true)

            local homePos = StringUtil.split(tostring(item.homeAreaPos), "#")
            if #homePos < 2 then
                homePos = {
                    "0,0,0",
                    "0,0,0",
                }
            end
            local pos1 = StringUtil.split(tostring(homePos[1]), ",")
            local pos2 = StringUtil.split(tostring(homePos[2]), ",")
            Teams[id].homeArea = IArea.new()
            Teams[id].homeArea:init(pos1[1], pos2[1], pos1[2], pos2[2], pos1[3], pos2[3])
        end
    end
end

function TeamConfig:getTeams()
    return Teams
end

function TeamConfig:getTeamCount()
    return #Teams
end

function TeamConfig:getTeam(id)
    local team = Teams[tonumber(id)]
    if team == nil then
        team = Teams[1]
    end
    return team
end

function TeamConfig:getTeamColor(id)
    return TeamColor[tonumber(id)] or TeamColor[1]
end

function TeamConfig:isInTeamArea(vec3)
    for _, area in pairs(TeamAreas) do
        local inArea = area:BlockPlaceArea(vec3)
        if inArea == true then
            return true
        end
    end
    return false
end

function TeamConfig:onPlayerMove(player, x, y, z)
    if not GameMatch:isGameStart() then
        return
    end
    for teamId, team in pairs(Teams) do
        ---检查玩家是否在家.
        if tostring(teamId) == tostring(player.teamId) then
            if team.homeArea:inArea(VectorUtil.newVector3(x, y, z)) then
                player.info:setValue("inHome", "1")
            else
                player.info:setValue("inHome", "0")
            end
        end
    end
end

function TeamConfig:isBeChecked(id, playerInArea)
    for _, userId in pairs(playerInArea) do
        if id == userId then
            return true
        end
    end
    return false
end

function TeamConfig:getTeamMaxMinDiff()
    local max = 0
    local min = 9999
    if Teams then
        for _, team in pairs(Teams) do
            local teamInfo = GameMatch.Teams[team.id]
            if teamInfo then
                if teamInfo.curPlayers and teamInfo.curPlayers > max then
                    max = teamInfo.curPlayers
                end
                if teamInfo.curPlayers and teamInfo.curPlayers < min then
                    min = teamInfo.curPlayers
                end
            else
                min = 0
            end
        end
        if max - min >= 0 then
            return max - min
        else
            return -1
        end
    end
    return -1
end

function TeamConfig:getTeamHeadItemId(teamId)
    local team = Teams[teamId]
    if not team then
        return 2056
    end
    for _, itemId in pairs(team.initItems) do
        if ItemMapping:getOldItemId(itemId) == ItemID.HELMET_LEATHER then
            return itemId
        end
    end
    return 2056
end

initTeams(FileUtil.getConfigFromCsv("setting/TeamConfig.csv"))
