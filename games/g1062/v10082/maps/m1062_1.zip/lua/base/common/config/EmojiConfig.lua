---@class EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")
---@type EmojiData[]
local Settings = {}

function EmojiConfig:init()
	local config = FileUtil.getConfigFromCsv("setting/Emoji.csv", 2, true, true)
	for _, item in pairs(config) do
		---@class EmojiData
		local data = {
			id = tonumber(item.id),
			icon = item.icon,
			name = item.name,
		}
		Settings[data.id] = data
	end
end

function EmojiConfig:getAllCfg()
	return Settings
end

---@return EmojiData
function EmojiConfig:getCfgById(id)
	return Settings[id]
end

---@return EmojiData
function EmojiConfig:getCfgByIcon(icon)
	for _, item in pairs(Settings) do
		if item.icon == icon then
			return item
		end
	end
	return nil
end

EmojiConfig:init()
