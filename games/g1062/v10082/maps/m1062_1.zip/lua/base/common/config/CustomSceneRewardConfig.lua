---@class CustomSceneRewardConfig
local CustomSceneRewardConfig = T(Global, "CustomSceneRewardConfig")

---@type CustomSceneRewardItem[]
local Rewards = {}

---@type CustomSceneConfig
local CustomSceneConfig = T(Global, "CustomSceneConfig")

function CustomSceneRewardConfig:init()
    if isClient then
        LuaTimer:scheduleTimer(function()
            self:onSelfMove()
        end, 100)
    end
    local configs = FileUtil.getConfigFromCsv("setting/CustomSceneReward.csv", 2, true)
    for _, config in pairs(configs) do
        local endTime
        if config.EndTime and config.EndTime ~= "#" then
            local _, _, year, month, day, hour, min, sec = string.find(config.EndTime, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
            endTime = DateUtil.date2BeiJingTime({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
        end
        ---@class CustomSceneRewardItem
        local item = {}
        item.Id = tonumber(config.Id) or 0
        item.SceneId = tonumber(config.SceneId) or 0
        item.RewardId = tonumber(config.RewardId) or 0
        item.EndTime = endTime
        item.Type = tonumber(config.Type) or 0
        item.Tip = config.Tip or "#"
        if isClient and CustomSceneConfig:getConfigById(item.SceneId) then
            item.Scene = CustomSceneConfig:getConfigById(item.SceneId)
            if item.EndTime then
                local nowTime = os.time()
                if nowTime >= endTime then
                    CustomSceneRewardConfig:removeScene(item)
                else
                    LuaTimer:schedule(function()
                        CustomSceneRewardConfig:removeScene(item)
                    end, (endTime - nowTime) * 1000)
                end
            end
        end
        Rewards[item.Id] = item
    end
end

----------------------server---------------------------
function CustomSceneRewardConfig:CloseSceneReward(player, id)
    local record = player.sceneRewardRecord or {}
    local item = Rewards[tonumber(id)]
    if record[tostring(id)] then
        return false
    end
    if not item then
        return false
    end
    if item.EndTime and item.EndTime < os.time() then
        return false
    end
    ---判断拾取条件
    if (item.Type == 0 or player.sceneRewardTypeRecord[tostring(item.Type)]) then
        local reward = RewardConfig:getRewardById(item.RewardId)
        if reward then
            record[tostring(id)] = GameReward:onPlayerGetReward(player, reward)
            return record[tostring(id)]
        end
    end
    return false
end

----------------------client---------------------------
---@param reward CustomSceneRewardItem
function CustomSceneRewardConfig:removeScene(reward)
    if not reward.Scene or reward.Scene.type == 0 then
        return
    end
    reward.Scene.type = 0
    LuaTimer:cancel(reward.Scene.animKey or 0)
    EngineWorld:removeEntity(reward.Scene.targetEntityId or 0)
    reward.Scene = nil
end

function CustomSceneRewardConfig:UpdateSceneRewardRecord(record)
    for id, _ in pairs(record) do
        local reward = Rewards[tonumber(id)]
        if reward then
            CustomSceneRewardConfig:removeScene(reward)
        end
    end
end

function CustomSceneRewardConfig:onSelfMove()
    local self = PlayerManager:getClientPlayer()
    local selfPos = self:getPosition()
    for _, item in pairs(Rewards) do
        if not item.alreadyCheck and item.Scene and VectorUtil.distance(selfPos, item.Scene.pos) < 3 then
            item.alreadyCheck = true
            self:sendPacket({
                pid = "CloseSceneReward",
                id = item.Id
            }, function(success)
                if success then
                    item.alreadyCheck = false
                    local reward = RewardConfig:getRewardById(item.RewardId)
                    if reward then
                        HostApi.notifyGetGoods(reward.ShowDetail.image, reward.Count)
                        CustomSceneRewardConfig:UpdateSceneRewardRecord({ [tostring(item.Id)] = true })
                    end
                else
                    CustomDialog.builder()
                                .setContentText(Lang:getString(item.Tip))
                                .setHideLeftButton()
                                .show()
                    LuaTimer:schedule(function()
                        item.alreadyCheck = false
                    end, 5000)
                end
            end)
        end
    end
end

CustomSceneRewardConfig:init()