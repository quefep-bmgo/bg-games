---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")
---@type BlindBoxLotteryConfig
local BlindBoxConfig = Plugins.Require("activity", "common.config.BlindBoxConfig")

---@type CBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "client.mode.BaseActivityMgr")
Plugins.Require("activity", "client.mode.LuckyLotteryMgr")
Plugins.Require("activity", "client.mode.MustLotteryMgr")
Plugins.Require("activity", "client.mode.BlindBoxMgr")
Plugins.Require("activity", "client.mode.ScoreActivityMgr")

---@class CMainActivity
local MainActivity = {}
---@type CBaseActivityMgr[]
local CurrentActivity = {}

local RefreshFunc

function MainActivity:init(initFunc, refreshFunc)
    if initFunc then
        initFunc(self)
    end
    RefreshFunc = refreshFunc
    for _, config in pairs(CommonActivityConfig:getAllCommonMoney()) do
        if config.moneyType > 100 then
            PlayerWallet:setMoneyCount(config.moneyType, 0)
            registerMoneyIcon(config.moneyType, config.moneyIcon)
        end
    end
end

---@param activity CommonActivityData
function MainActivity:addActivity(activity)
    if not activity then
        LogUtil.logError(string.format("MainActivity:addActivity ,activity not exist"))
        return
    end
    CurrentActivity[tostring(activity.id)] = BaseActivityMgr.createMgr(activity)
    if RefreshFunc then
        RefreshFunc()
    end
end

function MainActivity:removeActivity(activityId)
    CurrentActivity[tostring(activityId)] = nil
    if RefreshFunc then
        RefreshFunc()
    end
end

---@return CBaseActivityMgr
function MainActivity:getActivity(activityId)
    return CurrentActivity[tostring(activityId)]
end

function MainActivity:getAllActivity()
    ---@type CBaseActivityMgr[]
    local mgrList = {}
    for _, activityMgr in pairs(CurrentActivity) do
        table.insert(mgrList, activityMgr)
    end
    table.sort(mgrList, function(a, b)
        return a.mainConfig.sort < b.mainConfig.sort
    end)
    return mgrList
end

function MainActivity:getRewardGroupById(groupId)
    return CommonActivityConfig:getRewardGroupById(groupId)
end

function MainActivity:getRewardById(rewardId)
    return CommonActivityConfig:getRewardById(rewardId)
end

---@return CommonActivityConfig
function MainActivity:getCommonConfig()
    return CommonActivityConfig
end

---@return BlindBoxLotteryConfig
function MainActivity:getBlindBoxConfig()
    return BlindBoxConfig
end

return MainActivity
