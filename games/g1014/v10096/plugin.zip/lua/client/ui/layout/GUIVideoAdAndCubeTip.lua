---@class UIVideoAdAndCubeTipLayout : IGUILayout
local UIVideoAdAndCubeTipLayout = class("UIVideoAdAndCubeTipLayout", IGUILayout)

---@private
function UIVideoAdAndCubeTipLayout:ctor(parent)
	self.super.ctor(self, "VideoAdAndCubeTip.json", parent)
	PlayerManager:getClientPlayer().reviveHere=true
end

---@private
function UIVideoAdAndCubeTipLayout:isDelayLoad()
	return true
end

---@private
function UIVideoAdAndCubeTipLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIVideoAdAndCubeTipLayout:initCreateEvent()

end

---@private
function UIVideoAdAndCubeTipLayout:onLoad()
	self.llPanel = self:getChildWindow("VideoAdAndCubeTip-Panel", GUIType.Layout)
	self.llTitle = self:getChildWindow("VideoAdAndCubeTip-Title", GUIType.Layout)
	self.stTitleName = self:getChildWindow("VideoAdAndCubeTip-Title-Name", GUIType.StaticText)
	self.btnClose = self:getChildWindow("VideoAdAndCubeTip-Close", GUIType.Button)
	self.llContent = self:getChildWindow("VideoAdAndCubeTip-Content", GUIType.Layout)
	self.stContentText = self:getChildWindow("VideoAdAndCubeTip-Content-Text", GUIType.StaticText)
	self.ButtonPanel = self:getChildWindow("VideoAdAndCubeTip-Button-Panel", GUIType.DefaultWindow)
	self.rbReviveHere = self:getChildWindow("VideoAdAndCubeTip-RadioReviveHere", GUIType.RadioButton)
	self.rbReviveBase = self:getChildWindow("VideoAdAndCubeTip-RadioReviveBase", GUIType.RadioButton)
	self.btnWatch = self:getChildWindow("VideoAdAndCubeTip-Watch", GUIType.Button)
	self.siWatchIcon = self:getChildWindow("VideoAdAndCubeTip-Watch-Icon", GUIType.StaticImage)
	self.stWatchTips = self:getChildWindow("VideoAdAndCubeTip-Watch-Tips", GUIType.StaticText)
	self.btnCube = self:getChildWindow("VideoAdAndCubeTip-Cube", GUIType.Button)
	self.siCubeIcon = self:getChildWindow("VideoAdAndCubeTip-Cube-Icon", GUIType.StaticImage)
	self.stCubeTips = self:getChildWindow("VideoAdAndCubeTip-Cube-Tips", GUIType.StaticText)
	self.siAdIcon = self:getChildWindow("VideoAdAndCubeTip-Ad-Icon", GUIType.StaticImage)
	self.stReviveHere = self:getChildWindow("VideoAdAndCubeTip-ReviveHere", GUIType.StaticText)
	self.stReviveBase = self:getChildWindow("VideoAdAndCubeTip-ReviveBase", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIVideoAdAndCubeTipLayout:initView()
	self.stTitleName:SetText("")
	self.stContentText:SetText(Lang:getString("g1014_revive_detail"))
	self.stWatchTips:SetText(Lang:getString("g1014_revive_no_invincible"))
	self.btnWatch:SetText(Lang:getString("g1014_revive_watch_ad"))
	self.stReviveHere:SetText(Lang:getString("g1014_revive_here"))
	self.stReviveBase:SetText(Lang:getString("g1014_revive_base"))
end

---@private
function UIVideoAdAndCubeTipLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:reviveFree()
		self:hide()
	end)
	self.rbReviveHere:registerEvent(GUIEvent.RadioStateChanged, function()
		if self.rbReviveHere:IsSelected() then
			self:selectRevivePos(true)
		end
	end)
	self.rbReviveBase:registerEvent(GUIEvent.RadioStateChanged, function(buton)
		if self.rbReviveBase:IsSelected() then
			self:selectRevivePos(false)
		end
	end)
	self.btnWatch:registerEvent(GUIEvent.ButtonClick, function()
		self:reviveByWatchAd()
	end)
	self.btnCube:registerEvent(GUIEvent.ButtonClick, function()
		self:reviveByCube()
	end)
end

function UIVideoAdAndCubeTipLayout:updateInf()
	self.stTitleName:SetText(string.format(Lang:getString("g1014_revive_name"),self.showUITime))
	self.btnCube:SetText(self.revivePrice)
	self.rbReviveHere:SetSelected(PlayerManager:getClientPlayer().reviveHere)
	self.rbReviveBase:SetSelected(not PlayerManager:getClientPlayer().reviveHere)
	local invincibleTime=PlayerManager:getClientPlayer().reviveHere and self.invincibleTimeHere or self.invincibleTimeBase
	self.stCubeTips:SetText(string.format(Lang:getString("g1014_revive_invincible"),invincibleTime))
	local showAd = ClientHelper.getBoolPrefs("ShowVideoAd")
	self.btnWatch:SetEnabled(self.watchAdTimesLimit and showAd)
end

function UIVideoAdAndCubeTipLayout:onShow(param)
	self.watchAdTimesLimit=param.watchAdTimesLimit
	self.adType=param.AdType
	self.showUITime=param.showUITime
	self.revivePrice=param.revivePrice
	self.invincibleTimeHere=param.invincibleTimeHere
	self.invincibleTimeBase=param.invincibleTimeBase
	self:startDownTimer()
	self:updateInf()
end

function UIVideoAdAndCubeTipLayout:onHide()
	self:stopDownTimer()
end

function UIVideoAdAndCubeTipLayout:startDownTimer()
	self:stopDownTimer()
	self.remainTime=self.showUITime
	self.downTimerKey=LuaTimer:scheduleTimer(function()
		self.remainTime = self.remainTime - 1
		self:updateTimeShow()
	end, 1000)
end

function UIVideoAdAndCubeTipLayout:stopDownTimer()
	if self.downTimerKey then
		LuaTimer:cancel(self.downTimerKey)
		self.downTimerKey = nil
	end
end

function UIVideoAdAndCubeTipLayout:updateTimeShow()
	if self.remainTime <= 0 then
		self:reviveFree()
		self:hide()
		return
	end
	self.stTitleName:SetText(string.format(Lang:getString("g1014_revive_name"),self.remainTime))
end

function UIVideoAdAndCubeTipLayout:reviveFree()
	--print("--------------------------- UIVideoAdAndCubeTipLayout:reviveFree ")
	PlayerManager:getClientPlayer():sendPacket({
		pid = "reviveFree"
	})
end

function UIVideoAdAndCubeTipLayout:selectRevivePos(here)
	PlayerManager:getClientPlayer().reviveHere=here
	self:updateInf()
end

function UIVideoAdAndCubeTipLayout:reviveByCube()
	PayHelper.checkMoney(CurrencyId.GCube, self.revivePrice, function(success)
		if success then
			PlayerManager:getClientPlayer():sendPacket({
				pid = "reviveByCube",
				reviveHere=PlayerManager:getClientPlayer().reviveHere
			})
			self:hide()
		end
	end)
end

function UIVideoAdAndCubeTipLayout:reviveByWatchAd()
	ClientHelper.onWatchAd(self.adType,tostring(PlayerManager:getClientPlayer().reviveHere))
	self:hide()
end


return UIVideoAdAndCubeTipLayout
