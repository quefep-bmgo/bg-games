---@class SPacketHandlers : SBasePlayer
local PacketHandlers = T(Global, "PacketHandlers")
---@type function[]
local Session = T(Global, "Session")
---@type SBasePlayer
local SBasePlayer = BasePlayer

---@param packet PidPacket
function SBasePlayer:sendPacket(packet, resp, ignoreReady)
    assert(not packet.__session__)
    if not self.entityPlayerMP or not packet.pid then
        return
    end
    if resp then
        assert(type(resp) == "function")
        local session = #Session + 1
        Session[session] = resp
        packet.__session__ = session
    end
    local success, res = pcall(serialize.encode, packet)
    if not success then
        LogUtil.logScriptException("[SBasePlayer:sendPacket]", res)
        return
    end
    PacketSender:sendLuaCommonData(self.rakssid, "pid", res, ignoreReady)
end

---@param packet PidPacket
function SBasePlayer:broadCastPacket(packet, ignoreReady)
    if not self.entityPlayerMP or not packet.pid then
        return
    end
    local success, res = pcall(serialize.encode, packet)
    if not success then
        LogUtil.logScriptException("[SBasePlayer:broadCastPacket]", res)
        return
    end
    PacketSender:broadCastLuaCommonData("pid", res, ignoreReady)
end

---@param packet PidPacket
function SBasePlayer:sendTrackingPacket(packet, ignoreReady)
    if not self.entityPlayerMP or not packet.pid then
        return
    end
    local success, res = pcall(serialize.encode, packet)
    if not success then
        LogUtil.logScriptException("[SBasePlayer:sendTrackingPacket]", res)
        return
    end
    PacketSender:sendLuaCommonDataToTrackingPlayers(self:getEntityId(), "pid", res, ignoreReady)
end

---@param packet PidPacket
CommonDataEvents:registerCallBack("pid", function(userId, packet)
    if not packet.pid then
        LogUtil.logScriptException("[PacketHandlers] can not find pid.", "userId = " .. userId, StringUtil.v2s(packet))
        return
    end
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local func = PacketHandlers[packet.pid]
    if not func then
        LogUtil.logWarning("[PacketHandlers] can not find func, pid=" .. packet.pid)
        return
    end
    local ret = func(player, packet)
    if packet.__session__ ~= nil then
        player:sendPacket({
            pid = "resp",
            session = packet.__session__,
            ret = ret
        })
    end
end, SerializeBuilderProcessor)

function PacketHandlers:resp(packet)
    Session[packet.session](packet.ret)
    Session[packet.session] = nil
end

---@param player SBasePlayer
function PacketHandlers.GMOpenInputBack(player, packet)
    if player.GMCallBack then
        player.GMCallBack(unpack(packet.params))
        player.GMCallBack = nil
    end
end

---@param self SBasePlayer
function PacketHandlers.PerformanceReport(self, packet)
    self.performance = { fps = packet.fps, netPing = packet.netPing, logicPing = packet.logicPing }
end

---@param self SBasePlayer
function PacketHandlers.onWatchAdSuccess(self, packet)
    if isLocalWin then
        CEvents.WatchAdvertFinishedEvent:invoke(self.rakssid, packet.type, packet.params, 1)
    end
end

return PacketHandlers
