---
--- Created by Jimmy.
--- DateTime: 2018/3/9 0009 11:29
---

LogicListener = {}

function LogicListener:init()
    CEvents.PotionConvertGlassBottleEvent:registerCallBack(self.onPotionConvertGlassBottle)
    CEvents.UseItemBucketInBlockEvent:registerCallBack(self.onUseItemBucketInBlock)
end

function LogicListener.onPotionConvertGlassBottle(entityId, itemId)
   return false
end

function LogicListener.onUseItemBucketInBlock()
   return false
end

return LogicListener