---
--- Created by Jimmy.
--- DateTime: 2018/6/8 0008 11:51
---
require "util.VideoAdHelper"

CustomListener = {}

---@type SPidPacketSender
local SPidPacketSender = T(Global, "PidPacketSender")

function CustomListener:init()
    CEvents.WatchAdvertFinishedEvent:registerCallBack(self.onWatchAdvertFinished)
    Events.CloseVideoAdTipEvent:registerCallBack(self.onCloseVideoAdTip)
    Events.CommonReceiveRewardEvent:registerCallBack(self.onCommonReceiveReward)
    Events.CommonCanReceiveRewardEvent:registerCallBack(self.onCommonCanReceiveReward)
end

function CustomListener.onWatchAdvertFinished(rakssid, type, params, code)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return
    end
    if code ~= 1 then
        if type == Define.AdType.RespawnAd then
            RespawnHelper.sendRespawnCountdown(player, 1)
        end
        return
    end
    if type == Define.AdType.UnlockVehicle then
        local entityId = DataBuilder.new():fromData(params):getNumberParam("EntityId")
        VideoAdHelper:doUnlockVehicleReward(player, entityId)
        return
    end
    if type == Define.AdType.RespawnAd then
        VideoAdHelper:doRespawnVideoAdReward(player,params)
        return
    end
    if type == Define.AdType.Shop then
        local itemId = DataBuilder.new():fromData(params):getNumberParam("ItemId")
        VideoAdHelper:doShopVideoAdReward(player, itemId)
        return
    end
end

function CustomListener.onCloseVideoAdTip(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local type = DataBuilder.new():fromData(data):getNumberParam("Type")
    if type == Define.AdType.RespawnAd then
        RespawnHelper.sendRespawnCountdown(player, 1)
        return
    end
end

function CustomListener.onCommonReceiveReward(player, propsType, propsId, propsCount, expireTime)
    --print("===================================>> onCommonReceiveReward",propsType, propsId,propsCount)
    if propsType=="Gun" then
        local num=1
        local meta = 0
        local id=propsId
        local max = WeaponConfig:getGunMaxBullet(id)
        player:addGunItem(id, num, meta, max)
    elseif propsType == "Bullet" or propsType== "Item" then
        if propsId > 0 and propsId < 10000 then
            player:addItem(propsId, propsCount, 0)
        elseif propsId == 10000 then
            player:addCurrency(propsCount)
        end
    end
end

function CustomListener.onCommonCanReceiveReward(player, result,doNotShowTips)
    local needStackCount = 0
    for _, cfg in pairs(result) do
        if cfg.type == "Item" or cfg.type == "Gun" or cfg.type == "Bullet" then
            if cfg.rewardId > 0 and cfg.rewardId < 10000 then
                needStackCount = needStackCount + math.ceil(cfg.count / 64)
            end
        end
    end
    if player then
        local inventory=player:getInventory()
        if inventory and inventory.getEmptyStackCount and  needStackCount > inventory:getEmptyStackCount() then
            if not doNotShowTips then
                SPidPacketSender:sendShowToast(player.rakssid, "common.activity.tip.needBackPack")
            end
            return false
        end
    end
    return true
end

return CustomListener
--endregion
