---@class UISubscriptionVipEntryLayout : IGUILayout
local UISubscriptionVipEntryLayout = class("UISubscriptionVipEntryLayout", IGUILayout)

---@private
function UISubscriptionVipEntryLayout:ctor(parent)
	self.super.ctor(self, "SubscriptionVipEntry.json", GUIManager:getMainControl())
end

---@private
function UISubscriptionVipEntryLayout:isDelayLoad()
	return true
end

---@private
function UISubscriptionVipEntryLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UISubscriptionVipEntryLayout:initCreateEvent()

end

---@private
function UISubscriptionVipEntryLayout:onLoad()
	self.btnBtn = self:getChildWindow("SubscriptionVipEntry-Btn", GUIType.Button)
	self.siRedDot = self:getChildWindow("SubscriptionVipEntry-RedDot", GUIType.StaticImage)
	self.stTitle = self:getChildWindow("SubscriptionVipEntry-Title", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function UISubscriptionVipEntryLayout:initView()
	self.stTitle:SetText(Lang:getString("vip.entry"))
end

---@private
function UISubscriptionVipEntryLayout:initEvent()
	self.btnBtn:registerEvent(GUIEvent.ButtonClick, function()
		UIHelper.showGameGUILayout("GUISubscriptionVip")
	end)
end

function UISubscriptionVipEntryLayout:onShow()
end


return UISubscriptionVipEntryLayout
