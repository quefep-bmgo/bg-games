---@class CPacketHandlers : CBasePlayer
local PacketHandlers = T(Global, "PacketHandlers")
---@type function[]
local Session = T(Global, "Session")
---@type CBasePlayer
local CBasePlayer = BasePlayer

---@param packet PidPacket
function CBasePlayer:sendPacket(packet, resp)
    assert(not packet.__session__)
    if not packet.pid then
        return
    end
    if resp then
        assert(type(resp) == "function")
        local session = #Session + 1
        Session[session] = resp
        packet.__session__ = session
    end
    local success, res = pcall(serialize.encode, packet)
    if not success then
        LogUtil.logScriptException("[CBasePlayer:sendPacket]", res)
        return
    end
    PacketSender:sendLuaCommonData("pid", res)
end

---@param packet PidPacket
CommonDataEvents:registerCallBack("pid", function(packet)
    if not packet.pid then
        LogUtil.logScriptException("[PacketHandlers] can not find pid.", StringUtil.v2s(packet))
        return
    end
    local func = PacketHandlers[packet.pid]
    if not func then
        LogUtil.logWarning("[PacketHandlers] can not find func, pid=" .. packet.pid)
        return
    end
    local player = PlayerManager:getClientPlayer()
    local ret = func(player, packet)
    if packet.__session__ ~= nil then
        player:sendPacket({
            pid = "resp",
            session = packet.__session__,
            ret = ret
        })
    end
end, SerializeBuilderProcessor)

function PacketHandlers:resp(packet)
    Session[packet.session](packet.ret)
    Session[packet.session] = nil
end

function PacketHandlers:openGMHelper()
    GMHelper:enableGM()
end

function PacketHandlers:openErrorLog()
    local ErrorLogIds = T(Global, "ErrorLogIds")
    table.insert(ErrorLogIds, Game:getPlatformUserId())
end

function PacketHandlers:AddEventToDialog(packet)
    if GUIGMMain then
        GUIGMMain:addEventToDialog(packet.event_map)
    else
        LuaTimer:schedule(function()
            PacketHandlers.AddEventToDialog(self, packet)
        end, 1000)
    end
end

function PacketHandlers:showToast(packet)
    UIHelper.showToast(Lang:getString(packet.content), packet.time)
end

function PacketHandlers:GMOpenInput(packet)
    GUIGMControlPanel:openInput(packet.paramTexts, function(...)
        PlayerManager:getClientPlayer():sendPacket({
            pid = "GMOpenInputBack",
            params = { ... }
        })
    end)
end

function PacketHandlers:TotalRechargeCube(packet)
    PlayerManager:getClientPlayer().total_recharge_cube = packet.gcube
end

function PacketHandlers:DebugCmd(packet)
    ---@type DebugCmd
    local DebugCmd = T(Global, "DebugCmd")
    DebugCmd:doCmd({}, packet.line, false)
    return T(Global, "PrintCache")
end

return PacketHandlers