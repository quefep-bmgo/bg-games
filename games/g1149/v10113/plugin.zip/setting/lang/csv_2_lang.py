# -*- coding: UTF-8 -*-
import os
import argparse
import csv

lang_map = {}


def count_sub_str(string, match):
    return string.count(match)


def make_dir(path: str):
    if not os.path.exists(path):
        os.makedirs(path)


def has_error_newline(string: str):
    if string.find("\\") == -1:
        return False
    size = len(string)
    count = 0
    for index in range(0, size):
        if count > 0:
            count = count - 1
            continue
        char = string[index]
        if char == "\\" and index < size - 2:
            count = 2
            if string[index + 1] != "\\" or string[index + 2] != "n":
                return True
    return False


def safe_input(text):
    try:
        input(text)
    except EOFError:
        pass


def csv_to_list(path):
    items = []
    with open(path, "r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.reader(csv_file, delimiter="\t", quotechar='"')
        rows = list(reader)
    if len(rows) == 0:
        return items

    titles = []
    for title in rows[0]:
        if title == "":
            break
        titles.append(title)

    for row in rows[1:]:
        item = {}
        for index in range(0, len(titles)):
            if index < len(row):
                item[titles[index]] = row[index]
            else:
                item[titles[index]] = ""
        items.append(item)
    return items


def start(file):
    if not os.path.exists(file):
        print("“" + file + "”文件不存在")
        safe_input("按回车关闭")
        return
    print("正在读取csv文件...")
    lang_list = csv_to_list(file)
    if len(lang_list) == 0:
        return

    empty_map = {}
    error_map = {}
    newline_map = {}
    for key in lang_list[0].keys():
        if key != "key":
            lang_map[key] = {}
            empty_map[key] = []
            error_map[key] = []
            newline_map[key] = []

    print("正在导出多语言文件...")
    replace_keys = []
    for lang in lang_map.keys():
        langs = lang_map[lang]
        for item in lang_list:
            key = item["key"]
            zh_text = "zh" in item.keys() and item["zh"] or ""
            if type(key) == str and len(key) > 0:
                key = key.strip()
                if key in langs.keys() and key not in replace_keys:
                    replace_keys.append(key)
                if lang not in item.keys() or item[lang] == "":
                    empty = empty_map[lang]
                    if "en" not in item.keys() or item["en"] == "":
                        langs[key] = zh_text
                    else:
                        langs[key] = item["en"]
                        empty.append([key, "en", item["en"]])
                else:
                    text = item[lang]
                    langs[key] = text
                    if count_sub_str(text, "%s") != count_sub_str(zh_text, "%s"):
                        error = error_map[lang]
                        error.append([key, "%s"])
                    if count_sub_str(text, "%d") != count_sub_str(zh_text, "%d"):
                        error = error_map[lang]
                        error.append([key, "%d"])
                    if has_error_newline(text):
                        newline = newline_map[lang]
                        newline.append([key, text])

    if len(replace_keys) > 0:
        print("存在重复多语言：", replace_keys)
        safe_input("按回车继续")

    need_input = False
    for lang in empty_map.keys():
        empty = empty_map[lang]
        for item in empty:
            print("检测到空值：lang=" + lang + ", key=" + item[0] + ", 替换成：lang=" + item[1] + ", 文本=" + item[2])
            need_input = True
    if need_input:
        safe_input("按回车继续")

    need_input = False
    for lang in error_map.keys():
        error = error_map[lang]
        for item in error:
            print("检测到占位字符缺失：lang=" + lang + ", key=" + item[0] + ", 占位字符=" + item[1])
            need_input = True
    if need_input:
        safe_input("按回车继续")

    need_input = False
    for lang in newline_map.keys():
        newline = newline_map[lang]
        for item in newline:
            print("检测到换行符异常：lang=" + lang + ", key=" + item[0] + ", 文本=" + item[1])
            need_input = True
        break
    if need_input:
        safe_input("按回车继续")

    lang_path = os.getcwd()
    make_dir(lang_path)
    for lang in lang_map.keys():
        file_path = os.path.join(lang_path, lang + ".lang")
        file = open(file_path, "w", encoding='utf-8')
        langs = lang_map[lang]
        lines = []
        for key in langs.keys():
            text = langs[key]
            if text == "":
                if len(lines) != 0:
                    lines.append("\n----------" + key + "----------")
                else:
                    lines.append("----------" + key + "----------")
            else:
                lines.append(key + "=" + langs[key])
        file.write("\n".join(lines))
        file.close()
        print("导出多语言文件：" + file_path)

    print("多语言导出完成！")
    safe_input("按回车关闭")


def parse_args():
    description = u'导出多语言脚本'
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('-f', '--file', default='g1149',
                        required=False, help=u'csv文件名，例如：g1149')
    return parser.parse_args()


def main():
    args = parse_args()
    file = args.file
    if file.find(".csv") == -1:
        file = file + ".csv"
    start(file)


if __name__ == '__main__':
    main()
