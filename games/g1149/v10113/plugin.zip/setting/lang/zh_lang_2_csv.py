# -*- coding: UTF-8 -*-
import os
import csv

CSV_FILE = "g1149.csv"
ZH_LANG_FILE = "zh.lang"


def parse_lang_line(line):
    words = line.split("=", 1)
    if len(words) != 2:
        return None, None
    key = words[0].strip().rstrip("=").strip()
    text = words[1]
    if text.startswith("="):
        text = text[1:]
    return key, text


def read_zh_lang(path):
    result = {}
    order = []
    with open(path, "r", encoding="utf-8-sig") as lang_file:
        for line in lang_file:
            line = line.rstrip("\n\r")
            if line == "" or line.startswith("----------"):
                continue
            key, text = parse_lang_line(line)
            if key is None:
                continue
            if key == "":
                continue
            if key not in result:
                order.append(key)
            result[key] = text
    return result, order


def read_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.reader(csv_file, delimiter="\t", quotechar='"')
        rows = list(reader)
    return rows


def write_csv(path, rows):
    with open(path, "w", encoding="utf-8", newline="") as csv_file:
        writer = csv.writer(csv_file, delimiter="\t", quotechar='"', lineterminator="\n")
        writer.writerows(rows)


def main():
    if not os.path.exists(ZH_LANG_FILE):
        print("zh.lang文件不存在")
        input("按回车关闭")
        return
    if not os.path.exists(CSV_FILE):
        print("g1149.csv文件不存在")
        input("按回车关闭")
        return

    zh_map, zh_order = read_zh_lang(ZH_LANG_FILE)
    rows = read_csv(CSV_FILE)
    if len(rows) == 0:
        print("g1149.csv内容为空")
        input("按回车关闭")
        return

    titles = rows[0]
    if "key" not in titles or "zh" not in titles:
        print(CSV_FILE + "中找不到key列或zh列")
        input("按回车关闭")
        return

    key_index = titles.index("key")
    zh_index = titles.index("zh")
    column_count = len(titles)

    exists_keys = set()
    for row in rows[1:]:
        if key_index < len(row):
            key = row[key_index].strip()
            if key != "":
                exists_keys.add(key)

    add_keys = []
    for key in zh_order:
        if key in exists_keys:
            continue
        row = [""] * column_count
        row[key_index] = key
        row[zh_index] = zh_map[key]
        rows.append(row)
        exists_keys.add(key)
        add_keys.append(key)

    if len(add_keys) == 0:
        print("没有差异，未写入任何key。")
    else:
        write_csv(CSV_FILE, rows)
        print("本次写入key：")
        for key in add_keys:
            print(key)
        print("共写入" + str(len(add_keys)) + "个key。")

    input("按回车关闭")


if __name__ == '__main__':
    main()
