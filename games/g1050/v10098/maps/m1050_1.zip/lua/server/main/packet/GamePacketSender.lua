GamePacketSender = {}

function GamePacketSender:sendSkyBlockLoadingResult(rakssid, loading)
    PacketSender:sendLuaCommonData(rakssid, "SkyBlockLoading", tostring(loading))
end

function GamePacketSender:sendSignPostData(rakssid, data)
    PacketSender:sendLuaCommonData(rakssid, "EditSignPost", data)
end

function GamePacketSender:sendWelcomeVisitorTip(rakssid, data)
    PacketSender:sendLuaCommonData(rakssid, "WelcomeTip", data)
end

return GamePacketSender