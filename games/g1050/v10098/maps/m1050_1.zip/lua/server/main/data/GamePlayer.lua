---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
require "main.data.GameManor"
require "main.Match"

---@type ReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type SSkyBlockPlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type ReportValue
local ReportValue = T(Global, "ReportValue")
---@type MultiBuildMgr
local MultiBuildMgr = T(Global, "MultiBuildMgr")
---@type SSkyBlockPlayer
GamePlayer = class("GamePlayer", SSkyBlockPlayer)

function GamePlayer:init()
    SSkyBlockPlayer.init(self)
    self:initStaticAttr(0)
    self.manorIndex = 0
    self.curXChunkIndex = 0
    self.curYChunkIndex = 0
    self.curZChunkIndex = 0
    self.lastXChunkIndex = 0
    self.lastYChunkIndex = 0
    self.lastZChunkIndex = 0
    self.posOriginX = 0
    self.posOriginY = 0
    self.posOriginZ = 0
    self.score = 0
    self.respawnPos = VectorUtil.newVector3(102, 100, 100)
    self.genislandPos = GameConfig.genislandPos
    self.isGenisland = false
    self.target_user_id = nil

    local manorIndex = 0
    local targetUserId = GameMatch:getTargetByUid(self.userId)
    if targetUserId ~= nil then
        local targetManorInfo = GameMatch:getUserManorInfo(targetUserId)
        if targetManorInfo ~= nil then
            manorIndex = targetManorInfo.manorIndex
            local pos = GameConfig:getInitPosByManorIndex(targetManorInfo.manorIndex)
            if pos then
                if GameMatch:isMaster(self.userId) then
                    local manorInfo = GameMatch:getUserManorInfo(self.userId)
                    if manorInfo then
                        local rPos = manorInfo:aPosToRPos(pos)
                        if rPos then
                            self.respawnPos = rPos
                            HostApi.log("respawnPos master aPos  " .. tostring(self.userId) .. " " .. pos.x .. " " .. pos.y .. " " .. pos.z)
                            HostApi.log("respawnPos master rPos  " .. tostring(self.userId) .. " " .. self.respawnPos.x .. " " .. self.respawnPos.y .. " " .. self.respawnPos.z)
                        end
                    end
                else
                    HostApi.log("respawnPos vistor aPos  " .. tostring(self.userId) .. " " .. pos.x .. " " .. pos.y .. " " .. pos.z)
                end
                self:setRespawnPos(pos)
                self:teleportPos(pos)
                self.manorIndex = targetManorInfo.manorIndex
                self.target_user_id = targetUserId
                DbUtil.getPlayerData(targetUserId, DbUtil.TAG_SIGN)
                DbUtil.getPlayerData(targetUserId, DbUtil.TAG_ACTOR)
            end
        end
    end
    self.isLife = true
    self:initChunkIndex()
    self.initBlockCd = {}
    self.isNotInPartyCreateOrOver = true
    self.manorIsExistWhenReady = false
    self.checkAreaNormalCd = 0
end

function GamePlayer:initDataFromDB(data)
    if data.respawnPos ~= nil and data.respawnPos.x and data.respawnPos.y and data.respawnPos.z then
        self.respawnPos = VectorUtil.newVector3(data.respawnPos.x, data.respawnPos.y, data.respawnPos.z)
        HostApi.log("respawnPos GamePlayer  " .. tostring(self.userId) .. " " .. self.respawnPos.x .. " " .. self.respawnPos.y .. " " .. self.respawnPos.z)
        if self.respawnPos.x < 0 or self.respawnPos.y < 0 or self.respawnPos.z < 0
                or self.respawnPos.x > 200 or self.respawnPos.y > 200 or self.respawnPos.z > 200 then
            self.respawnPos.x = 102
            self.respawnPos.y = 100
            self.respawnPos.z = 100
        end
    end
    self:teleInitPos()
end

function GamePlayer:teleportHall()
    if not self.entityPlayerMP then
        return
    end
    if self.info then
        self.info:setValue(Define.PlayerInfoKey.InHome, false)
        ReportValue.setValue(self.userId, "area_name", "hall", true)
        ReportEvent.reportEvent(self.userId, "enter_area")
        self.buff:trigger("onAreaChange")
    end
    self:teleportPosWithYaw(self.genislandPos, GameConfig.genislandYaw)
    self:setRespawnPos(self.genislandPos)
    self.isGenisland = true
    HostApi.log("self.genislandPos x : " .. self.genislandPos.x .. " y : " .. self.genislandPos.y .. " z : " .. self.genislandPos.z)
    self.privilege:onBackHome(self)
    MultiBuildMgr:checkUseItemBucketState(self)
end

function GamePlayer:teleInitPos()
    if self.isGenisland == true then
        self:teleportHall()
        return
    end
    self.privilege:onBackHome(self)
    if not GameMatch:isMaster(self.userId) then
        local targetUserId = GameMatch:getTargetByUid(self.userId)
        if targetUserId ~= nil then
            local targetManorInfo = GameMatch:getUserManorInfo(targetUserId)
            if targetManorInfo ~= nil then
                local pos = GameConfig:getInitPosByManorIndex(targetManorInfo.manorIndex)
                if pos then
                    self:teleportPosWithYaw(pos, 90)
                    self:setRespawnPos(pos)
                    HostApi.log("teleInitPos " .. pos.x .. " " .. pos.y .. " " .. pos.z)
                end
            end
        end
    else
        self:checkBackHome()
    end
end

function GamePlayer:teleHomeWithYaw()
    local manorInfo = GameMatch:getUserManorInfo(self.userId)
    if not manorInfo then
        return
    end
    local pos = manorInfo:rPosToAPos(self.respawnPos)
    local aPos = VectorUtil.newVector3(pos.x + 0.5, pos.y, pos.z + 0.5)
    HostApi.log("teleHomeWithYaw  self.userId is : " .. tostring(self.userId) .. " aPos is : " .. aPos.x .. " " .. aPos.y .. " " .. aPos.z .. " self.manorIndex is : " .. self.manorIndex)
    self:setFlying(false)
    self:teleportPosWithYaw(aPos, 90)
    self:setRespawnPos(aPos)
    self.isGenisland = false
    self.backHomeTime = os.time()
    self.privilege:onBackHome(self)
    self.info:tryShowLoginTip(self)
    MsgSender.sendCenterTipsToTarget(self.rakssid, 1, Messages:msgBackHomeSuccess())
    MultiBuildMgr:checkUseItemBucketState(self)

    -- out of vistors list of current manor
    self.manorIndex = manorInfo.manorIndex
    self.target_user_id = manorInfo.userId
    self:initChunkIndex()
    GameMatch:leaveCurrentManor(self.userId)
    GameMatch:initCallOnTarget(self.userId, self.userId)

    -- must be self manor
    local targetUserId = GameMatch:getTargetByUid(self.userId)
    if targetUserId ~= nil then
        local targetManorInfo = GameMatch:getUserManorInfo(targetUserId)
        if targetManorInfo ~= nil then
            self.manorIndex = targetManorInfo.manorIndex
            self.target_user_id = targetManorInfo.userId
            self:initChunkIndex()

            -- player's manor is not exist when ready
            -- go home need to get data and init data
            if not self.manorIsExistWhenReady and self:checkReady() then
                targetManorInfo:masterLogin()
                targetManorInfo:refreshTime()
                targetManorInfo:initAllTree()
                --targetManorInfo:initAllDirt()
                if not DBManager:isLoadDataFinished(targetManorInfo.userId, DbUtil.TAG_MANOR) then
                    DbUtil.getPlayerData(targetManorInfo.userId, DbUtil.TAG_MANOR)
                end
                self.manorIsExistWhenReady = true
            end

        end
    end
end

function GamePlayer:checkBackHome()
    --check home is in this server and party is over
    local manorInfo = GameMatch:getUserManorInfo(self.userId)
    if manorInfo == nil or manorInfo.isNotInPartyCreateOrOver == false then
        MsgSender.sendTopTipsToTarget(self.rakssid, 1000, Messages:msgTransmitting())
        self.info:onJumpGame()
        EngineUtil.sendEnterOtherGame(self.rakssid, "g1048", self.userId)
        if manorInfo then
            HostApi.log("checkBackHome self.userId : " .. tostring(self.userId) .. "  manorInfo.isNotInPartyCreateOrOver : " .. tostring(manorInfo.isNotInPartyCreateOrOver))
        else
            HostApi.log("checkBackHome self.userId : " .. tostring(self.userId) .. "  home is in this server")
        end
        return true
    else
        self:backHome()
        return false
    end
end

function GamePlayer:backHome()
    if self.info then
        self.info:setValue(Define.PlayerInfoKey.InHome, true)
        self.info:setValue(Define.PlayerInfoKey.TargetId, self.userId)
        ReportValue.setValue(self.userId, "area_name", "private_house", true)
        ReportEvent.reportEvent(self.userId, "enter_area")
        self.buff:trigger("onAreaChange")
    end
    --check respawnPos is safe
    if self.respawnPos and self.respawnPos.x and self.respawnPos.y and self.respawnPos.z then
        local manorInfo = GameMatch:getUserManorInfo(self.userId)
        if manorInfo then
            local aPos = manorInfo:rPosToAPos(self.respawnPos)
            local d_Pos = VectorUtil.toBlockVector3(aPos.x, aPos.y, aPos.z)
            local d_BlockId = EngineWorld:getBlockId(d_Pos)
            local u_Pos = VectorUtil.toBlockVector3(aPos.x, aPos.y + 1, aPos.z)
            local u_BlockId = EngineWorld:getBlockId(u_Pos)
            if u_BlockId ~= BlockID.AIR then
                self:moveHome(u_Pos, true)
            elseif d_BlockId ~= BlockID.AIR then
                self:moveHome(d_Pos, true)
            end
            local newPos = manorInfo:rPosToAPos(self.respawnPos)
            local underBlockPos = VectorUtil.toBlockVector3(newPos.x, newPos.y - 1, newPos.z)
            local blockId = EngineWorld:getBlockId(underBlockPos)
            if blockId == BlockID.LAVA_MOVING or blockId == BlockID.LAVA_STILL or blockId == BlockID.WATER_MOVING or blockId == BlockID.WATER_STILL then
                self:moveHome(underBlockPos, false)
            end
            self:teleHomeWithYaw()
        end
    end
end

function GamePlayer:moveHome(vec3, isBlock)
    -- check Home has been occupied or destroyed
    if not DbUtil.CanSavePlayerData(self, DbUtil.TAG_PLAYER) then
        return
    end
    local manorInfo = GameMatch:getUserManorInfo(self.userId)
    if not manorInfo then
        return
    end
    local aPos = manorInfo:rPosToAPos(self.respawnPos)
    local pos1 = VectorUtil.toVector3i(vec3)--has been BlockVector3i
    local pos2 = VectorUtil.toBlockVector3(aPos.x, aPos.y, aPos.z)
    local pos3 = VectorUtil.toBlockVector3(aPos.x, aPos.y - 1, aPos.z)
    local pos4 = VectorUtil.toBlockVector3(aPos.x, aPos.y + 1, aPos.z)
    local basePos = VectorUtil.newVector3i(0, 0, 0)
    if isBlock then
        if VectorUtil.equal(pos1, pos2) or VectorUtil.equal(pos1, pos4) then
            basePos = pos1
            HostApi.log("Home has been occupied self.userId : " .. tostring(self.userId))
        else
            return
        end
    else
        if VectorUtil.equal(pos1, pos3) then
            local originPos = GameConfig:getOriginPosByManorIndex(self.manorIndex)
            if originPos then
                basePos = VectorUtil.newVector3i(originPos.x, originPos.y - 5, originPos.z)--起始点和基岩的高度差为5
            end
            HostApi.log("Home has been destroyed self.userId : " .. tostring(self.userId))
        else
            return
        end
    end
    local posY = basePos.y
    local bodyPos_1 = VectorUtil.toBlockVector3(basePos.x, posY + 1, basePos.z)
    local bodyPos_2 = VectorUtil.toBlockVector3(basePos.x, posY + 2, basePos.z)
    local blockId_1 = EngineWorld:getBlockId(bodyPos_1)
    local blockId_2 = EngineWorld:getBlockId(bodyPos_2)
    local is_airWall = false
    local posY_upperLimit = GameConfig.airWall_MaxY - 2--252--basePos.y + math.ceil(GameConfig.manorMax)
    --正常情况用不到（万一复活点腿部被空气墙占用）
    if blockId_1 == 916 then
        posY_upperLimit = bodyPos_1.y
        bodyPos_2 = VectorUtil.toBlockVector3(bodyPos_1.x, bodyPos_1.y - 1, bodyPos_1.z)
        bodyPos_1 = VectorUtil.toBlockVector3(bodyPos_1.x, bodyPos_1.y - 2, bodyPos_1.z)
        EngineWorld:setBlockToAir(bodyPos_1)
        EngineWorld:setBlockToAir(bodyPos_2)
        is_airWall = true
    end

    while is_airWall == false and (blockId_1 ~= BlockID.AIR or blockId_2 ~= BlockID.AIR) and posY <= posY_upperLimit do
        posY = posY + 1
        bodyPos_1 = VectorUtil.toBlockVector3(basePos.x, posY + 1, basePos.z)
        bodyPos_2 = VectorUtil.toBlockVector3(basePos.x, posY + 2, basePos.z)
        blockId_1 = EngineWorld:getBlockId(bodyPos_1)
        blockId_2 = EngineWorld:getBlockId(bodyPos_2)
        if not isBlock then
            if VectorUtil.equal(pos1, bodyPos_1) then
                blockId_1 = BlockID.AIR
            end
            if VectorUtil.equal(pos1, bodyPos_2) then
                blockId_2 = BlockID.AIR
            end
        end
        --正常情况用不到（万一复活点头部被空气墙占用）
        if blockId_2 == 916 then
            posY_upperLimit = bodyPos_2.y
            bodyPos_2 = bodyPos_1
            bodyPos_1 = VectorUtil.toBlockVector3(bodyPos_1.x, bodyPos_1.y - 1, bodyPos_1.z)
            EngineWorld:setBlockToAir(bodyPos_1)
            EngineWorld:setBlockToAir(bodyPos_2)
            break
        end
    end
    local pos = manorInfo:aPosToRPos(VectorUtil.newVector3(bodyPos_1.x + 0.5, bodyPos_1.y, bodyPos_1.z + 0.5))
    if pos then
        self.respawnPos = pos
    end
end

function GamePlayer:update()
    if self.initBlockCd then
        for hash, time in pairs(self.initBlockCd) do
            if time > 0 then
                self.initBlockCd[hash] = self.initBlockCd[hash] - 1
            end
        end
    end
end

function GamePlayer:initChunkIndex()
    local target_pos = GameConfig:getInitPosByManorIndex(self.manorIndex)
    local origin_pos = GameConfig:getOriginPosByManorIndex(self.manorIndex)
    if origin_pos and target_pos then
        self.posOriginX = origin_pos.x - GameConfig.manorMax / 2
        self.posOriginY = origin_pos.y - GameConfig.manorMax / 2
        self.posOriginZ = origin_pos.z - GameConfig.manorMax / 2

        self.curXChunkIndex = math.floor((target_pos.x - self.posOriginX) / GameConfig.manorChunk)
        self.curYChunkIndex = math.floor((target_pos.y - self.posOriginY) / GameConfig.manorChunk)
        self.curZChunkIndex = math.floor((target_pos.z - self.posOriginZ) / GameConfig.manorChunk)
    end

    self.lastXChunkIndex = 0
    self.lastYChunkIndex = 0
    self.lastZChunkIndex = 0
end

function GamePlayer:onMove(x, y, z)
    if self:checkReady() == false then
        return
    end

    if self.isGenisland == true then
        return
    end

    if self.isNotInPartyCreateOrOver == false then
        return
    end

    local targetManorInfo = GameMatch:getUserManorInfo(self.target_user_id)
    if targetManorInfo == nil then
        return
    end

    local playerPos = VectorUtil.newVector3i(math.floor(self:getPosition().x), math.floor(self:getPosition().y), math.floor(self:getPosition().z))
    self.curXChunkIndex = math.floor((playerPos.x - self.posOriginX) / GameConfig.manorChunk)
    self.curYChunkIndex = math.floor((playerPos.y - self.posOriginY) / GameConfig.manorChunk)
    self.curZChunkIndex = math.floor((playerPos.z - self.posOriginZ) / GameConfig.manorChunk)

    if self.curXChunkIndex ~= self.lastXChunkIndex
            or self.curYChunkIndex ~= self.lastYChunkIndex
            or self.curZChunkIndex ~= self.lastZChunkIndex then
        self:checkNeedLoadData()
    end
    self.lastXChunkIndex = self.curXChunkIndex
    self.lastYChunkIndex = self.curYChunkIndex
    self.lastZChunkIndex = self.curZChunkIndex
end

function GamePlayer:checkChunkLoad()
    local targetManorInfo = GameMatch:getUserManorInfo(self.target_user_id)
    if targetManorInfo == nil then
        return false
    end

    if self.curXChunkIndex and self.curYChunkIndex and self.curZChunkIndex and self.target_user_id then
        local subKey = DbUtil.TAG_BLOCK_PRE .. "_" .. self.curXChunkIndex .. "_" .. self.curYChunkIndex .. "_" .. self.curZChunkIndex
        local newKey = subKey .. "v2"
        if DBManager:isLoadDataFinished(self.target_user_id, newKey) and not targetManorInfo.newKeyLock[newKey] then
            -- if DBManager:isLoadDataFinished(self.target_user_id, newKey) or DBManager:isLoadDataFinished(self.target_user_id, subKey) then
            return true
        end
    end

    return false
end

function GamePlayer:checkNeedLoadData()
    local manorNear = GameConfig.manorNear
    local x_down = GameConfig:checkChunk(self.curXChunkIndex - manorNear)
    local x_up = GameConfig:checkChunk(self.curXChunkIndex + manorNear)
    local y_down = GameConfig:checkChunk(self.curYChunkIndex - manorNear)
    local y_up = GameConfig:checkChunk(self.curYChunkIndex + manorNear)
    local z_down = GameConfig:checkChunk(self.curZChunkIndex - manorNear)
    local z_up = GameConfig:checkChunk(self.curZChunkIndex + manorNear)

    for x = x_down, x_up do
        for y = y_down, y_up do
            for z = z_down, z_up do
                local subKey = DbUtil.TAG_BLOCK_PRE .. "_" .. x .. "_" .. y .. "_" .. z
                local newKey = subKey .. "v2"
                if not DBManager:isLoadDataFinished(self.target_user_id, newKey) then
                    HostApi.log("GamePlayer:checkNeedLoadData " .. tostring(self.userId) .. " " .. tostring(self.target_user_id) .. " " .. newKey)
                    if self.target_user_id ~= nil then
                        if self.initBlockCd[newKey] == nil or self.initBlockCd[newKey] == 0 then
                            DbUtil.getPlayerData(self.target_user_id, newKey)
                            self.initBlockCd[newKey] = 30
                        end
                    end
                end
            end
        end
    end
end

function GamePlayer:onTick()
    self.checkAreaNormalCd = self.checkAreaNormalCd + 1
    if self.checkAreaNormalCd > 10 then
        self.checkAreaNormalCd = 0
        if not self:checkAreaNormal() then
            local playerPos = VectorUtil.newVector3i(math.floor(self:getPosition().x), math.floor(self:getPosition().y), math.floor(self:getPosition().z))
            HostApi.log("player may be cheat checkAreaNormal error" .. tostring(self.userId) .. " " .. tostring(self.target_user_id) .. " pos: " .. playerPos.x .. " " .. playerPos.y .. " " .. playerPos.z)
            HostApi.sendGameover(self.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
        end
    end
end

function GamePlayer:addScore(score)
    self.score = self.score + score
end

function GamePlayer:reward()
    RewardManager:getUserGoldReward(self.userId, self.score, function(data)

    end)
end

function GamePlayer:visitorCheckCanGetBlockData()
    local targetUserId = GameMatch:getTargetByUid(self.userId)
    if targetUserId then
        local targetPlayer = PlayerManager:getPlayerByUserId(targetUserId)
        if targetPlayer then
            if targetPlayer.isNotInPartyCreateOrOver == false then
                return false
            end
        end
    end

    return true
end

function GamePlayer:checkAreaNormal()

    if self:checkReady() == false then
        return true
    end

    local targetManorInfo = GameMatch:getUserManorInfo(self.target_user_id)
    if targetManorInfo then
        local playerPos = VectorUtil.newVector3i(math.floor(self:getPosition().x), math.floor(self:getPosition().y), math.floor(self:getPosition().z))
        if playerPos then
            if self.isGenisland then
                if self:checkIsInHallArea(playerPos) then
                    return true
                end
            else

                if targetManorInfo:isNormal(playerPos) then
                    return true
                end
            end
        end
    end
    return false
end

function GamePlayer:checkIsInHallArea(pos)
    return pos.x >= 801 and pos.x <= 1267
            and pos.y <= 254
            and pos.z >= 249 and pos.z <= 718
end

function GamePlayer:removeCurItem(num)
    num = num or 1
    local inv = self:getPlayerInventory()
    if not inv then
        return false
    end
    return inv:removeCurrentItem(num)
end

return GamePlayer

--endregion
