local PluginMain = {}

function PluginMain:init()
    BaseListener.registerCallBack(CEvents.GameInitEvent, self.onGameInit)
end

function PluginMain.onGameInit()
    TextureAtlasRegister.Instance():addTextureAtlas("home_icon.json", "", function(_, _)
    end, true)
    TextureAtlasRegister.Instance():addTextureAtlas("head_image.json", "", function(_, _)
    end, true)
end

PluginMain:init()

return PluginMain