local CommonMain = require "common.CommonMain"

BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
    CommonMain:onGameInit()
    if GameType ~= "g1048" then
        GameConfig = {}
        require "mine_hole.util.DbUtil"
        require "mine_hole.listener.PlayerListener"
        PlayerListener:init()
    else
        require "main.Match"
        require "main.task.GameTimeTask"
        require "main.listener.GameListener"
        require "main.listener.DBDataListener"
        require "main.listener.PlayerListener"
        require "main.listener.BlockListener"
        require "main.listener.LogicListener"
        GameListener.onGameInit(config)
        PlayerListener:init()
        DBDataListener:init()
        BlockListener:init()
        LogicListener:init()
        HostApi.setMaxChangeInChunk(512)
        ServerHelper.putBoolPrefs("NeedSyncSchematicPlaceBlock", true)
        ServerHelper.putBoolPrefs("BlockCustomMeta", true)
        DBManager:disableAutoCache()
    end
    BaseMain:setGameType(GameType)
    DBManager:setGameType("g1048")
    PlayerManager:setMaxPlayer(100)
end)