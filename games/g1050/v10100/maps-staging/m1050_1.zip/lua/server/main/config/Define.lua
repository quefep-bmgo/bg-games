Define.manorRelese = {
    Not = 1,
    Start = 2,
    End = 3,
}

Define.startReleaseTime = 120