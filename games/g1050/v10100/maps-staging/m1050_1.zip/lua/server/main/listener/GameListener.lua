--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
require "main.config.GameConfig"

GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameInitEvent, self.onGameInit)
end

function GameListener.onGameInit(config)
    GameConfig:init(config)
    GameMatch:initMatch()
end

return GameListener
--endregion