---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:16
---
require "main.config.Define"
require "main.config.ConfigurableBlockConfig"

GameConfig = {}
GameConfig.RootPath = ""

function GameConfig:init(config)
    self.deathLineY = tonumber(config.deathLineY or 2)
    self.manorMax = tonumber(config.manorMax) or 100
    self.manorChunk = tonumber(config.manorChunk) or 20
    self.manorStart = config.manorStart
    self.manorNear = tonumber(config.manorNear) or 3
    self.furnaceLimit = tonumber(config.furnaceLimit)
    self.initSchemetic = tostring(config.initSchemetic)
    self.initSchematicOffset = tonumber(config.initSchematicOffset)
    self.moonName = tostring(config.moonName) or "moon_phases.png"
    self.sunName = tostring(config.sunName) or "sun.png"
    self.airWall_MaxY = tonumber(config.airWall_MaxY or 254)
    self.genislandPos = VectorUtil.newVector3(config.genislandPosYaw[1] or 0, config.genislandPosYaw[2] or 300, config.genislandPosYaw[3] or 0)
    self.genislandYaw = tonumber(config.genislandPosYaw[4] or 0)
    self.snowTime = config.snowTime

    ConfigurableBlockConfig:initConfig(FileUtil.getConfigFromCsv("setting/configurableBlock.csv", 3))
end

function GameConfig:getInitPosByManorIndex(index)
    for _, manor in pairs(self.manorStart) do
        if tonumber(manor.index) == tonumber(index) then
            return VectorUtil.newVector3i(manor.init_pos[1], manor.init_pos[2], manor.init_pos[3])
        end
    end
    return nil
end

function GameConfig:getOriginPosByManorIndex(index)
    for _, manor in pairs(self.manorStart) do
        if tonumber(manor.index) == tonumber(index) then
            return VectorUtil.newVector3i(manor.origin_pos[1], manor.origin_pos[2], manor.origin_pos[3])
        end
    end
    return nil
end

function GameConfig:getChunkMax()
    return math.floor(self.manorMax / self.manorChunk)
end

function GameConfig:checkChunk(chunkIndex)
    local result = chunkIndex
    if result < 0 then
        result = 0
    end
    if result >= self:getChunkMax() then
        result = self:getChunkMax() - 1
    end
    return result
end

function GameConfig:decodeHash(hash)
    local hashString = StringUtil.split(hash, ":")
    if hashString then
        return tonumber(hashString[1]), tonumber(hashString[2]), tonumber(hashString[3]), tonumber(hashString[4] or 0)
    end
    return 0, 0, 0, 0
end

function GameConfig:decodeValue(value)
    local valueString = StringUtil.split(value, ":")
    if valueString then
        return tonumber(valueString[1]), tonumber(valueString[2])
    end
    return 0, 0
end

function GameConfig:isDoorItemBlock(id)
    return id == 324 or id == 330 or id == 510
end

function GameConfig:isDoorBlock(id)
    return id == BlockID.WHITE_WOOD_DOOR
            or id == BlockID.DOOR_WOOD
            or id == BlockID.DOOR_IRON
            or id == BlockID.FENCE_GATE
            or id == BlockID.WHITE_FENCE_GATE
end

function GameConfig:isAttachmentBlock(id)
    return id == BlockID.LADDER
            or id == BlockID.WOOL_CARPET
            or id == BlockID.TORCH_WOOD
            or id == BlockID.ALLIUM
            or id == BlockID.BLUE_ORCHID
            or id == BlockID.HOUSTONIA
            or id == BlockID.OXEYE_DAISY
            or id == BlockID.PAEONIA
            or id == BlockID.TULIP_PINK
            or id == BlockID.TULIP_RED
            or id == BlockID.TULIP_WHITE
            or id == BlockID.SAPLING
            or id == BlockID.SIGN_POST
            or id == BlockID.SIGN_WALL
            or id == BlockID.SAPLING
            or id == BlockID.FLOWER_POT
            or id == BlockID.WATER_MOVING
            or id == BlockID.WATER_STILL
            or id == BlockID.LAVA_MOVING
            or id == BlockID.LAVA_STILL
end

function GameConfig:isStairsBlock(id)
    return id == BlockID.STAIRS_WOOD_OAK
            or id == BlockID.STAIRS_COBBLESTONE
            or id == BlockID.STAIRS_BRICK
            or id == BlockID.STAIRS_STONE_BRICK
            or id == BlockID.STAIRS_NETHER_BRICK
            or id == BlockID.STAIRS_SAND_STONE
            or id == BlockID.STAIRS_WOOD_SPRUCE
            or id == BlockID.STAIRS_WOOD_BIRCH
            or id == BlockID.STAIRS_WOOD_JUNGLE
            or id == BlockID.STAIRS_NETHER_QUARTZ
            or id == BlockID.STAIRS_WOOD_DARKOAK
            or id == BlockID.BLOCK_ID_STAIRS_PRISMARINE
            or id == BlockID.BLOCK_ID_STAIRS_PRISMARINE_BRICK
            or id == BlockID.BLOCK_ID_STAIRS_DARK_PRISMARINE
            or id == BlockID.BLOCK_ID_STAIRS_RED_NETHER_BRICK
            or ConfigurableBlockConfig:isStairs(id)
end

function GameConfig:checkPosHasBlock(id, aPos)
    local nowId = EngineWorld:getBlockId(aPos)
    if nowId == id then
        return true
    end
    return false
end

function GameConfig:isCommonHalfSlab(id)
    return id == BlockID.STONE_SINGLE_SLAB
            or id == BlockID.WOOD_SINGLE_SLAB
end

function GameConfig:isMoreThan1000HalfSlabItem(id)
    return id == BlockID.BLOCK_ID_PRISMARINE_SINGLE_SLAB
            or ConfigurableBlockConfig:isSingleHalfSlab(id)
end

function GameConfig:isMoreThan1000HalfSlabBlock(id)
    return id == BlockID.BLOCK_ID_PRISMARINE_SINGLE_SLAB
            or ConfigurableBlockConfig:isSingleHalfSlab(id)
end

function GameConfig:metaHandleFurnace(yaw, meta)
    local new_meta = meta
    local new_yaw = math.floor(yaw)
    while new_yaw < 0 do
        new_yaw = new_yaw + 360
    end

    while new_yaw > 360 do
        new_yaw = new_yaw - 360
    end

    if new_yaw >= 45 and new_yaw < 135 then
        new_meta = 5
    elseif new_yaw >= 135 and new_yaw < 225 then
        new_meta = 3
    elseif new_yaw >= 225 and new_yaw < 315 then
        new_meta = 4
    else
        new_meta = 2
    end
    return new_meta
end

function GameConfig:metaHandleGate(yaw, meta)
    local new_meta = meta
    local new_yaw = math.floor(yaw)
    while new_yaw < 0 do
        new_yaw = new_yaw + 360
    end

    while new_yaw > 360 do
        new_yaw = new_yaw - 360
    end

    if new_yaw >= 45 and new_yaw < 135 then
        new_meta = 5
    elseif new_yaw >= 135 and new_yaw < 225 then
        new_meta = 0
    elseif new_yaw >= 225 and new_yaw < 315 then
        new_meta = 1
    else
        new_meta = 2
    end
    return new_meta
end

function GameConfig:metaHandleStairs(yaw, meta)
    local new_meta = meta

    local new_yaw = math.floor(yaw)
    while new_yaw < 0 do
        new_yaw = new_yaw + 360
    end

    while new_yaw > 360 do
        new_yaw = new_yaw - 360
    end

    if meta == 4 then
        if new_yaw >= 45 and new_yaw < 135 then
            new_meta = 5
        elseif new_yaw >= 135 and new_yaw < 225 then
            new_meta = 7
        elseif new_yaw >= 225 and new_yaw < 315 then
            new_meta = 4
        else
            new_meta = 6
        end
    else
        if new_yaw >= 45 and new_yaw < 135 then
            new_meta = 1
        elseif new_yaw >= 135 and new_yaw < 225 then
            new_meta = 3
        elseif new_yaw >= 225 and new_yaw < 315 then
            new_meta = 0
        else
            new_meta = 2
        end
    end

    return new_meta
end

function GameConfig:isMoreThan1000Block(blockId)
    return blockId == BlockID.BLOCK_ID_PRISMARINE
            or blockId == BlockID.BLOCK_ID_PRISMARINE_BRICK
            or blockId == BlockID.BLOCK_ID_DARK_PRISMARINE
            or blockId == BlockID.BLOCK_ID_STARRY_SKY
            or blockId == BlockID.BLOCK_ID_STAIRS_PRISMARINE
            or blockId == BlockID.BLOCK_ID_STAIRS_PRISMARINE_BRICK
            or blockId == BlockID.BLOCK_ID_STAIRS_DARK_PRISMARINE
            or blockId == BlockID.BLOCK_ID_STAIRS_RED_NETHER_BRICK
            or blockId == BlockID.BLOCK_ID_PRISMARINE_DOUBLE_SLAB
            or blockId == BlockID.BLOCK_ID_PRISMARINE_SINGLE_SLAB
            or blockId == BlockID.ALLIUM
            or blockId == BlockID.BLUE_ORCHID
            or blockId == BlockID.HOUSTONIA
            or blockId == BlockID.OXEYE_DAISY
            or blockId == BlockID.PAEONIA
            or blockId == BlockID.TULIP_PINK
            or blockId == BlockID.TULIP_RED
            or blockId == BlockID.TULIP_WHITE or ConfigurableBlockConfig:isConfigurableBlock(blockId)
end

function GameConfig:isInSnowTime(time)
    if self.snowTime then
        for _, info in pairs(self.snowTime) do
            local down_time = tonumber(info.time[1])
            local up_time = tonumber(info.time[2])
            if down_time < up_time then
                if time > down_time and time < up_time then
                    return true
                end
            end
        end
    end
    return false
end

return GameConfig