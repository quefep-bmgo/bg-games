DBManager:addMustLoadSubKey("ShareData")

DBManager:setPlayerDBSaveFunction(function()

end)