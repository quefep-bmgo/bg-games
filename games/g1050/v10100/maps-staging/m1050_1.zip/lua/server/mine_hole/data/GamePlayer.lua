---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
---@type SSkyBlockPlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type CommonConfig
local CommonConfig = T(Global, "CommonConfig")
---@type SSkyBlockPlayer
GamePlayer = class("GamePlayer", SSkyBlockPlayer)

function GamePlayer:init()
    SSkyBlockPlayer.init(self)
    self:initStaticAttr(0)
end

function GamePlayer:teleInitPos()
    CommonConfig:teleportInitPos(self)
end

function GamePlayer:removeCurItem(num)
    num = num or 1
    local inv = self:getPlayerInventory()
    if not inv then
        return false
    end
    return inv:removeCurrentItem(num)
end

return GamePlayer

--endregion


