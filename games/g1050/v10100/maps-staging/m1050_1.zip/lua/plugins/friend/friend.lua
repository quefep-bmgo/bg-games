Plugins.Require("friend", "common.define.FriendDefine")
Plugins.Require("friend", "common.define.FriendEvents")

if isClient then
    Plugins.Require("friend", "client.manager.FriendManager")
    Plugins.Require("friend", "client.notification.NotificationCenter")
else
end

local handlers = {}
---@type FriendManager
local FriendManager = T(Global, "FriendManager")

function handlers.tryAddFriend(userId)
    if isClient then
        if FriendManager.IsFriend(userId) then
            return
        end
        local msg = Lang:getString("gui_friend_request_default_msg")
        CustomInputContent:setInputInfo(Lang:getString("gui_add_friend_msg_text"), msg)
        CustomInputContent:setContentChangeListener(function(content)
            msg = content
        end)
        CustomDialog.builder()
                    .setTitleText("gui_add_friend_msg_title")
                    .setContentView(CustomInputContent)
                    .setRightClickListener(function()
            FriendManager.FriendOperation(Define.FriendOperationType.Request, userId, msg)
            UIHelper.showToast(Lang:getString("gui.send.success"))
        end)        .show()
    end
end

function handlers.getFriends()
    return FriendManager.GetFriends()
end

function handlers.loadFriendData()
    FriendManager.LoadFriendData()
end

function handlers.loadMoreFriend()
    FriendManager.LoadMoreFriend()
end

function handlers.isFriend(userId)
    return FriendManager.IsFriend(userId)
end

function handlers.getTotalFriendCount()
    return FriendManager.GetTotalFriendCount() or 0
end

return function(name, ...)
    if type(handlers[name]) ~= "function" then
        return
    end
    return handlers[name](...)
end
