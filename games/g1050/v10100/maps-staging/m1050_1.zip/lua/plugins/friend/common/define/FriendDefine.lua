Define.FriendOperationType = {
    Agree = 1, ---同意好友
    Refuse = 2, ---拒绝好友
    Delete = 3, ---好友删除
    Request = 4, ---好友请求
    Screen = 5, ---好友筛选
}