---@class ExpConfig
local ExpConfig = T(Global, "ExpConfig")
---@type ExpConfigItem[]
local Settings = {}
---@type ExpConfigItem[]
local LvUpRewardSettings = {}
local FundRewardSettings = {}

function ExpConfig:initConfig()
    local config = FileUtil.getGameConfigFromCsv("common/ExpConfig.csv")
    for _, exp in pairs(config or {}) do
        ---@class ExpConfigItem
        local data = {}
        data.level = tonumber(exp.level) or 0
        data.minExp = tonumber(exp.minExp)
        data.maxExp = tonumber(exp.maxExp)
        if exp.rewardIds ~= "#" then
            ---@type ExpConfigRewardItem[]
            local rewards = {}
            local rewardIds = StringUtil.split(exp.rewardIds, "#", nil, true)
            local rewardNum = StringUtil.split(exp.rewardNum, "#", nil, true)
            for i, rewardId in pairs(rewardIds) do
                ---@class ExpConfigRewardItem
                local rewardItem = {
                    rewardId = rewardId,
                    count = rewardNum[i] or 1
                }
                if isClient then
                    rewardItem.lv = data.level
                end
                table.insert(rewards, rewardItem)
            end
            data.rewards = rewards
        end
        if exp.fundRewardIds ~= "#" then
            ---@type ExpConfigRewardItem[]
            local rewards = {}
            local rewardIds = StringUtil.split(exp.fundRewardIds, "#", nil, true)
            local rewardNum = StringUtil.split(exp.fundRewardNum, "#", nil, true)
            for i, rewardId in pairs(rewardIds) do
                ---@type ExpConfigRewardItem
                local rewardItem = {
                    rewardId = rewardId,
                    count = rewardNum[i] or 1
                }
                if isClient then
                    rewardItem.lv = data.level
                    rewardItem.isFund = true
                end
                table.insert(rewards, rewardItem)
            end
            data.fundRewards = rewards
        end
        if data.rewards or data.fundRewards then
            table.insert(LvUpRewardSettings, data)
        end
        table.insert(Settings, data)
    end


    table.sort(Settings, function(a, b)
        return a.level < b.level
    end)
    table.sort(LvUpRewardSettings, function(a, b)
        return a.level < b.level
    end)
end

function ExpConfig:getLvRewardSettings()
    local setting = {}
    for _, exp in pairs(LvUpRewardSettings) do
        if #exp.rewards > 0 then
            table.insert(setting, exp)
        end
    end
    return setting
end

function ExpConfig:getRewardMinLv()
    return LvUpRewardSettings[1].level or 1
end

function ExpConfig:getRewardMaxLv()
    return LvUpRewardSettings[#LvUpRewardSettings].level or 9999
end

function ExpConfig:getIndex(lv)
    local index = 1
    for _, exp in pairs(LvUpRewardSettings) do
        if #exp.rewards > 0 then
            if lv == exp.level or exp.level > lv then
                return index
            else
                index = index + 1
            end
        end
    end
    return 1
end

function ExpConfig:getLevelReward(lv)
    for _, exp in pairs(LvUpRewardSettings) do
        if lv == exp.level then
            return exp.rewards or {}
        end
    end
    return {}
end

function ExpConfig:getFundReward(lv)
    for _, exp in pairs(LvUpRewardSettings) do
        if lv == exp.level then
            return exp.fundRewards or {}
        end
    end
    return {}
end

function ExpConfig:getLevelByExp(exp)
    exp = exp or 0
    for i, k in pairs(Settings) do
        if k.minExp <= exp and k.maxExp >= exp then
            return k.level
        end
    end
    if exp < Settings[1].minExp then
        return Settings[1].level
    end
    return Settings[#Settings].level
end

function ExpConfig:getMaxExp(exp_lv)
    for _, exp in pairs(Settings) do
        if tonumber(exp.level) == tonumber(exp_lv) then
            if tonumber(exp.level) == 9999 then
                return 99999999999, true
            else
                return tonumber(exp.maxExp), false
            end
        end
    end
    return 99999999999, true
end

function ExpConfig:hasLevelReward(lv)
    for _, exp in pairs(LvUpRewardSettings) do
        if lv == exp.level and exp.rewards then
            return true
        end
    end
    return false
end

function ExpConfig:hasFundReward(lv)
    for _, exp in pairs(LvUpRewardSettings) do
        if lv == exp.level and exp.fundRewards then
            return true
        end
    end
    return false
end

ExpConfig:initConfig()

return ExpConfig