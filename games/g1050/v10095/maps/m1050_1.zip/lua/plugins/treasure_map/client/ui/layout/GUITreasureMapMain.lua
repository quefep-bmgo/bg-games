---@class UITreasureMapMainLayout : IGUILayout
local UITreasureMapMainLayout = class("UITreasureMapMainLayout", IGUILayout)
---@type TreasureMapConfig
local TreasureMapConfig = T(Global, "TreasureMapConfig")
---@type TreasurePointConfig
local TreasurePointConfig = T(Global, "TreasurePointConfig")
---@type CTreasureMapPkSender : CPidPacketSender
local CTreasureMapPkSender = T(Global, "PidPacketSender")
local TargetPosEffect = "g1048_treasure_point.effect"

---@private
function UITreasureMapMainLayout:ctor()
    self.super.ctor(self, "TreasureMapMain.json", GUIManager:getMainControl())
end

---@private
function UITreasureMapMainLayout:isDelayLoad()
    return true
end

---@private
function UITreasureMapMainLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UITreasureMapMainLayout:initCreateEvent()
    self:registerEvent(CEvents.PlayerChangeItemInHandEvent, function(userId, itemId, _)
        if userId ~= Game:getPlatformUserId() then
            return
        end
        self:onHandItemChange(itemId)
    end)
end

---@private
function UITreasureMapMainLayout:onLoad()
    self.btnOpen = self:getChildWindow("TreasureMapMain-Open", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UITreasureMapMainLayout:initView()
    self.info = PlayerManager:getClientPlayer().info
    self.btnOpen:SetText(Lang:getString("gui.treasure.map.open"))
end

---@private
function UITreasureMapMainLayout:initEvent()
    self.btnOpen:registerEvent(GUIEvent.ButtonClick, function()
        local pointId = self.info:getValue(Define.PlayerInfoKey.TreasurePointId)
        if pointId == 0 then
            CTreasureMapPkSender:tryOpenTreasureMap()
        else
            self:tryGoToPointMap()
        end
    end)
    self.info:addKeyObserver(Define.PlayerInfoKey.TreasurePointId, function()
        local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
        self:onHandItemChange(inventory:getHandItemId())
        self:tryGoToPointMap()
    end)
end

function UITreasureMapMainLayout:tryGoToPointMap()
    if not self:isShow() then
        return
    end
    local pointId = self.info:getValue(Define.PlayerInfoKey.TreasurePointId)
    local cfg = TreasurePointConfig:getCfgById(pointId)
    if not cfg or cfg.gameType ~= GameType then
        CTreasureMapPkSender:tryOpenTreasureMap()
        return
    end
    local position = PlayerManager:getClientPlayer():getPosition()
    if VectorUtil.distance(position, cfg.position) < 2 then
        CTreasureMapPkSender:tryDigTreasureMap()
    else
        if not self.info:getValue(Define.PlayerInfoKey.InHome) then
            self:addGuideArrow(cfg.position)
        else
            CustomDialog.builder()
                        .setContentText(Lang:getString("gui.treasure.map.guide.tip"))
                        .setRightClickListener(function()
                GamePacketSender:sendGotoHall()
                self:addGuideArrow(cfg.position)
            end)        .show()
        end
    end
end

---@private
function UITreasureMapMainLayout:onTick()
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    if not TreasureMapConfig:isTreasureMap(inventory:getHandItemId()) then
        self:hide()
        return
    end
    local pointId = self.info:getValue(Define.PlayerInfoKey.TreasurePointId)
    local cfg = TreasurePointConfig:getCfgById(pointId)
    if cfg and cfg.gameType == GameType then
        self:tryShowTreasureGuide(cfg)
        local position = PlayerManager:getClientPlayer():getPosition()
        if VectorUtil.distance(position, cfg.position) < 2 then
            self.btnOpen:SetVisible(true)
            self.btnOpen:SetText(Lang:getString("gui.treasure.map.dig"))
        else
            self.btnOpen:SetVisible(self.info:getValue(Define.PlayerInfoKey.InHome))
            self.btnOpen:SetText(Lang:getString("gui.treasure.map.open"))
        end
    else
        self.btnOpen:SetText(Lang:getString("gui.treasure.map.open"))
        self.btnOpen:SetVisible(true)
        self:hideTreasureGuide()
    end
end

---@private
---@param cfg TreasurePointConfigData
function UITreasureMapMainLayout:tryShowTreasureGuide(cfg)
    if self.curPointCfg == cfg then
        return
    end
    self.curPointCfg = cfg
    self:hideTreasureGuide()
    if not self.info:getValue(Define.PlayerInfoKey.InHome) then
        self:addGuideArrow(cfg.position)
    end
end

function UITreasureMapMainLayout:addGuideArrow(position)
    self.arrowPos = position
    PlayerManager:getClientPlayer().Player:addGuideArrow(position)
    if self.targetPosEffect then
        EngineWorld:removeSimpleEffect(self.targetPosEffect.mEffectName)
    end
    self.targetPosEffect = EngineWorld:addSimpleEffect(TargetPosEffect, position, 0, -1)
end

---@private
function UITreasureMapMainLayout:hideTreasureGuide()
    if self.arrowPos then
        if self.targetPosEffect then
            EngineWorld:removeSimpleEffect(self.targetPosEffect.mEffectName)
            self.targetPosEffect = nil
        end
        PlayerManager:getClientPlayer().Player:deleteGuideArrow(self.arrowPos)
        self.arrowPos = nil
    end
end

---@private
function UITreasureMapMainLayout:onHandItemChange(itemId)
    if not TreasureMapConfig:isTreasureMap(itemId) then
        self:hide()
        self:hideTreasureGuide()
        return
    end
    self.curPointCfg = nil
    self:show()
end

return UITreasureMapMainLayout
