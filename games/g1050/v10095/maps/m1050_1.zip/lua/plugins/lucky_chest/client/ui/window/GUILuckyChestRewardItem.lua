---@class GUILuckyChestRewardItemWindow : IGUIWindow
local GUILuckyChestRewardItemWindow = class("GUILuckyChestRewardItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUILuckyChestRewardItemWindow:ctor(...)
	self.super.ctor(self, "LuckyChestRewardItem.json", ...)
end

---@private
function GUILuckyChestRewardItemWindow:onLoad()
	self.siImage = self:getChildWindowByName("LuckyChestRewardItem-Image", GUIType.StaticImage)
	self.stCount = self:getChildWindowByName("LuckyChestRewardItem-Count", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUILuckyChestRewardItemWindow:initView()

end

---@private
function GUILuckyChestRewardItemWindow:initEvent()

end

---@param data LuckyChestRewardConfigData
function GUILuckyChestRewardItemWindow:onDataChanged(data)
	RewardConfig:setRewardImage(self.siImage, data.reward)
	self.stCount:SetText(data.rewardCount)
end

return GUILuckyChestRewardItemWindow
