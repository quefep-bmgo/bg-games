---@class UILuckyChestDetailLayout : IGUILayout
local UILuckyChestDetailLayout = class("UILuckyChestDetailLayout", IGUILayout)
---@type LuckyChestRewardConfig
local LuckyChestRewardConfig = T(Global, "LuckyChestRewardConfig")

---@private
function UILuckyChestDetailLayout:ctor(parent)
    self.super.ctor(self, "LuckyChestDetail.json", parent)
end

---@private
function UILuckyChestDetailLayout:isDelayLoad()
    return true
end

---@private
function UILuckyChestDetailLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UILuckyChestDetailLayout:initCreateEvent()

end

---@private
function UILuckyChestDetailLayout:onLoad()
    self.btnClose = self:getChildWindow("LuckyChestDetail-Close", GUIType.Button)
    self.stTitle = self:getChildWindow("LuckyChestDetail-Title", GUIType.StaticText)
    self.siBg = self:getChildWindow("LuckyChestDetail-Bg", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UILuckyChestDetailLayout:initView()
    self.stTitle:SetText(Lang:getString("gui.lucky.chest.reward"))
end

---@private
function UILuckyChestDetailLayout:initEvent()
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
end

---@private
function UILuckyChestDetailLayout:onShow(chestId)
    self:tryShowRewards(chestId)
end

---@private
function UILuckyChestDetailLayout:tryShowRewards(chestId)
    if not self.rewardAdapter then
        self.lvRewardList = IGUIGridView.new("LuckyChestDetail-RewardListItems", self.siBg)
        self.lvRewardList:setArea({ 0, 13 }, { 0, 13 }, { 1, -26 }, { 1, -26 })
        self.lvRewardList:setConfig(15, 15, 6)
        ---@type LuckyChestRewardAdapter
        self.rewardAdapter = UIHelper.newGameAdapter("LuckyChestRewardAdapter")
		self.lvRewardList:setAdapter(self.rewardAdapter)
    end
	local rewards = LuckyChestRewardConfig:getChestRewardCfg(chestId)
	self.rewardAdapter:setData(rewards)
end

return UILuckyChestDetailLayout
