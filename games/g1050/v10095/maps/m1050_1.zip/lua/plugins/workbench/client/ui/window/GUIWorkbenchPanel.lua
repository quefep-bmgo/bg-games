---@class GUIWorkbenchPanelWindow : IGUIWindow
local GUIWorkbenchPanelWindow = class("GUIWorkbenchPanelWindow", IGUIWindow)
---@type WorkbenchConfig
local WorkbenchConfig = T(Global, "WorkbenchConfig")
---@type ItemInfoConfig
local ItemInfoConfig = T(Global, "ItemInfoConfig")
---@type ItemContainerMgr
local ItemContainerMgr = T(Global, "ItemContainerMgr")
---@type CWorkbenchPkSender
local WorkbenchPkSender = T(Global, "PidPacketSender")
---@type ItemSlot
local ItemSlot = Plugins.Require("item_container", "common.data.ItemSlot")

local ItemType = {
    All = 0, ---全部
    Block = 1, ---方块
    Tool = 2, ---工具
    Props = 3, ---物品
    Colorful = 4, ---染色
}

local ItemTypeLang = {
    [ItemType.All] = "gui_compound1",
    [ItemType.Block] = "gui_compound2",
    [ItemType.Tool] = "gui_compound3",
    [ItemType.Props] = "gui_compound4",
    [ItemType.Colorful] = "gui_compound5",
}

---@private
function GUIWorkbenchPanelWindow:ctor(...)
    self.super.ctor(self, "WorkbenchPanel.json", ...)
end

---@private
function GUIWorkbenchPanelWindow:onLoad()
    self.llSwitchType = self:getChildWindowByName("WorkbenchPanel-SwitchType", GUIType.Layout)
    self.stSwitchTypeText = self:getChildWindowByName("WorkbenchPanel-SwitchTypeText", GUIType.StaticText)
    self.siSwitchTypeArrow = self:getChildWindowByName("WorkbenchPanel-SwitchTypeArrow", GUIType.StaticImage)
    self.llSwitchTypeClose = self:getChildWindowByName("WorkbenchPanel-SwitchTypeClose", GUIType.Layout)
    self.ltSwitchTypeList = self:getChildWindowByName("WorkbenchPanel-SwitchTypeList", GUIType.List)
    self.siSwitchCreatable = self:getChildWindowByName("WorkbenchPanel-SwitchCreatable", GUIType.StaticImage)
    self.stSwitchCreatableText = self:getChildWindowByName("WorkbenchPanel-SwitchCreatableText", GUIType.StaticText)
    self.llItems = self:getChildWindowByName("WorkbenchPanel-Items", GUIType.Layout)
    self.llWorkbenchPanel = self:getChildWindowByName("WorkbenchPanel-WorkbenchPanel", GUIType.Layout)
    self.llRecipe = self:getChildWindowByName("WorkbenchPanel-Recipe", GUIType.Layout)
    self.siArrow = self:getChildWindowByName("WorkbenchPanel-Arrow", GUIType.StaticImage)
    self.stLine = self:getChildWindowByName("WorkbenchPanel-Line", GUIType.StaticText)
    self.llDesc = self:getChildWindowByName("WorkbenchPanel-Desc", GUIType.Layout)
    self.stItemName = self:getChildWindowByName("WorkbenchPanel-ItemName", GUIType.StaticText)
    self.stItemCount = self:getChildWindowByName("WorkbenchPanel-ItemCount", GUIType.StaticText)
    self.stItemDesc = self:getChildWindowByName("WorkbenchPanel-ItemDesc", GUIType.StaticText)
    self.llItemBG = self:getChildWindowByName("WorkbenchPanel-ItemBG", GUIType.Layout)
    self.siItemImage = self:getChildWindowByName("WorkbenchPanel-ItemImage", GUIType.StaticImage)
    self.llCountBG = self:getChildWindowByName("WorkbenchPanel-CountBG", GUIType.Layout)
    self.stCount = self:getChildWindowByName("WorkbenchPanel-Count", GUIType.StaticText)
    self.siCountSub = self:getChildWindowByName("WorkbenchPanel-CountSub", GUIType.StaticImage)
    self.siCountAdd = self:getChildWindowByName("WorkbenchPanel-CountAdd", GUIType.StaticImage)
    self.btnCreate = self:getChildWindowByName("WorkbenchPanel-Create", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function GUIWorkbenchPanelWindow:initView()
    self.stLine:SetText("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
    self.btnCreate:SetText(Lang:getString("wordart_compound"))
    self.llDesc:SetVisible(false)
    ---@type GUIItemContainerWindow
    self.wItems = UIHelper.newGameGUIWindow("GUIItemContainer", self.llItems)
    self.wItems:initContainer({ 1, 0 }, { 1, 0 }, 62)
    self.showAllRecipe = true
    self:onSwitchCreatable()
    self:initShowItemType()
    self:initRecipeItems()
end

---@private
function GUIWorkbenchPanelWindow:initEvent()
    self.btnCreate:registerEvent(GUIEvent.ButtonClick, function()
        self:tryUseWorkbench()
    end)
    self.llSwitchType:registerEvent(GUIEvent.Click, function()
        self.ltSwitchTypeList:SetVisible(not self.ltSwitchTypeList:IsVisible())
        self.llSwitchTypeClose:SetVisible(self.ltSwitchTypeList:IsVisible())
        if self.ltSwitchTypeList:IsVisible() then
            self.siSwitchTypeArrow:SetImage("set:buttons.json image:img_0_on")
        else
            self.siSwitchTypeArrow:SetImage("set:buttons.json image:img_0_down")
        end
    end)
    self.siSwitchCreatable:registerEvent(GUIEvent.Click, function()
        self.showAllRecipe = not self.showAllRecipe
        self:onSwitchCreatable()
        self:updateItems()
    end)
    self.wItems:setItemClickListener(function(slot, event)
        if event == GUIEvent.Click then
            self:showItemDetail(slot)
        end
    end)
    self.siCountSub:registerEvent(GUIEvent.Click, function()
        self:updateItemCount(-1)
    end)
    self.siCountAdd:registerEvent(GUIEvent.Click, function()
        self:updateItemCount(1)
    end)
end

---@private
function GUIWorkbenchPanelWindow:onSwitchCreatable()
    if self.showAllRecipe then
        self.siSwitchCreatable:SetImage("set:backpack.json image:btn_0_visible01")
        self.stSwitchCreatableText:SetText(Lang:getString("backpack.equipment.on"))
        self.stSwitchCreatableText:SetHorizontalAlignment(HorizontalAlignment.Right)
        self.stSwitchCreatableText:SetXPosition({ 0, -3 })
    else
        self.siSwitchCreatable:SetImage("set:backpack.json image:btn_0_visible02")
        self.stSwitchCreatableText:SetText(Lang:getString("backpack.equipment.off"))
        self.stSwitchCreatableText:SetHorizontalAlignment(HorizontalAlignment.Left)
        self.stSwitchCreatableText:SetXPosition({ 0, 3 })
    end
end

---@private
function GUIWorkbenchPanelWindow:initShowItemType()
    self.showItemType = ItemType.All
    self.stSwitchTypeText:SetText(Lang:getString(ItemTypeLang[ItemType.All]))
    local lvSwitchTypeList = IGUIListView.new(nil, self.llSwitchType, self.ltSwitchTypeList, Orientation.Vertical)
    lvSwitchTypeList:setItemSpace(4)
    for type, lang in pairs(ItemTypeLang) do
        ---@type GUISwitchItemTypeItemWindow
        local item = UIHelper.newGameGUIWindow("GUISwitchItemTypeItem")
        item:setOnClickListener(function()
            self.showItemType = type
            self.stSwitchTypeText:SetText(Lang:getString(lang))
            self:updateItems()
            self.ltSwitchTypeList:SetVisible(false)
            self.llSwitchTypeClose:SetVisible(false)
            self.siSwitchTypeArrow:SetImage("set:buttons.json image:img_0_down")
        end)
        item:onDataChanged(lang)
        lvSwitchTypeList:addItem(item)
    end
end

---@private
function GUIWorkbenchPanelWindow:initRecipeItems()
    self.gvRecipe = IGUIGridView.new("WorkbenchPanel-Recipe-List", self.llRecipe)
    self.gvRecipe:setConfig(48, 30, 3)
    local container = ItemContainerMgr:createContainer("recipe", 9)
    for _, slot in pairs(container.slots) do
        slot.itemId = -1
        ---@type GUIItemSlotRecipeWindow
        local item = UIHelper.newGameGUIWindow("GUIItemSlotRecipe")
        item:onDataChanged(slot)
        self.gvRecipe:addItem(item)
    end
    self.gvRecipe.root:SetClipChild(false)
end

---@private
function GUIWorkbenchPanelWindow:updateRecipeItems()
    if not self.gvRecipe or not self.curSelectItem then
        return
    end
    local slot = self.curSelectItem.slot
    local multiple = tonumber(self.stCount:GetText())
    local cfg = WorkbenchConfig:getRecipeById(slot.recipeId)
    if not cfg then
        ---@param window GUIItemSlotRecipeWindow
        for _, window in pairs(self.gvRecipe.items) do
            window.slot.itemId = -1
            window:onDataChanged(window.slot)
        end
    else
        for index, item in pairs(cfg.items) do
            ---@type GUIItemSlotRecipeWindow
            local window = self.gvRecipe.items[index]
            if item[1] > 0 then
                window.slot.itemId = item[1]
                window.slot.meta = item[2]
                window.slot.count = multiple
            else
                window.slot.itemId = -1
            end
            window:onDataChanged(window.slot)
        end
    end

end

function GUIWorkbenchPanelWindow:tryUseWorkbench()
    if self.curSelectItem == nil then
        return
    end
    local slot = self.curSelectItem.slot
    local multiple = tonumber(self.stCount:GetText())
    local cfg = WorkbenchConfig:getRecipeById(slot.recipeId)
    if not cfg then
        return
    end
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    if inventory:isCanAddItem(cfg.result[1], cfg.result[2], cfg.result[3] * multiple) then
        WorkbenchPkSender:tryUseWorkbench(slot.recipeId, multiple)
    else
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui_str_app_shop_inventory_is_full"))
                    .show()
    end
end

---@private
function GUIWorkbenchPanelWindow:updateItemCount(change)
    if self.curSelectItem == nil then
        return
    end
    local slot = self.curSelectItem.slot
    local cfg = WorkbenchConfig:getRecipeById(slot.recipeId)
    if not cfg then
        return
    end
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    local multiple = tonumber(self.stCount:GetText())
    multiple = math.max(1, multiple + change)
    if WorkbenchConfig:isInventoryCanCreate(inventory, cfg, multiple) then
        self.stCount:SetText(multiple)
        self.stItemCount:SetVisible(slot.count * multiple > 1)
        self.stItemCount:SetText(slot.count * multiple)
        self:updateRecipeItems()
    end
end

function GUIWorkbenchPanelWindow:onShow(level)
    if level then
        self.level = level
    end
    self:updateItems()
    self:showItemDetail(self.curSelectItem)
    self.observer = function()
        self.updateWorkbench = true
    end
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    inv.hotbar:addObserver(self.observer)
    inv.backpack:addObserver(self.observer)
end

function GUIWorkbenchPanelWindow:onHide(clear)
    if clear then
        self.level = 0
        self.showItemType = ItemType.All
        self.showAllRecipe = true
        self.stSwitchTypeText:SetText(Lang:getString(ItemTypeLang[ItemType.All]))
        self.ltSwitchTypeList:SetVisible(false)
        self:onSwitchCreatable()
    end
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    inv.hotbar:clearObserver(self.observer)
    inv.backpack:clearObserver(self.observer)
end

function GUIWorkbenchPanelWindow:updateItems()
    local cfgs1, cfgs2 = WorkbenchConfig:getRecipeByTab(self.showItemType, self.level)
    local size = #cfgs1
    if self.showAllRecipe then
        size = size + #cfgs2
    end
    local container = ItemContainerMgr:createContainer("workbench", size)
    for i, cfg in pairs(cfgs1) do
        local slot = container.slots[i]
        slot.recipeId = cfg.id
        slot.itemId = cfg.result[1]
        slot.meta = cfg.result[2]
        slot.count = cfg.result[3]
        slot.creatable = cfg.creatable
    end
    if self.showAllRecipe then
        for i, cfg in pairs(cfgs2) do
            local slot = container.slots[i + #cfgs1]
            slot.recipeId = cfg.id
            slot.itemId = cfg.result[1]
            slot.meta = cfg.result[2]
            slot.count = 0
            slot.creatable = cfg.creatable
        end
    end
    if size < 54 then
        for i = size + 1, 54 do
            local slot = ItemSlot.new(container, i)
            slot.itemId = -1
            container.slots[i] = slot
        end
    end
    self.wItems:setItemContainer(container)
end

---@private
function GUIWorkbenchPanelWindow:hideItemDetail()
    self.siItemImage:SetImage("")
    self.stItemCount:SetVisible(false)
    self.stItemName:SetText("")
    self.llDesc:SetVisible(false)
    self:updateRecipeItems()
end

---@private
---@param item GUIItemSlotLuaWindow
function GUIWorkbenchPanelWindow:showItemDetail(item)
    if not item then
        return
    end
    self.curSelectItem = item
    self.siItemImage:SetHexagonImage("", "")
    self.siItemImage:SetRenderAsBlock(false)
    local slot = item.slot
    if slot.itemId <= 0 then
        self:hideItemDetail()
        return
    end
    self.llDesc:SetVisible(true)
    self.stItemName:SetText(Lang:getItemName(slot.itemId, slot.meta))
    self.stItemDesc:SetText(ItemInfoConfig:getItemDesc(slot.itemId, slot.meta))
    self.stCount:SetText("1")
    self.siItemImage:SetHexagonImage("", "")
    self.siItemImage:SetRenderAsBlock(false)
    self.stItemCount:SetVisible(slot.count > 1)
    self.stItemCount:SetText(slot.count)
    GuiItemStack.showItemIcon(self.siItemImage, slot.itemId, slot.meta, "")
    self.btnCreate:SetEnabled(slot.creatable)
    self:updateRecipeItems()
end

---@param data table
function GUIWorkbenchPanelWindow:onDataChanged(data)
    if not self.updateWorkbench then
        return
    end
    self:updateItems()
    self:showItemDetail(self.curSelectItem)
    self.updateWorkbench = false
end

return GUIWorkbenchPanelWindow
