---@class GUIItemSlotRecipeWindow : IGUIWindow
local GUIItemSlotRecipeWindow = class("GUIItemSlotRecipeWindow", IGUIWindow)

---@private
function GUIItemSlotRecipeWindow:ctor(...)
	self.super.ctor(self, "ItemSlotRecipe.json", ...)
end

---@private
function GUIItemSlotRecipeWindow:onLoad()
	self.llSelect = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
	self.siIcon = self:getChildWindowByName("ItemSlotRecipe-Icon", GUIType.StaticImage)
	self.stCount = self:getChildWindowByName("ItemSlotRecipe-Count", GUIType.StaticText)
	self.stName = self:getChildWindowByName("ItemSlotRecipe-Name", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIItemSlotRecipeWindow:initView()

end

---@private
function GUIItemSlotRecipeWindow:initEvent()

end

function GUIItemSlotRecipeWindow:hideOldItemUI()
	self.siIcon:SetImage("")
	self.stCount:SetVisible(false)
	self.stName:SetVisible(false)
end

---@param slot ItemSlot
function GUIItemSlotRecipeWindow:onDataChanged(slot)
	self.slot = slot
	self.siIcon:SetHexagonImage("", "")
	self.siIcon:SetRenderAsBlock(false)
	if slot.itemId < 0 then
		self:hideOldItemUI()
		return
	end
	local item = Item.getItemById(slot.itemId)
	if not item then
		self:hideOldItemUI()
		return
	end
	GuiItemStack.showItemIcon(self.siIcon, slot.itemId, slot.meta, "")
	self.stCount:SetVisible(slot.count > 1)
	self.stCount:SetText(slot.count)
	self.stName:SetVisible(true)
	self.stName:SetText(Lang:getItemName(slot.itemId, slot.meta))
end

return GUIItemSlotRecipeWindow
