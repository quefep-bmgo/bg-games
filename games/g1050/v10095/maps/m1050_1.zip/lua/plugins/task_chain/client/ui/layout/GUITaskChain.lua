---@class UITaskChainLayout : IGUILayout
local UITaskChainLayout = class("UITaskChainLayout", IGUILayout)
---@type TaskConfig
local TaskConfig = T(Global, "TaskConfig")
---@type TaskChainConfig
local TaskChainConfig = T(Global, "TaskChainConfig")
---@type TaskGroupConfig
local TaskGroupConfig = T(Global, "TaskGroupConfig")
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")
---@type DataInfoMgr
local DataInfoMgr = T(Global, "DataInfoMgr")
---@type TaskChainPkSender
local TaskChainPkSender = T(Global, "PidPacketSender")

---@private
function UITaskChainLayout:ctor(parent)
    self.super.ctor(self, "TaskChain.json", parent)
end

---@private
function UITaskChainLayout:isDelayLoad()
    return true
end

---@private
function UITaskChainLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UITaskChainLayout:initCreateEvent()

end

---@private
function UITaskChainLayout:isShowAnim()
    return false
end

---@private
function UITaskChainLayout:onLoad()
    self.stTitleText = self:getChildWindow("TaskChain-TitleText", GUIType.StaticText)
    self.siClose = self:getChildWindow("TaskChain-Close", GUIType.StaticImage)
    self.stIntroduction1 = self:getChildWindow("TaskChain-Introduction1", GUIType.StaticText)
    self.stIntroduction2 = self:getChildWindow("TaskChain-Introduction2", GUIType.StaticText)
    self.pbGrandPrizeProgress = self:getChildWindow("TaskChain-GrandPrizeProgress", GUIType.ProgressBar)
    self.btnGrandPrizeIcon = self:getChildWindow("TaskChain-GrandPrizeIcon", GUIType.Button)
    self.stGrandPrizeText = self:getChildWindow("TaskChain-GrandPrizeText", GUIType.StaticText)
    self.stGrandPrizeValue = self:getChildWindow("TaskChain-GrandPrizeValue", GUIType.StaticText)
    self.llTask = self:getChildWindow("TaskChain-Task", GUIType.Layout)
    self.stProgress = self:getChildWindow("TaskChain-Progress", GUIType.StaticText)
    self.stDesc = self:getChildWindow("TaskChain-Desc", GUIType.StaticText)
    self.siTaskIcon = self:getChildWindow("TaskChain-TaskIcon", GUIType.StaticImage)
    self.stTaskProgress = self:getChildWindow("TaskChain-TaskProgress", GUIType.StaticText)
    self.siRewardIcon = self:getChildWindow("TaskChain-RewardIcon", GUIType.StaticImage)
    self.stRewardCount = self:getChildWindow("TaskChain-RewardCount", GUIType.StaticText)
    self.llNoTask = self:getChildWindow("TaskChain-NoTask", GUIType.Layout)
    self.stNoTaskTip = self:getChildWindow("TaskChain-NoTaskTip", GUIType.StaticText)
    self.btnGiveUp = self:getChildWindow("TaskChain-GiveUp", GUIType.Button)
    self.btnFinish = self:getChildWindow("TaskChain-Finish", GUIType.Button)
    self.stCountdown = self:getChildWindow("TaskChain-Countdown", GUIType.StaticText)
    self.stGrandPrizeNum = self:getChildWindow("TaskChain-GrandPrizeNum", GUIType.StaticText)
    self.siGrandPrizeEffect = self:getChildWindow("TaskChain-GrandPrizeEffect", GUIType.StaticImage)
    self.btnTaskBg = self:getChildWindow("TaskChain-TaskBG", GUIType.Button)
    self.btnRewardBg = self:getChildWindow("TaskChain-RewardBG", GUIType.Button)

    self:initView()
    self:initEvent()
end

---@private
function UITaskChainLayout:initView()
    self.stTitleText:SetText(Lang:getString("gui.task.chain.title"))
    self.stIntroduction1:SetText(Lang:getString("gui.task.chain.introduction1"))
    self.stIntroduction2:SetText(Lang:getString("gui.task.chain.introduction2"))
    self.stGrandPrizeText:SetText(Lang:getString("gui.task.chain.grand.prize"))
    self.stGrandPrizeValue:SetText("")
    self.stTaskProgress:SetText("-/-")
    self.stRewardCount:SetText("-")
    self.btnGiveUp:SetText(Lang:getString("gui.task.chain.give.up"))
    self.btnFinish:SetText(Lang:getString("gui.task.chain.finish"))
    ---@type GUICurrencyGroupWindow
    self.wCurrencyGroup = UIHelper.newGameGUIWindow("GUICurrencyGroup")
    self.wCurrencyGroup:onDataChanged({ CurrencyId.TaskChainScore, CurrencyId.Diamonds }, nil, 15)
    self.root:AddChildWindow(self.wCurrencyGroup.root)
    self.taskSize = #TaskGroupConfig:getCfgsByKey(Define.TaskGroup.TaskChain)
    self.siGrandPrizeEffect:SetVisible(false)
end

---@private
function UITaskChainLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        self:hide()
        SoundUtil.clickUI()
    end)
    self.btnGiveUp:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.task.chain.give.up.tip"))
                    .setRightClickListener(function()
            PlayerManager:getClientPlayer().taskChain:tryGiveUp()
        end)        .show()
    end)
    self.btnFinish:registerEvent(GUIEvent.ButtonClick, function()
        self:tryToFinish()
    end)
    self.btnGrandPrizeIcon:registerEvent(GUIEvent.ButtonClick, function()
        if not PlayerManager:getClientPlayer().taskChain:tryGetGrandPrice() then
            local record = self.info:getValue(Define.TaskChainInfoKey.GrandPriceRecord)
            local cfg = TaskChainConfig:getNextGrandPrice(record)
            if not cfg then
                return
            end
            UIHelper.showGameGUILayout("GUIRewardDetail", cfg.rewardId)
        end
    end)
    self.info = DataInfoMgr:getTaskChainInfo(Game:getPlatformUserId())
    self.info:addKeyObserver(Define.TaskChainInfoKey.GrandPriceRecord, function(_, _, value)
        self:onGrandPriceRecordChange()
    end)
    ---@param task TaskLink
    self.observer = function(_, task)
        self:onTaskChange(task)
    end

    self.btnTaskBg:registerEvent(GUIEvent.ButtonClick, function()
        if not self.task then
            return
        end
        local cfg = self.task:cfg()
        if not cfg or not cfg.condition or cfg.type ~= Define.TaskType.SubmitItem then
            return
        end
        UIHelper.showGameGUILayout("GUIRewardDetail", {cfg.condition[1], cfg.condition[2]})
    end)

    self.btnRewardBg:registerEvent(GUIEvent.ButtonClick, function()
        if not self.task then
            return
        end
        local cfg = self.task:cfg()
        if not cfg or not cfg.rewardId then
            return
        end
        UIHelper.showGameGUILayout("GUIRewardDetail", cfg.rewardId)
    end)
end

---@private
function UITaskChainLayout:onTick()
    self.wCurrencyGroup:onTick()
    local controller = PlayerManager:getClientPlayer().taskController
    local group = controller:getTaskGroup(Define.TaskGroup.TaskChain)
    if group ~= self.group then
        if group then
            group:clearObserver(self.observer)
        end
        self.group = group
        if self.group then
            self.group:addObserver(self.observer)
            self:onTaskChange(self.group.tasks[1])
            self:showTaskUI()
        else
            self:hideTaskUI()
        end
    end
    if not self.task or self.task.status == Define.TaskStatus.Received then
        self:hideTaskUI()
    else
        self:showTaskUI()
    end
    local refreshTime = self.info:getValue(Define.TaskChainInfoKey.NextRefreshTime)
    local time = math.max(0, refreshTime - os.time())
    if self.llNoTask:IsVisible() then
        local text = string.format("%s\n%s", Lang:getString("gui.task.chain.not.task.tip"), DateUtil.getFormatTime(time))
        self.stNoTaskTip:SetText(text)
    end
    self.stCountdown:SetText(Lang:getString("gui.task.chain.refresh.tip") .. DateUtil.getFormatTime(time))
end

---@private
function UITaskChainLayout:showTaskUI()
    self.llTask:SetVisible(true)
    self.btnFinish:SetVisible(true)
    self.btnGiveUp:SetVisible(false)
    self.llNoTask:SetVisible(false)
end

---@private
function UITaskChainLayout:hideTaskUI()
    self.llTask:SetVisible(false)
    self.btnFinish:SetVisible(false)
    self.btnGiveUp:SetVisible(false)
    self.llNoTask:SetVisible(true)
    self:onGrandPriceRecordChange()
end

function UITaskChainLayout:show(...)
    RootGuiLayout.Instance():hideAllChildren()
    self.super.show(self, ...)
    local controller = PlayerManager:getClientPlayer().taskController
    local group = controller:getTaskGroup(Define.TaskGroup.TaskChain)
    if group == nil then
        self:hideTaskUI()
    else
        self:onTaskChange(group.tasks[1])
    end
end

---@private
function UITaskChainLayout:onShow()
    self.invObserver = function()
        self:onTaskChange(self.task)
    end
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    inventory.hotbar:addObserver(self.invObserver)
    inventory.backpack:addObserver(self.invObserver)
    if not self.group then
        return
    end
    self.group:addObserver(self.observer)
end

---@private
function UITaskChainLayout:onHide()
    RootGuiLayout.Instance():showMainControl()
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    inventory.hotbar:clearObserver(self.invObserver)
    inventory.backpack:clearObserver(self.invObserver)
    if not self.group then
        return
    end
    self.group:clearObserver(self.observer)
    self.task = nil
end

---@private
---@param task TaskLink
function UITaskChainLayout:onTaskChange(task)
    if not task then
        self:onGrandPriceRecordChange()
        return
    end
    local cfg = task:cfg()
    if not cfg then
        return
    end
    TaskConfig:setTaskIcon(self.siTaskIcon, cfg)
    TaskConfig:setTaskDesc(self.stDesc, cfg)
    self.task = task
    self.stProgress:SetText(Lang:getString("gui.task.chain.task.pro") .. task.times .. "/" .. self.taskSize)
    self.stRewardCount:SetText(cfg.rewardCount)
    RewardConfig:setRewardImage(self.siRewardIcon, RewardConfig:getCfgById(cfg.rewardId))
    self.stRewardCount:SetText(cfg.rewardCount)
    if cfg.type == Define.TaskType.SubmitItem then
        local itemId, meta = tonumber(cfg.condition[1]) or 0, tonumber(cfg.condition[2]) or -1
        local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
        local count = inventory:getItemCount(itemId, meta)
        self.stTaskProgress:SetText(count .. "/" .. cfg.value)
        if count >= cfg.value then
            self.stTaskProgress:SetTextColor({ 1, 162 / 255, 0, 1 })
            self.btnFinish:SetText(Lang:getString("gui.task.chain.pay.props"))
            self.btnFinish:SetNormalImage("set:buttons.json image:btn_0_general04")
            self.btnFinish:SetPushedImage("set:buttons.json image:btn_0_general04")
        else
            self.stTaskProgress:SetTextColor({ 219 / 255, 232 / 255, 239 / 255, 1 })
            self.btnFinish:SetText(Lang:getString("gui.task.chain.finish"))
            self.btnFinish:SetNormalImage("set:buttons.json image:btn_0_general03")
            self.btnFinish:SetPushedImage("set:buttons.json image:btn_0_general03")
        end
    else
        self.stTaskProgress:SetText(task.value .. "/" .. cfg.value)
        if self.task.status == Define.TaskStatus.Finished then
            self.stTaskProgress:SetTextColor({ 1, 162 / 255, 0, 1 })
            self.btnFinish:SetText(Lang:getString("gui.task.chain.receive"))
            self.btnFinish:SetNormalImage("set:buttons.json image:btn_0_general04")
            self.btnFinish:SetPushedImage("set:buttons.json image:btn_0_general04")
        else
            self.stTaskProgress:SetTextColor({ 219 / 255, 232 / 255, 239 / 255, 1 })
            self.btnFinish:SetText(Lang:getString("gui.task.chain.finish"))
            self.btnFinish:SetNormalImage("set:buttons.json image:btn_0_general03")
            self.btnFinish:SetPushedImage("set:buttons.json image:btn_0_general03")
        end
    end
    self:onGrandPriceRecordChange()
end

---@private
function UITaskChainLayout:onGrandPriceRecordChange()
    if not self.task then
        self.pbGrandPrizeProgress:SetProgress(0)
        self.stGrandPrizeValue:SetText("-/-")
        return
    end
    local info = DataInfoMgr:getTaskChainInfo(Game:getPlatformUserId())
    local record = info:getValue(Define.TaskChainInfoKey.GrandPriceRecord)
    local cfg = TaskChainConfig:getNextGrandPrice(record)
    if not cfg then
        return
    end
    self.stGrandPrizeNum:SetText(cfg.rewardCount)
    local times = 0
    if self.task.status >= Define.TaskStatus.Finished then
        times = self.task.times
    else
        times = self.task.times - 1
    end
    local progress = times / cfg.times
    self.pbGrandPrizeProgress:SetProgressImage(progress >= 1 and "set:common.json image:img_0_progress_bar02" or "set:common.json image:img_0_progress_bar03")
    self.pbGrandPrizeProgress:SetProgress(progress)
    self.stGrandPrizeValue:SetText(times .. "/" .. cfg.times)
    self.siGrandPrizeEffect:SetVisible(times >= cfg.times)
    if record > cfg.times then
        ---可以领奖
    end
end

---@private
function UITaskChainLayout:tryToFinish()
    if not self.task then
        self:hide()
        return
    end
    local cfg = self.task:cfg()
    if not cfg then
        self:hide()
        return
    end
    if cfg.type == Define.TaskType.SubmitItem then
        local itemId, meta = tonumber(cfg.condition[1]) or 0, tonumber(cfg.condition[2]) or -1
        local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
        local count = inventory:getItemCount(itemId, meta)
        if count >= cfg.value then
            TaskChainPkSender:tryDoSubmitItemTask(self.task)
        else
            self:hide()
        end
    elseif self.task.status == Define.TaskStatus.Finished then
        self.task:tryReceive()
    else
        self:hide()
    end
end

return UITaskChainLayout
