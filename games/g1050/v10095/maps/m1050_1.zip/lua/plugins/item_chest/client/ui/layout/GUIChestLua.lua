---@class UIChestLuaLayout : IGUILayout
local UIChestLuaLayout = class("UIChestLuaLayout", IGUILayout)
---@type ItemContainerMgr
local ItemContainerMgr = T(Global, "ItemContainerMgr")
---@type ItemContainerUtil
local ItemContainerUtil = T(Global, "ItemContainerUtil")
---@type CInventoryPkSender
local InventoryPkSender = T(Global, "PidPacketSender")
---@type ItemSlot
local ItemSlot = Plugins.Require("item_container", "common.data.ItemSlot")
---@type table<string, boolean>
local Locked = {}

---@private
function UIChestLuaLayout:ctor(parent)
    self.super.ctor(self, "ChestLua.json", parent)
end

---@private
function UIChestLuaLayout:isDelayLoad()
    return true
end

---@private
function UIChestLuaLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIChestLuaLayout:initCreateEvent()

end

---@private
function UIChestLuaLayout:isShowAnim()
    return false
end

---@private
function UIChestLuaLayout:onLoad()
    self.stPlayerInvTitleText = self:getChildWindow("ChestLua-PlayerInvTitleText", GUIType.StaticText)
    self.llBackpack = self:getChildWindow("ChestLua-Backpack", GUIType.Layout)
    self.llHotbar = self:getChildWindow("ChestLua-Hotbar", GUIType.Layout)
    self.btnSort = self:getChildWindow("ChestLua-Sort", GUIType.Button)
    self.llChestInvTitle = self:getChildWindow("ChestLua-ChestInvTitle", GUIType.Layout)
    self.stChestInvTitleText = self:getChildWindow("ChestLua-ChestInvTitleText", GUIType.StaticText)
    self.llChest = self:getChildWindow("ChestLua-Chest", GUIType.Layout)
    self.siClose = self:getChildWindow("ChestLua-Close", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIChestLuaLayout:initView()
    self.btnSort:SetText(Lang:getString("backpack.sort.btn"))
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    ---@type GUIItemContainerWindow
    self.wBackpack = UIHelper.newGameGUIWindow("GUIItemContainer", self.llBackpack)
    self.wBackpack:initContainer({ 1, 0 }, { 1, 0 }, 62)
    ---@type GUIItemContainerWindow
    self.wHotbar = UIHelper.newGameGUIWindow("GUIItemContainer", self.llHotbar)
    self.wHotbar:initContainer({ 1, -8 }, { 1, -8 }, 62)
    self.wHotbar:setPosition({ 0, 4 }, { 0, 4 })
    self.wHotbar:setItemContainer(inv.hotbar)
    ---@type GUIItemContainerWindow
    self.wChest = UIHelper.newGameGUIWindow("GUIItemContainer", self.llChest)
    self.wChest:initContainer({ 1, 0 }, { 1, 0 }, 62)
    ---@param slot ItemSlot
    self.invObserver = function(_, slot)
        if slot.container == inv.backpack then
            self.backpack:onItemChange(slot)
        end
        self:updateTitleText(1)
    end
    self.chestObserver = function(_, _)
        self:updateTitleText(2)
    end
end

---@private
function UIChestLuaLayout:setBackpackContainer()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    local maxSize = 45
    self.backpack = ItemContainerMgr:createContainer("backpack:chest", 0)
    for i = 1, maxSize do
        local slot = inv.backpack.slots[i]
        if not slot then
            slot = ItemSlot.new(inv.backpack, i)
            slot.itemId = -1
            table.insert(self.backpack.slots, slot)
        else
            table.insert(self.backpack.slots, slot)
        end
    end
    self.wBackpack:setItemContainer(self.backpack)
    inv.hotbar:addObserver(self.invObserver)
    inv.backpack:addObserver(self.invObserver)
    self:updateTitleText(1)
    self:updateTitleText(2)
end

---@private
function UIChestLuaLayout:updateTitleText(type)
    if type == 1 then
        local inv = PlayerManager:getClientPlayer():getPlayerInventory()
        local inventorySize = inv.hotbar:getContainerSize() + inv.backpack:getContainerSize()
        local inventoryCount = inventorySize - (inv.hotbar:getEmptySlotCount() + inv.backpack:getEmptySlotCount())
        self.stPlayerInvTitleText:SetText(Lang:getString("wordart_bag") .. "(" .. inventoryCount .. "/" .. inventorySize .. ")")
    else
        local chestSize = self.wChest.container:getContainerSize()
        local chestCount = chestSize - self.wChest.container:getEmptySlotCount()
        self.stChestInvTitleText:SetText(Lang:getString("wordart_chest") .. "(" .. chestCount .. "/" .. chestSize .. ")")
    end
end

---@private
function UIChestLuaLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self:hide()
    end)
    self.btnSort:registerEvent(GUIEvent.ButtonClick, function()
        local inv = PlayerManager:getClientPlayer():getPlayerInventory()
        InventoryPkSender:trySortInventoryItem(inv.backpack.key)
        InventoryPkSender:trySortInventoryItem(self.wChest.container.key)
    end)
    self.wBackpack:setItemClickListener(function(slot, event)
        if event ~= GUIEvent.Click and event ~= GUIEvent.TouchDown then
            return
        end
        self:onClickSlot(slot)
    end)
    self.wHotbar:setItemClickListener(function(slot, event)
        if event ~= GUIEvent.Click and event ~= GUIEvent.TouchDown then
            return
        end
        self:onClickSlot(slot)
    end)
    self.wChest:setItemClickListener(function(slot, event)
        if event ~= GUIEvent.Click and event ~= GUIEvent.TouchDown then
            return
        end
        self:onClickSlot(slot)
    end)
end

function UIChestLuaLayout:show(key)
    local container = ItemContainerMgr:getItemContainer(key)
    if not container then
        return
    end
    self.super.show(self)
    self.wChest:setItemContainer(container)
    self.wChest.container:addObserver(self.chestObserver)
    self:setBackpackContainer()
end

function UIChestLuaLayout:onShow()
    self.wBackpack:show()
    self.wHotbar:show()
    self.wChest:show()
end

function UIChestLuaLayout:onHide()
    self.wBackpack:hide()
    self.wHotbar:hide()
    self.wChest:hide()
    self.wChest.container:clearObserver(self.chestObserver)
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    inv.hotbar:clearObserver(self.invObserver)
    inv.backpack:clearObserver(self.invObserver)
end

---@param item GUIItemSlotLuaWindow
function UIChestLuaLayout:onClickSlot(item)
    if item.slot.itemId <= 0 then
        return
    end
    local slot = item.slot
    local key1 = slot.container.key
    ---@type GUIItemSlotLuaWindow
    local findWin
    if slot.container == self.wChest.container then
        ---箱子往背包移动物品
        local inv = PlayerManager:getClientPlayer():getPlayerInventory()
        local slots = inv:findCanAddItemSlot(slot.itemId, slot.meta)
        local find = slots[1]
        if find then
            if find.container == inv.hotbar then
                findWin = self.wHotbar.gvSlots:getItemByIndex(find.index)
            else
                findWin = self.wBackpack.gvSlots:getItemByIndex(find.index)
            end
        else
            find = ItemContainerUtil:findContainerFirstCanAddSlot(inv.hotbar, slot.itemId, slot.meta, slot.count)
            if find then
                findWin = self.wHotbar.gvSlots:getItemByIndex(find.index)
            else
                find = ItemContainerUtil:findContainerFirstCanAddSlot(inv.backpack, slot.itemId, slot.meta, slot.count)
                if find then
                    findWin = self.wBackpack.gvSlots:getItemByIndex(find.index)
                    if not findWin then
                        findWin = self.wBackpack.gvSlots.items[#self.wBackpack.gvSlots.items]
                    end
                end
            end
        end
    else
        local find = ItemContainerUtil:findContainerFirstCanAddSlot(self.wChest.container, slot.itemId, slot.meta, slot.count)
        if find then
            findWin = self.wChest.gvSlots:getItemByIndex(find.index)
        end
    end
    if not findWin then
        UIHelper.showToast(Lang:getString("gui_str_app_shop_inventory_is_full"))
        return
    end
    local lock = slot.container.key .. ":" .. slot.index
    if Locked[lock] then
        return
    end
    Locked[lock] = true
    local key2 = findWin.slot.container.key
    local name = "fly_image:" .. GUIManager:applyWindowId()
    local siImage = GUIManager:createGUIWindow(GUIType.StaticImage, name)
    local fromArea = item.root:GetRenderArea()
    siImage:SetArea({ 0, fromArea[1] }, { 0, fromArea[2] }, { 0, 50 }, { 0, 50 })
    self.root:AddChildWindow(siImage)
    GuiItemStack.showItemIcon(siImage, slot.itemId, slot.meta, "")
    local toArea = findWin.root:GetRenderArea()
    UIAnimation:translateXY(siImage, { fromArea[1], fromArea[2] }, { toArea[1], toArea[2] }, 10, function(destroy)
        Locked[lock] = nil
        if destroy then
            return
        end
        GUIManager:destroyGUIWindow(siImage)
        ItemContainerUtil:tryTransferContainerSlot(key1, key2, slot.index)
    end)
end

return UIChestLuaLayout
