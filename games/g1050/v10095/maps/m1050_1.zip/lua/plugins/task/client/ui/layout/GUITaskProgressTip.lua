---@class UITaskProgressTipLayout : IGUILayout
local UITaskProgressTipLayout = class("UITaskProgressTipLayout", IGUILayout)
---@type TaskConfig
local TaskConfig = T(Global, "TaskConfig")

---@private
function UITaskProgressTipLayout:ctor(parent)
    self.super.ctor(self, "TaskProgressTip.json", parent)
end

---@private
function UITaskProgressTipLayout:isDelayLoad()
    return true
end

---@private
function UITaskProgressTipLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UITaskProgressTipLayout:initCreateEvent()

end

---@private
function UITaskProgressTipLayout:onLoad()
    self.llBorder = self:getChildWindow("TaskProgressTip-Border", GUIType.Layout)
    self.siTaskIcon = self:getChildWindow("TaskProgressTip-TaskIcon", GUIType.StaticImage)
    self.siFinished = self:getChildWindow("TaskProgressTip-Finished", GUIType.StaticImage)
    self.stTaskDesc = self:getChildWindow("TaskProgressTip-TaskDesc", GUIType.StaticText)
    self.pbTaskProgress = self:getChildWindow("TaskProgressTip-TaskProgress", GUIType.ProgressBar)
    self.stProgressText = self:getChildWindow("TaskProgressTip-ProgressText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UITaskProgressTipLayout:initView()

end

---@private
function UITaskProgressTipLayout:initEvent()

end

---@private
function UITaskProgressTipLayout:show(task)
    if not task then
        return
    end
    if task.status == Define.TaskStatus.Received then
        return
    end
    if not task:cfg() then
        return
    end
    self.super.show(self, task)
end

---@private
---@param task TaskLink
function UITaskProgressTipLayout:onShow(task)
    self.root:SetAlpha(1)
    local cfg = task:cfg()
    TaskConfig:setTaskIcon(self.siTaskIcon, cfg)
    TaskConfig:setTaskDesc(self.stTaskDesc, cfg)
    self.pbTaskProgress:SetProgress(task.value / cfg.value)
    self.stProgressText:SetText(task.value .. "/" .. cfg.value)
    if task.status == Define.TaskStatus.Finished then
        self.siFinished:SetVisible(true)
        self.siTaskIcon:SetAlpha(0.4)
        self.pbTaskProgress:SetProgressImage("set:common.json image:img_0_progress_bar02")
    else
        self.siFinished:SetVisible(false)
        self.siTaskIcon:SetAlpha(1)
        self.pbTaskProgress:SetProgressImage("set:common.json image:img_0_progress_bar03")
    end
    UITimerMgr:cancelUITimerKey(self)
    self:addTimer(LuaTimer:schedule(function()
        UIAnimation:alpha(self.root, 1, 0, 30, function(destroy)
            if destroy then
                return
            end
            self:hide()
        end)
    end, 2000))
end

return UITaskProgressTipLayout
