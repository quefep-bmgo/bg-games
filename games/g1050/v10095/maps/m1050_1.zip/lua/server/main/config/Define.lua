Define.Money = {
    GOLD_DIAMOND = 0,
    DIAMOND = 1,
    MONEY = 3,
}

Define.manorRelese = {
    Not = 1,
    Start = 2,
    End = 3,
}

Define.buyGood = "buyGood"
Define.reciveNewPri = "receiveNewPri"

Define.ReplaceType = {
    expand_islands = 106,
    have_products = 109,
    products_level = 111,
}

Define.Npc_Func = {
    ["g1048"] = "enterSkyBlock",
    ["g1049"] = "enterSkyBlockMiningArea",
    ["g1050"] = "enterSkyBlockProduct"
}

Define.PartyLoveNumType = {
    mySelf = 1,
    otherPlayer = 2,
}

Define.visitMasterTips = {
    onShow = "onShow",
    notShow = "notShow",
}

Define.startReleaseTime = 120

Define.SchematicCreateOrDestroyNum = 2

Define.PriItemId = {
    THREE_NPC = 3103,
    ALL_PRI = 3050,
    NEW_ALL_PRI = 3150,
}

Define.CreatePartyType = {
    FREE = 1,
    NOT_FREE = 2,
}

Define.freeCreateTimes = 5

Define.ClickType = {
    TYPE1 = 1,
    TYPE2 = 2,
    TYPE3 = 3,
    TYPE4 = 4,
    TYPE5 = 5,
    TYPE6 = 6,
    TYPE7 = 7,
    TYPE8 = 8,
    TYPE9 = 9,
    TYPE10 = 10,
    TYPE11 = 11,
    TYPE12 = 12,
}

return Define