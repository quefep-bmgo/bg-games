---@type GameUtil
local GameUtil = T(Global, "GameUtil")
---@type TaskUtil
local TaskUtil = T(Global, "TaskUtil")

require "mine_hole.messages.Messages"
require "mine_hole.data.GamePlayer"
require "mine_hole.Match"

PlayerListener = {}

function PlayerListener:init()

    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerRespawnEvent, self.onPlayerRespawn)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerBackHallEvent:registerCallBack(self.onPlayerBackHall)
    CEvents.PlayerCurrencyChangeEvent:registerCallBack(self.onPlayerCurrencyChange)
    CEvents.PlayerChangeItemInHandEvent:registerCallBack(self.onChangeItemInHandEvent)

    PlayerSkyBlocShopOperateEvent:registerCallBack(self.onPlayerSkyBlocBuyGoods)
    PlayerCancelGuideArrowEvent:registerCallBack(self.onPlayerCancelGuideArrow)
    Events.ReceiveSumRechargeEvent:registerCallBack(self.onReceiveSumRecharge)
    Events.ReceiveSumRechargeEndEvent:registerCallBack(self.onReceiveSumRechargeEnd)
end

function PlayerListener.onPlayerLogin(clientPeer)
    local player = GamePlayer.new(clientPeer)
    player:init()
    return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerLogout(player)
    GameMatch:onPlayerQuit(player)
end

function PlayerListener.onPlayerReady(player)
    DbUtil:getPlayerData(player.userId)
    HostApi.sendPlaySound(player.rakssid, 10042)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))
    player:initHintText()
    return 4320000
end

function PlayerListener.onPlayerRespawn(player)
    player.isLife = true
    player:teleInitPos()
    PrivilegeConfig:checkSpePri(player)
    player.isNeedGuideArrow = false
    return 4320000
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return false
    end
    local playerPos = VectorUtil.newVector3(x, y, z)
    if player.isNeedGuideArrow then
        if GameConfig:isInArea(playerPos, GameConfig.ArrowArea, false) then
            player:changeGuideArrow(false)
        end
    end
    local canPvp = GameConfig:isInArea(playerPos, GameConfig.pvpArea, true)
    if not canPvp then
        player.isInPvp = true
    else
        player.isInPvp = false
    end
    return true
end

function PlayerListener.onPlayerBackHall(rakssid)
    HostApi.log("onPlayer leave for SkyBlockMain")
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return
    end
    local interval = GameConfig.backHomeCD + player.backHomeTime - os.time()
    if interval > 0 then
        MsgSender.sendBottomTipsToTarget(player.rakssid, 1, Messages:msgUIButtonCountDown(interval))
        return
    else
        player.backHomeTime = os.time()
    end
    local pos = player:getPosition()
    local canPvp = GameConfig:isInArea(pos, GameConfig.pvpArea, true)
    if not canPvp then
        MsgSender.sendCenterTipsToTarget(rakssid, 1, Messages:msgCannotBackHome())
        player:changeGuideArrow(true)
        if player.enableIndie then
            GameAnalytics:design(player.userId, 0, { "g1049pvp_click_home_indie", "g1049pvp_click_home_indie" })
        else
            GameAnalytics:design(player.userId, 0, { "g1049pvp_click_home", "g1049pvp_click_home" })
        end

        return
    end
    GameUtil:resetGame(player.userId, "g1048")
    MsgSender.sendTopTipsToTarget(player.rakssid, 1000, Messages:msgTransmitting())
    if player.enableIndie then
        GameAnalytics:design(player.userId, 0, { "g1049pve_click_home_indie", "g1049pve_click_home_indie" })
    else
        GameAnalytics:design(player.userId, 0, { "g1049pve_click_home", "g1049pve_click_home" })
    end
end

function PlayerListener.onPlayerSkyBlocBuyGoods(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    if player.isLife == false then
        print("onPlayerSkyBlocBuyGoods player is die userid == " .. tostring(userId))
        return
    end

    local builder = DataBuilder.new():fromData(data)
    local num = builder:getNumberParam("num")
    local indexId = builder:getNumberParam("indexId")
    local type = builder:getNumberParam("type")

    if not DbUtil:CanSavePlayerData(player, DbUtil.TAG_SHAREDATA) then
        return
    end

    if type == AppShopConfig.OperateType.BUY_GOOD then
        HostApi.log("SkyBlocBuyGoodsEvent goodId == " .. indexId .. " num == " .. num)
        if num >= 1 and num <= 64 then
            AppShopConfig:BuyGoods(player.rakssid, indexId, num)
        end
    elseif type == AppShopConfig.OperateType.UPDATE_DATA then
        player:sendSkyBlockShopInfo()
    end
end

function PlayerListener.onChangeItemInHandEvent(rakssid, itemId, itemMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        player.inHandItemId = itemId
    end
end

function PlayerListener.onPlayerCurrencyChange(rakssid, currency)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        player:onMoneyChange()
    end
end

function PlayerListener.onPlayerCancelGuideArrow(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    player:changeGuideArrow(false)
end

function PlayerListener.onReceiveSumRecharge(player, type, id, count, meta)
    print("onReceiveSumRecharge userId == " .. tostring(player.userId))
    RechargeUtil:doSumRechargeRewards(player, type, id, count, meta)
end

function PlayerListener.onReceiveSumRechargeEnd(player, id)
    print("onReceiveSumRechargeEnd userId == " .. tostring(player.userId))
end

return PlayerListener
--endregion
