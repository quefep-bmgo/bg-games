local CommonMain = require "common.CommonMain"

BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
    CommonMain:onGameInit()
    if GameType ~= "g1048" then
        GameConfig = {}
        require "mine_hole.listener.PlayerListener"
    else
        require "main.config.GameConfig"
        require "main.listener.PlayerListener"
        require "main.listener.BlockListener"
        GameConfig:init(config)
        HostApi.setMaxChangeInChunk(512)
        DBManager:disableAutoCache()
    end
    BaseMain:setGameType(GameType)
    DBManager:setGameType("g1048")
    PlayerManager:setMaxPlayer(100)
end)