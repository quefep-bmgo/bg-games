---@type TaskUtil
local TaskUtil = T(Global, "TaskUtil")
---@type BlockConfig
local BlockConfig = T(Global, "BlockConfig")
---@type IslandAreaConfig
local IslandAreaConfig = T(Global, "IslandAreaConfig")
---@type SCommonPkHandler
local CommonPkHandler = T(Global, "PacketHandlers")
---@type CustomBlock
local CustomBlock = T(Global, "CustomBlock")
---@type HomeTerrainMgr
local HomeTerrainMgr = T(Global, "HomeTerrainMgr")

local BlockListener = {}

function BlockListener:init()
    CEvents.BlockBreakWithMetaEvent:registerCallBack(self.onBlockBreakWithMeta)
    CEvents.PlayerPlaceBlockEvent:registerCallBack(self.onBlockPlace)
    CEvents.BlockTNTExplodeEvent:registerCallBack(self.onBlockTNTExplode)
end

local function calcPistonMeta(yaw, pitch)
    if pitch >= -90 and pitch < -45 then
        return 0
    elseif pitch <= 90 and pitch > 45 then
        return 1
    end
    yaw = yaw % 360
    yaw = yaw < 0 and 360 + yaw or yaw
    if yaw > 315 or yaw <= 45 then
        return 2
    elseif yaw > 45 and yaw <= 135 then
        return 5
    elseif yaw > 135 and yaw <= 225 then
        return 3
    elseif yaw > 225 and yaw <= 315 then
        return 4
    end
end

local function calcBlockMeat(yaw, meta)
    yaw = yaw % 360
    yaw = yaw < 0 and 360 + yaw or yaw
    if yaw > 315 or yaw <= 45 then
        return meta
    elseif yaw > 45 and yaw <= 135 then
        return meta == 0 and 3 or 11
    elseif yaw > 135 and yaw <= 225 then
        return meta == 0 and 1 or 9
    elseif yaw > 225 and yaw <= 315 then
        return meta == 0 and 2 or 10
    end
end

local function doExplode(entityId, pos)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return
    end
    player.inTNTExplode = true
    for x = -5, 5 do
        for y = -5, 5 do
            for z = -5, 5 do
                if math.random() < 0.5 then
                    goto CONTINUE
                end
                local blockPos = VectorUtil.toBlockVector3(pos.x + x, pos.y + y, pos.z + z)
                if player.obInfo:isOneBlockPos(blockPos) then
                    goto CONTINUE
                end
                local blockId = EngineWorld:getBlockId(blockPos)
                if blockId > 0 and blockId ~= 916 then
                    local meta = EngineWorld:getBlockMeta(blockPos)
                    if BlockListener.onBlockBreakWithMeta(player.rakssid, blockId, meta, blockPos) then
                        EngineWorld:setBlockToAir(blockPos)
                    end
                end
                :: CONTINUE ::
            end
        end
    end
    player.inTNTExplode = nil
end

local function doSponge(userId, pos)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local sponge_count = 0.5
    local play_count = 4
    LuaTimer:scheduleTimer(function(vec3)
        local posFloat = VectorUtil.newVector3(vec3.x + 0.5, vec3.y, vec3.z + 0.5)
        EngineWorld:addSimpleEffect("haimian.effect", posFloat, player:getYaw(), 1200, 0, sponge_count)
        sponge_count = sponge_count + 0.2
        play_count = play_count - 1
        if play_count == 2 then
            for x = vec3.x - 5, vec3.x + 5 do
                for y = vec3.y - 5, vec3.y + 5 do
                    for z = vec3.z - 5, vec3.z + 5 do
                        local posInt = VectorUtil.newVector3i(x, y, z)
                        local bId = EngineWorld:getBlockId(posInt)
                        if bId == BlockID.WATER_MOVING or bId == BlockID.WATER_STILL then
                            local _meta = EngineWorld:getBlockMeta(posInt)
                            if BlockListener.onBlockBreakWithMeta(player.rakssid, bId, _meta, posInt) then
                                EngineWorld:setBlockToAir(posInt)
                            end
                        end
                    end
                end
            end
        elseif play_count == 0 then
            local bId = EngineWorld:getBlockId(vec3)
            local _meta = EngineWorld:getBlockMeta(vec3)
            if BlockListener.onBlockBreakWithMeta(player.rakssid, bId, _meta, vec3) then
                EngineWorld:setBlockToAir(vec3)
            end
        end
    end, 1000, play_count, pos)
end

function BlockListener.onBlockBreakWithMeta(rakssid, blockId, blockMeta, blockPos)
    local integral = BlockConfig:getBlockIntegral(blockId, blockMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil or player.isKickOut then
        return false
    end
    if blockId == BlockID.BEDROCK then
        ---基岩方块
        return false
    end
    local targetId = player.info:getValue(Define.PlayerInfoKey.TargetId)
    local master = PlayerManager:getPlayerByUserId(targetId)
    if not master then
        --- master is not exist
        return false
    end
    local terrain = HomeTerrainMgr:getTerrain(targetId)
    if not terrain then
        return false
    end
    master:addExp(-integral)
    BlockConfig:onBreakBlock(master, blockId, blockMeta, blockPos)
    terrain:recordBlock(blockPos, 0, 0)
    if not player.inTNTExplode then
        TaskUtil:breakBlock(player, blockId, blockMeta)
    end
    return true
end

function BlockListener.onBlockPlace(rakssid, itemId, meta, toPlacePos)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player or player.isKickOut then
        return false
    end
    if player:getPlayerInventory():getHandItemId() ~= itemId then
        return false
    end
    local targetId = player.info:getValue(Define.PlayerInfoKey.TargetId)
    local master = PlayerManager:getPlayerByUserId(targetId)
    if not master then
        --- master is not exist
        return false
    end
    local terrain = HomeTerrainMgr:getTerrain(targetId)
    if not terrain then
        return false
    end
    local item = Item.getItemById(itemId)
    if not item then
        return false
    end
    local blockId = itemId < 1000 and itemId or itemId - 1000
    local name = item:getClassName()
    if name ~= "ItemDoor" then
        if not BlockManager.getBlockById(blockId) then
            return false
        end
    end
    local yaw = player:getYaw()
    if blockId == BlockID.TNT then
        if master ~= player then
            return false
        end
        if player:removeCurItem(1) then
            EngineWorld:setBlock(toPlacePos, blockId, 0, 0, false)
            EngineWorld:getWorld():fireTNT(toPlacePos, player:getEntityId())
        end
        return false
    end

    if CustomBlock:isCustomPlace(itemId) then
        return false
    end

    -- area
    local isInArea = IslandAreaConfig:isInIslandArea(master, terrain, toPlacePos)
    if isInArea == false then
        CommonPkHandler.showExtendArea(player)
        HostApi.log("onBlockPlace info15[isInArea] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end

    -- door
    if GameConfig:isDoorItemBlock(blockId) then
        HostApi.log("onBlockPlace info16[isDoorItemBlock] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    --custom item
    if name == "ItemCustom" then
        HostApi.log("onBlockPlace info19[isCustomItem] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return true
    end

    --half slab block less than 1000
    if GameConfig:isCommonHalfSlab(blockId) then
        HostApi.log("onBlockPlace isCommonHalfSlab " .. blockId)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    --half slab block more than 1000
    if GameConfig:isMoreThan1000HalfSlabItem(blockId) then
        HostApi.log("onBlockPlace isMoreThan1000HalfSlabItem " .. blockId)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    if blockId == BlockID.TRAPDOOR and (meta == 0 or meta == 8) then
        meta = calcBlockMeat(yaw, meta)
    end

    -- blockId more than 1000 handle
    if GameConfig:isMoreThan1000Block(blockId) then
        if player:removeCurItem(1) then

            local new_meta_1000 = meta
            if GameConfig:isStairsBlock(blockId) then
                new_meta_1000 = GameConfig:metaHandleStairs(yaw, new_meta_1000)
            end

            EngineWorld:setBlock(toPlacePos, blockId, new_meta_1000, 3)

            terrain:recordBlock(toPlacePos, blockId, new_meta_1000)
            local exp = BlockConfig:getBlockIntegral(blockId, meta)
            master:addExp(exp)
            HostApi.log("onBlockPlace suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockId
                    .. " blockMeta: " .. new_meta_1000 .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
            TaskUtil:placeBlock(player, itemId, meta)
        end

        return false
    end

    if player:removeCurItem(1) then
        -- block meta handle
        local new_meta = meta

        if blockId == BlockID.FENCE_GATE
                or blockId == BlockID.WHITE_FENCE_GATE then
            new_meta = GameConfig:metaHandleGate(yaw, new_meta)
        end

        if GameConfig:isStairsBlock(blockId) then
            new_meta = GameConfig:metaHandleStairs(yaw, new_meta)
        end

        if blockId == BlockID.PISTON_BASE or blockId == BlockID.PISTON_STICKY_BASE then
            new_meta = calcPistonMeta(player:getYaw(), player:getPitch())
        end

        HostApi.log("onBlockPlace suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockId
                .. " blockMeta: " .. new_meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)

        local oldBlockId = EngineWorld:getBlockId(toPlacePos)
        EngineWorld:setBlock(toPlacePos, blockId, new_meta, 3)

        if BlockID.SPONGE == itemId and (oldBlockId == BlockID.AIR or oldBlockId == BlockID.WATER_STILL or oldBlockId == BlockID.WATER_MOVING or oldBlockId == BlockID.WATERLILY or oldBlockId == BlockID.SNOW) then
            doSponge(player.userId, toPlacePos)
        end

        terrain:recordBlock(toPlacePos, blockId, new_meta)
        local integral = BlockConfig:getBlockIntegral(blockId, meta)
        master:addExp(integral)
        TaskUtil:placeBlock(player, itemId, new_meta)
    end
    return false
end

function BlockListener.onBlockTNTExplode(entityId, pos, attr)
    attr.isCanHurt = false
    attr.isBreakBlock = false
    doExplode(entityId, pos)
    return false
end

BlockListener:init()

return BlockListener