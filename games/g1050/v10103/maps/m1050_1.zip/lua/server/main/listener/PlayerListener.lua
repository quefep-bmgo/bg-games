---@type SBasePlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type HomeMgr
local HomeMgr = T(Global, "HomeMgr")
---@type CommonServer
local CommonServer = T(Global, "CommonServer")

local PlayerListener = {}

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerRespawnEvent, self.onPlayerRespawn)
    CEvents.PlayerUseInitSpawnPositionEvent:registerCallBack(self.onPlayerUseInitSpawnPosition)
end

---@param clientPeer ClientPeer
function PlayerListener.onPlayerLogin(clientPeer)
    if CommonServer:isServerClosed() then
        return GameOverCode.GameOver
    end
    local userId = clientPeer:getPlatformUserId()
    local attr = GameServer:getRoomManager():getUserAttrInfo(userId)
    if not attr then
        LogUtil.logWarning("[PlayerListener.onPlayerLogin] attr=nil, userId=" .. userId)
        return GameOverCode.GameOver
    end
    local home = HomeMgr:findHomeById(attr.manorId)
    if isLocalWin and not home then
        HomeMgr:initHome(attr.targetUserId, attr.manorId)
        home = HomeMgr:findHomeById(attr.manorId)
    end
    if not home or not home:canPlayerEnter() then
        LogUtil.logWarning("[PlayerListener.onPlayerLogin] home=nil or home is force release, userId=" .. userId .. ", manorId=" .. attr.manorId)
        return GameOverCode.GameOver
    end
    local player = SSkyBlockPlayer.new(clientPeer)
    player:init()
    home:onBackHome(player)
    return GameOverCode.Success, player, 1
end

---@param player SBasePlayer
function PlayerListener.onPlayerRespawn(player)
    if player:inHome() then
        local home = HomeMgr:findPlayerHome(player.userId)
        if home then
            home:onBackHome(player)
        else
            player:teleInitPos()
        end
    else
        player:teleInitPos()
    end
end

---@param player SBasePlayer
function PlayerListener.onPlayerReady(player)
    local home = HomeMgr:findPlayerHome(player.userId)
    if home then
        player:checkBackHome(home.masterId)
    end
end

function PlayerListener.onPlayerUseInitSpawnPosition(userId, spawnPos, spawnYaw)
    local attr = GameServer:getRoomManager():getUserAttrInfo(userId)
    if not attr then
        return true
    end
    local home = HomeMgr:findHomeById(attr.manorId)
    if not home then
        return true
    end
    local teleportPos, teleportYaw
    if home:isMaster(userId) then
        teleportPos = home:toWorldPos(home.terrain.masterPos)
        teleportYaw = home.terrain.masterPos.yaw or 90
    else
        teleportPos = home:toWorldPos(home.terrain.visitorPos)
        teleportYaw = home.terrain.visitorPos.yaw or 90
    end
    spawnPos.x = teleportPos.x
    spawnPos.y = teleportPos.y
    spawnPos.z = teleportPos.z
    spawnYaw.value = teleportYaw
    return false
end

PlayerListener:init()

return PlayerListener