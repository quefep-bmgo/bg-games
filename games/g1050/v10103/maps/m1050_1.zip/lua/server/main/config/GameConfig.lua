---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:16
---
require "main.config.ConfigurableBlockConfig"

GameConfig = {}
GameConfig.RootPath = ""

function GameConfig:init(config)
    ConfigurableBlockConfig:initConfig(FileUtil.getConfigFromCsv("setting/configurableBlock.csv", 3))
end

function GameConfig:isDoorItemBlock(id)
    return id == 324 or id == 330 or id == 510
end

function GameConfig:isStairsBlock(id)
    return id == BlockID.STAIRS_WOOD_OAK
            or id == BlockID.STAIRS_COBBLESTONE
            or id == BlockID.STAIRS_BRICK
            or id == BlockID.STAIRS_STONE_BRICK
            or id == BlockID.STAIRS_NETHER_BRICK
            or id == BlockID.STAIRS_SAND_STONE
            or id == BlockID.STAIRS_WOOD_SPRUCE
            or id == BlockID.STAIRS_WOOD_BIRCH
            or id == BlockID.STAIRS_WOOD_JUNGLE
            or id == BlockID.STAIRS_NETHER_QUARTZ
            or id == BlockID.STAIRS_WOOD_DARKOAK
            or id == BlockID.BLOCK_ID_STAIRS_PRISMARINE
            or id == BlockID.BLOCK_ID_STAIRS_PRISMARINE_BRICK
            or id == BlockID.BLOCK_ID_STAIRS_DARK_PRISMARINE
            or id == BlockID.BLOCK_ID_STAIRS_RED_NETHER_BRICK
            or ConfigurableBlockConfig:isStairs(id)
end

function GameConfig:isCommonHalfSlab(id)
    return id == BlockID.STONE_SINGLE_SLAB
            or id == BlockID.WOOD_SINGLE_SLAB
end

function GameConfig:isMoreThan1000HalfSlabItem(id)
    return id == BlockID.BLOCK_ID_PRISMARINE_SINGLE_SLAB
            or ConfigurableBlockConfig:isSingleHalfSlab(id)
end

function GameConfig:metaHandleGate(yaw, meta)
    local new_meta = meta
    local new_yaw = math.floor(yaw)
    while new_yaw < 0 do
        new_yaw = new_yaw + 360
    end

    while new_yaw > 360 do
        new_yaw = new_yaw - 360
    end

    if new_yaw >= 45 and new_yaw < 135 then
        new_meta = 5
    elseif new_yaw >= 135 and new_yaw < 225 then
        new_meta = 0
    elseif new_yaw >= 225 and new_yaw < 315 then
        new_meta = 1
    else
        new_meta = 2
    end
    return new_meta
end

function GameConfig:metaHandleStairs(yaw, meta)
    local new_meta = meta

    local new_yaw = math.floor(yaw)
    while new_yaw < 0 do
        new_yaw = new_yaw + 360
    end

    while new_yaw > 360 do
        new_yaw = new_yaw - 360
    end

    if meta == 4 then
        if new_yaw >= 45 and new_yaw < 135 then
            new_meta = 5
        elseif new_yaw >= 135 and new_yaw < 225 then
            new_meta = 7
        elseif new_yaw >= 225 and new_yaw < 315 then
            new_meta = 4
        else
            new_meta = 6
        end
    else
        if new_yaw >= 45 and new_yaw < 135 then
            new_meta = 1
        elseif new_yaw >= 135 and new_yaw < 225 then
            new_meta = 3
        elseif new_yaw >= 225 and new_yaw < 315 then
            new_meta = 0
        else
            new_meta = 2
        end
    end

    return new_meta
end

function GameConfig:isMoreThan1000Block(blockId)
    return blockId == BlockID.BLOCK_ID_PRISMARINE
            or blockId == BlockID.BLOCK_ID_PRISMARINE_BRICK
            or blockId == BlockID.BLOCK_ID_DARK_PRISMARINE
            or blockId == BlockID.BLOCK_ID_STARRY_SKY
            or blockId == BlockID.BLOCK_ID_STAIRS_PRISMARINE
            or blockId == BlockID.BLOCK_ID_STAIRS_PRISMARINE_BRICK
            or blockId == BlockID.BLOCK_ID_STAIRS_DARK_PRISMARINE
            or blockId == BlockID.BLOCK_ID_STAIRS_RED_NETHER_BRICK
            or blockId == BlockID.BLOCK_ID_PRISMARINE_DOUBLE_SLAB
            or blockId == BlockID.BLOCK_ID_PRISMARINE_SINGLE_SLAB
            or blockId == BlockID.ALLIUM
            or blockId == BlockID.BLUE_ORCHID
            or blockId == BlockID.HOUSTONIA
            or blockId == BlockID.OXEYE_DAISY
            or blockId == BlockID.PAEONIA
            or blockId == BlockID.TULIP_PINK
            or blockId == BlockID.TULIP_RED
            or blockId == BlockID.TULIP_WHITE or ConfigurableBlockConfig:isConfigurableBlock(blockId)
end

return GameConfig