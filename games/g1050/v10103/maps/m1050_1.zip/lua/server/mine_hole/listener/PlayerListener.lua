---@type SBasePlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type CommonServer
local CommonServer = T(Global, "CommonServer")

local PlayerListener = {}

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)
end

function PlayerListener.onPlayerLogin(clientPeer)
    if CommonServer:isServerClosed() then
        return GameOverCode.GameOver
    end
    local player = SSkyBlockPlayer.new(clientPeer)
    player:init()
    return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerReady(player)
    player:teleInitPos()
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player then
        player.cheat:trigger("onMove", VectorUtil.newVector3(x, y, z))
    end
    return true
end

PlayerListener:init()

return PlayerListener