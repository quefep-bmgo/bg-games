local PluginMain = {}

local function setPlayerMPCanUpdate(times)
    local player = Blockman.Instance():getPlayer()
    if not player then
        return
    end
    if not Blockman.Instance():isGameReady() then
        player:setCanUpdate(false)
        LuaTimer:schedule(function()
            setPlayerMPCanUpdate(times)
        end, 0)
        return
    end
    local position = player:getPosition()
    position.y = position.y - player:getYOffset() + 0.5
    position = VectorUtil.toVector3i(position)
    for i = 0, 5 do
        local blockPos = VectorUtil.newVector3i(position.x, position.y - i, position.z)
        if EngineWorld:getBlockId(blockPos) ~= BlockID.AIR then
            player:setCanUpdate(true)
            return
        end
    end
    player:setCanUpdate(false)
    LuaTimer:schedule(function()
        if times < 25 then
            setPlayerMPCanUpdate(times + 1)
        else
            Blockman.Instance():getPlayer():setCanUpdate(true)
        end
    end, 200)
end

function PluginMain:init()
    BaseListener.registerCallBack(CEvents.GameInitEvent, self.onGameInit)
    BaseListener.registerCallBack(CEvents.LuaLoadWorldEndEvent, self.onLuaLoadWorldEnd)
end

function PluginMain.onGameInit()
    TextureAtlasRegister.Instance():addTextureAtlas("home_icon.json", "", function(_, _)
    end, true)
    TextureAtlasRegister.Instance():addTextureAtlas("head_image.json", "", function(_, _)
    end, true)
end

function PluginMain.onLuaLoadWorldEnd()
    if GameType ~= "g1048" then
        return
    end
    setPlayerMPCanUpdate(0)
end

PluginMain:init()

return PluginMain