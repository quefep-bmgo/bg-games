Plugins.Require("chat", "common.define.ChatDefine")
Plugins.Require("chat", "common.define.ChatEvents")
Plugins.Require("chat", "common.config.ChatConfig")
Plugins.Require("chat", "common.config.EmojiConfig")

if isClient then
    Plugins.Require("chat", "client.service.MessageService")
    Plugins.Require("chat", "client.service.ChatService")
    Plugins.Require("chat", "client.service.FriendService")
    Plugins.Require("chat", "client.chat.ChatClient")
    Plugins.Require("chat", "client.chat.ChatCommand")
    Plugins.Require("chat", "client.packet.ChatPkSender")
    Plugins.Require("chat", "client.player.ClientPlayer")
    UIHelper.newGameGUILayout("GUILuaChat")
else
    Plugins.Require("chat", "server.connector.MessageInterceptor")
    Plugins.Require("chat", "server.packet.ChatPkHandler")
    ---@type SConnectorCenter
    local SConnectorCenter = T(Global, "ConnectorCenter")
    SConnectorCenter:start()
end

local handlers = {}

---@param player SBasePlayer
function handlers.onPlayerLogout(player)
    if isClient then
        return
    end
    ---@type table<table<number>>
    local MessageCdTime = T(Global, "MessageCdTime")
    MessageCdTime[player.userId] = nil
end

return function(name, ...)
    if type(handlers[name]) ~= "function" then
        return
    end
    return handlers[name](...)
end