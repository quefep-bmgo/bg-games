
GameMerchant = class()

function GameMerchant:ctor(config)
    self.level = 0
    self.config = config
    self.teamId = config.id
    self.goods = config.goods
    self.entityId = EngineWorld:addMerchantNpc(config.initPos, config.yaw, config.name)
end

function GameMerchant:getCurGoods()
    local info = self.config.goods[self.level]
    if info == nil then
        info = self.config.goods[1]
    end
    return info
end

function GameMerchant:syncPlayers()
    local info = self:getCurGoods()
    if info == nil then
        return
    end
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        MerchantUtil:changeCommodityList(self.entityId, player.rakssid, info.groupId)
    end
end

function GameMerchant:syncPlayer(player)
    local info = self:getCurGoods()
    if info == nil then
        return
    end
    MerchantUtil:changeCommodityList(self.entityId, player.rakssid, info.groupId)
end

function GameMerchant:onRemove()
    EngineWorld:removeEntity(self.entityId)
end
