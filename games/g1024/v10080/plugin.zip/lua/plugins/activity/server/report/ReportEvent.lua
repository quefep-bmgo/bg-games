---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@param player SBasePlayer
---@param event number event [event name]
---@param event_map table event_map [eg {key1 = value1,key2 = value2, ...}]
local function newDesign(player, event, event_map)
    if AIManager and AIManager:isAIByUserId(player.userId) then
        return
    end
    local new_map = {}
    for key, value in pairs(event_map) do
        new_map["activity_" .. key] = value
    end
    new_map["total_recharge_cube"] = player.total_recharge_cube
    GameAnalytics:newDesign(player.userId, event, new_map)
end

---@param player SBasePlayer
function ReportEvent.activity_must_lottery(player, activity_id, cur_times, reward_id)
    local map = {
        id = tonumber(activity_id),
        cur_times = tonumber(cur_times),
        reward_id = tonumber(reward_id)
    }
    newDesign(player, "activity_must_lottery", map)
end
---@param player SBasePlayer
function ReportEvent.activity_must_delete(player, activity_id, reward_id)
    local map = {
        id = tonumber(activity_id),
        reward_id = tonumber(reward_id)
    }
    newDesign(player, "activity_must_delete", map)
end
---@param player SBasePlayer
function ReportEvent.activity_lucky_lottery(player, activity_id, use_discount, use_ticket, lottery_times, total_times)
    local map = {
        id = tonumber(activity_id),
        lottery_times = tonumber(lottery_times),
        total_times = tonumber(total_times),
        use_ticket = use_ticket,
        use_discount = use_discount
    }
    newDesign(player, "activity_lucky_lottery", map)
end

---@param player SBasePlayer
function ReportEvent.activity_lucky_grand_prize(player, activity_id, cur_lucky_value)
    local map = {
        id = tonumber(activity_id),
        cur_lucky_value = tonumber(cur_lucky_value),
    }
    newDesign(player, "activity_lucky_grand_prize", map)
end

---@param player SBasePlayer
function ReportEvent.activity_blind_lottery(player, activity_id, box_id, box_cur_times, box_cur_day_times)
    local map = {
        id = tonumber(activity_id),
        box_id = tonumber(box_id),
        box_cur_times = tonumber(box_cur_times),
        box_cur_day_times = tonumber(box_cur_day_times),
    }
    newDesign(player, "activity_blind_lottery", map)
end

---@param player SBasePlayer
function ReportEvent.activity_chest_reward(player, activity_id, chest_id)
    local map = {
        id = tonumber(activity_id),
        chest_id = tonumber(chest_id)
    }
    newDesign(player, "activity_chest_reward", map)
end

---@param player SBasePlayer
function ReportEvent.activity_reward(player, activity_id, reward_id, is_compensate)
    local map = {
        id = tonumber(activity_id),
        reward_id = tonumber(reward_id),
        is_compensate = is_compensate,
    }
    newDesign(player, "activity_reward", map)
end

---@param player SBasePlayer
function ReportEvent.activity_coin_change(player, total, change)
    local map = {
        coin_total = tonumber(total),
        coin_change = tonumber(change),
    }
    newDesign(player, "activity_coin_change", map)
end


