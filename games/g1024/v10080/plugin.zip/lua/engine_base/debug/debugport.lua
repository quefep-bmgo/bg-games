-- https://www.iana.org/assignments/telnet-options/telnet-options.xhtml

local lfs = require("lfs")
local misc = require("misc")
local cjson = require("cjson")
local ts = require("telnetserver")

function L(name, init)
    -- 未实现热更新
    return init
end

function table.pack(...)
    local tb = { ... }
    tb.n = select("#", ...)
    return tb
end

function _load(chunk, chunkname, mode, env)
    local func, msg = loadstring(chunk, chunkname)
    if func and env then
        setfenv(func, env)
    end
    return func, msg
end

function _loadfile(filename, mode, env)
    local func, msg = loadfile(filename)
    if func and env then
        setfenv(func, env)
    end
    return func, msg
end

local function v2s(value, sp, restLevel)
    local typ = type(value)
    if typ == "string" then
        return '\"' .. value .. '\"'
    elseif typ ~= "table" then
        return tostring(value)
    end
    restLevel = restLevel - 1
    if restLevel < 0 then
        return "..."
    end
    local nsp = sp .. "  "
    local tb = {}
    local idxs = {}
    for k, v in ipairs(tb) do
        idxs[k] = true
        tb[#tb + 1] = "[" .. k .. "] = " .. v2s(v, nsp, restLevel)
    end
    for k, v in pairs(value) do
        if not idxs[k] then
            k = (type(k) == "string") and ('\"' .. k .. '\"') or tostring(k)
            tb[#tb + 1] = "[" .. k .. "] = " .. v2s(v, nsp, restLevel)
        end
    end
    if not tb[1] then
        return "{}"
    end
    nsp = "\n" .. nsp
    return "{" .. nsp .. table.concat(tb, "," .. nsp) .. "\n" .. sp .. "}";
end

Lib = {}

function Lib.v2s(value, maxLevel)
    return v2s(value, "", maxLevel or 3)
end

function Lib.pv(value, maxLevel, tips)
    print(
            tips, v2s(value, "", maxLevel or 3)
    )
end

local remotedebug = require "engine_base.debug.remotedebug"

local TelnetServer = ts.mt

local oldPrint = L("oldPrint", print)
local servers = L("servers", {})
local historyPath = L("historyPath")
local debugEnv = setmetatable({}, { __index = _G })
local reportData = L("reportData")
local reportTime = L("reportTime", 0)
local REPORT_SERVER = "47.243.80.43"
local curDir = L("curDir", lfs.currentdir())
local pathList = L("pathList", {})
local attachedSessions = L("attachedSessions", {})

local M = L("M", {})

debugEnv.curServer = nil
debugEnv.w = World.CurWorld

function TelnetServer:writeline(...)
    local arg = table.pack(...)
    for i = 1, arg.n do
        arg[i] = tostring(arg[i]):gsub("\n", "\r\n")
    end
    self:write(table.concat(arg, "\t") .. "\r\n")
end

function TelnetServer:print(...)
    oldPrint("[DebugPort]", ...)
    self:writeline(...)
end

local function p(...)
    debugEnv.curServer:writeline(...)
end
debugEnv.p = p
function debugEnv.print(...)
    oldPrint(...)
    p(...)
end
function debugEnv.pv(value, maxLevel)
    p(Lib.v2s(value, maxLevel))
end
function debugEnv.o(id)
    return World.CurWorld:getObject(id)
end

local function readHistory()
    local file = io.open(historyPath)
    if not file then
        return {}
    end
    local lines = {}
    for line in file:lines() do
        lines[#lines + 1] = line
    end
    file:close()
    return lines
end

local function addHistory(line)
    local file = io.open(historyPath, "a+")
    if file then
        file:write(line .. "\n")
        file:close()
    end
end

local function dofunc(serverInfo, func, msg)
    local server = serverInfo.server
    if not func then
        server:print(msg)
        return
    end
    print = debugEnv.print
    local ok, msg = xpcall(func, traceback)
    print = oldPrint
    if not ok then
        server:print(msg)
    end
end

local cmds = {}

function cmds:d(value)
    dofunc(self, _load(value, "@(DebugCmd)", nil, debugEnv))
end

function cmds:i(value)
    self.isREPLMode = true
    self.isMultilineStatement = false
    self.incompleteStatement = ''
end

function cmds:f(value)
    if not value then
        p("need filename!")
        return
    end
    dofunc(self, _loadfile(value, nil, debugEnv))
end

function cmds:pf(value)
    if not value then
        p("Profiler is " .. (Profiler.inited and "on" or "off"))
    elseif value == "dump" then
        p(Profiler:dumpString())
    elseif value == "on" then
        Profiler:init()
    elseif value == "off" then
        Profiler:reset()
    else
        p("useage: pf [dump|on|off]")
    end
end

function cmds:o(value)
    for _, obj in ipairs(World.CurWorld:getAllObject()) do
        p(obj.objID, obj:getCfgName(), obj.map, obj.isEntity and obj.name or "", Lib.tov3(obj:getPosition() or {}), obj)
    end
end

function cmds:p(value)
    for _, entity in ipairs(World.CurWorld:getAllEntity()) do
        if entity.isPlayer then
            p(entity.objID, entity:getCfgName(), entity.map, entity.name or "", Lib.tov3(entity:getPosition() or {}), entity)
        end
    end
end

local function reload(hasChangeImage)
    local changed = {}
    for name, info in pairs(package.filelist) do
        local time = lfs.attributes(info.path, "modification")
        if time and time ~= info.time then
            changed[#changed + 1] = name
        end
    end
    print("changed lua file(s):", #changed)
    for _, name in ipairs(changed) do
        print("", name)
        package.loaded[name] = nil
        require(name)
    end
    local changed = setting:reload()
    if World.isClient then
        ResLoader:reload(changed, hasChangeImage)
    end
    if #changed > 0 then
        Player.Reload()
        Coin.Reload()
        Shop.Reload()
        Commodity.Reload()
        if not World.isClient then
            GM.updateAllPlayer()
        end
    end
    World.Reload(changed)
    print("changed config file(s):", #changed)
    for _, name in ipairs(changed) do
        print("", name)
    end

    if World.isClient then
        --ui files
        local uiChanged = {}
        for uiName, uiInfo in pairs(UIMgr.uiFileList) do
            local uiTime = lfs.attributes(uiInfo.path, "modification")
            if uiTime and uiTime ~= uiInfo.time then
                uiChanged[#uiChanged + 1] = uiName
                UIMgr:reload(uiName)
            end
        end
        print("changed ui window file(s):", #uiChanged)
    end

    for _, v in pairs(Config) do
        if type(v) == "table" then
            if v.reload then
                v:reload()
            end
        end
    end
end

function cmds:r(value)
    print = debugEnv.print
    reload(value)
    print = oldPrint
end

function cmds:R(value)
    print = debugEnv.print
    M.AutoReload()
    print = oldPrint
end

function cmds:bake(maxLightMode)
    print = debugEnv.print
    if World.isClient then
        World.CurMap:bakeLightAndSave(maxLightMode, true)
    end
    print = oldPrint
end

function cmds:h(value)
    local lines = readHistory()
    local h = math.tointeger(value)
    if h and h >= 1 and h <= #lines then
        local tb = self
        tb.text = lines[h]
        tb.cursor = #tb.text + 1
        tb.history = h
    else
        for i, line in ipairs(lines) do
            p(string.format("%d. %s", i, line))
        end
    end
end

local function AttachPlayer(tb, player)
    if tb.server then
        tb.server:writeline("attach player:", player)
    end
    local sessionId = 1
    while attachedSessions[sessionId] do
        sessionId = sessionId + 1
    end
    attachedSessions[sessionId] = true
    tb.player = player
    tb.attachedSessionId = sessionId
    player:AttachDebugPort(tb.attachedSessionId)
end

local function DetachPlayer(tb)
    if not tb.player then
        return
    end
    if tb.server then
        tb.server:writeline("detach player")
    end
    tb.player:DetachDebugPort(tb.attachedSessionId)
    attachedSessions[tb.attachedSessionId] = nil
    tb.attachedSessionId = nil
    tb.player = nil
end

function cmds:a(value)
    local server = self.server
    if World.isClient ~= false then
        server:writeline("for server only!")
        return
    end
    if not value or value == "" then
        DetachPlayer(self)
        return
    end
    local obj = World.CurWorld:getObject(tonumber(value))
    if not obj or not obj.isPlayer then
        server:writeline("player not found:", value)
        return
    end
    AttachPlayer(self, obj)
end

function cmds:l(value)
    local server = self.server
    if not value or value == "" then
        pathList = {
            Root.Instance():getRootPath(),
            Root.Instance():getMapPath(),
            Root.Instance():getWriteablePath(),
        }
        server:writeline(" curent:", curDir)
        server:writeline("1. root:", pathList[1])
        server:writeline("2. game:", pathList[2])
        server:writeline("3. conf:", pathList[3])
        return
    end
    if value == "." then
        value = curDir
    elseif value == ".." then
        local i = curDir:find("[/\\][^/\\]+[/\\]?$")
        if i then
            value = curDir:sub(1, i - 1)
        else
            value = curDir
        end
    elseif tonumber(value) then
        value = pathList[tonumber(value)] or value
    end
    if value:sub(1, 1) ~= "/" and value:sub(2, 2) ~= ":" then
        if curDir:sub(-1) ~= "/" and curDir:sub(-1) ~= "\\" then
            value = curDir .. "/" .. value
        else
            value = curDir .. value
        end
    end
    if value:sub(2) == ":" then
        value = value .. "/"
    end
    local mode = lfs.attributes(value, "mode")
    if not mode then
        server:writeline("can't find path:", value)
        return
    end
    if mode == "file" then
        local file = io.open(value)
        if not file then
            server:writeline("can't open file:", value)
            return
        end
        server:writeline("show file:", value)
        server:writeline(file:read("a"))
        file:close()
        return
    end
    if mode ~= "directory" then
        server:writeline("unknown file type:", mode)
        return
    end
    server:writeline(" curent:", value)
    local list = {}
    for name in lfs.dir(value) do
        if name ~= "." and name ~= ".." then
            local attr = lfs.attributes(value .. "/" .. name)
            if attr then
                local index = #list + 1
                list[index] = name
                local text = string.format("%3d.  ", index) .. os.date("%Y-%m-%d %H:%M:%S ", attr.modification)
                if attr.mode == "directory" then
                    server:writeline(text .. string.format("%10s [%s]", "-", name))
                else
                    server:writeline(text .. string.format("%10d %s", attr.size, name))
                end
            end
        end
    end
    curDir = value
    pathList = list
end

function cmds:q(value)
    DetachPlayer(self)
    servers[self.server] = nil
    self.server:close()
    self.server = nil
end

function cmds:ce(value)
    local server = self.server
    if not value or value == "" then
        server:writeline("need the obj ID")
        return
    end
    local entity = World.CurWorld:getObject(tonumber(value))
    if not entity or not entity.isPlayer then
        server:writeline("player not found:", value)
        return
    end
    -- level / exp
    if entity:getValue("level") then
        entity:setValue("level", 1)
    end
    if entity:getValue("exp") then
        entity:setValue("exp", 0)
    end
    -- skill
    local studySkillMap = entity:data("skill").studySkillMap or {}
    local skillMap = studySkillMap["studySkills"]
    local equipSkills = studySkillMap["equipSkills"]
    for name, v in pairs(skillMap or {}) do
        local skill = Skill.Cfg(name)
        if skill.isActive then
            skillMap[name] = nil
        end
        if skill.isPassive then
            local buffCfg = skill.buffCfg
            skillMap[name] = nil
            local buff = entity:getTypeBuff("fullName", buffCfg)
            if buff then
                entity:removeBuff(buff)
            end
        end
    end
    studySkillMap["studySkills"] = {}
    studySkillMap["equipSkills"] = {}
    local vars = entity.vars
    if vars then
        vars.entitySkill = {}
        vars.entitySkill[1] = {}
        vars.entitySkill[2] = {}
    end
    entity:syncSkillMap()
    entity:syncStudySkillMap()
    -- tray bag
    --local trays = entity:tray():query_trays(Define.TRAY_TYPE.BAG)
    --for _, tray in pairs(trays or {}) do
    --	local slots = tray:query_items()
    --	for slot, item in pairs(slots) do
    --		tray:remove_item(slot)
    --	end
    --end
end

function cmds:se(value)
    local server = self.server
    if not value or value == "" then
        server:writeline("need the obj ID")
        return
    end
    local entity = World.CurWorld:getObject(tonumber(value))
    if not entity or not entity.isPlayer then
        server:writeline("player not found:", value)
        return
    end
    entity:saveDBData()
end

function cmds:help(value)
    local server = self.server
    server:writeline()
    server:writeline("DebugPort usage:")
    server:writeline("  i       ,enter REPL mode. call 'exit()' to leave")
    server:writeline("  d str   ,do lua script.")
    server:writeline("  f file  ,do lua file.")
    server:writeline("  o       ,show all map object.")
    server:writeline("  p       ,show all players.")
    server:writeline("  r bool  ,reload all new file,has change image? 0 or 1,default=0.")
    server:writeline("  R       ,start/stop auto reload.")
    server:writeline("  bake bool ,rebake forceRecalculate map block light and save,maxLightMode=0?1")
    server:writeline("  a [id]  ,attach player.")
    server:writeline("  h [n]   ,command history.")
    server:writeline("  l path  ,list dir or show file.")
    server:writeline("  q       ,exit debug.")
    server:writeline("  ce [id] ,clear entity all active/passive skill ,level and tray.")
    server:writeline("  se [id] ,save the entity data(win).")
    server:writeline("  pf [dump|on|off] ,profiler operations.")
    server:writeline("  help    ,this message.")
end

local CC_Home = string.char(27, 91, 49, 126)
local CC_Del = string.char(27, 91, 51, 126)
local CC_End = string.char(27, 91, 52, 126)
local CC_Up = string.char(27, 91, 65)
local CC_Down = string.char(27, 91, 66)
local CC_Right = string.char(27, 91, 67)
local CC_Left = string.char(27, 91, 68)

local function addText(tb, text)
    local i = tb.cursor
    tb.text = tb.text:sub(1, i - 1) .. text .. tb.text:sub(i)
    tb.cursor = i + #text
end

local ByteFunc = {
    [0] = function(tb)
        return 1, true
    end,
    [8] = function(tb)
        local c = tb.cursor - 1
        if c >= 1 then
            tb.text = tb.text:sub(1, c - 1) .. tb.text:sub(c + 1)
            tb.cursor = c
        end
        return 1, false
    end,
    [10] = function(tb)
        local nb = tb.buff:byte(2)
        if nb == 13 or nb == 0 then
            return 2, true
        else
            return 1, true
        end
    end,
    [13] = function(tb, index)
        local nb = tb.buff:byte(2)
        if nb == 10 or nb == 0 then
            return 2, true
        else
            return 1, true
        end
    end,
    [27] = function(tb)
        if #tb.buff == 1 then
            tb.text = ""
            tb.cursor = 1
            return 1, false
        end
        local cc3 = tb.buff:sub(1, 3)
        local cc4 = tb.buff:sub(1, 4)
        if cc3 == CC_Left then
            local c = tb.cursor - 1
            if c >= 1 then
                tb.cursor = c
            end
            return 3, false
        elseif cc3 == CC_Right then
            local c = tb.cursor + 1
            if c <= #tb.text + 1 then
                tb.cursor = c
            end
            return 3, false
        elseif cc3 == CC_Up then
            local lines = readHistory()
            local h = tb.history or (#lines + 1)
            if h > 1 then
                h = h - 1
                tb.text = lines[h] or ""
                tb.cursor = #tb.text + 1
                tb.history = h
            end
            return 3, false
        elseif cc3 == CC_Down then
            local h = tb.history
            if h then
                local lines = readHistory()
                if h >= #lines then
                    h = nil
                    tb.text = ""
                    tb.cursor = 1
                else
                    h = h + 1
                    tb.text = lines[h]
                    tb.cursor = #tb.text + 1
                end
                tb.history = h
            end
            return 3, false
        elseif cc4 == CC_Del then
            local c = tb.cursor
            tb.text = tb.text:sub(1, c - 1) .. tb.text:sub(c + 1)
            return 4, false
        elseif cc4 == CC_Home then
            tb.cursor = 1
            return 4, false
        elseif cc4 == CC_End then
            tb.cursor = #tb.text + 1
            return 4, false
        end
        return #cc3, false
    end,
    [127] = function(tb)
        local c = tb.cursor
        tb.text = tb.text:sub(1, c - 1) .. tb.text:sub(c + 1)
        return 1, false
    end,
    [255] = function(tb)
        local buff = tb.buff
        if #buff < 2 then
            return false
        end
        local b = buff:byte(2)
        if b == 255 then
            addText(tb, string.char(255))
            return 2, false
        end
        if b ~= 250 then
            print("[DebugPort] unknown code:", b)
            return 2, false
        end
        local sub = ""
        local iac = false
        for i = 3, #buff do
            b = buff:byte(i)
            if iac then
                if b == 255 then
                    sub = sub .. string.char(b)
                elseif b == 240 then
                    return i, sub
                else
                    print("[DebugPort] unknown sub code:", b)
                    return i, false
                end
            elseif b == 255 then
                iac = true
            else
                sub = sub .. string.char(b)
            end
        end
        return false
    end,
}

local function addBuffText(tb, index)
    if index <= 1 then
        return false
    end
    addText(tb, tb.buff:sub(1, index - 1))
    tb.buff = tb.buff:sub(index)
    return true
end

local function readline(tb)
    local buff, running = tb.server:readbuff()
    buff = buff or ''
    tb.buff = tb.buff .. buff
    if tb.buff == '' then
        return nil, running
    end
    local index = 1
    while index <= #tb.buff do
        local b = tb.buff:byte(index)
        local func = ByteFunc[b]
        if func then
            addBuffText(tb, index)
            local len, lok = func(tb, index)
            if not len then
                break
            end
            tb.buff = tb.buff:sub(len + 1)
            if lok then
                return lok, running
            end
            index = 1
        else
            index = index + 1
        end
    end
    addBuffText(tb, index)
    return false, running
end

local function writeInput(tb)
    if not tb.server then
        return
    end
    local text = tb.text
    local sp = tb.inputLen - #text
    if sp < 0 then
        sp = 0
    end
    local prompt = ""
    local player = tb.player
    if player then
        if player:isValid() then
            prompt = prompt .. string.format("[%d] ", player.objID)
        else
            tb.player = nil
        end
    end
    if tb.isREPLMode then
        prompt = prompt .. "i"
    end
    if tb.isMultilineStatement then
        prompt = prompt .. ">>> "
    else
        prompt = prompt .. "> "
    end

    tb.server:write(string.rep(CC_Up, tb.inputRow) .. string.char(13) .. prompt .. text .. string.rep(" ", sp + 1) .. string.char(8))
    tb.inputLen = #text
    local cursor = tb.cursor + #prompt - 1
    tb.inputRow = math.floor(cursor / tb.screenWidth)
    tb.server:write(string.rep(CC_Up, math.floor((tb.inputLen + sp + #prompt) / tb.screenWidth) - tb.inputRow) .. string.char(13) .. string.rep(CC_Right, cursor % tb.screenWidth))
end

local function playerCmdRet(server, msg, isREPLMode_, isMultilineStatement_)
    local tb = servers[server]
    if not tb then
        return
    end
    tb.isREPLMode = isREPLMode_
    tb.isMultilineStatement = isMultilineStatement_
    server:print(msg)
    writeInput(tb)
end

local function evaluateLuaStatement(serverInfo, line)
    local server = serverInfo.server
    serverInfo.isMultilineStatement = false
    serverInfo.incompleteStatement = serverInfo.incompleteStatement .. line .. '\n'
    local func, msg = _load('return ' .. serverInfo.incompleteStatement, "@(DebugCmd)", "t", debugEnv)
    if not func then
        if msg:sub(-#'<eof>') == '<eof>' then
            serverInfo.isMultilineStatement = true
            return
        end
        func, msg = _load(serverInfo.incompleteStatement, "@(DebugCmd)", "t", debugEnv)
        if not func then
            if msg:sub(-#'<eof>') == '<eof>' then
                serverInfo.isMultilineStatement = true
                return
            else
                server:print(msg)
                serverInfo.incompleteStatement = ''
                return
            end
        end
    end
    print = debugEnv.print
    local oldExit = rawget(debugEnv, "exit")
    debugEnv.exit = function()
        serverInfo.isREPLMode = false
    end
    local results = { xpcall(func, traceback) }
    debugEnv.exit = oldExit
    print = oldPrint
    if not results[1] then
        server:print(results[2])
    else
        server:print(table.unpack(results, 2))
    end
    serverInfo.incompleteStatement = ''
end

local function docmd(serverInfo, line, needWriteInput)
    local server = serverInfo.server
    print("[DebugPort] docmd:", line)
    if serverInfo.isREPLMode then
        local player = serverInfo.player
        if player and player:isValid() then
            print("[DebugPort] doPlayerCmd:", player.objID, player.name, line)
            player:doClientCmd(line, serverInfo.attachedSessionId, playerCmdRet, server)
            return
        end
        evaluateLuaStatement(serverInfo, line)
    else
        local i = line:find(" ")
        local key, value
        if i then
            key = line:sub(1, i - 1)
            value = line:sub(i + 1)
        else
            key = line
        end
        local player = serverInfo.player
        if player and player:isValid() then
            if key ~= "a" and key ~= "q" and key ~= "h" then
                print("[DebugPort] doPlayerCmd:", player.objID, player.name, line)
                player:doClientCmd(line, serverInfo.attachedSessionId, playerCmdRet, server)
                return
            end
        end
        local func = cmds[key]
        if func then
            debugEnv.curServer = server
            local ok, msg = xpcall(function()
                func(serverInfo, value)
            end, traceback)
            if not ok then
                server:print(msg)
            end
        elseif line ~= "" then
            server:writeline("unknown cmd: ", key)
        end
    end
    if needWriteInput then
        writeInput(serverInfo)
    end
end

local function dosub(tb, data)
    local code = data:byte(1)
    if code == 31 then
        -- Negotiate About Window Size
        local x1, x2 = data:byte(2, 3)
        tb.screenWidth = x1 * 256 + x2
        print("screenWidth", tb.screenWidth)
    else
        print("[DebugPort] unknown sub option:", code)
    end
end

local function _addr(addr)
    local i = assert(addr:find(":"), addr)
    return addr:sub(1, i - 1), tonumber(addr:sub(i + 1))
end

function M.Tick()
    remotedebug.Tick()
    if M.filewatch then
        local changed = false
        for _, h in ipairs(M.filewatch) do
            while misc.win_filewatch_next(h) do
                changed = true
            end
        end
        if changed then
            reload()
        end
    end
    if not M.listen then
        return
    end
    local sock, addr = ts.accept(M.listen)
    if sock then
        print("[DebugPort] client connected:", addr, sock)
        local server = ts.newserver(sock)
        local serverInfo = {
            server = server,
            addr = addr,
            buff = "",
            text = "",
            cursor = 1,
            history = nil,
            inputLen = 0,
            inputRow = 0,
            screenWidth = 999,
        }
        servers[server] = serverInfo
        server:setoption(1, false, true)    -- echo
        server:setoption(3, false, true)    -- SUPPRESS-GO-AHEAD
        server:setoption(31, true, true)    -- Telnet Window Size
        server:setoption(34, true, false)    -- Linemode
        --server:setoption(24, true, true)	-- Terminal-Type
        --server:rawwrite(string.char(255,250,24,1,255,240))
        server:start()
        if isClient then
            local player = PlayerManager:getClientPlayer()
            if player then
                server:writeline(string.format("[port:%d] Client of %s[%d]", M.port, tostring(player.userId), player.entityId))
            else
                server:writeline(string.format("[port:%d] Client without player", M.port))
            end
        else
            server:writeline(string.format("[port:%d] Server", M.port))
        end
        server:writeline("dir:", lfs.currentdir())
        server:writeline("game:", GameType, M.engineVersion)
        docmd(serverInfo, "help", true)
    end
    for server, tb in pairs(servers) do
        for _ = 1, 10 do
            -- server might be closed in the last loop
            if tb.server == nil then
                break
            end
            local data, running = readline(tb)
            if data == true then
                local text = tb.text
                if text ~= "" then
                    addHistory(text)
                end
                tb.cursor = #text + 1
                writeInput(tb)
                server:writeline()
                tb.text = ""
                tb.cursor = 1
                tb.inputLen = 0
                tb.inputRow = 0
                tb.history = nil
                docmd(tb, text, true)
            elseif data ~= nil then
                if type(data) == "string" then
                    dosub(tb, data)
                end
                writeInput(tb)
            elseif not running then
                print("[DebugPort] client closed:", tb.addr)
                DetachPlayer(tb)
                servers[server] = nil
                server:close()
                tb.server = nil
                break
            elseif not data then
                break
            end
        end
    end
    if not M.udp then
        return
    end
    local now = misc.now_microseconds()
    if now >= reportTime + 10 * 1000000 then
        ts.sendto(M.udp, "\0", REPORT_SERVER, 10086)
        reportTime = now
    end
    local buf, addr = ts.recvfrom(M.udp)
    if not buf then
        return
    end
    local packet = cjson.decode(buf)
    print("[DebugPort] udp cmd", addr)
    Lib.pv(packet)
    if packet.typ == "info" then
        ts.sendto(M.udp, cjson.encode(reportData), _addr(addr))
    elseif packet.typ == "debug" then
        local text = cjson.encode({ typ = "debug", port = remotedebug.Start() })
        ts.sendto(M.udp, text, _addr(addr))
    elseif packet.typ == "trans" then
        M.Transfer(packet.targetAddr, _addr(addr) .. ":" .. packet.serverPort)
    end
end

function M.Init(path, from, to)
    assert(not M.listen, "already inited!")
    historyPath = path
    to = to or from
    local listen = ts.create()
    for port = from, to do
        if ts.listen(listen, "127.0.0.1", port) then
            M.port = port
            print("[DebugPort] start listen:", port)
            break
        end
    end
    M.udp = ts.create(true)
    ts.noblock(M.udp, true)
    if not M.port then
        ts.close(listen)
        print("[DebugPort] start failed!", from, to)
        return false
    end
    ts.listen(M.udp, "0.0.0.0", M.port, true)
    ts.noblock(listen, true)
    M.listen = listen
    local engineVersion = EngineVersionSetting.getEngineVersion()
    M.engineVersion = engineVersion
    local isClient = isClient
    local data = misc.sys_info()
    if isClient and not Platform.isWindow() then

    end
    data.port = M.port
    data.dir = lfs.currentdir()
    data.game = GameType
    data.gamePort = M.gamePort
    data.client = isClient
    data.engineVersion = engineVersion
    if isClient then
        data.userId = CGame.Instance():getPlatformUserId()
    end
    ts.sendto(M.udp, misc.data_encode(data), REPORT_SERVER, 10086)
    reportData = data
    reportTime = misc.now_microseconds()

    local port = tonumber(os.getenv("DebugConnect"))
    if port then
        remotedebug.Connect(port)
    end

    return true
end

function M.Uninit()
    if M.listen then
        ts.close(M.listen)
        M.listen = nil
    end
    if M.udp then
        ts.close(M.udp)
        M.udp = nil
    end
end

function M.Transfer(addr1, addr2)
    local sock1 = ts.connect(_addr(addr1))
    local sock2 = ts.connect(_addr(addr2))
    print("begin transfer", addr1, "<=>", addr2)
    ts.transfer(sock1, sock2)
end

function M.Attach(sessionId)
    local fakeServer = { lines = {} }
    function fakeServer:writeline(...)
        local arg = table.pack(...)
        for i = 1, arg.n do
            arg[i] = tostring(arg[i]):gsub("\n", "\r\n")
        end
        self.lines[#self.lines + 1] = table.concat(arg, "\t") .. "\r\n"
    end
    function fakeServer:print(...)
        oldPrint("[DebugPort]", ...)
        self:writeline(...)
    end
    attachedSessions[sessionId] = {
        server = fakeServer,
        isREPLMode = false,
        isMultilineStatement = false,
        incompleteStatement = "",
    }
end

function M.Detach(sessionId)
    attachedSessions[sessionId] = nil
end

function M.DoCmd(sessionId, str)
    local session = attachedSessions[sessionId]
    local lines = {}
    session.server.lines = lines
    docmd(session, str, false)
    return table.concat(lines):sub(1, -3), session.isREPLMode, session.isMultilineStatement
end

function M.Reload(hasChangeImage)
    reload(hasChangeImage)
end

function M.AutoReload()
    if M.filewatch then
        for _, h in ipairs(M.filewatch) do
            misc.win_filewatch_stop(h)
        end
        M.filewatch = nil
        print("auto reload stoped.")
        return false
    end
    local dirs = {
        Root.Instance():getRootPath() .. "\\lua\\",
        Root.Instance():getMapPath() .. "\\",
    }
    M.filewatch = {}
    for i, dir in ipairs(dirs) do
        if dir:sub(2, 2) ~= ":" then
            dir = curDir .. "\\" .. dir
        end
        dir = dir:gsub("/", "\\"):gsub("\\%.\\", "\\"):gsub("\\\\", "\\")
        M.filewatch[i] = misc.win_filewatch_start(dir)
        print("auto reload start", dir)
    end
    return true
end

return M
