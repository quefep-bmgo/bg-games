GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
end

function GameListener.onGameReady()
    TextureAtlasRegister.Instance():addTextureAtlas("throwable.json", "")
end

return GameListener