---
--- Created by Jimmy.
--- DateTime: 2018/9/13 0028 11:37
---
local callbacks = T(Global, "BaseListener.callbacks")

GameType = Server.Instance():getConfig().gameType

local function tryCallEvent(event, ...)
    local callback = callbacks[event]
    if not callback then
        return false, false
    end
    local result = false
    for _, func in pairs(callback) do
        result = func(...) or result
    end
    return true, result
end

---@type SConnectorCenter
local SConnectorCenter = T(Global, "ConnectorCenter")

BaseListener = {}

local function IsWatch(userId)
    local manager = GameServer:getRoomManager()
    if not manager:isUserAttrExisted(userId) then
        return false
    end
    local attr = manager:getUserAttrInfo(userId)
    if attr.followEnterType == 2 then
        return true
    end
    return false
end

---@param player SBasePlayer
---@param follower SBasePlayer
local function setFollowModeAndTeleport(player, follower)
    LuaTimer:schedule(function()
        player:setAllowFlying(true)
        player:setFlying(true)
    end, 10)
    PacketSender:sendIntoFollowMode(player.rakssid, tostring(follower.userId))
    PacketSender:sendLuaCommonData(player.rakssid, "JoinGameStatus", tostring(PlayerManager:getJoinGameStatus()))
end

---@param player SBasePlayer
local function intoFollowMode(player, targetUserId)
    local targetPlayer = PlayerManager:getPlayerByUserId(targetUserId)
    if targetPlayer then
        player:addNightVisionPotionEffect(43200)
        player:teleportPos(targetPlayer:getPosition())
        Events.PlayerIntoFollowModeEvent:invoke(player, targetPlayer)
        setFollowModeAndTeleport(player, targetPlayer)
    end
end

function BaseListener.registerCallBack(event, func)
    callbacks[event] = callbacks[event] or {}
    if TableUtil.tableContain(callbacks[event], func) then
        return
    end
    table.insert(callbacks[event], func)
end

function BaseListener:init()
    CEvents.GameInitEvent:registerCallBack(self.onGameInit)
    CEvents.PlayerLoginEvent:registerCallBack(self.onPlayerLogin)
    CEvents.PlayerLogoutEvent:registerCallBack(self.onPlayerLogout)
    CEvents.PlayerReadyEvent:registerCallBack(self.onPlayerReady)
    CEvents.PlayerAttackedEvent:registerCallBack(self.onPlayerHurt)
    CEvents.PlayerFirstSpawnEvent:registerCallBack(self.onPlayerFirstSpawn)
    CEvents.PlayerRespawnEvent:registerCallBack(self.onPlayerRespawn)
    CEvents.PlayerReviewPlayerEvent:registerCallBack(self.onPlayerReviewPlayer)
    CEvents.PlayerDieEvent:registerCallBack(self.onPlayerDied)
    CEvents.PlayerDieTipEvent:registerCallBack(self.onPlayerDiedTip)
    CEvents.PlayerMoveEvent:registerCallBack(self.onPlayerMove)
    CEvents.PlayerAfterRespawnEvent:registerCallBack(self.onPlayerAfterRespawn)
    CEvents.ClientCommonDataEvent:registerCallBack(self.onClientCommonData)
    CEvents.SpawnEntityEvent:registerCallBack(self.onSpawnEntity)
    CEvents.RemoveEntityEvent:registerCallBack(self.onRemoveEntity)
    CEvents.PlayerReconnectSuccessEvent:registerCallBack(self.onPlayerReconnectSuccess)
    CEvents.SavePlayerDBDataEvent:registerCallBack(self.onSavePlayerDBData)
    CEvents.PlayerDynamicAttrEvent:registerCallBack(self.onPlayerDynamicAttr)
    CEvents.GameStatusChangeEvent:registerCallBack(self.onGameStatusChange)
    CEvents.ReceiveRoomCommonMsgEvent:registerCallBack(self.onReceiveRoomCommonMsg)
    CEvents.EnginePayMoneyEvent:registerCallBack(self.onEnginePayMoney)
    Events.GetDataFromDBEvent:registerCallBack(self.onGetDataFromDB)


    CEvents.RechargeResultEvent:registerCallBack(function(rakssid, type, result)
        if type ~= 1 then
            ---不是购买金魔方
            return
        end
        if result ~= 1 then
            ---购买不成功
            return
        end
        local player = PlayerManager:getPlayerByRakssid(rakssid)
        if not player then
            return
        end
        player:uploadTotalRecharge()
    end)
end

---@param GamePath string
---@param ver string
---@param serverWorld ServerWorld
---@param config RoomGameConfig
function BaseListener.onGameInit(GamePath, ver, serverWorld, config)
    HostApi.log(VarDump(ServerWorld))
    BaseMain:setIsChina(config.isChina)
    local mapPath = string.gsub(tostring(GamePath), "config.yml", "")
    --[[
        2021/3/31
        目前不支持服务器和客户端使用不同的配置文件，但是服务器和客户端允许有同名
        但不同逻辑的XXXXConfig.lua文件，也就是说服务器和客户端允许有不同的预处理逻
        辑。所以服务器和客户端可能需要使用不一样的离线预处理后的二进制配置文件。
        所以暂时禁用服务器使用二进制配置文件，地图的二进制配置文件是客户端专用的。
        目前只关注客户端的游戏启动速度，所以客户端能使用二进制配置文件就可以了
    ]]
    ConfigLoader.setBinaryEnabled(false)
    ConfigLoader.setMapPath(mapPath)
    FileUtil:setMapPath(mapPath)
    FileUtil:setRootPath("./")
    EngineWorld:setWorld(serverWorld)
    PacketSender:init()
    AppProps:init()
    WebService:init(ver, config)
    CommonTask:start()
    PlayerManager:setMaxPlayer(config.maxPlayers)
    PlayerManager:setRoomMaxPlayer(config.maxPlayers)
    PlayerManager:setWatchMode(config.watchMode)
    GMHelper:init()
    GameAnalytics:init()
    Global:loadSetting()
    Plugins.LoadAllPlugins()
    Plugins.CallPluginFunc("onGameInit")
    tryCallEvent(CEvents.GameInitEvent, FileUtil.getConfigFromYml("config"))
    WebService:GetExpRule()
    ServerLang:init()
    PlayerIdentityCache:init()
    SumRechargeConfig:init()
    MaxRecordHelper:init()
    require "engine_base.config.CommonActivityChestConfig"
    require "engine_base.config.CommonActivityConfig"
    require "engine_base.config.CommonActivityRewardConfig"
    require "engine_base.config.MustLotteryPriceConfig"
    require "engine_base.config.LuckyLotteryPrice"
    require "engine_base.config.LuckyValueConfig"
    require "engine_base.config.BlindBoxConfig"
    require "engine_base.config.BlindBoxRewardConfig"
    require "engine_server.config.GameDynamicConfig"
    require "engine_server.antihack.AntiHacker"

    if isLocalWin then
        startLuaHotUpdate()
    end
end

---@param clientPeer ClientPeer
---@param clientInfo string
---@param enableIndie number
---@param gameTimeToday number
function BaseListener.onPlayerLogin(clientPeer, clientInfo, enableIndie, gameTimeToday)
    ---玩家进入游戏前发送服务器配置
    local builder = DataBuilder.new()
    builder:addParam("isChina", BaseMain:isChina())
    builder:addParam("isStaging", GameServer:getServerConfig().isStaging)
    builder:addParam("regionId", GameServer:getServerConfig().regionId)
    builder:addParam("gameId", GameServer:getServerConfig().gameId)
    builder:addParam("serverOsTime", os.time())
    PacketSender:sendLuaCommonData(clientPeer:getRakssid(), "ServerInfo", builder:getData(), true)

    if IsWatch(clientPeer:getPlatformUserId()) then
        ---好友跟随进入观战模式
        local player = BasePlayer.new(clientPeer)
        PlayerManager:addWatcher(player)
        PacketSender:sendPlayerDBReady(player.rakssid)
        player:subHealth(player:getHealth() + 1)
        player:sendLoginResult(true, player.dynamicAttr.team, "",
                PlayerManager:getPlayerCount(), PlayerManager:getMaxPlayer())
        SConnectorCenter:onUserLogin(clientPeer:getPlatformUserId())
        return false
    end
    ---@type SBasePlayer
    local player = PlayerManager:getPlayerByUserId(clientPeer:getPlatformUserId())
    if player and not PlayerManager:isAIPlayer(player) then
        ---顶号登录，直接使用现有玩家，不重置玩家数据
        local entityPlayerMP = clientPeer:getEntityPlayer()
        local oldPlayerMP = player.entityPlayerMP
        if oldPlayerMP then
            local oldPosition = oldPlayerMP:getPosition()
            local oldYaw = oldPlayerMP:getYaw()
            entityPlayerMP:clonePlayer(player.entityPlayerMP, true)
            player:initStaticAttr(oldPlayerMP:getTeamId())
            LuaTimer:schedule(function()
                player:teleportPosWithYaw(oldPosition, oldYaw)
            end, 100)
        else
            player:initStaticAttr(player.dynamicAttr.team)
        end
        player.clientPeer = clientPeer
        player.entityPlayerMP = entityPlayerMP
        player.rakssid = clientPeer:getRakssid()
        player.isKickOut = false
        if player:checkReady() then
            ---顶号登录需要保存一次数据，否则会拉取到旧数据
            DBManager:callSavePlayerData(player)
        end
        return DBManager:onPlayerLogin(player)
    end
    ---------------正常登录流程---------------
    if PlayerManager:isPlayerFull() then
        HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGamePlayerIsEnough(), GameOverCode.PlayerIsEnough)
        return true
    end
    GameAnalyticsCache:addClientInfo(clientPeer:getPlatformUserId(), clientInfo)
    local code, status, c_callback, delayDBTime
    local callback = callbacks[CEvents.PlayerLoginEvent]
    if callback == nil then
        code = GameOverCode.Success
        player = BasePlayer.new(clientPeer)
        player:initStaticAttr(player.dynamicAttr.team)
    else
        code, player, status, c_callback, delayDBTime = callback[1](clientPeer)
        if code == GameOverCode.GameStarted then
            HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGameHasStarting(), GameOverCode.GameStarted)
            return true
        end
        if code == GameOverCode.GameEnd then
            HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGameEnd(), GameOverCode.GameEnd)
            return true
        end
        if code ~= GameOverCode.Success then
            HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGameOver(), GameOverCode.GameOver)
            return true
        end
        if player == nil then
            code = GameOverCode.Success
            player = BasePlayer.new(clientPeer)
            player:initStaticAttr(player.dynamicAttr.team)
        end
    end
    SConnectorCenter:onUserLogin(clientPeer:getPlatformUserId())
    PlayerManager:addPlayer(player)
    if BaseMain:isChina() and Platform.isLinux() then
        player.gameTimeToday = gameTimeToday or 0
    else
        player.gameTimeToday = -1
    end
    player.enableIndie = enableIndie or false
    if PlayerManager:isPlayerFull() then
        HostApi.sendStartGame(PlayerManager:getPlayerCount())
    end
    if status ~= nil and status >= 1 and status <= 2 then
        HostApi.sendGameStatus(clientPeer:getRakssid(), status)
    end
    if c_callback ~= nil then
        c_callback()
    end
    Plugins.CallPluginFunc("onPlayerLogin", player)
    if delayDBTime and delayDBTime > 0 then
        LuaTimer:schedule(function()
            player = PlayerManager:getPlayerByUserId(player.userId)
            if not player then
                return
            end
            if DBManager:onPlayerLogin(player) then
                PacketSender:sendPlayerDBReady(player.rakssid)
            end
        end, delayDBTime)
        return false
    else
        return DBManager:onPlayerLogin(player)
    end
end

function BaseListener.onPlayerLogout(rakssid)
    local watcher = PlayerManager:getWatcherByRakssid(rakssid)
    if watcher then
        SConnectorCenter:onUserOut(watcher.userId)
        PlayerManager:subWatcher(watcher)
        GMHelper:onPlayerLogout(watcher)
        return true
    end

    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return false
    end
    GMHelper:onPlayerLogout(player)
    SConnectorCenter:onUserOut(player.userId)
    GameGroupManager:removeUser(player.userId)
    SumRechargeHelper:onPlayerLogout(player.userId)
    CommonActivity:onPlayerLogout(player)
    PlayerManager:subPlayer(player)
    local clear = function()
        ---玩家正常退出游戏后，保存一次数据
        if not player.isKickOut then
            DBManager:callSavePlayerData(player)
        end
        Plugins.CallPluginFunc("onPlayerLogout", player)
        player:onPlayerLogout()
        if DBManager:isAutoCache() then
            DBManager:removeCache(player.userId)
        end
        RewardManager:removeRewardCache(player.userId)
        GameAnalyticsCache:removeCache(player.userId)
        MaxRecordHelper:onPlayerLogout(player.userId)
        SumRechargeHelper:removeCache(player)
    end
    tryCallEvent(CEvents.PlayerLogoutEvent, player)
    clear()
    return true
end

function BaseListener.onPlayerReady(rakssid)
    local player = PlayerManager:getWatcherByRakssid(rakssid)
    if player then
        SConnectorCenter:onUserIn(player.userId)
        PacketSender:sendDataReport(rakssid, "follow_watch", GameType)
        intoFollowMode(player, player.dynamicAttr.targetUserId)
        return
    end
    player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        HostApi.sendGameover(rakssid, IMessages:msgGameOver(), GameOverCode.ReadyNoPlayer)
        return
    end
    SConnectorCenter:onUserIn(player.userId)
    local callback = callbacks[CEvents.PlayerReadyEvent]
    if not callback then
        return
    end
    player.isReady = true
    Plugins.CallPluginFunc("onPlayerReady", player)
    local _, time = tryCallEvent(CEvents.PlayerReadyEvent, player)
    DBManager:onPlayerReady(player)
    SumRechargeHelper:onPlayerReady(player)
    ExchangeHelper:onPlayerReady(player)
    GMHelper:onPlayerReady(player)
    player:uploadTotalRecharge()
    if type(time) == "number" and time > 0 then
        player:addNightVisionPotionEffect(time)
    end
    if player.dynamicAttr.followEnterType == 1 then
        PacketSender:sendDataReport(rakssid, "follow_game", GameType)
    end
    CommonActivity:onPlayerReady(player)
end

---@param clientPeer ClientPeer
function BaseListener.onPlayerFirstSpawn(clientPeer)
    local player = PlayerManager:getPlayerByRakssid(clientPeer:getRakssid())
    if player == nil then
        return
    end
    PlayerIdentityCache:onPlayerSpawn(player)
    tryCallEvent(CEvents.PlayerFirstSpawnEvent)
end

---@param playerMP EntityPlayerMP
function BaseListener.onPlayerAfterRespawn(playerMP)
    local player = PlayerManager:getPlayerByUserId(playerMP:getPlatformUserId())
    if player == nil then
        return
    end
    tryCallEvent(CEvents.PlayerAfterRespawnEvent, player)
end

---@param playerMP EntityPlayerMP
function BaseListener.onPlayerRespawn(playerMP)
    local player = PlayerManager:getPlayerByUserId(playerMP:getPlatformUserId())
    if player == nil then
        return
    end
    PlayerIdentityCache:onPlayerSpawn(player)
    if player.clientPeer then
        player:respawn(player.clientPeer)
    end
    local _, time = tryCallEvent(CEvents.PlayerRespawnEvent, player)
    if type(time) == "number" and time > 0 then
        player:addNightVisionPotionEffect(time)
    end
end

function BaseListener.onPlayerReviewPlayer(selfId, targetId)
    local player = PlayerManager:getPlayerByRakssid(selfId)
    if not player then
        return
    end
    player:setShowName(player:buildShowName(), targetId)
end

function BaseListener.onGetDataFromDB(userId, subKey, data)
    local callback = callbacks[Events.GetDataFromDBEvent]
    if not callback then
        return
    end
    local player = PlayerManager:getPlayerByUserId(userId)
    if player ~= nil then
        if DBManager:isAutoCache() then
            DBManager:addCache(userId, subKey, data)
        end
        tryCallEvent(Events.GetDataFromDBEvent, player, subKey, data)
    end
end

function BaseListener.onClientCommonData(userId, key, data)
    CommonDataEvents:dispatchEvent(userId, key, data)
end

---@param entity Entity
function BaseListener.onSpawnEntity(entity, type, properties)
    if not EngineWorld:getWorld() then
        return
    end
    tryCallEvent(CEvents.SpawnEntityEvent, EntityCache:createEntityCache(entity, type, properties))
end

function BaseListener.onRemoveEntity(entityId)
    EntityCache:removeEntityCache(entityId)
end

---@param hurtPlayer EntityPlayerMP
---@param hurtFrom EntityPlayerMP
function BaseListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---攻击者如果是 观战者拦截攻击
    if hurtFrom and PlayerManager:getWatcherByUserId(hurtFrom:getPlatformUserId()) then
        return false
    end
    local register, result = tryCallEvent(CEvents.PlayerAttackedEvent, hurtPlayer, hurtFrom, damageType, hurtValue)
    if not register then
        return true
    end
    return result
end

---@param diePlayer EntityPlayerMP
---@param killPlayer EntityPlayerMP
function BaseListener.onPlayerDied(diePlayer, isKillByPlayer, killPlayer)
    ---死亡者如果是 观战者必须死
    if diePlayer and PlayerManager:getWatcherByUserId(diePlayer:getPlatformUserId()) then
        return true
    end
    local register, result = tryCallEvent(CEvents.PlayerDieEvent, diePlayer, isKillByPlayer, killPlayer)
    if not register then
        return true
    end
    return result
end

---@param diePlayer EntityPlayerMP
---@param killPlayer EntityPlayerMP
function BaseListener.onPlayerDiedTip(diePlayer, killPlayer)
    ---死亡者如果是 观战者 不提示
    if diePlayer and PlayerManager:getWatcherByUserId(diePlayer:getPlatformUserId()) then
        return false
    end
    local register, result = tryCallEvent(CEvents.PlayerDieTipEvent, diePlayer, killPlayer)
    if not register then
        return true
    end
    return result
end

---@param playerMp EntityPlayerMP
function BaseListener.onPlayerMove(playerMp, x, y, z)
    ---移动者如果是 观战者 默认允许移动
    if playerMp and PlayerManager:getWatcherByUserId(playerMp:getPlatformUserId()) then
        return true
    end
    if x == 0 and y == 0 and z == 0 then
        return true
    end
    local register, result = tryCallEvent(CEvents.PlayerMoveEvent, playerMp, x, y, z)
    if not register then
        return true
    end
    return result
end

function BaseListener.onPlayerReconnectSuccess(clientPeer)

end

function BaseListener.onSavePlayerDBData(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player ~= nil then
        ---玩家被踢退出游戏，保存一次数据
        player.isKickOut = true
        DBManager:callSavePlayerData(player)
    end
end

---@param attr UserAttrInfo
function BaseListener.onPlayerDynamicAttr(attr)
    local userId = attr.userId
    if not Platform.isWindow() and not ServerHelper.getBoolPrefs("DisableRoomUserManager") then
        if Server.Instance():getEnableRoom() then
            LuaTimer:schedule(function(requestId)
                local player = PlayerManager:getPlayerByUserId(userId)
                local watcher = PlayerManager:getWatcherByUserId(userId)
                if not player and not watcher then
                    GameServer:getRoomManager():sendUserOut(userId, requestId)
                end
            end, 90000, nil, attr.requestId)
        end
    end
    if attr.followEnterType == 2 then
        return
    end
    tryCallEvent(CEvents.PlayerDynamicAttrEvent, attr)
end

function BaseListener.onGameStatusChange(status)
    PlayerManager:onGameStatusChange(status)
end

function BaseListener.onReceiveRoomCommonMsg(content)
    local ok, result = pcall(json.decode, content)
    if not ok then
        return
    end
    tryCallEvent(CEvents.ReceiveRoomCommonMsgEvent, result)
end

function BaseListener.onEnginePayMoney(userId, uniqueId, currencyType, price, reason, sessionId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    PayHelper.payMoneySync(player, uniqueId, currencyType, price, function()
        HttpRequest.onPayResult(sessionId, userId, true)
    end, function()
        HttpRequest.onPayResult(sessionId, userId, false)
    end, nil, reason, 1)
end

return BaseListener