---@class TriggerGiftTriggerListConfig
local TriggerGiftTriggerListConfig = T(Global, "TriggerGiftTriggerListConfig")
---@type TriggerGiftTriggerListData[]
local Settings = {}

function TriggerGiftTriggerListConfig:init()
    local config = FileUtil.getConfigFromCsv("common/TriggerGiftTriggerList.csv", 2, true, true)
    for _, item in pairs(config) do
        ---@class TriggerGiftTriggerListData
        local data = {
            index = item.index,
            triggerId = item.triggerId,
            trigger = tonumber(item.trigger),
            param = tonumber(item.param),
            param2 = tonumber(item.param2 or 0),
            param3 = tonumber(item.param3 or 0),
            tailNumber = StringUtil.split(item.tailNumber, "-"),
            rechargePoints = tonumber(item.rechargePoints),
            isRepeatable = item.isRepeatable == "1" or false,
            cd = tonumber(item.cd),
            giftGroupId = item.giftGroupId
        }
        Settings[data.triggerId] = data
    end
end

function TriggerGiftTriggerListConfig:getAllCfg()
    return Settings
end

---@return TriggerGiftTriggerListData
function TriggerGiftTriggerListConfig:getCfgById(triggerId)
    return Settings[triggerId]
end

TriggerGiftTriggerListConfig:init()

return TriggerGiftTriggerListConfig
