---@class UILimitTimeSignalEntryLayout : IGUILayout
local UILimitTimeSignalEntryLayout = class("UILimitTimeSignalEntryLayout", IGUILayout)

---@private
function UILimitTimeSignalEntryLayout:ctor(parent)
	self.super.ctor(self, "LimitTimeSignalEntry.json", GUIManager:getMainControl())
end

---@private
function UILimitTimeSignalEntryLayout:isDelayLoad()
	return true
end

---@private
function UILimitTimeSignalEntryLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UILimitTimeSignalEntryLayout:initCreateEvent()

end

---@private
function UILimitTimeSignalEntryLayout:onLoad()
	self.btnBtn = self:getChildWindow("LimitTimeSignalEntry-Btn", GUIType.Button)
	self.stName = self:getChildWindow("LimitTimeSignalEntry-name", GUIType.StaticText)
	self.siRedDot = self:getChildWindow("LimitTimeSignalEntry-RedDot", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function UILimitTimeSignalEntryLayout:initView()
	self.stName:SetText(Lang:getString(Lang:getString("gui.limit.time.combined.title")))
end

---@private
function UILimitTimeSignalEntryLayout:initEvent()
	self.btnBtn:registerEvent(GUIEvent.ButtonClick, function()
		local activity=PlayerManager:getClientPlayer().payActivity.activities[self.activityId]
		if activity then
			activity:tryShowActivityUI()
			if self.siRedDot then
				self.siRedDot:SetVisible(false)
			end
		end
	end)

	self:registerEvent(Events.PayActivityGiftSignalRecord,function ()
		local activity=PlayerManager:getClientPlayer().payActivity.activities[self.activityId]
		if activity then
			local hasAllBought=activity:hasBoughtAll()
			print("-0-------------------------  activity:hasBoughtAll()",hasAllBought)
			if hasAllBought then
				self:hide()
			end
		end
	end)
end

function UILimitTimeSignalEntryLayout:onShow(activityId)
	self.activityId=activityId
end


return UILimitTimeSignalEntryLayout
