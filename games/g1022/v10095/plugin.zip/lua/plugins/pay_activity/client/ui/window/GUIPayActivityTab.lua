---@class GUIPayActivityTabWindow : IGUIWindow
local GUIPayActivityTabWindow = class("GUIPayActivityTabWindow", IGUIWindow)

---@private
function GUIPayActivityTabWindow:ctor(...)
    self.super.ctor(self, "PayActivityTab.json", ...)
end

---@private
function GUIPayActivityTabWindow:onLoad()
    self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.stName = self:getChildWindowByName("PayActivityTab-Name", GUIType.StaticText)
    self.llSelected = self:getChildWindowByName("PayActivityTab-Selected", GUIType.Layout)
    self.siRed = self:getChildWindowByName("PayActivityTab-Red", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIPayActivityTabWindow:initView()
    ---@type UIPayActivityLayout
    self.parent = UIHelper.newGameGUILayout("GUIPayActivity")
    self.siRed:SetVisible(false)
end

---@private
function GUIPayActivityTabWindow:initEvent()
    self.llRoot:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self.parent:setCurSelectActivity(self.activity)
    end)
    self:registerEvent(Events.PayActivityTabRedEvent, function(activity, isShow)
        if self.activity ~= activity then
            return
        end
        self.siRed:SetVisible(isShow)
    end)
end

---@param activity IPayActivity
function GUIPayActivityTabWindow:onDataChanged(activity)
    self.activity = activity
    self.stName:SetText(Lang:getString(activity.cfg.tabName))
    self.llRoot:SetBackImage(activity.cfg.tabImage)
    self.llSelected:SetVisible(activity == self.parent.curSelectActivity)
end

return GUIPayActivityTabWindow
