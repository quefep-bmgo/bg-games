---@class UISkyRoyaleMainLayout : IGUILayout
local UISkyRoyaleMainLayout = class("UIMain", IGUILayout)

---@private
function UISkyRoyaleMainLayout:ctor()
    self.super.ctor(self, "SkyRoyaleMain.json", GUIManager:getMainControl())
end

function UISkyRoyaleMainLayout:onLoad()
    self.btnSubscription = self:getChildWindow("SkyRoyaleMain-Subscription", GUIType.Button)
    if Game:isEnableIndie() then
        self.btnSubscription:SetVisible(false)
    end
    self:initEvent()
end

function UISkyRoyaleMainLayout:initEvent()
    self.btnSubscription:registerEvent(GUIEvent.ButtonClick, function()
        UIHelper.showGameGUILayout("GUISubscriptionVip")
    end)
end

return UISkyRoyaleMainLayout