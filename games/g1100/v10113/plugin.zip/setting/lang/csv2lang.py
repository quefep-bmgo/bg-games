#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import importlib
import time

importlib.reload(sys)


def csv2lang():
    csv_file = open(os.path.join(os.getcwd(), "lang.csv"), "r", encoding='utf-8')
    result = {}
    lang_list = csv_file.readline().replace('\n', '').replace('\t\n', '').split('\t')
    del lang_list[0]
    for lang in lang_list:
        result[lang] = ''

    csv_file.readline()
    line = csv_file.readline()
    while line:
        words = line.replace('\n', '').split('\t')
        index = 1
        for lang in lang_list:
            if len(words[index]) > 0:
                result[lang] = result[lang] + words[0] + "=" + words[index] + '\n'
            index = index + 1
        line = csv_file.readline()

    for lang in lang_list:
        if len(lang) > 0:
            print('output file:\t' + lang + ".lang")
            time.sleep(0.05)
            lang_file = open(os.path.join(os.getcwd(), lang + ".lang"), "w", encoding='utf-8')
            lang_file.write(result[lang])
            lang_file.close()


csv2lang()
