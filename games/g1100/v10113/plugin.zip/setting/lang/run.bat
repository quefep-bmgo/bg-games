@echo off
setlocal

:input_loop
echo 1-csv2lang
echo 2-lang2csv
echo q-exit
set "choice="
set /p "choice=please input 1/2/q: "

if /I "%choice%"=="1" (
    python csv2lang.py
    set /p "_dummy=done, input anything to continue: "
    goto :end
)

if /I "%choice%"=="2" (
    python lang2csv.py
    set /p "_dummy=done, input anything to continue: "
    goto :end
)

if /I "%choice%"=="q" (
    goto :end
)

echo invalid input, please try again.
goto :input_loop

:end
endlocal
