#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import importlib

importlib.reload(sys)


def lang2csv():
    result = {}
    lang_list = ['zh', 'en', 'pt', 'ru', 'th', 'de', 'ja', 'ko', 'es', 'in', 'vi', 'fr', 'it', 'tr', 'pl']
    lang_name = ['汉语', '英语', '葡萄牙语', '俄语', '泰语', '德语', '日语', '韩语', '西班牙语', '印尼语', '越南语', '法语', '意大利语', '土耳其', '波兰语']

    for root, dirs, files in os.walk(os.getcwd()):
        for file in files:
            if file.find('.lang') >= 0:
                lang_file = open(os.path.join(root, file), "r", encoding='utf-8')
                line = lang_file.readline()
                lang = file.replace('.lang', '')
                while line:
                    line = line.strip()
                    wolds = line.split('=')
                    if len(wolds) >= 2:
                        if wolds[0] not in result.keys():
                            result[wolds[0]] = {}
                        text = line.replace(wolds[0], '')
                        text = text[1:len(text)]
                        result[wolds[0]][lang] = text
                    line = lang_file.readline()
                lang_file.close()

    csv_file = open(os.path.join(os.getcwd(), "lang.csv"), "w", encoding='utf-8')
    content = "T(语言表)" + '\t'
    for lang in lang_list:
        content = content + lang + '\t'
    content = content + '\n'
    content = content + "K(键名)" + '\t'
    for name in lang_name:
        content = content + name + '\t'
    content = content + '\n'
    for key in result.keys():
        content = content + key + '\t'
        for lang in lang_list:
            if lang in result[key].keys():
                content = content + result[key][lang] + '\t'
            else:
                content = content + '\t'
        content = content + '\n'

    csv_file.write(content)
    csv_file.close()


lang2csv()
