
PlayerListener = {}

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)

    Listener.registerCallBack(UpdateRankKeyEvent, self.onUpdateRankKey)

    self.timerKey = LuaTimer:scheduleTimer(self.checkPlayersMove, 100)

end

function PlayerListener.checkPlayersMove()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        local pos = player:getPosition()
        AreaManager:onPlayerMove(player, pos.x, pos.y, pos.z)
    end
end

function PlayerListener.onPlayerLogout(player)
    AreaManager:onPlayerMove(player, 0, 99999, 0)
end

function PlayerListener.onUpdateRankKey(key)
    RankConfig:updateKey(tonumber(key))
end