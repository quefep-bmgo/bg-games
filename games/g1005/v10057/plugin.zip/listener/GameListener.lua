--region *.lua
require "web.ClanWarWeb"
require "config.TeamConfig"
require "messages.Messages"

GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(GameInitEvent, GameListener.onGameInit)
end

function GameListener.onGameInit(initPos, config)
    GameConfig:init(config)
    GameMatch:initMatch()
    initPos.x = GameMatch.Teams[1].initPos.x
    initPos.y = GameMatch.Teams[1].initPos.y
    initPos.z = GameMatch.Teams[1].initPos.z
    EngineWorld:stopWorldTime()
    ClanWarWeb:init(ver, config.rankAddr, config.rewardAddr, config.propAddr, config.gameId)
end

return GameListener
--endregion
