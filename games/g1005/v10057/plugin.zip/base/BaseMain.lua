---
--- Created by Jimmy.
--- DateTime: 2018/10/9 0009 15:02
---
require "base.define.BlockID"
require "base.define.ItemID"
require "base.define.PotionID"
require "base.define.PotionItemID"
require "base.define.ScoreID"
require "base.define.EntityDefine"
require "base.util.class"
require "base.util.CsvUtil"
require "base.util.DateUtil"
require "base.util.DynamicCast"
require "base.util.EngineUtil"
require "base.util.InventoryUtil"
require "base.util.json"
require "base.util.MerchantUtil"
require "base.util.MsgSender"
require "base.util.NumberUtil"
require "base.util.StringUtil"
require "base.util.tinyyaml"
require "base.util.vardump"
require "base.util.VectorUtil"
require "base.util.WalletUtils"
require "base.util.TableUtil"
require "base.util.FileUtil"
require "base.util.BaseUtil"
require "base.util.PointUtil"
require "base.util.MathUtil"
require "base.util.BigNum"
require "base.util.RectUtil"
require "base.util.LogUtil"
inspect = require "base.util.inspect"
require "base.event.CommonDataEvents"
require "base.event.EventObservable"
require "base.event.IScriptEvent"
require "base.event.GameEvents"
require "base.analytics.GameAnalytics"
require "base.analytics.GameAnalyticsCache"
require "base.cache.UserInfoCache"
require "base.classes.PlayerClassInfo"
require "base.code.GameOverCode"
require "base.code.MailType"
require "base.entity.IEntity"
require "base.entity.EntityCache"
require "base.data.IArea"
require "base.data.BasePlayer"
require "base.data.EngineWorld"
require "base.exp.ExpRule"
require "base.exp.UserExpManager"
require "base.listener.HttpListener"
require "base.listener.BaseListener"
require "base.messages.IMessages"
require "base.messages.TextFormat"
require "base.packet.PacketSender"
require "base.packet.DataBuilder"
require "base.pay.PayHelper"
require "base.pay.OrderManager"
require "base.prop.AppProps"
require "base.rank.RankManager"
require "base.season.SeasonManager"
require "base.task.ITask"
require "base.task.CommonTask"
require "base.task.LuaTimer"
require "base.web.WebRequestType"
require "base.web.WebService"
require "base.web.WebResponse"
require "base.DBManager"
require "base.GameServer"
require "base.PlayerManager"
require "base.ReportManager"
require "base.RewardManager"

HttpListener:init()
BaseListener:init()

BaseMain = {}
BaseMain.GameType = "g1001"
BaseMain.IsChina = false

function BaseMain:setGameType(GameType)
    self.GameType = GameType
    DBManager:setGameType(self.GameType)
    ReportManager:setGameType(self.GameType)
    RewardManager:setGameType(self.GameType)
    HostApi.setServerGameType(GameType)
end

function BaseMain:getGameType()
    return self.GameType
end

function BaseMain:setIsChina(isChina)
    self.IsChina = isChina
end

function BaseMain:isChina()
    return self.IsChina
end

local DataProcessor = require "base.packet.processor.DataBuilderProcessor"
DataBuilderProcessor = DataProcessor.new()
local JsonProcessor = require "base.packet.processor.JsonDataProcessor"
JsonBuilderProcessor = JsonProcessor.new()

return BaseMain