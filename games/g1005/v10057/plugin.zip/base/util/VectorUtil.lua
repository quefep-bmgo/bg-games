---
--- Created by Jimmy.
--- DateTime: 2017/10/19 0019 10:38
---

VectorUtil = {}

function VectorUtil.newVector3i(x, y, z)
    local vec = Vector3i.new()
    vec.x = tonumber(x)
    vec.y = tonumber(y)
    vec.z = tonumber(z)
    return vec
end

function VectorUtil.newVector3(x, y, z)
    local vec3 = Vector3.new()
    vec3.x = tonumber(x)
    vec3.y = tonumber(y)
    vec3.z = tonumber(z)
    return vec3
end

function VectorUtil.toVector3(vec3i)
    local vec3 = Vector3.new()
    vec3.x = vec3i.x
    vec3.y = vec3i.y
    vec3.z = vec3i.z
    return vec3
end

function VectorUtil.toVector3i(vec3)
    local vec3i = Vector3i.new()
    vec3i.x = vec3.x
    vec3i.y = vec3.y
    vec3i.z = vec3.z
    return vec3i
end

function VectorUtil.hashVector3(vec3)
    return vec3.x .. ":" .. vec3.y .. ":" .. vec3.z
end

function VectorUtil.toBlockVector3(x, y, z)
    if x < 0 then
        x = x - 1
    end
    if y < 0 then
        y = y - 1
    end
    if z < 0 then
        z = z - 1
    end
    return VectorUtil.newVector3i(x, y, z)
end

function VectorUtil.equal(vec3_1, vec3_2)
    if vec3_1 and vec3_2 then
        return vec3_1.x == vec3_2.x and vec3_1.y == vec3_2.y and vec3_1.z == vec3_2.z
    else
        return false
    end
end

function VectorUtil.add3(vec3_1, vec3_2)
    return VectorUtil.newVector3(vec3_1.x + vec3_2.x, vec3_1.y + vec3_2.y, vec3_1.z + vec3_2.z)
end

function VectorUtil.add3i(vec3_1, vec3_2)
    return VectorUtil.newVector3i(vec3_1.x + vec3_2.x, vec3_1.y + vec3_2.y, vec3_1.z + vec3_2.z)
end

function VectorUtil.sub3(vec3_1, vec3_2)
    return VectorUtil.newVector3(vec3_1.x - vec3_2.x, vec3_1.y - vec3_2.y, vec3_1.z - vec3_2.z)
end

function VectorUtil.sub3i(vec3_1, vec3_2)
    return VectorUtil.newVector3i(vec3_1.x - vec3_2.x, vec3_1.y - vec3_2.y, vec3_1.z - vec3_2.z)
end

function VectorUtil.getPosX(vec3i, size)
    size = size or 1
    return VectorUtil.newVector3i(vec3i.x + size, vec3i.y, vec3i.z)
end

function VectorUtil.getNegX(vec3i, size)
    size = size or 1
    return VectorUtil.newVector3i(vec3i.x - size, vec3i.y, vec3i.z)
end

function VectorUtil.getPosY(vec3i, size)
    size = size or 1
    return VectorUtil.newVector3i(vec3i.x, vec3i.y + size, vec3i.z)
end

function VectorUtil.getNegY(vec3i, size)
    size = size or 1
    return VectorUtil.newVector3i(vec3i.x, vec3i.y - size, vec3i.z)
end

function VectorUtil.getPosZ(vec3i, size)
    size = size or 1
    return VectorUtil.newVector3i(vec3i.x, vec3i.y, vec3i.z + size)
end

function VectorUtil.getNegZ(vec3i, size)
    size = size or 1
    return VectorUtil.newVector3i(vec3i.x, vec3i.y, vec3i.z - size)
end

VectorUtil.ZERO = VectorUtil.newVector3(0, 0, 0)
VectorUtil.ONE = VectorUtil.newVector3(1, 1, 1)
VectorUtil.UNIT_X = VectorUtil.newVector3(1, 0, 0)
VectorUtil.UNIT_Y = VectorUtil.newVector3(0, 1, 0)
VectorUtil.UNIT_Z = VectorUtil.newVector3(0, 0, 1)
VectorUtil.NEG_UNIT_X = VectorUtil.newVector3(-1, 0, 0)
VectorUtil.NEG_UNIT_Y = VectorUtil.newVector3(0, -1, 0)
VectorUtil.NEG_UNIT_Z = VectorUtil.newVector3(0, 0, -1)

return VectorUtil