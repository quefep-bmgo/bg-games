---
--- Created by Jimmy.
--- DateTime: 2018/6/28 0028 11:37
---
HttpListener = {}

function HttpListener:init()
    HttpResponseEvent.registerCallBack(self.onHttpResponse)
end

function HttpListener.onHttpResponse(result, marked)
    -- BLOCKYMODS --
    if string.find(marked, WebRequestType.BLOCKYMODS_USER_ATTR) ~= nil then
        WebResponse:onGetUserAttr(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_REWARD) ~= nil then
        WebResponse:onGetReward(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_GOLD_REWARD) ~= nil then
        WebResponse:onGetGoldReward(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_REPORT) ~= nil then
        WebResponse:onReportData(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_USER_INFOS) ~= nil then
        WebResponse:onGetUserInfos(result, marked)
        return
    end
    if marked == WebRequestType.BLOCKYMODS_REWARD_LIST then
        WebResponse:onGetRewardList(result, marked)
        return
    end
    if marked == WebRequestType.BLOCKYMODS_REPORT_LIST then
        WebResponse:onReportList(result, marked)
        return
    end
    if marked == WebRequestType.BLOCKYMODS_EXP_RULE then
        WebResponse:onGetExpRole(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_USER_EXP) ~= nil then
        WebResponse:onGetExp(result, marked)
        return
    end
    if marked == WebRequestType.BLOCKYMODS_SAVE_EXP then
        WebResponse:onSaveExp(result, marked)
        return
    end
    if marked == WebRequestType.BLOCKYMODS_SAVE_HONOR then
        WebResponse:onSaveHonor(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_USER_SEASON_INFO) ~= nil then
        WebResponse:onGetUserSeasonInfo(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_USER_SEASON_REWARD) ~= nil then
        WebResponse:onUpdateUserSeasonReward(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_USER_HAS_RECHARGE) ~= nil then
        WebResponse:onUserHasRecharge(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_USER_PROPS) ~= nil then
        WebResponse:onGetUserProps(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_CONSUME_USER_PROPS) ~= nil then
        WebResponse:onConsumeUserProps(result, marked)
        return
    end
    if string.find(marked, WebRequestType.BLOCKYMODS_PAY_ORDER) ~= nil then
        WebResponse:onGetUserPayOrder(result, marked)
        return
    end

    -- game api --
    if string.find(marked, WebRequestType.CHECK_MAILS) ~= nil then
        WebResponse:onCheckMails(result, marked)
        return
    end
    if string.find(marked, WebRequestType.SEND_MAILS) ~= nil then
        WebResponse:onSendMails(result, marked)
        return
    end
    if string.find(marked, WebRequestType.UPDATE_MAILS) ~= nil then
        WebResponse:onUpdateMails(result, marked)
        return
    end
    if string.find(marked, WebRequestType.GET_THUMB_UP_RECORD) ~= nil then
        WebResponse:onGetThumbUpRecord(result, marked)
        return
    end

    -- game data api --
    if string.find(marked, WebRequestType.USER_GAME_DATA) ~= nil then
        WebResponse:onGetGameData(result, marked)
        return
    end
    if string.find(marked, WebRequestType.SAVE_GAME_DATA) ~= nil then
        WebResponse:onSaveGameData(result, marked)
        return
    end

    -- game api --
    if string.find(marked, WebRequestType.APP_RANK_USER) ~= nil then
        WebResponse:onGetUserAppRank(result, marked)
        return
    end

    if string.find(marked, WebRequestType.APP_RANK_ALL) ~= nil then
        WebResponse:onGetAllAppRank(result, marked)
        return
    end
end

return HttpListener