---
--- Created by Jimmy.
--- DateTime: 2018/6/28 0028 11:42
---
WebRequestType = {}

WebRequestType.BLOCKYMODS_USER_ATTR = "blockymods.user.attr:"
WebRequestType.BLOCKYMODS_REWARD = "blockymods.user.reward:"
WebRequestType.BLOCKYMODS_GOLD_REWARD = "blockymods.user.gold.reward:"
WebRequestType.BLOCKYMODS_REPORT = "blockymods.user.report:"
WebRequestType.BLOCKYMODS_USER_INFOS = "blockymods.user.infos:"
WebRequestType.BLOCKYMODS_REWARD_LIST = "blockymods.reward.list"
WebRequestType.BLOCKYMODS_REPORT_LIST = "blockymods.report.list"
WebRequestType.BLOCKYMODS_EXP_RULE = "blockymods.exp.rule"
WebRequestType.BLOCKYMODS_USER_EXP = "blockymods.user.exp:"
WebRequestType.BLOCKYMODS_SAVE_EXP = "blockymods.save.exp"
WebRequestType.BLOCKYMODS_SAVE_HONOR = "blockymods.save.honor"
WebRequestType.BLOCKYMODS_USER_SEASON_INFO = "blockymods.user.season.info:"
WebRequestType.BLOCKYMODS_USER_SEASON_REWARD = "blockymods.user.season.reward:"
WebRequestType.BLOCKYMODS_USER_HAS_RECHARGE = "blockymods.user.has.recharge:"
WebRequestType.BLOCKYMODS_USER_PROPS = "blockymods.user.props:"
WebRequestType.BLOCKYMODS_CONSUME_USER_PROPS = "blockymods.consume.user.props:"
WebRequestType.BLOCKYMODS_PAY_ORDER = "blockymods.pay.order:"

-- game api ---
WebRequestType.CHECK_MAILS = "blockymods.checkMails:"
WebRequestType.SEND_MAILS = "blockymods.sendMails:"
WebRequestType.UPDATE_MAILS = "blockymods.updateMails:"
WebRequestType.SEND_MSG = "blockymods.sendMsg:"

WebRequestType.SEND_THUMB_UP_RECORD = "blockymods.sendThumbUpRecord"
WebRequestType.GET_THUMB_UP_RECORD = "blockymods.loadThumbUpRecord"
WebRequestType.DELETE_THUMB_UP_RECORD = "blockymods.deleteThumbUpRecord"

-- email status --
WebRequestType.EMAIL_STATUS_UNREAD = "UNREAD"
WebRequestType.EMAIL_STATUS_READ = "READ"
WebRequestType.EMAIL_STATUS_RECEIVED = "RECEIVED"
WebRequestType.EMAIL_STATUS_DELETED = "DELETED"

-- game data api --
WebRequestType.USER_GAME_DATA = "blockymods.user.game.data:"
WebRequestType.SAVE_GAME_DATA = "blockymods.save.game.data:"

-- game api --
WebRequestType.APP_RANK_USER = "blockymods.app.rank.user:"
WebRequestType.APP_RANK_ALL = "blockymods.app.rank.all:"

return WebRequestType