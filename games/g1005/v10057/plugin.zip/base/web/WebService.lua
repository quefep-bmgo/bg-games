--region *.lua
WebService = {}
WebService.ver = nil
WebService.ServerHttpHost = nil

WebService.UserAttr = "/user/api/v1/inner/user/details"
WebService.UserInfos = "/user/api/v1/inner/simple-info"
WebService.RewardAPI = "/game/api/v1/users/games/settlement"
WebService.RewardGoldAPI = "/game/api/v1/users/games/settlement/golds"
WebService.RewardList = "/game/api/v1/users/inner/games/settlement/list"
WebService.ReportList = "/game/api/v2/inner/users/games/reporting/list"
WebService.ExpRule = "/activity/api/v2/inner/activity/games/settlement/rule"
WebService.UserExp = "/activity/api/v1/inner/activity/games/user/exp"
WebService.SaveExp = "/activity/api/v1/inner/activity/games/records"
WebService.SaveHonor = "/gameaide/api/v1/inner/user/segment/integral"
WebService.UserSeasonInfo = "/gameaide/api/v1/inner/user/segment/info"
WebService.UserSeasonReward = "/gameaide/api/v1/inner/segment/integral/reward"
WebService.UserHasRecharge = "/pay/api/v1/pay/inner/has/user/recharge"
WebService.UserProps = "/gameaide/api/v1/inner/user/game/props"
WebService.ConsumeUserProps = "/gameaide/api/v1/inner/user/game/props/times"
WebService.PayOrder = "/pay/api/v2/inner/pay/users/purchase/game/props"
WebService.UploadRank = "/gameaide/api/v1/inner/rank/integral/upload/{gameId}"

WebService.MailsApi = "/gameaide/api/v1/inner/game/mails"
WebService.MailsStatusApi = "/gameaide/api/v1/inner/game/mails/{id}/status"
WebService.SendMsgApi = "/gameaide/api/v1/inner/msg/send"

WebService.SendThumbUpRecordApi = "/gameaide/api/v1/inner/insert/thumbs-up-record"
WebService.GetThumbUpRecordApi = "/gameaide/api/v1/inner/get/thumbs-up-record"
WebService.DeleteThumbUpRecordApi = "/gameaide/api/v1/inner/delete/thumbs-up-record"

WebService.UserGameData = "/api/v2/game/data"
WebService.SaveGameData = "/api/v2/game/data"

WebService.AppRankUserApi = "/game/api/v1/inner/games/{gameId}/uses/rank"
WebService.AppRankAllApi = "/game/api/v1/inner/games/{gameId}/rank"

function WebService:init(version, config)
    self.ver = version
    self.WebSession = 0
    self.ServerHttpHost = config.blockymodsRewardAddr
    self.DBHttpHost = config.dbHttpServiceUrl
    self.DBHttpRetryHost = config.dbHttpServiceRetryUrl
    self:initGameId()
end

function WebService:getSession()
    self.WebSession = self.WebSession + 1
    return self.WebSession
end

function WebService:initGameId()
    local uuid = require "base.util.uuid"
    uuid.randomseed(os.time())
    self.gameId = uuid()
end

function WebService:GetUserAttr(userId)
    local path = self.ServerHttpHost .. self.UserAttr
    local params = {
        { "userId", tostring(userId) },
        { "gameId", BaseMain:getGameType() }
    }
    local marked = WebRequestType.BLOCKYMODS_USER_ATTR .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:GetUserInfos(userIds, key)
    local path = self.ServerHttpHost .. self.UserInfos
    local params = {
        { "userIdList", table.concat(userIds, ",") }
    }
    local marked = WebRequestType.BLOCKYMODS_USER_INFOS .. key
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:GetReward(userId, data)
    local path = self.ServerHttpHost .. self.RewardAPI
    local params = {
        { "userId", tostring(userId) },
        { "gameId", RewardManager:getGameType() }
    }
    local marked = WebRequestType.BLOCKYMODS_REWARD .. self:getSession()
    HttpRequest.asyncPost(path, params, json.encode(data), marked)
    return marked
end

function WebService:GetGoldReward(userId, golds)
    local path = self.ServerHttpHost .. self.RewardGoldAPI
    local params = {
        { "userId", tostring(userId) },
        { "gameId", RewardManager:getGameType() },
        { "golds", tostring(golds) }
    }
    local marked = WebRequestType.BLOCKYMODS_GOLD_REWARD .. self:getSession()
    HttpRequest.asyncPost(path, params, "{}", marked)
    return marked
end

function WebService:GetRewardList(data)
    local path = self.ServerHttpHost .. self.RewardList
    local params = {}
    HttpRequest.asyncPost(path, params, json.encode(data), WebRequestType.BLOCKYMODS_REWARD_LIST)
    return WebRequestType.BLOCKYMODS_REWARD_LIST
end

function WebService:GetReportList(data)
    local path = self.ServerHttpHost .. self.ReportList
    local params = {}
    HttpRequest.asyncPost(path, params, json.encode(data), WebRequestType.BLOCKYMODS_REPORT_LIST)
    return WebRequestType.BLOCKYMODS_REPORT_LIST
end

function WebService:GetExpRule()
    local path = self.ServerHttpHost .. self.ExpRule
    local params = {
        { "gameId", BaseMain:getGameType() }
    }
    local marked = WebRequestType.BLOCKYMODS_EXP_RULE
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:GetUserExp(userId)
    local path = self.ServerHttpHost .. self.UserExp
    local params = {
        { "userId", tostring(userId) }
    }
    local marked = WebRequestType.BLOCKYMODS_USER_EXP .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:SaveUsersExp(data)
    local path = self.ServerHttpHost .. self.SaveExp
    local params = {}
    local marked = WebRequestType.BLOCKYMODS_SAVE_EXP
    HttpRequest.asyncPost(path, params, json.encode(data), marked)
    return marked
end

function WebService:SaveUsersHonor(data)
    local path = self.ServerHttpHost .. self.SaveHonor
    local params = {}
    local marked = WebRequestType.BLOCKYMODS_SAVE_HONOR
    HttpRequest.asyncPost(path, params, json.encode(data), marked)
    return marked
end

function WebService:GetUserSeasonInfo(userId, isLast)
    local path = self.ServerHttpHost .. self.UserSeasonInfo
    local lastSeason
    if isLast then
        lastSeason = "1"
    else
        lastSeason = "0"
    end
    local params = {
        { "userId", tostring(userId) },
        { "gameId", BaseMain:getGameType() },
        { "lastSeason", lastSeason }
    }
    local marked = WebRequestType.BLOCKYMODS_USER_SEASON_INFO .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:UpdateUserSeasonReward(userId)
    local path = self.ServerHttpHost .. self.UserSeasonReward
    local params = {
        { "userId", tostring(userId) },
        { "gameId", BaseMain:getGameType() }
    }
    local marked = WebRequestType.BLOCKYMODS_USER_SEASON_REWARD .. self:getSession()
    HttpRequest.asyncPost(path, params, "{}", marked)
    return marked
end

function WebService:HasRecharge(userId)
    local path = self.ServerHttpHost .. self.UserHasRecharge
    local params = {
        { "userId", tostring(userId) }
    }
    local marked = WebRequestType.BLOCKYMODS_USER_HAS_RECHARGE .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:GetUserProps(userId, gameType)
    local path = self.ServerHttpHost .. self.UserProps
    local params = {
        { "userId", tostring(userId) },
        { "gameId", gameType or BaseMain:getGameType() }
    }
    local marked = WebRequestType.BLOCKYMODS_USER_PROPS .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:ConsumeProps(userId, gameType, propsId)
    local path = self.ServerHttpHost .. self.ConsumeUserProps
    local params = {
        { "userId", tostring(userId) },
        { "gameId", gameType or BaseMain:getGameType() },
        { "propsId", propsId }
    }
    local marked = WebRequestType.BLOCKYMODS_CONSUME_USER_PROPS .. self:getSession()
    HttpRequest.asyncPost(path, params, "{}", marked)
    return marked
end

function WebService:CheckMails(userId, gameType)
    local path = self.ServerHttpHost .. self.MailsApi
    local params = {
        { "userId", tostring(userId) },
        { "gameType", gameType }
    }
    local marked = WebRequestType.CHECK_MAILS .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:SendMails(fromUser, toUser, mailType, title, content, gameType)
    local path = self.ServerHttpHost .. self.MailsApi
    local content_json = json.encode(content)
    local data = {
        fromUser = tostring(fromUser),
        toUser = tostring(toUser),
        mailType = mailType,
        title = title,
        content = content_json,
        gameType = gameType,
    }
    local params = {}
    local marked = WebRequestType.SEND_MAILS .. self:getSession()
    HttpRequest.asyncPost(path, params, json.encode(data), marked)
    return marked
end

function WebService:UpdateMails(id, status)
    local path = self.ServerHttpHost .. self.MailsStatusApi
    path = string.gsub(path, "{id}", id)
    local params = {
        { "status", status }
    }
    local marked = WebRequestType.UPDATE_MAILS .. self:getSession()
    HttpRequest.asyncPost(path, params, "{}", marked)
    return marked
end

function WebService:SendMsg(targets, content, msgType, scope, gameType)
    local path = self.ServerHttpHost .. self.SendMsgApi
    local data = {
        content = content,
        gameType = gameType,
        msgType = msgType,
        scope = scope, -- 'all', 'game', 'user'
        targets = targets,
    }
    local params = {}
    local marked = WebRequestType.SEND_MSG
    HttpRequest.asyncPost(path, params, json.encode(data), marked)
    return marked
end

function WebService:SendThumbUpRecord(userId, targetId, status)
    local path = self.ServerHttpHost .. self.SendThumbUpRecordApi
    local data = {
        activeUserId = tostring(userId),
        gameId = BaseMain:getGameType(),
        passiveUserId = tostring(targetId),
        status = status,
    }
    local params = {}
    local marked = WebRequestType.SEND_THUMB_UP_RECORD .. self:getSession()
    HttpRequest.asyncPost(path, params, json.encode(data), marked)
    return marked
end

function WebService:GetThumbUpRecord(userId, pageNo, pageSize)
    local path = self.ServerHttpHost .. self.GetThumbUpRecordApi
    local params = {
        { "userId", tostring(userId) },
        { "gameId", BaseMain:getGameType() },
        { "pageNo", pageNo },
        { "pageSize", pageSize }
    }
    local marked = WebRequestType.GET_THUMB_UP_RECORD .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:DeleteThumbUpRecord(messageId)
    local path = self.ServerHttpHost .. self.DeleteThumbUpRecordApi
    local params = {
        { "id", messageId },
    }
    local marked = WebRequestType.DELETE_THUMB_UP_RECORD .. self:getSession()
    HttpRequest.asyncPost(path, params, "", marked)
    return marked
end

function WebService:GetUserGameData(userId, subKey, isRetry)
    isRetry = isRetry or false
    local path
    if isRetry then
        path = self.DBHttpRetryHost .. self.UserGameData
    else
        path = self.DBHttpHost .. self.UserGameData
    end
    local params = {
        { "userId", tostring(userId) },
        { "subKey", tostring(subKey) },
        { "tableName", DBManager:getGameType() }
    }
    local marked = WebRequestType.USER_GAME_DATA .. self:getSession()
    HttpRequest.asyncGet(path, params, marked)
    return marked
end

function WebService:SaveUserGameData(data, isRetry)
    isRetry = isRetry or false
    local path
    if isRetry then
        path = self.DBHttpRetryHost .. self.UserGameData
    else
        path = self.DBHttpHost .. self.UserGameData
    end
    local params = {
        { "tableName", DBManager:getGameType() }
    }
    local marked = WebRequestType.SAVE_GAME_DATA .. self:getSession()
    HttpRequest.asyncPost(path, params, data, marked)
    return marked
end

function WebService:UpdateRank(userId, gameId, score, type)
    local path = self.ServerHttpHost .. self.UploadRank
    path = string.gsub(path, "{gameId}", gameId)
    local params = {
        { "userId", tostring(userId) },
        { "gameId", gameId },
        { "type", type },
        { "integral", score }
    }
    HttpRequest.asyncPost(path, params, "{}", "")
end

function WebService:Pay(userId, propsId, currency, quantity)
    local path = self.ServerHttpHost .. self.PayOrder
    local versionCode = "1"
    local packageName = "com.sandboxol.blockymods"
    local info = GameAnalyticsCache:getClientInfo(userId)
    if info ~= nil then
        versionCode = info.version_code or "1"
        packageName = info.package_name or "com.sandboxol.blockymods"
    end
    if currency == 1 then
        currency = 0
    end
    local data = {
        userId = tostring(userId),
        propsId = propsId,
        currency = currency,
        quantity = quantity,
        gameId = BaseMain:getGameType(),
        engineVersion = EngineVersionSetting.getEngineVersion(),
        appVersion = versionCode,
        packageName = packageName,
    }
    local params = {}
    local marked = WebRequestType.BLOCKYMODS_PAY_ORDER .. self:getSession()
    HttpRequest.asyncPost(path, params, json.encode(data), marked)
    return marked
end

function WebService:getUserAppRank(userId, type, lastWeek)
    local path = self.ServerHttpHost .. self.AppRankUserApi
    path = string.gsub(path, "{gameId}", RewardManager:getGameType())

    local params = {
        { "userId", tostring(userId) },
        { "gameId", RewardManager:getGameType() },
        { "type", type }, -- all, month, week
        { "lastWeek", lastWeek }, -- 0 this week, 1 last week
    }

    local marked = WebRequestType.APP_RANK_USER .. tostring(userId) .. ":" .. type .. ":" .. tostring(lastWeek)
    HttpRequest.asyncGet(path, params, marked)

    return marked
end

function WebService:getAllAppRank(type, pageNo, pageSize, lastWeek)
    local path = self.ServerHttpHost .. self.AppRankAllApi
    path = string.gsub(path, "{gameId}", RewardManager:getGameType())

    local params = {
        { "userId", tostring(0) },
        { "gameId", RewardManager:getGameType() },
        { "type", type }, -- all, month, week
        { "pageNo", pageNo },
        { "pageSize", pageSize },
        { "lastWeek", lastWeek }, -- 0 this week, 1 last week
    }

    local marked = WebRequestType.APP_RANK_ALL .. type .. ":" .. tostring(lastWeek)
    HttpRequest.asyncGet(path, params, marked)

    return marked
end

--endregion
