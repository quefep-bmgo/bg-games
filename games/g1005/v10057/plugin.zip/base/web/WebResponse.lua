---
--- Created by Jimmy.
--- DateTime: 2018/6/28 0028 11:25
---
WebResponse = {}
WebResponse.callbacks = {}

function WebResponse:registerCallBack(func, marked, ...)
    assert(type(marked) == "string")
    assert(func ~= nil)
    self:unregisterCallBack(marked)
    self.callbacks[marked] = { func, ... }
end

function WebResponse:unregisterCallBack(marked)
    if self.callbacks[marked] ~= nil then
        self.callbacks[marked] = nil
    end
end

function WebResponse:onCallFunc(data, marked)
    local callback = self.callbacks[marked]
    if callback ~= nil then
        self:unregisterCallBack(marked)
        callback[1](data, unpack(callback, 2))
    end
end

function WebResponse:onGetUserAttr(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    if data ~= nil then
        local player = PlayerManager:getPlayerByUserId(data.userId)
        if player ~= nil then
            player.name = string.gsub(data.nickName or player.name, TextFormat.colorStart, "")
            player.staticAttr.clanName = string.gsub(data.clanName or "", TextFormat.colorStart, "")
            player.staticAttr.role = data.role
            player.staticAttr.props = data.propsId or {}
            player.staticAttr.hasInit = true
        else
            data = nil
        end
    end
    self:onCallFunc(data, marked)
end

function WebResponse:onGetReward(result, marked)
    result = self:formatResult(result)
    local reward = self:formatData(result)
    if reward ~= nil then
        local player = PlayerManager:getPlayerByUserId(reward.userId)
        if player ~= nil then
            player.gold = reward.golds or 0
            player.available = reward.available or 0
            player.hasGet = reward.hasGet or 0
            player.adSwitch = reward.adSwitch or 0
        end
    end
    self:onCallFunc(reward, marked)
end

function WebResponse:onGetGoldReward(result, marked)
    result = self:formatResult(result)
    local reward = self:formatData(result)
    if reward ~= nil then
        local player = PlayerManager:getPlayerByUserId(reward.userId)
        if player ~= nil then
            player.gold = reward.golds or 0
            player.available = reward.available or 0
            player.hasGet = reward.hasGet or 0
        end
    end
    self:onCallFunc(reward, marked)
end

function WebResponse:onGetExpRole(result, marked)
    HostApi.log("[onGetExpRole]:" .. result)
    result = self:formatResult(result)
    local data = self:formatData(result)
    if data ~= nil then
        ExpRule:initRole(data)
    else
        ExpRule:disable()
    end
    self:onCallFunc(result, marked)
end

function WebResponse:onGetExp(result, marked)
    result = self:formatResult(result)
    local expInfo = self:formatData(result)
    if expInfo ~= nil then
        local player = PlayerManager:getPlayerByUserId(expInfo.userId)
        if player ~= nil then
            UserExpManager:addExpCache(expInfo.userId, expInfo.level, expInfo.experience, expInfo.expGetToday)
        end
    end
    self:onCallFunc(result, marked)
end

function WebResponse:onSaveExp(result, marked)
    self:onCallFunc(result, marked)
end

function WebResponse:onSaveHonor(result, marked)
    self:onCallFunc(result, marked)
end

function WebResponse:onGetUserSeasonInfo(result, marked)
    result = self:formatResult(result)
    local info = self:formatData(result)
    self:onCallFunc(info, marked)
end

function WebResponse:onUpdateUserSeasonReward(result, marked)
    result = self:formatResult(result)
    local isSuccess = false
    if result == "{}" then
        isSuccess = false
    else
        local data = json.encode(result)
        if data.code ~= nil and data.code == 1 then
            isSuccess = true
        end
    end
    self:onCallFunc(isSuccess, marked)
end

function WebResponse:onUserHasRecharge(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    local status = 0
    if data ~= nil then
        status = data.status
    end
    self:onCallFunc(status, marked)
end

function WebResponse:onGetUserProps(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    if data == nil then
        data = {}
    end
    self:onCallFunc(data, marked)
end

function WebResponse:onConsumeUserProps(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    self:onCallFunc(data, marked)
end

function WebResponse:onGetUserPayOrder(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    self:onCallFunc(data, marked)
end

function WebResponse:onReportData(result, marked)
    self:onCallFunc(result, marked)
end

function WebResponse:onGetUserInfos(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    self:onCallFunc(data, marked)
end

function WebResponse:onGetRewardList(result, marked)
    result = self:formatResult(result)
    local rewards = self:formatData(result)
    if rewards ~= nil then
        for i, reward in pairs(rewards) do
            local player = PlayerManager:getPlayerByUserId(reward.userId)
            if player ~= nil then
                player.gold = reward.golds or 0
                player.available = reward.available or 0
                player.hasGet = reward.hasGet or 0
                player.adSwitch = reward.adSwitch or 0
            end
        end
    end
    self:onCallFunc(rewards, marked)
end

function WebResponse:onReportList(result, marked)
    self:onCallFunc(result, marked)
end

function WebResponse:onCheckMails(result, marked)
    result = self:formatResult(result)
    local data = WebResponse:formatData(result)
    if data ~= nil then
        local items = {}
        local index = 1
        for i, v in pairs(data) do
            if v.id ~= nil then
                local item = {}
                item.id = v.id
                item.title = v.title
                item.content = v.content
                item.fromUser = v.fromUser
                item.toUser = v.toUser
                item.status = v.status
                item.mailType = v.mailType
                items[index] = item
                index = index + 1
            end
        end
        self:onCallFunc(items, marked)
        return
    end
    self:onCallFunc(nil, marked)
end

function WebResponse:onSendMails(result, marked)
    result = self:formatResult(result)
    if result ~= "{}" then
        self:onCallFunc(result, marked)
    else
        self:onCallFunc(nil, marked)
    end
end

function WebResponse:onUpdateMails(result, marked)
    result = self:formatResult(result)
    if result ~= "{}" then
        self:onCallFunc(result, marked)
    else
        self:onCallFunc(nil, marked)
    end
end

function WebResponse:onGetThumbUpRecord(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    if data ~= nil and data.data ~= nil then
        self:onCallFunc(data.data, marked)
    else
        self:onCallFunc(nil, marked)
    end
end

function WebResponse:onGetUserAppRank(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    if data then
        self:onCallFunc(data, marked)
    end
end

function WebResponse:onGetAllAppRank(result, marked)
    result = self:formatResult(result)
    local data = self:formatData(result)
    if data and data.pageInfo then
        self:onCallFunc(data.pageInfo, marked)
    end
end

function WebResponse:onGetGameData(result, marked)
    result = self:formatResult(result)
    local data, code = self:formatData(result)
    if code == 11 then
        data = { __first = true }
    end
    self:onCallFunc(data, marked)
end

function WebResponse:onSaveGameData(result, marked)
    result = self:formatResult(result)
    local data, code = self:formatData(result)
    self:onCallFunc(code, marked)
end

function WebResponse:formatResult(result)
    if result == nil or string.len(result) == 0 then
        return "{}"
    end
    if string.sub(result, 1, 1) == '{' and string.find(result, "\"code\":1") ~= nil then
        return result
    end
    print("[Error] http request failed: " .. result)
    return "{}"
end

function WebResponse:formatResultCode(result)
    if result == nil or string.len(result) == 0 then
        return "{}"
    end
    if string.sub(result, 1, 1) == '{' and string.find(result, "\"code\":") ~= nil then
        return result
    end
    print("[Error] http request failed: " .. result)
    return "{}"
end

function WebResponse:formatData(result)
    if result == "{}" then
        return nil, 0
    end
    result = json.decode(string.gsub(result, TextFormat.colorStart, ""))
    if result.code == 1 or result.data ~= nil then
        return result.data, result.code
    end
    return nil, result.code
end

return WebResponse