---
--- Created by Jimmy.
--- DateTime: 2018/9/13 0028 11:37
---
BaseListener = {}
BaseListener.callbacks = {}

function BaseListener.registerCallBack(event, func)
    BaseListener.callbacks[event] = func
end

function BaseListener:init()
    GameInitEvent.registerCallBack(self.onGameInit)
    PlayerLoginEvent.registerCallBack(self.onPlayerLogin)
    PlayerLogoutEvent.registerCallBack(self.onPlayerLogout)
    PlayerReadyEvent.registerCallBack(self.onPlayerReady)
    PlayerFirstSpawnEvent.registerCallBack(self.onPlayerFirstSpawn)
    PlayerRespawnEvent.registerCallBack(self.onPlayerRespawn)
    PlayerAfterRespawnEvent.registerCallBack(self.onPlayerAfterRespawn)
    GetDataFromDBEvent:registerCallBack(self.onGetDataFromDB)
    ClientCommonDataEvent.registerCallBack(self.onClientCommonData)
    SpawnEntityEvent.registerCallBack(self.onSpawnEntity)
    RemoveEntityEvent.registerCallBack(self.onRemoveEntity)
    PlayerReconnectSuccessEvent.registerCallBack(self.onPlayerReconnectSuccess)
    PlayerNetworkTimeoutEvent.registerCallBack(self.onPlayerNetworkTimeout)
    PlayerDynamicAttrEvent.registerCallBack(self.onPlayerDynamicAttr)
end

function BaseListener.onGameInit(GamePath, ver, serverworld, config)
    GameType = config.gameType
    HostApi.log(VarDump(ServerWorld))
    BaseMain:setIsChina(config.isChina)
    FileUtil:setMapPath(GamePath)
    EngineWorld:setWorld(serverworld)
    GameServer:setServerConfig(config)
    PacketSender:init()
    AppProps:init()
    WebService:init(ver, config)
    CommonTask:start()
    PlayerManager:setMaxPlayer(config.maxPlayers)

    require "base.helper.GMHelper"

    local callback = BaseListener.callbacks[GameInitEvent]
    if callback ~= nil then
        callback(FileUtil.getConfigFromYml("config"))
    end

    WebService:GetExpRule()
    PlayerIdentityCache:init()
    GameAnalyticsRequest.asyncInit(3)
    SumRechargeConfig:init()
    MaxRecordHelper:init()
    ExchangeHelper:init()
    if Platform.isWindow() then
        local path = string.gsub(FileUtil:getScriptDir(), "ServerGame", "BaseGame")
        HU.Init("base.hotupdate.hotupdatelist", { ".\\Media\\Scripts\\ServerGame\\Common", FileUtil:getScriptDir(), path })
    end
end

function BaseListener.onPlayerLogin(clientPeer, clientInfo, enableIndie, gameTimeToday)
    local builder =  DataBuilder.new()
    builder:addParam("isChina", BaseMain:isChina())
    PacketSender:sendLuaCommonData(clientPeer:getRakssid(), "ServerInfo", builder:getData())
    local player = PlayerManager:getPlayerByUserId(clientPeer:getPlatformUserId())
    if player then
        local entityPlayerMP = clientPeer:getEntityPlayer()
        local oldPosition = player.entityPlayerMP:getPosition()
        local oldYaw = player.entityPlayerMP:getYaw()
        entityPlayerMP:clonePlayer(player.entityPlayerMP, true)
        player:initStaticAttr(player.entityPlayerMP:getTeamId())
        player.clientPeer = clientPeer
        player.entityPlayerMP = entityPlayerMP
        player.rakssid = clientPeer:getRakssid()
        LuaTimer:schedule(function()
            player:teleportPosWithYaw(oldPosition, oldYaw)
        end, 100)
        ExchangeHelper:onPlayerLogin(player)
        return DBManager:onPlayerLogin(player)
    end
    if PlayerManager:isPlayerFull() then
        HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGamePlayerIsEnough(), GameOverCode.PlayerIsEnough)
        return true
    end
    GameAnalyticsCache:addClientInfo(clientPeer:getPlatformUserId(), clientInfo)
    local code, status, c_callback
    local callback = BaseListener.callbacks[PlayerLoginEvent]
    if callback == nil then
        code = GameOverCode.Success
        player = BasePlayer.new(clientPeer)
        player:initStaticAttr(player.dynamicAttr.team)
    else
        code, player, status, c_callback = callback(clientPeer)
        if code == GameOverCode.GameStarted then
            HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGameHasStarting(), GameOverCode.GameStarted)
            return true
        end
        if code ~= GameOverCode.Success then
            HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGameOver(), GameOverCode.GameOver)
            return true
        end
        if player == nil then
            code = GameOverCode.Success
            player = BasePlayer.new(clientPeer)
            player:initStaticAttr(player.dynamicAttr.team)
        end
    end
    PlayerManager:addPlayer(player)
    if BaseMain:isChina() and Platform.isLinux() then
        player.gameTimeToday = gameTimeToday or 0
    else
        player.gameTimeToday = -1
    end
    player.enableIndie = enableIndie or false
    if PlayerManager:isPlayerFull() then
        HostApi.sendStartGame(PlayerManager:getPlayerCount())
    end
    if status ~= nil and status >= 1 and status <= 2 then
        HostApi.sendGameStatus(clientPeer:getRakssid(), status)
    end
    if c_callback ~= nil then
        c_callback()
    end
    ExchangeHelper:onPlayerLogin(player)
    return DBManager:onPlayerLogin(player)
end

function BaseListener.onPlayerLogout(rakssid)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return false
    end
    GameGroupManager:removeUser(player.userId)
    SumRechargeHelper:onPlayerLogout(player.userId)
    ExchangeHelper:onPlayerLogout(player.userId)
    if player ~= nil then
        PlayerManager:subPlayer(player)
        local clear = function(player)
            player:onPlayerLogout()
            if DBManager:isAutoCache() then
                DBManager:removeCache(player.userId)
            end
            RewardManager:removeRewardCache(player.userId)
            GameAnalyticsCache:removeCache(player.userId)
            MaxRecordHelper:onPlayerLogout(player.userId)
        end
        local callback = BaseListener.callbacks[PlayerLogoutEvent]
        if callback == nil then
            clear(player)
            return
        end
        callback(player)
        clear(player)
    else
        RewardManager:removeRewardCache(player.userId)
        GameAnalyticsCache:removeCache(player.userId)
        MaxRecordHelper:onPlayerLogout(player.userId)
    end
    SumRechargeHelper:removeCache(player)
    return true
end

function BaseListener.onPlayerReady(rakssid)
    local callback = BaseListener.callbacks[PlayerReadyEvent]
    if callback == nil then
        return
    end
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        HostApi.sendGameover(rakssid, IMessages:msgGameOver(), GameOverCode.ReadyNoPlayer)
        return
    end
    player.isReady = true
    local time = callback(player)
    DBManager:onPlayerReady(player)
    SumRechargeHelper:onPlayerReady(player)
    ExchangeHelper:onPlayerReady(player)
    if time ~= nil and time > 0 then
        player:addNightVisionPotionEffect(time)
    end
end

function BaseListener.onPlayerFirstSpawn(clientPeer)
    local player = PlayerManager:getPlayerByRakssid(clientPeer:getRakssid())
    if player == nil then
        return
    end
    PlayerIdentityCache:onPlayerSpawn(player)
    local callback = BaseListener.callbacks[PlayerFirstSpawnEvent]
    if callback == nil then
        return
    end
    callback(player)
end

function BaseListener.onPlayerAfterRespawn(clientPeer)
    local player = PlayerManager:getPlayerByRakssid(clientPeer:getRakssid())
    if player == nil then
        return
    end
    local callback = BaseListener.callbacks[PlayerAfterRespawnEvent]
    if callback == nil then
        return
    end
    callback(player)
end

function BaseListener.onPlayerRespawn(clientPeer)
    local player = PlayerManager:getPlayerByRakssid(clientPeer:getRakssid())
    if player == nil then
        return
    end
    PlayerIdentityCache:onPlayerSpawn(player)
    local callback = BaseListener.callbacks[PlayerRespawnEvent]
    if callback == nil then
        return
    end
    player:respawn(clientPeer)
    local time = callback(player)
    if time ~= nil and time > 0 then
        player:addNightVisionPotionEffect(time)
    end
end

function BaseListener.onGetDataFromDB(userId, subKey, data)
    local callback = BaseListener.callbacks[GetDataFromDBEvent]
    if callback == nil then
        return
    end
    local player = PlayerManager:getPlayerByUserId(userId)
    if player ~= nil then
        if DBManager:isAutoCache() then
            DBManager:addCache(userId, subKey, data)
        end
        callback(player, subKey, data)
    end
end

function BaseListener.onClientCommonData(userId, key, data)
    CommonDataEvents:dispatchEvent(userId, key, data)
end

function BaseListener.onSpawnEntity(entity, type)
    if not EngineWorld:getWorld() then
        return
    end
    local lEntity = EntityCache:createEntityCache(entity, type)
    local callback = BaseListener.callbacks[SpawnEntityEvent]
    if callback then
        callback(lEntity)
    end
end

function BaseListener.onRemoveEntity(entityId)
    EntityCache:removeEntityCache(entityId)
end

function BaseListener.onPlayerReconnectSuccess(clientPeer)

end

function BaseListener.onPlayerNetworkTimeout(rakssid)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        DBManager:callSavePlayerData(player)
    end
end

function BaseListener.onPlayerDynamicAttr(attr)
    if Platform.isWindow() then
        return
    end
    if Server.Instance():getEnableRoom() then
        LuaTimer:schedule(function(userId)
            local player = PlayerManager:getPlayerByUserId(userId)
            if not player then
                GameServer:getRoomManager():sendUserOut(userId)
            end
        end, 90000, nil, attr.userId)
    end
end

return BaseListener