---
--- Created by Jimmy.
--- DateTime: 2018/3/8 0008 10:16
---
DateUtil = {}

function DateUtil.getYearWeek(time)
    return os.date("%Y", time) .. DateUtil.getWeeksOfYear(time)
end

function DateUtil.getWeeksOfYear(time)
    if time == nil then
        time = os.time()
    end
    local firstYearTime = os.time({ day = 1, month = 1, year = os.date("%Y", time) })
    local firstYearDate = os.date("*t", firstYearTime)
    local date = os.date("*t", time)
    local start_wday = firstYearDate.wday - 1
    local yday = date.yday
    if (start_wday + yday) % 7 == 0 then
        return (start_wday + yday) / 7
    else
        return NumberUtil.getIntPart((start_wday + yday) / 7) + 1
    end
end

function DateUtil.getWeekDay(time)
    if time == nil then
        time = os.time()
    end
    return os.date("*t", time).wday
end

function DateUtil.getYearDay(time)
    if time == nil then
        time = os.time()
    end
    return os.date("%Y", time) .. os.date("*t", time).yday
end

function DateUtil.getDate(time)
    if time == nil then
        time = os.time()
    end
    return os.date("%Y-%m-%d", time)
end

function DateUtil.getDateString(time)
    if time == nil then
        time = os.time()
    end
    return os.date("%Y-%m-%d %X", time)
end

function DateUtil.getWeekLastTime(time, real)
    time = DateUtil.getDayLastTime(time, true)
    local date = os.date("*t", time)
    local wday = date.wday
    time = time + (7 - wday + 1) * 86400
    if real then
        return time
    end
    return time + 86400
end

function DateUtil.getDayLastTime(time, real)
    if time == nil then
        time = os.time()
    end
    local date = os.date("*t", time + 86400)
    time = os.time({ year = date.year, month = date.month, day = date.day, hour = 0, minute = 0, second = 0})
    if real then
        return time
    end
    return time + 86400
end

function DateUtil.getWeekSeconds()
    return 604800
end

function DateUtil.getDaySeconds()
    return 86400
end

return DateUtil