---@class SPacketHandlers : SBasePlayer
local PacketHandlers = T(Global, "PacketHandlers")
---@type function[]
local Session = T(Global, "Session")
---@type table<string, number>
local HashId2Name = T(Global, "C2SPid_HashId2Name")
---@type PacketChecker
local PacketChecker = T(Global, "PacketChecker")
---@type SBasePlayer
local SBasePlayer = BasePlayer
---@type table<string, string>
local ClientFileCache = {}

---@param packet PidPacket
function SBasePlayer:sendPacket(packet, resp, ignoreReady)
    assert(not packet.__session__)
    if not self.entityPlayerMP or not packet.pid then
        return
    end
    if resp then
        assert(type(resp) == "function")
        local session = #Session + 1
        Session[session] = resp
        packet.__session__ = session
    end
    PacketSender:sendPidPacket(self.rakssid, packet, ignoreReady)
end

---@param packet PidPacket
function SBasePlayer:broadCastPacket(packet, ignoreReady)
    if not self.entityPlayerMP or not packet.pid then
        return
    end
    PacketSender:broadCastPidPacket(packet, ignoreReady)
end

---@param packet PidPacket
function SBasePlayer:sendTrackingPacket(packet, ignoreReady)
    if not self.entityPlayerMP or not packet.pid then
        return
    end
    PacketSender:sendPidPacketToTracking(self:getEntityId(), packet, ignoreReady)
end

---@param packet PidPacket
CommonDataEvents:registerCallBack("pid", function(userId, packet)
    if not packet then
        LogUtil.logError("[PacketHandlers] packet = nil.", "userId = " .. userId)
        PacketChecker:addErrorTimes(userId)
        return
    end
    if not packet.pid then
        LogUtil.logError("[PacketHandlers] can not find pid.", "userId = " .. userId, StringUtil.v2s(packet))
        PacketChecker:addErrorTimes(userId)
        return
    end
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player or player.isKickOut then
        LogUtil.logWarning("[PacketHandlers] can not find player or player.isKickOut, pid=" .. packet.pid)
        return
    end
    packet.pid = HashId2Name[packet.pid] or packet.pid
    local func = PacketHandlers[packet.pid]
    if not func then
        LogUtil.logWarning("[PacketHandlers] can not find func, pid=" .. packet.pid)
        return
    end
    local ret = func(player, packet)
    if packet.__session__ ~= nil then
        player:sendPacket({
            pid = "resp",
            session = packet.__session__,
            ret = ret
        })
    end
end, SerializeBuilderProcessor)

function PacketHandlers:resp(packet)
    Session[packet.session](packet.ret)
    Session[packet.session] = nil
end

---@param player SBasePlayer
function PacketHandlers.GMOpenInputBack(player, packet)
    if player.GMCallBack then
        player.GMCallBack(unpack(packet.params))
        player.GMCallBack = nil
    end
end

---@param self SBasePlayer
function PacketHandlers.PerformanceReport(self, packet)
    self.performance = { fps = packet.fps, netPing = packet.netPing, logicPing = packet.logicPing }
end

---@param self SBasePlayer
function PacketHandlers.onWatchAdSuccess(self, packet)
    if isLocalWin then
        CEvents.WatchAdvertFinishedEvent:invoke(self.rakssid, packet.type, packet.params, 1)
    end
end

function PacketHandlers:SyncClientVerify(packet)
    if not DBManager:isPlayerDBReady(self.userId) then
        return
    end
    local globals = { "isTest" }
    local engines = {}
    local games = { "/lua/client/PluginMain.lua" }
    if not packet.globals or not packet.engines or not packet.games then
        HostApi.sendGameoverByPlatformUserId(self.userId, "[verify] verification failed, please login again! [0]", 17)
        return
    end
    for _, key in pairs(globals) do
        if _G[key] ~= packet.globals[key] then
            HostApi.sendGameoverByPlatformUserId(self.userId, "[verify] verification failed, please login again! [1]", 17)
            return
        end
    end
    for _, engine in pairs(engines) do
        local key = "engine:" .. engine
        local content = ClientFileCache[key]
        if not content then
            local path = FileUtil:getScriptPath() .. engine
            local file = io.open(path, "r")
            if not file and isLocalWin then
                path = FileUtil:getRootPath() .. "Media/Scripts/Engine" .. engine
                file = io.open(path, "r")
            end
            content = ""
            if file then
                content = file:read("*a")
                file:close()
            end
            ClientFileCache[key] = content
        end
        if content ~= packet.engines[engine] then
            HostApi.sendGameoverByPlatformUserId(self.userId, "[verify] verification failed, please login again! [2]", 17)
            return
        end
    end
    for _, game in pairs(games) do
        local key = "game:" .. game
        local content = ClientFileCache[key]
        if not content then
            local path = FileUtil:getMapPath() .. game
            local file = io.open(path, "r")
            if not file then
                path = FileUtil:getScriptPath() .. game
                file = io.open(path, "r")
            end
            content = ""
            if file then
                content = file:read("*a")
                file:close()
            end
            ClientFileCache[key] = content
        end
        if content ~= packet.games[game] then
            HostApi.sendGameoverByPlatformUserId(self.userId, "[verify] verification failed, please login again! [3]", 17)
            return
        end
    end
    PacketSender:getSender():sendPlayerDBDataReady(self.rakssid)
end

function PacketHandlers:onCheckGMOpenResult(packet)
    if packet.isGMOpen then
        HostApi.sendGameoverByPlatformUserId(self.userId, "[verify] cheat detected [gm][1]", 19)
    end
end

return PacketHandlers
