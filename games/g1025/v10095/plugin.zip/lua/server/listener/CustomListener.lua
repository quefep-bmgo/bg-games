---
--- Created by Jimmy.
--- DateTime: 2018/6/8 0008 11:51
---
CustomListener = {}

local SPidPacketSender = T(Global, "PidPacketSender")

function CustomListener:init()
    CEvents.CustomTipMsgEvent:registerCallBack(self.onCustomTipMsg)
    CEvents.ConsumeDiamondsEvent:registerCallBack(self.onConsumeDiamonds)
    CEvents.WatchAdvertFinishedEvent:registerCallBack(self.onWatchAdvertFinished)
    Events.CommonReceiveRewardEvent:registerCallBack(self.onCommonReceiveReward)
    Events.CommonCanReceiveRewardEvent:registerCallBack(self.onCommonCanReceiveReward)
end

function CustomListener.onCustomTipMsg(rakssid, extra, isRight)
    if isRight == false then
        return
    end
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return
    end

    local extras = StringUtil.split(extra, "=")
    if #extras ~= 2 then
        return
    end

    if extras[1] == "ExtraPortal" then
        local npc = GameManager:getNpcByEntityId(tonumber(extras[2]))
        if npc then
            npc:onPlayerSelected(player)
        end
        return
    end

    if extras[1] == "Single" then
        player:unlockOccupation(extra)
        return
    end

    if extras[1] == "Perpetual" then
        player:unlockOccupation(extra)
        return
    end

    if extras[1] == "FreeUse" then
        local npc = GameManager:getNpcByEntityId(tonumber(extras[2]))
        if not npc then
            return
        end
        if player.freeOccId == 0 then
            return
        end
        if npc:selectOccupation(player) then
            player.freeOccId = 0
        else
            MsgSender.sendCenterTipsToTarget(player.rakssid, 3, Messages:msgHeroHasBeenChosen())
        end
    end

    if extras[1] == "Occupation" then
        local npc = GameManager:getNpcByEntityId(tonumber(extras[2]))
        if npc and npc:selectOccupation(player) then
            return
        end
        MsgSender.sendCenterTipsToTarget(player.rakssid, 3, Messages:msgHeroHasBeenChosen())
    end

end

function CustomListener.onConsumeDiamonds(rakssid, isSuccess, message, extra)
    if isSuccess == false then
        return
    end

    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return
    end

    local extras = StringUtil.split(extra, "=")
    if #extras ~= 2 then
        return
    end

    local npc = GameManager:getNpcByEntityId(tonumber(extras[2]))
    if npc == nil then
        MsgSender.sendCenterTipsToTarget(player.rakssid, 3, Messages:msgHeroHasBeenChosen())
        return
    end

    if npc.curSelectNum >= npc.selectedMaxNum then
        MsgSender.sendCenterTipsToTarget(player.rakssid, 3, Messages:msgHeroHasBeenChosen())
        return
    end

    if extras[1] == "Single" then
        npc:selectOccupation(player)
        return
    end

    if extras[1] == "Perpetual" then
        player:addsupOccIds(npc.config.id)
        npc:selectOccupation(player)
        return
    end

end

function CustomListener.onWatchAdvertFinished(rakssid, type, params, code)
    if code ~= 1 then
        return
    end
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return
    end
    if type == Define.AdType.Money then
        VideoAdHelper:doGetMoneyAdReward(player)
        return
    end
    if type == Define.AdType.Building then
        VideoAdHelper:doGetBuildingAdReward(player)
        return
    end
    if type == Define.AdType.AppShop then
        local itemId = DataBuilder.new():fromData(params):getNumberParam("ItemId")
        if itemId == BlockID.TNT then
            VideoAdHelper:doGetTNTAdReward(player)
        end
        if itemId == BlockID.LADDER then
            VideoAdHelper:doGetLadderAdReward(player)
        end
        return
    end
end

function CustomListener.onCommonReceiveReward(player, propsType, propsId, propsCount, expireTime)
    if propsType == "Privilege" then
        local occId = OccupationConfig:getOccupationIdByCommonItemId(propsId) or 0
        if occId ~= 0 then
            player.privilege[tostring(occId)] = player.privilege[tostring(occId)] or os.time()
            player.privilege[tostring(occId)] = player.privilege[tostring(occId)] + expireTime
            player:syncPrivilegeData()
        end
    elseif propsType == "Hero" then
        local occId = OccupationConfig:getOccupationIdByCommonItemId(propsId) or 0
        if tonumber(occId) == 0 then
            occId = OccupationConfig:getOccupationIdByMoneyItemId(propsId) or 0
        end
        if tonumber(occId) == 0 then
            return false
        end
        --解锁职业
        local isBuy = true
        for _, id in pairs(player.baseOccIds) do
            if tonumber(id) == tonumber(occId) then
                isBuy = false
                break
            end
        end
        for _, id in pairs(player.supOccIds) do
            if tonumber(id) == tonumber(occId) then
                isBuy = false
                break
            end
        end
        if isBuy then
            player:addsupOccIds(occId)
        end
    elseif propsType:find("ShopItem") then

        local occId = OccupationConfig:getOccupationIdByCommonItemId(propsId) or 0
        if tonumber(occId) == 0 then
            occId = OccupationConfig:getOccupationIdByMoneyItemId(propsId) or 0
        end

        if tonumber(occId) == 0 then
            return false
        end
        local num=string.gsub(propsType, "ShopItem", "")
        local iType = tonumber(num)
        if not iType then
            return false
        end

        for _, bId in pairs(player.baseOccIds) do
            if tonumber(bId) == tonumber(occId) then
                if not player:hasUpgradeEquip(occId, iType) then
                    player:addUpgradeEquips(occId, iType)
                    break
                end
            end
        end

        for _, sId in pairs(player.supOccIds) do
            if tonumber(sId) == tonumber(occId) then
                if not player:hasUpgradeEquip(occId, iType) then
                    player:addUpgradeEquips(occId, iType)
                    break
                end
            end
        end

    elseif propsType == "Item" then
        if propsId > 0 and propsId < 10000 then
            player:addItem(propsId, propsCount, 0)
        elseif propsId == 10000 then
            player:addCurrency(propsCount)
        end
    end
end

function CustomListener.onCommonCanReceiveReward(player, result,doNotShowTips)

    local needCheckBag = false
    local needStackCount = 0

    for _, cfg in pairs(result) do
        if cfg.type == "Item" then
            if cfg.rewardId > 0 and cfg.rewardId < 10000 then
                needStackCount = needStackCount + math.ceil(cfg.count / 64)
                needCheckBag = true
            end
        elseif cfg.type == "Hero" then
            local occId = OccupationConfig:getOccupationIdByCommonItemId(cfg.rewardId) or 0
            if tonumber(occId) == 0 then
                occId = OccupationConfig:getOccupationIdByMoneyItemId(cfg.rewardId) or 0
            end
            if tonumber(occId) == 0 then
                if not doNotShowTips then
                    SPidPacketSender:sendShowToast(player.rakssid, "gui.limit.time.discount.store.item.unlock")
                end
                return false
            end
            for _, id in pairs(player.baseOccIds) do
                if tonumber(id) == tonumber(occId) then
                    if not doNotShowTips then
                        SPidPacketSender:sendShowToast(player.rakssid, "gui.limit.time.discount.store.item.unlock")
                    end
                    return false
                end
            end
            for _, id in pairs(player.supOccIds) do
                if tonumber(id) == tonumber(occId) then
                    if not doNotShowTips then
                        SPidPacketSender:sendShowToast(player.rakssid, "gui.limit.time.discount.store.item.unlock")
                    end
                    return false
                end
            end

        elseif cfg.type:find("ShopItem") then
            local occId = OccupationConfig:getOccupationIdByCommonItemId(cfg.rewardId) or 0
            if tonumber(occId) == 0 then
                occId = OccupationConfig:getOccupationIdByMoneyItemId(cfg.rewardId) or 0
            end
            if tonumber(occId) == 0 then
                if not doNotShowTips then
                    SPidPacketSender:sendShowToast(player.rakssid, "gui.limit.time.discount.store.item.unlock")
                end
                return false
            end
            local num=string.gsub(cfg.type, "ShopItem", "")
            local iType = tonumber(num) or 0
            for _, bId in pairs(player.baseOccIds) do
                if tonumber(bId) == tonumber(occId) then
                    if player:hasUpgradeEquip(occId, iType) then
                        if not doNotShowTips then
                            SPidPacketSender:sendShowToast(player.rakssid, "gui.limit.time.discount.store.item.unlock")
                        end
                        return false
                    end
                end
            end

            for _, sId in pairs(player.supOccIds) do
                if tonumber(sId) == tonumber(occId) then
                    if player:hasUpgradeEquip(occId, iType) then
                        if not doNotShowTips then
                            SPidPacketSender:sendShowToast(player.rakssid, "gui.limit.time.discount.store.item.unlock")
                        end
                        return false
                    end
                end
            end
        end
    end

    if needCheckBag and needStackCount >  player:getInventory():getEmptyStackCount() then
        if not doNotShowTips then
            SPidPacketSender:sendShowToast(player.rakssid, "common.activity.tip.needBackPack")
        end
        return false
    end

    return true
end

return CustomListener
--endregion
