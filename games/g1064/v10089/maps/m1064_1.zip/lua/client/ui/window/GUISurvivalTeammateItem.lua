---@class GUISurvivalTeammateItemWindow : IGUIWindow
local GUISurvivalTeammateItemWindow = class("GUISurvivalTeammateItemWindow", IGUIWindow)
---@type table<string, number[]>
local NumberColor = {
    ["0"] = { 187 / 255, 176 / 255, 55 / 255, 1 },
    ["1"] = { 187 / 255, 176 / 255, 55 / 255, 1 },
    ["2"] = { 197 / 255, 65 / 255, 30 / 255, 1 },
    ["3"] = { 30 / 255, 105 / 255, 197 / 255, 1 },
    ["4"] = { 34 / 255, 152 / 255, 32 / 255, 1 },
}

---@private
function GUISurvivalTeammateItemWindow:ctor(...)
    self.super.ctor(self, "SurvivalTeammateItem.json", ...)
end

---@private
function GUISurvivalTeammateItemWindow:onLoad()
    self.stNumber = self:getChildWindowByName("SurvivalTeammateItem-Number", GUIType.StaticText)
    self.stName = self:getChildWindowByName("SurvivalTeammateItem-Name", GUIType.StaticText)
    self.siHPClip = self:getChildWindowByName("SurvivalTeammateItem-HP-Clip", GUIType.StaticImage)
    self.siHPColor = self:getChildWindowByName("SurvivalTeammateItem-HP-Color", GUIType.StaticImage)
end

---@param data PlayerInfo
function GUISurvivalTeammateItemWindow:onDataChanged(data)
    local number = data:getValue("number")
    self.stNumber:SetText(number)
    self.stNumber:SetBackgroundColor(NumberColor[number] or Color.WHITE)
    self.stName:SetText(data:getValue("userName"))
    local maxHp = data:getValue("maxHp", true)
    local curHp = data:getValue("curHp", true)
    local progress = curHp / maxHp
    self.siHPClip:SetWidth({ progress, 0 })
    if progress > 0.8 then
        self.siHPColor:SetBackgroundColor({ 1, 88 / 255, 76 / 255, 1 })
    elseif progress > 0.3 then
        self.siHPColor:SetBackgroundColor({ 0.88, 0.66, 0.27, 1 })
    else
        self.siHPColor:SetBackgroundColor({ 1, 0, 200 / 255, 1 })
    end
    ---@type CBasePlayer
    local player = PlayerManager:getPlayerByUserId(data.infoKey)
    if not player or not player.Player then
        Plugins.CallTargetPluginFunc("mini_map", "removeImage", "PlayerArrow" .. data.infoKey)
        Plugins.CallTargetPluginFunc("mini_map", "removeImage", "PlayerCircle" .. data.infoKey)
        Plugins.CallTargetPluginFunc("mini_map", "removeText", "PlayerNumber" .. data.infoKey)
        return
    end
    local position = player:getPosition()
    local info = GameInfoManager:getPlayerInfo(data.infoKey)
    if info:getBoolValue("lifeStatus") then
        Plugins.CallTargetPluginFunc("mini_map", "addImage", {
            id = "PlayerCircle" .. data.infoKey,
            image = "set:survival_main.json image:img_0_arrow_player2",
            color = NumberColor[number] or Color.WHITE,
            width = 58,
            height = 58,
            level = tonumber(data.infoKey) == Game:getPlatformUserId() and 2 or 4,
            centerPos = position,
            ignoreMap = true
        })
        Plugins.CallTargetPluginFunc("mini_map", "addImage", {
            id = "PlayerArrow" .. data.infoKey,
            image = "set:survival_main.json image:img_0_arrow_player",
            width = 58,
            height = 58,
            rotate = player:getYaw() % 360,
            level = tonumber(data.infoKey) == Game:getPlatformUserId() and 2 or 4,
            centerPos = position,
            ignoreMap = true
        })
        Plugins.CallTargetPluginFunc("mini_map", "addText", {
            id = "PlayerNumber" .. data.infoKey,
            textColor = Color.WHITE,
            text = number,
            width = 58,
            height = 58,
            level = tonumber(data.infoKey) == Game:getPlatformUserId() and 1 or 3,
            centerPos = position,
        })
    else
        Plugins.CallTargetPluginFunc("mini_map", "removeImage", "PlayerArrow" .. data.infoKey)
        Plugins.CallTargetPluginFunc("mini_map", "removeImage", "PlayerCircle" .. data.infoKey)
        Plugins.CallTargetPluginFunc("mini_map", "removeText", "PlayerNumber" .. data.infoKey)
    end

    if player.userId ~= Game:getPlatformUserId() then
        local showName = player.Player:getShowName()
        local nameList = StringUtil.split(showName, "\n")
        local font = GUIFontManager.Instance():GetFont("HT20")
        local width = font:GetTextExtent(nameList[1], 1) * (0.3 / font:GetFontHeight()) / 2 + 0.25
        local builder = DataBuilder.new()
        builder:addParam("atlasName", "survival_team.json")
        builder:addParam("spriteName", "img_0_teammateid_" .. tostring(number))
        builder:addVector3Param("offset", VectorUtil.newVector3(0, 2.4, 0))
        builder:addVector3Param("absoluteOffset", VectorUtil.newVector3(-width, 0, -width))
        player.Player:addCustomImage("SurvivalTeamId", builder:getData(), -1, 1)
    end
end

return GUISurvivalTeammateItemWindow
