---@type CBasePlayer
local handler = T(Global, "PacketHandlers")

---@type CMainActivity
local MainActivity = Plugins.Require("activity", "client.MainActivity")

---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

function handler:PluginAddActivity(packet)
    MainActivity:addActivity(CommonActivityConfig:getCommonActivityById(packet.activityId))
end

function handler:PluginRemoveActivity(packet)
    MainActivity:removeActivity(packet.activityId)
end

function handler:ToActivityPacket(packet)
    local activityMgr = MainActivity:getActivity(packet.activityId)
    if activityMgr and activityMgr[packet.funcName] then
        activityMgr[packet.funcName](activityMgr, PlayerManager:getClientPlayer(), packet)
    else
        LogUtil.logError(string.format("ToActivityPacket Error ,activityMgr not exist , activityId = %d", packet.activityId))
    end
end

function handler:SetActivityMoney(packet)
    PlayerWallet:setMoneyCount(tonumber(packet.coinId), packet.count)
end