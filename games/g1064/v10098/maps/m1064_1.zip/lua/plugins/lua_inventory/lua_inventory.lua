---起床专属插件 ， 为了功能模块化

--Plugins.Require("lua_inventory", "common.define.InventoryDefine")

local handlers
Plugins.Require("lua_inventory", "common.manager.IInventoryManager")
Plugins.Require("lua_inventory", "common.event.LuaInventoryEvents")
if isClient then
    Plugins.Require("lua_inventory", "client.manager.CInventoryManager")
    Plugins.Require("lua_inventory", "client.packet.PacketHandler")
    handlers = {}
else
    Plugins.Require("lua_inventory", "server.manager.SInventoryManager")
    handlers = Plugins.Require("lua_inventory", "server.lua_inventory_server")
end

return function(name, ...)
    if type(handlers[name]) ~= "function" then
        return
    end
    handlers[name](...)
end