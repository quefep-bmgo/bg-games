---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:10
---
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")

GameMatch = {}

function GameMatch:initMatch()
    GameTimeTask:start()
    TreasureChallenge:setSeasonRefreshTimer()
end

function GameMatch:onTick(ticks)

end

function GameMatch:onPlayerQuit(player)
    local time = os.time() - player.login_time
    player.day_play_time = player.day_play_time + time
    TreasureChallenge:onPlayerLogout(player)
    QualifyingHelper:onPlayerLogout(player)
end

return GameMatch