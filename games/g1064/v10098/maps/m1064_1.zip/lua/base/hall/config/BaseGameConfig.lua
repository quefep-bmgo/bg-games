BaseGameConfig = {}

function BaseGameConfig:init()
    require "common.CommonHeader"
    require "common.config.TaskConfig"
    require "common.config.TreasureChallengeConfig"
    require "common.config.ActionEmojiConfig"
    require "common.config.EmojiConfig"
    require "common.config.CreditScoreConfig"
    require "common.config.MonthCardConfig"
end
