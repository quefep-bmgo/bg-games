---@class BackgroundConfig
local BackgroundConfig = T(Global, "BackgroundConfig")

---@type BackgroundConfigItem[]
local Configs = {}

---@class BackgroundConfigItem
---@field Id string
---@field Effect string
---@field BackImg string
---@field BackIcon string

function BackgroundConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/BackgroundSetting.csv", 3)
    for _, config in pairs(configs) do
        Configs[config.Id] = {
            Id = tonumber(config.Id),
            Effect = config.Effect,
            BackImg = config.BackImg,
            BackIcon = config.BackIcon
        }
    end
end

---@return BackgroundConfigItem
function BackgroundConfig.getConfigById(id)
    return Configs[tostring(id)]
end

BackgroundConfig:init()

return BackgroundConfig

