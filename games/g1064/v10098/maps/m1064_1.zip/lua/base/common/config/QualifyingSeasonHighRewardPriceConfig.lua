---@class QualifyingSeasonHighRewardPriceConfig
local QualifyingSeasonHighRewardPriceConfig = T(Global, "QualifyingSeasonHighRewardPriceConfig")
---@type table<number, QualifyingSeasonChallengeRewardData[]>
local Settings = {}

function QualifyingSeasonHighRewardPriceConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/QualifyingSeasonRewardHighPrice.csv", 2, true, true)
    for _, item in pairs(config) do
        ---@class QualifyingSeasonHighRewardPriceData
        local data = {
            Id = tonumber(item.Id),
            Season = tonumber(item.Season),
            Price = tonumber(item.Price) or 0,
            UniqueId = tonumber(item.UniqueId) or 0,
        }
        Settings[data.Season] = data
    end
end

function QualifyingSeasonHighRewardPriceConfig:getAllCfg()
    return Settings
end

---@return QualifyingSeasonChallengeRewardData[]
function QualifyingSeasonHighRewardPriceConfig:getCfgBySeason(seasonId)
    local seasons = {}
    for season, _ in pairs(Settings) do
        table.insert(seasons, season)
    end
    if not TableUtil.tableContain(seasons, seasonId) then
        table.sort(seasons, function(s1, s2)
            return s1 > s2
        end)
		for _, season in pairs(seasons) do
			if season < seasonId then
				seasonId = season
				break
			end
		end
    end
	return Settings[seasonId] or {}
end

QualifyingSeasonHighRewardPriceConfig:init()
