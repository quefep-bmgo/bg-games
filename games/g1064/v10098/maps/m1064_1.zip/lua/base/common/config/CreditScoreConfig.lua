---@class CreditScoreConfig
local CreditScoreConfig = T(Global, "CreditScoreConfig")
---@type CreditScoreData[]
local Settings = {}

function CreditScoreConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/CreditScore.csv", 2, true, true)
    for _, item in pairs(config) do
        ---@class CreditScoreData
        local data = {
            index = item.index,
            scoreInterval = StringUtil.split(item.scoreInterval, "#", false, true),
            level = item.level,
            icon = item.icon,
            keyBuff = tonumber(item.keyBuff),
            expBuff = tonumber(item.expBuff),
            isCanQualifying = (item.isCanQualifying == "1"),
            noNegativeScore = tonumber(item.noNegativeScore),
            noEscapeScore = tonumber(item.noEscapeScore),
            negativeScore = tonumber(item.negativeScore),
            escapeScore = tonumber(item.escapeScore),
        }
        table.insert(Settings, data)
    end
end

function CreditScoreConfig:getAllCfg()
    return Settings
end

---@return CreditScoreData
function CreditScoreConfig:getCfgByCreditScore(creditScore)
    if creditScore == nil then
        creditScore = Define.CreditScore.InitCreditScore
    end
    if creditScore > Define.CreditScore.UpperLimit then
        creditScore = Define.CreditScore.UpperLimit
    elseif creditScore < Define.CreditScore.LowerLimit then
        creditScore = Define.CreditScore.LowerLimit
    end

    for _, setting in pairs(Settings) do
        if creditScore >= setting.scoreInterval[1] and creditScore <= setting.scoreInterval[2] then
            return setting
        end
    end
    return nil
end

---@return CreditScoreData
function CreditScoreConfig:getCreditScoreUpperLimit()
    local upperLimit = 0
    for _, setting in pairs(Settings) do
        if upperLimit < setting.scoreInterval[1] then
            upperLimit = setting.scoreInterval[1]
        end
        if upperLimit < setting.scoreInterval[2] then
            upperLimit = setting.scoreInterval[2]
        end
    end
    return upperLimit
end

CreditScoreConfig:init()
