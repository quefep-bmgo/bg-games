---@class HeadImageShopConfig
local HeadImageShopConfig = T(Global, "HeadImageShopConfig")
---@type HeadImageShopItem[]
local ShopConfigs = {}

function HeadImageShopConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/HeadImageShop.csv", 3)
    for _, config in pairs(configs) do
        ---@class HeadImageShopItem
        local data = {
            Id = tonumber(config.Id),
            IsFree = tonumber(config.IsFree),
            Rank = tonumber(config.Rank),
            CanBuy = false,
            RewardId = config.RewardId,
            OpenTime = 0,
            GetWayDesc = config.GetWayDesc
        }
        if config.OpenTime and config.OpenTime ~= "#" then
            local _, _, year, month, day, hour, min, sec = string.find(config.OpenTime, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
            data.OpenTime = DateUtil.date2BeiJingTime({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
        end
        if config.CoinId ~= "#" then
            data.CanBuy = true
            data.CoinId = tonumber(config.CoinId)
            data.Price = tonumber(config.Price)
        end

        table.insert(ShopConfigs, data)
    end
    table.sort(ShopConfigs, function(a, b)
        return a.Rank < b.Rank
    end)
    ShopConfigs[1].Default = true
end

---@param id number
---@return HeadImageShopItem | nil
function HeadImageShopConfig:getShopConfigById(id)
    for _, config in pairs(ShopConfigs) do
        if config.Id == tonumber(id) then
            return config
        end
    end
    return nil
end

function HeadImageShopConfig:getShopAllConfigs()
    return ShopConfigs
end

---@return HeadImageShopItem[]
function HeadImageShopConfig:getShopConfigs()
    local configs = {}
    local nowTime = os.time()
    for _, config in pairs(ShopConfigs) do
        if nowTime > config.OpenTime then
            table.insert(configs, config)
        end
    end
    if #configs > 0 then
        configs[1].Default = true
    end
    return configs
end

function HeadImageShopConfig:getDefaultFrame()
    return ShopConfigs[1]
end

HeadImageShopConfig:init()

return HeadImageShopConfig