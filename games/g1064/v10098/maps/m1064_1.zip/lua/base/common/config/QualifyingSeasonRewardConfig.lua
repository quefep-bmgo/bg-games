---@class QualifyingSeasonRewardConfig
local QualifyingSeasonRewardConfig = T(Global, "QualifyingSeasonRewardConfig")
---@type table<number, QualifyingSeasonChallengeRewardData[]>
local Settings = {}

function QualifyingSeasonRewardConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/QualifyingSeasonReward.csv", 2, true, true)
    for _, item in pairs(config) do
        ---@class QualifyingSeasonRewardData
        local data = {
            Id = tonumber(item.Id),
            Season = tonumber(item.Season),
            qualifying = {
                segment = tonumber(item.Segment) or 0,
                grade = tonumber(item.Grade) or 0,
                starNumber = 1
            },
            NormalRewardId = tonumber(item.NormalRewardId),
            NormalRewardCount = tonumber(item.NormalRewardCount) or 0,
            HighRewardId = tonumber(item.HighRewardId),
            HighRewardCount = tonumber(item.HighRewardCount) or 0,
        }
        local items = Settings[data.Season] or {}
        table.insert(items, data)
        Settings[data.Season] = items
    end
end

function QualifyingSeasonRewardConfig:getAllCfg()
    return Settings
end

---@return QualifyingSeasonChallengeRewardData[]
function QualifyingSeasonRewardConfig:getCfgBySeason(seasonId)
    local seasons = {}
    for season, _ in pairs(Settings) do
        table.insert(seasons, season)
    end
    if not TableUtil.tableContain(seasons, seasonId) then
        table.sort(seasons, function(s1, s2)
            return s1 > s2
        end)
		for _, season in pairs(seasons) do
			if season < seasonId then
				seasonId = season
				break
			end
		end
    end
	return Settings[seasonId] or {}
end

---@return QualifyingSeasonChallengeRewardData
function QualifyingSeasonRewardConfig:getCfgById(seasonId, id)
    local items = self:getCfgBySeason(seasonId)
    for _, item in pairs(items) do
        if item.Id == id then
            return item
        end
    end
    LogUtil.logError("can't find QualifyingSeasonRewardConfig ", id)
	return nil
end

QualifyingSeasonRewardConfig:init()
