

---@class PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")
local Config = {}
local ImbueLvSetting = {}

if not Plugins.IsLoaded("imbue") then
    return
end

local function getItemName(itemId)
    local goods = StoreConfig:getGoodsByItemId(itemId)
    if goods and goods.showDetail and goods.Count == 1 then
        return Lang:getString(goods.showDetail.name)
    end
    return Lang:getItemName(itemId)
end

local DescFunc = {
    [Define.ImbueType.ExtraSwordImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate, params[2])
    end,
    [Define.ImbueType.ExtraArrowImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate, params[2])
    end,
    [Define.ImbueType.PropEDImbue] = function(desc, params)
        local itemName = getItemName(tonumber(params[1]))
        return string.format(Lang:getString(desc), itemName, params[2])
    end,
    [Define.ImbueType.ProductionImbue] = function(desc, params)
        local itemName = getItemName(tonumber(params[3]))
        if tonumber(params[3]) == BlockID.CLOTH then
            itemName = Lang:getString("CustomShopTabs_Lang_2")
        end
        return string.format(Lang:getString(desc), params[1], params[2], itemName)
    end,
    [Define.ImbueType.PickUpRewardImbue] = function(desc, params)
        local itemName = getItemName(tonumber(params[1]))
        local rate = math.modf(tonumber(params[2]) / 100)
        return string.format(Lang:getString(desc), itemName, rate, params[3], params[4])
    end,
    [Define.ImbueType.ReturnFireBallImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate, params[2])
    end,
    [Define.ImbueType.InitItemImbue] = function(desc, params)
        local items = StringUtil.split(params[1], "#")
        local num = StringUtil.split(params[2], "#")
        local str = {}
        for i, id in pairs(items) do
            local itemName = getItemName(tonumber(id))
            table.insert(str, itemName .. "(" .. num[i] .. ")")
        end
        return string.format(Lang:getString(desc), table.concat(str, "、"))
    end,
    [Define.ImbueType.DoubleJumpImbue] = function(desc, params)
        local height = tonumber(params[1]) * 100
        local rate = math.ceil((height - 42) / 42 * 100)
        return string.format(Lang:getString(desc), rate)
    end,
    [Define.ImbueType.OnDieCountDownImbue] = function(desc, params)
        local value = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), value)
    end,
    [Define.ImbueType.KnockBackImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate)
    end
}

function PetLvConfig:init()
    local ImbueConfig = FileUtil.getConfigFromCsv("setting/ImbueClassSetting.csv", 3)
    for _, config in pairs(ImbueConfig or {}) do
        if tonumber(config.Type) == 2 and config.Group ~= 0 then
            ---@class PetLvItemConfig
            local data = {}
            data.type = tonumber(config.Type) or 0
            data.level = tonumber(config.Level) or 0
            data.group = tonumber(config.Group) or 0
            data.imbueId = tonumber(config.Id)
            data.moneyType = Define.Money.PET_CANDY
            data.price = tonumber(config.Price)
            data.imbueType = tonumber(config.ImbueType)
            data.values = {}
            for i = 1, 4 do
                if tonumber(config["Value"..i]) ~= 0 then
                    table.insert(data.values,config["Value"..i])
                end
            end
            local list = ImbueLvSetting[data.group]
            if not list then
                ImbueLvSetting[data.group] = {}
            end
            ImbueLvSetting[data.group][tostring(data.level)] = data
        end
    end

    local config = FileUtil.getConfigFromCsv("setting/PetLv.csv")
    for _, vConfig in pairs(config) do
        local data = {
            petId = tonumber(vConfig.petId),
            imbueGroupId = tonumber(vConfig.imbueGroupId),
            maxLv = tonumber(vConfig.maxLv),
            noEquipSame = vConfig.noEquipSame == "1" or false
        }
        if isClient then
            data.icon = vConfig.icon
            data.desc = vConfig.desc
        end
        local imbueLevelCfg = ImbueLvSetting[data.imbueGroupId]
        if imbueLevelCfg then
            data.lvCfg = imbueLevelCfg
        end
        Config[tostring(data.petId)] = data
    end
end

---@return PetLvItemConfig
function PetLvConfig:getConfigByLv(petId, lv)
    local configs = Config[tostring(petId)] or {}
    if configs.lvCfg then
        return TableUtil.copyTable(configs.lvCfg[tostring(lv)])
    end
    return {}
end

function PetLvConfig:isMaxLv(petId, lv)
    local config = Config[tostring(petId)] or {}
    return lv >= config.maxLv
end

function PetLvConfig:getDesc(petId, lv)
    local config = PetLvConfig:getConfigByLv(petId, lv)
    if not config.imbueType then
        return ""
    end
    local uiConfig = Config[tostring(petId)] or {}
    if not uiConfig then
        return ""
    end
    local imbueType = config.imbueType
    local params = config.values
    if DescFunc[imbueType] then
        return DescFunc[imbueType](uiConfig.desc, params)
    end
    if #params == 1 then
        return string.format(Lang:getString(uiConfig.desc), params[1])
    elseif #params == 2 then
        return string.format(Lang:getString(uiConfig.desc), params[1], params[2])
    elseif #params == 3 then
        return string.format(Lang:getString(uiConfig.desc), params[1], params[2], params[3])
    elseif #params == 4 then
        return string.format(Lang:getString(uiConfig.desc), params[1], params[2], params[3], params[4])
    end
end

function PetLvConfig:getIcon(petId)
    local config = Config[tostring(petId)] or {}
    return config.icon or ""
end

function PetLvConfig:getMaxLv(petId)
    local config = Config[tostring(petId)] or {}
    return config.maxLv or 0
end

function PetLvConfig:getCanEquipSame(petId)
    local config = Config[tostring(petId)] or {}
    return not (config.noEquipSame or false)
end

PetLvConfig:init()

return PetLvConfig