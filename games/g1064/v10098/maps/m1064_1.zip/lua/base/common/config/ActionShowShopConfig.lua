
---@class ActionShowShopConfig
local ActionShowShopConfig = T(Global, "ActionShowShopConfig")
---@type ActionShowShopItem[]
local ShopConfigs = {}
local DefaultItem = {}

function ActionShowShopConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/ActionShowShop.csv", 3)
    for _, config in pairs(configs) do
        ---@class ActionShowShopItem
        local data = {
            Id = tonumber(config.Id),
            Rank = tonumber(config.Rank),
            CanBuy = false,
            RewardId = config.RewardId,
            GetWayDesc = config.GetWayDesc,
            RewardDetail = tonumber(config.RewardDetail),
            NotOwned = config.NotOwned == "1"
        }
        if config.CoinId ~= "#" then
            data.CanBuy = true
            data.CoinId = tonumber(config.CoinId)
            data.Price = tonumber(config.Price)
        end
        if data.Id == 0 then
            data.Default = true
            DefaultItem = data
        end

        table.insert(ShopConfigs, data)
    end
    table.sort(ShopConfigs, function(a, b)
        return a.Rank < b.Rank
    end)
end

---@param id number
---@return ActionShowShopItem | nil
function ActionShowShopConfig:getShopConfigById(id)
    for _, config in pairs(ShopConfigs) do
        if config.Id == tonumber(id) then
            return config
        end
    end
    return nil
end

---@return ActionShowShopItem[]
function ActionShowShopConfig:getShopConfigs()
    return TableUtil.copyTable(ShopConfigs)
end

---@return ActionShowShopItem
function ActionShowShopConfig:getDefault()
    return DefaultItem
end

ActionShowShopConfig:init()

return ActionShowShopConfig