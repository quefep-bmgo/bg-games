---@class HeadImageConfig
local HeadImageConfig = T(Global, "HeadImageConfig")

local Configs = {}

function HeadImageConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/HeadImageSetting.csv", 3)
    for _, config in pairs(configs) do
        Configs[config.Id] = {
            Id = tonumber(config.Id),
            Frame = config.Frame,
            FrameEffect = config.FrameEffect
        }
    end
end

function HeadImageConfig.getConfigById(id)
    return Configs[tostring(id)]
end

function HeadImageConfig.getDefaultImage()
    return Configs["0"]
end

HeadImageConfig:init()

return HeadImageConfig

