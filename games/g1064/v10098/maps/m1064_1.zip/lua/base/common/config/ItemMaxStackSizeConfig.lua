---@class ItemMaxStackSizeConfig
local ItemMaxStackSizeConfig = T(Global, "ItemMaxStackSizeConfig")
---@type ItemMaxStackSizeData[]
local Settings = {}

local function setItemMaxStack(itemId, maxStackSize)
    local Item = Item.getItemById(itemId)
    if Item then
        Item:setMaxStackSize(maxStackSize)
    else
        local block = BlockManager.getBlockById(itemId)
        if block then
            ---自定义方块
            local BlockItem = Item.getItemById(itemId + 1000)
            if BlockItem then
                BlockItem:setMaxStackSize(maxStackSize)
            end
        end
    end
end

function ItemMaxStackSizeConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/ItemMaxStackSize.csv")
    for _, item in pairs(config) do
        ---@class ItemMaxStackSizeData
        local data = {
            id = item.id,
            itemId = item.itemId,
            maxStackSize = item.maxStackSize,
        }
        setItemMaxStack(data.itemId, data.maxStackSize)
        Settings[data.id] = data
    end
end

function ItemMaxStackSizeConfig:getAllCfg()
    return Settings
end

---@return ItemMaxStackSizeData
function ItemMaxStackSizeConfig:getCfgById(id)
    return Settings[id]
end

ItemMaxStackSizeConfig:init()
