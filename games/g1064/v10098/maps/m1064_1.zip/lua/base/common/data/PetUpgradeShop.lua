---@class PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")
---@type PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")

function PetUpgradeShop:init()

end

function PetUpgradeShop:onUpgradePet(player, petId)
    local data = player.petData
    local lv = data[tostring(petId)] or -1
    if PetLvConfig:isMaxLv(petId, lv) then
        return
    end
    local nextLv = lv + 1
    local config = PetLvConfig:getConfigByLv(petId, nextLv)
    if isClient then
        PayHelper.checkMoney(config.moneyType, config.price, function(canBuy)
            if canBuy then
                CommonPacketSender:sendUpgradePet(petId)
            else
            end
        end)
    else
        if config.moneyType == Define.Money.PET_CANDY and MoneyUtil:checkHasMoney(player, config.moneyType, config.price) then
            if player:subPetCandy(config.price) then
                self:onUpgradePetSuss(player, petId)
            end
        end
    end
end

function PetUpgradeShop:onUpgradePetSuss(player, petId)
    local data = player.petData
    local lv = data[tostring(petId)] or -1
    if PetLvConfig:isMaxLv(petId, lv) then
        return
    end
    player.petData[tostring(petId)] = lv + 1
    local params = {}
    params[tostring(petId)] = lv + 1
    ServerReportEvent.pet_upgrade(player, tonumber(petId), lv + 1)
    CommonPacketSender:sendSyncPetLvData(player.rakssid, params)
end

function PetUpgradeShop:isMaxLv(player, petId)
    local data = player.petData
    local lv = data[tostring(petId)] or -1
    return PetLvConfig:isMaxLv(petId, lv)
end

function PetUpgradeShop:syncPetLvData(player)
    CommonPacketSender:sendSyncPetLvData(player.rakssid, player.petData)
end

function PetUpgradeShop:checkCanEquip(player, petId, ignoreIndex)
    local canEquipSame = PetLvConfig:getCanEquipSame(petId)
    if not canEquipSame then
        local data = player.petData
        local lv = data[tostring(petId)] or 0
        local config = PetLvConfig:getConfigByLv(petId, lv)
        local info = isClient and GameInfoManager:getPlayerInfo(Game:getPlatformUserId()) or player.info
        if not info then
            return true
        end
        local petsStr = info:getValue("curPets")
        local pets = StringUtil.split(petsStr, ",", false, true)
        ignoreIndex = ignoreIndex or 0
        if type(pets) == "table" then
            for index, _petId in pairs(pets) do
                if _petId ~= 0 and index ~= ignoreIndex then
                    local _lv = data[tostring(_petId)] or 0
                    local _config = PetLvConfig:getConfigByLv(_petId, _lv)
                    if config.imbueType == _config.imbueType then
                        return false
                    end
                end
            end
        end
    end
    return true
end