---@class MonthCardConfig
local MonthCardConfig = T(Global, "MonthCardConfig")

---@type MonthCardConfigData[]
local settings = {}
local compensateSettings = {}

function MonthCardConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/MonthCard.csv", 3)
    for _, item in pairs(config) do
        ---@class MonthCardConfigData
        local data = {
            id = tonumber(item.Id),
            price = tonumber(item.Price),
            firstPrice = tonumber(item.FirstPrice),
            renewPrice = tonumber(item.RenewPrice),
            time = tonumber(item.Time),
            rewardItemId = tonumber(item.RewardItemId),
            rewardItemNum = tonumber(item.RewardItemNum),
            percent = item.Percent,
        }
        settings[data.id] = data
    end

    -- 补偿逻辑
    if not isClient then
        config = FileUtil.getConfigFromCsv("setting/MonthCardCompensate.csv", 3)
        for _, item in pairs(config) do
            local data = {
                id = tonumber(item.Id),
                userId = tonumber(item.UserId),
                cardId = tonumber(item.CardId),
                time = tonumber(item.Time),
            }
            compensateSettings[data.id] = data
        end
    end
end

function MonthCardConfig:getAllCfg()
    return settings
end

---@return MonthCardConfigData
function MonthCardConfig:getCfgById(id)
    return settings[tonumber(id)]
end

function MonthCardConfig:getCompensateCfgByUserId(userId)
    local data = {}
    for i, v in pairs(compensateSettings) do
        if v.userId == userId then
            table.insert(data, v)
        end
    end
    return data
end

MonthCardConfig:init()