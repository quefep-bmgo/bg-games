---@class EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")
---@type EmojiData[]
local Settings = {}
---@type TabSettingsData[]
local TabSettings = {}
---@type EmojiTabData
local TabData = {}

function EmojiConfig:init()
	local config = FileUtil.getConfigFromCsv("setting/Emoji.csv", 2, true, true)
	for _, item in pairs(config) do
		---@class EmojiData
		local data = {
			id = tonumber(item.id),
			rewardId = item.rewardId == "#" and 0 or tonumber(item.rewardId),
			icon = item.icon,
			name = item.name,
			effect = item.effect,
			tabId = tonumber(item.tabId),
			moneyType = tonumber(item.moneyType),
			canBuy = item.canBuy == "1",
			price = tonumber(item.price),
		}
		Settings[data.id] = data

		if not TabSettings[data.tabId] then
			TabSettings[data.tabId] = {}
		end
		---@class TabSettingsData
		table.insert(TabSettings[data.tabId], data)
	end

	config = FileUtil.getConfigFromCsv("setting/EmojiTab.csv", 2, true, true)
	for _, item in pairs(config) do
		---@class EmojiTabData
		local data = {
			id = tonumber(item.id),
			icon = item.icon,
		}
		TabData[data.id] = data
	end
end

function EmojiConfig:getAllCfg()
	return Settings
end

---@return EmojiData
function EmojiConfig:getCfgById(id)
	return Settings[tonumber(id)]
end

function EmojiConfig:getCfgByRewardId(rewardId)
	for i, v in pairs(Settings) do
		if v.rewardId == tonumber(rewardId) then
			return v
		end
	end
	LogUtil.logError("EmojiConfig:getCfgByRewardId can not find id = ", rewardId)
end

---@return EmojiData
function EmojiConfig:getCfgByIcon(icon)
	for _, item in pairs(Settings) do
		if item.icon == icon then
			return item
		end
	end
	return nil
end

function EmojiConfig:getTabCfg()
	return TabData
end

function EmojiConfig:getCfgByTabId(tabId)
	return TabSettings[tonumber(tabId)] or {}
end

EmojiConfig:init()
