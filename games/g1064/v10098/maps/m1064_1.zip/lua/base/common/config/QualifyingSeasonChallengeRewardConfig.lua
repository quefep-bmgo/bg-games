---@class QualifyingSeasonChallengeRewardConfig
local QualifyingSeasonChallengeRewardConfig = T(Global, "QualifyingSeasonChallengeRewardConfig")
---@type table<number, QualifyingSeasonChallengeRewardData[]>
local Settings = {}

function QualifyingSeasonChallengeRewardConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/QualifyingSeasonChallengeReward.csv", 2, true, true)
    for _, item in pairs(config) do
        ---@class QualifyingSeasonChallengeRewardData
        local data = {
            Id = tonumber(item.Id),
            Season = tonumber(item.Season),
            Score = tonumber(item.Score),
            RewardId = tonumber(item.RewardId),
            ShowEffect = item.ShowEffect == "1",
            IsGrandPrize = item.IsGrandPrize == "1",
            ShowDetailId = tonumber(item.ShowDetailId) or 0,
            RewardCount = tonumber(item.RewardCount) or 0,
        }
        local items = Settings[data.Season] or {}
        table.insert(items, data)
        Settings[data.Season] = items
    end
end

function QualifyingSeasonChallengeRewardConfig:getAllCfg()
    return Settings
end

---@return QualifyingSeasonChallengeRewardData[]
function QualifyingSeasonChallengeRewardConfig:getCfgBySeason(seasonId)
    local seasons = {}
    for season, _ in pairs(Settings) do
        table.insert(seasons, season)
    end
    if not TableUtil.tableContain(seasons, seasonId) then
        table.sort(seasons, function(s1, s2)
            return s1 > s2
        end)
		for _, season in pairs(seasons) do
			if season < seasonId then
				seasonId = season
				break
			end
		end
    end
	return Settings[seasonId] or {}
end

---@return QualifyingSeasonChallengeRewardData
function QualifyingSeasonChallengeRewardConfig:getCfgById(seasonId, id)
    local items = self:getCfgBySeason(seasonId)
    for _, item in pairs(items) do
        if item.Id == id then
            return item
        end
    end
	return nil
end

QualifyingSeasonChallengeRewardConfig:init()
