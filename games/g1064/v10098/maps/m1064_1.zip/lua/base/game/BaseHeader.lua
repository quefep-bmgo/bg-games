require "game.config.BaseGameConfig"

LogUtil.setDebug(false)