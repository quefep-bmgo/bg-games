BaseGameConfig = {}

function BaseGameConfig:init()
    require "common.CommonHeader"
    require "common.config.ActionEmojiConfig"
    require "common.config.EmojiConfig"
    require "survival.config.ItemDetailConfig"
end
