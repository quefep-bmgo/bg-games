---@class ItemDetailConfig
local ItemDetailConfig = T(Global, "ItemDetailConfig")
---@type ItemDetailData[]
local Settings = {}


function ItemDetailConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/ItemDetail.csv", 2, true, true)
    for _, item in pairs(config) do
        ---@class ItemDetailData
        local data = {
            id = tonumber(item.id),
            itemId = tonumber(item.itemId),
            type = tonumber(item.type) or 0,
            icon = item.icon or "#",
            iconSmall = item.iconSmall or "#",
            nameLang = item.nameLang or "#",
            descLang = item.descLang or "#",
            mesh = item.mesh or "#",
            qualityType = tonumber(item.qualityType) or 0
        }
        Settings[data.itemId] = data
    end
end

function ItemDetailConfig:getAllCfg()
    return Settings
end

---@return ItemDetailData
function ItemDetailConfig:getCfgByItemId(itemId)
    return Settings[tonumber(itemId)] or {}
end

ItemDetailConfig:init()
