---@class GuideProcessSettingConfig
local GuideProcessSettingConfig = T(Global, "GuideProcessSettingConfig")
---@type GuideProcessSettingData[]
local Settings = {}

function GuideProcessSettingConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/GuideProcessSetting.csv")
    for _, item in pairs(config) do
        ---@class GuideProcessSettingData
        local data = {
            processId = tonumber(item.processId),
            processGroupId = tonumber(item.processGroupId),
            isMustFinish = (item.isMustFinish == "1") or false ,
            beginEvent = tonumber(item.beginEvent),
            beginParam = item.beginParam,
            finishEvent = tonumber(item.finishEvent),
            finishParam = item.finishParam,
            processTip = item.processTip,
            enableMove = item.enableMove,
        }
        if not Settings[data.processGroupId] then
            Settings[data.processGroupId] = {}
        end
        table.insert(Settings[data.processGroupId], data)
    end
end

function GuideProcessSettingConfig:getAllCfg()
    return Settings
end

---@return GuideProcessSettingData
function GuideProcessSettingConfig:getCfgByProcessGroupId(id)
    return Settings[id]
end

GuideProcessSettingConfig:init()
