---@class GuideNodesSettingConfig
local GuideNodesSettingConfig = T(Global, "GuideNodesSettingConfig")
---@type GuideNodesSettingData[]
local Settings = {}

function GuideNodesSettingConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/GuideNodesSetting.csv")
    for _, item in pairs(config) do
        ---@class GuideNodesSettingData
        local data = {
            nodeId = tonumber(item.nodeId),
            processGroupId = tonumber(item.processGroupId),
            spawnPos = VectorUtil.str2Vector3(item.spawnPos),
            initYaw = tonumber(item.initYaw),
            initItems = StringUtil.split(item.initItems, "&"),
        }
        table.insert(Settings,data)
    end

    table.sort(Settings,function(a, b)
        return a.nodeId < b.nodeId
    end)
end

function GuideNodesSettingConfig:getAllCfg()
    return Settings
end

---@return GuideNodesSettingData
function GuideNodesSettingConfig:getCfgById(id)
    return Settings[id]
end

GuideNodesSettingConfig:init()
