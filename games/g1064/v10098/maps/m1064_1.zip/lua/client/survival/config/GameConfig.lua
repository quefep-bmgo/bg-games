
GameConfig = {}