local function hideEngineWindow(name)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetXPosition({ 0, 6000 })
    window:SetVisible(false)
end

local function setTouchable(window, visible)
    window:SetTouchable(visible)
    local count = window:GetChildCount()
    if count == 0 then
        return
    end
    for index = 1, count do
        setTouchable(window:GetChildByIndex(index - 1), visible)
    end
end

---@class UIGuideMain : IGUILayout
local UIGuideMain = class("UIGuideMain", IGUILayout)

function UIGuideMain:onLoad()
    self.btnStore = self:getChildWindow("BedWarGuideMain-Store-Btn", GUIType.Button)
    self.btnUpgradeStore = self:getChildWindow("BedWarGuideMain-UpgradeStore-Btn", GUIType.Button)

    self.ivScreenEffect = self:getChildWindow("BedWarGuideMain-Screen-Effect", GUIType.StaticImage)
    self.ivScreenEffect:SetVisible(false)

    self.ivTouchEffect = self:getChildWindow("BedWarGuideMain-Touch-Effect", GUIType.StaticImage)
    self.ivTouchEffect:SetVisible(false)

    self.ivClickScreenEffect = self:getChildWindow("BedWarGuideMain-ClickScreen-Effect", GUIType.StaticImage)
    self.stClickScreen = self:getChildWindow("BedWarGuideMain-ClickScreen-Tip", GUIType.StaticText)
    self.ivClickScreenEffect:SetVisible(false)

    self.lyPersonView = self:getChildWindow("BedWarGuideMain-PersonView", GUIType.Layout)
    self.siPersonView = self:getChildWindow("BedWarGuideMain-PersonView-Image", GUIType.StaticImage)
    self.lyPersonView:SetVisible(false)

    self.btnSkip = self:getChildWindow("BedWarGuideMain-Skip", GUIType.Button)

    self.siGuideTip = self:getChildWindow("BedWarGuideMain-Guide-Tip", GUIType.StaticImage)
    self.stGuideTipText = self:getChildWindow("BedWarGuideMain-Guide-Tip-Text", GUIType.StaticText)

    self.btnUpgradeStore:SetVisible(false)
    self:setEngineUIStyle()
    self:initView()
    self:register()
end

function UIGuideMain:initView()
    self.btnSkip:SetText(Lang:getString("gui.guide.skip.button"))
    self.btnSkip:SetWidth({ 0, self.btnSkip:GetTextWidth() + 35 })
end

function UIGuideMain:setEngineUIStyle()
    ClientHelper.putFloatPrefs("PoleControlMaxDistance", 65)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaNormal", 1)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaPress", 1)
    local ivPoleArrow = GUIManager:getWindowByName("Main-PoleControl-Arrow", GUIType.StaticImage)
    ivPoleArrow:SetImage("set:pole.json image:pole_arrow")
    local wMoveState = GUIManager:getWindowByName("Main-MoveState")
    wMoveState:SetArea({ 10, 0 }, { 10, 0 }, { 0, 70 }, { 0, 70 })
    local wJumControls = GUIManager:getWindowByName("Main-Jump-Controls")
    wJumControls:SetArea(wJumControls:GetXPosition(), wJumControls:GetYPosition(), { 0, 138 }, { 0, 377 })
    local btnSkillRelease = GUIManager:getWindowByName("Main-Skill-Release-btn", GUIType.Button)
    btnSkillRelease:SetNormalImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetPushedImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetArea(btnSkillRelease:GetXPosition(), btnSkillRelease:GetYPosition(), { 0, 120 }, { 0, 120 })
    self.btnSkill = btnSkillRelease
    local btnCannon = GUIManager:getWindowByName("Main-Cannon", GUIType.Button)
    btnCannon:SetNormalImage("set:bedwarsmall.json image:btn_0_fort")
    btnCannon:SetPushedImage("set:bedwarsmall.json image:btn_0_fort")
    local ivSneak = GUIManager:getWindowByName("Main-MoveState-Sneak", GUIType.StaticImage)
    ivSneak:SetImage("set:move_state.json image:sneak_circle")
    local btnFly = GUIManager:getWindowByName("Main-Fly", GUIType.Button)
    btnFly:SetNormalImage("set:bedwarsmall.json image:fly")
    btnFly:SetPushedImage("set:bedwarsmall.json image:fly")
    btnFly:SetArea(btnFly:GetXPosition(), btnFly:GetYPosition(), { 0, 70 }, { 0, 70 })
    hideEngineWindow("Main-Player-Exp")
    hideEngineWindow("Main-Chat-Message")
    hideEngineWindow("Main-Gun-Operate-ReloadBtn")

    local bgWatch = GUIManager:getWindowByName("Main-Watch-Battle-Bg", GUIType.StaticImage)
    bgWatch:SetProperty("StretchOffset", "60 10 0 0")
    bgWatch:SetImage("set:bedwar_toolbar.json image:bg_onWatch")
    GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetHeight({ 0, 49 })
    GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetWidth({ 0, 250 })
    GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetArea({ 0, 50 }, { 0, 0 }, { 1, -50 }, { 1, 0 })
    GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetHorizontalAlignment(HorizontalAlignment.Left)

    GUIManager:getWindowByName("MenuPlayer-PlayerList"):SetVisible(false)
end

function UIGuideMain:register()
    self.btnStore:registerEvent(GUIEvent.ButtonClick, function()
        if true then
            GUIStore:show(StoreId.GoodsStore, nil, true)
        else
            CustomDialog.builder().setContentText(Lang:getString("gui.message.not.start"))
                        .setLeftText("gui_dialog_tip_btn_cancel")
                        .setRightText("gui_dialog_tip_btn_sure")
                        .show()
        end
    end)

    self.lyPersonView:registerEvent(GUIEvent.Click, function()
        local cruCamera = SystemSettingRecord.defaultCamera
        if cruCamera == 1 then
            GUIBedWarSetting:changeCamera(2)
            SystemSettingRecord.defaultCamera = 2
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective3_normal")
        elseif cruCamera == 2 then
            GUIBedWarSetting:changeCamera(1)
            SystemSettingRecord.defaultCamera = 1
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
        elseif cruCamera == 3 then
            GUIBedWarSetting:changeCamera(1)
            SystemSettingRecord.defaultCamera = 1
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
        end
    end)

    self.btnSkip:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui.guide.skip.title")
                    .setHideLeftButton()
                    .setContentText(Lang:getString("gui.guide.skip.tip"))
                    .setRightClickListener(function()
            PlayerManager:getClientPlayer():sendPacket({
                pid = "skipGuide"
            })
        end)
                    .show()
    end)

    self:registerEvent(Events.ShowFrontPlaceBlockEvent, function()
        local heldItemId = Game:getPlayer():getHeldItemId()
        ---过滤有技能的方块
        local skill = SkillConfig:getSkill(heldItemId)
        if skill then
            return false
        end
        ---过滤保护墙和防御
        if heldItemId == 2418 or heldItemId == 2417 then
            return false
        end
        return true
    end)
end

function UIGuideMain:upScreenEffect(time)
    self.ivScreenEffect:SetVisible(true)
    self.ivScreenEffect:SetEffectName("g1008_radar_ui.effect")
    LuaTimer:cancel(self.screen_key or 0)
    self.screen_key = LuaTimer:scheduleWithEnd(function()
    end, function()
        self.ivScreenEffect:SetVisible(false)
    end, time * 1000)
end

local function checkOnMount()
    local entityPlayer = PlayerManager:getClientPlayer().Player
    if entityPlayer then
        if entityPlayer:isOnFloatingMount() or entityPlayer:isOnFlyingMount() then
            return true
        end
    end
    return false
end

function UIGuideMain:onTick(frameTime)
    GUIPlayerInventory:onTick(frameTime)

    local onMount = checkOnMount()
    GUIBedWarToolBar.btnChangeCamera:SetEnabled(not onMount)
    GUISystem.Instance():handleTouchLeaveTesting()
end

function UIGuideMain:cameraChange()
    local cruCamera = Blockman.Instance():getCurrPersonView()
    if cruCamera == 1 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective3_normal")
    elseif cruCamera == 2 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective2_normal")
    elseif cruCamera == 0 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
    end
end

function UIGuideMain:showGuideTip(tip)
    self.siGuideTip:SetVisible(true)
    self.stGuideTipText:SetText(Lang:getString(tip or ""))
end

function UIGuideMain:hideGuideTip()
    self.siGuideTip:SetVisible(false)
end

function UIGuideMain:showClickScreenGuideEffect(screenPos)
    self.ivClickScreenEffect:SetXPosition({ screenPos.x, -50 })
    self.ivClickScreenEffect:SetYPosition({ screenPos.y, -100 })
    self.ivClickScreenEffect:SetVisible(true)
end

function UIGuideMain:setClickScreenGuideEffect(effectName)
    self.ivClickScreenEffect:SetEffectName(effectName)
end

function UIGuideMain:hideClickScreenGuideEffect()
    self.ivClickScreenEffect:SetVisible(false)
end

function UIGuideMain:setClickScreenGuideText(text)
    self.stClickScreen:SetText(Lang:getString(text or ""))
end

return UIGuideMain
