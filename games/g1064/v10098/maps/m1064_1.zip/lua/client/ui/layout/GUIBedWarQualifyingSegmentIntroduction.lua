---@class UIBedWarQualifyingSegmentIntroductionLayout : IGUILayout
local UIBedWarQualifyingSegmentIntroductionLayout = class("UIBedWarQualifyingSegmentIntroductionLayout", IGUILayout)

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingSegmentIntroduction.json", parent)
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:onLoad()
    self.btnCloseMask = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Close-Mask", GUIType.Button)
    self.llMain = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Main", GUIType.Layout)
    self.llContent = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Content", GUIType.Layout)
    self.siPre = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Pre", GUIType.StaticImage)
    self.siNext = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Next", GUIType.StaticImage)
    self.llStar = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Star", GUIType.Layout)
    self.starList = {
        self:getChildWindow("BedWarQualifyingSegmentIntroduction-Star1", GUIType.StaticImage),
        self:getChildWindow("BedWarQualifyingSegmentIntroduction-Star2", GUIType.StaticImage),
        self:getChildWindow("BedWarQualifyingSegmentIntroduction-Star3", GUIType.StaticImage),
        self:getChildWindow("BedWarQualifyingSegmentIntroduction-Star4", GUIType.StaticImage),
        self:getChildWindow("BedWarQualifyingSegmentIntroduction-Star5", GUIType.StaticImage),
    }
    self.stTitle = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Title", GUIType.StaticText)
    self.btnClose = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Close", GUIType.Button)
    self.siTipBg = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Tip-Bg", GUIType.StaticImage)
    self.stTip = self:getChildWindow("BedWarQualifyingSegmentIntroduction-Tip", GUIType.StaticText)
    self.curToOffset = 0
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:initView()
    self.stTitle:SetText(Lang:getString("gui.qualifying.introduction.title"))
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:initEvent()
    self.btnCloseMask:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.siPre:registerEvent(GUIEvent.Click, function()
        local toOffset = self.curToOffset + self.itemWidth
        self:animScroll(toOffset)
    end)
    self.siNext:registerEvent(GUIEvent.Click, function()
        local toOffset = self.curToOffset - self.itemWidth
        self:animScroll(toOffset)
    end)
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:correctHonorItems()
    local container = self.lvHonors.root:GetChildByIndex(0)
    if not container then
        return
    end
    local offset = self.lvHonors.root:GetScrollOffset()
    local index = math.floor((math.abs(offset) / self.itemWidth) + 0.5)
    self:animScroll(-index * self.itemWidth)
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:animScroll(toOffset)
    if not self.lvHonors or self.lvHonors.root:GetChildCount() == 0 then
        return
    end
    local maxOffset = self.itemWidth * self.lvHonors:getItemCount() - self.lvHonors.root:GetPixelSize().x
    self.curToOffset = math.max(math.min(toOffset, 0), -maxOffset)
    self.siPre:SetVisible(self.curToOffset < 0)
    self.siNext:SetVisible(self.curToOffset > -maxOffset)
    local fromOffset = self.lvHonors.root:GetScrollOffset()
    local times = math.floor(math.abs(toOffset - fromOffset) / 25) + 1
    LuaTimer:cancel(self.animKey)
    self.animKey = LuaTimer:scheduleTimerWithEnd(function()
        if toOffset > fromOffset then
            fromOffset = fromOffset + 25
            if fromOffset > toOffset then
                fromOffset = toOffset
            end
        else
            fromOffset = fromOffset - 25
            if fromOffset < toOffset then
                fromOffset = toOffset
            end
        end
        self.lvHonors.root:SetScrollOffset(fromOffset)
    end, function()
        self:updateSelectUI()
    end, 20, times)
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:updateSelectUI()
    local offset = self.lvHonors.root:GetScrollOffset()
    local rank = math.floor((math.abs(offset) / self.itemWidth) + 0.5) + 1
    self.stTip:SetText(Lang:getString("gui.qualifying.introduction.tip." .. rank))
    self.siTipBg:SetWidth({ 0, math.max(self.stTip:GetTextWidth() + 50, 600) })
    self.llStar:SetVisible(true)
    if rank == 8 then
        QualifyingTool.setQualifyingStarUI(7, 50, self.starList)
    else
        QualifyingTool.setQualifyingStarUI(rank, nil, self.starList)
    end
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:updateHonorItemSize()
    local centerX = self.root:GetPixelSize().x / 2
    ---@param item GUIBedWarQualifyingSegmentIntroductionItemWindow
    for _, item in pairs(self.lvHonors.items) do
        item:updateSize(centerX)
    end
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:onShow()
    self:initHonorRankList()
end

---@private
function UIBedWarQualifyingSegmentIntroductionLayout:initHonorRankList()
    if self.lvHonors then
        return
    end

    self.itemWidth = math.floor((self.llContent:GetPixelSize().x - 100) / 3)
    local itemHeight = self.itemWidth * 323 / 317
    local offset = math.floor(self.llContent:GetPixelSize().y - itemHeight)
    local topOffset = 0
    if offset > 70 then
        topOffset = (offset - 70) / 2
    end
    local bottomOffset = offset - topOffset
    self.lvHonors = IGUIListView.new("BedWarQualifyingSegmentIntroduction-Honors", self.llContent, nil, Orientation.Horizontal)
    self.lvHonors.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.lvHonors.root:SetItemWidth(self.itemWidth)
    self.lvHonors:setArea({ 0, 0 }, { 0, topOffset }, { 1, -100 }, { 1, -bottomOffset })
    self.lvHonors.root:registerEvent(GUIEvent.ScrollMoveEnd, function()
        self:correctHonorItems()
    end)
    self.lvHonors.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
        if self.curToOffset ~= args.offset then
            self.llStar:SetVisible(false)
            self:updateHonorItemSize()
        end
    end)

    WebService:GetQualifyingSegmentConfig(function(data)
        ---@type GUIBedWarQualifyingSegmentIntroductionItemWindow
        local first = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegmentIntroductionItem", self.itemWidth)
        first:setBlank()
        self.lvHonors:addItem(first)
        for key, _ in pairs(data) do
            ---@type GUIBedWarQualifyingSegmentIntroductionItemWindow
            local item = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegmentIntroductionItem", self.itemWidth)
            item:onDataChanged(key)
            self.lvHonors:addItem(item)
        end

        ---添加荣耀王者
        ---@type GUIBedWarQualifyingSegmentIntroductionItemWindow
        local item = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegmentIntroductionItem", self.itemWidth)
        item:onDataChanged(8)
        self.lvHonors:addItem(item)

        ---@type GUIBedWarQualifyingSegmentIntroductionItemWindow
        local last = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegmentIntroductionItem", self.itemWidth)
        last:setBlank()
        self.lvHonors:addItem(last)
        self:updateSelectUI()
    end)
end

return UIBedWarQualifyingSegmentIntroductionLayout
