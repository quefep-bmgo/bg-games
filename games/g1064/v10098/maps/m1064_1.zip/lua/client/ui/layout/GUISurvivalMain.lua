local function hideEngineWindow(name)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetXPosition({ 0, 6000 })
    window:SetVisible(false)
end

---@class UISurvivalMainLayout : IGUILayout
local UISurvivalMainLayout = class("UISurvivalMainLayout", IGUILayout)
---@type FollowPlayerHelper
local FollowPlayerHelper = T(Global, "FollowPlayerHelper")
---@type CMountsMgr
local CMountsMgr = T(Global, "CMountsMgr")

---@private
function UISurvivalMainLayout:ctor(parent)
    self.super.ctor(self, "SurvivalMain.json", parent)
end

---@private
function UISurvivalMainLayout:onLoad()
    self.llTeammate = self:getChildWindow("SurvivalMain-Teammate", GUIType.Layout)
    self.llGameInfo = self:getChildWindow("SurvivalMain-GameInfo", GUIType.Layout)
    self.llLifeInfo = self:getChildWindow("SurvivalMain-LifeInfo", GUIType.Layout)
    self.stLifeNum = self:getChildWindow("SurvivalMain-LifeNum", GUIType.StaticText)
    self.llKillInfo = self:getChildWindow("SurvivalMain-KillInfo", GUIType.Layout)
    self.stKillNum = self:getChildWindow("SurvivalMain-KillNum", GUIType.StaticText)
    self.llPoisonCircleInfo = self:getChildWindow("SurvivalMain-PoisonCircleInfo", GUIType.Layout)
    self.stPoisonCircleTime = self:getChildWindow("SurvivalMain-PoisonCircleTime", GUIType.StaticText)
    self.llRespawnInfo = self:getChildWindow("SurvivalMain-RespawnInfo", GUIType.Layout)
    self.siTag4 = self:getChildWindow("SurvivalMain-Tag4", GUIType.StaticImage)
    self.stSpawnTime = self:getChildWindow("SurvivalMain-SpawnTime", GUIType.StaticText)
    self.siWatchBattle = self:getChildWindow("SurvivalMain-WatchBattle", GUIType.StaticImage)
    self.stFollowerName = self:getChildWindow("SurvivalMain-FollowerName", GUIType.StaticText)
    self.stWatchBattleText = self:getChildWindow("SurvivalMain-WatchBattleText", GUIType.StaticText)
    self.btnNextTeammate = self:getChildWindow("SurvivalMain-NextTeammate", GUIType.Button)
    self.btnLastTeammate = self:getChildWindow("SurvivalMain-LastTeammate", GUIType.Button)
    self.siHurtHint = self:getChildWindow("SurvivalMain-HurtHint", GUIType.StaticImage)
    self.siFootHint = self:getChildWindow("SurvivalMain-FootHint", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UISurvivalMainLayout:setEngineUIStyle()
    ClientHelper.putFloatPrefs("PoleControlMaxDistance", 65)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaNormal", 1)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaPress", 1)
    GUIManager:getWindowByName("Main-ItemBarBg"):SetYPosition({ -1, 0 })
    GUIManager:getWindowByName("Main-VisibleBar"):SetYPosition({ -1, 0 })
    local ivPoleArrow = GUIManager:getWindowByName("Main-PoleControl-Arrow", GUIType.StaticImage)
    ivPoleArrow:SetImage("set:pole.json image:pole_arrow")
    local wMoveState = GUIManager:getWindowByName("Main-MoveState")
    wMoveState:setRenderInMainScreen()
    wMoveState:SetArea(wMoveState:GetXPosition(), wMoveState:GetYPosition(), { 0, 60 }, { 0, 60 })
    local wJumControls = GUIManager:getWindowByName("Main-Jump-Controls")
    wJumControls:setRenderInMainScreen()
    wJumControls:SetArea(wJumControls:GetXPosition(), wJumControls:GetYPosition(), { 0, 138 }, { 0, 377 })
    local btnSkillRelease = GUIManager:getWindowByName("Main-Skill-Release-btn", GUIType.Button)
    btnSkillRelease:SetNormalImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetPushedImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetArea(btnSkillRelease:GetXPosition(), btnSkillRelease:GetYPosition(), { 0, 120 }, { 0, 120 })
    self.btnSkill = btnSkillRelease
    local btnCannon = GUIManager:getWindowByName("Main-Cannon", GUIType.Button)
    btnCannon:SetNormalImage("set:bedwarsmall.json image:btn_0_fort")
    btnCannon:SetPushedImage("set:bedwarsmall.json image:btn_0_fort")
    local ivSneak = GUIManager:getWindowByName("Main-MoveState-Sneak", GUIType.StaticImage)
    ivSneak:SetImage("set:move_state.json image:sneak_circle")
    local btnFly = GUIManager:getWindowByName("Main-Fly", GUIType.Button)
    btnFly:SetNormalImage("set:bedwarsmall.json image:fly")
    btnFly:SetPushedImage("set:bedwarsmall.json image:fly")
    btnFly:SetArea(btnFly:GetXPosition(), btnFly:GetYPosition(), { 0, 70 }, { 0, 70 })
    local btnLeftShoot = GUIManager:getWindowByName("Main-Gun-Operate-LeftShootBtn", GUIType.Button)
    btnLeftShoot:SetNormalImage("set:survival_main.json image:btn_0_shoot_left")
    btnLeftShoot:SetPushedImage("set:survival_main.json image:btn_0_shoot_left_click")
    btnLeftShoot:SetVerticalAlignment(VerticalAlignment.Center)
    btnLeftShoot:SetArea({ 0, 15 }, { 0, -50 }, { 0, 80 }, { 0, 80 })
    local btnRightShoot = GUIManager:getWindowByName("Main-Gun-Operate-RightShootBtn", GUIType.Button)
    btnRightShoot:SetNormalImage("set:survival_main.json image:btn_0_shoot_right")
    btnRightShoot:SetPushedImage("set:survival_main.json image:btn_0_shoot_right_click")
    btnRightShoot:SetWidth({ 0, 115 })
    btnRightShoot:SetHeight({ 0, 115 })
    local btnReload = GUIManager:getWindowByName("Main-Gun-Operate-ReloadBtn", GUIType.Button)
    btnReload:SetNormalImage("set:survival_main.json image:btn_0_reroad")
    btnReload:SetPushedImage("set:survival_main.json image:btn_0_reroad_click")
    btnReload:SetVerticalAlignment(VerticalAlignment.Bottom)
    btnReload:SetWidth({ 0, 95 })
    btnReload:SetHeight({ 0, 87 })
    local btnAim = GUIManager:getWindowByName("Main-Gun-Operate-AimBtn", GUIType.Button)
    btnAim:SetNormalImage("set:survival_main.json image:btn_0_sniper2")
    btnAim:SetPushedImage("set:survival_main.json image:btn_0_sniper2_click")
    btnAim:SetWidth({ 0, 78 })
    btnAim:SetHeight({ 0, 78 })
    local btnCancelAim = GUIManager:getWindowByName("Main-Gun-Operate-CancelAimBtn", GUIType.Button)
    btnCancelAim:SetNormalImage("set:survival_main.json image:btn_0_sniper1")
    btnCancelAim:SetPushedImage("set:survival_main.json image:btn_0_sniper1_click")
    btnCancelAim:SetWidth({ 0, 78 })
    btnCancelAim:SetHeight({ 0, 78 })
    local llFrozenMask = GUIManager:getWindowByName("Main-Frozen-Mask", GUIType.StaticImage)
    llFrozenMask:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    hideEngineWindow("Main-Player-Exp")
    hideEngineWindow("Main-Chat-Message")
    hideEngineWindow("Main-Watch-Battle-Tip")
end

---@private
function UISurvivalMainLayout:initView()
    self:setEngineUIStyle()
    self.gameHintTimer = {}
    self.siWatchBattle:SetVisible(false)
    self.siHurtHint:SetVisible(false)
    self.siFootHint:SetVisible(false)
    self.stWatchBattleText:SetText(Lang:getString("gui.main.watch.battle"))
    self.lvTeammates = IGUIListView.new("SurvivalMain-Teammate-List", self.llTeammate)
    self.lvTeammates:setItemSpace(4)
    self.lvTeammates.root:SetTouchable(false)
    ---@type SurvivalTeammateAdapter
    self.teammateAdapter = UIHelper.newGameAdapter("SurvivalTeammateAdapter")
    self.lvTeammates:setAdapter(self.teammateAdapter)
    self:setWaitGameUI()
end

---@private
function UISurvivalMainLayout:initEvent()
    self.btnNextTeammate:registerEvent(GUIEvent.ButtonClick, function()
        self:findNextFollower()
    end)
    self.btnLastTeammate:registerEvent(GUIEvent.ButtonClick, function()
        self:findLastFollower()
    end)
    ---@param poisonCircle CPoisonCircle
    self:registerEvent(Events.PoisonCircleInitEvent, function(poisonCircle)
        LuaTimer:cancel(self.poisonCircleTimer)
        local waitTime = math.floor(poisonCircle.config.waitTime / 1000)
        self.poisonCircleTimer = LuaTimer:scheduleTimerWithEnd(function()
            waitTime = waitTime - 1
            local text = DateUtil.getFormatTime(waitTime, "mm:ss")
            self.stPoisonCircleTime:SetText(text)
        end, function()
            self.stPoisonCircleTime:SetText("00:00")
        end, 1000, waitTime)
        local text = DateUtil.getFormatTime(waitTime, "mm:ss")
        self.stPoisonCircleTime:SetText(text)
    end)
    self:registerEvent(Events.StartGameEvent, function()
        self:setStartGameUI()
    end)
    ---@param player EntityPlayer
    self:registerEvent(CEvents.PlayerMoveEvent, function(player, position)
        if not isGameStart then
            return
        end
        local selfTeamId = PlayerManager:getClientPlayer():getTeamId()
        if player:getTeamId() == selfTeamId then
            return
        end
        if not player.onGround and not CMountsMgr:isPlayerOnMounts(player:getPlatformUserId()) then
            return
        end
        self:setGameHintUI(self.siFootHint, position, 40, 150)
    end)
end

function UISurvivalMainLayout:cameraChange()

end

---@private
function UISurvivalMainLayout:setWaitGameUI()
    self.llGameInfo:SetWidth({ 0, 150 })
    self.llLifeInfo:SetWidth({ 0, 110 })
    self.stLifeNum:SetWidth({ 0, 68 })
    self.llKillInfo:SetVisible(false)
    self.llPoisonCircleInfo:SetVisible(false)
    self.llRespawnInfo:SetVisible(false)
end

---@private
function UISurvivalMainLayout:setStartGameUI()
    self.llGameInfo:SetWidth({ 0, 401 })
    self.llLifeInfo:SetWidth({ 0, 75 })
    self.stLifeNum:SetWidth({ 0, 30 })
    self.llKillInfo:SetVisible(true)
    self.llPoisonCircleInfo:SetVisible(true)
    self.llRespawnInfo:SetVisible(true)
end

function UISurvivalMainLayout:onTick(frameTime, renderDt)
    local selfInfo = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
    if not selfInfo then
        return
    end
    local infoList = GameInfoManager:getAllPlayerInfo()
    local lifeCount = 0
    ---@type PlayerInfo[]
    local data = {}
    for _, info in pairs(infoList) do
        if info:getBoolValue("lifeStatus") then
            lifeCount = lifeCount + 1
        end
        if info:getValue("teamId") == selfInfo:getValue("teamId") then
            table.insert(data, info)
        end
    end
    table.sort(data, function(a, b)
        return a:getValue("number", true) < b:getValue("number", true)
    end)
    self.teammateAdapter:setData(data)
    if self.teammateAdapter:getItemCount() > 0 then
        self.lvTeammates.root:getContainerWindow():SetTouchable(false)
    end
    if isGameStart then
        self.stLifeNum:SetText(lifeCount)
        self.stKillNum:SetText(selfInfo:getValue("kill"))
    else
        self.stLifeNum:SetText(lifeCount .. "/24")
    end
    if self.respawnCountDown == 0 or selfInfo:getValue("respawnTimes", true) > 0 then
        self.siTag4:SetImage("set:survival_main.json image:img_0_icon_revival_stop")
        self.stSpawnTime:SetTextColor({ 1, 0.52, 0.52, 1 })
        self.llRespawnInfo:SetBackgroundColor({ 1, 0, 0, 0.3 })
    else
        self.siTag4:SetImage("set:survival_main.json image:img_0_icon_revival")
        self.stSpawnTime:SetTextColor(Color.WHITE)
        self.llRespawnInfo:SetBackgroundColor(Color.TRANS)
    end
    self:updateWatchBattleUI(selfInfo, frameTime, renderDt)

    --local btnRightShoot = GUIManager:getWindowByName("Main-Gun-Operate-RightShootBtn", GUIType.Button)
    --btnRightShoot:SetVerticalAlignment(VerticalAlignment.Bottom)
    --btnRightShoot:SetHorizontalAlignment(HorizontalAlignment.Right)
    --btnRightShoot:SetArea({ 0, -201 }, { 0, -202 }, { 0, 115 }, { 0, 115 })
end

---@param hintImage GUIStaticImage
function UISurvivalMainLayout:setGameHintUI(hintImage, hintPosition, hintRange, hintOffset)
    local selfPosition = PlayerManager:getClientPlayer():getPosition()
    local distance = VectorUtil.distance(selfPosition, hintPosition)
    if distance > hintRange then
        return
    end
    local targetDir = VectorUtil.sub3(hintPosition, selfPosition)
    targetDir.y = 0
    VectorUtil.normalize(targetDir)
    local camera = SceneManager.Instance():getMainCamera()
    local viewDir = camera:getDirection()
    viewDir.y = 0
    VectorUtil.normalize(viewDir)
    local cosValue = VectorUtil.dot(targetDir, viewDir)
    local tangent = VectorUtil.cross(targetDir, viewDir)
    local rotateAngle = math.acos(cosValue)
    local rate = 1 - distance / hintRange
    local isScreenLeft = false
    if tangent.y < 0 then
        isScreenLeft = true
    end
    local angle
    if isScreenLeft then
        angle = 360 - rotateAngle * MathUtil.RAD2DEG
    else
        angle = rotateAngle * MathUtil.RAD2DEG
    end
    hintImage:SetVisible(true)
    hintImage:SetAlpha(rate)
    hintImage:SetXPosition({ 0, math.sin(angle * MathUtil.DEG2RAD) * hintOffset })
    hintImage:SetYPosition({ 0, math.cos(angle * MathUtil.DEG2RAD) * -hintOffset })
    LuaTimer:cancel(self.gameHintTimer[hintImage:GetName()])
    self.gameHintTimer[hintImage:GetName()] = LuaTimer:schedule(function()
        hintImage:SetVisible(false)
    end, 1500)
end

---@private
function UISurvivalMainLayout:findNextFollower()
    self.followerId = self.followerId or 0
    PlayerManager:getClientPlayer():sendPacket({
        pid = "findNextFollower"
    })
end

---@private
function UISurvivalMainLayout:findLastFollower()
    self.followerId = self.followerId or 0
    PlayerManager:getClientPlayer():sendPacket({
        pid = "findLastFollower"
    })
end

function UISurvivalMainLayout:setWatchFollower(followerId)
    self.followerId = followerId
end

---@private
function UISurvivalMainLayout:updateWatchBattleUI(selfInfo, frameTime, renderDt)
    if selfInfo:getBoolValue("lifeStatus") then
        self.siWatchBattle:SetVisible(false)
    else
        if not self.siWatchBattle:IsVisible() then
            CameraUtil:disableMove()
            GUIManager:hideWindowByName("SurvivalPacket.json")
        end
        self.siWatchBattle:SetVisible(true)
        if not self.followerId then
            self:findNextFollower()
            FollowPlayerHelper:onUpdate(nil)
            return
        end
        local follower = PlayerManager:getPlayerByUserId(self.followerId)
        if not follower or not follower.Player or follower.Player.isDead then
            if self.followerId > 0 then
                self.followerId = 0
                self:findNextFollower()
            end
            FollowPlayerHelper:onUpdate(nil)
            return
        end
        local info = UserInfoCache:GetCache(self.followerId)
        if info then
            self.stFollowerName:SetText(info.nickName)
        else
            self.siWatchBattle:SetVisible(false)
        end
        FollowPlayerHelper:onUpdate(follower, frameTime, renderDt)
    end
end

function UISurvivalMainLayout:setRespawnCountDown(time)
    self.respawnCountDown = time
    LuaTimer:scheduleTimerWithEnd(function()
        self.respawnCountDown = self.respawnCountDown - 1
        self.stSpawnTime:SetText(DateUtil.getFormatTime(self.respawnCountDown, "mm:ss"))
    end, function()
        self.stSpawnTime:SetText("00:00")
    end, 1000, self.respawnCountDown)
end

return UISurvivalMainLayout
