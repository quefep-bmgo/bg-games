---@class GUIBedWarQualifyingSegmentIntroductionItemWindow : IGUIWindow
local GUIBedWarQualifyingSegmentIntroductionItemWindow = class("GUIBedWarQualifyingSegmentIntroductionItemWindow", IGUIWindow)

---@private
function GUIBedWarQualifyingSegmentIntroductionItemWindow:ctor(width)
    self.super.ctor(self, "BedWarQualifyingSegmentIntroductionItem.json")
    width = width or 317
    self.root:SetWidth({ 0, width })
    self.root:SetHeight({ 0, width * 323 / 317 })
    self.contentWidth = self.siImage:GetPixelSize().x
end

---@private
function GUIBedWarQualifyingSegmentIntroductionItemWindow:setContentSize(width)
    self.siImage:SetWidth({ 0, width })
    self.siImage:SetHeight({ 0, width * 249 / 244 })
end

---@private
function GUIBedWarQualifyingSegmentIntroductionItemWindow:onLoad()
    self.siImage = self:getChildWindowByName("BedWarQualifyingSegmentIntroductionItem-Image", GUIType.StaticImage)
    self.stText = self:getChildWindowByName("BedWarQualifyingSegmentIntroductionItem-Text", GUIType.StaticText)
end

function GUIBedWarQualifyingSegmentIntroductionItemWindow:setBlank()
    self.siImage:SetImage("")
    self.stText:SetText("")
end

---@param rank number
function GUIBedWarQualifyingSegmentIntroductionItemWindow:onDataChanged(rank)
    self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(rank))
    self.stText:SetText(Lang:getString("gui.qualifying.introduction.name." .. rank))
end

function GUIBedWarQualifyingSegmentIntroductionItemWindow:updateSize(centerX)
    local rect = self.root:GetUnclippedOuterRect()
    local rootCenterX = rect[1] + (rect[3] - rect[1]) / 2
    local scale = 1 - math.abs((rootCenterX - centerX)) / (self.contentWidth * 4)
    self:setContentSize(scale * self.contentWidth)
end

return GUIBedWarQualifyingSegmentIntroductionItemWindow
