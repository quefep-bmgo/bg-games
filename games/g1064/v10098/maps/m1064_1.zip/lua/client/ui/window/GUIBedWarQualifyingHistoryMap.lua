---@class GUIBedWarQualifyingHistoryMapWindow : IGUIWindow
local GUIBedWarQualifyingHistoryMapWindow = class("GUIBedWarQualifyingHistoryMapWindow", IGUIWindow)

---@private
function GUIBedWarQualifyingHistoryMapWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingHistoryMap.json", ...)
end

---@private
function GUIBedWarQualifyingHistoryMapWindow:onLoad()
    self.siImage = self:getChildWindowByName("BedWarQualifyingHistoryMap-Image", GUIType.StaticImage)
    self.stWins = self:getChildWindowByName("BedWarQualifyingHistoryMap-Wins", GUIType.StaticText)
    self.stRounds = self:getChildWindowByName("BedWarQualifyingHistoryMap-Rounds", GUIType.StaticText)
    self.stWinRate = self:getChildWindowByName("BedWarQualifyingHistoryMap-WinRate", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingHistoryMapWindow:initView()

end

---@private
function GUIBedWarQualifyingHistoryMapWindow:initEvent()

end

---@param data HistoryQualifyingMapDetailData
function GUIBedWarQualifyingHistoryMapWindow:onDataChanged(data)
    self.stWins:SetText(Lang:getString("gui.win.times") .. " : " .. data.winNum)
    self.stRounds:SetText(Lang:getString("gui.rounds") .. " : " .. data.roundNum)
	if data.roundNum ~= 0 then
		self.stWinRate:SetText(Lang:getString("gui.win.rate") .. " : "
				.. (math.floor(data.winNum * 1000 / data.roundNum) / 10) .. "%")
	else
		self.stWinRate:SetText("0%")
	end

	self.siImage:SetImage("set:bed_war_2_qualifying_map.json image:img_0_mapview_" .. (data.mapId or 0))
end

return GUIBedWarQualifyingHistoryMapWindow
