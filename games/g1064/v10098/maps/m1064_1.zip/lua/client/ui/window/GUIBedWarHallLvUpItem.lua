---@class GUIBedWarHallLvUpItemWindow : IGUIWindow
local GUIBedWarHallLvUpItemWindow = class("GUIBedWarHallLvUpItemWindow", IGUIWindow)

---@private
function GUIBedWarHallLvUpItemWindow:ctor(...)
	self.super.ctor(self, "BedWarHallLvUpItem.json", ...)
end

---@private
function GUIBedWarHallLvUpItemWindow:onLoad()
	self.stTitle = self:getChildWindowByName("BedWarHallLvUpItem-Title", GUIType.StaticText)
	self.llRewards = self:getChildWindowByName("BedWarHallLvUpItem-Rewards", GUIType.Layout)
	self.llBtns = self:getChildWindowByName("BedWarHallLvUpItem-Btns", GUIType.Layout)
	self.btnReceive = self:getChildWindowByName("BedWarHallLvUpItem-Receive", GUIType.Button)
	self.btnGo = self:getChildWindowByName("BedWarHallLvUpItem-Go", GUIType.Button)
	self.siReceived = self:getChildWindowByName("BedWarHallLvUpItem-Received", GUIType.StaticImage)
	self.siBgEffect = self:getChildWindowByName("BedWarHallLvUpItem-Effect", GUIType.StaticImage)
	self.siBtnEffect = self:getChildWindowByName("BedWarHallLvUpItem-BtnEffect", GUIType.StaticImage)
	self.stReceivedText = self:getChildWindowByName("BedWarHallLvUpItem-Received-Text", GUIType.StaticText)

	self.gvList = IGUIGridView.new("BedWarHallLvUpItem-List-Grid_" .. self.windowId, self.llRewards)
	self.gvList.root:SetTouchable(false)
	self.gvList:setConfig(25, 0, 10)
	---@type LvUpRewardItemAdapter
	self.lvItemAdapt = UIHelper.newGameAdapter("LvUpRewardItemAdapter")
	local height = self.gvList:getHeight()
	self.lvItemAdapt:setItemSize(height, height)
	self.gvList:setAdapter(self.lvItemAdapt)

	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarHallLvUpItemWindow:initView()
	self.btnReceive:SetVisible(false)
	self.btnGo:SetVisible(false)
	self.siReceived:SetVisible(false)
	self.siBgEffect:SetVisible(false)
	self.siBtnEffect:SetVisible(false)
	self.btnReceive:SetText(Lang:getString("bed.war.activity.receive"))
	self.btnGo:SetText(Lang:getString("gui_bed_war_task_toComplete"))
	self.stReceivedText:SetText(Lang:getString("bed.war.super.player.received"))
end

---@private
function GUIBedWarHallLvUpItemWindow:initEvent()
	self.btnReceive:registerEvent(GUIEvent.ButtonClick, function()
		if not self.lv or not self.status or self.status ~= Define.RewardStatus.WaitReceived then
			return
		end
		self:showEffect(false)
		GamePacketSender:sendReceiveLvUpReward(self.lv)
	end)

	self.btnGo:registerEvent(GUIEvent.ButtonClick, function()
		GUIBedWarHallLvUpLayout:hide()
		---@type TeamService
		local TeamService = T(Global, "TeamService")
		TeamService:sendCreateTeam("g1008")
	end)

	self:registerEvent(Events.UpdateLvUpRewardEvent, function(lv)
		if self.lv and self.lv <= lv then
			self:updateStatus()
		end
	end)

	self:registerEvent(Events.SetLvUpRewardAlphaEvent, function(alpha)
		self.root:SetAlpha(alpha)
	end)

	self:registerEvent(Events.ShowLvUpRewardEffectEvent, function(lv, show)
		if lv == 0 or (self.lv and lv == self.lv) then
			self:showEffect(show)
		end
	end)
end

---@param data ExpConfigItem
function GUIBedWarHallLvUpItemWindow:onDataChanged(data)
	self.lv = data.exp_lv
	self.stTitle:SetText(Lang:getString("gui_lv_up_reward_title_" .. data.exp_lv))
	self.lvItemAdapt:setData(data.rewards)
	self:updateStatus()
end

function GUIBedWarHallLvUpItemWindow:updateStatus()
	self.status = GUIBedWarHallLvUpLayout:getStatus(self.lv)
	self.siReceived:SetVisible(self.status == Define.RewardStatus.Received)
	self.btnGo:SetVisible(self.status == Define.RewardStatus.CantReceived)
	self.btnReceive:SetVisible(self.status == Define.RewardStatus.WaitReceived)
	self.siBtnEffect:SetVisible(self.status == Define.RewardStatus.WaitReceived)
end

function GUIBedWarHallLvUpItemWindow:showEffect(show)
	self.siBgEffect:SetVisible(show)
end

return GUIBedWarHallLvUpItemWindow
