---@class GUIBedWarQualifyingMatchTeamWindow : IGUIWindow
local GUIBedWarQualifyingMatchTeamWindow = class("GUIBedWarQualifyingMatchTeamWindow", IGUIWindow)
---@type QualifyingService
local QualifyingService = T(Global, "QualifyingService")

---@private
function GUIBedWarQualifyingMatchTeamWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingMatchTeam.json", ...)
end

---@private
function GUIBedWarQualifyingMatchTeamWindow:onLoad()
    self.siIcon = self:getChildWindowByName("BedWarQualifyingMatchTeam-Icon", GUIType.StaticImage)
    self.llPlayers = self:getChildWindowByName("BedWarQualifyingMatchTeam-Players", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingMatchTeamWindow:initView()

end

---@private
function GUIBedWarQualifyingMatchTeamWindow:initEvent()

end

---@param teamId number
function GUIBedWarQualifyingMatchTeamWindow:onDataChanged(teamId)
    self.llPlayers:CleanupChildren()
    self.siIcon:SetImage(TeamGUIInfo.getTeamGUI(teamId).tab_icon)
    local startIndex = 1 + (teamId - 1) * 4
    local endIndex = math.min(teamId * 4, #QualifyingService:getMatchUserList())
    for index = startIndex, endIndex do
        ---@type GUIBedWarHead
        local header = UIHelper.newGameGUIWindow("GUIBedWarHead", 67)
        local info = QualifyingService:getMatchUser(index)
        header:setUserInfo(info)
        header.root:SetYPosition({ 0, 12 })
        header.root:SetXPosition({ 0, (index - startIndex) * 86 + 6 })
        if info.userId == Game:getPlatformUserId() then
            local text = GUIManager:createGUIWindow(GUIType.StaticText, header.root:GetName() .. "Text")
            text:SetWidth({ 1, 0 })
            text:SetHeight({ 0, 30 })
            text:SetYPosition({ 1, 8 })
            text:SetText(info.name)
            text:SetBordered(true)
            text:SetProperty("Font", "HT14")
            text:SetTextHorzAlign(HorizontalAlignment.Center)
            text:SetTextVertAlign(VerticalAlignment.Center)
            header.root:AddChildWindow(text)
        end
        self.llPlayers:AddChildWindow(header.root)
    end
end

return GUIBedWarQualifyingMatchTeamWindow
