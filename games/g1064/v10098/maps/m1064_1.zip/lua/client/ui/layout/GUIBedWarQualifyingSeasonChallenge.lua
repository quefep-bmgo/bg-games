---@class UIBedWarQualifyingSeasonChallengeLayout : IGUILayout
local UIBedWarQualifyingSeasonChallengeLayout = class("UIBedWarQualifyingSeasonChallengeLayout", IGUILayout)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function UIBedWarQualifyingSeasonChallengeLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingSeasonChallenge.json", parent)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:onLoad()
    self.btnReward = self:getChildWindow("BedWarQualifyingSeasonChallenge-Reward", GUIType.Button)
    self.btnChallenge = self:getChildWindow("BedWarQualifyingSeasonChallenge-Challenge", GUIType.Button)
    self.llPanel = self:getChildWindow("BedWarQualifyingSeasonChallenge-Panel", GUIType.Layout)
    self.llMoney = self:getChildWindow("BedWarQualifyingSeasonChallenge-Money", GUIType.Layout)
    self.txtReward = self:getChildWindow("BedWarQualifyingSeasonChallenge-RewardText", GUIType.StaticText)
    self.txtChallenge = self:getChildWindow("BedWarQualifyingSeasonChallenge-ChallengeText", GUIType.StaticText)
    UIUtils.addRedDot(self.btnReward, Define.RedDotKey.QualifyingReward, Define.RedDotKey.Qualifying)
    UIUtils.addRedDot(self.btnChallenge, Define.RedDotKey.QualifyingChallenge, Define.RedDotKey.Qualifying)

    ---@type GUIBedWarQualifyingSeasonChallengePanel1Window
    local challengeClass
    local qualifyingData = CQualifyingController:getQualifyingData()
    if qualifyingData then
        local success = pcall(function()
            challengeClass = require("client.ui.window.GUIBedWarQualifyingSeasonChallengePanel" .. qualifyingData.quarter)
        end)
        if not success then
            challengeClass = nil
        end
    end
    if not challengeClass then
        challengeClass = require "client.ui.window.GUIBedWarQualifyingSeasonChallengePanel1"
    end
    self.challengeWindow = challengeClass.new()
    self.llPanel:AddChildWindow(self.challengeWindow.root)
    self.challengeWindow:onShow()
    self.panelWindow = self.challengeWindow
    local rewardClass = require("client.ui.window.GUIBedWarQualifyingSeasonReward")
    self.rewardWindow = rewardClass.new()
    self.llPanel:AddChildWindow(self.rewardWindow.root)

    self:initView()
    self:initEvent()

    WebService:GetQualifyingSegmentConfig(function()  end)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:initView()
    ---@type GUIBedWarUIReturnControlWindow
    self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.qualifying.season.challenge", function()
        self:hide()
    end)
    self.llReturn.siBg:SetVisible(false)
    self.stLastTime = GUIManager:createGUIWindow(GUIType.StaticText, "BedWarQualifyingSeasonChallenge-LastTime")
    self.siTimeIcon = GUIManager:createGUIWindow(GUIType.StaticImage, "BedWarQualifyingSeasonChallenge-TimeIcon")
    self.siTimeIcon:SetImage("set:store_time_goods.json image:icon_0_time")
    self.siTimeIcon:SetArea({0, 0}, {0, 50}, {0, 21}, {0, 21})
    self.llReturn.stText:AddChildWindow(self.siTimeIcon)
    self.siTimeIcon:AddChildWindow(self.stLastTime)
    self.stLastTime:SetArea({0,30}, {0, 0}, {0, 150}, {0, 30})
    self.stLastTime:SetVerticalAlignment(VerticalAlignment.Center)
    self.stLastTime:SetTextVertAlign(VerticalAlignment.Center)
    self.root:AddChildWindow(self.llReturn.root)

    self.lvMoney = IGUIListView.new("BedWarQualifyingSeasonChallenge-Money-List", self.llMoney, nil, Orientation.Horizontal)
    self.lvMoney:setItemSpace(10)
    self.moneyItems = {}
    for _, money in pairs({Define.Money.GameCashCoupon, Define.Money.KEY, Define.Money.DIAMOND}) do
        ---@type GUICurrency
        local item = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
        item.root:SetProperty("LayoutBackImage", "set:bedwar_toolbar.json image:camera_bg")
        item:onDataChanged({ ItemId = 0, RealId = money })
        table.insert(self.moneyItems, item)
        self.lvMoney:addItem(item)
    end

    local strlen = string.len(Lang:getString("gui.qualifying.reward.qualifying_challenge"))
    local font = math.max(2, math.floor(128 / strlen) * 2)
    self.txtReward:SetText(Lang:getString("gui.qualifying.reward.qualifying_season_reward"))
    self.txtChallenge:SetText(Lang:getString("gui.qualifying.reward.qualifying_challenge"))
    self.txtChallenge:SetFont(GUIFontManager:Instance():GetFont("HT" .. font))
    self.txtReward:SetFont(GUIFontManager:Instance():GetFont("HT" .. font))
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:initEvent()
    self.btnReward:registerEvent(GUIEvent.ButtonClick, function()
        ClientReportEvent.click_qualifying_button("qualifying_tabReward")
        self.rewardWindow:setVisible(true)
        self.challengeWindow:setVisible(false)
        self.btnReward:SetPushedImage("set:bed_war_season_reward.json image:chb_9_selected")
        self.btnReward:SetNormalImage("set:bed_war_season_reward.json image:chb_9_selected")
        self.btnChallenge:SetPushedImage("set:bed_war_season_reward.json image:chb_9_normal")
        self.btnChallenge:SetNormalImage("set:bed_war_season_reward.json image:chb_9_normal")
    end)
    self.btnChallenge:registerEvent(GUIEvent.ButtonClick, function()
        ClientReportEvent.click_qualifying_button("qualifying_tabChallenge")
        self.rewardWindow:setVisible(false)
        self.challengeWindow:setVisible(true)
        self.btnReward:SetPushedImage("set:bed_war_season_reward.json image:chb_9_normal")
        self.btnReward:SetNormalImage("set:bed_war_season_reward.json image:chb_9_normal")
        self.btnChallenge:SetPushedImage("set:bed_war_season_reward.json image:chb_9_selected")
        self.btnChallenge:SetNormalImage("set:bed_war_season_reward.json image:chb_9_selected")
    end)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:onShow()
    if self.panelWindow then
        self.panelWindow.root:SetVisible(true)
        self.panelWindow:onShow()
    end
end

function UIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(rewardDetailId)
    if self.panelWindow then
        self.panelWindow:showRewardDetail(rewardDetailId)
    end
end

function UIBedWarQualifyingSeasonChallengeLayout:onHide()
    if self.panelWindow then
        self.panelWindow.root:SetVisible(false)
        self.panelWindow:onHide()
    end
end
function UIBedWarQualifyingSeasonChallengeLayout:onTick()
    for _, item in pairs(self.moneyItems) do
        item:onTick()
    end
    local qualifyingData = CQualifyingController:getQualifyingData()
    if not qualifyingData then
        return
    end
    local timeRemaining = qualifyingData.timeRemaining / 1000
    if timeRemaining >= DateUtil.getDaySeconds() then
        local text = Lang:format("common.activity.day", tostring(math.floor(timeRemaining / DateUtil.getDaySeconds())))
        self.stLastTime:SetText(text)
    else
        self.stLastTime:SetText(DateUtil.getFormatTime(timeRemaining))
    end
end

return UIBedWarQualifyingSeasonChallengeLayout
