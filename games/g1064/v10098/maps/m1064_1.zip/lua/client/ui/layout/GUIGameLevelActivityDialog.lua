---@class UIGameLevelActivityDialogLayout : IGUILayout
local UIGameLevelActivityDialogLayout = class("UIGameLevelActivityDialogLayout", IGUILayout)

---@private
function UIGameLevelActivityDialogLayout:ctor(parent)
	self.super.ctor(self, "GameLevelActivityDialog.json", parent)
end

---@private
function UIGameLevelActivityDialogLayout:isDelayLoad()
	return true
end

---@private
function UIGameLevelActivityDialogLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGameLevelActivityDialogLayout:initCreateEvent()

end

---@private
function UIGameLevelActivityDialogLayout:onLoad()
	self.siBg = self:getChildWindow("GameLevelActivityDialog-Bg", GUIType.StaticImage)
	self.stTip = self:getChildWindow("GameLevelActivityDialog-Tip", GUIType.StaticText)
	self.btnClose = self:getChildWindow("GameLevelActivityDialog-Close", GUIType.Button)
	self.siLeftBg = self:getChildWindow("GameLevelActivityDialog-LeftBg", GUIType.StaticImage)
	self.stLeftTitle = self:getChildWindow("GameLevelActivityDialog-LeftTitle", GUIType.StaticText)
	self.siLeftItemBg = self:getChildWindow("GameLevelActivityDialog-Left-Item-Bg", GUIType.StaticImage)
	self.siLeftIcon = self:getChildWindow("GameLevelActivityDialog-Left-Icon", GUIType.StaticImage)
	self.stLeftItemNum = self:getChildWindow("GameLevelActivityDialog-Left-Item-Num", GUIType.StaticText)
	self.siRightBg = self:getChildWindow("GameLevelActivityDialog-RightBg", GUIType.StaticImage)
	self.stRightTitle = self:getChildWindow("GameLevelActivityDialog-RightTitle", GUIType.StaticText)
	self.siRightItemBg = self:getChildWindow("GameLevelActivityDialog-Right-Item-Bg", GUIType.StaticImage)
	self.siRightIcon = self:getChildWindow("GameLevelActivityDialog-Right-Icon", GUIType.StaticImage)
	self.stRightItemNum = self:getChildWindow("GameLevelActivityDialog-Right-Item-Num", GUIType.StaticText)
	self.btnBuy = self:getChildWindow("GameLevelActivityDialog-Buy", GUIType.Button)
	self.siIcon = self:getChildWindow("GameLevelActivityDialog-Icon", GUIType.StaticImage)
	self.stPrice = self:getChildWindow("GameLevelActivityDialog-Price", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIGameLevelActivityDialogLayout:initView()
	self.stTip:SetText(Lang:getString("gui.activity.level.buy.tip"))
	self.stLeftTitle:SetText(Lang:getString("gui.activity.level.buy.now.receive"))
	self.stRightTitle:SetText(Lang:getString("gui.activity.level.buy.total.receive"))
end

---@private
function UIGameLevelActivityDialogLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		if self.closeCallBack then
			self.closeCallBack()
			self.closeCallBack = nil
		end
		self:hide()
	end)
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		if self.successCallBack then
			self.successCallBack()
			self.successCallBack = nil
		end
		self:hide()
	end)
end

function UIGameLevelActivityDialogLayout:onShow(data)
	if data.image1 then
		self.siLeftIcon:SetImage(data.image1)
	end
	if data.num1 then
		self.stLeftItemNum:SetText(data.num1)
	end
	if data.image2 then
		self.siRightIcon:SetImage(data.image2)
	end
	if data.num2 then
		self.stRightItemNum:SetText(data.num2)
	end
	if data.price then
		self.stPrice:SetText(data.price)
	end
	if data.closeCallBack then
		self.closeCallBack = data.closeCallBack
	end
	if data.successCallBack then
		self.successCallBack = data.successCallBack
	end
end

return UIGameLevelActivityDialogLayout
