---@class UIBedWarQualifyingHistoryLayout : IGUILayout
local UIBedWarQualifyingHistoryLayout = class("UIBedWarQualifyingHistoryLayout", IGUILayout)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")

---@private
function UIBedWarQualifyingHistoryLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingHistory.json", parent)
end

---@private
function UIBedWarQualifyingHistoryLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingHistoryLayout:onLoad()
    self.stSubTitle = self:getChildWindow("BedWarQualifyingHistory-SubTitle", GUIType.StaticText)
    self.stTime = self:getChildWindow("BedWarQualifyingHistory-Time", GUIType.StaticText)
    self.llTabs = self:getChildWindow("BedWarQualifyingHistory-Tabs", GUIType.Layout)
    self.llContent = self:getChildWindow("BedWarQualifyingHistory-Content", GUIType.Layout)
    ---@type table<number, HistoryQualifyingData[]>
    self.historyCache = {}
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarQualifyingHistoryLayout:isShowAnim()
    return false
end

---@private
function UIBedWarQualifyingHistoryLayout:initView()
    ---@type GUIBedWarUIReturnControlWindow
    self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.qualifying.history.title", function()
        self:hide()
    end)
    self.root:AddChildWindow(self.llReturn.root)
end

---@private
function UIBedWarQualifyingHistoryLayout:initEvent()
    self:registerEvent(Events.SyncQualifyingDataEvent, function()
        if not self:isShow() then
            return
        end
        self:onShow()
    end)
end

---@private
function UIBedWarQualifyingHistoryLayout:onShow()
    if not CQualifyingController:getQualifyingData() then
        return
    end
    self:initDetail()
    self:initItemList()
    self:initTabList()
end

---@private
function UIBedWarQualifyingHistoryLayout:initDetail()
    if self.wHistoryDetail then
        return
    end
    ---@type GUIBedWarQualifyingHistoryDetailWindow
    self.wHistoryDetail = UIHelper.newGameGUIWindow("GUIBedWarQualifyingHistoryDetail")
end

---@private
function UIBedWarQualifyingHistoryLayout:initTabList()
    if self.lvTabList then
        return
    end
    local qualifyingData = CQualifyingController:getQualifyingData()
    if not qualifyingData then
        return
    end
    local quarter = qualifyingData.quarter
    local tabCount = quarter % 4 == 0 and math.ceil(quarter / 4) or math.floor(quarter / 4) + 1
    self.lvTabList = IGUIListView.new("BedWarQualifyingHistory-Tab-List", self.llTabs)
    self.lvTabList:setItemSpace(10)
    self.tabGroup = RadioBoxGroup.new()
    for index = tabCount, 1, -1 do
        local tab = IGUIWindow.new(GUIManager:createGUIWindow(GUIType.CheckBox, "BedWarQualifyingHistory-Tab"))
        tab.root:SetNormalImage("set:bed_war_store.json image:tab_nor")
        tab.root:SetPushedImage("set:bed_war_store.json image:tab_pre")
        tab.root:SetText("S" .. (index * 4 - 3) .. " - " .. "S" .. math.min(index * 4, quarter))
        tab.root:SetProperty("TextBorder", "true")
        tab.root:SetProperty("StretchType", "NineGrid")
        tab.root:SetProperty("StretchOffset", "60 60 10 35")
        tab:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 0, 60 })
        self.lvTabList:addItem(tab)
        self.tabGroup:addCheckBox(tab.root, function()
            self:updateItems(index)
        end)
    end
    self.tabGroup:selectIndex(1)
end

---@private
function UIBedWarQualifyingHistoryLayout:initItemList()
    if self.lvHistoryList then
        return
    end
    self.lvHistoryList = IGUIListView.new("BedWarQualifyingHistory-Item-List", self.llContent, nil, Orientation.Horizontal)
    self.lvHistoryList:setItemSpace(24)
    self.lvHistoryList.root:SetItemWidth(243)
    ---@type BedWarQualifyingHistoryAdapter
    self.historyAdapter = UIHelper.newGameAdapter("BedWarQualifyingHistoryAdapter")
    self.lvHistoryList:setAdapter(self.historyAdapter)
end

---@private
function UIBedWarQualifyingHistoryLayout:updateItems(year)
    WebService:GetQualifyingSegmentConfig(function()
        local qualifyingData = CQualifyingController:getQualifyingData()
        if not qualifyingData then
            return
        end
        self.wHistoryDetail:removeFromParent()
        local cache = self.historyCache[year]
        if cache then
            self.historyAdapter:setData(cache, true)
            self.stTime:SetText(QualifyingTool.formatSeasonTime(cache[1].quarterStartTime, cache[#cache].quarterOverTime))
            self.stSubTitle:SetText("S" .. cache[1].quarter .. " - " .. "S" .. cache[#cache].quarter)
            return
        end
        local quarters = {}
        for i = 1, 4 do
            local quarter = (year - 1) * 4 + i
            if quarter <= qualifyingData.quarter then
                table.insert(quarters, quarter)
            end
        end
        WebService:GetQualifyingHistoryList(quarters, function(data)
            local result = {}
            for _, quarter in pairs(quarters) do
                local item = data[tostring(quarter)] or {}
                QualifyingTool.setInitQualifyingData(item, quarter)
                table.insert(result, item)
            end
            self.historyCache[year] = result
            self:updateItems(year)
        end)
    end)
end

return UIBedWarQualifyingHistoryLayout
