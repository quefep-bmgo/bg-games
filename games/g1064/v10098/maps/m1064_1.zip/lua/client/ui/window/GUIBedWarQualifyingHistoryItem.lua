---@class GUIBedWarQualifyingHistoryItemWindow : IGUIWindow
local GUIBedWarQualifyingHistoryItemWindow = class("GUIBedWarQualifyingHistoryItemWindow", IGUIWindow)

---@private
function GUIBedWarQualifyingHistoryItemWindow:ctor()
    self.super.ctor(self, "BedWarQualifyingHistoryItem.json")
    self.width = 243
    self:initView()
end

---@private
function GUIBedWarQualifyingHistoryItemWindow:onLoad()
    self.siContent = self:getChildWindowByName("BedWarQualifyingHistoryItem-Content", GUIType.StaticImage)
    self.llDetail = self:getChildWindowByName("BedWarQualifyingHistoryItem-Detail", GUIType.Layout)
    self.llHonor = self:getChildWindowByName("BedWarQualifyingHistoryItem-Honor", GUIType.Layout)
    self.stName = self:getChildWindowByName("BedWarQualifyingHistoryItem-Name", GUIType.StaticText)
    self.stTime = self:getChildWindowByName("BedWarQualifyingHistoryItem-Time", GUIType.StaticText)
    self.siArrow = self:getChildWindowByName("BedWarQualifyingHistoryItem-Arrow", GUIType.StaticImage)
    self.btnClick = self:getChildWindowByName("BedWarQualifyingHistoryItem-Click", GUIType.Button)
    self:initEvent()
end

---@private
function GUIBedWarQualifyingHistoryItemWindow:initView()
    self.root:SetWidth({ 0, self.width })
    self.root:SetHeight({ 0, self.width * 437 / 243 })
    self.siContent:SetWidth({ 0, self.width })
    self.llDetail:SetXPosition({ 0, self.width - 1 })

    ---@type GUIBedWarQualifyingSegmentWindow
    self.llHonorRank = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegment", self.llHonor, self.llHonor:GetPixelSize().x)
end

---@private
function GUIBedWarQualifyingHistoryItemWindow:initEvent()
    self.btnClick:registerEvent(GUIEvent.ButtonClick, function()
        if self.wDetail then
            GUIBedWarQualifyingHistoryLayout.wHistoryDetail:closeByItem(self)
        else
            GUIBedWarQualifyingHistoryLayout.wHistoryDetail:openByItem(self)
        end
    end)
end

---@param data HistoryQualifyingData
function GUIBedWarQualifyingHistoryItemWindow:onDataChanged(data)
    self.data = data
    self.llHonorRank:onDataChanged(data)
    self:setDetailWidth(0)
    self.stTime:SetText(QualifyingTool.formatSeasonTime(data.quarterStartTime, data.quarterOverTime))
    self.stName:SetText("S" .. data.quarter)
    self.siArrow:SetImage("set:bed_war_2_qualifying_history.json image:img_0_spread_arrows")
end

---@param wDetail GUIBedWarQualifyingHistoryDetailWindow
function GUIBedWarQualifyingHistoryItemWindow:openDetail(wDetail, callback)
    if self.wDetail then
        return
    end
    self.wDetail = wDetail
    self.wDetail:onDataChanged(self.data)
    self.llDetail:AddChildWindow(wDetail.root)
    local curWidth = 0
    local maxWidth = wDetail.root:GetPixelSize().x - 11
    local addWidth = (maxWidth - curWidth) / 12
    self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
        curWidth = math.max(curWidth + addWidth, 0)
        self:setDetailWidth(curWidth)
    end, function()
        self.siArrow:SetImage("set:bed_war_2_qualifying_history.json image:img_0_spread_arrows2")
        if callback then
            callback()
        end
    end, 25, 12))
end

---@param wDetail GUIBedWarQualifyingHistoryDetailWindow
function GUIBedWarQualifyingHistoryItemWindow:closeDetail(wDetail, callback)
    if not self.wDetail then
        if callback then
            callback()
        end
        return
    end
    local curWidth = wDetail.root:GetPixelSize().x - 11
    local minWidth = 0
    local subWidth = (curWidth - minWidth) / 12
    self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
        curWidth = math.max(curWidth - subWidth, 0)
        self:setDetailWidth(curWidth)
    end, function()
        self.wDetail = nil
        self.siArrow:SetImage("set:bed_war_2_qualifying_history.json image:img_0_spread_arrows")
        if callback then
            callback()
        end
    end, 25, 12))
end

---@private
function GUIBedWarQualifyingHistoryItemWindow:setDetailWidth(width)
    self.root:SetWidth({ 0, self.width + width })
    local lvList = GUIBedWarQualifyingHistoryLayout.lvHistoryList.root
    lvList:LayoutChild()
    self.llDetail:SetWidth({ 0, width })
    local wContainer = lvList:getContainerWindow()
    local maxOffset = math.max(wContainer:GetPixelSize().x - lvList:GetPixelSize().x, 0)
    local offset = math.min(self.root:GetXPosition()[2], maxOffset)
    if lvList:GetScrollOffset() ~= -offset then
        lvList:SetScrollOffset(-offset)
    end
end

return GUIBedWarQualifyingHistoryItemWindow
