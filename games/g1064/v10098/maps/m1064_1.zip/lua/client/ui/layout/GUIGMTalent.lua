---@class UIGMTalentLayout : IGUILayout
local UIGMTalentLayout = class("UIGMTalentLayout", IGUILayout)
---@type TalentConfig
local TalentConfig = T(Global, "TalentConfig")
---@type ImbueClassSetting
local ImbueClassSetting = T(Global, "ImbueClassSetting")

---@private
function UIGMTalentLayout:isDelayLoad()
	return true
end

---@private
function UIGMTalentLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGMTalentLayout:initCreateEvent()
	self:registerEvent(Events.GMGameTalentRefreshData, function(packet)
		local str = "当前天赋数据:\n"
		local talent = packet.talent or {}
		local specialImbueMap = packet.specialImbueMap or {}
		--local imbueList = packet.imbueList or {}
		local index = 1
		LogUtil.pv(talent)
		for i, v in pairs(talent) do
			local talentCfg = TalentConfig:getTalentCfg(v.talentId, v.level)
			if talentCfg then
				if index % 2 ~= 0 then
					str = str .. string.format("%s ID:%s Lv:%s 效果ID:%s              ", Lang:getString(talentCfg.name),v.talentId, v.level, talentCfg.effectId)
				else
					str = str .. string.format("%s ID:%s Lv:%s 效果ID:%s\n", Lang:getString(talentCfg.name),v.talentId, v.level, talentCfg.effectId)
				end
				index = index + 1
			end
		end
		str = str .. "\n===========特殊效果===================\n"
		for key, imbueList in pairs(specialImbueMap) do
			str = str .. string.format("[%s]:\n", key)
			for _, imbueId in pairs(imbueList) do
				local imbueCfg = ImbueClassSetting:getImbueById(imbueId)
				str = str .. string.format("  效果ID:%s Lv:%s  \n", imbueId, imbueCfg.level)
			end
		end
		self.stDataText:SetText(str)
	end)
end

---@private
function UIGMTalentLayout:onLoad()
	self.btnAddTalentBtn = self:getChildWindow("GMTalent-AddTalentBtn", GUIType.Button)
	self.btnDeleteTalentBtn = self:getChildWindow("GMTalent-DeleteTalentBtn", GUIType.Button)
	self.btnAddImbueBtn = self:getChildWindow("GMTalent-AddImbueBtn", GUIType.Button)
	self.btnDeleteImbueBtn = self:getChildWindow("GMTalent-DeleteImbueBtn", GUIType.Button)
	self.stDataText = self:getChildWindow("GMTalent-DataText", GUIType.StaticText)
	self.stDataDescText = self:getChildWindow("GMTalent-DataDescText", GUIType.StaticText)
	self.llDataContent = self:getChildWindow("GMTalent-DataContent", GUIType.Layout)
	self.llDataLevelContent = self:getChildWindow("GMTalent-DataLevelContent", GUIType.Layout)
	self.btnQuitBtn = self:getChildWindow("GMTalent-QuitBtn", GUIType.Button)
	self.btnSureBtn = self:getChildWindow("GMTalent-SureBtn", GUIType.Button)
	self.btnDeleteAllTalentBtn = self:getChildWindow("GMTalent-DeleteAllTalentBtn", GUIType.Button)
	self.btnDeleteAllImbueBtn = self:getChildWindow("GMTalent-DeleteAllImbueBtn", GUIType.Button)
	self.btnAddAllTalentBtn = self:getChildWindow("GMTalent-AddAllTalentBtn", GUIType.Button)
	self.btnSwitchDataTextBtn = self:getChildWindow("GMTalent-SwitchDataTextBtn", GUIType.Button)
	self.btnRefresh = self:getChildWindow("GMTalent-Refresh", GUIType.Button)
	self:initView()
	self:initEvent()
end

---@private
function UIGMTalentLayout:initView()
	self.dataItemTextMap = {}
	self.dataLevelTextMap = {}
	self.isOpenDataText = true
end

---@private
function UIGMTalentLayout:initEvent()
	self.btnAddTalentBtn:registerEvent(GUIEvent.ButtonClick, function()
		if self.selectType ~= 1 then
			self.selectType = 1
			self.llDataLevelContent:SetVisible(true)
			self.stDataDescText:SetVisible(true)
			self.btnSureBtn:SetVisible(true)
			self.llDataContent:SetVisible(true)
			self:createTalentItemText(function(levelMap)
				self:createLevelText(levelMap)
				self:setDataItemSelectState(levelMap[1].talentId)
				self:setDefaultTalentSelectLevel(levelMap,1)
			end)
			self.btnAddTalentBtn:SetBackgroundColor({0,1,0,1})
			self.btnDeleteTalentBtn:SetBackgroundColor({1,0,0,1})
		else
			self.selectType = 0
			self.llDataContent:SetVisible(false)
			self.llDataLevelContent:SetVisible(false)
			self.stDataDescText:SetVisible(false)
			self.btnSureBtn:SetVisible(false)
			self.btnAddTalentBtn:SetBackgroundColor({1,0,0,1})
		end
	end)
	self.btnDeleteTalentBtn:registerEvent(GUIEvent.ButtonClick, function()
		if self.selectType ~= 2 then
			self.selectType = 2
			self.btnSureBtn:SetVisible(true)
			self.llDataLevelContent:SetVisible(false)
			self.stDataDescText:SetVisible(false)
			self.llDataContent:SetVisible(true)
			self:createTalentItemText(function(levelMap)
				self.selectData = levelMap[1].talentId
				self:setDataItemSelectState(levelMap[1].talentId)
			end)
			self.btnDeleteTalentBtn:SetBackgroundColor({0,1,0,1})
			self.btnAddTalentBtn:SetBackgroundColor({1,0,0,1})
		else
			self.selectType = 0
			self.llDataContent:SetVisible(false)
			self.btnSureBtn:SetVisible(false)
			self.btnDeleteTalentBtn:SetBackgroundColor({1,0,0,1})
		end
	end)
	self.btnDeleteAllTalentBtn:registerEvent(GUIEvent.ButtonClick, function()
		PlayerManager:getClientPlayer():sendPacket({
			pid = "C2SGMClearTalent",
			talentId = -1,
		})
	end)
	self.btnAddAllTalentBtn:registerEvent(GUIEvent.ButtonClick, function()
		PlayerManager:getClientPlayer():sendPacket({
			pid = "C2SGMAddTalent",
			talentId = -1,
		})
	end)

	self.btnRefresh:registerEvent(GUIEvent.ButtonClick, function()
		PlayerManager:getClientPlayer():sendPacket({
			pid = "C2SGMRefreshAttrShow"
		})
	end)

	self.btnAddImbueBtn:registerEvent(GUIEvent.ButtonClick, function()
		self.llDataLevelContent:SetVisible(false)
		self.stDataDescText:SetVisible(false)
		GMHelper:openInput({ "效果id" }, function(imbueId)
			PlayerManager:getClientPlayer():sendPacket({
				pid = "C2SGMAddImbue",
				imbueId = tonumber(imbueId)
			})
		end)
	end)
	self.btnDeleteImbueBtn:registerEvent(GUIEvent.ButtonClick, function()
		self.llDataLevelContent:SetVisible(false)
		GMHelper:openInput({ "效果id" }, function(imbueId)
			PlayerManager:getClientPlayer():sendPacket({
				pid = "C2SGMClearImbue",
				imbueId = tonumber(imbueId)
			})
		end)
	end)
	self.btnDeleteAllImbueBtn:registerEvent(GUIEvent.ButtonClick, function()
		PlayerManager:getClientPlayer():sendPacket({
			pid = "C2SGMClearImbue",
			imbueId = -1,
		})
	end)
	self.btnSureBtn:registerEvent(GUIEvent.ButtonClick, function()
		if self.selectType == 1 then
			if self.selectData then
				PlayerManager:getClientPlayer():sendPacket({
					pid = "C2SGMAddTalent",
					talentId = self.selectData.talentId,
					level = self.selectData.level
				})
				self:setDataItemSelectState(0)
				self.llDataLevelContent:CleanupChildren()
				self.selectData = nil
			end
		elseif self.selectType == 2 then
			PlayerManager:getClientPlayer():sendPacket({
				pid = "C2SGMClearTalent",
				talentId = self.selectData,
			})
			self:setDataItemSelectState(0)
		end
	end)
	self.btnQuitBtn:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)

	self.btnSwitchDataTextBtn:registerEvent(GUIEvent.ButtonClick, function()
		if self.isOpenDataText then
			self.stDataText:SetWidth({0, 0})
			self.isOpenDataText = false
		else
			self.isOpenDataText = true
			self.stDataText:SetWidth({0, 671})
		end
	end)
end

function UIGMTalentLayout:createTalentItemText(clickCb)
	self.dataItemTextMap = {}
	self.llDataContent:CleanupChildren()
	local levelMap = TalentConfig:getTalentLevelMap()
	local xIndex = 0
	local yIndex = 0
	for i, v in pairs(levelMap) do
		if v[1].type ~= 3 then
			local text = GUIManager:createGUIWindow(GUIType.StaticText, 'talent'..i)
			text:SetBackgroundColor({0,0,0,1})
			text:SetTextHorzAlign(HorizontalAlignment.Center)
			text:SetTextVertAlign(VerticalAlignment.Center)
			text:SetWidth({0, 100})
			text:SetHeight({0, 50})
			text:SetXPosition({0, 100 * xIndex + 30})
			text:SetYPosition({0, 50 * yIndex + 30})
			text:SetText(Lang:getString(v[1].name))
			text:registerEvent(GUIEvent.Click, function()
				clickCb(v)
			end)
			self.llDataContent:AddChildWindow(text)
			xIndex = xIndex + 1
			if xIndex == 6 then
				yIndex = yIndex + 1
				xIndex = 0
			end
			self.dataItemTextMap[v[1].talentId] = text
		end
	end
end

function UIGMTalentLayout:setDataItemSelectState(selectTalentId)
	for talentId, text in pairs(self.dataItemTextMap) do
		if talentId == selectTalentId then
			text:SetBackgroundColor({0,1,0,1})
		else
			text:SetBackgroundColor({0,0,0,1})
		end
	end
end

function UIGMTalentLayout:setLevelItemSelectState(selectLevel)
	for level, text in pairs(self.dataLevelTextMap) do
		if level == selectLevel then
			text:SetBackgroundColor({0,1,0,1})
		else
			text:SetBackgroundColor({0,0,0,1})
		end
	end
end

function UIGMTalentLayout:createLevelText(levelMap)
	self.llDataLevelContent:CleanupChildren()
	local xIndex = 0
	local yIndex = 0
	for i, v in pairs(levelMap) do
		local text = GUIManager:createGUIWindow(GUIType.StaticText, 'talent'..i)
		text:SetTextHorzAlign(HorizontalAlignment.Center)
		text:SetTextVertAlign(VerticalAlignment.Center)
		text:SetWidth({0, 50})
		text:SetHeight({0, 30})
		text:SetXPosition({0, 50 * xIndex + 10})
		text:SetYPosition({0, 30 * yIndex + 10})
		text:SetText(v.level)
		text:registerEvent(GUIEvent.Click, function()
			self.selectData = v
			local str = Lang:getString(v.name).." Lv"..v.level
			self.stDataDescText:SetText(str.."\n"..UITalentDetail:getPropDesc(v.desc, v.effectId))
			self:setLevelItemSelectState(v.level)
		end)
		self.llDataLevelContent:AddChildWindow(text)
		xIndex = xIndex + 1
		if xIndex == 2 then
			yIndex = yIndex + 1
			xIndex = 0
		end
		self.dataLevelTextMap[v.level] = text
	end
end

function UIGMTalentLayout:setDefaultTalentSelectLevel(levelMap, level)
	local selectData = levelMap[level]
	if selectData then
		local str = Lang:getString(selectData.name).." Lv"..selectData.level
		self.stDataDescText:SetText(str.."\n"..UITalentDetail:getPropDesc(selectData.desc, selectData.effectId))
		self:setLevelItemSelectState(selectData.level)
		self.selectData = selectData
	else
		self.stDataDescText:SetText("没有该配置")
	end
end

return UIGMTalentLayout
