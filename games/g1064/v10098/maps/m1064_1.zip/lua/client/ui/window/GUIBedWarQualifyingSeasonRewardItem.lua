---@class GUIBedWarQualifyingSeasonRewardItemWindow : IGUIWindow
local GUIBedWarQualifyingSeasonRewardItemWindow = class("GUIBedWarQualifyingSeasonRewardItemWindow", IGUIWindow)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")

---@private
function GUIBedWarQualifyingSeasonRewardItemWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingSeasonRewardItem.json", ...)
end

---@private
function GUIBedWarQualifyingSeasonRewardItemWindow:onLoad()
    self.siGradeIcon = self:getChildWindowByName("BedWarQualifyingRewardItem-GradeIcon", GUIType.StaticImage)
    self.stGradeName = self:getChildWindowByName("BedWarQualifyingRewardItem-GradeName", GUIType.StaticText)
    self.siNormalImage = self:getChildWindowByName("BedWarQualifyingRewardItem-NormalBoxIcon", GUIType.StaticImage)
    self.stNormalRewardCount = self:getChildWindowByName("BedWarQualifyingRewardItem-NormalRewardCount", GUIType.StaticText)
    self.siNormalMask = self:getChildWindowByName("BedWarQualifyingRewardItem-NormalMask", GUIType.Layout)
    self.siNormalReceived = self:getChildWindowByName("BedWarQualifyingRewardItem-NormalReceivedIcon", GUIType.StaticImage)
    self.siHighImage = self:getChildWindowByName("BedWarQualifyingRewardItem-HighBoxIcon", GUIType.StaticImage)
    self.stHighRewardCount = self:getChildWindowByName("BedWarQualifyingRewardItem-HighRewardCount", GUIType.StaticText)
    self.siHighMask = self:getChildWindowByName("BedWarQualifyingRewardItem-HighMask", GUIType.Layout)
    self.siHighReceived = self:getChildWindowByName("BedWarQualifyingRewardItem-HighReceivedIcon", GUIType.StaticImage)
    self.siHighLock = self:getChildWindowByName("BedWarQualifyingRewardItem-Lock", GUIType.StaticImage)
    self.siNormalEffect = self:getChildWindowByName("BedWarQualifyingRewardItem-NormalRewardEffect", GUIType.Layout)
    self.siHighEffect = self:getChildWindowByName("BedWarQualifyingRewardItem-HighRewardEffect", GUIType.Layout)
    self:initEvent()
end

function GUIBedWarQualifyingSeasonRewardItemWindow:canReceive()
    local cache = UserInfoCache:GetCache(Game:getPlatformUserId())
    if cache.qualifyingData.segment > self.data.qualifying.segment
            or (cache.qualifyingData.segment == self.data.qualifying.segment and cache.qualifyingData.grade >= self.data.qualifying.grade) then
        return true
    end
    return false
end

---@private
function GUIBedWarQualifyingSeasonRewardItemWindow:initEvent()
    self.siNormalImage:registerEvent(GUIEvent.Click, function()
        LogUtil.logError("season reward click", StringUtil.v2s(self.data))
        if self:canReceive() and CQualifyingController:sendReceiveChallengeReward(Define.QualifyingSeasonRewardType.Normal, self.data.Id) then
            return
        end
        GUICommonActivityRewardDetail:show(self.data.NormalRewardId)
    end)
    self.siHighImage:registerEvent(GUIEvent.Click, function()
        local score = CQualifyingController:getChallengeScore(Define.QualifyingSeasonRewardType.High)
        if score <= 0 then
            CQualifyingController:tryBuyDialog()
            return
        end
        if self:canReceive() and CQualifyingController:sendReceiveChallengeReward(Define.QualifyingSeasonRewardType.High, self.data.Id) then
            return
        end
        GUICommonActivityRewardDetail:show(self.data.HighRewardId)
    end)
end

---@param data QualifyingSeasonChallengeRewardData
function GUIBedWarQualifyingSeasonRewardItemWindow:onDataChanged(data)
    self.data = data
    self.rewardId = self.data.Id
    local cache = UserInfoCache:GetCache(Game:getPlatformUserId())
    self.stGradeName:SetText(QualifyingTool.getQualifyingSegmentName(data.qualifying.segment, data.qualifying.grade, 0))
    self.siGradeIcon:SetImage(QualifyingTool.getQualifyingSegmentIcon(data.qualifying.segment))
    local canReceive = false
    if cache.qualifyingData.segment > data.qualifying.segment
            or (cache.qualifyingData.segment == data.qualifying.segment and cache.qualifyingData.grade >= data.qualifying.grade) then
        canReceive = true
    end
    if CQualifyingController:isChallengeRewardReceived(Define.QualifyingSeasonRewardType.Normal, data.Id) then
        self.siNormalEffect:SetVisible(false)
        self.siNormalMask:SetVisible(false)
        self.siNormalReceived:SetVisible(true)
    elseif canReceive then
        self.siNormalEffect:SetVisible(true)
        self.siNormalMask:SetVisible(false)
        self.siNormalReceived:SetVisible(false)
    else
        self.siNormalEffect:SetVisible(false)
        self.siNormalMask:SetVisible(true)
        self.siNormalReceived:SetVisible(false)
    end
    if CQualifyingController:isChallengeRewardReceived(Define.QualifyingSeasonRewardType.High, data.Id) then
        self.siHighEffect:SetVisible(false)
        self.siHighMask:SetVisible(false)
        self.siHighReceived:SetVisible(true)
    elseif canReceive and true then
        self.siHighEffect:SetVisible(true)
        self.siHighMask:SetVisible(false)
        self.siHighReceived:SetVisible(false)
    else
        self.siHighEffect:SetVisible(false)
        self.siHighMask:SetVisible(true)
        self.siHighReceived:SetVisible(false)
    end
    local score = CQualifyingController:getChallengeScore(Define.QualifyingSeasonRewardType.High)
    if score <= 0 then
        self.siHighLock:SetVisible(true)
    else
        self.siHighLock:SetVisible(false)
    end
    if data.NormalRewardCount == 1 then
        self.stNormalRewardCount:SetText("")
    else
        self.stNormalRewardCount:SetText(data.NormalRewardCount)
    end
    self.stHighRewardCount:SetText(data.HighRewardCount)
    local cfg = RewardConfig.findRewardById(data.NormalRewardId)
    if cfg then
        self.siNormalImage:SetImage(cfg.ShowDetail.image)
    end
    cfg = RewardConfig.findRewardById(data.HighRewardId)
    if cfg then
        self.siHighImage:SetImage(cfg.ShowDetail.image)
    end
end

return GUIBedWarQualifyingSeasonRewardItemWindow
