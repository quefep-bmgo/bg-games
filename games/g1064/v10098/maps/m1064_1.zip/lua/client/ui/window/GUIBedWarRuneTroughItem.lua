---@class GUIBedWarRuneTroughItemWindow : IGUIWindow
local GUIBedWarRuneTroughItemWindow = class("GUIBedWarRuneTroughItemWindow", IGUIWindow)
---@type table[]
local lockColor = { { 79 / 255, 24 / 255, 24 / 255, 1 },
                    { 20 / 255, 50 / 255, 104 / 255, 1 },
                    { 65 / 255, 54 / 255, 20 / 255, 1 },
                    { 63 / 255, 20 / 255, 94 / 255, 1 } }

---@private
------@param parent GUIWindow
function GUIBedWarRuneTroughItemWindow:ctor(troughId, XPos, YPos, parent)
    self.id = troughId
    self.super.ctor(self, "BedWarRuneTroughItem.json")
    self.root:SetXPosition({ 0, XPos or 0 })
    self.root:SetYPosition({ 0, YPos or 0 })
    if parent then
        parent:AddChildWindow(self.root)
    end
end

---@private
function GUIBedWarRuneTroughItemWindow:onLoad()
    self.siTrough = self:getChildWindowByName("RuneTroughItem-Trough", GUIType.StaticImage)
    self.siRune = self:getChildWindowByName("RuneTroughItem-Rune", GUIType.StaticImage)
    self.siLock = self:getChildWindowByName("RuneTroughItem-Lock", GUIType.StaticImage)
    self.stUnlockLevel = self:getChildWindowByName("RuneTroughItem-UnlockLevel", GUIType.StaticText)
    self.siSelect = self:getChildWindowByName("RuneTroughItem-Select", GUIType.StaticImage)
    self.siBg = self:getChildWindowByName("RuneTroughItem-Bg", GUIType.StaticImage)
    self.siPlus = self:getChildWindowByName("RuneTroughItem-Plus", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarRuneTroughItemWindow:initView()
    self.stUnlockLevel:SetText(Lang:format("gui_bed_war_rune_trough_lock_txt", self.id % 7 == 0 and 7 or self.id % 7))
    self.siBg:SetDrawColor(lockColor[math.ceil(self.id / 7)])
end

---@private
function GUIBedWarRuneTroughItemWindow:initEvent()

end

---@param config RuneConfigItem
function GUIBedWarRuneTroughItemWindow:onDataChanged(config)
    if config then
        self.siTrough:SetImage(string.format("set:bed_war_rune.json image:img_0_slot_frame_%d", config.Level))
        self.siRune:SetImage(config.Image)
        self.siRune:SetVisible(true)
        self.siBg:SetVisible(false)
        self.siPlus:SetVisible(false)
        self.siLock:SetVisible(false)
    else
        self.siTrough:SetImage("set:bed_war_rune.json image:img_0_slot_frame_1")
        self.siRune:SetVisible(false)
        self.siBg:SetVisible(true)
        self.siPlus:SetVisible(true)
        self.siLock:SetVisible(false)
    end
end

function GUIBedWarRuneTroughItemWindow:setSelected(selected)
    self.siSelect:SetVisible(selected)
end

return GUIBedWarRuneTroughItemWindow
