---@class UISelectTeamInviteListLayout : IGUILayout
local UISelectTeamInviteListLayout = class("UISelectTeamInviteListLayout", IGUILayout)
---@type FriendManager
local FriendManager = T(Global, "FriendManager")
---@type TribeManager
local TribeManager = T(Global, "TribeManager")
---@type RecentPlayManager
local RecentPlayManager = T(Global, "RecentPlayManager")
---@type table
local InviteStatusRecord = T(Global, "InviteStatusRecord")
---@type TeamService
local TeamService = T(Global, "TeamService")

---@class HallCreateTeamInviteTab
---@field window GUICheckBox
---@field type number

local InviteListType = {
    Friend = 1,
    Tribe = 2,
    RecentPlay = 3,
}

---@private
function UISelectTeamInviteListLayout:ctor(parent)
    self.super.ctor(self, "SelectTeamInviteList.json", parent)
end

---@private
function UISelectTeamInviteListLayout:isDelayLoad()
    return true
end

---@private
function UISelectTeamInviteListLayout:onLoad()
    self.llInvite = self:getChildWindow("SelectTeamInviteList-Invite", GUIType.Layout)
    self.btnClose = self:getChildWindow("SelectTeamInviteList-Close", GUIType.Button)
    self.stInviteCount = self:getChildWindow("SelectTeamInviteList-Invite-Count", GUIType.StaticText)
    self.llInviteTabs = self:getChildWindow("SelectTeamInviteList-Invite-Tabs", GUIType.Layout)
    self.llTabLine1 = self:getChildWindow("SelectTeamInviteList-Tab-Line1", GUIType.Layout)
    self.llTabLine2 = self:getChildWindow("SelectTeamInviteList-Tab-Line2", GUIType.Layout)
    self.cbInviteTabFriend = self:getChildWindow("SelectTeamInviteList-Invite-Tab-Friend", GUIType.CheckBox)
    self.cbInviteTabTribe = self:getChildWindow("SelectTeamInviteList-Invite-Tab-Tribe", GUIType.CheckBox)
    self.cbInviteTabRecent = self:getChildWindow("SelectTeamInviteList-Invite-Tab-Recent", GUIType.CheckBox)
    self.llInviteList = self:getChildWindow("SelectTeamInviteList-Invite-List", GUIType.Layout)
    self.btnInviteRefresh = self:getChildWindow("SelectTeamInviteList-Invite-Refresh", GUIType.Button)
    self.llNoFriendTip = self:getChildWindow("SelectTeamInviteList-No-Friend-Tip", GUIType.Layout)
    self.siNoFriendTipIcon = self:getChildWindow("SelectTeamInviteList-No-Friend-Tip-Icon", GUIType.StaticImage)
    self.stNoFriendTipText = self:getChildWindow("SelectTeamInviteList-No-Friend-Tip-Text", GUIType.StaticText)
    self.siArrow = self:getChildWindow("SelectTeamInviteList-Arrow", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UISelectTeamInviteListLayout:initView()
    ---@type HallCreateTeamInviteTab[]
    self.inviteTabs = {}
    table.insert(self.inviteTabs, { window = self.cbInviteTabFriend, type = InviteListType.Friend })
    table.insert(self.inviteTabs, { window = self.cbInviteTabTribe, type = InviteListType.Tribe })
    table.insert(self.inviteTabs, { window = self.cbInviteTabRecent, type = InviteListType.RecentPlay })
    ---@type HallCreateTeamInviteTab
    self.curInviteTab = nil
    self:changeInviteTab(self.cbInviteTabFriend)

    self.cbInviteTabFriend:SetText(Lang:getString("gui.chat.friend"))
    self.cbInviteTabTribe:SetText(Lang:getString("gui.chat.tribe"))
    self.cbInviteTabRecent:SetText(Lang:getString("gui.chat.recent"))

    self.llNoFriendTip:SetVisible(false)
    self.stNoFriendTipText:SetText(Lang:getString("gui.no.friend.tip"))
end

---@private
function UISelectTeamInviteListLayout:initEvent()
    for _, inviteTab in pairs(self.inviteTabs) do
        inviteTab.window:registerEvent(GUIEvent.CheckStateChanged, function()
            if not inviteTab.window:GetChecked() then
                return
            end
            self:changeInviteTab(inviteTab.window)
        end)
    end
    self.btnInviteRefresh:registerEvent(GUIEvent.ButtonClick, function()
        self:refreshInviteList()
    end)
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:openOrClose(false)
    end)
end

---只有界面打开着才监听的事件
---@private
function UISelectTeamInviteListLayout:initOpenEvent()
    self:registerEvent(Events.TeammateInviteStatusEvent, function()
        self:updateInviteList()
    end)
    self:registerEvent(Events.UserJoinTeamEvent, function()
        self:updateInviteList()
    end)
    self:registerEvent(Events.UserLeaveTeamEvent, function(userId)
        InviteStatusRecord[userId] = Define.InviteStatus.Invite
        self:updateInviteList()
    end)
    self:registerEvent(Events.FinishLoadFriendDataEvent, function()
        if self.curInviteTab and self.curInviteTab.type == InviteListType.Friend then
            self:updateInviteList()
        end
    end)
    self:registerEvent(Events.FinishLoadTribeMemberEvent, function()
        if self.curInviteTab and self.curInviteTab.type == InviteListType.Tribe then
            self:updateInviteList()
        end
    end)
    self:registerEvent(Events.FinishLoadRecentPlayEvent, function()
        if self.curInviteTab and self.curInviteTab.type == InviteListType.RecentPlay then
            self:updateInviteList()
        end
    end)
end

---@private
function UISelectTeamInviteListLayout:unregisterOpenEvent()
    self:unregisterEvent(Events.TeammateInviteStatusEvent)
    self:unregisterEvent(Events.UserJoinTeamEvent)
    self:unregisterEvent(Events.UserLeaveTeamEvent)
    self:unregisterEvent(Events.FinishLoadFriendDataEvent)
    self:unregisterEvent(Events.FinishLoadTribeMemberEvent)
    self:unregisterEvent(Events.FinishLoadRecentPlayEvent)
end

---@private
function UISelectTeamInviteListLayout:onTick(frameTime)
    ---@param item GUITeamInvitePlayerItemWindow
    for _, item in pairs(self.lvInviteList.items) do
        item:onTick()
    end
end

---@private
---@param parent GUIWindow
function UISelectTeamInviteListLayout:onShow(parent, isPullBack)
    parent:AddChildWindow(self.root)
    self:updateInviteList()
    if isPullBack then
        self:openOrClose(true)
    else
        self.llInvite:SetXPosition({ 0, 0 })
        self:refreshInviteList()
    end
    self.btnClose:SetVisible(isPullBack)
    self:initOpenEvent()

    self.siArrow:SetVisible(TeamService:isQualifying())
end

---@private
function UISelectTeamInviteListLayout:onHide()
    self:unregisterOpenEvent()
end

function UISelectTeamInviteListLayout:openOrClose(isOpen)
    LuaTimer:cancel(self.animKey)
    local times = 8
    local width = self.llInvite:GetPixelSize().x
    local startX = isOpen and width or 0
    local offset = isOpen and -width / times or width / times
    self.llInvite:SetXPosition({ 0, startX })
    self.animKey = LuaTimer:scheduleTimerWithEnd(function()
        startX = startX + offset
        self.llInvite:SetXPosition({ 0, startX })
    end, function()
        if not isOpen then
            self:hide()
        else
            self:refreshInviteList()
        end
    end, 30, times)
end

---@private
function UISelectTeamInviteListLayout:refreshInviteList()
    if self.curInviteTab.type == InviteListType.Friend then
        FriendManager.LoadFriendData()
    elseif self.curInviteTab.type == InviteListType.Tribe then
        TribeManager.LoadTribeMembers()
    elseif self.curInviteTab.type == InviteListType.RecentPlay then
        RecentPlayManager.RefreshPlayersData()
    end
    self.inviteListAdapter:setScrollOffset(0)
end

---@private
function UISelectTeamInviteListLayout:changeInviteTab(checkedTab)
    for _, inviteTab in pairs(self.inviteTabs) do
        if inviteTab.window == checkedTab then
            self.curInviteTab = inviteTab
            inviteTab.window:SetTouchable(false)
            inviteTab.window:SetChecked(true)
            inviteTab.window:SetProperty("Font", "HT20")
            inviteTab.window:SetProperty("TextRenderOffset", "0 -5")
            inviteTab.window:SetProperty("BtnTextColor", "0.152941 0.176471 0.360784 1")
        else
            inviteTab.window:SetTouchable(true)
            inviteTab.window:SetChecked(false)
            inviteTab.window:SetProperty("Font", "HT16")
            inviteTab.window:SetProperty("TextRenderOffset", "0 -2")
            inviteTab.window:SetProperty("BtnTextColor", "0.686275 0.780392 0.917647 1")
        end
    end
    if self.inviteListAdapter then
        self.inviteListAdapter:setScrollOffset(0)
    end
    self:updateInviteList()
end

function UISelectTeamInviteListLayout:updateInviteList()
    if self.lvInviteList == nil then
        self.lvInviteList = IGUIListView.new("HallCreateTeam-Invite-Players", self.llInviteList)
        ---@type TeamInvitePlayerAdapter
        self.inviteListAdapter = UIHelper.newGameAdapter("TeamInvitePlayerAdapter")
        self.lvInviteList:setAdapter(self.inviteListAdapter)
        self.inviteListAdapter:setBottomCall(function()
            if self.curInviteTab.type == InviteListType.Friend then
                FriendManager.LoadMoreFriend()
            end
        end)
    end
    if not self.curInviteTab then
        self:changeInviteTab(self.cbInviteTabFriend)
        return
    end
    local userIds = {}
    ---@type UserInfo[]
    local userInfoList = {}
    local userCount = 0
    if self.curInviteTab.type == InviteListType.Friend then
        userIds = FriendManager.GetFriends()
        userCount = FriendManager.GetTotalFriendCount()
    elseif self.curInviteTab.type == InviteListType.Tribe then
        TribeManager.TryInitLoad()
        userIds = TribeManager.GetMembers()
        userCount = #userIds
    elseif self.curInviteTab.type == InviteListType.RecentPlay then
        RecentPlayManager.TryInitLoad()
        userIds = RecentPlayManager.GetPlayers()
        userCount = #userIds
    end
    for _, userId in pairs(userIds) do
        if userId ~= Game:getPlatformUserId() then
            table.insert(userInfoList, UserInfoCache:GetCache(userId))
        end
    end
    table.sort(userInfoList, function(info1, info2)
        if info1.status == nil or info2.status == nil then
            return info1.userId < info2.userId
        end
        if info1.status ~= info2.status then
            return info1.status < info2.status
        end
        local record1 = InviteStatusRecord[info1.userId] or Define.InviteStatus.Invite
        local record2 = InviteStatusRecord[info2.userId] or Define.InviteStatus.Invite
        if record1 ~= record2 then
            return record1 < record2
        end
        return info1.userId < info2.userId
    end)
    self.inviteListAdapter:setData(userInfoList, true)
    local onlineCount = 0
    for _, userInfo in pairs(userInfoList) do
        if userInfo.status ~= Define.UserStatus.Offline then
            onlineCount = onlineCount + 1
        end
    end
    self.llNoFriendTip:SetVisible(self.curInviteTab.type == InviteListType.Friend and userCount <= 0)
    self.stInviteCount:SetText(string.format("  " .. self.curInviteTab.window:GetText() .. ": %s/%s", onlineCount, userCount))
end

return UISelectTeamInviteListLayout
