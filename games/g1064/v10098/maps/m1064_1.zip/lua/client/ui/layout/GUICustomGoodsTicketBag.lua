---@type CustomGoodsTicketConfig
local CustomGoodsTicketConfig = T(Global, "CustomGoodsTicketConfig")

---@class UICustomGoodsTicketBagLayout : IGUILayout
local UICustomGoodsTicketBagLayout = class("UICustomGoodsTicketBagLayout", IGUILayout)

---@private
function UICustomGoodsTicketBagLayout:ctor(parent)
    self.super.ctor(self, "CustomGoodsTicketBag.json", parent)
end

---@private
function UICustomGoodsTicketBagLayout:isDelayLoad()
    return true
end

---@private
function UICustomGoodsTicketBagLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UICustomGoodsTicketBagLayout:initCreateEvent()

end

---@private
function UICustomGoodsTicketBagLayout:isShowAnim()
    return false
end

---@private
function UICustomGoodsTicketBagLayout:onLoad()
    self.llContent = self:getChildWindow("CustomGoodsTicketBag-Content", GUIType.Layout)
    self.stTitle = self:getChildWindow("CustomGoodsTicketBag-Title", GUIType.StaticText)
    self.siClose = self:getChildWindow("CustomGoodsTicketBag-Close", GUIType.StaticImage)
    self.llTickets = self:getChildWindow("CustomGoodsTicketBag-Tickets", GUIType.Layout)
    self.siEmpty = self:getChildWindow("CustomGoodsTicketBag-Empty", GUIType.StaticImage)
    self.stEmptyText = self:getChildWindow("CustomGoodsTicketBag-EmptyText", GUIType.StaticText)
    self.llDetail = self:getChildWindow("CustomGoodsTicketBag-Detail", GUIType.Layout)
    self.siTicketBorder = self:getChildWindow("CustomGoodsTicketBag-TicketBorder", GUIType.StaticImage)
    self.siTicketImage = self:getChildWindow("CustomGoodsTicketBag-TicketImage", GUIType.StaticImage)
    self.siTicketTag = self:getChildWindow("CustomGoodsTicketBag-TicketTag", GUIType.StaticImage)
    self.stTicketTime = self:getChildWindow("CustomGoodsTicketBag-TicketTime", GUIType.StaticText)
    self.stTicketName = self:getChildWindow("CustomGoodsTicketBag-TicketName", GUIType.StaticText)
    self.stTicketDesc = self:getChildWindow("CustomGoodsTicketBag-TicketDesc", GUIType.StaticText)
    self.siHasTip = self:getChildWindow("CustomGoodsTicketBag-HasTip", GUIType.StaticImage)
    self.stHasTipText = self:getChildWindow("CustomGoodsTicketBag-HasTipText", GUIType.StaticText)
    self.btnUseTicket = self:getChildWindow("CustomGoodsTicketBag-UseTicket", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UICustomGoodsTicketBagLayout:initView()
    self.stTitle:SetText(Lang:getString("custom.goods.ticket.bag"))
    self.stEmptyText:SetText(Lang:getString("custom.goods.ticket.empty"))
    self.stHasTipText:SetText(Lang:getString("custom.goods.has.tip"))
    self.btnUseTicket:SetText(Lang:getString("custom.goods.ticket.use"))

    self.lvTickets = IGUIGridView.new("CustomGoodsTicketBag-TicketList", self.llTickets)
    self.lvTickets:setConfig(10, 12, 5)
    self.lvTickets:setArea({ 0, 10 }, { 0, 10 }, { 1, -20 }, { 1, -20 })
    self.ticketsAdapter = UIHelper.newGameAdapter("CustomGoodsTicketAdapter")
    self.lvTickets:setAdapter(self.ticketsAdapter)

    self:showCurrentTicket()
end

---@private
function UICustomGoodsTicketBagLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)
    self.btnUseTicket:registerEvent(GUIEvent.ButtonClick, function()
        if not self.curShowTicket then
            return
        end
        if self.curShowTicket.count <= 0 then
            return
        end
        CustomDialog.builder()
                    .setPanelSize(691, 350)
                    .setTitleText("use.custom.goods.ticket.title")
                    .setContentView(UseCustomGoodsTicketContent)
                    .setHideLeftButton()
                    .setHideRightButton()
                    .setHideListener(function()
            self:hide()
        end)
                    .show()
        UseCustomGoodsTicketContent:setCurrentTicket(self.curShowTicket)
    end)
end

---@param ticket CustomGoodsTicketData
function UICustomGoodsTicketBagLayout:showCurrentTicket(ticket)
    self.curShowTicket = ticket
    if ticket then
        self.siEmpty:SetVisible(false)
        self.llDetail:SetVisible(true)
        self.lvTickets.root:SetVisible(true)
        self.llTickets:SetWidth({ 0, 471 })
        self.siTicketBorder:SetImage("set:bed_war_3_dress_store.json image:img_0_ticket_" .. tostring(ticket.level))
        self.siTicketTag:SetImage("set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(ticket.level))
        self.stTicketTime:SetText(ticket.day .. Lang:getString("gui.day"))
        self.stTicketName:SetText(Lang:getString(ticket.nameLang))
        self.stTicketDesc:SetText(Lang:getString(ticket.descLang))
        local config = CustomShopConfig:getGoodsConfig(ticket.customGoodsId)
        if config then
            self.siTicketImage:SetImage(config.Image)
            local hasGoods = config.Time == -1
            self.siHasTip:SetVisible(hasGoods)
            self.btnUseTicket:SetEnabled(not hasGoods)
        end
    else
        self.siEmpty:SetVisible(true)
        self.llDetail:SetVisible(false)
        self.lvTickets.root:SetVisible(false)
        self.llTickets:SetWidth({ 1, -24 })
    end
end

function UICustomGoodsTicketBagLayout:onShow()
    self:updateTicketList()
end

function UICustomGoodsTicketBagLayout:updateTicketList()
    if not self:isShow() then
        return
    end
    local settings = CustomGoodsTicketConfig:getAllConfig()
    ---@type CustomGoodsTicketData[]
    local items = {}
    for _, item in pairs(settings) do
        if item.count > 0 then
            table.insert(items, item)
        end
    end
    table.sort(items, function(item1, item2)
        return item1.weight > item2.weight
    end)
    self.ticketsAdapter:setData(items)
    if #items > 0 then
        self:showCurrentTicket(items[1])
    else
        self:showCurrentTicket(nil)
    end
end

return UICustomGoodsTicketBagLayout
