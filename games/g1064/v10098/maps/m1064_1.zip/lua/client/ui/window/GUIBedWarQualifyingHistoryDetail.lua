---@class GUIBedWarQualifyingHistoryDetailWindow : IGUIWindow
local GUIBedWarQualifyingHistoryDetailWindow = class("GUIBedWarQualifyingHistoryDetailWindow", IGUIWindow)

---@private
function GUIBedWarQualifyingHistoryDetailWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingHistoryDetail.json", ...)
end

---@private
function GUIBedWarQualifyingHistoryDetailWindow:onLoad()
    self.siTitle = self:getChildWindowByName("BedWarQualifyingHistoryDetail-Title", GUIType.StaticImage)
    self.stRankText = self:getChildWindowByName("BedWarQualifyingHistoryDetail-Rank-Text", GUIType.StaticText)
    self.stWinTimesText = self:getChildWindowByName("BedWarQualifyingHistoryDetail-WinTimes-Text", GUIType.StaticText)
    self.stWinRateText = self:getChildWindowByName("BedWarQualifyingHistoryDetail-WinRate-Text", GUIType.StaticText)
    self.stWinStreakText = self:getChildWindowByName("BedWarQualifyingHistoryDetail-WinStreak-Text", GUIType.StaticText)
    self.stMVPText = self:getChildWindowByName("BedWarQualifyingHistoryDetail-MVP-Text", GUIType.StaticText)
    self.stGoldMedalText = self:getChildWindowByName("BedWarQualifyingHistoryDetail-GoldMedal-Text", GUIType.StaticText)
    self.llContent = self:getChildWindowByName("BedWarQualifyingHistoryDetail-Content", GUIType.Layout)
    self.siEmpty = self:getChildWindowByName("BedWarQualifyingHistoryDetail-Empty", GUIType.StaticImage)
    self.stEmptyText = self:getChildWindowByName("BedWarQualifyingHistoryDetail-Empty-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingHistoryDetailWindow:initView()
    self.lvMapList = IGUIListView.new("BedWarQualifyingHistoryDetail-Map-List", self.llContent, nil, Orientation.Horizontal)
    self.lvMapList:setItemSpace(6)
    ---@type BedWarQualifyingHistoryMapAdapter
    self.mapAdapter = UIHelper.newGameAdapter("BedWarQualifyingHistoryMapAdapter")
    self.lvMapList:setAdapter(self.mapAdapter)
    self.stRankText:SetText(Lang:getString("gui.rank"))
    self.stWinTimesText:SetText(Lang:getString("gui.win.times"))
    self.stWinRateText:SetText(Lang:getString("gui.win.rate"))
    self.stWinStreakText:SetText(Lang:getString("gui.max.win.streak"))
    self.stMVPText:SetText("MVP")
    self.stGoldMedalText:SetText(Lang:getString("gui.gold.medal"))
    self.stEmptyText:SetText(Lang:getString("gui.no.data"))
end

---@private
function GUIBedWarQualifyingHistoryDetailWindow:initEvent()

end

---@param data HistoryQualifyingData
function GUIBedWarQualifyingHistoryDetailWindow:onDataChanged(data)
    local rankDataDetail = data.rankDataDetail or {}
    local roundNum, winNum, mvpNum, highConsecutiveWins, goldMedalNum = 0, 0, 0, 0, 0
    for _, item in pairs(rankDataDetail) do
        roundNum = roundNum + item.roundNum
        winNum = winNum + item.winNum
        mvpNum = mvpNum + item.mvpNum
        goldMedalNum = goldMedalNum + item.goldMedalNum
        highConsecutiveWins = math.max(highConsecutiveWins, item.highConsecutiveWins)
    end
    if data.rank and data.rank <= 10000 then
        self.stRankText:SetText(Lang:getString("gui.rank") .. " : -")
    else
        self.stRankText:SetText(Lang:getString("gui.rank") .. " : " .. Lang:getString("gui.not.in.rank"))
    end
    self.stWinTimesText:SetText(Lang:getString("gui.win.times") .. " : " .. winNum)
    if roundNum ~= 0 then
        self.stWinRateText:SetText(Lang:getString("gui.win.rate") .. " : " .. (math.floor(winNum * 1000 / roundNum) / 10) .. "%")
    else
        self.stWinRateText:SetText(Lang:getString("gui.win.rate") .. " : " .. "0%")
    end
    self.stWinStreakText:SetText(Lang:getString("gui.max.win.streak") .. " : " .. highConsecutiveWins)
    self.stMVPText:SetText("MVP : " .. mvpNum)
    self.stGoldMedalText:SetText(Lang:getString("gui.gold.medal") .. " : " .. goldMedalNum)
    self.mapAdapter:setData(rankDataDetail)
    self.siEmpty:SetVisible(#rankDataDetail == 0)
end

---@param item GUIBedWarQualifyingHistoryItemWindow
function GUIBedWarQualifyingHistoryDetailWindow:openByItem(item)
    if self.isLocked then
        return
    end
    if self.curAttachItem then
        self:closeByItem(self.curAttachItem, function()
            self.isLocked = true
            self.curAttachItem = item
            self.curAttachItem:openDetail(self, function()
                self.isLocked = false
            end)
        end)
        return
    end
    self.isLocked = true
    self.curAttachItem = item
    self.curAttachItem:openDetail(self, function()
        self.isLocked = false
    end)
end

---@param item GUIBedWarQualifyingHistoryItemWindow
function GUIBedWarQualifyingHistoryDetailWindow:closeByItem(item, callback)
    if self.isLocked then
        return
    end
    self.isLocked = true
    item:closeDetail(self, function()
        self:removeFromParent()
        if callback then
            callback()
        end
    end)
end

function GUIBedWarQualifyingHistoryDetailWindow:removeFromParent()
    local parent = self.root:GetParent()
    if parent then
        parent:RemoveChildWindow1(self.root)
    end
    if self.curAttachItem then
        self.curAttachItem.wDetail = nil
        self.curAttachItem = nil
    end
    self.isLocked = false
end

return GUIBedWarQualifyingHistoryDetailWindow
