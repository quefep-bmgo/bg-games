---@class GUIBedWarHallChatItemContentVoiceWindow : IGUIWindow
local GUIBedWarHallChatItemContentVoiceWindow = class("GUIBedWarHallChatItemContentVoiceWindow", IGUIWindow)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")

---@private
function GUIBedWarHallChatItemContentVoiceWindow:ctor(...)
	self.super.ctor(self, "BedWarHallChatItemContentVoice.json", ...)
end

---@private
function GUIBedWarHallChatItemContentVoiceWindow:onLoad()
	self.siArrow = self:getChildWindowByName("BedWarHallChatItemContentVoice-Arrow", GUIType.StaticImage)
	self.siVoice = self:getChildWindowByName("BedWarHallChatItemContentVoice-Voice", GUIType.StaticImage)
	self:initEvent()
end

---@private
function GUIBedWarHallChatItemContentVoiceWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		self:playVoice()
	end)
end

---@param data ChatMsgData
function GUIBedWarHallChatItemContentVoiceWindow:onDataChanged(data)
	self.data = data
	if data.sendId == Game:getPlatformUserId() then
		self.siArrow:SetXPosition({ 1, 0 })
		self.siArrow:SetProperty("Rotate", 180)
		self.siVoice:SetProperty("Rotate", 180)
	end
end

function GUIBedWarHallChatItemContentVoiceWindow:playVoice()
	---播放语音消息
	local msgData = self.data.data
	if not msgData.uri then
		return
	end
	ChatClient:playVoice(msgData.uri)
end

return GUIBedWarHallChatItemContentVoiceWindow
