---@class UIBedWarQualifyingMatchLayout : IGUILayout
local UIBedWarQualifyingMatchLayout = class("UIBedWarQualifyingMatchLayout", IGUILayout)
---@type QualifyingService
local QualifyingService = T(Global, "QualifyingService")

---@private
function UIBedWarQualifyingMatchLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingMatch.json", parent)
end

---@private
function UIBedWarQualifyingMatchLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingMatchLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIBedWarQualifyingMatchLayout:initCreateEvent()
    self:registerEvent(Events.QualifyingMatchSuccessEvent, function()
        self:show()
    end)
end

---@private
function UIBedWarQualifyingMatchLayout:onLoad()
    self.stTitle = self:getChildWindow("BedWarQualifyingMatch-Title", GUIType.StaticText)
    self.stTip = self:getChildWindow("BedWarQualifyingMatch-Tip", GUIType.StaticText)
    self.stReady = self:getChildWindow("BedWarQualifyingMatch-Ready", GUIType.StaticText)
    self.llTeams = self:getChildWindow("BedWarQualifyingMatch-Teams", GUIType.Layout)
    self.btnConfirm = self:getChildWindow("BedWarQualifyingMatch-Confirm", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarQualifyingMatchLayout:isShowAnim()
    return false
end

function UIBedWarQualifyingMatchLayout:hide(force)
    if not force then
        return
    end
    self.super.hide(self)
end

---@private
function UIBedWarQualifyingMatchLayout:initView()
    self.stTitle:SetText(Lang:getString("gui.qualifying.match.title"))
    self.btnConfirm:SetText(Lang:getString("gui.qualifying.match.ready"))
end

---@private
function UIBedWarQualifyingMatchLayout:initEvent()
    self.btnConfirm:registerEvent(GUIEvent.ButtonClick, function()
        self.btnConfirm:SetVisible(false)
        QualifyingService:sendPlayerReady()
    end)
    self:registerEvent(Events.QualifyingPlayerReadyEvent, function(count)
        local userCount = #QualifyingService:getMatchUserList()
        self.stReady:SetText(Lang:getString("gui.qualifying.match.ready") .. " (" .. count .. "/" .. userCount .. ")")
    end)
    self:registerEvent(Events.QualifyingMatchCancelEvent, function()
        self:hide(true)
    end)
end

---@private
function UIBedWarQualifyingMatchLayout:onShow()
    self.btnConfirm:SetVisible(true)
    self:initTeamList()
    self:setCountdown()
end

---@private
function UIBedWarQualifyingMatchLayout:onHide()
    LuaTimer:cancel(self.countdown)
end

---@private
function UIBedWarQualifyingMatchLayout:initTeamList()
    if self.gvTeamList then
        return
    end
    self.gvTeamList = IGUIGridView.new("BedWarQualifyingMatch-Team-List", self.llTeams)
    self.gvTeamList:setConfig(80, 20, 2)
    if #QualifyingService:getMatchUserList() == 0 then
        return
    end
    local userCount = #QualifyingService:getMatchUserList()
    self.stReady:SetText(Lang:getString("gui.qualifying.match.ready") .. " (0/" .. userCount .. ")")
    local teamCount = userCount % 4 == 0 and userCount / 4 or math.floor(userCount / 4) + 1
    for i = 1, teamCount do
        ---@type GUIBedWarQualifyingMatchTeamWindow
        local team = UIHelper.newGameGUIWindow("GUIBedWarQualifyingMatchTeam")
        team:onDataChanged(i)
        self.gvTeamList:addItem(team)
    end
end

---@private
function UIBedWarQualifyingMatchLayout:setCountdown()
    LuaTimer:cancel(self.countdown)
    local countdown = 5
    self.stTip:SetText(Lang:getString("gui.qualifying.match.tip") .. "(" .. countdown .. "s)")
    self.countdown = LuaTimer:scheduleTimer(function()
        countdown = countdown - 1
        self.stTip:SetText(Lang:getString("gui.qualifying.match.tip") .. "(" .. countdown .. "s)")
    end, 1000, countdown)
end

return UIBedWarQualifyingMatchLayout