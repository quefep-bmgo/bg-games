---@class GUIBedWarHallChatItemContentImageWindow : IGUIWindow
local GUIBedWarHallChatItemContentImageWindow = class("GUIBedWarHallChatItemContentImageWindow", IGUIWindow)

---@private
function GUIBedWarHallChatItemContentImageWindow:ctor(...)
    self.super.ctor(self, "BedWarHallChatItemContentImage.json", ...)
end

---@private
function GUIBedWarHallChatItemContentImageWindow:onLoad()
    self.siArrow = self:getChildWindowByName("BedWarHallChatItemContentImage-Arrow", GUIType.StaticImage)
    self.uivImage = self:getChildWindowByName("BedWarHallChatItemContentImage-Image", GUIType.UrlImage)
    self:initEvent()
end

---@private
function GUIBedWarHallChatItemContentImageWindow:initEvent()

end

---@param data ChatMsgData
function GUIBedWarHallChatItemContentImageWindow:onDataChanged(data)
    if data.sendId == Game:getPlatformUserId() then
        self.siArrow:SetXPosition({ 1, 0 })
        self.siArrow:SetProperty("Rotate", 180)
    end
    self.uivImage:setUrl(data.data.uri)
	local height = 120
    self.root:SetHeight({ 0, height })
    return height
end

return GUIBedWarHallChatItemContentImageWindow
