---@class GUIBedWarQualifyingSeasonChallengeRewardWindow : IGUIWindow
local GUIBedWarQualifyingSeasonChallengeRewardWindow = class("GUIBedWarQualifyingSeasonChallengeRewardWindow", IGUIWindow)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
local SelectedRewardId = -1

---@private
function GUIBedWarQualifyingSeasonChallengeRewardWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingSeasonChallengeReward.json", ...)
end

---@private
function GUIBedWarQualifyingSeasonChallengeRewardWindow:onLoad()
    self.siBg = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward-Bg", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward-Image", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward-Count", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward-Score", GUIType.StaticText)
    self.siEffect = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward-Effect", GUIType.StaticImage)
    self.siShadow = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward-Shadow", GUIType.StaticImage)
    self.siSelected = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward-Selected", GUIType.StaticImage)
    self:initEvent()
end

---@private
function GUIBedWarQualifyingSeasonChallengeRewardWindow:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
        if score >= self.data.Score then
            if not CQualifyingController:sendReceiveChallengeReward(Define.GameMode.Qualifying, self.data.Id) then
                self:setSelectId(self.rewardId)
                GUIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(self.data.ShowDetailId)
            end
        else
            self:setSelectId(self.rewardId)
            GUIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(self.data.ShowDetailId)
        end
    end)
end

function GUIBedWarQualifyingSeasonChallengeRewardWindow:setSelectId(rewardId)
    SelectedRewardId = rewardId
end

---@param data QualifyingSeasonChallengeRewardData
function GUIBedWarQualifyingSeasonChallengeRewardWindow:onDataChanged(data)
    self.data = data
    self.rewardId = self.data.Id
    local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
    local isRewardReceived = CQualifyingController:isChallengeRewardReceived(Define.GameMode.Qualifying, data.Id)
    if isRewardReceived then
        self.siShadow:SetVisible(true)
        self.stScore:SetText(Lang:getString("gui.gained"))
    else
        self.stScore:SetText(data.Score)
        self.siShadow:SetVisible(false)
    end
    local canReceive = score >= data.Score and (not isRewardReceived)
    if canReceive then
        self.siBg:SetImage("set:bed_war_2_qualifying_season_challenge.json image:img_0_icon_receive")
    else
        self.siBg:SetImage("set:bed_war_2_qualifying_season_challenge.json image:img_0_icon_ordinary")
    end
    self.siEffect:SetVisible(data.ShowEffect)
    self.stCount:SetText("x" .. data.RewardCount)
    local cfg = RewardConfig.findRewardById(data.RewardId)
    if cfg then
        self.siImage:SetImage(cfg.ShowDetail.image)
    else
        self.siImage:SetImage("")
    end
    self.siSelected:SetVisible(SelectedRewardId == self.rewardId)
end

return GUIBedWarQualifyingSeasonChallengeRewardWindow
