---@class GUIBedWarUIClickPopUpControlWindow : IGUIWindow
local GUIBedWarUIClickPopUpControlWindow = class("GUIBedWarUIClickPopUpControlWindow", IGUIWindow)

local function setTouchable(window, touchable)
    window:SetTouchable(touchable)
    local count = window:GetChildCount()
    if count == 0 then
        return
    end
    for index = 1, count do
        setTouchable(window:GetChildByIndex(index - 1), touchable)
    end
end

local Alignment = {
    Vertical = 1,
    Horizontal = 2
}

---@type GUILayout[]
local LayoutTable = {}
local ButtonListTable = {}
local itemSpace = 6
local buttonWidth = 54
local buttonHeight = 54

---@private
function GUIBedWarUIClickPopUpControlWindow:ctor(...)
    self.super.ctor(self, "BedWarUIClickPopUpControl.json", ...)
end

---@private
function GUIBedWarUIClickPopUpControlWindow:onLoad()
    self.cbSwitch = self:getChildWindowByName("BedWarUIClickPopUpControl-Switch", GUIType.CheckBox)
    self.llRightList = self:getChildWindowByName("BedWarUIClickPopUpControl-Right-List", GUIType.Layout)
    self.llLeftList = self:getChildWindowByName("BedWarUIClickPopUpControl-Left-List", GUIType.Layout)
    self.llTopList = self:getChildWindowByName("BedWarUIClickPopUpControl-Top-List", GUIType.Layout)
    self.llBottomList = self:getChildWindowByName("BedWarUIClickPopUpControl-Bottom-List", GUIType.Layout)

    LayoutTable[Define.ClickPopUpLayout.Right] = self.llRightList
    LayoutTable[Define.ClickPopUpLayout.Left] = self.llLeftList
    LayoutTable[Define.ClickPopUpLayout.Top] = self.llTopList
    LayoutTable[Define.ClickPopUpLayout.Bottom] = self.llBottomList
    self:initEvent()
end

---@private
function GUIBedWarUIClickPopUpControlWindow:initEvent()
    self.cbSwitch:registerEvent(GUIEvent.CheckStateChanged, function()
        for type, layout in pairs(LayoutTable) do
            local buttonList = ButtonListTable[type]
            if buttonList and #buttonList > 0 then
                self:showList(layout, type, self.cbSwitch:GetChecked())
            end
        end
    end)
end

---@param layoutType number
---@param buttonName string
---@param normalImage string
---@param pushedImage string
---@param callback function
function GUIBedWarUIClickPopUpControlWindow:addButton(layoutType, buttonName, normalImage, pushedImage, callback)
    local layout = LayoutTable[layoutType]
    if not layout then
        return nil
    end
    if not ButtonListTable[layoutType] then
        ButtonListTable[layoutType] = {}
    end

    local button = GUIManager:createGUIWindow(GUIType.Button, buttonName)
    button:SetNormalImage(normalImage)
    button:SetPushedImage(pushedImage)
    --button:SetProperty("Material", "CullBackLinear")
    if callback ~= nil then
        button:registerEvent(GUIEvent.ButtonClick, callback)
    end
    layout:AddChildWindow(button)
    table.insert(ButtonListTable[layoutType], button)

    self:setButtonPos(button, #ButtonListTable[layoutType], layoutType)
    return button
end

---@param buttonName string
function GUIBedWarUIClickPopUpControlWindow:removeButton(layoutType, buttonName)
    local layout = LayoutTable[layoutType]
    if not layout then
        return
    end
    if not ButtonListTable[layoutType] then
        return
    end

    for index, _button in pairs(ButtonListTable[layoutType]) do
        if _button:GetName() == buttonName then
            table.remove(ButtonListTable[layoutType], index)
            layout:RemoveChildWindow(buttonName)
            GUIManager:destroyGUIWindow(GUIManager:getWindowByName(buttonName))
            break
        end
    end

    self:refreshButton(layoutType)
end

function GUIBedWarUIClickPopUpControlWindow:refreshButton(layoutType)
    for buttonIndex, button in pairs(ButtonListTable[layoutType]) do
        self:setButtonPos(button, buttonIndex, layoutType)
    end
end

function GUIBedWarUIClickPopUpControlWindow:setButtonPos(button, buttonIndex, layoutType)
    local curPos = (buttonIndex - 1) * (itemSpace + buttonWidth)
    if layoutType == Define.ClickPopUpLayout.Right then
        button:SetHorizontalAlignment(HorizontalAlignment.Left)
        button:SetVerticalAlignment(VerticalAlignment.Center)
        button:SetArea({ 0, curPos }, { 0, 0 }, { 0, buttonWidth }, { 0, buttonHeight })
    elseif layoutType == Define.ClickPopUpLayout.Left then
        button:SetHorizontalAlignment(HorizontalAlignment.Right)
        button:SetVerticalAlignment(VerticalAlignment.Center)
        button:SetArea({ 0, -curPos }, { 0, 0 }, { 0, buttonWidth }, { 0, buttonHeight })
    elseif layoutType == Define.ClickPopUpLayout.Top then
        button:SetHorizontalAlignment(HorizontalAlignment.Center)
        button:SetVerticalAlignment(VerticalAlignment.Bottom)
        button:SetArea({ 0, 0 }, { 0, -curPos }, { 0, buttonWidth }, { 0, buttonHeight })
    elseif layoutType == Define.ClickPopUpLayout.Bottom then
        button:SetHorizontalAlignment(HorizontalAlignment.Center)
        button:SetVerticalAlignment(VerticalAlignment.Top)
        button:SetArea({ 0, 0 }, { 0, curPos }, { 0, buttonWidth }, { 0, buttonHeight })
    end
end

---@private
---@param layout GUILayout
---@param layoutType number
---@param check boolean
function GUIBedWarUIClickPopUpControlWindow:showList(layout, layoutType, check)
    LuaTimer:cancel(self.listKey or 0)
    if layoutType == Define.ClickPopUpLayout.Right or layoutType == Define.ClickPopUpLayout.Left then
        if check then
            local width = #ButtonListTable[layoutType] * buttonWidth + (#ButtonListTable[layoutType] - 1) * itemSpace
            setTouchable(layout, true)
            self.listKey = LuaTimer:scheduleTimer(function()
                local curWidth = math.floor(layout:GetPixelSize().x)
                if curWidth == width then
                    LuaTimer:cancel(self.listKey or 0)
                else
                    if curWidth + 3 < width - 60 then
                        layout:SetWidth({ 0, curWidth + 20 })
                    else
                        layout:SetWidth({ 0, width })
                    end
                end
            end, 10)
        else
            setTouchable(layout, false)
            self.listKey = LuaTimer:scheduleTimer(function()
                local curWidth = math.floor(layout:GetPixelSize().x)
                if curWidth == 0 then
                    LuaTimer:cancel(self.listKey or 0)
                else
                    if curWidth - 3 > 0 then
                        layout:SetWidth({ 0, curWidth - 20 })
                    else
                        layout:SetWidth({ 0, 0 })
                    end
                end
            end, 10)
        end
    elseif layoutType == Define.ClickPopUpLayout.Top or layoutType == Define.ClickPopUpLayout.Bottom then
        if check then
            local height = #ButtonListTable[layoutType] * buttonWidth + (#ButtonListTable[layoutType] - 1) * itemSpace
            setTouchable(layout, true)
            self.listKey = LuaTimer:scheduleTimer(function()
                local curHeight = math.floor(layout:GetPixelSize().y)
                if curHeight == height then
                    LuaTimer:cancel(self.listKey or 0)
                else
                    if curHeight + 3 < height - 60 then
                        layout:SetHeight({ 0, curHeight + 20 })
                    else
                        layout:SetHeight({ 0, curHeight })
                    end
                end
            end, 10)
        else
            setTouchable(layout, false)
            self.listKey = LuaTimer:scheduleTimer(function()
                local curHeight = math.floor(layout:GetPixelSize().y)
                if curHeight == 0 then
                    LuaTimer:cancel(self.listKey or 0)
                else
                    if curHeight - 3 > 0 then
                        layout:SetHeight({ 0, curHeight - 20 })
                    else
                        layout:SetHeight({ 0, 0 })
                    end
                end
            end, 10)
        end
    end
end

---@param touchable boolean
function GUIBedWarUIClickPopUpControlWindow:setChecked(touchable)
    self.cbSwitch:SetChecked(touchable)
end

---@return boolean
function GUIBedWarUIClickPopUpControlWindow:getChecked()
    return self.cbSwitch:GetChecked()
end

return GUIBedWarUIClickPopUpControlWindow
