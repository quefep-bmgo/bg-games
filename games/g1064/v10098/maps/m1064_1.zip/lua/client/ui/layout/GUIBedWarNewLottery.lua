---@class UIBedWarNewLotteryLayout : IGUILayout
local UIBedWarNewLotteryLayout = class("UIBedWarNewLotteryLayout", IGUILayout)

---@private
function UIBedWarNewLotteryLayout:isDelayLoad()
	return true
end

---@private
function UIBedWarNewLotteryLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIBedWarNewLotteryLayout:initCreateEvent()

end

---@private
function UIBedWarNewLotteryLayout:onLoad()
	self.btnCloseMask = self:getChildWindow("BedWarNewLottery-Close-Mask", GUIType.Button)
	self.llMain = self:getChildWindow("BedWarNewLottery-Main", GUIType.Layout)
	self.siBg = self:getChildWindow("BedWarNewLottery-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("BedWarNewLottery-Content", GUIType.Layout)
	self.llTitle = self:getChildWindow("BedWarNewLottery-Title", GUIType.Layout)
	self.stTitleText = self:getChildWindow("BedWarNewLottery-Title-Text", GUIType.StaticText)
	self.llMoney = self:getChildWindow("BedWarNewLottery-Money", GUIType.Layout)
	self.btnClose = self:getChildWindow("BedWarNewLottery-Close", GUIType.Button)

	self.lvMoney = IGUIListView.new("BedWarNewLottery-Money-List", self.llMoney, nil, Orientation.Horizontal)
	self.lvMoney:setItemSpace(25)
	self.maxMoneyWidth = self.llMoney:GetPixelSize().x

	local lottery = UIHelper.newGameGUIWindow("GUIBedWarLottery3")
	self.llContent:AddChildWindow(lottery.root)
	self:updateMoneyList({
		{
			RealId = 5,
			Id = 0,
			ItemId = 0,
			Sort = 1
		},
		{
			RealId = 1,
			Id = 0,
			ItemId = 0,
			Sort = 2
		}
	})
	self:initView()
	self:initEvent()
end

---@private
function UIBedWarNewLotteryLayout:initView()
	self.stTitleText:SetText(Lang:getString(""))
end

---@private
function UIBedWarNewLotteryLayout:initEvent()
	self.btnCloseMask:registerEvent(GUIEvent.ButtonClick, function()
		self:hide(true)
	end)
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide(true)
	end)
end

function UIBedWarNewLotteryLayout:updateMoneyList(currencyList)
	if not currencyList then
		return
	end
	self.lvMoney:clearItems()
	local width = math.min(#currencyList * 153 + (#currencyList - 1) * 25, self.maxMoneyWidth)
	self.llMoney:SetWidth({ 0, width })
	for _, data in pairs(currencyList) do
		---@type GUICurrency
		local money = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency2.json")
		money:onDataChanged(data)
		self.lvMoney:addItem(money)
	end
end

function UIBedWarNewLotteryLayout:show(playSound)
	if playSound then
		SoundUtil.playSound(SoundConfig.openStore)
	end
	self.super.show(self)
end

function UIBedWarNewLotteryLayout:onShow()

end

function UIBedWarNewLotteryLayout:onTick()
	for _, item in pairs(self.lvMoney.items) do
		item:onTick()
	end
end

function UIBedWarNewLotteryLayout:hide(playSound)
	if playSound then
		SoundUtil.playSound(SoundConfig.closeStore)
	end
	self.super.hide(self)
end

return UIBedWarNewLotteryLayout
