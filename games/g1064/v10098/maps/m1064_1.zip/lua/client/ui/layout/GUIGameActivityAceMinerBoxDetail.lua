---@class UIGameActivityAceMinerBoxDetailLayout : IGUILayout
local UIGameActivityAceMinerBoxDetailLayout = class("UIGameActivityAceMinerBoxDetailLayout", IGUILayout)

---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")

---@private
function UIGameActivityAceMinerBoxDetailLayout:ctor(parent)
	self.super.ctor(self, "GameActivityAceMinerBoxDetail.json", parent)
end

---@private
function UIGameActivityAceMinerBoxDetailLayout:isDelayLoad()
	return true
end

---@private
function UIGameActivityAceMinerBoxDetailLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGameActivityAceMinerBoxDetailLayout:initCreateEvent()

end

local uiSetting = {
	area = {{ 0, 0 }, { 0, 0 }, { 0.614844, 0 }, { 0.656944, 0 }},
	bg = "set:bed_war_3_common_dialog.json image:img_9_board01",
	offset = "10 10 70 10",
	listBgArea = {{ 0, 0 }, { 0, -20 }, { 0.958069, 0 }, { 1, -96 }},
	listBg = "",
	listBgColor = { 8 / 255, 23 / 255, 47 / 255, 0.8 },
	titleColor = { 1, 1, 1, 0.8 },
	titleBorder = "false",
	titleHeight = {0, 63},
	coreItemBg = "set:bedwar_new_license.json image:img_0_special",
	norItemBg = "set:bedwar_new_license.json image:img_0_ordinary"
}

---@private
function UIGameActivityAceMinerBoxDetailLayout:onLoad()
	self.btnClose = self:getChildWindow("AceMinerBoxDetail-Close", GUIType.Button)
	self.llContent = self:getChildWindow("AceMinerBoxDetail-Content", GUIType.Layout)
	self.stTitle = self:getChildWindow("AceMinerBoxDetail-Title", GUIType.StaticText)
	self.siRewardListBg = self:getChildWindow("AceMinerBoxDetail-Reward-List-Bg", GUIType.StaticImage)
	self.llRewardItems = self:getChildWindow("AceMinerBoxDetail-Reward-Items", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function UIGameActivityAceMinerBoxDetailLayout:initView()
	self.stTitle:SetText(Lang:getString(""))
end

---@private
function UIGameActivityAceMinerBoxDetailLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

function UIGameActivityAceMinerBoxDetailLayout:setData(data)
	if data.title then
		self.stTitle:SetText(Lang:getString(data.title))
	end
end

function UIGameActivityAceMinerBoxDetailLayout:updateUIByType()
	self.llContent:SetArea(uiSetting.area[1], uiSetting.area[2], uiSetting.area[3], uiSetting.area[4])
	self.llContent:SetBackImage(uiSetting.bg)
	self.llContent:SetProperty("StretchOffset", uiSetting.offset)
	self.siRewardListBg:SetArea(uiSetting.listBgArea[1], uiSetting.listBgArea[2], uiSetting.listBgArea[3], uiSetting.listBgArea[4])
	self.siRewardListBg:SetImage(uiSetting.listBg)
	self.siRewardListBg:SetBackgroundColor(uiSetting.listBgColor)
	self.stTitle:SetTextColor(uiSetting.titleColor)
	self.stTitle:SetProperty("TextBorder", uiSetting.titleBorder)
	self.stTitle:SetHeight(uiSetting.titleHeight)
end

function UIGameActivityAceMinerBoxDetailLayout:onShow(cfg)
	self:updateUIByType()
	self.llRewardItems:CleanupChildren()
	local gvItems = IGUIGridView.new("GameActivityAceMinerBoxDetail-Item", self.llRewardItems)
	gvItems:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	gvItems:setConfig(6, 6, 7)
	gvItems.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	gvItems.root:SetVerticalAlignment(VerticalAlignment.Center)
	local ContentSize = self.llRewardItems:GetPixelSize().x
	local itemHeightAndHeight = (ContentSize - 6 * 6) / 7
	for i, v in pairs(cfg) do
		local rewardCfg = CommonActivityConfig:getRewardById(v.id)
		local Item = UIHelper.newGameGUIWindow("GUILotteryBoxItem", "LotteryBoxItem.json")
		Item:setWidth({ 0, itemHeightAndHeight })
		Item:setHeight({ 0, itemHeightAndHeight })
		Item:onSetImage(rewardCfg.image, Define.BoxDetailUIType.License)
		Item.bg:SetImage(uiSetting.norItemBg)
		if v.num then
			Item:setNum(v.num)
		end
		if v.isCore == 2 then
			Item.bg:SetImage(uiSetting.coreItemBg)
		end
		Item:registerClick(rewardCfg.showDetailId)
		gvItems:addItem(Item)
	end
end

return UIGameActivityAceMinerBoxDetailLayout
