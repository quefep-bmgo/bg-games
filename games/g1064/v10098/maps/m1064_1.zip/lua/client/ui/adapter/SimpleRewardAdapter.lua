
---@class SimpleRewardAdapter : IDataAdapter
local SimpleRewardAdapter = class("SimpleRewardAdapter", IDataAdapter)

function SimpleRewardAdapter:setItemSize(width, height)
    self.width = width
    self.height = height
end

function SimpleRewardAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUISimpleRewardCell")
end

function SimpleRewardAdapter:getJsonName()
    return "SimpleRewardCell.json"
end

function SimpleRewardAdapter:getItemWidth()
    return { 0, self.width or 96 }
end

function SimpleRewardAdapter:getItemHeight()
    return { 0, self.height or 126 }
end

return SimpleRewardAdapter