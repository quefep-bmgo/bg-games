---@class BedWarActionShowItemAdapter : IDataAdapter
local BedWarActionShowItemAdapter = class("BedWarActionShowItemAdapter", IDataAdapter)

function BedWarActionShowItemAdapter:setItemSize(width, height)
    self.width = width
    self.height = height
end

function BedWarActionShowItemAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIBedWarActionShowItem")
end

function BedWarActionShowItemAdapter:getJsonName()
    return "BedWarActionShowItem.json"
end

function BedWarActionShowItemAdapter:getItemWidth()
    return { 0, self.width }
end

function BedWarActionShowItemAdapter:getItemHeight()
    return { 0, self.height }
end

return BedWarActionShowItemAdapter