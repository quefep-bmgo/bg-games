---@class GUIBedWarNewStoreGoodsGroupWindow2 : IGUIWindow
local GUIBedWarNewStoreGoodsGroupWindow2 = class("GUIBedWarNewStoreGoodsGroupWindow2", IGUIWindow)

local initListIndex = 1

---@private
function GUIBedWarNewStoreGoodsGroupWindow2:ctor(...)
	self.super.ctor(self, "BedWarNewStoreGoodsGroup2.json", ...)
end

---@private
function GUIBedWarNewStoreGoodsGroupWindow2:onLoad()
	self.stTitle = self:getChildWindowByName("BedWarStoreGoodsGroup-title", GUIType.StaticText)
	self.llList = self:getChildWindowByName("BedWarStoreGoodsGroup-list", GUIType.Layout)
	self.siTitleIcon = self:getChildWindowByName("BedWarStoreGoodsGroup-Title-Icon", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarNewStoreGoodsGroupWindow2:initView()
	self.stTitle:SetText()
	self.items = {}
end

---@private
function GUIBedWarNewStoreGoodsGroupWindow2:initEvent()

end

function GUIBedWarNewStoreGoodsGroupWindow2:filtrationData(data)
	local arr = {}
	local LevelGroups = {}
	for _, v in pairs(data) do
		if not LevelGroups[v.config.LevelGroup] then
			table.insert(arr, v)
		end
		if v.config.LevelGroup and v.config.LevelGroup ~= "#" and not v.config.SkipLevel then
			LevelGroups[v.config.LevelGroup] = true
		end
	end
	return arr
end

---@param data table
function GUIBedWarNewStoreGoodsGroupWindow2:onDataChanged(data, contentWidth, id)
	local imagePath = StoreConfig:getShowGroupIconByKey(id)
	self.siTitleIcon:SetImage(imagePath)
	local width, height = UIHelper:getImageFileSize(imagePath)
	self.siTitleIcon:SetWidth({0, width})
	self.siTitleIcon:SetHeight({ 0, height })

	self.llList:Rename("BedWarStoreGoodsGroup-list"..id)
	self.data = self:filtrationData(data)
	self.curId = id
	self.stTitle:SetText(Lang:getString(StoreConfig:getShowGroupLangByKey(id)))
	local contentWidth = contentWidth
	local row = 4
	local itemWidth = (contentWidth - 63) / row
	local itemHeight = (itemWidth / 114) * 145
	local index = 1
	for _, v in pairs(self.data or {}) do
		if not self.items[index] then
			self.items[index] = UIHelper.newGameGUIWindow("GUINewStoreGoods2","BedWarNewStoreGoods2.json")
			local px = (index - 1) % row * (itemWidth + 21)
			local py = math.floor((index - 1) / row) * (itemHeight + 16)
			self.items[index]:setArea({ 0,  px }, { 0, py }, { 0, itemWidth }, { 0, itemHeight })
			self.llList:AddChildWindow(self.items[index].root)
		end
		self.items[index]:onDataChanged(v)
		index = index + 1
	end
end

return GUIBedWarNewStoreGoodsGroupWindow2
