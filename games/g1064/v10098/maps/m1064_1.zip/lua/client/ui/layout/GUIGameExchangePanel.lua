---@type LotteryExchangeStoreConfig
local LotteryExchangeStoreConfig = Plugins.Require("activity", "common.config.LotteryExchangeStore")

---@class GUIGameExchangePanelWindow :IGUILayout
local GUIGameExchangePanelWindow = class("GUIGameExchangePanelWindow", IGUILayout)

---@private
function GUIGameExchangePanelWindow:onLoad()
	self.btnClose = self:getChildWindow("ExchangePage-Close", GUIType.Button)
	self.llContainer = self:getChildWindow("ExchangePage-Container", GUIType.Layout)
	self.stTitle = self:getChildWindow("ExchangePage-Title", GUIType.StaticText)
	self.gvGoodsList = IGUIGridView.new("ExchangePage-GoodsList", self.llContainer)
	self.gvGoodsList:setConfig(18, 10, 4)
	---@type ExchangeRewardAdapter
	self.goodsAdapter = UIHelper.requireAdapter("ExchangeRewardAdapter", false, "ui_activity").new()
	self.goodsAdapter:setActivityMgr(self.mgr)
	self.gvGoodsList:setAdapter(self.goodsAdapter)

	self.stTitle:SetText(Lang:getString("CommonActivity__Shop"))
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

---@private
function GUIGameExchangePanelWindow:initView()
end

function GUIGameExchangePanelWindow:onShow(activityCfg)
	local goodsList = LotteryExchangeStoreConfig:getConfigByGroup(activityCfg.exchangeStoreGroup)
	for _, item in pairs(goodsList) do
		item.activityCfg = activityCfg
	end
	self.goodsAdapter:setData(goodsList)
end

return GUIGameExchangePanelWindow
