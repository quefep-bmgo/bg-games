---@class GUIBedWarNewStoreGoodsWindow : IGUIWindow
local GUIBedWarNewStoreGoodsWindow = class("GUIBedWarNewStoreGoodsWindow", IGUIWindow)

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIBedWarNewStoreGoodsWindow:onLoad()
    self.llContent = self:getChildWindowByName("BedWarNewStoreGoods-Content", GUIType.Layout)
    self.stTime = self:getChildWindowByName("BedWarNewStoreGoods-Time", GUIType.StaticText)
    self.siNewBg = self:getChildWindowByName("BedWarNewStoreGoods-New-Bg", GUIType.StaticImage)
    self.stNewText = self:getChildWindowByName("BedWarNewStoreGoods-New-Text", GUIType.StaticText)
    self.siImage = self:getChildWindowByName("BedWarNewStoreGoods-Image", GUIType.StaticImage)
    self.llBuy = self:getChildWindowByName("BedWarNewStoreGoods-Buy", GUIType.Layout)
    self.siMoneyIcon = self:getChildWindowByName("BedWarNewStoreGoods-Money-Icon", GUIType.StaticImage)
    self.stMoneyText = self:getChildWindowByName("BedWarNewStoreGoods-Money-Text", GUIType.StaticText)
    self.stOriginCost = self:getChildWindowByName("BedWarNewStoreGoods-Origin-Cost", GUIType.StaticText)
    self.siCrossing = self:getChildWindowByName("BedWarNewStoreGoods-Crossing", GUIType.StaticImage)
    self.siDiscountBg = self:getChildWindowByName("BedWarNewStoreGoods-Discount-Bg", GUIType.StaticImage)
    self.stDiscount = self:getChildWindowByName("BedWarNewStoreGoods-Discount", GUIType.StaticText)
    self.llSelect = self:getChildWindowByName("BedWarNewStoreGoods-Select", GUIType.Layout)
    self.siRedPoint = self:getChildWindowByName("BedWarNewStoreGoods-Red-Point", GUIType.StaticImage)
    self.stRemainText = self:getChildWindowByName("BedWarNewStoreGoods-Remain-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarNewStoreGoodsWindow:initView()
    self.goodsInfo = {}
    self.siRedPoint:SetVisible(false)
end

---@private
function GUIBedWarNewStoreGoodsWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        self:select()
    end)

    self:registerEvent(Events.StoreGoodsSelectEvent, function(goodsId)
        if goodsId == self.goodsInfo.goodsId then
            self:select()
        end
    end)
end

function GUIBedWarNewStoreGoodsWindow:select()
    if GUINewStore:getCurrentGoodsId() ~= self.goodsInfo.goodsId then
        GUINewStore:showGoodsDetail(self.goodsInfo)
    end
    if StoreConfig:isNewGoods(self.goodsInfo) then
        ClientHelper.putBoolForKey("ClickStoreNewGoods" .. tostring(self.goodsInfo.goodsId), true)
        UIUtils.updateRedDotCount(Define.RedDotKey.Store .. "_newGoodsId" .. self.goodsInfo.config.Id, 0)
        self:onDataChanged(self.goodsInfo)
    end
end

---@param goodsInfo GoodsInfo
function GUIBedWarNewStoreGoodsWindow:onDataChanged(goodsInfo)
    self.goodsInfo = goodsInfo

    if goodsInfo == nil then
        print("GUIBedWarNewStoreGoodsWindow:onDataChanged  goodsInfo is empty!")
        return
    end

    --- 加载图片
    self.siImage:SetImage(self.goodsInfo.config.showDetail.image)

    --- 是否新品
    self.siNewBg:SetVisible(StoreConfig:isNewGoods(self.goodsInfo))

    --- 特权显示时间
    if not self.goodsInfo.EndTime then
        self.stTime:SetVisible(false)
    else
        local time = self.goodsInfo.EndTime - os.time()
        self.stTime:SetVisible(time > 0)
        self.stTime:SetText(DateUtil.getTimeByTwoPara(time))
    end

    --- 花费图标
    local config = StoreConfig:getCurrencyConfig(self.goodsInfo.config.CurrencyId)
    if config then
        if config.ItemId > 0 then
            GuiItemStack.showItemIcon(self.siMoneyIcon, config.ItemId, 0, "")
        elseif config.RealId > 0 then
            self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(config.RealId))
        else
            self.siMoneyIcon:SetImage("")
        end
    else
        self.siMoneyIcon:SetImage("")
    end

    --- 花费价格
    if self.goodsInfo.config.DiscountPrice == self.goodsInfo.config.Price then
        self.siDiscountBg:SetVisible(false)
        self.stOriginCost:SetVisible(false)
        self.stMoneyText:SetText(self.goodsInfo.config.Price)
    else
        self.siDiscountBg:SetVisible(true)
        local discount = math.floor(self.goodsInfo.config.DiscountPrice / self.goodsInfo.config.Price * 100)
        self.stDiscount:SetText("-" .. (100 - discount) .. "%")
        self.stOriginCost:SetVisible(true)
        self.stMoneyText:SetText(self.goodsInfo.config.DiscountPrice)
        self.stMoneyText:SetWidth({ 0, self.stMoneyText:GetFont():GetTextExtent(self.goodsInfo.config.DiscountPrice, 1) })
        self.stOriginCost:SetText(self.goodsInfo.config.Price)
        self.stOriginCost:SetWidth({ 0, self.stOriginCost:GetFont():GetTextExtent(self.goodsInfo.config.Price, 1) })
    end

    self.llBuy:SetVisible(not goodsInfo.config.AdGoods)
    self.stRemainText:SetVisible(goodsInfo.config.AdGoods and goodsInfo.LimitCount ~= -1)
    if goodsInfo.LimitCount > 0 then
        self.stRemainText:SetTextColor(Color.WHITE)
        self.stRemainText:SetText(Lang:getString("bed_war_new_store_free_goods_count") .. goodsInfo.LimitCount)
    else
        self.stRemainText:SetTextColor({ 255 / 255, 190 / 255, 38 / 255, 1 })
        self.stRemainText:SetText(Lang:getString("bed_war_new_store_free_goods_sell_out"))
    end

    --- 选中状态
    self.llSelect:SetVisible(GUINewStore:getCurrentGoodsId() == self.goodsInfo.goodsId)
end

return GUIBedWarNewStoreGoodsWindow
