---@class GUIBedWarItemTagWindow : IGUIWindow
local GUIBedWarItemTagWindow = class("GUIBedWarItemTagWindow", IGUIWindow)

---@private
function GUIBedWarItemTagWindow:ctor(...)
	self.super.ctor(self, "BedWarItemTag.json", ...)
end

---@private
function GUIBedWarItemTagWindow:onLoad()
	self.siBg = self:getChildWindowByName("BedWarItemTag-Bg", GUIType.StaticImage)
	self.stText = self:getChildWindowByName("BedWarItemTag-Text", GUIType.StaticText)
end

---@param data table
function GUIBedWarItemTagWindow:onDataChanged(data)
	self.siBg:SetImage("set:bed_war_3_dress_store.json image:img_0_label_1")
	self.stText:SetVisible(false)
	if data.bg then
		self.siBg:SetImage(data.bg)
	end
	if data.text then
		self.stText:SetText(data.text)
		self.stText:SetVisible(true)
	end
end

return GUIBedWarItemTagWindow
