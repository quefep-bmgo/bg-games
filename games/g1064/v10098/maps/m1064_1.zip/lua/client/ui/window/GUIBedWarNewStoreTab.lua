---@class GUIBedWarNewStoreTab : IGUIWindow
local GUIBedWarNewStoreTab = class("GUIBedWarNewStoreTab", IGUIWindow)

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIBedWarNewStoreTab:onLoad()
    self.root = self:getChildWindowByName("BedWarNewStoreTab", GUIType.Layout)
    self.stTitle = self:getChildWindowByName("BedWarNewStoreTab-Title", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarNewStoreTab:initView()

end

---@private
function GUIBedWarNewStoreTab:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        GUINewStore:onSelectTab(self.tabId)
    end)

end

---@param data StoreTabsData
function GUIBedWarNewStoreTab:onDataChanged(data)
    self.data = data
    self.tabId = data.Id
    self.root:SetBackImage(data.Bg)
    self.stTitle:SetText(Lang:getString(data.Lang))
end

function GUIBedWarNewStoreTab:setSelected(selected)
    if selected then
        self.root:SetHorizontalAlignment(HorizontalAlignment.Left)
    else
        self.root:SetHorizontalAlignment(HorizontalAlignment.Right)
    end
end

return GUIBedWarNewStoreTab
