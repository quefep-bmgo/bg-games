---@class GUIBedWarHallRuneItemWindow : IGUIWindow
local GUIBedWarHallRuneItemWindow = class("GUIBedWarHallRuneItemWindow", IGUIWindow)
---@type RuneConfig
local RuneConfig = T(Global, "RuneConfig")

---@private
function GUIBedWarHallRuneItemWindow:ctor(...)
	self.super.ctor(self, "BedWarHallRuneItem.json", ...)
end

---@private
function GUIBedWarHallRuneItemWindow:onLoad()
	self.siIcon = self:getChildWindowByName("BedWarHallRuneItem-Icon", GUIType.StaticImage)
	self.stDesc = self:getChildWindowByName("BedWarHallRuneItem-Desc", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarHallRuneItemWindow:initView()

end

---@private
function GUIBedWarHallRuneItemWindow:initEvent()

end

---@param id number
function GUIBedWarHallRuneItemWindow:onDataChanged(id)
	local cfg = RuneConfig:getRuneById(id)
	if not cfg then
		return
	end
	self.siIcon:SetImage(cfg.Image)
	self.stDesc:SetText(Lang:getString(cfg.Des))
end

return GUIBedWarHallRuneItemWindow
