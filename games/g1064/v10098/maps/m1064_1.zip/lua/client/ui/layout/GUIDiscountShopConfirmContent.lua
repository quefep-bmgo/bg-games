---@class UIDiscountShopConfirmContentLayout : IGUILayout
local UIDiscountShopConfirmContentLayout = class("UIDiscountShopConfirmContentLayout", IGUILayout)

---@private
function UIDiscountShopConfirmContentLayout:onLoad()
    self:initView()
end

---@private
function UIDiscountShopConfirmContentLayout:initView()
    self.llGoods = self:getChildWindow("DiscountShopConfirmContent-Goods", GUIType.Layout)
    self.siPriceIcon = self:getChildWindow("DiscountShopConfirmContent-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindow("DiscountShopConfirmContent-Price", GUIType.StaticText)
end

---@param goodsList DiscountShopGoodsData[] | ScoreActivityRewardData[]
function UIDiscountShopConfirmContentLayout:setGoodsList(goodsList, price, priceIcon)
    self.llGoods:CleanupChildren()
    self.llGoods:SetWidth({ 0, 116 * #goodsList + 65 * (#goodsList - 1) })
    for index, goods in pairs(goodsList) do
        ---@type GUIDiscountShopConfirmItemWindow
        local item = UIHelper.newGameGUIWindow("GUIDiscountShopConfirmItem")
        item.root:SetXPosition({ 0, (index - 1) * 181 })
        item:onDataChanged(goods)
		self.llGoods:AddChildWindow(item.root)
    end
	self.stPrice:SetText(price)
    if priceIcon then
        self.siPriceIcon:SetImage(priceIcon)
    else
        self.siPriceIcon:SetImage("set:bed_war_block_shop.json image:icon_cube_border")
    end
end

---@type UIDiscountShopConfirmContentLayout
DiscountShopConfirmContent = buildCustomDialogContent(UIDiscountShopConfirmContentLayout, "DiscountShopConfirmContent.json")