---@class GUIBedWarHallRankTabItemWindow : IGUIWindow
local GUIBedWarHallRankTabItemWindow = class("GUIBedWarHallRankTabItemWindow", IGUIWindow)

---@private
function GUIBedWarHallRankTabItemWindow:ctor(...)
	self.super.ctor(self, "BedWarHallRankTabItem.json", ...)
end

---@private
function GUIBedWarHallRankTabItemWindow:onLoad()
	self.siBtn = self:getChildWindowByName("BedWarHallRankTabItem-Btn", GUIType.StaticImage)
	self.siIcon = self:getChildWindowByName("BedWarHallRankTabItem-Icon", GUIType.StaticImage)
	self.stName = self:getChildWindowByName("BedWarHallRankTabItem-Name", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarHallRankTabItemWindow:initView()

end

---@private
function GUIBedWarHallRankTabItemWindow:initEvent()
	self.siBtn:registerEvent(GUIEvent.Click, function()
		Events.RankTabChangeEvent:invoke(self.key)
	end)

	self:registerEvent(Events.RankTabChangeEvent, function(key)
		local image = self.key == key
				and "set:bed_war_3_rank.json image:btn_9_change_selected"
				or "set:bed_war_3_rank.json image:btn_9_change_normal"
		self.siBtn:SetImage(image)
	end)
end

---@param data RankConfigItem
function GUIBedWarHallRankTabItemWindow:onDataChanged(data)
	self.key = data.Key
	self.type = data.RankType
	self.siIcon:SetImage(data.Icon)
	self.stName:SetText(Lang:getString(data.Title))
end

return GUIBedWarHallRankTabItemWindow
