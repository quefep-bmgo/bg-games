---@class BedWarUserInfo : UserInfo
---@field pageLike number 主页被点赞数
---@field battleLikeCount number 对战被点赞数
---@field totalGameTimes number 游戏总场次
---@field totalRankTimes number 排位总场次
---@field totalFunTimes number 娱乐总场次
---@field runeLevel number 符文等级
---@field dressNum number 个性装饰数量
---@field playDays number 游戏天数
---@field fansNum number 粉丝数量
---@field followNum number 关注他人的数量
---@field currentPet number 当前装备的宠物
---@field valuableDress string 价值最高的三个个性装扮
---@field dailyVisitorCount number 今日访客数
---@field historyVisitorCount string 历史访客数
---@field visitorInfos table 访客信息
---@field followStatus number 关注关系状态: 0.无关系 1.关注 2.粉丝 3.互相关注
---@field friendCount number 好友数量
---@field dressCount number 装扮数量
---@field qualifyingData QualifyingData
---@field maxSegment number 历史最高段位
---@field singleMatch number 单人匹配
---@field creditScore number 信誉分
---@field playerLevel number 等级
---@field loserStreak number 连败次数
---@field currTitle number 称号id
---@field currentPets string 当前装备的宠物
---@alias IUserInfo UserInfo | BedWarUserInfo

---@class UIPersonalHomePageLayout : IGUILayout
local UIPersonalHomePageLayout = class("UIPersonalHomePageLayout", IGUILayout)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

local pageRecord = {
    selfPage = {
        userId = 0,
        page = 1,
        isOpen = false
    },
    otherPlayerPage = {
        userId = 0,
        page = 1,
        isOpen = false
    }
}

function UIPersonalHomePageLayout:ctor(parent)
    self.super.ctor(self, "PersonalHomePage.json", parent)
end

function UIPersonalHomePageLayout:isDelayLoad()
    return true
end

function UIPersonalHomePageLayout:onLoad()
    self.llBg = self:getChildWindow("PersonalHomePage-Bg", GUIType.Layout)
    self.llInfo = self:getChildWindow("PersonalHomePage-Info", GUIType.Layout)
    self.siContentBg = self:getChildWindow("PersonalHomePage-ContentBg", GUIType.StaticImage)
    self.llTabs = self:getChildWindow("PersonalHomePage-Tabs", GUIType.Layout)
    self.cbHome = self:getChildWindow("PersonalHomePage-Home", GUIType.CheckBox)
    self.cbCreditScore = self:getChildWindow("PersonalHomePage-CreditScore", GUIType.CheckBox)
    self.stHome = self:getChildWindow("PersonalHomePage-Home-Text", GUIType.StaticText)
    self.stCreditScore = self:getChildWindow("PersonalHomePage-CreditScore-Text", GUIType.StaticText)

    self:initView()
    self:initEvent()
    self.curUserIds = {}
end

function UIPersonalHomePageLayout:initView()
    ---@type GUIBedWarUIReturnControlWindow
    local llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.bed_war.back.btn.txt", function()
        Events.ClosePersonalHomePageEvent:invoke()
    end)
    self.root:AddChildWindow(llReturn.root)

    self.stHome:SetText(Lang:getString("gui.personal.home"))
    self.stCreditScore:SetText(Lang:getString("gui.personal.creditScore"))

    self.cbHome:SetVisible(false)
    self.cbCreditScore:SetVisible(false)
    self.playerInfo = UIHelper.newGameGUIWindow("GUIPersonalHomePlayerInfo")
    self.siContentBg:AddChildWindow(self.playerInfo.root)
    --self.llTabs:SetVisible(false)
end

function UIPersonalHomePageLayout:onCreate()
    --local siContentBg = self:getChildWindow("PersonalHomePage-ContentBg", GUIType.StaticImage)
    ---@type GUIPersonalHomePlayerInfoWindow
    --self.playerInfo = UIHelper.newGameGUIWindow("GUIPersonalHomePlayerInfo")
    --siContentBg:AddChildWindow(self.playerInfo.root)
end

function UIPersonalHomePageLayout:initEvent()
    self:registerEvent(Events.ClosePersonalHomePageEvent, function()
        self:closePersonalHomePage()
    end)

    self.tapGroup = RadioBoxGroup.new(SoundConfig.switchSetting)

    self.cbHome:SetVisible(true)
    self.tapGroup:addCheckBox(self.cbHome, function(checked)
        if checked then
            self.stHome:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
            --if self.playerInfo == nil then
            --    ---@type GUIPersonalHomePlayerInfoWindow
            --    self.playerInfo = UIHelper.newGameGUIWindow("GUIPersonalHomePlayerInfo")
            --    self.siContentBg:AddChildWindow(self.playerInfo.root)
            --end
            self:onChangePage(1)
            self.playerInfo.root:SetVisible(true)
        else
            self.playerInfo.root:SetVisible(false)
            self.stHome:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
        end
    end)

    self.cbCreditScore:SetVisible(true)
    self.tapGroup:addCheckBox(self.cbCreditScore, function(checked)
        if checked then
            self.stCreditScore:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
            if self.creditScore == nil then
                ---@type GUIPersonalHomeCreditScoreWindow
                self.creditScore = UIHelper.newGameGUIWindow("GUIPersonalHomeCreditScore")
                self.siContentBg:AddChildWindow(self.creditScore.root)
            end
            if pageRecord.otherPlayerPage.userId == 0 then
                self.creditScore:initData(Game:getPlatformUserId())
            else
                self.creditScore:initData(pageRecord.otherPlayerPage.userId)
            end
            self:onChangePage(5)
            self.creditScore.root:SetVisible(true)
        else
            self.creditScore.root:SetVisible(false)
            self.stCreditScore:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
        end
    end)

    --self.tapGroup:addCheckBox(self.cbBattleResults, function(checked)
    --    if checked then
    --        self:onChangePage(2)
    --        self.stBattleResults:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
    --    else
    --        self.stBattleResults:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
    --    end
    --end)
    --
    --self.tapGroup:addCheckBox(self.cbSkin, function(checked)
    --    if checked then
    --        self:onChangePage(3)
    --        self.stSkin:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
    --    else
    --        self.stSkin:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
    --    end
    --end)
    --
    --self.tapGroup:addCheckBox(self.cbPersonality, function(checked)
    --    if checked then
    --        self:onChangePage(4)
    --        self.stPersonality:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
    --    else
    --        self.stPersonality:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
    --    end
    --end)
end

function UIPersonalHomePageLayout:openPersonalHomePageByUserId(userId)
    local info = {
        userId = userId,
        curPage = 1,
        isOpen = true
    }

    if userId == Game:getPlatformUserId() then
        pageRecord.selfPage = info
    else
        pageRecord.otherPlayerPage = info
        WebService:UploadVisitorInfo(Game:getPlatformUserId(), userId)
    end

    self:show()
    self:updatePersonalPageInfo(info)
end

---@param closeAll boolean
function UIPersonalHomePageLayout:closePersonalHomePage(closeAll)
    if not self:isLoad() then
        return
    end
    closeAll = closeAll or false
    if pageRecord.otherPlayerPage and pageRecord.otherPlayerPage.isOpen == true then
        pageRecord.otherPlayerPage = {
            userId = 0,
            page = 1,
            isOpen = false
        }
        if pageRecord.selfPage.isOpen and not closeAll then
            self:updatePersonalPageInfo(pageRecord.selfPage)
        else
            self:hide()
        end
    else
        pageRecord.selfPage.isOpen = false
        self:hide()
    end
end

function UIPersonalHomePageLayout:onChangePage(pageId)
    if pageRecord.otherPlayerPage and pageRecord.otherPlayerPage.isOpen == true then
        pageRecord.otherPlayerPage.page = pageId
    else
        pageRecord.selfPage.page = pageId
    end
end

function UIPersonalHomePageLayout:updatePersonalPageInfo(pageInfo)
    if self.curLoadUserId == pageInfo.userId then
        return
    end
    self.curLoadUserId = pageInfo.userId
    PlayerCustomInfoUtil:getPlayerAllCustomInfo(pageInfo.userId, function()
        self.playerInfo:setShowPlayerUserId(pageInfo.userId)
        self.curLoadUserId = nil
    end)
    self.tapGroup:selectIndex(pageInfo.curPage)
end

function UIPersonalHomePageLayout:onShow()
    if pageRecord.otherPlayerPage.userId == 0 then
        self:openPersonalHomePageByUserId(Game:getPlatformUserId())
    end
end

return UIPersonalHomePageLayout
