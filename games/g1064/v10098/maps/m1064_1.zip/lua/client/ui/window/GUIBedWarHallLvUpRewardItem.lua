---@class GUIBedWarHallLvUpRewardItemWindow : IGUIWindow
local GUIBedWarHallLvUpRewardItemWindow = class("GUIBedWarHallLvUpRewardItemWindow", IGUIWindow)

---@private
function GUIBedWarHallLvUpRewardItemWindow:ctor(...)
	self.super.ctor(self, "BedWarHallLvUpRewardItem.json", ...)
end

---@private
function GUIBedWarHallLvUpRewardItemWindow:onLoad()
	self.siImg = self:getChildWindowByName("BedWarHallLvUpRewardItem", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("BedWarHallLvUpRewardItem-Num", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarHallLvUpRewardItemWindow:initView()
	self.siImg:registerEvent(GUIEvent.Click, function()
		if self.data and self.data.ShowDetailId then
			GUICommonActivityRewardDetail:show(self.data.ShowDetailId)
		end
	end)
end

---@private
function GUIBedWarHallLvUpRewardItemWindow:initEvent()
	self:registerEvent(Events.SetLvUpRewardAlphaEvent, function(alpha)
		self.root:SetAlpha(alpha)
	end)
end

---@param data ExpConfigRewardItem
function GUIBedWarHallLvUpRewardItemWindow:onDataChanged(data)
	self.data = data
	local _reward = RewardConfig.findRewardById(data.RewardId)
	if _reward then
		self.stNum:SetText("x" .. data.Count)
		self.siImg:SetImage(_reward.ShowDetail.image)
	end
end

return GUIBedWarHallLvUpRewardItemWindow
