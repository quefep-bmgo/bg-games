---@class GUIBedWarActionShowItemWindow : IGUIWindow
local GUIBedWarActionShowItemWindow = class("GUIBedWarActionShowItemWindow", IGUIWindow)
---@type ClientActionShowShop
local ActionShowShop = T(Global, "ActionShowShop")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@private
function GUIBedWarActionShowItemWindow:ctor(...)
	self.super.ctor(self, "BedWarActionShowItem.json", ...)
end

---@private
function GUIBedWarActionShowItemWindow:onLoad()
	self.siIcon = self:getChildWindowByName("BedWarActionShowItem-Icon", GUIType.StaticImage)
	self.stName = self:getChildWindowByName("BedWarActionShowItem-Name", GUIType.StaticText)
	self.siSelect = self:getChildWindowByName("BedWarActionShowItem-Select", GUIType.StaticImage)
	self.siLock = self:getChildWindowByName("BedWarActionShowItem-Lock", GUIType.StaticImage)
	self.siUse = self:getChildWindowByName("BedWarActionShowItem-Use", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarActionShowItemWindow:initView()

end

---@private
function GUIBedWarActionShowItemWindow:initEvent()
	self.siIcon:registerEvent(GUIEvent.Click, function()
		Events.ActionShowItemSelectEvent:invoke(self.data.Id)
	end)

	self:registerEvent(Events.ActionShowItemSelectEvent, function(id)
		if not self.cantBeSelect then
			self.siSelect:SetVisible(id == self.data.Id)
		end
	end)

	self:registerEvent(Events.ActionShowChangeEvent, function(userId)
		if userId ~= Game:getPlatformUserId() then
			return
		end
		if self.cantBeSelect or not self.data then
			return
		end
		local reward = CustomShopConfig:getGoodsConfig(self.data.RewardId)
		if reward and reward.Id then
			self.siUse:SetVisible(reward.Id == ActionShowShop.curActionShow)
		else
			self.siUse:SetVisible(ActionShowShop.curActionShow == 0)
		end
	end)

	self:registerEvent(Events.ActionShowItemStatusEvent, function(id)
		if not self.data then
			return
		end
		local reward = CustomShopConfig:getGoodsConfig(self.data.RewardId) or {}
		local isOwn = ActionShowShop:checkActionShowStatus(reward.Id or 0)
		self.siLock:SetVisible(not isOwn)

		if not self.siLock:IsVisible() or self.cantBeSelect or self.data.Default then
			if self.data.Default and not self.cantBeSelect then
				self.siUse:SetVisible(id == 0)
			end
			return
		end
	end)
end

---@param data ActionShowShopItem
function GUIBedWarActionShowItemWindow:onDataChanged(data)
	self.data = data
	if not self.cantBeSelect and GUIBedWarPictureFrameShopLayout then
		self.siSelect:SetVisible(self.data.Id == GUIBedWarPictureFrameShopLayout:getCurSelectId(4))
	end

	if data.Default then
		local detailConfig = RewardItemShowDetailConfig:getConfigById(data.RewardDetail)
		self.siIcon:SetImage(detailConfig.image)
		self.stName:SetText(Lang:getString(detailConfig.name))
		self.siLock:SetVisible(false)
		self.siUse:SetVisible(ActionShowShop.curActionShow == 0)
	else
		local reward = CustomShopConfig:getGoodsConfig(data.RewardId) or {}
		self.siIcon:SetImage(reward.Image)
		self.stName:SetText(Lang:getString(reward.Name))
		local isOwn = ActionShowShop:checkActionShowStatus(reward.Id)
		self.siLock:SetVisible(not isOwn)
		self.siUse:SetVisible(reward.Id == ActionShowShop.curActionShow)
	end
end

return GUIBedWarActionShowItemWindow
