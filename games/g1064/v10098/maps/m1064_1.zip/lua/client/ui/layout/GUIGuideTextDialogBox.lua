---@class UIGuideTextDialogBoxLayout : IGUILayout
local UIGuideTextDialogBoxLayout = class("UIGuideTextDialogBoxLayout", IGUILayout)
local CanClose = true

---@private
function UIGuideTextDialogBoxLayout:ctor(parent)
    self.super.ctor(self, "GuideTextDialogBox.json", parent)
end

---@private
function UIGuideTextDialogBoxLayout:onLoad()
    self.siTextBg = self:getChildWindow("GuideTextDialogBox-Text-Bg", GUIType.StaticImage)
    self.siGuideBg = self:getChildWindow("GuideTextDialogBox-Guide-Bg", GUIType.StaticImage)
    self.stText = self:getChildWindow("GuideTextDialogBox-Text", GUIType.StaticText)
    self.siClickTipImage = self:getChildWindow("GuideTextDialogBox-Click-Tip-Image", GUIType.StaticImage)
    self.stClickTipText = self:getChildWindow("GuideTextDialogBox-Click-Tip-Text", GUIType.StaticText)
    self.siGuideImage = self:getChildWindow("GuideTextDialogBox-Guide-Image", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIGuideTextDialogBoxLayout:initView()
    self.stClickTipText:SetText(Lang:getString("Guide_Dialog_Click_Tip"))
end

---@private
function UIGuideTextDialogBoxLayout:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if CanClose then
            Blockman.Instance():enableBreakCurrentScreenMoveTouch(false)
            self:hide()
        end
    end)
end

function UIGuideTextDialogBoxLayout:onShow(tipStr)
    self.stText:SetText(Lang:getString(tipStr))
    CanClose = false
    Blockman.Instance():enableBreakCurrentScreenMoveTouch(true)
    LuaTimer:scheduleTimer(function()
        CanClose = true
    end, 800, 1)
end

return UIGuideTextDialogBoxLayout
