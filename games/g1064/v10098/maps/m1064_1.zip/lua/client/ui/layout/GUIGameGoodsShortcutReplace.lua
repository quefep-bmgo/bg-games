---@class UIGameGoodsShortcutReplaceLayout : IGUILayout
local UIGameGoodsShortcutReplaceLayout = class("UIGameGoodsShortcutReplaceLayout", IGUILayout)

local GoodsShortcutMode = require("game.model.GoodsShortcutMode")

---@private
function UIGameGoodsShortcutReplaceLayout:ctor(parent)
	self.super.ctor(self, "GameGoodsShortcutReplace.json", parent)
end

---@private
function UIGameGoodsShortcutReplaceLayout:isDelayLoad()
	return true
end

---@private
function UIGameGoodsShortcutReplaceLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGameGoodsShortcutReplaceLayout:initCreateEvent()

end

---@private
function UIGameGoodsShortcutReplaceLayout:onLoad()
	self.siCloseBg = self:getChildWindow("GameGoodsShortcutReplace-Close-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("GameGoodsShortcutReplace-Content", GUIType.Layout)
	self.stTop = self:getChildWindow("GameGoodsShortcutReplace-Top", GUIType.StaticText)
	self.btnClose = self:getChildWindow("GameGoodsShortcutReplace-Close", GUIType.Button)
	self.itemUIData = {}
	for i = 1, 2 do
		local data = {
			siSlot = self:getChildWindow("GameGoodsShortcutReplace-Slot-"..i, GUIType.StaticImage),
			siSlotIcon = self:getChildWindow("GameGoodsShortcutReplace-Slot-Icon-"..i, GUIType.StaticImage),
			stSlotName = self:getChildWindow("GameGoodsShortcutReplace-Slot-Name-"..i, GUIType.StaticText),
			btnSlotEquip = self:getChildWindow("GameGoodsShortcutReplace-Slot-Equip-"..i, GUIType.Button),
			stCount = self:getChildWindow("GameGoodsShortcutReplace-Slot-Count-"..i, GUIType.StaticText)
		}
		data.btnSlotEquip:SetText(Lang:getString("gui_pet_equip_change_btn"))
		data.btnSlotEquip:registerEvent(GUIEvent.ButtonClick, function()
			GoodsShortcutMode:replaceShortcutGoods(i, self.goodsId)
			self:hide()
		end)
		self.itemUIData[i] = data
	end

	self:initView()
	self:initEvent()
end

---@private
function UIGameGoodsShortcutReplaceLayout:initView()
	self.stTop:SetText(Lang:getString("gui_goods_shortcut_equip_change_title"))
end

---@private
function UIGameGoodsShortcutReplaceLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

function UIGameGoodsShortcutReplaceLayout:onShow(goodsId)
	self.goodsId = goodsId
	self:setGoodsData()
end

function UIGameGoodsShortcutReplaceLayout:setGoodsData()
	for i, goodsId in ipairs(GoodsShortcutMode:getShortcutList()) do
		local uiData = self.itemUIData[i]
		local goods = StoreConfig:getGoodsById(goodsId)
		if not goods then
			return
		end
		LogUtil.pv(goods)
		if #goods.showDetail.image > 10 then
			uiData.siSlotIcon:SetImage(goods.showDetail.image)
		else
			if goods.ItemId > 0 then
				GuiItemStack.showItemIcon(uiData.siSlotIcon, goods.ItemId, 0, "")
			else
				uiData.siSlotIcon:SetImage("")
			end
		end
		uiData.stSlotName:SetText(Lang:getString(goods.showDetail.name))
		uiData.stCount:SetText("X"..goods.Count)
	end
end

return UIGameGoodsShortcutReplaceLayout
