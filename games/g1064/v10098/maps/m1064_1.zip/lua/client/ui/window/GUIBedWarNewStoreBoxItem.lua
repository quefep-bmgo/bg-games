---@class GUIBedWarNewStoreBoxItem : IGUIWindow
local GUIBedWarNewStoreBoxItem = class("GUIBedWarNewStoreBoxItem", IGUIWindow)

---@private
function GUIBedWarNewStoreBoxItem:onLoad()
    self.siBg = self:getChildWindowByName("BedWarNewStoreBoxItem-Bg", GUIType.StaticImage)
    self.siContent = self:getChildWindowByName("BedWarNewStoreBoxItem-Content", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarNewStoreBoxItem:initView()

end

---@private
function GUIBedWarNewStoreBoxItem:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        GUINewStore:UpdateBoxDesc(self.lotteryBox)
    end)
end

function GUIBedWarNewStoreBoxItem:onDataChanged(box)
    ---@type RewardData
    self.lotteryBox = RewardConfig.findRewardById(box.RewardId)
    self.siContent:SetImage(self.lotteryBox.ShowDetail.image)
end

return GUIBedWarNewStoreBoxItem
