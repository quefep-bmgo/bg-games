---@class GUIBedWarQualifyingWaitMatchWindow : IGUIWindow
local GUIBedWarQualifyingWaitMatchWindow = class("GUIBedWarQualifyingWaitMatchWindow", IGUIWindow)

---@private
---@param oppWindows GUIWindow[] 显示互斥的控件组
function GUIBedWarQualifyingWaitMatchWindow:ctor(oppWindows)
    self.oppWindows = oppWindows or {}
    self.super.ctor(self, "BedWarQualifyingWaitMatch.json")
end

---@private
function GUIBedWarQualifyingWaitMatchWindow:onLoad()
    self.stTip = self:getChildWindowByName("BedWarQualifyingWaitMatch-Tip", GUIType.StaticText)
    self.siCancel = self:getChildWindowByName("BedWarQualifyingWaitMatch-Cancel", GUIType.StaticImage)
    self.stTime = self:getChildWindowByName("BedWarQualifyingWaitMatch-Time", GUIType.StaticText)
    self.siHome = self:getChildWindowByName("BedWarQualifyingWaitMatch-Home", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingWaitMatchWindow:initView()
    self.stTip:SetText(Lang:getString("gui.qualifying.wait.match.tip"))
    self:stop()
end

---@private
function GUIBedWarQualifyingWaitMatchWindow:initEvent()
    self.siCancel:registerEvent(GUIEvent.Click, function()
        self:stop()
        if self.cancelListener then
            self.cancelListener()
        end
    end)
    self.siHome:registerEvent(GUIEvent.Click, function()
        GUIHallCreateTeamLayout:hide()
    end)
    self:registerEvent(Events.QualifyingMatchStatusUpdateEvent, function(isMatching)
        if isMatching then
            self:start()
        else
            self:stop()
        end
    end)
end

---@private
function GUIBedWarQualifyingWaitMatchWindow:onSecondTick()
    self.stTime:SetText(DateUtil.getFormatTime(self.waitTime, "mm:ss"))
    self.waitTime = self.waitTime + 1
    Events.QualifyingMatchWaitTimeEvent:invoke(self.waitTime)
end

function GUIBedWarQualifyingWaitMatchWindow:start()
    if self.waitKey then
        return
    end
    self.waitTime = 0
    Events.QualifyingMatchWaitTimeEvent:invoke(self.waitTime)
    self:onSecondTick()
    self:stop()
    self.waitKey = LuaTimer:scheduleTimer(function()
        self:onSecondTick()
    end, 1000)
    self.root:SetVisible(true)
    for _, window in pairs(self.oppWindows) do
        window:SetVisible(false)
    end
end

function GUIBedWarQualifyingWaitMatchWindow:stop()
    LuaTimer:cancel(self.waitKey)
    self.waitKey = nil
    Events.QualifyingMatchWaitTimeEvent:invoke(0)
    self.root:SetVisible(false)
    for _, window in pairs(self.oppWindows) do
        window:SetVisible(true)
        window:SetWholeEnabled(true)
    end
end

function GUIBedWarQualifyingWaitMatchWindow:setCancelListener(listener)
    self.cancelListener = listener
end

return GUIBedWarQualifyingWaitMatchWindow
