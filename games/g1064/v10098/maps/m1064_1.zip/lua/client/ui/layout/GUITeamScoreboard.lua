---@class UITeamScoreboardLayout : IGUILayout
local UITeamScoreboardLayout = class("UITeamScoreboardLayout", IGUILayout)

local TabColor = {
	Normal = { 0.486275, 0.537255, 0.603922, 1 },
	Select = { 0.866667, 0.992157, 1, 1 }
}

---@private
function UITeamScoreboardLayout:ctor(parent)
	self.super.ctor(self, "TeamScoreboard.json", parent)
end

---@private
function UITeamScoreboardLayout:isDelayLoad()
	return true
end

---@private
function UITeamScoreboardLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UITeamScoreboardLayout:initCreateEvent()

end

---@private
function UITeamScoreboardLayout:onLoad()
	self.siBg = self:getChildWindow("TeamScoreboard-Bg", GUIType.StaticImage)
	self.llContentRoot = self:getChildWindow("TeamScoreboard-ContentRoot", GUIType.Layout)
	self.siTitleBg = self:getChildWindow("TeamScoreboard-Title-Bg", GUIType.StaticImage)
	self.stTitleText = self:getChildWindow("TeamScoreboard-Title-Text", GUIType.StaticText)
	self.llTabs = self:getChildWindow("TeamScoreboard-Tabs", GUIType.Layout)
	self.siMyTeamIcon = self:getChildWindow("TeamScoreboard-My-Team-Icon", GUIType.StaticImage)
	self.cbTeamTab1 = self:getChildWindow("TeamScoreboard-Team-Tab1", GUIType.CheckBox)
	self.siTabIcon1 = self:getChildWindow("TeamScoreboard-Tab-Icon1", GUIType.StaticImage)
	self.cbTeamTab2 = self:getChildWindow("TeamScoreboard-Team-Tab2", GUIType.CheckBox)
	self.siTabIcon2 = self:getChildWindow("TeamScoreboard-Tab-Icon2", GUIType.StaticImage)
	self.cbTeamTab3 = self:getChildWindow("TeamScoreboard-Team-Tab3", GUIType.CheckBox)
	self.siTabIcon3 = self:getChildWindow("TeamScoreboard-Tab-Icon3", GUIType.StaticImage)
	self.btnCloseBtn = self:getChildWindow("TeamScoreboard-CloseBtn", GUIType.Button)
	self.llTeamInfo = self:getChildWindow("TeamScoreboard-Team-Info", GUIType.Layout)
	self:initView()
	self:initEvent()

	self.battleInfo = {}
	self.tabs = {}
end

---@private
function UITeamScoreboardLayout:initView()
	self.stTitleText:SetText(Lang:getString("gui.scoreboard.title"))
end

---@private
function UITeamScoreboardLayout:initEvent()
	self.btnCloseBtn:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

function UITeamScoreboardLayout:onShow()
	self:onUpdateUI()
end

function UITeamScoreboardLayout:onUpdateUI()
	local llTeamInfo = self:getChildWindow("TeamScoreboard-Team-Info")
	llTeamInfo:CleanupChildren()
	self.battleInfo = {}
	self.tabs = {}

	---@type GUIResultTeamItem
	self.leftTeamInfo = UIHelper.newGameGUIWindow("GUITeamScoreboardItem", "TeamScoreboardItem.json")
	local contentWidth = llTeamInfo:GetPixelSize().x
	local contentHeight = llTeamInfo:GetPixelSize().y
	local teamInfoWidth = (contentWidth - 20) / 2
	self.leftTeamInfo.root:SetWidth({ 0, teamInfoWidth })
	self.leftTeamInfo.root:SetHeight({ 0, contentHeight })
	self.leftTeamInfo.root:SetXPosition({ 0, 10 })
	self.leftTeamInfo:initItemPlayers()
	llTeamInfo:AddChildWindow(self.leftTeamInfo.root)

	---@type GUIResultTeamItem
	self.rightTeamInfo = UIHelper.newGameGUIWindow("GUITeamScoreboardItem", "TeamScoreboardItem.json")
	self.rightTeamInfo.root:SetWidth({ 0, teamInfoWidth })
	self.rightTeamInfo.root:SetHeight({ 0, contentHeight })
	self.rightTeamInfo.root:SetXPosition({ 0, -10 })
	self.rightTeamInfo.root:SetHorizontalAlignment(HorizontalAlignment.Right)
	self.rightTeamInfo:initItemPlayers()
	self.rightTeamInfo:setRightLayout()
	llTeamInfo:AddChildWindow(self.rightTeamInfo.root)
	local teamIds = {}
	local infoList = GameInfoManager:getAllPlayerInfo()
	local selfTeamId = "0"
	for userId, info in pairs(infoList) do
		local teamId = info:getValue("teamId")
		if tonumber(teamId) >= 1 and tonumber(teamId) <= 4 then
			if teamIds[teamId] == nil then
				teamIds[teamId] = tonumber(teamId)
			end
			local battleInfo = self.battleInfo[teamId]
			if not battleInfo then
				battleInfo = { teamId = tonumber(teamId), players = {} }
				self.battleInfo[teamId] = battleInfo
			end
			local data = {
				userId = tonumber(userId),
				info = info
			}
			if tostring(userId) == tostring(Game:getPlatformUserId()) then
				selfTeamId = teamId
			end
			table.insert(battleInfo.players, data)
			GameInfoManager:registerObserver(tostring(userId), function(_)
				self.leftTeamInfo.adapter:notifyItemDataChange(data)
				self.rightTeamInfo.adapter:notifyItemDataChange(data)
			end)
		end
	end

	local battleInfo = self.battleInfo[selfTeamId]
	if battleInfo then
		local me
		for pos, player in pairs(battleInfo.players) do
			if tostring(player.userId) == tostring(Game:getPlatformUserId()) then
				me = player
				table.remove(battleInfo.players, pos)
				break
			end
		end
		table.insert(battleInfo.players, 1, me)
		self.leftTeamInfo:setTeamInfo(battleInfo)
		local ivMyTeamIcon = self:getChildWindow("TeamScoreboard-My-Team-Icon", GUIType.StaticImage)
		ivMyTeamIcon:SetImage(TeamGUIInfo.getTeamGUI(selfTeamId).tab_icon)
	end
	teamIds[selfTeamId] = nil
	local ids = {}
	for _, teamId in pairs(teamIds) do
		table.insert(ids, teamId)
	end
	if #ids ~= 0 then
		if not self.rightTeamInfo:setTeamInfo(self.battleInfo[tostring(ids[1])]) then
			for teamId, _battleInfo in pairs(self.battleInfo) do
				for _, player in pairs(_battleInfo.players) do
					player.info:print()
				end
			end
		end
	end
	for i = 1, 3 do
		local teamId = ids[i]
		local cbTab = self:getChildWindow("TeamScoreboard-Team-Tab" .. tostring(i), GUIType.CheckBox)
		if teamId ~= nil then
			cbTab:SetVisible(true)
			cbTab:removeEvent(GUIEvent.CheckStateChanged)
			cbTab:registerEvent(GUIEvent.CheckStateChanged, function()
				local checked = cbTab:GetChecked()
				if checked then
					cbTab:SetTextColor(TabColor.Select)
					for _, tab in pairs(self.tabs) do
						if tab.teamId == teamId then
							tab.icon:SetImage(TeamGUIInfo.getTeamGUI(tab.teamId).tab_icon)
						else
							tab.icon:SetImage(TeamGUIInfo.getTeamGUI(tab.teamId).tab_icon_normal)
							tab.checkbox:SetChecked(false)
						end
					end
					self.rightTeamInfo:setTeamInfo(self.battleInfo[tostring(teamId)])
				else
					cbTab:SetTextColor(TabColor.Normal)
				end
			end)
			local ivTabIcon = self:getChildWindow("TeamScoreboard-Tab-Icon" .. tostring(i), GUIType.StaticImage)
			ivTabIcon:SetImage(TeamGUIInfo.getTeamGUI(teamId).tab_icon)
			self.tabs[tostring(teamId)] = { checkbox = cbTab, icon = ivTabIcon, teamId = teamId }
		else
			cbTab:SetVisible(false)
		end
	end
	local teamId = ids[1]
	for _, tab in pairs(self.tabs) do
		tab.checkbox:SetChecked(false)
		if tab.teamId == teamId then
			tab.checkbox:SetChecked(true)
		end
	end
end

return UITeamScoreboardLayout
