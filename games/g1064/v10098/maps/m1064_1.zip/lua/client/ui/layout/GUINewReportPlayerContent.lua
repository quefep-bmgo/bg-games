---@class UINewReportPlayerContentLayout : IGUILayout
local UINewReportPlayerContentLayout = class("UINewReportPlayerContentLayout", IGUILayout)

---@type table<number, boolean>
local ReportRecord = {}

---@private
function UINewReportPlayerContentLayout:isDelayLoad()
	return true
end

---@private
function UINewReportPlayerContentLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UINewReportPlayerContentLayout:initCreateEvent()

end

---@private
function UINewReportPlayerContentLayout:onLoad()
	self.llTargetBg = self:getChildWindow("NewReportPlayerContent-Target-Bg", GUIType.Layout)
	self.stHint = self:getChildWindow("NewReportPlayerContent-Hint", GUIType.StaticText)
	self.siTeam = self:getChildWindow("NewReportPlayerContent-Team", GUIType.StaticImage)
	self.siLine = self:getChildWindow("NewReportPlayerContent-Line", GUIType.StaticImage)
	self.llHeader = self:getChildWindow("NewReportPlayerContent-Header", GUIType.Layout)
	self.stName = self:getChildWindow("NewReportPlayerContent-Name", GUIType.StaticText)
	self.stReportTitle = self:getChildWindow("NewReportPlayerContent-Report-Title", GUIType.StaticText)
	self.stReportContent = self:getChildWindow("NewReportPlayerContent-Report-Content", GUIType.StaticText)
	self.stReportTips = self:getChildWindow("NewReportPlayerContent-Report-Tips", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UINewReportPlayerContentLayout:initView()
	self.stReportTitle:SetText(Lang:getString("gui.report.content")..":") --举报内容
	self.stReportContent:SetText(Lang:getString("gui.report.msg"))	--该玩家在游戏中开挂作弊
	self.stHint:SetText(Lang:getString("gui.report.id"))
	self.stReportTips:SetText(Lang:getString("gui.report.tips")) --核实后将会处罚作弊玩家
	---@type GUIBedWarHead
	self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
	self.llHeader:AddChildWindow(self.winHead.root)
end

---@private
function UINewReportPlayerContentLayout:initEvent()

end

function UINewReportPlayerContentLayout:onShow()
	if self.targetUserId then
		self:setPlayerData()
	end
end

function UINewReportPlayerContentLayout:canReport(userId)
	return ReportRecord[userId] == nil
end

function UINewReportPlayerContentLayout:setReportPlayer(userId)
	self.targetUserId = userId
end

function UINewReportPlayerContentLayout:setPlayerData()
	local playerInfo = GameInfoManager:getPlayerInfo(self.targetUserId)
	if not playerInfo or not playerInfo.infoKey then
		return
	end
	self.curUserId = tonumber(playerInfo.infoKey)
	local cache = UserInfoCache:GetCache(self.curUserId)
	if cache then
		self.winHead:setUserInfo(cache)
		self.stName:SetText(cache.nickName)
	else
		self.winHead:setUserInfo({
			picUrl = playerInfo:getValue("picUrl"),
			userId = self.curUserId,
		})
		self.stName:SetText(playerInfo:getValue("userName"))
	end
	local config = TeamGUIInfo.getTeamGUI(playerInfo:getValue("teamId") or "1")
	if config then
		self.siTeam:SetImage(config.tab_icon)
	else
		self.siTeam:SetImage("set:bed_war_battle_info.json image:tab_red")
	end
end

function UINewReportPlayerContentLayout:doReport()
	if not self:canReport(self.curUserId) then
		UIHelper.showToast(Lang:getString("gui.report.player.already"))
		return
	end
	PlayerManager:getClientPlayer():sendPacket({
		pid = "ReportPlayer",
		userId = self.curUserId,
		reportIds = {5}, --开挂作弊
	})
	ReportRecord[self.curUserId] = true
end

---@type UINewReportPlayerContentLayout
NewReportPlayerContentLayout = buildCustomDialogContent(UIHelper.getGameGUILayoutProxyClass("GUINewReportPlayerContent"), "NewReportPlayerContent.json")
--NewReportPlayerContentLayout = buildCustomDialogContent(UINewReportPlayerContentLayout, "NewReportPlayerContent.json")

return UINewReportPlayerContentLayout
