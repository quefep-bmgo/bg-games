---@class UIBedWarQualifyingQuarterSwitchLayout : IGUILayout
local UIBedWarQualifyingQuarterSwitchLayout = class("UIBedWarQualifyingQuarterSwitchLayout", IGUILayout)

---@private
function UIBedWarQualifyingQuarterSwitchLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingQuarterSwitch.json", parent)
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:initCreateEvent()
    ---@param oldQualifyingData QualifyingData
    ---@param newQualifyingData QualifyingData
    self:registerEvent(Events.QualifyingSwitchQuarterEvent, function(oldQualifyingData, newQualifyingData)
        self.oldQualifyingData = oldQualifyingData
        self.newQualifyingData = newQualifyingData
        self:show()
    end)
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:onLoad()
    self.siBg = self:getChildWindow("BedWarQualifyingQuarterSwitch-Title-Bg", GUIType.StaticImage)
    self.stTitle = self:getChildWindow("BedWarQualifyingQuarterSwitch-Title", GUIType.StaticText)
    self.llSegment = self:getChildWindow("BedWarQualifyingQuarterSwitch-Segment", GUIType.Layout)
    self.stContinue = self:getChildWindow("BedWarQualifyingQuarterSwitch-Continue", GUIType.StaticText)
    self.siLight = self:getChildWindow("BedWarQualifyingQuarterSwitch-Light", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:initView()
    if self.wSegment then
        return
    end
    ---@type GUIBedWarQualifyingSegmentWindow
    self.wSegment = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegment", self.llSegment, 300)
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if not self.canContinue then
            return
        end
        if self.isShowNewQualifying then
            self:hide()
        else
            self.isShowNewQualifying = true
            self.canContinue = false
            self.stTitle:SetText(Lang:format("gui.qualifying.new.quarter", self.newQualifyingData.quarter))
            self.wSegment:showQualifyingAnim(self.newQualifyingData, false, function()
                self.canContinue = true
            end)
        end
    end)
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:onHide()
    self.wSegment:cancelAllTimer()
end

---@private
function UIBedWarQualifyingQuarterSwitchLayout:onShow()
    self.canContinue = false
    self.isShowNewQualifying = false
    self.stTitle:SetText(Lang:format("gui.qualifying.quarter.switch", self.oldQualifyingData.quarter))
    self.stContinue:SetText(Lang:getString("gui.qualifying.continue"))
    WebService:GetQualifyingSegmentConfig(function(_)
        self.siLight:PlayEffect1("")
        self.siLight:SetEffectName("g1008_effect_ui_ranklight.effect")
        local curSize = 0.4
        local offset = 0.1
        LuaTimer:scheduleTicker(function()
            curSize = curSize + offset
            if curSize >= 1.2 then
                offset = -offset
            end
            self.siBg:SetWidth({ 0, 550 * curSize })
            self.siBg:SetHeight({ 0, 70 * curSize })
            self.stTitle:SetText(Lang:format("gui.qualifying.quarter.switch", self.oldQualifyingData.quarter))
        end, 1, 10)
        self.wSegment:showQualifyingAnim(self.oldQualifyingData, true, function()
            self.canContinue = true
        end)
    end)
end

return UIBedWarQualifyingQuarterSwitchLayout
