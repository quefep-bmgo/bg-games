---@class UISurvivalSettlementLayout : IGUILayout
local UISurvivalSettlementLayout = class("UISurvivalSettlementLayout", IGUILayout)
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function UISurvivalSettlementLayout:ctor(parent)
    self.super.ctor(self, "SurvivalSettlement.json", parent)
end

---@private
function UISurvivalSettlementLayout:isDelayLoad()
    return true
end

---@private
function UISurvivalSettlementLayout:onLoad()
    self.siCenter = self:getChildWindow("SurvivalSettlement-Center", GUIType.StaticImage)
    self.siTeamRank = self:getChildWindow("SurvivalSettlement-TeamRank", GUIType.StaticImage)
    self.llTeamRankNum = self:getChildWindow("SurvivalSettlement-TeamRankNum", GUIType.Layout)
    self.stTeamRankText = self:getChildWindow("SurvivalSettlement-TeamRankText", GUIType.StaticText)
    self.llRewards = self:getChildWindow("SurvivalSettlement-Rewards", GUIType.Layout)
    self.stExpName = self:getChildWindow("SurvivalSettlement-ExpName", GUIType.StaticText)
    self.stExpValue = self:getChildWindow("SurvivalSettlement-ExpValue", GUIType.StaticText)
    self.llHeader = self:getChildWindow("SurvivalSettlement-Header", GUIType.Layout)
    self.pbExpPro = self:getChildWindow("SurvivalSettlement-ExpPro", GUIType.ProgressBar)
    self.stLevel = self:getChildWindow("SurvivalSettlement-Level", GUIType.StaticText)
    self.stExpText = self:getChildWindow("SurvivalSettlement-ExpText", GUIType.StaticText)
    self.stKeyName = self:getChildWindow("SurvivalSettlement-KeyName", GUIType.StaticText)
    self.stKeyValue = self:getChildWindow("SurvivalSettlement-KeyValue", GUIType.StaticText)
    self.stGoldName = self:getChildWindow("SurvivalSettlement-GoldName", GUIType.StaticText)
    self.stGoldValue = self:getChildWindow("SurvivalSettlement-GoldValue", GUIType.StaticText)
    self.stTips = self:getChildWindow("SurvivalSettlement-Tips", GUIType.StaticText)
    self.siTitleBg = self:getChildWindow("SurvivalSettlement-TitleBg", GUIType.StaticImage)
    self.stTitle1 = self:getChildWindow("SurvivalSettlement-Title1", GUIType.StaticText)
    self.stTitle2 = self:getChildWindow("SurvivalSettlement-Title2", GUIType.StaticText)
    self.llBottom = self:getChildWindow("SurvivalSettlement-Bottom", GUIType.Layout)
    self.btnQuit = self:getChildWindow("SurvivalSettlement-Quit", GUIType.Button)
    self.btnBack = self:getChildWindow("SurvivalSettlement-Back", GUIType.Button)
    self.btnAgain = self:getChildWindow("SurvivalSettlement-Again", GUIType.Button)
    self.btnWatch = self:getChildWindow("SurvivalSettlement-Watch", GUIType.Button)
    self.btnBack:SetVisible(false)
    self:initView()
    self:initEvent()
end

---@private
function UISurvivalSettlementLayout:initView()
    self.stTeamRankText:SetText(Lang:getString("gui.team.rank"))
    self.stExpName:SetText(Lang:getString("gui.settlement.exp"))
    self.stKeyName:SetText(Lang:getString("shop_key"))
    self.stGoldName:SetText(Lang:getString("gui.settlement.gold"))
    self.stTips:SetText(Lang:getString("gui.teammate.battle.tip"))
    self.btnQuit:SetText(Lang:getString("gui_bed_war_quit_game"))
    self.btnBack:SetText(Lang:getString("gui.backHall"))
    self.btnAgain:SetText(Lang:getString("gui.playAgain"))
    self.btnWatch:SetText(Lang:getString("gui.watch"))
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
    self.winHead:setCanOpenPersonalHome(false)
    self.winHead:setUserInfo(UserInfoCache:GetCache(Game:getPlatformUserId()) or {})
end

---@private
function UISurvivalSettlementLayout:initEvent()
    self.btnQuit:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        GUIBedWarSetting:onClickExit()
    end)
    self.btnBack:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        CommonPacketSender:sendBackHall()
    end)
    self.btnAgain:registerEvent(GUIEvent.ButtonClick, function()
        Game:playAgain()
        self.btnAgain:SetEnabled(false)
    end)
    self.btnWatch:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        self:hide()
    end)
end

function UISurvivalSettlementLayout:isAlwaysShow()
    return isGameEnd
end

function UISurvivalSettlementLayout:showDeathSettlement(data)
    self:show()
    isWatch = true
    self.stLevel:SetText("Lv." .. data.level)
    if data.isExpMax then
        self.stExpText:SetText("MAX")
        self.pbExpPro:SetProgress(1)
    else
        self.stExpText:SetText(data.curExp .. "/" .. data.maxExp)
        self.pbExpPro:SetProgress(data.curExp / data.maxExp)
    end
    self.stExpValue:SetText("+" .. data.addExp)
    self.stKeyValue:SetText("+" .. data.yaoshi)
    self.stGoldValue:SetText("+" .. data.gold)
    self.stTitle1:SetText(Lang:getString("gui.failed"))
    self.stTitle2:SetText(Lang:getString("gui.failed"))
    self.siTeamRank:SetVisible(false)
    self.stTips:SetVisible(true)
    self.llRewards:SetXPosition({ 0, 0 })
    self.llRewards:SetYPosition({ 0, -15 })
end

function UISurvivalSettlementLayout:showGameSettlement()
    self:show()
    isGameEnd = true
    self.btnWatch:SetVisible(false)
    self.llBottom:SetWidth({ 0, 451 })
    self.btnBack:SetXPosition({ 0, 248 })
    self.btnAgain:SetXPosition({ 0, 248 })
    self.siTeamRank:SetVisible(true)
    self.stTips:SetVisible(false)
    self.llRewards:SetXPosition({ 0, 150 })
    self.llRewards:SetYPosition({ 0, 0 })
    self.stTitle1:SetText(Lang:getString("gui.victory"))
    self.stTitle2:SetText(Lang:getString("gui.victory"))
    local playerInfo = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
    if not playerInfo then
        return
    end
    local teamInfo = GameInfoManager:getTeamInfo(playerInfo:getValue("teamId"))
    if not teamInfo then
        return
    end
    playerInfo:getValue("teamId")
    local rank = teamInfo:getValue("rank", true)
    UIUtils.setNumberToLayout(rank, self.llTeamRankNum)
    if rank == 1 then
        self.stTitle1:SetText(Lang:getString("gui.victory"))
        self.stTitle2:SetText(Lang:getString("gui.victory"))
        self.siTitleBg:SetDrawColor({ 1, 145 / 255, 34 / 255, 1 })
        self.stTitle1:SetProperty("TextColorLeftTop", Color.tostring({ 188 / 255, 88 / 255, 41 / 255, 1 }))
        self.stTitle1:SetProperty("TextColorRightTop", Color.tostring({ 188 / 255, 88 / 255, 41 / 255, 1 }))
        self.stTitle1:SetProperty("TextColorLeftBottom", Color.tostring({ 188 / 255, 88 / 255, 41 / 255, 1 }))
        self.stTitle1:SetProperty("TextColorRightBottom", Color.tostring({ 188 / 255, 88 / 255, 41 / 255, 1 }))
        self.stTitle2:SetProperty("TextColorLeftTop", Color.tostring({ 1, 228 / 255, 67 / 255, 1 }))
        self.stTitle2:SetProperty("TextColorRightTop", Color.tostring({ 1, 228 / 255, 67 / 255, 1 }))
    else
        self.stTitle1:SetText(Lang:getString("gui.failed"))
        self.stTitle2:SetText(Lang:getString("gui.failed"))
    end
end

return UISurvivalSettlementLayout
