---@class BedWarHeadImageItemAdapter : IDataAdapter
local BedWarHeadImageItemAdapter = class("BedWarHeadImageItemAdapter", IDataAdapter)

function BedWarHeadImageItemAdapter:setItemSize(width, height)
    self.width = width
    self.height = height
end

function BedWarHeadImageItemAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIBedWarHeadImageItem")
end

function BedWarHeadImageItemAdapter:getJsonName()
    return "BedWarHeadImageShopItem.json"
end

function BedWarHeadImageItemAdapter:getItemWidth()
    return { 0, self.width }
end

function BedWarHeadImageItemAdapter:getItemHeight()
    return { 0, self.height }
end

return BedWarHeadImageItemAdapter