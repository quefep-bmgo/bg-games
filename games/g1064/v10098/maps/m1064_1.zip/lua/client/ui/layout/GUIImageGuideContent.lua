---@class UIImageGuideContentLayout : IGUILayout
local UIImageGuideContentLayout = class("UIImageGuideContentLayout", IGUILayout)

---@class GuideImageSetting
---@field leftImage string
---@field leftTip string
---@field RightImage string
---@field RightTip string

---@type GuideImageSetting[]
local GuideImageSetting = {
    {
        leftImage = "set:bed_war_3_guide.json image:img_0_guide_pic1",
        leftTip = "guide_image_tip_1",
        RightImage = "set:bed_war_3_guide.json image:img_0_guide_pic2",
        RightTip = "guide_image_tip_2",
    }
}

local GuideIndex = 1

---@private
function UIImageGuideContentLayout:ctor(name, parent)
    self.super.ctor(self, "ImageGuideContent.json", parent)
end

---@private
function UIImageGuideContentLayout:onLoad()
    self.siLeftImage = self:getChildWindow("ImageGuideContent-Left-Image", GUIType.StaticImage)
    self.stLeftTip = self:getChildWindow("ImageGuideContent-Left-Tip", GUIType.StaticText)
    self.siRightImage = self:getChildWindow("ImageGuideContent-Right-Image", GUIType.StaticImage)
    self.stRightTip = self:getChildWindow("ImageGuideContent-Right-Tip", GUIType.StaticText)
    self.siCenter = self:getChildWindow("ImageGuideContent-Center", GUIType.StaticImage)
    self.btnLastButton = self:getChildWindow("ImageGuideContent-Last-Button", GUIType.Button)
    self.btnRightButton = self:getChildWindow("ImageGuideContent-Right-Button", GUIType.Button)
    self.stPage = self:getChildWindow("ImageGuideContent-Page", GUIType.StaticText)
    self.siCenterTipBg = self:getChildWindow("ImageGuideContent-Center-Tip-Bg", GUIType.StaticImage)
    self.stCenterTipText = self:getChildWindow("ImageGuideContent-Center-Tip-Text", GUIType.StaticText)

    self.siCenterTipBg:SetVisible(false)
    self:initView()
    self:initEvent()
end

---@private
function UIImageGuideContentLayout:initView()
    self:setData(GuideIndex)
    self.btnLastButton:SetText(Lang:getString("gui_guide_image_last"))
    self.btnRightButton:SetText(Lang:getString("gui_guide_image_next"))
end

---@private
function UIImageGuideContentLayout:initEvent()
    self.btnLastButton:registerEvent(GUIEvent.ButtonClick, function()
        if GuideIndex > 1 then
            GuideIndex = GuideIndex - 1
            self:setData(GuideIndex)
        else
            self:showTip("guide_image_tip_First")
        end
    end)
    self.btnRightButton:registerEvent(GUIEvent.ButtonClick, function()
        if GuideIndex < #GuideImageSetting then
            GuideIndex = GuideIndex + 1
            self:setData(GuideIndex)
        else
            self:showTip("guide_image_tip_Last")
        end
    end)
end

---@private
function UIImageGuideContentLayout:setData(index)
    self.siLeftImage:SetImage(GuideImageSetting[index].leftImage)
    self.stLeftTip:SetText(Lang:getString(GuideImageSetting[index].leftTip))
    self.siRightImage:SetImage(GuideImageSetting[index].RightImage)
    self.stRightTip:SetText(Lang:getString(GuideImageSetting[index].RightTip))
    self.stPage:SetText(tostring(index) .. "/" .. tostring(#GuideImageSetting))
end

---@private
function UIImageGuideContentLayout:showTip(tip)
    self.siCenterTipBg:SetVisible(true)
    self.stCenterTipText:SetText(Lang:getString(tip))
    LuaTimer:cancel(self.centerKey)
    self.centerKey = LuaTimer:scheduleTimer(function()
        self.siCenterTipBg:SetVisible(false)
    end, 3000, 1)
end

---@type UIImageGuideContentLayout
GuideImageContent = buildPopUpWindowsContent(UIImageGuideContentLayout, "ImageGuideContent.json")

return UIImageGuideContentLayout
