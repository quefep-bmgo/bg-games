---@class UICustomInputContentLayout : IGUILayout
local UICustomInputContentLayout = class("UICustomInputContentLayout", IGUILayout)

---@private
function UICustomInputContentLayout:onLoad()
    self.stTip = self:getChildWindow("CustomInputContent-Tip", GUIType.StaticText)
    self.etContentText = self:getChildWindow("CustomInputContent-Content-Text", GUIType.Edit)
    self:initView()
    self:initEvent()
end

---@private
function UICustomInputContentLayout:initView()
    self.stTip:SetText("")
    self.etContentText:SetTextVertAlign(VerticalAlignment.Top)
end

---@private
function UICustomInputContentLayout:initEvent()
    self.etContentText:registerEvent(GUIEvent.EditTextInput, function()
        if self.contentChangeListener then
            local text = self.etContentText:GetText()
            text = FilterWord.getReplaceContent(text)
            self.contentChangeListener(text)
        end
    end)
end

function UICustomInputContentLayout:setTipText(tip)
    self.stTip:SetText(tip)
end

function UICustomInputContentLayout:setDefaultContentText(content)
    self.etContentText:SetText(content)
end

function UICustomInputContentLayout:onHide()
    self.contentChangeListener = nil
    self.etContentText:SetText("")
end

function UICustomInputContentLayout:setContentChangeListener(contentChangeListener)
    self.contentChangeListener = contentChangeListener
end

---@type UICustomInputContentLayout
GUICustomInputContentLayout = buildCustomDialogContent(UICustomInputContentLayout, "CustomInputContent.json")
