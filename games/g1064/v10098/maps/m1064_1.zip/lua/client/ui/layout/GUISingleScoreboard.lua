---@class UISingleScoreboardLayout : IGUILayout
local UISingleScoreboardLayout = class("UISingleScoreboardLayout", IGUILayout)

---@private
function UISingleScoreboardLayout:ctor(parent)
	self.super.ctor(self, "SingleScoreboard.json", parent)
end

---@private
function UISingleScoreboardLayout:isDelayLoad()
	return true
end

---@private
function UISingleScoreboardLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UISingleScoreboardLayout:initCreateEvent()

end

---@private
function UISingleScoreboardLayout:onLoad()
	self.llContentRoot = self:getChildWindow("SingleScoreboard-ContentRoot", GUIType.Layout)
	self.llTitleBg = self:getChildWindow("SingleScoreboard-Title-Bg", GUIType.Layout)
	self.stTitleText = self:getChildWindow("SingleScoreboard-Title-Text", GUIType.StaticText)
	self.btnCloseBtn = self:getChildWindow("SingleScoreboard-CloseBtn", GUIType.Button)
	self.llPlayers = self:getChildWindow("SingleScoreboard-Players", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function UISingleScoreboardLayout:initView()
	self.stTitleText:SetText(Lang:getString("gui.scoreboard.title"))

	self.gvPlayers = IGUIGridView.new("SingleScoreboard-Players-list", self.llPlayers)
	self.gvPlayers:setConfig(0, 6, 1)
end

---@private
function UISingleScoreboardLayout:initEvent()
	self.btnCloseBtn:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

function UISingleScoreboardLayout:onShow()
	self:onUpdateUI()
end

function UISingleScoreboardLayout:onUpdateUI()
	self.gvPlayers:clearItems()
	local players = {}
	local infoList = GameInfoManager:getAllPlayerInfo()
	for userId, info in pairs(infoList) do
		local data = {
			info = info,
			rank = tonumber(info:getValue("rank")) or 100,
			userId = tonumber(userId)
		}
		table.insert(players, data)
		GameInfoManager:registerObserver(tostring(userId), function(_)
			local item = self.gvPlayers:getItem("curInfo", info)
			if item then
				item:onDataChanged(data)
			end
		end)
	end
	table.sort(players, function(a, b)
		if a.rank ~= b.rank then
			return a.rank < b.rank
		end
		return a.userId < b.userId
	end)
	for rank, player in pairs(players) do
		player.rank = rank
		local item = UIHelper.newGameGUIWindow("GUISingleScoreboardPlayerItem", "SingleScoreboardPlayerItem.json")
		item:onDataChanged(player)
		item:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 0, 56 })
		self.gvPlayers:addItem(item)
	end
end

return UISingleScoreboardLayout
