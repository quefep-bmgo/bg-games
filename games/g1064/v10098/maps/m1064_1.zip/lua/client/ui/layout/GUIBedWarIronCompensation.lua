---@class GUIBedWarIronCompensationLayout : IGUILayout
local GUIBedWarIronCompensationLayout = class("GUIBedWarIronCompensationLayout", IGUILayout)

local page = {
	introduce = 1,
	convert = 2,
	iron = 3
}

---@private
function GUIBedWarIronCompensationLayout:ctor(parent)
	self.super.ctor(self, "BedWarIronCompensation.json", parent)
end

---@private
function GUIBedWarIronCompensationLayout:isDelayLoad()
	return true
end

---@private
function GUIBedWarIronCompensationLayout:onCreate()
	self:initCreateEvent()
end

---@private
function GUIBedWarIronCompensationLayout:initCreateEvent()

end

---@private
function GUIBedWarIronCompensationLayout:onLoad()
	self.llBg = self:getChildWindow("BedWarIronCompensation-Bg", GUIType.Layout)
	self.llPanel = self:getChildWindow("BedWarIronCompensation-Panel", GUIType.Layout)
	self.llTitle = self:getChildWindow("BedWarIronCompensation-Title", GUIType.Layout)
	self.stTitleText = self:getChildWindow("BedWarIronCompensation-Title-Text", GUIType.StaticText)
	self.btnClose = self:getChildWindow("BedWarIronCompensation-Close", GUIType.Button)
	self.siLine = self:getChildWindow("BedWarIronCompensation-Line", GUIType.StaticImage)
	self.llContent = self:getChildWindow("BedWarIronCompensation-Content", GUIType.Layout)
	self.llMajorUpdate = self:getChildWindow("BedWarIronCompensation-MajorUpdate", GUIType.Layout)
	self.stMajorUpdateTip = self:getChildWindow("BedWarIronCompensation-MajorUpdateTip", GUIType.StaticText)
	self.siNpcIcon1 = self:getChildWindow("BedWarIronCompensation-NpcIcon1", GUIType.StaticImage)
	self.siNpcIcon2 = self:getChildWindow("BedWarIronCompensation-NpcIcon2", GUIType.StaticImage)
	self.btnNextPage = self:getChildWindow("BedWarIronCompensation-NextPage", GUIType.Button)
	self.llConvert = self:getChildWindow("BedWarIronCompensation-Convert", GUIType.Layout)
	self.siTextBg1 = self:getChildWindow("BedWarIronCompensation-TextBg1", GUIType.StaticImage)
	self.stText1 = self:getChildWindow("BedWarIronCompensation-Text1", GUIType.StaticText)
	self.siTextBg2 = self:getChildWindow("BedWarIronCompensation-TextBg2", GUIType.StaticImage)
	self.stText2 = self:getChildWindow("BedWarIronCompensation-Text2", GUIType.StaticText)
	self.stText3 = self:getChildWindow("BedWarIronCompensation-Text3", GUIType.StaticText)
	self.stText4 = self:getChildWindow("BedWarIronCompensation-Text4", GUIType.StaticText)
	self.stText5 = self:getChildWindow("BedWarIronCompensation-Text5", GUIType.StaticText)
	self.stText6 = self:getChildWindow("BedWarIronCompensation-Text6", GUIType.StaticText)
	self.stIronTipText = self:getChildWindow("BedWarIronCompensation-Iron-Tip-Text", GUIType.StaticText)
	self.btnFinish = self:getChildWindow("BedWarIronCompensation-Finish", GUIType.Button)
	self.llIron = self:getChildWindow("BedWarIronCompensation-Iron", GUIType.Layout)
	self.btnSure = self:getChildWindow("BedWarIronCompensation-Sure", GUIType.Button)

	self.stMajorUpdateTip:SetText(Lang:getString("gui_dialog_tip_major_update_dec"))
	self.btnNextPage:SetText(Lang:getString("gui.next"))
	self.btnFinish:SetText(Lang:getString("gui.sure"))
	self.btnSure:SetText(Lang:getString("gui.sure"))
	self.stIronTipText:SetText(Lang:getString("gui_iron_change_tip_text"))
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarIronCompensationLayout:initView(type)
	self.llConvert:SetVisible(false)
	self.llMajorUpdate:SetVisible(false)
	self.llIron:SetVisible(false)
	if type == page.introduce then
		self.llPanel:SetHeight({0, 488})
		self.stTitleText:SetText(Lang:getString("gui_dialog_tip_major_update"))
		self.llMajorUpdate:SetVisible(true)
	elseif type == page.convert then
		self.llPanel:SetHeight({0, 448})
		self.needShowDetails = false
		self.stTitleText:SetText(Lang:getString("gui_dialog_tip_title_tip"))

		local runeCounts = {}
		local totalEssence = 0
		if self.data then
			runeCounts = self.data.runeCounts
			totalEssence = self.data.totalEssence
		end
		self.stText1:SetText(runeCounts[1] or 0)
		self.stText2:SetText(runeCounts[2] or 0)
		self.stText3:SetText(runeCounts[3] or 0)
		self.stText4:SetText(totalEssence)
		self.llConvert:SetVisible(true)
		self.btnFinish:SetText(self.data.iron and Lang:getString("gui.next") or Lang:getString("gui.sure"))
	elseif type == page.iron then
		if not self.data or not self.data.iron then
			return
		end
		self.stTitleText:SetText(Lang:getString("gui_iron_change_tip_title"))
		self.stText5:SetText(self.data.iron)
		self.stText6:SetText(math.ceil(self.data.iron / 8))
		self.llIron:SetVisible(true)
	end
end

---@private
function GUIBedWarIronCompensationLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		if self.needShowDetails then
			self:initView(page.convert)
		else
			self:hide()
		end
	end)

	self.btnNextPage:registerEvent(GUIEvent.ButtonClick, function()
		self:initView(page.convert)
	end)

	self.btnFinish:registerEvent(GUIEvent.ButtonClick, function()
		if self.data and self.data.iron then
			self:initView(page.iron)
		else
			self:hide()
		end
	end)

	self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

function GUIBedWarIronCompensationLayout:onShow(data)
	self.data = data
	self.needShowDetails = data.totalEssence and data.totalEssence > 0
	self:initView(data.page or page.convert)
end

return GUIBedWarIronCompensationLayout

