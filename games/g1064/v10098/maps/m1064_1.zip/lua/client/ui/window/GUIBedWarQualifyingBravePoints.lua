---@class GUIBedWarQualifyingBravePointsWindow : IGUIWindow
local GUIBedWarQualifyingBravePointsWindow = class("GUIBedWarQualifyingBravePointsWindow", IGUIWindow)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")

---@private
function GUIBedWarQualifyingBravePointsWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingBravePoints.json", ...)
end

---@private
function GUIBedWarQualifyingBravePointsWindow:onLoad()
    self.siIntegralBg = self:getChildWindowByName("BedWarQualifyingBravePoints-Integral-Bg", GUIType.StaticImage)
    self.stWinningStreak = self:getChildWindowByName("BedWarQualifyingBravePoints-Winning-Streak", GUIType.StaticText)
    self.stText = self:getChildWindowByName("BedWarQualifyingBravePoints-Text", GUIType.StaticText)
    self.siQuestion = self:getChildWindowByName("BedWarQualifyingBravePoints-Question", GUIType.StaticImage)
    self.btnQuestionClick = self:getChildWindowByName("BedWarQualifyingBravePoints-Question-Click", GUIType.Button)
    self.stHint2 = self:getChildWindowByName("BedWarQualifyingBravePoints-Hint2", GUIType.StaticText)
    self.siIntegralProgressBg = self:getChildWindowByName("BedWarQualifyingBravePoints-Integral-Progress-Bg", GUIType.StaticImage)
    self.siIntegralProgress = self:getChildWindowByName("BedWarQualifyingBravePoints-Integral-Progress", GUIType.StaticImage)
    self.stIntegral = self:getChildWindowByName("BedWarQualifyingBravePoints-Integral", GUIType.StaticText)
    self.stHint1 = self:getChildWindowByName("BedWarQualifyingBravePoints-Hint1", GUIType.StaticText)
    self.siTag = self:getChildWindowByName("BedWarQualifyingBravePoints-Tag", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingBravePointsWindow:initView()
    self.stHint2:SetText("")
    self.stWinningStreak:SetText("")
    self.stText:SetText(Lang:getString("gui.brave.points"))
    self.stText:SetWidth({ 0, self.stText:GetTextWidth() })
    self.stHint1:SetText(Lang:getString("gui.brave.points.hint1"))
end

---@private
function GUIBedWarQualifyingBravePointsWindow:initEvent()
    self.btnQuestionClick:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui.brave.points.rule.title")
                    .setContentText(Lang:getString("gui.brave.points.rule.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .setContentAlign(HorizontalAlignment.Left)
                    .show()
    end)
end

---@param data QualifyingData
function GUIBedWarQualifyingBravePointsWindow:onDataChanged(data)
    local info = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
    if info then
        self.stWinningStreak:SetText(Lang:format("gui.win.streak.format", math.max(CQualifyingController:getWinnerStreak() - 1, 0)))
        self.stIntegral:SetText(CQualifyingController:getBravePoint())
        local qualifyingData = CQualifyingController:getQualifyingData()
        local setting = QualifyingTool.getSubStarBravePointSetting(qualifyingData.segment, qualifyingData.grade)
        self.stHint2:SetText(Lang:format("gui.brave.points.hint2", setting[1]))
        local index = math.max(1, math.min(4, math.floor(setting[2] / setting[1]) - 1))
        self.siTag:SetImage("set:bed_war_2_qualifying.json image:img_0_grade_" .. index)
        self.siIntegralProgressBg:SetImage("set:bed_war_2_qualifying.json image:pbar_0_progress_" .. index)
        self.siIntegralProgress:SetImage("set:bed_war_2_qualifying.json image:pbar_0_progress_top_" .. index)
        local maxPoints = setting[2] * 1.15
        local points = CQualifyingController:getBravePoint() + setting[2] * 0.075
        local progress = math.min(math.max(1, maxPoints - points), maxPoints - 1)
        self.siIntegralProgress:SetCircleMask(progress, maxPoints, true)
    end
end

function GUIBedWarQualifyingBravePointsWindow:setInGameSettlement()
    self.root:SetWidth({ 0, 212 })
    self.root:SetHeight({ 0, 80 })
    self.root:SetProperty("LayoutBackImage", "set:bed_war_2_qualifying.json image:img_0_integral_floor")
    self.stHint1:SetProperty("Font", "HT8")
    self.stIntegral:SetProperty("Font", "HT18")
    self.stWinningStreak:SetProperty("Font", "HT10")
    self.stText:SetProperty("Font", "HT12")
    self.stHint2:SetProperty("Font", "HT8")
    self.siQuestion:SetVisible(false)
    self.btnQuestionClick:SetVisible(false)
end

function GUIBedWarQualifyingBravePointsWindow:setInQualifying()
    self.root:SetXPosition({ 0, 150 })
    self.stWinningStreak:SetXPosition({ 1.18, 10 })
    self.stText:SetXPosition({ 1.18, 10 })
    self.stHint2:SetXPosition({ 1.18, 10 })
end

return GUIBedWarQualifyingBravePointsWindow
