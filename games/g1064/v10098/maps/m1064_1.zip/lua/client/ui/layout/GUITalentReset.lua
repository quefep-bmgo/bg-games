---@class UITalentResetLayout : IGUILayout
local UITalentResetLayout = class("UITalentResetLayout", IGUILayout)

---@type CTalentController
local CTalentController = T(Global, "CTalentController")

---@private
function UITalentResetLayout:isDelayLoad()
	return true
end

---@private
function UITalentResetLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UITalentResetLayout:initCreateEvent()

end

---@private
function UITalentResetLayout:onLoad()
	self.stTips = self:getChildWindow("TalentReset-Tips", GUIType.StaticText)
	self.stCurrencyPrice = self:getChildWindow("TalentReset-CurrencyPrice", GUIType.StaticText)
	self.siCurrencyIcon = self:getChildWindow("TalentReset-CurrencyIcon", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function UITalentResetLayout:initView()
	self.stTips:SetText(Lang:getString("gui.talent.reset.tips"))
	self.siCurrencyIcon:SetImage(PayHelper.getMoneyIcon(Define.Money.DIAMOND))
	self.stCurrencyPrice:SetText(Define.TalentResetPrice)
end

function UITalentResetLayout:onShow()
	self.firstReset = CTalentController:isFirstResetTalent()
	self.siCurrencyIcon:SetVisible(not self.firstReset)
	self.stCurrencyPrice:SetVisible(not self.firstReset)
end

---@private
function UITalentResetLayout:initEvent()

end

---@type UITalentResetLayout
GUITalentResetLayout = buildCustomDialogContent(UITalentResetLayout, "TalentReset.json")
