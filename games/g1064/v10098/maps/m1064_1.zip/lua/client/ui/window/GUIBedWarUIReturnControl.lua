---@class GUIBedWarUIReturnControlWindow : IGUIWindow
local GUIBedWarUIReturnControlWindow = class("GUIBedWarUIReturnControlWindow", IGUIWindow)

---@private
function GUIBedWarUIReturnControlWindow:ctor(...)
    self.super.ctor(self, "BedWarUIReturnControl.json", ...)
end

---@private
function GUIBedWarUIReturnControlWindow:onLoad(text, callback)
    self.siBg = self:getChildWindowByName("BedWarUIReturnControl-Bg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("BedWarUIReturnControl-Icon", GUIType.StaticImage)
    self.stText = self:getChildWindowByName("BedWarUIReturnControl-Text", GUIType.StaticText)
    self.btnBtn = self:getChildWindowByName("BedWarUIReturnControl-Btn", GUIType.Button)
    self:initView(text)
    self:initEvent(callback)
end

---@private
function GUIBedWarUIReturnControlWindow:initView(text)
    self:setTitle(text)
end

---@private
function GUIBedWarUIReturnControlWindow:initEvent(callback)
    self.btnBtn:registerEvent(GUIEvent.ButtonClick, function()
        callback()
    end)
end

function GUIBedWarUIReturnControlWindow:setTitle(title)
    self.stText:SetText(Lang:getString(title))
    self:setWidth({ 0, self.stText:GetTextWidth() + 130 })
end

function GUIBedWarUIReturnControlWindow:setUI(uiSetting)
    if uiSetting.bgIcon then
        self.siBg:SetImage(uiSetting.bgIcon)
    end
    if uiSetting.textXPos then
        self.stText:SetXPosition(uiSetting.textXPos)
    end
    if uiSetting.textYPos then
        self.stText:SetYPosition(uiSetting.textYPos)
    end
end

return GUIBedWarUIReturnControlWindow
