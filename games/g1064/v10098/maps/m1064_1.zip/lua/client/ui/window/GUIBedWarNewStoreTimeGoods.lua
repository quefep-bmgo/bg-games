---@class GUIBedWarNewStoreTimeGoodsWindow : IGUIWindow
local GUIBedWarNewStoreTimeGoodsWindow = class("GUIBedWarNewStoreTimeGoodsWindow", IGUIWindow)
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIBedWarNewStoreTimeGoodsWindow:onLoad()
    self.siBg = self:getChildWindowByName("BedWarNewStoreTimeGoods", GUIType.Layout)
    self.stName = self:getChildWindowByName("BedWarNewStoreTimeGoods-Name", GUIType.StaticText)
    self.itemInfo = {
        [1] = {
            quality = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item1Quality", GUIType.StaticImage),
            icon = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item1Icon", GUIType.StaticImage),
            num = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item1Num", GUIType.StaticText)
        },
        [2] = {
            quality = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item2Quality", GUIType.StaticImage),
            icon = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item2Icon", GUIType.StaticImage),
            num = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item2Num", GUIType.StaticText)
        },
        [3] = {
            quality = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item3Quality", GUIType.StaticImage),
            icon = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item3Icon", GUIType.StaticImage),
            num = self:getChildWindowByName("BedWarNewStoreTimeGoods-Item3Num", GUIType.StaticText)
        }
    }
    self.llBuy = self:getChildWindowByName("BedWarNewStoreTimeGoods-Buy", GUIType.Button)
    self.llSelect = self:getChildWindowByName("BedWarNewStoreTimeGoods-Select", GUIType.Button)
    self.siMoneyIcon = self:getChildWindowByName("BedWarNewStoreTimeGoods-PriceIcon", GUIType.StaticImage)
    self.stMoneyText = self:getChildWindowByName("BedWarNewStoreTimeGoods-PriceCount", GUIType.StaticText)
    self.stMoneyOriginText = self:getChildWindowByName("BedWarNewStoreTimeGoods-OriginPriceCount", GUIType.StaticText)
    self.stName = self:getChildWindowByName("BedWarNewStoreTimeGoods-Name", GUIType.StaticText)
    self.stLimitCount = self:getChildWindowByName("BedWarNewStoreTimeGoods-LimitCount", GUIType.StaticText)
    self.stSoldOut = self:getChildWindowByName("BedWarNewStoreTimeGoods-SoldOut", GUIType.StaticText)
    self.siRedDot = self:getChildWindowByName("BedWarNewStoreTimeGoods-RedDot", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarNewStoreTimeGoodsWindow:initView()
    self.goodsInfo = {}
    self.stSoldOut:SetText(Lang:getString("bed_war_new_store_free_goods_sell_out"))
end

---@private
function GUIBedWarNewStoreTimeGoodsWindow:initEvent()
    self.llBuy:registerEvent(GUIEvent.ButtonClick, function()
        local currency = StoreConfig:getCurrencyConfig(self.goodsInfo.CurrencyId)
        CustomDialog.builder()
                    .setTitleText("gui.store.purchase.title")
                    .setContentText(Lang:getString("gui.store.purchase.tip"))
                    .setRightIcon(PayHelper.getMoneyIcon(currency.RealId))
                    .setRightText(tostring(self.goodsInfo.DiscountPrice))
                    .setRightClickListener(function()
            LuaTimer:schedule(function()
                UIUtils.updateRedDotCount(Define.RedDotKey.Store .. "_TimeFreeGoodsId" .. self.goodsInfo.Id, 0)
                PayHelper.checkMoney(currency.RealId, self.goodsInfo.DiscountPrice, function(success, tips)
                    if success then
                        PacketSender:sendLuaCommonData("BuyTimeGoods", self.goodsInfo.Id)
                    end
                end)
            end, 50)
        end).show()
    end)

    for i = 1, 3 do
        local item = self.itemInfo[i]
        item.icon:registerEvent(GUIEvent.Click, function()
            self:updateDetail(i)
        end)
        item.num:SetTextHorzAlign(HorizontalAlignment.Right)
    end
    self.llSelect:registerEvent(GUIEvent.ButtonClick, function()
        self:updateDetail(1)
    end)
end

function GUIBedWarNewStoreTimeGoodsWindow:updateDetail(i)
    local items = StringUtil.split(self.goodsInfo.ItemId, "#")
    local counts = StringUtil.split(self.goodsInfo.Count, "#")
    if not items[i] then
        return
    end
    local reward = RewardConfig.findRewardById(items[i])
    self.goodsInfo.showDetail = reward.ShowDetail
    local groupCfg = StoreTimeGroupConfig:getGroupCfg(self.goodsInfo.GroupId)
    local detailInfo = {
        LimitCount = self.goodsInfo.canBuyCount,
        config = TableUtil.copyTable(self.goodsInfo),
        RefreshTime = StoreTimeGroupConfig:getTabEndTime(groupCfg.key),
    }
    detailInfo.config.Count = counts[i]
    detailInfo.config.CountText = "#"
    GUINewStore:showGoodsDetail(detailInfo)
end

---@param goodsInfo GoodsInfo
function GUIBedWarNewStoreTimeGoodsWindow:onDataChanged(goodsInfo)
    self.siRedDot:SetVisible(false)
    self.goodsInfo = goodsInfo
    if goodsInfo == nil then
        print("GUIBedWarNewStoreTimeGoodsWindow:onDataChanged  goodsInfo is empty!")
        return
    end

    self.stName:SetText(Lang:getString(goodsInfo.Name))
    --如果玩家已经购买，隐藏购买按钮，北京变灰
    if goodsInfo.canBuyCount > 0 then
        self.llBuy:SetVisible(true)
        self.stSoldOut:SetVisible(false)
        self.siBg:SetBackImage("set:store_time_goods.json image:img_0_gift_pack01")
        if goodsInfo.DiscountPrice <= 0 then
            self.siRedDot:SetVisible(true)
        end
    else
        self.llBuy:SetVisible(false)
        self.stSoldOut:SetVisible(true)
        self.siBg:SetBackImage("set:store_time_goods.json image:img_0_gift_pack02")
    end
    self.stLimitCount:SetText(goodsInfo.canBuyCount .. " / " .. goodsInfo.LimitCount)

    local items = StringUtil.split(goodsInfo.ItemId, "#")
    local counts = StringUtil.split(goodsInfo.Count, "#")
    local qualities = StringUtil.split(goodsInfo.Quality, "#")
    for i = 1, 3 do
        local item = self.itemInfo[i]
        if items[i] then
            item.quality:SetVisible(true)
            local reward = RewardConfig.findRewardById(items[i])
            item.icon:SetImage(reward.ShowDetail.image)
            item.quality:SetImage("set:store_time_goods.json image:img_0_quality0" .. qualities[i])
            if tonumber(counts[i]) > 1 then
                item.num:SetVisible(true)
                item.num:SetText(counts[i])
            else
                item.num:SetVisible(false)
            end
        else
            item.quality:SetVisible(false)
        end
    end

    --- 花费
    local config = StoreConfig:getCurrencyConfig(self.goodsInfo.CurrencyId)
    if config then
        if config.ItemId > 0 then
            GuiItemStack.showItemIcon(self.siMoneyIcon, config.ItemId, 0, "")
        elseif config.RealId > 0 then
            self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(config.RealId))
        else
            self.siMoneyIcon:SetImage("")
        end
    else
        self.siMoneyIcon:SetImage("")
    end
    self.stMoneyOriginText:SetText(self.goodsInfo.Price)
    self.stMoneyText:SetText(self.goodsInfo.DiscountPrice)
end

return GUIBedWarNewStoreTimeGoodsWindow
