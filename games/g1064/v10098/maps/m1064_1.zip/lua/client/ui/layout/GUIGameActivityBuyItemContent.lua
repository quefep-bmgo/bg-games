---@class UIGameActivityBuyItemContentLayout : IGUILayout
local UIGameActivityBuyItemContentLayout = class("UIGameActivityBuyItemContentLayout", IGUILayout)

---@private
function UIGameActivityBuyItemContentLayout:onLoad()
	self.siBg = self:getChildWindow("GameActivityBuyItemContent", GUIType.StaticImage)
	self.siIcon = self:getChildWindow("GameActivityBuyItemContent-Icon", GUIType.StaticImage)
	self.stNum = self:getChildWindow("GameActivityBuyItemContent-Num", GUIType.StaticText)
end

GameActivityBuyItemContentLayout = buildCustomDialogContent(UIGameActivityBuyItemContentLayout, "GameActivityBuyItemContent.json")

function GameActivityBuyItemContentLayout:setView(data)
	self.siBg:SetImage(data.bg or "")
	self.siIcon:SetImage(data.image)
	self.stNum:SetVisible(false)
	if data.num and data.num > 1 then
		self.stNum:SetText(data.num)
		self.stNum:SetVisible(true)
	end
	self.siBg:SetHeight({0, 120 * (data.scale or 1)})
	self.siBg:SetWidth({0, 120 * (data.scale or 1)})
end

return UIGameActivityBuyItemContentLayout
