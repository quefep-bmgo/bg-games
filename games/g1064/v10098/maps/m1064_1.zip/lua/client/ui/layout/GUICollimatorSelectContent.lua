---@class UICollimatorSelectContentLayout : IGUILayout
local UICollimatorSelectContentLayout = class("UICollimatorSelectContentLayout", IGUILayout)

---@private
function UICollimatorSelectContentLayout:ctor()
    self.super.ctor(self, "CollimatorSelectContent.json")
end

---@private
function UICollimatorSelectContentLayout:onLoad()
    self:initView()
    self:initEvent()
end

---@private
function UICollimatorSelectContentLayout:initView()
    self.clickBox = self:getChildWindow("CollimatorSelectContent-ClickScene-Box", GUIType.CheckBox)
    ---@type GUICheckBox
    self.collimatorBox = self:getChildWindow("CollimatorSelectContent-Collimator-Box", GUIType.CheckBox)


    self.clickLayout = self:getChildWindow("CollimatorSelectContent-ClickScene-Show", GUIType.StaticImage)
    self.collimatorLayout = self:getChildWindow("CollimatorSelectContent-Collimator-Show", GUIType.StaticImage)

    self:getChildWindow("CollimatorSelectContent-Title-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.collimator.title-choose"))
    self:getChildWindow("CollimatorSelectContent-ClickScene-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.collimator.clickScene"))
    self:getChildWindow("CollimatorSelectContent-Collimator-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.collimator.collimator"))
    self:getChildWindow("CollimatorSelectContent-Tip", GUIType.StaticText):SetText(Lang:getString("gui.setting.collimator.tip"))

    self.closeBtn = self:getChildWindow("CollimatorSelectContent-Close", GUIType.Button)
    self.sureBtn = self:getChildWindow("CollimatorSelectContent-Sure", GUIType.Button)
    self.sureBtn:SetText(Lang:getString("gui.sure"))
    self.selectGroup = RadioBoxGroup.new(522)

end

---@private
function UICollimatorSelectContentLayout:initEvent()
    self.selectGroup:addCheckBox(self.clickBox, function(checked)
        --Blockman.Instance().m_gameSettings:setCollimatorMode(false)
    end)

    self.selectGroup:addCheckBox(self.collimatorBox, function(checked)
        --Blockman.Instance().m_gameSettings:setCollimatorMode(true)
    end)

    self.sureBtn:registerEvent(GUIEvent.ButtonClick, function()
        local mode = false
        if self.collimatorBox:GetChecked() then
            mode = true
        end
        Blockman.Instance().m_gameSettings:setCollimatorMode(mode)
        local player = PlayerManager:getClientPlayer()
        player:sendPacket({
            pid = "UpdateCollimatorMode",
            mode = mode,
        })

        self:hide()
    end)

    self.closeBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)

    self.clickLayout:registerEvent(GUIEvent.Click, function()
        self.clickBox:SetChecked(true)
    end)

    self.collimatorLayout:registerEvent(GUIEvent.Click, function()
        self.collimatorBox:SetChecked(true)
    end)
end

function UICollimatorSelectContentLayout:onShow()
    if Blockman.Instance().m_gameSettings:isCollimatorMode() then
        self.collimatorBox:SetChecked(true)
    else
        self.clickBox:SetChecked(true)
    end
end

return UICollimatorSelectContentLayout
