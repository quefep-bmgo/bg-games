---@class GUIBedWarRuneProItemWindow : IGUIWindow
local GUIBedWarRuneProItemWindow = class("GUIBedWarRuneProItemWindow", IGUIWindow)

---@private
function GUIBedWarRuneProItemWindow:ctor(...)
    self.super.ctor(self, "BedWarRuneProItem.json", ...)
    ---@type RuneConfigItem
    self.config = {}
    self.type = 0
end

---@private
function GUIBedWarRuneProItemWindow:onLoad()
    self.stRuneDes = self:getChildWindowByName("BedWarRuneProItem-RuneDes", GUIType.StaticText)
    self.stRunePro = self:getChildWindowByName("BedWarRuneProItem-RunePro", GUIType.StaticText)
end

---@param config RuneConfigItem
function GUIBedWarRuneProItemWindow:onDataChanged(config)
    if self.type == 0 then
        self.config = config
        self.type = config.SubType
        self.stRuneDes:SetText(Lang:getString(self.config.DesWithoutPro))
    else
        self.config.Pro = self.config.Pro + config.Pro
        self.config.StackMaxPro = self.config.StackMaxPro + config.StackMaxPro
    end
    local showPro = self.config.MaxPro == 0 and self.config.Pro or self.config.MaxPro
    showPro = self.config.StackMaxPro == 0 and showPro or self.config.StackMaxPro
    self.stRunePro:SetText(Lang:format(self.config.DesPro, showPro))
    return self.config.Pro
end

return GUIBedWarRuneProItemWindow
