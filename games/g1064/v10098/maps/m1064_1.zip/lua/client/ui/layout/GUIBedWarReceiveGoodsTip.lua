---@class UIBedWarReceiveGoodsTipLayout : IGUILayout
local UIBedWarReceiveGoodsTipLayout = class("UIBedWarReceiveGoodsTipLayout", IGUILayout)

---@private
function UIBedWarReceiveGoodsTipLayout:ctor(parent)
	self.super.ctor(self, "BedWarReceiveGoodsTip.json", parent)
end

---@private
function UIBedWarReceiveGoodsTipLayout:isDelayLoad()
	return true
end

---@private
function UIBedWarReceiveGoodsTipLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIBedWarReceiveGoodsTipLayout:initCreateEvent()

end

---@private
function UIBedWarReceiveGoodsTipLayout:onLoad()
	self.siBg = self:getChildWindow("BedWarReceiveGoodsTip-Bg", GUIType.StaticImage)
	self.siIcon = self:getChildWindow("BedWarReceiveGoodsTip-Icon", GUIType.StaticImage)
	self.stText = self:getChildWindow("BedWarReceiveGoodsTip-Text", GUIType.StaticText)
	self.stSellFailText = self:getChildWindow("BedWarReceiveGoodsTip-SellFailText", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIBedWarReceiveGoodsTipLayout:initView()
	self.stText:SetText(Lang:getString(""))
	self.stSellFailText:SetText(Lang:getString(""))
	self.stSellFailText:SetVisible(false)
end

---@private
function UIBedWarReceiveGoodsTipLayout:initEvent()

end

function UIBedWarReceiveGoodsTipLayout:onShow(data)
	if self.timer then
		LuaTimer:cancel(self.timer)
	end

	local image = data.image
	local num = tonumber(data.num)
	self.siIcon:SetImage(image)
	self.stText:SetText(num > 0 and tostring(num) or "")
	self:setYPosition({0, 0})
	local yPos = 0
	local alpha = 1
	local count = 0
	self.root:SetAlpha(alpha)
	self.timer = LuaTimer:scheduleTimer(function()
		count = count + 1
		if count > 100 then
			yPos = yPos - 1
			alpha = alpha - 0.01
			self:setYPosition({0, yPos})
			self.root:SetAlpha(alpha)
			if yPos <= -250 then
				self:hide()
			end
		end
	end, 5)
end

function UIBedWarReceiveGoodsTipLayout:onHide()
	if self.timer then
		LuaTimer:cancel(self.timer)
		self.timer = nil
	end
end

return UIBedWarReceiveGoodsTipLayout
