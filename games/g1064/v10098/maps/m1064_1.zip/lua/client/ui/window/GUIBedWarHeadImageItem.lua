---@class GUIBedWarHeadImageItem : IGUIWindow
local GUIBedWarHeadImageItem = class("GUIBedWarHeadImageItem", IGUIWindow)
---@type HeadImageConfig
local HeadImageConfig = T(Global, "HeadImageConfig")
---@type ClientHeadImageShop
local HeadImageShop = T(Global, "HeadImageShop")

local DefaultIcon = "default_headshot.png"

function GUIBedWarHeadImageItem:ctor(...)
    self.super.ctor(self, "BedWarHeadImageShopItem.json", ...)
end

function GUIBedWarHeadImageItem:onLoad()
    self.siHead = self:getChildWindowByName("BedWarHeadImageShopItem-Head", GUIType.StaticImage)
    self.llTouch = self:getChildWindowByName("BedWarHeadImageShopItem-Touch", GUIType.Layout)
    --self.siFrame = self:getChildWindowByName("BedWarHeadImageShopItem-Frame", GUIType.StaticImage)
    self.siMask = self:getChildWindowByName("BedWarHeadImageShopItem-Mask", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("BedWarHeadImageShopItem-Image", GUIType.UrlImage)
    self.siSelect = self:getChildWindowByName("BedWarHeadImageShopItem-Select", GUIType.StaticImage)
    --self.siFrameEffect = self:getChildWindowByName("BedWarHeadImageShopItem-Frame-Effect", GUIType.StaticImage)
    self.siLock = self:getChildWindowByName("BedWarHeadImageShopItem-Lock", GUIType.StaticImage)
    self.siUse = self:getChildWindowByName("BedWarHeadImageShopItem-Use", GUIType.StaticImage)

    self.siImage:setChildMaterial(0)
    --self.siImage:setDefaultImage(DefaultIcon)
    self.siMask:SetVisible(true)
    self.siLock:SetVisible(true)
    self.siUse:SetVisible(false)
    self.llTouch:SetTouchable(true)
    self.siSelect:SetVisible(false)

    self:initEvent()
end

function GUIBedWarHeadImageItem:initEvent()
    self.llTouch:registerEvent(GUIEvent.Click, function()
        Events.HeadImageItemSelectEvent:invoke(self.id)
    end)

    self:registerEvent(Events.HeadImageItemSelectEvent, function(id)
        ---选中
        if not self.cantBeSelect then
            self.siSelect:SetVisible(self.id == id)
        end
    end)

    self:registerEvent(Events.HeadImageChangeEvent, function(userId)
        if userId ~= Game:getPlatformUserId() then
            return
        end
        if self.cantBeSelect or not self.data then
            return
        end
        local reward = RewardConfig.findRewardById(self.data.RewardId)
        if reward and reward.RewardId then
            self.siUse:SetVisible(reward.RewardId == HeadImageShop.curHeadImage)
        else
            self.siUse:SetVisible(HeadImageShop.curHeadImage == 0)
        end
    end)

    self:registerEvent(Events.HeadImageItemStatusEvent, function(id)
        if not self.data then
            return
        end
        local reward = RewardConfig.findRewardById(self.data.RewardId)
        local isOwn = HeadImageShop:checkHeadImageStatus(reward.RewardId)
        self.siLock:SetVisible(not isOwn)
        self.siMask:SetVisible(not isOwn)

        if not self.siLock:IsVisible() or self.cantBeSelect or self.data.Default then
            if self.data.Default and not self.cantBeSelect then
                self.siUse:SetVisible(id == 0)
            end
            return
        end
    end)
end

-----@param data HeadFrameConfigItem
function GUIBedWarHeadImageItem:onDataChanged(data)
    self.siImage:setUrl("")
    self.siImage:setDefaultImage("")
    if not next(data) then
        self.root:SetVisible(false)
        return
    else
        self.root:SetVisible(true)
    end
    self.id = data.Id
    self.data = data
    local reward = RewardConfig.findRewardById(data.RewardId)
    if reward and reward.RewardId and not data.Default then
        local config = HeadImageConfig.getConfigById(reward.RewardId)
        local isOwn = HeadImageShop:checkHeadImageStatus(reward.RewardId)
        self.siLock:SetVisible(not isOwn)
        self.siMask:SetVisible(not isOwn)
        self.siUse:SetVisible(reward.RewardId == HeadImageShop.curHeadImage)
        if config and config.Frame and config.Frame ~= "#" then
            self.siImage:setDefaultImage(config.Frame)
        else
            self.siImage:setDefaultImage(DefaultIcon)
        end
    else
        self.siLock:SetVisible(false)
        self.siMask :SetVisible(false)
        self.siUse:SetVisible(HeadImageShop.curHeadImage == 0)
        local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
        if userInfo and (not userInfo[Define.PlayerCustomInfo.CurHeadImage] or userInfo[Define.PlayerCustomInfo.CurHeadImage] == 0) then
            if userInfo.picUrl then
                self.siImage:setUrl(userInfo.picUrl)
            else
                self.siImage:setDefaultImage(DefaultIcon)
            end
        end
    end

    if self.cantBeSelect then
        self.siUse:SetVisible(false)
        self.siLock:SetVisible(false)
        self.siMask:SetVisible(false)
        self.siSelect:SetVisible(false)
    end

    if not self.cantBeSelect and GUIBedWarPictureFrameShopLayout then
        self.siSelect:SetVisible(self.id == GUIBedWarPictureFrameShopLayout:getCurSelectId(2))
    end
end

function GUIBedWarHeadImageItem:setCanNotBeSelect()
    self.cantBeSelect = true
end

return GUIBedWarHeadImageItem