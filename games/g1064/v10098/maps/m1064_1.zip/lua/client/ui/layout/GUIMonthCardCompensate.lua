---@class UIMonthCardCompensate : IGUILayout
local UIMonthCardCompensate = class("UIMonthCardCompensate", IGUILayout)

---@private
function UIMonthCardCompensate:onLoad()
	self.siEffect = self:getChildWindow("MonthCardCompensate-Effect", GUIType.StaticImage)
	self.llContent = self:getChildWindow("MonthCardCompensate-Content", GUIType.Layout)
	self.siTitle = self:getChildWindow("MonthCardCompensate-Title", GUIType.StaticImage)
	self.stTitleText = self:getChildWindow("MonthCardCompensate-Title-Text", GUIType.StaticText)
	self.stHint = self:getChildWindow("MonthCardCompensate-Hint", GUIType.StaticText)
	self.llRewards = self:getChildWindow("MonthCardCompensate-Rewards", GUIType.Layout)
	self.btnSure = self:getChildWindow("MonthCardCompensate-Sure", GUIType.Button)
	self.btnSure:SetText(Lang:getString("gui_bed_war_sure"))
	self:initView()
	self:initEvent()
end

---@private
function UIMonthCardCompensate:initView()
	self.stTitleText:SetText(Lang:getString("gui.month.card.compensate.title"))
	self.stHint:SetText("")
end

function UIMonthCardCompensate:onShowRewardsTip(rewards)
	if #rewards == 0 then
		return
	end
	SoundUtil.playSound(SoundType.GetCoin)
	self.llRewards:CleanupChildren()
	local TotalWidth = self.llRewards:GetPixelSize().x
	local Space = -25
	local Width = math.min(130, (TotalWidth - (#rewards - 1) * Space + 50) / #rewards)
	local PosX = ((Width + Space) * (#rewards - 1)) / -2
	for index, reward in pairs(rewards) do
		local ivBackground = GUIManager:createGUIWindow(GUIType.StaticImage, string.format("UIMonthCardCompensate-Rewards-Background-%d", index))
		ivBackground:SetArea({ 0, PosX }, { 0, 25 }, { 0, Width }, { 0, Width })
		ivBackground:SetHorizontalAlignment(HorizontalAlignment.Center)
		ivBackground:SetImage("set:game_activity.json image:img_0_grade_blue")

		local eivIcon = GUIManager:createGUIWindow(GUIType.EffectViewOfObtainment, string.format("UIMonthCardCompensate-Rewards-Icon-%d", index))
		eivIcon:SetWidth({ 0, Width * 0.5 })
		eivIcon:SetHeight({ 0, Width * 0.5 })
		eivIcon:SetHorizontalAlignment(HorizontalAlignment.Center)
		eivIcon:SetVerticalAlignment(VerticalAlignment.Center)
		if reward.cardId == 1 then
			eivIcon:SetImage("set:month_card.json image:icon_0_key02")
		else
			eivIcon:SetImage("set:month_card.json image:icon_0_key01")
		end

		if reward.time > 0 then
			local tvCount = GUIManager:createGUIWindow(GUIType.StaticText, string.format("UIMonthCardCompensate-Rewards-Count-%d", index))
			tvCount:SetWidth({ 0.2, 0 })
			tvCount:SetHeight({ 0, 25 })
			tvCount:SetYPosition({ 1, -20 })
			tvCount:SetXPosition({ 0, -2 })
			tvCount:SetTextHorzAlign(HorizontalAlignment.Right)
			tvCount:SetTextVertAlign(VerticalAlignment.Center)
			tvCount:SetHorizontalAlignment(HorizontalAlignment.Right)
			tvCount:SetTextBoader(Color.BLACK)
			tvCount:SetProperty("Font", "HT14")
			tvCount:SetText(tostring(reward.time))
			eivIcon:AddChildWindow(tvCount)
		end

		ivBackground:AddChildWindow(eivIcon)
		self.llRewards:AddChildWindow(ivBackground)
		PosX = PosX + Width + Space
	end
	self:show()
end


---@private
function UIMonthCardCompensate:initEvent()
	self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
		self:close()
	end)
end

function UIMonthCardCompensate:close()
	self:hide(true)
end

function UIMonthCardCompensate:hide(force)
	if not force then
		return
	end
	self.super.hide(self, force)
end

return UIMonthCardCompensate
