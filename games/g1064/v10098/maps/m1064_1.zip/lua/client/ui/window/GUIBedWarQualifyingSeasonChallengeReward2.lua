---@class GUIBedWarQualifyingSeasonChallengeReward2Window : IGUIWindow
local GUIBedWarQualifyingSeasonChallengeReward2Window = class("GUIBedWarQualifyingSeasonChallengeReward2Window", IGUIWindow)

---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
local SelectedRewardId = -1

---@private
function GUIBedWarQualifyingSeasonChallengeReward2Window:ctor(...)
    self.super.ctor(self, "BedWarQualifyingSeasonChallengeReward2.json", ...)
end

---@private
function GUIBedWarQualifyingSeasonChallengeReward2Window:onLoad()
    self.siBg = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Bg", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Image", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Count", GUIType.StaticText)
    self.siEffect = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Effect", GUIType.StaticImage)
    self.siMask = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Mask", GUIType.StaticImage)
    self.siSelected = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Selected", GUIType.StaticImage)
    self.siScoreBg = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Score-Bg", GUIType.StaticImage)
    self.stScore = self:getChildWindowByName("BedWarQualifyingSeasonChallengeReward2-Score", GUIType.StaticText)

    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingSeasonChallengeReward2Window:initView()

end

---@private
function GUIBedWarQualifyingSeasonChallengeReward2Window:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
        if score >= self.data.Score then
            if not CQualifyingController:sendReceiveChallengeReward(Define.GameMode.Qualifying, self.data.Id) then
                self:setSelectId(self.rewardId)
                GUIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(self.data.ShowDetailId)
            end
        else
            self:setSelectId(self.rewardId)
            GUIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(self.data.ShowDetailId)
        end
    end)
end

function GUIBedWarQualifyingSeasonChallengeReward2Window:setSelectId(rewardId)
    SelectedRewardId = rewardId
end

---@param data QualifyingSeasonChallengeRewardData
function GUIBedWarQualifyingSeasonChallengeReward2Window:onDataChanged(data)
    self.data = data
    self.rewardId = self.data.Id
    local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
    local isRewardReceived = CQualifyingController:isChallengeRewardReceived(Define.GameMode.Qualifying, data.Id)
    if score >= data.Score then
        self.siScoreBg:SetImage("set:bed_war_2_qualifying_season_challenge_2.json image:img_0_bardot_get")
        self.stScore:SetText("▢FF481705" .. data.Score)
    else
        self.siScoreBg:SetImage("set:bed_war_2_qualifying_season_challenge_2.json image:img_0_bardot_normal")
        self.stScore:SetText(data.Score)
    end
    local canReceive = score >= data.Score and (not isRewardReceived)
    if canReceive then
        if data.ShowEffect then
            self.siEffect:SetEffectName("g1008_effect_ui_shenzhuan_1.effect")
        else
            self.siEffect:SetEffectName("g1008_effect_ui_shenzhuan_2.effect")
        end
    end
    if data.ShowEffect then
        self.siBg:SetImage("set:bed_war_2_qualifying_season_challenge_2.json image:img_0_icon_receive")
    else
        self.siBg:SetImage("set:bed_war_2_qualifying_season_challenge_2.json image:img_0_icon_ordinary")
    end
    self.siMask:SetVisible(isRewardReceived)
    self.siEffect:SetVisible(canReceive)
    self.stCount:SetText("x" .. data.RewardCount)
    local cfg = RewardConfig.findRewardById(data.RewardId)
    if cfg then
        self.siImage:SetImage(cfg.ShowDetail.image)
    else
        self.siImage:SetImage("")
    end
    self.siSelected:SetVisible(SelectedRewardId == self.rewardId)
end
return GUIBedWarQualifyingSeasonChallengeReward2Window
