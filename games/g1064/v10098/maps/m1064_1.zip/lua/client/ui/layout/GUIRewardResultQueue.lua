---@class UIRewardResultQueueLayout : IGUILayout
local UIRewardResultQueueLayout = class("UIRewardResultQueueLayout", IGUILayout)

---@private
function UIRewardResultQueueLayout:ctor(parent)
	self.super.ctor(self, "RewardResultQueue.json", parent)
end

---@private
function UIRewardResultQueueLayout:isDelayLoad()
	return true
end

---@private
function UIRewardResultQueueLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIRewardResultQueueLayout:initCreateEvent()

end

---@private
function UIRewardResultQueueLayout:onLoad()
	self:initView()
	self:initEvent()
end

function UIRewardResultQueueLayout:onShow(result, isShowCount, closeCallBack, counts)
	GUIRewardResult:onShowRewardsTip(result, isShowCount, closeCallBack, counts)
	self:hide()
end

---@private
function UIRewardResultQueueLayout:initView()

end

---@private
function UIRewardResultQueueLayout:initEvent()

end

return UIRewardResultQueueLayout
