---@class GUIBedWarCustomShopSuitItemWindow : IGUIWindow
local GUIBedWarCustomShopSuitItemWindow = class("GUIBedWarCustomShopSuitItemWindow", IGUIWindow)

local Bg = {
	"set:bed_war_3_dress_store.json image:img_0_itembd_leather",
	"set:bed_war_3_dress_store.json image:img_0_itembd_iron",
	"set:bed_war_3_dress_store.json image:img_0_itembd_gold",
	"set:bed_war_3_dress_store.json image:img_0_itembd_diamond",
}

---@private
function GUIBedWarCustomShopSuitItemWindow:ctor(...)
	self.super.ctor(self, "BedWarCustomShopSuitItem.json", ...)
end

---@private
function GUIBedWarCustomShopSuitItemWindow:onLoad()
	self.llContent = self:getChildWindowByName("BedWarCustomShopSuitItem-Content", GUIType.Layout)
	self.siImage = self:getChildWindowByName("BedWarCustomShopSuitItem-Image", GUIType.StaticImage)
	self.siUseIcon = self:getChildWindowByName("BedWarCustomShopSuitItem-Use-Icon", GUIType.StaticImage)
	self.siUseSelectIcon = self:getChildWindowByName("BedWarCustomShopSuitItem-Use-Select-Icon", GUIType.StaticImage)
	self.siLockMask = self:getChildWindowByName("BedWarCustomShopSuitItem-Lock-Mask", GUIType.StaticImage)
	self.siLockIcon = self:getChildWindowByName("BedWarCustomShopSuitItem-Lock-Icon", GUIType.StaticImage)
	self.llPriceBox1 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Box-1", GUIType.Layout)
	self.siPriceBg1 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Bg-1", GUIType.StaticImage)
	self.stPriceText1 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Text-1", GUIType.StaticText)
	self.siPriceIcon1 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Icon-1", GUIType.StaticImage)
	self.siPriceOffBg1 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Off-Bg-1", GUIType.StaticImage)
	self.stPriceOffText1 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Off-Text-1", GUIType.StaticText)
	self.siPriceOffLine1 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Off-Line-1", GUIType.StaticImage)
	self.llPriceBox2 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Box-2", GUIType.Layout)
	self.siPriceBg2 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Bg-2", GUIType.StaticImage)
	self.stPriceText2 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Text-2", GUIType.StaticText)
	self.siPriceIcon2 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Icon-2", GUIType.StaticImage)
	self.siPriceOffBg2 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Off-Bg-2", GUIType.StaticImage)
	self.stPriceOffText2 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Off-Text-2", GUIType.StaticText)
	self.siPriceOffLine2 = self:getChildWindowByName("BedWarCustomShopSuitItem-Price-Off-Line-2", GUIType.StaticImage)
	self.siSelect = self:getChildWindowByName("BedWarCustomShopSuitItem-Select", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarCustomShopSuitItemWindow:initView()
	self.stPriceText1:SetText()
	self.stPriceOffText1:SetText()
	self.stPriceText2:SetText()
	self.stPriceOffText2:SetText()
end

function GUIBedWarCustomShopSuitItemWindow:setArea(xPos, yPos, width, height)
	if not self.root then
		return
	end
	self.root:SetArea(xPos, yPos, width, height)
	local w = self.root:GetPixelSize().x
	local h = self.root:GetPixelSize().y
	local size = w > h and h * 0.85 or w * 0.95
	self.siImage:SetWidth({0, size})
	self.siImage:SetHeight({0, size})

	--size = w > h and h * 0.15 or w * 0.2
	--self.siUseIcon:SetWidth({0, size})
	--self.siUseIcon:SetHeight({0, size})

	--size = h * 0.26
	--self.siLockIcon:SetWidth({0, size / 48 * 43})
	--self.siLockIcon:SetHeight({0, size})
end

---@private
function GUIBedWarCustomShopSuitItemWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		SoundUtil.playSound(SoundConfig.selectGoodsStore)
		GUICustomShop:onSelectGoods(self.data)
	end)

	self:registerEvent(Events.CustomShopGroupItemSelectEvent, function(id)
		self.siSelect:SetVisible(self.Id == id)
	end)
end

---@param data table
function GUIBedWarCustomShopSuitItemWindow:onDataChanged(data, type)
	self.Id = data.Id
	self.data = data

	self.llContent:SetBackImage(Bg[type])
	local unLock = data.Time == -1 or data.Time > 0
	self.siLockMask:SetVisible(not unLock)
	self.llPriceBox1:SetVisible( data.ShowPrice and not unLock and not data.IsMain)
	self.llPriceBox2:SetVisible(data.ShowPrice and not unLock and not data.IsMain)

	local isOff = data.DiscountPrices1 ~= data.Price1
	self.siPriceOffBg1:SetVisible(isOff)
	self.stPriceText1:SetText(isOff and tostring(data.DiscountPrices1) or tostring(data.Price1))
	self.stPriceOffText1:SetText(isOff and tostring(data.Price1) or "")
	self.siPriceIcon1:SetImage(PayHelper.getMoneyIcon(data.CoinId1))

	if data.CoinId2 and data.CoinId2 ~= "#" and data.Price2 > 0 then
		self.siPriceIcon2:SetImage(PayHelper.getMoneyIcon(data.CoinId2))
		isOff = data.DiscountPrices2 ~= data.Price2
		self.siPriceOffBg2:SetVisible(isOff)
		self.stPriceText2:SetText(isOff and tostring(data.DiscountPrices2) or tostring(data.Price2))
		self.stPriceOffText2:SetText(isOff and tostring(data.Price2) or "")
	else
		self.llPriceBox2:SetVisible(false)
	end
	self.siImage:SetImage(data.Image)
	self.siSelect:SetVisible(GUICustomShop.curSelectGoods == data)
	self.siUseIcon:SetVisible(data.Status == CustomShopGoodsStatus.Equipped)
end

function GUIBedWarCustomShopSuitItemWindow:setUnlock()
	self.siLockMask:SetVisible(false)
end

return GUIBedWarCustomShopSuitItemWindow
