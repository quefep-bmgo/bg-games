---@class UIUseCustomGoodsTicketContentLayout : IGUILayout
local UIUseCustomGoodsTicketContentLayout = class("UIUseCustomGoodsTicketContentLayout", IGUILayout)

---@private
function UIUseCustomGoodsTicketContentLayout:onStart()
    self.siTicketBorder = self:getChildWindow("UseCustomGoodsTicketContent-TicketBorder", GUIType.StaticImage)
    self.siTicketImage = self:getChildWindow("UseCustomGoodsTicketContent-TicketImage", GUIType.StaticImage)
    self.siTicketTag = self:getChildWindow("UseCustomGoodsTicketContent-TicketTag", GUIType.StaticImage)
    self.stTicketTime = self:getChildWindow("UseCustomGoodsTicketContent-TicketTime", GUIType.StaticText)
    self.stHint = self:getChildWindow("UseCustomGoodsTicketContent-Hint", GUIType.StaticText)
    self.btnSubOne = self:getChildWindow("UseCustomGoodsTicketContent-SubOne", GUIType.Button)
    self.stCount = self:getChildWindow("UseCustomGoodsTicketContent-Count", GUIType.StaticText)
    self.btnAddOne = self:getChildWindow("UseCustomGoodsTicketContent-AddOne", GUIType.Button)
    self.btnAddTen = self:getChildWindow("UseCustomGoodsTicketContent-AddTen", GUIType.Button)
    self.btnUse = self:getChildWindow("UseCustomGoodsTicketContent-Use", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIUseCustomGoodsTicketContentLayout:initView()
    self.stHint:SetText(Lang:getString("use.custom.goods.ticket.hint"))
	self.btnUse:SetText(Lang:getString("custom.goods.ticket.use"))
    self.btnAddTen:SetText("+10")
end

---@private
function UIUseCustomGoodsTicketContentLayout:initEvent()
    self.btnSubOne:registerEvent(GUIEvent.ButtonClick, function()
		self:changeCount(-1)
    end)
    self.btnAddOne:registerEvent(GUIEvent.ButtonClick, function()
		self:changeCount(1)
    end)
    self.btnAddTen:registerEvent(GUIEvent.ButtonClick, function()
		self:changeCount(10)
    end)
    self.btnUse:registerEvent(GUIEvent.ButtonClick, function()
		if self.curCount <= 0 then
			return
		end
		CommonPacketSender:sendUseCustomGoodsTicket(self.curTicket.id, self.curCount)
		CustomDialog.hide()
    end)
end

function UIUseCustomGoodsTicketContentLayout:changeCount(count)
    if not self.curTicket then
        return
    end
    self.curCount = self.curCount + count
    self.curCount = math.max(self.curCount, 1)
    self.curCount = math.min(self.curTicket.count, self.curCount)
    self.stCount:SetText(self.curCount)
end

---@type UIUseCustomGoodsTicketContentLayout
UseCustomGoodsTicketContent = buildCustomDialogContent(UIUseCustomGoodsTicketContentLayout, "UseCustomGoodsTicketContent.json")

---@param ticket CustomGoodsTicketData
function UseCustomGoodsTicketContent:setCurrentTicket(ticket)
    self.curCount = math.min(ticket.count, 1)
    self.curTicket = ticket
    self.siTicketBorder:SetImage("set:bed_war_3_dress_store.json image:img_0_ticket_" .. tostring(ticket.level))
    self.siTicketTag:SetImage("set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(ticket.level))
    self.stTicketTime:SetText(ticket.day .. Lang:getString("gui.day"))
    local config = CustomShopConfig:getGoodsConfig(ticket.customGoodsId)
    if config then
        self.siTicketImage:SetImage(config.Image)
    end
    self.stCount:SetText(self.curCount)
end
