---@class GUIBedWarQualifyingLoadingPlayerWindow : IGUIWindow
local GUIBedWarQualifyingLoadingPlayerWindow = class("GUIBedWarQualifyingLoadingPlayerWindow", IGUIWindow)

---@private
function GUIBedWarQualifyingLoadingPlayerWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingLoadingPlayer.json", ...)
end

---@private
function GUIBedWarQualifyingLoadingPlayerWindow:onLoad()
    self.siRoot = self:getChildWindowByName("BedWarQualifyingLoadingPlayer", GUIType.StaticImage)
    self.llHeader = self:getChildWindowByName("BedWarQualifyingLoadingPlayer-Header", GUIType.Layout)
    self.siHonor = self:getChildWindowByName("BedWarQualifyingLoadingPlayer-Honor", GUIType.StaticImage)
    self.stHonorName = self:getChildWindowByName("BedWarQualifyingLoadingPlayer-HonorName", GUIType.StaticText)
    self.stName = self:getChildWindowByName("BedWarQualifyingLoadingPlayer-Name", GUIType.StaticText)
    self:initView()
end

---@private
function GUIBedWarQualifyingLoadingPlayerWindow:initView()
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
end

---@param userId number
function GUIBedWarQualifyingLoadingPlayerWindow:onDataChanged(userId, teamId)
    if teamId % 2 == 0 then
        self.siRoot:SetHorizontalAlignment(HorizontalAlignment.Right)
        self.llHeader:SetHorizontalAlignment(HorizontalAlignment.Right)
        self.siHonor:SetHorizontalAlignment(HorizontalAlignment.Right)
        self.siHonor:SetXPosition({ 0, -80 })
        self.stHonorName:SetXPosition({ -1, -5 })
        self.stHonorName:SetTextHorzAlign(HorizontalAlignment.Right)
        self.stName:SetHorizontalAlignment(HorizontalAlignment.Left)
        self.stName:SetTextHorzAlign(HorizontalAlignment.Right)
    end
    local cache = UserInfoCache:GetCache(userId)
    if not cache then
        self.stName:SetText(tostring(userId))
        QualifyingTool.setQualifyingSegmentInListUI(self.siHonor, self.stHonorName, nil)
        return
    end
    local loadingBg = TeamGUIInfo.getTeamGUI(teamId).loadingBg
    if userId == Game:getPlatformUserId() then
        loadingBg = loadingBg .. "_self"
    end
    self.siRoot:SetImage(loadingBg)
    self.stName:SetText(cache.nickName or userId)
    if cache.qualifyingData then
        QualifyingTool.setQualifyingSegmentInListUI(self.siHonor, self.stHonorName, cache.qualifyingData)
    else
        QualifyingTool.setQualifyingSegmentInListUI(self.siHonor, self.stHonorName, nil)
    end
    self.winHead:setUserInfo(cache)
end

function GUIBedWarQualifyingLoadingPlayerWindow:startShowAnim(isRight, index)
    local startPos, endPos
    if isRight then
        startPos = 150
        endPos = -94
    else
        startPos = -150
        endPos = 94
    end
    local offset = (endPos - startPos) / 5
    local curPos = startPos
    self.siRoot:SetXPosition({ 0, curPos })
    self.siRoot:SetVisible(false)
    self:addTimer(LuaTimer:scheduleTicker(function()
        self.siRoot:SetVisible(true)
        self:addTimer(LuaTimer:scheduleTicker(function()
            curPos = curPos + offset
            self.siRoot:SetXPosition({ 0, curPos })
        end, 1, 5))
    end, 5 + index * 2, 1))
end

return GUIBedWarQualifyingLoadingPlayerWindow
