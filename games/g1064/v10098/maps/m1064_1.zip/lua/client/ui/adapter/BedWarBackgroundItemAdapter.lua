---@class BedWarBackgroundItemAdapter : IDataAdapter
local BedWarBackgroundItemAdapter = class("BedWarBackgroundItemAdapter", IDataAdapter)

function BedWarBackgroundItemAdapter:setItemSize(width, height)
    self.width = width
    self.height = height
end

function BedWarBackgroundItemAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIBedWarBackgroundItem")
end

function BedWarBackgroundItemAdapter:getJsonName()
    return "BedWarBackgroundItem.json"
end

function BedWarBackgroundItemAdapter:getItemWidth()
    return { 0, self.width }
end

function BedWarBackgroundItemAdapter:getItemHeight()
    return { 0, self.height }
end

return BedWarBackgroundItemAdapter