---@class UIReportPlayerContentLayout : IGUILayout
local UIReportPlayerContentLayout = class("UIReportPlayerContentLayout", IGUILayout)
---@type table<number, boolean>
local ReportRecord = {}

---@private
function UIReportPlayerContentLayout:onLoad()
    self.llPlayerList = self:getChildWindow("ReportPlayerContent-PlayerList", GUIType.Layout)
    self.llSelected = self:getChildWindow("ReportPlayerContent-Selected", GUIType.Layout)
    self.llClose = self:getChildWindow("ReportPlayerContent-Close", GUIType.Layout)
    self.stHint = self:getChildWindow("ReportPlayerContent-Hint", GUIType.StaticText)
    self.siTeam = self:getChildWindow("ReportPlayerContent-Team", GUIType.StaticImage)
    self.siLine = self:getChildWindow("ReportPlayerContent-Line", GUIType.StaticImage)
    self.llHeader = self:getChildWindow("ReportPlayerContent-Header", GUIType.Layout)
    self.stName = self:getChildWindow("ReportPlayerContent-Name", GUIType.StaticText)
    self.siArrow = self:getChildWindow("ReportPlayerContent-Arrow", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIReportPlayerContentLayout:initView()
    self.stHint:SetText(Lang:getString("gui.report.id"))
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
    self.lvPlayers = IGUIListView.new("ReportPlayerContent-Players", self.llPlayerList)
    self.lvPlayers:setArea({ 0, 0 }, { 0, 50 }, { 1, 0 }, { 1, -50 })
    ---@type ReportPlayerAdapter
    self.playerAdapter = UIHelper.newGameAdapter("ReportPlayerAdapter")
    self.lvPlayers:setAdapter(self.playerAdapter)
    self.llPlayerList:SetVisible(false)
    self.gvReportItems = IGUIGridView.new("ReportPlayerContent-ReportItems", self.root)
    self.gvReportItems:setArea({ 0, 0 }, { 0, 80 }, { 1, 0 }, { 1, -90 })
    self.gvReportItems:setConfig(0, 20, 2)
    ---@type ReportItemAdapter
    self.reportItemAdapter = UIHelper.newGameAdapter("ReportItemAdapter")
    self.gvReportItems:setAdapter(self.reportItemAdapter)
    self.reportItemAdapter:setData(Global.setting.report_items or {})
end

---@private
function UIReportPlayerContentLayout:initEvent()
    self.llSelected:registerEvent(GUIEvent.Click, function()
        self.llPlayerList:SetVisible(not self.llPlayerList:IsVisible())
        self.llClose:SetVisible(self.llPlayerList:IsVisible())
        self.siArrow:SetRotate(self.llPlayerList:IsVisible() and 180 or 0)
    end)
    self.llClose:registerEvent(GUIEvent.Click, function()
        self.llPlayerList:SetVisible(false)
        self.llClose:SetVisible(self.llPlayerList:IsVisible())
        self.siArrow:SetRotate(self.llPlayerList:IsVisible() and 180 or 0)
    end)
end

function UIReportPlayerContentLayout:canReport(userId)
    return ReportRecord[userId] == nil
end

function UIReportPlayerContentLayout:setDefaultPlayer()
    local infos = GameInfoManager:getAllPlayerInfo()
    infos[tostring(Game:getPlatformUserId())] = nil
    local userId = next(infos)
    if userId then
        self:setPlayerInfo(infos[userId])
        return true
    end
    return false
end

---@param playerInfo PlayerInfo
function UIReportPlayerContentLayout:setPlayerInfo(playerInfo)
    self.curUserId = tonumber(playerInfo.infoKey)
    local cache = UserInfoCache:GetCache(self.curUserId)
    if cache then
        self.winHead:setUserInfo(cache)
        self.stName:SetText(cache.nickName)
    else
        self.winHead:setUserInfo({
            picUrl = playerInfo:getValue("picUrl"),
            userId = self.curUserId,
        })
        self.stName:SetText(playerInfo:getValue("userName"))
    end
    local config = TeamGUIInfo.getTeamGUI(playerInfo:getValue("teamId") or "1")
    if config then
        self.siTeam:SetImage(config.tab_icon)
    else
        self.siTeam:SetImage("set:bed_war_battle_info.json image:tab_red")
    end
    local infos = GameInfoManager:getAllPlayerInfo()
    infos[tostring(self.curUserId)] = nil
    infos[tostring(Game:getPlatformUserId())] = nil
    local infoList = {}
    local idMapping = {}
    for userId, info in pairs(infos) do
        if info ~= nil then
            table.insert(infoList, info)
            idMapping[info] = userId
        end
    end
    ---@type PlayerInfo[]
    table.sort(infoList, function(u1, u2)
        return u1:getValue("teamId", true) < u2:getValue("teamId", true)
    end)
    self.llPlayerList:SetHeight({ 0, math.min(300, #infoList * 48 + 50) })
    self.llPlayerList:SetVisible(false)
    self.siArrow:SetRotate(0)
    self.playerAdapter:setData(infoList)
end

function UIReportPlayerContentLayout:doReport()
    if not self:canReport(self.curUserId) then
        UIHelper.showToast(Lang:getString("gui.report.player.already"))
        return
    end
    if #self.reportIds == 0 then
        return
    end
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ReportPlayer",
        userId = self.curUserId,
        reportIds = self.reportIds,
    })
    ReportRecord[self.curUserId] = true
    self.reportIds = {}
    self.reportItemAdapter:notifyDataChange()
end

function UIReportPlayerContentLayout:addReportId(reportId)
    table.insert(self.reportIds, reportId)
    self.reportItemAdapter:notifyDataChange()
    CustomDialog.setRightDisable(#self.reportIds ~= 0)
end

function UIReportPlayerContentLayout:removeReportId(reportId)
    if reportId == nil then
        self.reportIds = {}
    else
        TableUtil.tableRemove(self.reportIds, reportId)
    end
    self.reportItemAdapter:notifyDataChange()
    CustomDialog.setRightDisable(#self.reportIds ~= 0)
end

function UIReportPlayerContentLayout:containReportId(reportId)
    return TableUtil.tableContain(self.reportIds, reportId)
end

---@type UIReportPlayerContentLayout
ReportPlayerContentLayout = buildCustomDialogContent(UIHelper.getGameGUILayoutProxyClass("GUIReportPlayerContent"), "ReportPlayerContent.json")

return UIReportPlayerContentLayout
