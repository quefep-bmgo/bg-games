---@class GUIBedWarHallChatItemContentTextWindow : IGUIWindow
local GUIBedWarHallChatItemContentTextWindow = class("GUIBedWarHallChatItemContentTextWindow", IGUIWindow)

---@private
function GUIBedWarHallChatItemContentTextWindow:ctor(...)
    self.super.ctor(self, "BedWarHallChatItemContentText.json", ...)
end

---@private
function GUIBedWarHallChatItemContentTextWindow:onLoad()
    self.siRoot = DynamicCast.dynamicCastWindow(GUIType.StaticImage, self.root)
    self.stText = self:getChildWindowByName("BedWarHallChatItemContentText-Text", GUIType.StaticText)
end

---@param data ChatMsgData
function GUIBedWarHallChatItemContentTextWindow:onDataChanged(data)
    self.stText:SetText(data.data.content)
    ---@type number 消息总宽度
    local width = self.stText:GetTextWidth()
    ---@type number 消息总高度（换行后），最小取46
    local height = math.max(self.stText:GetTextHeight() + 16, 46)
    if width < self.stText:GetPixelSize().x then
        self.root:SetWidth({ 0, width + 35 })
    end
    self.root:SetHeight({ 0, height })
    Plugins.CallTargetPluginFunc("chat_bubble", "create", self.siRoot, data.sendId, 0, 30)
    return self.root:GetHeight()[2]
end

return GUIBedWarHallChatItemContentTextWindow
