---@class GUIQuestionnaire : IGUILayout
local GUIQuestionnaire = class("GUIQuestionnaire", IGUILayout)

local QuestionnaireConfig = require "game.config.QuestionnaireConfig"

function GUIQuestionnaire:onLoad()

    local bg = self:getChildWindow("Questionnaire-Content-Bg", GUIType.StaticImage)
    bg:SetArea({ 0, 0 }, { 0, 0 }, { 0, 647 }, { 0, 500 })
    self.tvTitleText = self:getChildWindow("Questionnaire-Title-Text", GUIType.StaticText)
    self.btnSure = GUIManager:createGUIWindow(GUIType.Button, "Questionnaire-Sure-Btn")
    self.btnSure:SetArea({ 0, 0 }, { 0, -15 }, { 0, 150 }, { 0, 59 })
    self.btnSure:SetNormalImage("set:bedwar_treasurechallenge.json image:bt_green")
    self.btnSure:SetPushedImage("set:bedwar_treasurechallenge.json image:bt_green")
    self.btnSure:SetVerticalAlignment(VerticalAlignment.Bottom)
    self.btnSure:SetHorizontalAlignment(HorizontalAlignment.Center)
    bg:AddChildWindow(self.btnSure)
    self.btnClose = self:getChildWindow("Questionnaire-Close", GUIType.Button)
    local gvContent = GUIManager:createGUIWindow(GUIType.GridView, "Questionnaire-Content-GridView")
    gvContent:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    local content = self:getChildWindow("Questionnaire-Content-Layout", GUIType.Layout)
    content:SetArea({ 0, 0 }, { 0, 85 }, { 1, 0 }, { 1, -170 })
    content:AddChildWindow(gvContent)
    self.lytContent = GUIManager:createGUIWindow(GUIType.Layout, "Questionnaire-Content-Layout2")
    self.lytContent:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 0, 0 })
    gvContent:AddItem(self.lytContent)

    ---@type GUIQuestionnaireItem[]
    self.itemList = {}
    local questionnaire_list = QuestionnaireConfig:getAllConfig()
    for index, config in pairs(questionnaire_list) do
        if index > 1 then
            local line = GUIManager:createGUIWindow(GUIType.StaticImage, string.format("Questionnaire-Line-%d", index))
            line:SetArea({ 0, 0 }, { 0, yPos }, { 0, 553 }, { 0, 2 })

            line:SetImage("set:bedwar_questionnaire.json image:img_0_dividing_line")
            self:addItemToContent(line)
        end
        local item = UIHelper.newGameGUIWindow("GUIQuestionnaireItem")
        item:setData(config)
        self:addItemToContent(item.root)
        table.insert(self.itemList, item)
    end
    self:initRegister()
    self:initLang()
end

function GUIQuestionnaire:addItemToContent(window)
    local yPos = self.lytContent:GetHeight()[2]
    local height = window:GetPixelSize().y
    window:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.lytContent:AddChildWindow(window)
    window:SetYPosition({ 0, yPos })
    self.lytContent:SetHeight({ 0, yPos + height })
end

function GUIQuestionnaire:initLang()
    self.tvTitleText:SetText(Lang:getString("gui.questionnaire.title.text"))
    self.btnSure:SetText(Lang:getString("gui.sure.btn"))
end

function GUIQuestionnaire:onShow()
    for _, item in pairs(self.itemList) do
        item:reset()
    end
end

function GUIQuestionnaire:initRegister()
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)

    self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
        self:clickSure()
    end)
end

function GUIQuestionnaire:clickSure()
    for _, item in pairs(self.itemList) do
        item:checkReport()
    end
    self:hide()
end

return GUIQuestionnaire