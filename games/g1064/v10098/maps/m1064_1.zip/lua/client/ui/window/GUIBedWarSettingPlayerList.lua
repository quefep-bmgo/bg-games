---@class GUIBedWarSettingPlayerListWindow : IGUIWindow
local GUIBedWarSettingPlayerListWindow = class("GUIBedWarSettingPlayerListWindow", IGUIWindow)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

---@private
function GUIBedWarSettingPlayerListWindow:ctor(...)
    self.super.ctor(self, "BedWarSettingPlayerList.json", ...)
end

---@private
function GUIBedWarSettingPlayerListWindow:onLoad()
    self:initView()
end

---@private
function GUIBedWarSettingPlayerListWindow:initView()
    self.lvPlayers = IGUIListView.new("BedWarSettingPlayerList-Players", self.root)
    self.lvPlayers:setItemSpace(12)
    ---@type BedWarSettingPlayerAdapter
    self.playerAdapter = UIHelper.newGameAdapter("BedWarSettingPlayerAdapter")
    self.lvPlayers:setAdapter(self.playerAdapter)
end

function GUIBedWarSettingPlayerListWindow:onDataChanged()
    local userIds = {}
    ---@type PlayerInfo[]
    local infoList = {}
    local infoMap = GameInfoManager:getAllPlayerInfo()
    for userId, info in pairs(infoMap) do
        table.insert(infoList, info)
        table.insert(userIds, userId)
    end
    UserInfoCache:GetCacheByUserIds(userIds, function()
        PlayerCustomInfoUtil:getPlayerListCustomInfo(userIds, function()
            if GameType ~= "g1046" then
                ---@type PlayerInfo[]
                table.sort(infoList, function(u1, u2)
                    local rank1 = u1:getValue("rank", true)
                    local rank2 = u2:getValue("rank", true)
                    if rank1 == 0 and rank2 ~= 0 then
                        return true
                    end
                    if rank1 ~= 0 and rank2 == 0 then
                        return false
                    end
                    return u1:getValue("teamId", true) < u2:getValue("teamId", true)
                end)
            end
            local caches = {}
            for _, info in pairs(infoList) do
                table.insert(caches, UserInfoCache:GetCache(info.infoKey))
            end
            self.playerAdapter:setData(caches)
        end)
    end)
end

return GUIBedWarSettingPlayerListWindow
