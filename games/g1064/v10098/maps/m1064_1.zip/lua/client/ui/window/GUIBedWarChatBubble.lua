---@class GUIBedWarChatBubbleWindow : IGUIWindow
local GUIBedWarChatBubbleWindow = class("GUIBedWarChatBubbleWindow", IGUIWindow)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")

---@private
function GUIBedWarChatBubbleWindow:ctor(...)
    self.super.ctor(self, "BedWarChatBubble.json", ...)
end

---@private
function GUIBedWarChatBubbleWindow:onLoad()
    self.llBubble = self:getChildWindowByName("BedWarChatBubble", GUIType.Layout)
    self.llBubble:SetLevel(100)
    self.stText = self:getChildWindowByName("BedWarChatBubble-Text", GUIType.StaticText)
    self.siEmoji = self:getChildWindowByName("BedWarChatBubble-Emoji", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("BedWarChatBubble-Effect", GUIType.StaticImage)
end

---@param chatMsg ChatMsgData
function GUIBedWarChatBubbleWindow:onDataChanged(chatMsg)
    if self.timer then
        LuaTimer:cancel(self.timer)
        self.timer = nil
    end
    if chatMsg.type == Define.ChatMsgType.CustomMsg and chatMsg.data.content.type == Define.CustomChatMsgType.EmojiMsg then
        self.stText:SetVisible(false)
        self.llBubble:SetWidth({ 0, 100 })
        self.llBubble:SetHeight({ 0, 115 })
        local config = EmojiConfig:getCfgById(chatMsg.data.content.emojiId)
        self.siEmoji:SetImage(config.icon)
        if string.len(config.effect) > 7 then
            self.siEmoji:SetVisible(false)
            self.siEffect:SetVisible(true)
            local time = self.siEffect:SetEffectName(config.effect)
            if time > 0 then
                self.timer = LuaTimer:schedule(function()
                    self.siEmoji:SetVisible(true)
                    self.siEffect:SetVisible(false)
                end, time)
            end
        else
            self.siEmoji:SetVisible(true)
            self.siEffect:SetVisible(false)
        end
    else
        local text = ChatClient:chatMsgToString(chatMsg, TextFormat.colorBlack, true)
        local width = math.min(200, math.max(self.stText:GetFont():GetTextExtent(text, 1) + 25, 90))
        self.llBubble:SetWidth({ 0, width })
        self.stText:SetVisible(true)
        self.siEmoji:SetVisible(false)
        self.siEffect:SetVisible(false)
        self.stText:SetText(text)
        self.llBubble:SetHeight({ 0, math.max(62, self.stText:GetTextHeight() + 30) })
    end
end

return GUIBedWarChatBubbleWindow
