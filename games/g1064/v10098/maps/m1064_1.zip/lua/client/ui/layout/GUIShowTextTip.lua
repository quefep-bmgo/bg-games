---@class UIShowTextTip : IGUILayout
local UIShowTextTip = class("UIShowTextTip", IGUILayout)

---@private
function UIShowTextTip:ctor()
    self.super.ctor(self, "ShowTextTip.json")
end

---@private
function UIShowTextTip:onLoad()
    self.siBg = self:getChildWindow("ShowTextTip-bg", GUIType.StaticImage)
    self.stText = self:getChildWindow("ShowTextTip-text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIShowTextTip:initView()

end

---@private
function UIShowTextTip:initEvent()
end

---@param text string
function UIShowTextTip:show(text)
    self.super.show(self)
    self.stText:SetText(text)

    self.luaKey = LuaTimer:schedule(function()
        self.luaKey = nil
        self:hide()
    end, 3000)
end

function UIShowTextTip:onShow()

end

return UIShowTextTip
