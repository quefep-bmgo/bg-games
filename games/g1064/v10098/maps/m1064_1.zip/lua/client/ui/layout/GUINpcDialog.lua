---@class UINpcDialogLayout : IGUILayout
local UINpcDialogLayout = class("UINpcDialogLayout", IGUILayout)

local DialogShowType = {
    Ergodic = 1,
    AllShow = 2
}

local DialogShowStatus = {
    Loading = 1,
    Finish = 2
}

---@private
function UINpcDialogLayout:isDelayLoad()
    return false
end

---@private
function UINpcDialogLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UINpcDialogLayout:initCreateEvent()

end

---@private
function UINpcDialogLayout:onLoad()
    self.siBackground = self:getChildWindow("NpcDialog-Background", GUIType.StaticImage)
    self.siDialogImage = self:getChildWindow("NpcDialog-DialogImage", GUIType.StaticImage)
    self.stDialogText = self:getChildWindow("NpcDialog-DialogText", GUIType.StaticText)
    self.stTip = self:getChildWindow("NpcDialog-Tip", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UINpcDialogLayout:initView()
    self.dialogQueue = {}
    self.status = DialogShowStatus.Finish
end

---@private
function UINpcDialogLayout:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        self:onCompleteDialog()
    end)
end

---@private
function UINpcDialogLayout:checkIsCanEnter(dialogId)
    ---@type NpcDialogLimitConfig
    local NpcDialogLimitConfig = T(Global, "NpcDialogLimitConfig")
    local config = NpcDialogLimitConfig:getConfigByGroupId(dialogId)
    if not config then
        return true
    end

    if config.enterLimit == Define.NpcDialogEnterLimitType.TimeRange then
        ---时间范围
        local timeRange = StringUtil.split(config.enterParam, "#", false, true)
        if timeRange[1] > os.time() or timeRange[2] < os.time() then
            return false
        end
    elseif config.enterLimit == Define.NpcDialogEnterLimitType.TriggerTimes then
        ---对话触发次数
        local triggerTimes = tonumber(ClientHelper.getStringForKey(tostring(Game:getPlatformUserId()) .. "NpcDialog_" .. tostring(dialogId), "0"))
        if triggerTimes >= tonumber(config.enterParam) then
            return false
        end
    end
    return true
end

---@param dialogId number
---@param callback function
function UINpcDialogLayout:addNpcDialog(dialogId, callback)
    ---@type NpcDialogListConfig
    local NpcDialogListConfig = T(Global, "NpcDialogListConfig")
    local dialogGroup = NpcDialogListConfig:getConfigByGroupId(dialogId)
    if not dialogGroup then
        return false
    end

    if not self:checkIsCanEnter(dialogId) then
        return false
    end

    table.insert(self.dialogQueue, {
        curIndex = 1,
        dialogGroupId = dialogId,
        dialogGroup = dialogGroup,
        callback = callback,
    })

    if self.status == DialogShowStatus.Finish then
        self:setDialogContent(self.dialogQueue[1].dialogGroup[self.dialogQueue[1].curIndex])
    else
        ---wait
    end
    return true
end

---@private
---@param dialogConfig NpcDialogData
function UINpcDialogLayout:setDialogContent(dialogConfig)
    local content = Lang:getString(dialogConfig.content)
    local times = math.min(#content, 80)

    local x, y = UIHelper:getImageSize(dialogConfig.image, 1280, 720)
    self.siDialogImage:SetArea({ 0, dialogConfig.imageOffset[1] }, { 0, dialogConfig.imageOffset[2] }, x, y)
    self.siDialogImage:SetImage(dialogConfig.image)
    if dialogConfig.background == "#" then
        self.siBackground:SetImage("")
        self.siBackground:SetBackgroundColor({ 0 / 255, 0 / 255, 0 / 255, 180 / 255 })
    else
        self.siBackground:SetImage(dialogConfig.background)
        self.siBackground:SetBackgroundColor({ 0 / 255, 0 / 255, 0 / 255, 0 })
    end
    self.stTip:SetText("")

    if dialogConfig.canSkip == false then
        self.status = DialogShowStatus.Loading
        LuaTimer:scheduleTimer(function()
            self.status = DialogShowStatus.Finish
        end, 30 * times, 1)
    else
        self.status = DialogShowStatus.Finish
    end

    if dialogConfig.showType == DialogShowType.Ergodic then
        local charSub = #content / times
        local curIndex = 0
        self.stDialogText:SetText("")
        self.dialogTimer = LuaTimer:scheduleTimer(function()
            curIndex = curIndex + charSub
            local text = content:sub(1, math.floor(curIndex + 1))
            self.stDialogText:SetText(text)
        end, 30, times)
    elseif dialogConfig.showType == DialogShowType.AllShow then
        if dialogConfig.contentColor == "#" then
            self.stDialogText:SetText(content)
        else
            self.stDialogText:SetText(string.format("▢FF" .. dialogConfig.contentColor .. " %s", tostring(content)))
        end

        if dialogConfig.tip ~= "#" then
            if dialogConfig.tipColor == "#" then
                self.stTip:SetText(Lang:getString(dialogConfig.tip))
            else
                self.stTip:SetText(string.format("▢FF" .. dialogConfig.tipColor .. " %s", tostring(dialogConfig.tip)))
            end
        end
    end

    GUIManager:addShowQueue(self)
end

---@private
function UINpcDialogLayout:onCompleteDialog()
    ---有播放中的对话，直接return
    if self.status == DialogShowStatus.Loading then
        return
    end
    if #self.dialogQueue == 0 then
        self:hide()
        return
    end

    ---记录对话触发次数
    local CompleteTimes = tonumber(ClientHelper.getStringForKey(tostring(Game:getPlatformUserId()) .. "NpcDialog_" .. tostring(self.dialogQueue[1].dialogGroupId), "0"))
    ClientHelper.putStringForKey(tostring(Game:getPlatformUserId()) .. "NpcDialog_" .. tostring(self.dialogQueue[1].dialogGroupId), CompleteTimes + 1)

    self.dialogQueue[1].curIndex = self.dialogQueue[1].curIndex + 1
    if self.dialogQueue[1].curIndex > #self.dialogQueue[1].dialogGroup then
        ---已完成对话，关闭UI
        if self.dialogQueue[1].callback then
            self.dialogQueue[1].callback()
        end
        table.remove(self.dialogQueue, 1)
        if #self.dialogQueue == 0 then
            self:hide()
            return
        end
    end

    ---播放下一段对话
    self:setDialogContent(self.dialogQueue[1].dialogGroup[self.dialogQueue[1].curIndex])
end

---@private
function UINpcDialogLayout:onTick()
    local GuideWindow = GUIManager:getWindowByName("GuideSystem")
    if self.root:IsVisible() and GuideWindow:IsVisible() then
        self.root:SetVisible(false)
        LuaTimer:scheduleTimer(function()
            GUIManager:addShowQueue(self)
        end, 100, 1)
    end
end

return UINpcDialogLayout
