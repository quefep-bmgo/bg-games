---@class UIBedWarHallRankLayout : IGUILayout
local UIBedWarHallRankLayout = class("UIBedWarHallRankLayout", IGUILayout)
---@type FriendManager
local FriendManager = T(Global, "FriendManager")
---@type RankConfig
local RankConfig = T(Global, "RankConfig")
---@type CRankUtil
local CRankUtil = T(Global, "CRankUtil")
---@type FriendScreenConfig
local FriendScreenConfig = T(Global, "FriendScreenConfig")

local RankAreaTabText = {
	[Define.RankSubType.Global] = "gui_rank_area_type_global",
	[Define.RankSubType.Country] = "gui_rank_area_type_country",
	[Define.RankSubType.Friend] = "gui_rank_area_type_friend",
	[Define.RankSubType.Strongest] = "gui_rank_area_type_strongest"
}

local RankSubTabType = {
	[Define.RankSubType.Global] = 3,
	[Define.RankSubType.Country] = 1,
	[Define.RankSubType.Friend] = 5,
	[Define.RankSubType.Strongest] = 4,
	[Define.RankSubType.G1008] = 4,
	[Define.RankSubType.G1061] = 1,
	[Define.RankSubType.G1062] = 2,
	[Define.RankSubType.Qualifying] = 0
}

local RuneTabText = {
	[Define.RuneType.GongJi] = "RuneType_gongji",
	[Define.RuneType.FangYu] = "RuneType_fangyu",
	[Define.RuneType.JiNeng] = "RuneType_jineng",
	[Define.RuneType.GongNeng] = "RuneType_gongneng"
}

local DefaultSubType = {
	[Define.RankType.One] = Define.RankSubType.Global,
	[Define.RankType.Two] = Define.RankSubType.Global,
	[Define.RankType.Three] = Define.RankSubType.Qualifying,
}

---@private
function UIBedWarHallRankLayout:onLoad()
	self.curUser = 0
	self.interval = 100

	self.areaTabs = {
		[Define.RankSubType.Global] = self:getChildWindow("BedWarHallRank-Global", GUIType.Button),
		[Define.RankSubType.Friend] = self:getChildWindow("BedWarHallRank-Friend", GUIType.Button)
	}
	self.fullAreaTabs = {
		[Define.RankSubType.Global] = self:getChildWindow("BedWarHallRank-Full-Global", GUIType.Button),
		[Define.RankSubType.Country] = self:getChildWindow("BedWarHallRank-Full-Country", GUIType.Button),
		[Define.RankSubType.Strongest] = self:getChildWindow("BedWarHallRank-Strongest", GUIType.Button)
	}
	self.runeTabs = {
		[Define.RuneType.GongJi] = self:getChildWindow("BedWarHallRank-Rune-Atk", GUIType.Button),
		[Define.RuneType.FangYu] = self:getChildWindow("BedWarHallRank-Rune-Def", GUIType.Button),
		[Define.RuneType.JiNeng] = self:getChildWindow("BedWarHallRank-Rune-Luk", GUIType.Button),
		[Define.RuneType.GongNeng] = self:getChildWindow("BedWarHallRank-Rune-Buff", GUIType.Button)
	}

	self.siBg = self:getChildWindow("BedWarHallRank-Bg", GUIType.StaticImage)
	self.stTitleText = self:getChildWindow("BedWarHallRank-Title-Text", GUIType.StaticText)
	self.llRankTab = self:getChildWindow("BedWarHallRank-Rank-Tab", GUIType.Layout)
	self.llTabs = self:getChildWindow("BedWarHallRank-Tabs", GUIType.Layout)
	self.btnChange = self:getChildWindow("BedWarHallRank-Change", GUIType.Button)
	self.llFullTabs = self:getChildWindow("BedWarHallRank-Full-Tabs", GUIType.Layout)
	self.llContent = self:getChildWindow("BedWarHallRank-Content", GUIType.Layout)
	self.llSelf = self:getChildWindow("BedWarHallRank-Self", GUIType.Layout)
	self.llPlayerInfo = self:getChildWindow("BedWarHallRank-Player-Info", GUIType.Layout)
	self.stPlayerInfoTitleText = self:getChildWindow("BedWarHallRank-Player-Info-Title-Text", GUIType.StaticText)

	self.siTitleBg = self:getChildWindow("BedWarHallRank-Title-Bg", GUIType.StaticImage)
	self.stTitleNoTitle = self:getChildWindow("BedWarHallRank-Title-NoTitle", GUIType.StaticText)

	self.stDanName = self:getChildWindow("BedWarHallRank-Dan-Name", GUIType.StaticText)
	self.stDanText = self:getChildWindow("BedWarHallRank-Dan-Text", GUIType.StaticText)
	self.stTribeName = self:getChildWindow("BedWarHallRank-Tribe-Name", GUIType.StaticText)
	self.stTribeText = self:getChildWindow("BedWarHallRank-Tribe-Text", GUIType.StaticText)
	self.stIdentityName = self:getChildWindow("BedWarHallRank-Identity-Name", GUIType.StaticText)
	self.stIdentityText = self:getChildWindow("BedWarHallRank-Identity-Text", GUIType.StaticText)
	self.llRune = self:getChildWindow("BedWarHallRank-Rune", GUIType.Layout)
	self.stRuneTitleText = self:getChildWindow("BedWarHallRank-Rune-Title-Text", GUIType.StaticText)
	self.llRuneContent = self:getChildWindow("BedWarHallRank-Rune-Content", GUIType.Layout)

	self.siLimit = self:getChildWindow("BedWarHallRank-Limit", GUIType.StaticImage)
	self.stLimitText = self:getChildWindow("BedWarHallRank-Limit", GUIType.StaticText)

	self.btnRule = self:getChildWindow("BedWarHallRank-Rule", GUIType.Button)
	self.stClose = self:getChildWindow("BedWarHallRank-Close", GUIType.StaticImage)

	self.btnAdd = self:getChildWindow("BedWarHallRank-Add", GUIType.Button)
	self.siAdded = self:getChildWindow("BedWarHallRank-Added", GUIType.StaticImage)
	self.stAddedText = self:getChildWindow("BedWarHallRank-Added-Text", GUIType.StaticText)

	self.btnHomePage = self:getChildWindow("BedWarHallRank-Home-Page", GUIType.Button)
	self.btnChange = self:getChildWindow("BedWarHallRank-Change", GUIType.Button)

	---@type GUIBedWarHallRankItemWindow
	self.selfRankItem = UIHelper.newGameGUIWindow("GUIBedWarHallRankItem")
	self.llSelf:AddChildWindow(self.selfRankItem.root)
	self.selfRankItem.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })

	self.screenItem = UIHelper.newGameGUIWindow("GUISelectList", "BedWarSelectList.json")
	self.llRankTab:AddChildWindow(self.screenItem.root)
	self.screenItem.root:SetArea({0, 0}, {0, 20}, {1, 0}, {0, 41})
	self.screenItem:initList(Define.SelectType.Mode, {
		Height = 42,
		Bg = "set:bed_war_3_rank.json image:btn_0_txt_bg",
		ClickIcon = "set:bed_war_3_rank.json image:btn_0_drop_down",
		ClickIconSize = {{0, -10}, {0, 0}, {0, 25}, {0, 15}}
	})
	self.llDetailClose = self:getChildWindow("BedWarHallRank-Detail-Close", GUIType.Layout)

	self.llTabs:SetVisible(false)
	self.screenItem.root:SetVisible(false)
	self.siLimit:SetVisible(false)
	self.btnRule:SetVisible(false)
	self.siBg:SetXPosition({0, -800})

	self:initView()
	self:initEvent()
end

---@private
function UIBedWarHallRankLayout:onCreate()

end

---@private
function UIBedWarHallRankLayout:initView()
	self.stTitleText:SetText(Lang:getString("gui_rank_title"))
	self.stDanName:SetText(Lang:getString("gui_chat_dan_text"))
	self.stTribeName:SetText(Lang:getString("gui_chat_clan_text"))
	self.stIdentityName:SetText(Lang:getString("gui_chat_role_text"))

	self.btnAdd:SetText(Lang:getString("gui_chat_add_friend_btn_text"))
	self.stAddedText:SetText(Lang:getString("gui_chat_already_friend"))
	self.btnHomePage:SetText(Lang:getString("gui_chat_home_page_btn_text"))
	self.btnChange:SetText(Lang:getString("gui_rank_change_text"))

	self.stTitleNoTitle:SetText(Lang:getString("gui.personal_title.noTitle"))

	self:initRankTabs()
	self:initRankView()
	self:initRuneList()

	self.lvRankList.root:SetVisible(false)
	self.lvTabList.root:SetVisible(false)

	---@type GUIBedWarPersonalTitleShowItem
	self.showTitleItem = UIHelper.newGameGUIWindow("GUIBedWarPersonalTitleShowItem")
	self.siTitleBg:AddChildWindow(self.showTitleItem.root)
end

---@private
function UIBedWarHallRankLayout:initEvent()
	self.screenItem:hideList()
	for type, btn in pairs(self.areaTabs) do
		btn:SetText(Lang:getString(RankAreaTabText[type]))
		btn:registerEvent(GUIEvent.ButtonClick, function()
			self:onAreaTypeChange(type, btn)
		end)
	end

	for type, btn in pairs(self.fullAreaTabs) do
		self.screenItem:hideList()
		btn:SetText(Lang:getString(RankAreaTabText[type]))
		btn:registerEvent(GUIEvent.ButtonClick, function()
			self:onAreaTypeChange(type, btn)
		end)
	end

	for type, btn in pairs(self.runeTabs) do
		self.screenItem:hideList()
		btn:SetText(Lang:getString(RuneTabText[type]))
		btn:registerEvent(GUIEvent.ButtonClick, function()
			self:onRuneTabChange(type)
		end)
	end

	self.btnRule:registerEvent(GUIEvent.ButtonClick, function()
		self.screenItem:hideList()
		if self:isShowTabList() then
			return
		end
		local config = RankConfig:getRankConfigByKey(self.curRankKey)
		if not config or not config.Rule or config.Rule == "#" then
			return
		end
		CustomDialog.builder()
					.setTitleText("gui_rank_rule_title")
					.setContentText(Lang:getString(config.Rule))
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setHideLeftButton()
					.setHideRightButton()
				.show()
	end)

	self.btnChange:registerEvent(GUIEvent.ButtonClick, function()
		if self:isShowTabList() then
			return
		end
		self:hideDetail()
		self.lvRankList.root:SetVisible(false)
		self.lvTabList.root:SetVisible(true)
		self.llRankTab:SetVisible(false)
		self.llFullTabs:SetVisible(false)
		self.btnRule:SetVisible(false)
		self.stTitleText:SetText(Lang:getString("gui_rank_title"))
	end)

	self.btnAdd:registerEvent(GUIEvent.ButtonClick, function()
		self.screenItem:hideList()
		if self.curUser == 0 then
			return
		end
		if FriendManager.IsFriend(self.curUser) then
			return
		end
		local msg = Lang:getString("gui_friend_request_default_msg")
		GUICustomInputContentLayout:setTipText(Lang:getString("gui_add_friend_msg_text"))
		GUICustomInputContentLayout:setDefaultContentText(msg)
		GUICustomInputContentLayout:setContentChangeListener(function(content)
			msg = content
		end)
		CustomDialog.builder()
					.setTitleText("gui_add_friend_msg_title")
					.setContentView(GUICustomInputContentLayout)
					.setRightClickListener(function()
			FriendManager.FriendOperation(Define.FriendOperationType.Request, self.curUser, msg)
			UIHelper.showToast(Lang:getString("gui.send.success"))
			self.llPlayerInfo:SetVisible(false)
		end)        .show()
	end)

	self.btnHomePage:registerEvent(GUIEvent.ButtonClick, function()
		self.screenItem:hideList()
		if self.curUser == 0 then
			return
		end
		---主页
		PopUpWindows.hide()
		CustomDialog.hide()
		GUIPersonalHomePageLayout:openPersonalHomePageByUserId(self.curUser)
	end)

	self.stClose:registerEvent(GUIEvent.Click, function()
		self:hideAnim()
	end)

	self.llDetailClose:registerEvent(GUIEvent.Click, function()
		self.screenItem:hideList()
		if self.llPlayerInfo:IsVisible() or self.llRune:IsVisible() then
			self:hideDetail()
			return
		end
		self:hideAnim()
	end)

	self.siBg:registerEvent(GUIEvent.Click, function()
		self.screenItem:hideList()
	end)

	self:registerEvent(Events.RankTabChangeEvent, function(key, subKey)
		self:onRankChang(key or false, subKey or false)
	end)

	---@param data FriendScreenData
	self:registerEvent(Events.ScreenBeSelectedEvent, function(data, force)
		if data.mainType ~= Define.SelectType.Mode then
			return
		end
		if not force and self.curSubType == data.key then
			return
		end
		self.rankItemAdapter:setScrollOffset(0)
		self:hideDetail()
		self.curSubType = data.key
		CRankUtil:initRankData(self.curRankType, self.curRankKey, RankSubTabType[self.curSubType])
	end)

	self:registerEvent(Events.FinishLoadRankDataEvent, function()
		if self:isShow() then
			self:updateRank(false)
		end
	end)
end

---@private
function UIBedWarHallRankLayout:isShowAnim()
	return false
end

---@private
function UIBedWarHallRankLayout:initRankTabs()
	self.lvTabList = IGUIGridView.new("BedWarHallRank-Tab-List", self.llContent)
	self.lvTabList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.lvTabList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvTabList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvTabList:setConfig(0, 0, 4)
	---@type BedWarHallRankTabAdapter
	self.rankTabAdapter = UIHelper.newGameAdapter("BedWarHallRankTabAdapter")
	local itemWidth = self.lvTabList.root:GetPixelSize().x / 4
	local itemHeight = itemWidth / 192 * 131
	self.rankTabAdapter:setItemSize(itemWidth, itemHeight)
	self.lvTabList:setAdapter(self.rankTabAdapter)
	self:setShowRank(false)
end

---@private
function UIBedWarHallRankLayout:initRankView()
	self.lvRankList = IGUIGridView.new("BedWarHallRank-Item-List", self.llContent)
	self.lvRankList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.lvRankList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvRankList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvRankList:setConfig(0, 0, 1)
	---@type BedWarHallRankItemAdapter
	self.rankItemAdapter = UIHelper.newGameAdapter("BedWarHallRankItemAdapter")
	local itemWidth = self.lvRankList.root:GetPixelSize().x
	local itemHeight = itemWidth / 10 + 14
	self.rankItemAdapter:setItemSize(itemWidth, itemHeight)
	self.lvRankList:setAdapter(self.rankItemAdapter)
	self.rankItemAdapter:setBottomCall(function()
		---加载下一页
		CRankUtil:loadMoreRank(self.curRankKey .. RankSubTabType[self.curSubType], false)
	end)
	self.lvRankList.root:SetVisible(false)
end

---@private
function UIBedWarHallRankLayout:initRuneList()
	self.lvRuneList = IGUIGridView.new("BedWarHallRank-Rune-Item-List", self.llRuneContent)
	self.lvRuneList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.lvRuneList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvRuneList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvRuneList:setConfig(0, 5, 1)
	---@type BedWarHallRankRuneItemAdapter
	self.rankRuneItemAdapter = UIHelper.newGameAdapter("BedWarHallRankRuneItemAdapter")
	local itemWidth = self.lvRuneList.root:GetPixelSize().x
	local itemHeight = (self.lvRuneList.root:GetPixelSize().y - 30) / 7
	self.rankRuneItemAdapter:setItemSize(itemWidth, itemHeight)
	self.lvRuneList:setAdapter(self.rankRuneItemAdapter)
end

function UIBedWarHallRankLayout:onAreaTypeChange(type, btn, force)
	if not force and self.curSubType == type and self.curAreaBtn == btn then
		return
	end
	self.rankItemAdapter:setScrollOffset(0)

	self:hideDetail()
	if self.curAreaBtn then
		self.curAreaBtn:SetNormalImage("set:bed_war_3_rank.json image:tab_9_normal")
		self.curAreaBtn:SetPushedImage("set:bed_war_3_rank.json image:tab_9_normal")
	end
	self.curSubType = type
	self.curAreaBtn = btn
	self.curAreaBtn:SetNormalImage("set:bed_war_3_rank.json image:tab_9_selected")
	self.curAreaBtn:SetPushedImage("set:bed_war_3_rank.json image:tab_9_selected")

	CRankUtil:initRankData(self.curRankType, self.curRankKey, RankSubTabType[self.curSubType])
end

function UIBedWarHallRankLayout:onRankChang(_key, subType)
	local key = (type(_key) == "string" and string.len(_key) > 0) and _key or Define.RankKey.QualifyingRank
	if not self:isShowTabList() and self.curRankKey == key and self.curSubType == subType then
		return
	end
	self:hideDetail()
	self.lvRankList.root:SetVisible(true)
	self.lvTabList.root:SetVisible(false)
	self.btnRule:SetVisible(true)

	local config = RankConfig:getRankConfigByKey(key)
	local isSame = self.curRankKey == key and (subType and self.curSubType == subType or self.curSubType == DefaultSubType[config.RankType])
	local newSubType = subType or DefaultSubType[config.RankType]
	self.curRankType = config.RankType
	self.curRankKey = key
	self.stTitleText:SetText(Lang:getString(config.Title))

	self.llRankTab:SetVisible(true)
	self.llFullTabs:SetVisible(false)
	self.llTabs:SetVisible(false)
	self.screenItem.root:SetVisible(false)
	--self.siLimit:SetVisible(false)
	self.lvRankList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })

	if config.RankType == Define.RankType.One then
		--self.siLimit:SetVisible(true)
		self.llFullTabs:SetVisible(true)
		self.lvRankList.root:SetArea({ 0, 0 }, { 0, 30 }, { 1, 0 }, { 1, -60 })
		self:onAreaTypeChange(newSubType, self.fullAreaTabs[newSubType], not isSame)
	elseif config.RankType == Define.RankType.Two then
		self.llTabs:SetVisible(true)
		self:onAreaTypeChange(newSubType, self.areaTabs[newSubType], not isSame)
	elseif config.RankType == Define.RankType.Three then
		self.screenItem.root:SetVisible(true)
		local screenConfig = FriendScreenConfig:getConfigByKey(Define.SelectType.Mode, newSubType)
		Events.ScreenBeSelectedEvent:invoke(screenConfig, not isSame)
	end
end

function UIBedWarHallRankLayout:updateRank(reset)
	local data = CRankUtil:getRankList(self.curRankKey .. RankSubTabType[self.curSubType]) or {}
	self.rankItemAdapter:setData(data, not reset)
	local userRank = CRankUtil:getUserRank(self.curRankKey .. RankSubTabType[self.curSubType])
	if userRank then
		self.selfRankItem:setSelfData(userRank)
	end
end

function UIBedWarHallRankLayout:showPlayerInfo(userId)
	self.screenItem:hideList()
	self.curUser = userId
	self.llRune:SetVisible(false)

	local cache = UserInfoCache:GetCache(self.curUser)
	if not cache then
		return
	end
	local clanInfo = cache.clanRole or {clanId = 0}
	local qualifyingData = cache.qualifyingData
	self.stPlayerInfoTitleText:SetText(cache.nickName)
	if qualifyingData then
		self.stDanText:SetText(QualifyingTool.getQualifyingSegmentName(qualifyingData.segment, qualifyingData.grade, qualifyingData.starNumber))
	end
	if self.showTitleItem:onDataChanged(cache.currTitle) then
		self.stTitleNoTitle:SetVisible(false)
	else
		self.stTitleNoTitle:SetVisible(true)
	end
	self.stTribeText:SetText(clanInfo.clanId ~= 0 and clanInfo.clanName or Lang:getString("gui_no_clan_text"))
	self.stIdentityText:SetText(Lang:getString(Define.RoleTypeText[clanInfo.clanId ~= 0 and cache.role or -1]))
	local isFriend = FriendManager.IsFriend(cache.userId)
	self.btnAdd:SetVisible(not isFriend)
	self.siAdded:SetVisible(isFriend)
	self.llPlayerInfo:SetVisible(true)
end


function UIBedWarHallRankLayout:showRuneInfo(userId)
	self.screenItem:hideList()
	self.curUser = userId
	self.llPlayerInfo:SetVisible(false)
	local cache = UserInfoCache:GetCache(userId)
	self.stRuneTitleText:SetText(Lang:format("gui_rank_rune_info_title", cache.nickName))
	self:onRuneTabChange(Define.RuneType.GongJi, true)

	self.llRune:SetVisible(true)
end

function UIBedWarHallRankLayout:onRuneTabChange(type, force)
	if not force and type == self.curRuneType then
		return
	end
	if self.curRuneType then
		self.runeTabs[self.curRuneType]:SetHeight({0, 75})
	end
	self.curRuneType = type
	self.runeTabs[self.curRuneType]:SetHeight({0, 95})
	local cache = UserInfoCache:GetCache(self.curUser)
	local runeData = json.decode(cache[Define.PlayerCustomInfo.EquipRune] or "{}") or {}
	self.rankRuneItemAdapter:setData(runeData[tostring(self.curRuneType)] or {})
end

function UIBedWarHallRankLayout:onShow(key, subType)
	self.siBg:SetXPosition({0, -800})
	LuaTimer:cancel(self.showTimer)
	self.showTimer = LuaTimer:scheduleTimerWithEnd(function()
		local cur = self.siBg:GetXPosition()[2]
		self.siBg:SetXPosition({0, cur + self.interval})
	end, function()
		Events.RankTabChangeEvent:invoke(key or false, subType or false)
	end, 30, 8)
end

function UIBedWarHallRankLayout:isShowTabList()
	return self.lvTabList.root:IsVisible()
end

function UIBedWarHallRankLayout:hideAnim()
	LuaTimer:cancel(self.showTimer)
	self.siBg:SetXPosition({0, 0})
	self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
		local cur = self.siBg:GetXPosition()[2]
		self.siBg:SetXPosition({0, cur - self.interval})
	end, function()
		GUIBedWarHallRankLayout:hide()
	end,30, 8))
end

function UIBedWarHallRankLayout:onHide()
	self:hideDetail()
end

function UIBedWarHallRankLayout:onDestroy()
	self.super.onDestroy(self)
	LuaTimer:cancel(self.showTimer)
end

function UIBedWarHallRankLayout:hideDetail()
	self.llPlayerInfo:SetVisible(false)
	self.llRune:SetVisible(false)
end

function UIBedWarHallRankLayout:setShowRank(isShow)
	local config = RankConfig:getRankConfigs()
	local canShowHiddenRank = false
	if isTest or isStaging then
		canShowHiddenRank = isShow
	end
	if not canShowHiddenRank then
		config = TableUtil.removeElementByFun(config, function(key, value)
			if value.Key == Define.RankKey.KeyRank
					or value.Key == Define.RankKey.NegativeRuneRank
					or value.Key == Define.RankKey.PropPacketRank
					or value.Key == Define.RankKey.HornNumRank
					or value.Key == Define.RankKey.ChipNumRank
					or value.Key == Define.RankKey.ChestNumRank
			then
				return true
			end
		end)
	end
	self.rankTabAdapter:setData(config)
end

return UIBedWarHallRankLayout
