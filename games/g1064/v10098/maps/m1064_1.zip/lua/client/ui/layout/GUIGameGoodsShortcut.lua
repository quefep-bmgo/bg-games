---@class UIGameGoodsShortcutLayout : IGUILayout
local UIGameGoodsShortcutLayout = class("UIGameGoodsShortcutLayout", IGUILayout)

local GoodsShortcutMode = require("game.model.GoodsShortcutMode")

---@private
function UIGameGoodsShortcutLayout:ctor(parent)
	self.super.ctor(self, "GameGoodsShortcut.json", parent)
end

---@private
function UIGameGoodsShortcutLayout:isDelayLoad()
	return true
end

---@private
function UIGameGoodsShortcutLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGameGoodsShortcutLayout:initCreateEvent()

end

---@private
function UIGameGoodsShortcutLayout:onLoad()
	self.root:SetLevel(51)
	self.llShopGuide = self:getChildWindow("GameGoodsShortcut-ShopGuide", GUIType.Layout)
	self.stTips = self:getChildWindow("GameGoodsShortcut-Tips", GUIType.StaticText)
	self.shopItemList = {}
	for i = 1, 2 do
		local data = {
			siShopGuideBg = self:getChildWindow("GameGoodsShortcut-ShopGuide-Bg"..i, GUIType.StaticImage),
			siShopGuideIcon = self:getChildWindow("GameGoodsShortcut-ShopGuide-Icon"..i, GUIType.StaticImage),
			siShopGuideMoneyIcon = self:getChildWindow("GameGoodsShortcut-ShopGuide-Money-Icon"..i, GUIType.StaticImage),
			stShopGuidePrice = self:getChildWindow("GameGoodsShortcut-ShopGuide-Price"..i, GUIType.StaticText),
			stShopGuideNum = self:getChildWindow("GameGoodsShortcut-ShopGuide-Num"..i, GUIType.StaticText),
			siMask = self:getChildWindow("GameGoodsShortcut-Mask"..i, GUIType.StaticImage),
			index = i
		}
		data.siShopGuideBg:registerEvent(GUIEvent.Click, function()
			local goodsId = GoodsShortcutMode:getShortcutGoodsByIndex(data.index)
			if isGameStart then
				if not GoodsShortcutMode:isCanBuyGoodsTab(goodsId) then
					return
				end
				ClientStore:onBuyGoods(goodsId, 1, function(success, tips)
					if success then
						local goods = StoreConfig:getGoodsById(goodsId)
						if not goods then
							return
						end
						local totalCount = GoodsStorePrivilege:onBuyGoods(goods)
						local selfUserId = PlayerManager:getClientPlayer().userId
						local info = GameInfoManager:getPlayerInfo(selfUserId)
						local buyItemAddNum = info:getValue("buyItemAdd"..goods.ItemId, true)
						if buyItemAddNum and buyItemAddNum > 0 then
							totalCount = totalCount + buyItemAddNum
						end
						HostApi.notifyGetGoods(goods.showDetail.image, totalCount)
					end
					if tips and #tips > 0 then
						self:showTips(tips)
					end
				end)
				SoundUtil.playSound(SoundConfig.buyGoodsStore)
			end
		end)
		self.shopItemList[i] = data
	end
	self:initView()
	self:initEvent()
end

---@private
function UIGameGoodsShortcutLayout:initView()
	self:setShortcutGoodsData()

	---获得道具UIBg修改
	local llBuyGoods = GUIManager:getWindowByName("BuyGoodsTip-Bg", GUIType.StaticImage)
	llBuyGoods:SetImage("set:bed_war_store.json image:bg_get_goods")
	llBuyGoods:SetArea({ 0, 0 }, { 0, 0 }, { 0, 384 }, { 0, 96 })
	local ivBuyGoodsIcon = GUIManager:getWindowByName("BuyGoodsTip-Icon", GUIType.StaticImage)
	ivBuyGoodsIcon:SetArea({ 0, -40 }, { 0, -5 }, { 0, 53.3 }, { 0, 53.3 })
end

---@private
function UIGameGoodsShortcutLayout:initEvent()
	self:registerEvent(Events.GoodsShortcutListRefresh, function()
		self:setShortcutGoodsData()
	end)

	self:registerEvent(CEvents.ShowMainControlEvent, function()
		self:show()
	end)

	self:registerEvent(Events.StoreBuySuccessEvent, function(goods, count)
		self:refreshBuyState()
	end)

	self:registerEvent(CEvents.InventoryItemStackChangedEvent, function(userId)
		if PlayerManager:getClientPlayer().userId == userId then
			self:refreshBuyState()
		end
	end)
end

---设置商店引导数据
---@param data ShopWeakGuideData[]
function UIGameGoodsShortcutLayout:setShortcutGoodsData()
	for _, v in pairs(self.shopItemList) do
		v.siShopGuideBg:SetVisible(false)
	end
	for i, goodsId in pairs(GoodsShortcutMode:getShortcutList()) do
		local itemUIData = self.shopItemList[i]
		if not itemUIData then
			return
		end
		itemUIData.siShopGuideBg:SetVisible(true)
		local goods = StoreConfig:getGoodsById(goodsId)
		if not goods then
			return
		end
		if #goods.showDetail.image > 10 then
			itemUIData.siShopGuideIcon:SetRenderAsBlock(false)
			itemUIData.siShopGuideIcon:SetImage(goods.showDetail.image)
		else
			if goods.ItemId > 0 then
				GuiItemStack.showItemIcon(itemUIData.siShopGuideIcon, goods.ItemId, 0, "")
			else
				itemUIData.siShopGuideIcon:SetRenderAsBlock(false)
				itemUIData.siShopGuideIcon:SetImage("")
			end
		end
		itemUIData.stShopGuidePrice:SetText(goods.Price)
		itemUIData.stShopGuideNum:SetText(goods.Count)

		local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
		if currency then
			if currency.ItemId > 0 then
				GuiItemStack.showItemIcon(itemUIData.siShopGuideMoneyIcon, currency.ItemId, 0, "")
			elseif currency.RealId > 0 then
				itemUIData.siShopGuideMoneyIcon:SetImage(PayHelper.getMoneyIcon(currency.RealId))
			else
				itemUIData.siShopGuideMoneyIcon:SetImage("")
			end
		else
			itemUIData.siShopGuideMoneyIcon:SetImage("")
		end
		local state = self:canBuy(goodsId)
		itemUIData.siMask:SetVisible(not state)
	end
end

function UIGameGoodsShortcutLayout:canBuy(goodsId)
	local limit = false
	local success = false
	local goodsInfo = ClientStore:getGoods(goodsId)
	local goods = goodsInfo.config
	if goodsInfo.LimitCount >= 0 then
		if goodsInfo.LimitCount - 1 < 0 then
			limit = true
		end
	end
	local currency = StoreConfig:getCurrencyConfig(goods.CurrencyId)
	local price = math.min(goods.Price, goods.DiscountPrice)
	if currency then
		if currency.ItemId > 0 then
			if PlayerWallet.getCoinNum(currency.Id) >= price then
				success = true
			end
		else
			local money = PlayerWallet.getMoneyByCoinId(currency.RealId)
			if money >= price then
				success = true
			end
		end
	end
	if not success or limit then
		return false
	end
	return true
end

function UIGameGoodsShortcutLayout:refreshBuyState()
	for i, goodsId in pairs(GoodsShortcutMode:getShortcutList()) do
		local itemUIData = self.shopItemList[i]
		if itemUIData then
			local state = self:canBuy(goodsId)
			itemUIData.siMask:SetVisible(not state)
		end
	end
end

function UIGameGoodsShortcutLayout:showTips(tips)
	self.stTips:SetText(tips)
	self.stTips:SetVisible(true)
	LuaTimer:cancel(self.curTipKey)
	self.curTipKey = LuaTimer:schedule(function()
		self.stTips:SetVisible(false)
	end, 1000)
end

function UIGameGoodsShortcutLayout:onHide()
	if self.curTipKey then
		LuaTimer:cancel(self.curTipKey)
		self.curTipKey = nil
	end
end

return UIGameGoodsShortcutLayout
