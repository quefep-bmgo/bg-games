---@class GUIBedWarQualifyingSeasonRewardWindow : IGUIWindow
local GUIBedWarQualifyingSeasonRewardWindow = class("GUIBedWarQualifyingSeasonRewardWindow", IGUIWindow)

---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
---@type QualifyingSeasonRewardConfig
local QualifyingSeasonRewardConfig = T(Global, "QualifyingSeasonRewardConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIBedWarQualifyingSeasonRewardWindow:ctor(...)
    self.super.ctor(self, "BedWarQualifyingSeasonReward.json", ...)
end

---@private
function GUIBedWarQualifyingSeasonRewardWindow:onLoad()
    self.btnReward = self:getChildWindowByName("BedWarQualifyingSeasonReward-ReceiveReward", GUIType.Button)
    self.llRewardLayout = self:getChildWindowByName("BedWarQualifyingSeasonReward-RewardPanel", GUIType.Layout)
    self.stDescText = self:getChildWindowByName("BedWarQualifyingSeasonReward-DescTxt", GUIType.StaticText)
    self.stNormalTxt = self:getChildWindowByName("BedWarQualifyingSeasonReward-NormalTxt", GUIType.StaticText)
    self.stHighText = self:getChildWindowByName("BedWarQualifyingSeasonReward-HighTxt", GUIType.StaticText)
    self.siTitleImage = self:getChildWindowByName("BedWarQualifyingSeasonReward-TitleImg", GUIType.StaticImage)
    self.siHighImage = self:getChildWindowByName("BedWarQualifyingSeasonReward-HighIcon", GUIType.StaticImage)
    self.siLockImage = self:getChildWindowByName("BedWarQualifyingSeasonReward-LockImg", GUIType.StaticImage)
    self.siHighIcon = self:getChildWindowByName("BedWarQualifyingSeasonReward-HighIcon", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingSeasonRewardWindow:initView()
    self.stDescText:SetText(Lang:getString("gui.qualifying.reward.desc"))
    self.stNormalTxt:SetText(Lang:getString("gui.qualifying.reward.normal"))
    self.stHighText:SetText(Lang:getString("gui.qualifying.reward.high"))
    if self:needUpgrade() then
        self.siHighIcon:SetDrawColor({ 0.5, 0.5, 0.5, 1 })
        self.btnReward:SetText(Lang:getString("bed_war_levelUp_page1"))
    else
        self.siHighIcon:SetDrawColor({ 1, 1, 1, 1 })
        self.btnReward:SetText(Lang:getString("gui.qualifying.reward.receive"))
    end
    UIHelper:setImageAdjustSize(self.siTitleImage, UIUtils.GetLangImage("set:bed_war_season_reward.json image:text"), 9999, 9999)

    ---@type UIBedWarNewStorePurchase
    self.purchasePanel = UIHelper.newGameGUILayout("GUIBedWarNewStorePurchase", "BedWarNewStorePurchase.json")
    self:initRewardList()
end

function GUIBedWarQualifyingSeasonRewardWindow:showRewardDetail(rewardDetailId)
    local reward = RewardItemShowDetailConfig:getConfigById(rewardDetailId)
    if not reward then
        self:hide()
        return
    end
    if reward.showType == Define.ShowDetailType.Icon then
        self:setIcon(reward)
    elseif reward.showType == Define.ShowDetailType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, reward, self.llActorTouch)
    end
    self.rewardAdapter:notifyDataChange()
end

---@private
function GUIBedWarQualifyingSeasonRewardWindow:initEvent()
    self.btnReward:registerEvent(GUIEvent.ButtonClick, function()
        if self:needUpgrade() then
            CQualifyingController:tryBuyDialog()
        else
            PlayerManager:getClientPlayer():sendPacket({
                pid = "ReceiveSeasonRewardAll"
            })
        end
    end)
    self.siHighImage:registerEvent(GUIEvent.Click, function()
        if self:needUpgrade() then
            CQualifyingController:tryBuyDialog()
        end
    end)
    self:registerEvent(Events.UpdateSeasonReceiveRecordEvent, function()
        if not self.root:IsVisible() or not self.rewardAdapter then
            return
        end
        if self:needUpgrade() then
            self.siHighIcon:SetDrawColor({ 0.5, 0.5, 0.5, 1 })
            self.btnReward:SetText(Lang:getString("bed_war_levelUp_page1"))
        else
            self.siHighIcon:SetDrawColor({ 1, 1, 1, 1 })
            self.btnReward:SetText(Lang:getString("gui.qualifying.reward.receive"))
        end
        self.rewardAdapter:notifyDataChange()
    end)
    self:registerEvent(Events.UpdateChallengeReceiveRecordEvent, function()
        if not self.root:IsVisible() or not self.rewardAdapter then
            return
        end
        self.rewardAdapter:notifyDataChange()
    end)
end

---@private
function GUIBedWarQualifyingSeasonRewardWindow:onShow()
end

function GUIBedWarQualifyingSeasonRewardWindow:onHide()
end


function GUIBedWarQualifyingSeasonRewardWindow:onDestroy()
    RewardItemShowDetailConfig:onWindowHide(self.awActor)
    self.super:onDestroy()
end

function GUIBedWarQualifyingSeasonRewardWindow:needUpgrade()
    local score = CQualifyingController:getChallengeScore(Define.QualifyingSeasonRewardType.High)
    return score <= 0
end

---@private
function GUIBedWarQualifyingSeasonRewardWindow:initRewardList()
    if self.lvRewardList ~= nil then
        return
    end
    self.lvRewardList = IGUIListView.new("BedWarQualifyingSeasonReward-List", self.llRewardLayout, nil, Orientation.Horizontal)
    ---@type BedWarQualifyingSeasonChallengeRewardAdapter
    self.rewardAdapter = UIHelper.newGameAdapter("BedWarQualifyingSeasonRewardAdapter")
    self.lvRewardList:setAdapter(self.rewardAdapter)
    local qualifyingData = CQualifyingController:getQualifyingData()
    if not qualifyingData then
        return
    end
    local items = QualifyingSeasonRewardConfig:getCfgBySeason(qualifyingData.quarter)
    self.rewardAdapter:setData(items)
    self.curOffset = 0
    self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
        if self.curOffset == args.offset then
            return
        end
        self.curOffset = args.offset
    end)
    CQualifyingController:updateSeasonRewardRedPoint()
end

return GUIBedWarQualifyingSeasonRewardWindow
