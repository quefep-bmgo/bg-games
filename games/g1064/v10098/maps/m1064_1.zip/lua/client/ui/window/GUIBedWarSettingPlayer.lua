---@class GUIBedWarSettingPlayerWindow : IGUIWindow
local GUIBedWarSettingPlayerWindow = class("GUIBedWarSettingPlayerWindow", IGUIWindow)
---@type FriendManager
local FriendManager = T(Global, "FriendManager")
---@type table<number, boolean>
local LikeRecord = {}

---@private
function GUIBedWarSettingPlayerWindow:ctor(...)
    self.super.ctor(self, "BedWarSettingPlayer.json", ...)
end

---@private
function GUIBedWarSettingPlayerWindow:onLoad()
    self.llRoot = self:getChildWindowByName("BedWarSettingPlayer", GUIType.Layout)
    self.siTeam = self:getChildWindowByName("BedWarSettingPlayer-Team", GUIType.StaticImage)
    self.llHeader = self:getChildWindowByName("BedWarSettingPlayer-Header", GUIType.Layout)
    self.siSex = self:getChildWindowByName("BedWarSettingPlayer-Sex", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("BedWarSettingPlayer-Name", GUIType.StaticText)
    self.stUserId = self:getChildWindowByName("BedWarSettingPlayer-UserId", GUIType.StaticText)
    self.llDead = self:getChildWindowByName("BedWarSettingPlayer-Dead", GUIType.Layout)
    self.btnReport = self:getChildWindowByName("BedWarSettingPlayer-Report", GUIType.Button)
    self.btnGood = self:getChildWindowByName("BedWarSettingPlayer-Good", GUIType.Button)
    self.btnAddFriend = self:getChildWindowByName("BedWarSettingPlayer-AddFriend", GUIType.Button)
    self:initView()
    self:initEvent()
    self.siSex:SetImage("")
    
end

---@private
function GUIBedWarSettingPlayerWindow:initView()
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
    if GameType == "g1046" then
        self.siTeam:SetVisible(false)
        self.llHeader:SetXPosition({ 0, 30 })
        self.btnReport:SetVisible(false)
        self.btnGood:SetVisible(false)
        self.btnAddFriend:SetXPosition({ 0, -32 })
        self.llDead:SetVisible(false)
        self.siSex:SetXPosition({ 0, 115 })
    end
end

---@private
function GUIBedWarSettingPlayerWindow:initEvent()
    self.btnReport:registerEvent(GUIEvent.ButtonClick, function()
        if not self.data then
            return
        end
        local playerInfo = GameInfoManager:getPlayerInfo(self.data.userId)
        if not playerInfo then
            return
        end
        if NewReportPlayerContentLayout:canReport(self.data.userId) then
            NewReportPlayerContentLayout:setReportPlayer(self.data.userId)
            CustomDialog.builder()
                        .setTitleText("gui.report.player.title")
                        .setPanelSize(nil, 520)
                        .setContentView(NewReportPlayerContentLayout)
                        .setHideLeftButton()
                        .setRightText("gui.report.commit")
                        .setRightClickListener(function()
                NewReportPlayerContentLayout:doReport()
                self.btnReport:SetVisible(false)
            end)        .show()
        else
            UIHelper.showToast(Lang:getString("gui.report.player.already"))
        end
    end)
    self.btnGood:registerEvent(GUIEvent.ButtonClick, function()
        if LikeRecord[self.data.userId] then
            UIHelper.showToast(Lang:getString("gui.personal.popularity.once"))
            return
        end
        if not self.data then
            return
        end
        if Game:getPlatformUserId() == self.data.userId then
            return
        end
        WebService:GivePlayerPageLike(self.data.userId, function(code)
            LikeRecord[self.data.userId] = true
            self.btnGood:SetNormalImage("set:bed_war_3_button.json image:btn_0_likes_1")
            self.btnGood:SetPushedImage("set:bed_war_3_button.json image:btn_0_likes_1")
            if code == 17001 then
                UIHelper.showToast(Lang:getString("gui.personal.popularity.limit"))
            elseif code == 17002 then
                UIHelper.showToast(Lang:getString("gui.personal.popularity.once"))
            elseif code == 1 then
                WebService:GetPlayerPageLikeCount(self.data.userId, function(_, data)
                    CommonPacketSender:sendReportPopularRank(self.data.userId)
                end)
            end
        end)
    end)
    self.btnAddFriend:registerEvent(GUIEvent.ButtonClick, function()
        if not self.data then
            return
        end
        self.btnAddFriend:SetVisible(false)
        if self.data.isRobot then
            FriendManager.UpdateCdTime(self.data.userId, Define.FriendOperationType.Request)
        else
            FriendManager.FriendOperation(Define.FriendOperationType.Request, self.data.userId)
        end
    end)
end

---@param data BedWarUserInfo
function GUIBedWarSettingPlayerWindow:onDataChanged(data)
    self.data = data
    if not self.data then
        return
    end
    self.winHead:setUserInfo(data)
    --self.siSex:SetImage(Define.SexIcon[data.sex] or Define.SexIcon[Define.SexType.Boy])
    self.stName:SetText(data.name or data.nickName)
    self.stUserId:SetText("ID: " .. data.userId)
    self.btnAddFriend:SetVisible(FriendManager.CanAddFriend(data.userId))
    if data.userId == Game:getPlatformUserId() then
        self.llRoot:SetBackImage("set:bed_war_3_setting.json image:img_9_information_1")
    else
        self.llRoot:SetBackImage("set:bed_war_3_setting.json image:img_9_information._bg")
    end
    if LikeRecord[data.userId] then
        self.btnGood:SetNormalImage("set:bed_war_3_button.json image:btn_0_likes_1")
        self.btnGood:SetPushedImage("set:bed_war_3_button.json image:btn_0_likes_1")
    else
        self.btnGood:SetNormalImage("set:bed_war_3_button.json image:btn_0_likes")
        self.btnGood:SetPushedImage("set:bed_war_3_button.json image:btn_0_likes")
    end
    if GameType ~= "g1046" then
        self.btnGood:SetVisible(data.userId ~= Game:getPlatformUserId())
        self.btnReport:SetVisible(data.userId ~= Game:getPlatformUserId())
        local info = GameInfoManager:getPlayerInfo(data.userId)
        if not info then
            self.llDead:SetVisible(true)
            return
        end
        local config = TeamGUIInfo.getTeamGUI(info:getValue("teamId"))
        if config then
            self.siTeam:SetImage(config.tab_icon)
        end
        self.llDead:SetVisible(info:getValue("rank", true) ~= 0)
    end
end

return GUIBedWarSettingPlayerWindow
