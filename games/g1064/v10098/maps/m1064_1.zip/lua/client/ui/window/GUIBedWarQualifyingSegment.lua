---@class GUIBedWarQualifyingSegmentWindow : IGUIWindow
local GUIBedWarQualifyingSegmentWindow = class("GUIBedWarQualifyingSegmentWindow", IGUIWindow)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")

---@private
---@param parent GUIWindow
---@param width number
function GUIBedWarQualifyingSegmentWindow:ctor(parent, width)
    self.super.ctor(self, "BedWarQualifyingSegment.json")
    self.width = width or 244
    self.root:SetWidth({ 0, self.width })
    self.root:SetHeight({ 0, self.width * 370 / 244 })
    self.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.root:SetVerticalAlignment(VerticalAlignment.Center)
    self.contentWidth = self.siImage:GetPixelSize().x
    if parent then
        parent:AddChildWindow(self.root)
    end
end

---@private
function GUIBedWarQualifyingSegmentWindow:onLoad()
    self.siImage = self:getChildWindowByName("BedWarQualifyingSegment-Image", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("BedWarQualifyingSegment-Effect", GUIType.StaticImage)
    ---@type GUIStaticImage[]
    self.starList = {
        self:getChildWindowByName("BedWarQualifyingSegment-Star1", GUIType.StaticImage),
        self:getChildWindowByName("BedWarQualifyingSegment-Star2", GUIType.StaticImage),
        self:getChildWindowByName("BedWarQualifyingSegment-Star3", GUIType.StaticImage),
        self:getChildWindowByName("BedWarQualifyingSegment-Star4", GUIType.StaticImage),
        self:getChildWindowByName("BedWarQualifyingSegment-Star5", GUIType.StaticImage),
    }
    self.stName = self:getChildWindowByName("BedWarQualifyingSegment-Name", GUIType.StaticText)
end

---@param data QualifyingData
function GUIBedWarQualifyingSegmentWindow:onDataChanged(data, anim)
    if not anim then
        self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(data.segment))
        self.stName:SetText(QualifyingTool.getQualifyingSegmentName(data.segment, data.grade, data.starNumber))
        QualifyingTool.setQualifyingStarUI(data.segment, data.starNumber, self.starList)
    else
        local preQualifyingData = CQualifyingController:getPreQualifyingData()
        if not preQualifyingData then
            self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(data.segment))
            self.stName:SetText(QualifyingTool.getQualifyingSegmentName(data.segment, data.grade, data.starNumber))
            QualifyingTool.setQualifyingStarUI(data.segment, data.starNumber, self.starList)
        else
            self:showQualifyingDataChangeAnim(preQualifyingData, data)
        end
    end
end

---@private
---@param preQualifyingData QualifyingData
---@param curQualifyingData QualifyingData
function GUIBedWarQualifyingSegmentWindow:showQualifyingDataChangeAnim(preQualifyingData, curQualifyingData)
    QualifyingTool.setQualifyingStarUI(preQualifyingData.segment, preQualifyingData.starNumber, self.starList)
    if preQualifyingData.segment == curQualifyingData.segment and
            preQualifyingData.grade == curQualifyingData.grade and
            preQualifyingData.starNumber == curQualifyingData.starNumber then
        self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(curQualifyingData.segment))
        self.stName:SetText(QualifyingTool.getQualifyingSegmentName(curQualifyingData.segment, curQualifyingData.grade, curQualifyingData.starNumber))
        return
    end
    local upgradeSegment, addStar = true, true
    if preQualifyingData.segment > curQualifyingData.segment then
        upgradeSegment, addStar = false, false
    elseif curQualifyingData.segment > preQualifyingData.segment then
        upgradeSegment, addStar = true, true
    elseif preQualifyingData.grade > curQualifyingData.grade then
        upgradeSegment, addStar = false, false
    elseif curQualifyingData.grade > preQualifyingData.grade then
        upgradeSegment, addStar = true, true
    else
        upgradeSegment = false
        addStar = preQualifyingData.starNumber < curQualifyingData.starNumber
    end
    if addStar then
        ---加星星，星星动画
        self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(preQualifyingData.segment))
        self.stName:SetText(QualifyingTool.getQualifyingSegmentName(preQualifyingData.segment, preQualifyingData.grade, preQualifyingData.starNumber))
        local maxIndex = 1
        for index, siStar in pairs(self.starList) do
            if siStar:IsVisible() and (index <= curQualifyingData.starNumber or upgradeSegment) then
                maxIndex = index
                self:addTimer(LuaTimer:schedule(function()
                    local siLight = GUIManager:createGUIWindow(GUIType.StaticImage, siStar:GetName() .. "-" .. GUIManager:applyWindowId())
                    siLight:SetWidth({ 1, 0 })
                    siLight:SetHeight({ 1, 0 })
                    siLight:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start3")
                    siStar:AddChildWindow(siLight)
                    local alpha = 1
                    self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
                        alpha = alpha - 0.1
                        siLight:SetAlpha(alpha)
                    end, function()
                        siStar:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start2")
                        GUIManager:destroyGUIWindow(siLight)
                    end, 30, 6))
                end, (index - 1) * 150))
            end
        end
        if upgradeSegment then
            ---升段，升段特效
            self:addTimer(LuaTimer:schedule(function()
                self.siImage:SetImage("")
                self.siEffect:SetVisible(true)
                if preQualifyingData.segment ~= curQualifyingData.segment then
                    self.siEffect:SetEffectName("img_0_ic_honor_lv" .. math.max((curQualifyingData.segment - 1), 1) .. ".effect")
                else
                    self.siEffect:SetEffectName("img_0_ic_honor_up_" .. curQualifyingData.segment .. ".effect")
                end
                self:addTimer(LuaTimer:schedule(function()
                    self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(curQualifyingData.segment))
                    self.siEffect:PlayEffect1("")
                    self.siEffect:SetVisible(false)
                end, preQualifyingData.segment ~= curQualifyingData.segment and 2500 or 1000))
                self.stName:SetText(QualifyingTool.getQualifyingSegmentName(curQualifyingData.segment, curQualifyingData.grade, curQualifyingData.starNumber))
                QualifyingTool.setQualifyingStarUI(curQualifyingData.segment, curQualifyingData.starNumber, self.starList)
            end, (maxIndex - 1) * 300))
        else
            ---升段，升段特效
            self:addTimer(LuaTimer:schedule(function()
                self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(curQualifyingData.segment))
                self.stName:SetText(QualifyingTool.getQualifyingSegmentName(curQualifyingData.segment, curQualifyingData.grade, curQualifyingData.starNumber))
                QualifyingTool.setQualifyingStarUI(curQualifyingData.segment, curQualifyingData.starNumber, self.starList)
            end, (maxIndex - 1) * 300))
        end
    else
        ---减星星
        for index, siStar in pairs(self.starList) do
            if siStar:IsVisible() and index == preQualifyingData.starNumber then
                local siLight = GUIManager:createGUIWindow(GUIType.StaticImage, siStar:GetName() .. "-" .. GUIManager:applyWindowId())
                siLight:SetWidth({ 1, 0 })
                siLight:SetHeight({ 1, 0 })
                siLight:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start3")
                siStar:AddChildWindow(siLight)
                local alpha = 1.5
                self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
                    alpha = alpha - 0.1
                    siLight:SetAlpha(alpha)
                end, function()
                    siStar:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start")
                    GUIManager:destroyGUIWindow(siLight)
                    QualifyingTool.setQualifyingStarUI(curQualifyingData.segment, curQualifyingData.starNumber, self.starList)
                end, 50, 15))
            end
        end
        if preQualifyingData.grade ~= curQualifyingData.grade then
            ---掉段，掉段特效
            local segmentAlpha = 1
            local changeAlpha = preQualifyingData.segment ~= curQualifyingData.segment and 0.1 or 0
            self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
                segmentAlpha = segmentAlpha - changeAlpha
                self.siImage:SetAlpha(segmentAlpha, true)
            end, function()
                self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(curQualifyingData.segment))
                self.stName:SetText(QualifyingTool.getQualifyingSegmentName(curQualifyingData.segment, curQualifyingData.grade, curQualifyingData.starNumber))
                QualifyingTool.setQualifyingStarUI(curQualifyingData.segment, curQualifyingData.starNumber, self.starList)
                for i = 5, 1, -1 do
                    local siStar = self.starList[i]
                    if siStar:IsVisible() then
                        siStar:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start2")
                        break
                    end
                end
                self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
                    segmentAlpha = segmentAlpha + 0.1
                    self.siImage:SetAlpha(segmentAlpha, true)
                end, function()
                    for i = 5, 1, -1 do
                        local siStar = self.starList[i]
                        if siStar:IsVisible() then
                            siStar:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start2")
                            local siLight = GUIManager:createGUIWindow(GUIType.StaticImage, siStar:GetName() .. "-" .. GUIManager:applyWindowId())
                            siLight:SetWidth({ 1, 0 })
                            siLight:SetHeight({ 1, 0 })
                            siLight:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start3")
                            siStar:AddChildWindow(siLight)
                            local starAlpha = 1.5
                            self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
                                starAlpha = starAlpha - changeAlpha
                                siLight:SetAlpha(starAlpha)
                            end, function()
                                siStar:SetImage("set:bed_war_2_qualifying_history.json image:img_0_start")
                                GUIManager:destroyGUIWindow(siLight)
                                QualifyingTool.setQualifyingStarUI(curQualifyingData.segment, curQualifyingData.starNumber, self.starList)
                            end, 50, 15))
                            break
                        end
                    end
                end, 50, 10))
            end, 50, 10))
        else
            self.siImage:SetImage(QualifyingTool.getQualifyingSegmentIcon(preQualifyingData.segment))
            self.stName:SetText(QualifyingTool.getQualifyingSegmentName(preQualifyingData.segment, preQualifyingData.grade, preQualifyingData.starNumber))
        end
    end
end

function GUIBedWarQualifyingSegmentWindow:cancelAllTimer()
    UITimerMgr:cancelUITimerKey(self.windowId)
end

---@param qualifyingData QualifyingData
function GUIBedWarQualifyingSegmentWindow:showQualifyingAnim(qualifyingData, isOld, endCallback)
    self.siEffect:PlayEffect1("")
    self.siEffect:SetVisible(true)
    self.siImage:SetImage("")
    self.stName:SetText(QualifyingTool.getQualifyingSegmentName(qualifyingData.segment, qualifyingData.grade, qualifyingData.starNumber))
    QualifyingTool.setQualifyingStarUI(qualifyingData.segment, qualifyingData.starNumber, self.starList)
    self:cancelAllTimer()
    if isOld then
        local segmentSize = 0
        local changeAlpha = 0.1
        self.siEffect:SetEffectName("g1008_effect_ui_rank_" .. qualifyingData.segment .. ".effect")
        self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
            segmentSize = segmentSize + changeAlpha
            self.siImage:SetWidth({ 0, self.width * segmentSize })
            self.siImage:SetHeight({ 0, self.width / 244 * 249 * segmentSize })
        end, function()
            endCallback()
            local curOffset = 0
            local offset = 1
            self:addTimer(LuaTimer:scheduleTicker(function()
                curOffset = curOffset + offset
                if curOffset == 3 or curOffset == -3 then
                    offset = -offset
                end
                self.siImage:SetYPosition({ 0.027, curOffset })
            end, 8))
        end, 1, 10))
    else
        local segmentSize = 1
        local segmentAlpha = 1
        local change = 0.1
        self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
            segmentSize = segmentSize + change
            segmentAlpha = segmentAlpha - change
            self.siImage:SetWidth({ 0, self.width * segmentSize })
            self.siImage:SetHeight({ 0, self.width / 244 * 249 * segmentSize })
            self.siImage:SetAlpha(segmentAlpha)
            self.siEffect:SetEffectName("g1008_effect_ui_rank_" .. qualifyingData.segment .. ".effect")
        end, function()
            endCallback()
            self.siImage:SetWidth({ 0, self.width })
            self.siImage:SetHeight({ 0, self.width / 244 * 249 })
            self.siImage:SetAlpha(1)
            local curOffset = 0
            local offset = 1
            self:addTimer(LuaTimer:scheduleTicker(function()
                curOffset = curOffset + offset
                if curOffset == 3 or curOffset == -3 then
                    offset = -offset
                end
                self.siImage:SetYPosition({ 0.027, curOffset })
            end, 8))
        end, 1, 10))
    end
end

function GUIBedWarQualifyingSegmentWindow:updateSize(centerX)
    local rect = self.root:GetUnclippedOuterRect()
    local rootCenterX = rect[1] + (rect[3] - rect[1]) / 2
    local scale = 1 - math.abs((rootCenterX - centerX)) / (self.contentWidth * 4)
    self:setContentSize(scale * self.contentWidth)
end

function GUIBedWarQualifyingSegmentWindow:setClickListener(callback)
    self.siImage:registerEvent(GUIEvent.Click, function()
        callback()
    end)
end

return GUIBedWarQualifyingSegmentWindow
