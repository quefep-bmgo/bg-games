---@class UIVisitorsListContentLayout : IGUILayout
local UIVisitorsListContentLayout = class("UIVisitorsListContentLayout", IGUILayout)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

function UIVisitorsListContentLayout:ctor(name, parent)
    self.super.ctor(self, name, parent)
end

function UIVisitorsListContentLayout:onLoad()
    self.llInfo = self:getChildWindow("VisitorsListContent-Info", GUIType.Layout)
    self.stToday = self:getChildWindow("VisitorsListContent-Today", GUIType.StaticText)
    self.stHistory = self:getChildWindow("VisitorsListContent-History", GUIType.StaticText)
    self.llList = self:getChildWindow("VisitorsListContent-List", GUIType.Layout)
    self:initView()

    self.gvVisitorsList = IGUIGridView.new("VisitorsListContent-Visitors-List", self.llList)
    self.gvVisitorsList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.gvVisitorsList:setConfig(14, 10, 1)
    ---@type VisitorsAdapter
    self.visitorsAdapter = UIHelper.newGameAdapter("VisitorsAdapter")
    self.visitorsAdapter:setItemSize(686, 101)
    self.gvVisitorsList:setAdapter(self.visitorsAdapter)
end

function UIVisitorsListContentLayout:initView()
    self.stToday:SetText(Lang:getString("gui.personal.visitors.today") .. ":▢FF81F3EA 0")
    self.stHistory:SetText(Lang:getString("gui.personal.visitors.history") .. ":▢FF81F3EA 0")
end

---@param data BedWarUserInfo
function UIVisitorsListContentLayout:setData(data)
    if not data then
        return
    end
    self.stToday:SetText(Lang:getString("gui.personal.visitors.today") .. ":▢FF81F3EA  " .. (data.dailyVisitorCount or 0))
    self.stHistory:SetText(Lang:getString("gui.personal.visitors.history") .. ":▢FF81F3EA  " .. (data.historyVisitorCount or 0))

    local userIds = {}
    local effectiveVisitors = {}
    for _, visitorInfo in pairs(data.visitorInfos or {}) do
        if UserInfoCache:GetCache(visitorInfo.visitorId) then
            table.insert(effectiveVisitors, visitorInfo)
            table.insert(userIds, visitorInfo.visitorId)
        end
    end
    PlayerCustomInfoUtil:getPlayerListCustomInfo(userIds, function()
        self.visitorsAdapter:setData(effectiveVisitors)
    end)
end

---@type UIVisitorsListContentLayout
--VisitorsListContentLayout = buildPopUpWindowsContent(UIVisitorsListContentLayout, "VisitorsListContent.json")

return UIVisitorsListContentLayout
