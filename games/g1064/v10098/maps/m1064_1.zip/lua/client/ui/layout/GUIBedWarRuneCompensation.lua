---@class UIBedWarRuneCompensationLayout : IGUILayout
local UIBedWarRuneCompensationLayout = class("UIBedWarRuneCompensationLayout", IGUILayout)
---@type RuneConfig
local RuneConfig = T(Global, "RuneConfig")

local page = {
	introduce = 1,
	convert = 2,
}

local cellW = 96
local cellH = 126
local runeInterval = 10
local rewardInterval = 20

---@private
function UIBedWarRuneCompensationLayout:ctor(parent)
	self.super.ctor(self, "BedWarRuneCompensation.json", parent)
end

---@private
function UIBedWarRuneCompensationLayout:isDelayLoad()
	return true
end

---@private
function UIBedWarRuneCompensationLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIBedWarRuneCompensationLayout:initCreateEvent()

end

---@private
function UIBedWarRuneCompensationLayout:onLoad()
	self.llBg = self:getChildWindow("BedWarRuneCompensation-Bg", GUIType.Layout)
	self.llPanel = self:getChildWindow("BedWarRuneCompensation-Panel", GUIType.Layout)
	self.llTitle = self:getChildWindow("BedWarRuneCompensation-Title", GUIType.Layout)
	self.stTitleText = self:getChildWindow("BedWarRuneCompensation-Title-Text", GUIType.StaticText)
	self.btnClose = self:getChildWindow("BedWarRuneCompensation-Close", GUIType.Button)
	self.siLine = self:getChildWindow("BedWarRuneCompensation-Line", GUIType.StaticImage)
	self.llContent = self:getChildWindow("BedWarRuneCompensation-Content", GUIType.Layout)
	self.llMajorUpdate = self:getChildWindow("BedWarRuneCompensation-MajorUpdate", GUIType.Layout)
	self.stMajorUpdateTip = self:getChildWindow("BedWarRuneCompensation-MajorUpdateTip", GUIType.StaticText)
	self.siNpcIcon1 = self:getChildWindow("BedWarRuneCompensation-NpcIcon1", GUIType.StaticImage)
	self.siNpcIcon2 = self:getChildWindow("BedWarRuneCompensation-NpcIcon2", GUIType.StaticImage)
	self.btnNextPage = self:getChildWindow("BedWarRuneCompensation-NextPage", GUIType.Button)
	self.llConvert = self:getChildWindow("BedWarRuneCompensation-Convert", GUIType.Layout)
	self.siTextBg1 = self:getChildWindow("BedWarRuneCompensation-TextBg1", GUIType.StaticImage)
	self.siTextBg2 = self:getChildWindow("BedWarRuneCompensation-TextBg2", GUIType.StaticImage)
	self.stText2 = self:getChildWindow("BedWarRuneCompensation-Text2", GUIType.StaticText)
	self.stText3 = self:getChildWindow("BedWarRuneCompensation-Text3", GUIType.StaticText)
	self.stText5 = self:getChildWindow("BedWarRuneCompensation-Text5", GUIType.StaticText)
	self.stText6 = self:getChildWindow("BedWarRuneCompensation-Text6", GUIType.StaticText)
	self.stIronTipText = self:getChildWindow("BedWarRuneCompensation-Iron-Tip-Text", GUIType.StaticText)
	self.btnFinish = self:getChildWindow("BedWarRuneCompensation-Finish", GUIType.Button)
	self.llIron = self:getChildWindow("BedWarRuneCompensation-Iron", GUIType.Layout)
	self.btnSure = self:getChildWindow("BedWarRuneCompensation-Sure", GUIType.Button)

	self.stMajorUpdateTip:SetText(Lang:getString("gui_dialog_tip_major_update_dec"))
	self.btnNextPage:SetText(Lang:getString("gui.next"))
	self.btnFinish:SetText(Lang:getString("gui.sure"))
	self.btnSure:SetText(Lang:getString("gui.sure"))
	self.stIronTipText:SetText(Lang:getString("gui_iron_change_tip_text"))

	self.stConvertTipText = self:getChildWindow("BedWarRuneCompensation-convert-Tip-Text", GUIType.StaticText)

	self.llConvertList1 = self:getChildWindow("BedWarRuneCompensation-Convert_list1", GUIType.Layout)
	self.gvConvert1 = IGUIListView.new("rune_compensation_convert_grid_view_1", self.llConvertList1, nil, Orientation.Horizontal)
	self.gvConvert1:setArea({ 0, 0 }, { 0, 0 }, { 1.0, 0 }, { 1.0, 0 })
	self.simpleRewardAdapter1 = UIHelper.newGameAdapter("SimpleRewardAdapter", cellW, cellH)
	self.gvConvert1:setAdapter(self.simpleRewardAdapter1)
	self.gvConvert1:setItemSpace(runeInterval)
	self.llConvertList2 = self:getChildWindow("BedWarRuneCompensation-Convert_list2", GUIType.Layout)
	self.gvConvert2 = IGUIListView.new("rune_compensation_convert_grid_view_2", self.llConvertList2, nil, Orientation.Horizontal)
	self.gvConvert2:setArea({ 0, 0 }, { 0, 0 }, { 1.0, 0 }, { 1.0, 0 })
	self.simpleRewardAdapter2 = UIHelper.newGameAdapter("SimpleRewardAdapter", cellW, cellH)
	self.gvConvert2:setAdapter(self.simpleRewardAdapter2)
	self.gvConvert2:setItemSpace(rewardInterval)

	self:initView()
	self:initEvent()
end

---@private
function UIBedWarRuneCompensationLayout:initView(type)
	self.llConvert:SetVisible(false)
	self.llMajorUpdate:SetVisible(false)
	self.llIron:SetVisible(false)
	if type == page.introduce then
		self.llPanel:SetHeight({0, 488})
		self.stTitleText:SetText(Lang:getString("gui_dialog_tip_major_update"))
		self.llMajorUpdate:SetVisible(true)
	elseif type == page.convert then
		self.llPanel:SetHeight({0, 448})
		self.needShowDetails = false
		self.stTitleText:SetText(Lang:getString("gui_rune_conversion_tip"))
		self.stConvertTipText:SetText(Lang:getString("gui_rune_conversion_dec"))
		if not self.data or not self.data.conversionResult then
			return
		end
		local runes = {}
		local rewards = {}
		local rewardCount = 0
		for runeId, v in pairs(self.data.conversionResult) do
			local runeCfg = RuneConfig:getRuneById(runeId)
			if runeCfg then
				local runeInfo = {}
				runeInfo.icon = runeCfg.Image
				runeInfo.num = v.num
				runeInfo.lv = runeCfg.Level
				table.insert(runes, runeInfo)
			end
			local result = v.result
			if result then
				local item = {}
				if not rewards[result.propsId] then
					rewards[result.propsId] = {}
					rewards[result.propsId].num = 0
					rewardCount = rewardCount + 1
				end
				if result.type == "Chest" then
					item = GUIBoxLotteryConfig:findLotteryBoxById(result.propsId)
					rewards[result.propsId].num = rewards[result.propsId].num + v.num * v.result.num
					rewards[result.propsId].icon = item.Image
				end
			end
		end
		table.sort(runes, function(a, b)
			return a.lv > b.lv
		end)
		local runeCount = #runes
		local needWidth1 = runeCount * cellW + math.max((runeCount - 1), 0) * runeInterval
		local needWidth2 = rewardCount * cellW + math.max((rewardCount - 1), 0) * rewardInterval
		self.llConvertList1:SetWidth({ 0, math.min(needWidth1 , 349) })
		self.llConvertList2:SetWidth({ 0, math.min(needWidth2 , 349) })
		self.simpleRewardAdapter1:setData(runes)
		self.simpleRewardAdapter2:setData(rewards)
		self.llConvert:SetVisible(true)
		self.btnFinish:SetText(self.data.iron and Lang:getString("gui.next") or Lang:getString("gui.sure"))
	end
end

---@private
function UIBedWarRuneCompensationLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		if self.needShowDetails then
			self:initView(page.convert)
		else
			self:hide()
		end
	end)

	self.btnNextPage:registerEvent(GUIEvent.ButtonClick, function()
		self:initView(page.convert)
	end)

	self.btnFinish:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)

	self.btnSure:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
end

function UIBedWarRuneCompensationLayout:onShow(data)
	self.data = data
	self.needShowDetails = data.totalEssence and data.totalEssence > 0
	self:initView(data.page or page.convert)
end

return UIBedWarRuneCompensationLayout

