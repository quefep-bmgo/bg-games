---@class GUIActivityTalentItemWindow : IGUIWindow
local GUIActivityTalentItemWindow = class("GUIActivityTalentItemWindow", IGUIWindow)

---@private
function GUIActivityTalentItemWindow:ctor(...)
	self.super.ctor(self, "ActivityTalentItem.json", ...)
end

---@private
function GUIActivityTalentItemWindow:onLoad()
	self.siBg = self:getChildWindowByName("ActivityTalentItem-Bg", GUIType.StaticImage)
	self.siIcon = self:getChildWindowByName("ActivityTalentItem-Icon", GUIType.StaticImage)
	self.stLevel = self:getChildWindowByName("ActivityTalentItem-Level", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIActivityTalentItemWindow:initView()
end

---@private
function GUIActivityTalentItemWindow:initEvent()
	self.siIcon:registerEvent(GUIEvent.Click, function()
		GUITalent:show()
		Events.TalentShowDetail:invoke(self.talentCfg.talentId)
	end)
end

---@param data table
function GUIActivityTalentItemWindow:initData(talentCfg, level)
	self.talentCfg = talentCfg
	self.siIcon:SetImage(talentCfg.icon)
	if level > 0 then
		self.stLevel:SetText(level)
	else
		self.stLevel:SetText()
	end
end

return GUIActivityTalentItemWindow
