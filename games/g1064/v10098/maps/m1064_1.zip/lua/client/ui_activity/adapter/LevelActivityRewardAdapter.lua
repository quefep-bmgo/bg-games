---@type IActivityItemAdapter
local IActivityItemAdapter = UIHelper.requireAdapter("IActivityItemAdapter")

---@class LevelActivityRewardAdapter : IActivityItemAdapter
local LevelActivityRewardAdapter = class("LevelActivityRewardAdapter", IActivityItemAdapter)

---必须重写，返回子UI的json文件名
function LevelActivityRewardAdapter:getJsonName()
    return ""
end

---必须重写，返回子UI的class类创建对象
---@type GUIGameScoreActivityRewardItemWindow
function LevelActivityRewardAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIGameLevelActivityRewardItem", false, "ui_activity")
end

function LevelActivityRewardAdapter:getItemWidth()
    return { 0, 150 }
end

function LevelActivityRewardAdapter:getItemHeight()
    return { 0, 257 }
end

return LevelActivityRewardAdapter