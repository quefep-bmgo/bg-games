---@type IActivityItemAdapter
local IActivityItemAdapter = UIHelper.requireAdapter("IActivityItemAdapter")

---@class ScoreActivityReward10Adapter : IActivityItemAdapter
local ScoreActivityReward10Adapter = class("ScoreActivityReward10Adapter", IActivityItemAdapter)

---必须重写，返回子UI的json文件名
function ScoreActivityReward10Adapter:getJsonName()
    return ""
end

---必须重写，返回子UI的class类创建对象
---@type GUIGameScoreActivityRewardItem10Window
function ScoreActivityReward10Adapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIGameScoreActivityRewardItem10", false, "ui_activity")
end

function ScoreActivityReward10Adapter:getItemWidth()
    return { 0, 130 }
end

function ScoreActivityReward10Adapter:getItemHeight()
    return { 0, 136 }
end

return ScoreActivityReward10Adapter