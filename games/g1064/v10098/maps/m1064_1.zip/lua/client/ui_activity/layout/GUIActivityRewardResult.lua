---@class UIActivityRewardResultLayout : IGUILayout
local UIActivityRewardResultLayout = class("UIActivityRewardResultLayout", IGUILayout)

---@type GUIActivityRewardItemWindow
local itemWindow = require "client.ui_activity.window.GUIActivityRewardItem"

---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function UIActivityRewardResultLayout:ctor(parent)
    self.super.ctor(self, "ActivityRewardResult.json", parent)
end

---@private
function UIActivityRewardResultLayout:onCreate()
    self:initCreateEvent()
end

function UIActivityRewardResultLayout:isDelayLoad()
    return true
end

---@private
function UIActivityRewardResultLayout:initCreateEvent()
    self:registerEvent(Events.ActivityRewardResultEvent, function(rewardList, tip, skipInfo)
        self:show(rewardList, tip, skipInfo or false)
    end)
end

---@private
function UIActivityRewardResultLayout:onLoad()
    self.skipInfo = false
    self.siContentBg = self:getChildWindow("ActivityRewardResult-Content-Bg", GUIType.StaticImage)
    self.llContent = self:getChildWindow("ActivityRewardResult-Content", GUIType.Layout)
    self.stRewardTip = self:getChildWindow("ActivityRewardResult-Reward-Tip", GUIType.StaticText)
    self.llTitleBg = self:getChildWindow("ActivityRewardResult-Title-Bg", GUIType.Layout)
    self.stTitleText = self:getChildWindow("ActivityRewardResult-Title-Text", GUIType.StaticText)
    self.stClickTip = self:getChildWindow("ActivityRewardResult-Click-Tip", GUIType.StaticText)
    self.btnSkip = self:getChildWindow("ActivityRewardResult-SkipBtn", GUIType.Button)
    self:setAlwaysOnTop(true)
    self:initView()
    self:initEvent()
end

---@private
function UIActivityRewardResultLayout:initView()
    self.btnSkip:SetVisible(false)
    self.btnSkip:SetText(Lang:getString("gui.activity.reward.result.skip"))
    self.stTitleText:SetText(Lang:getString("gui.activity.reward.result.title"))
    self.stClickTip:SetText(Lang:getString("gui.activity.reward.result.click"))
end

---@private
function UIActivityRewardResultLayout:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)

    self.btnSkip:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
        self:checkSkip()
    end)
end

function UIActivityRewardResultLayout:onShow(rewardList, tip, skipInfo)
    self:showRewardReward(rewardList, tip, skipInfo)
end

---@param rewardList CommonActivityRewardData[]
function UIActivityRewardResultLayout:showRewardReward(rewardList, tip, skipInfo)
    if #rewardList == 0 then
        return
    end
    self.btnSkip:SetVisible(false)
    if skipInfo then
        self.btnSkip:SetVisible(true)
        self.skipInfo = skipInfo
    end
    SoundUtil.playSound(SoundType.GetCoin)
    self.llContent:CleanupChildren()
    local TotalWidth = self.llContent:GetPixelSize().x
    local Space = 20
    local Width = math.min(192, (TotalWidth - (#rewardList - 1) * Space + 50) / #rewardList)
    local PosX = ((Width + Space) * (#rewardList - 1)) / -2
    for _, reward in pairs(rewardList) do
        local detail = RewardItemShowDetailConfig:getConfigById(reward.showDetailId) or {}
        local item = itemWindow.new()
        item.root:SetArea({ 0, PosX }, { 0, 25 }, { 0, Width }, { 0, Width })
        item.siItemImage:SetImage(detail.image or "")
        if reward.num <= 1 then
            item.stItemName:SetText(Lang:getString(detail.name or ""))
        else
            item.stItemName:SetText(Lang:getString(detail.name or "") .. " x" .. reward.num)
        end
        item:onSetTag(reward)
        item.stCount:SetText("")
        self.llContent:AddChildWindow(item.root)

        PosX = PosX + Width + Space
    end
    self.stRewardTip:SetText(tip)
end

function UIActivityRewardResultLayout:checkSkip()
    if not self.skipInfo then
        return
    end
    GUICustomShop:openCustomShopByGoodsId(self.skipInfo)
    self.skipInfo = false
end

return UIActivityRewardResultLayout
