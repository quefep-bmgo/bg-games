---@type IActivityItemAdapter
local IActivityItemAdapter = UIHelper.requireAdapter("IActivityItemAdapter")

---@class ExchangeRewardAdapter : IActivityItemAdapter
local ExchangeRewardAdapter = class("ExchangeRewardAdapter", IActivityItemAdapter)

---必须重写，返回子UI的json文件名
function ExchangeRewardAdapter:getJsonName()
    return ""
end

---必须重写，返回子UI的class类创建对象
---@type GUIGameScoreActivityRewardItemWindow
function ExchangeRewardAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIExchangeRewardItem", false, "ui_activity")
end

function ExchangeRewardAdapter:getItemWidth()
    return { 0, 159 }
end

function ExchangeRewardAdapter:getItemHeight()
    return { 0, 208 }
end

return ExchangeRewardAdapter