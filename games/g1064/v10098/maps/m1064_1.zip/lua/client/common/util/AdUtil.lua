
---@class AdUtil
local AdUtil = T(Global, "AdUtil")
local AdUnitInfo = {}
local AdEnable = false

function AdUtil:init()
    local VersionCode = tonumber(GameAnalyticsCache:getClientInfo().version_code) or 0
    LogUtil.logInfo("-------------ClientPlayer:initAdInfos()---------------")
    AdEnable = isGarena and tonumber(VersionCode) >= 4410
    if not AdEnable then
        return
    end
    local info = CGame.Instance():getShellInterface():getAdUnitIds() or ""
    if string.len(info) > 0 then
        local ids = json.decode(info)
        AdUnitInfo = {}
        for id, adId in pairs(ids) do
            ---@class AdInfo
            AdUnitInfo[tostring(id)] = {
                unitId = adId,
                isReady = false
            }
        end
        LogUtil.logInfo("--------------Ad Info-------------", LogUtil.pv(AdUnitInfo))
    end
end

function AdUtil:checkAdStatus(adType)
    if not AdEnable then
        return
    end
    LogUtil.logInfo("function AdUtil:checkAdStatus(adType)" .. adType)
    if not AdUnitInfo[adType] or AdUnitInfo[adType].isReady then
        return
    end
    LogUtil.logInfo(string.format("loadAd ---- adType: %s   unitId: %s", adType, AdUnitInfo[adType].unitId))
    CGame.Instance():getShellInterface():loadAd(AdUnitInfo[adType].unitId)
end

function AdUtil:showAd(adType, param)
    if not AdEnable then
        ClientHelper.onWatchAd(tonumber(adType), param)
        return
    end
    LogUtil.logInfo("function AdUtil:showAd(adType, param)")
    if not AdUnitInfo[adType] or not AdUnitInfo[adType].isReady then
        return
    end
    AdUnitInfo[adType].param = param
    AdUnitInfo[adType].isWatch = true
    LogUtil.logInfo(string.format("showAd ---- adType: %s   unitId: %s", adType, AdUnitInfo[adType].unitId))
    CGame.Instance():getShellInterface():showAd(AdUnitInfo[adType].unitId)
end

function AdUtil:isAdReady(adType)
    if not AdEnable then
        return ClientHelper.getBoolPrefs("ShowVideoAd")
    end
    if not AdUnitInfo[adType] then
        return false
    end
    return AdUnitInfo[adType].isReady
end

function AdUtil:getAdUnitIds()
    if not AdEnable then
        return
    end
    return AdUnitInfo
end

function onAdLoaded(adUnitId, status)
    if not AdEnable then
        return
    end
    LogUtil.logInfo(string.format("onAdLoaded ---- adUnitId: %s   status: %s", adUnitId, status))
    if status ~= 0 then
        return
    end
    for type, info in pairs(AdUnitInfo) do
        if info.unitId == adUnitId then
            info.isReady = true
            if type == Define.AdType.BoxLottery and GUIBoxLottery and GUIBoxLottery:isShow() then
                GUIBoxLottery:checkAdUI()
            end
        end
    end
end

function onShowAdResult(adUnitId, result)
    if not AdEnable then
        return
    end
    LogUtil.logInfo(string.format("onShowAdResult ---- adUnitId: %s   params: %s", adUnitId, result))

    for type, info in pairs(AdUnitInfo) do
        if info.unitId == adUnitId and info.isWatch then
            info.isWatch = false
            if result == 0 then
                PlayerManager:getClientPlayer():sendPacket({
                    pid = "OnWatchAdSuccess",
                    type = type,
                    param = info.param or false
                })
            end
            if Platform.isMacIOS() then
                AdUnitInfo[type].isReady = false
                AdUtil:checkAdStatus(type)
            end
        end
    end
end

--AdUtil:init()