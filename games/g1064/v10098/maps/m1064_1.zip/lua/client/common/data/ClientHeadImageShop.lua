---@class ClientHeadImageShop
local HeadImageShop = T(Global, "HeadImageShop")
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type HeadImageShopConfig
local HeadImageShopConfig = T(Global, "HeadImageShopConfig")
local ownHeadImage = {}
---@type TeamService
local TeamService = T(Global, "TeamService")

function HeadImageShop:init()
    self.curHeadImage = 0

    EventObservable:registerDataCallBack("HeadImageDataData", function(data)
        self:updateData(data)
    end, JsonBuilderProcessor)

    EventObservable:registerDataCallBack("BuyHeadImageSuccess", function(data)
        self:updateData(data)
    end, JsonBuilderProcessor)

    EventObservable:registerDataCallBack("RemoveHeadImage", function(data)
        self:removeData(data)
    end, JsonBuilderProcessor)

    EventObservable:registerDataCallBack("EquipHeadImageSuccess", function(data)
        self:updateEquipData(data)
    end, DataBuilderProcessor)

    PlayerCustomInfoUtil:getPlayerAllCustomInfo(Game:getPlatformUserId(), function()
        local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
        if userInfo and userInfo[Define.PlayerCustomInfo.CurHeadImage] then
            self.curHeadImage = userInfo[Define.PlayerCustomInfo.CurHeadImage]
            Events.HeadImageChangeEvent:invoke(Game:getPlatformUserId())
        end
    end)
end

HeadImageShop:init()

function HeadImageShop:onBuyGoods(goods)
    if not HeadImageShopConfig:getShopConfigById(goods.Id) then
        return
    end

    PayHelper.checkMoney(goods.CoinId, goods.Price, function(canBuy)
    end)

    GamePacketSender:sendBuyHeadImage(goods.Id)
end

function HeadImageShop:onEquipGoods(goods)
    if not HeadImageShopConfig:getShopConfigById(goods.Id) then
        return
    end
    local id = 0
    if not goods.Default then
        local reward = RewardConfig.findRewardById(tonumber(goods.RewardId))
        if not reward or not ownHeadImage[tostring(reward.RewardId)] then
            return
        end
        id = reward.RewardId
    end
    if self.curHeadImage == id then
        return
    end
    GamePacketSender:sendEquipHeadImage(goods.Id)
    self:updateShopView()
end

function HeadImageShop:updateData(data)
    for _, id in pairs(data) do
        ownHeadImage[tostring(id)] = true
        Events.HeadImageItemStatusEvent:invoke(id)
    end

    self:updateShopView()
end

function HeadImageShop:removeData(data)
    for _, id in pairs(data) do
        ownHeadImage[tostring(id)] = false
        Events.HeadImageItemStatusEvent:invoke(id)
    end
    self:updateShopView()
end

function HeadImageShop:checkHeadImageStatus(id)
    return ownHeadImage[tostring(id)] or false
end

function HeadImageShop:updateShopView()
    if GUIBedWarPictureFrameShopLayout then
        GUIBedWarPictureFrameShopLayout:updateListUI()
    end
end

function HeadImageShop:updateEquipData(data)
    local id = data:getNumberParam("id")
    if id ~= 0 and not ownHeadImage[tostring(id)] then
        return
    end
    self.curHeadImage = id
    self:updateShopView()
    local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
    if userInfo then
        userInfo[Define.PlayerCustomInfo.CurHeadImage] = self.curHeadImage
    end
    if TeamService:isInTeam(Game:getPlatformUserId()) then
        TeamService:updateTeamMemberInfo()
    end
    Events.HeadImageChangeEvent:invoke(Game:getPlatformUserId())
end