---@class ClientMonthCard
ClientMonthCard = {}

function ClientMonthCard:init()
    self.monthCard = {}
    EventObservable:registerDataCallBack("UpdateMonthCardData", function(data)
        self.monthCard = data
        Events.UpdateMonthCardDataEvent:invoke()
    end, JsonBuilderProcessor)

    EventObservable:registerDataCallBack("MonthCardReceive", function(data)
        local result = {}
        local counts = {}
        local rewardIds = data.rewardIds or {}
        local delay = data.delay
        for rewardId, count in pairs(rewardIds) do
            if count ~= 0 then
                local rewardConfig = RewardConfig.findRewardById(rewardId)
                if rewardConfig then
                    table.insert(result, rewardConfig)
                    counts[rewardConfig.Id] = count
                else
                    assert(false, "rewardId not exist ,id = " .. rewardId)
                end
            end
        end

        if delay then
            LuaTimer:schedule(function()
                local params = {result, true, nil, counts}
                GUIManager:addShowQueue(GUIRewardResultQueueLayout, nil, params)
            end, 1000)
        else
            local params = {result, true, nil, counts}
            GUIManager:addShowQueue(GUIRewardResultQueueLayout, nil, params)
        end
    end, JsonBuilderProcessor)

    EventObservable:registerDataCallBack("NotifyMonthCardCompensate", function(data)
        GUIMonthCardCompensate:onShowRewardsTip(data)
    end, JsonBuilderProcessor)
end

function ClientMonthCard:getMonthCardData()
    return self.monthCard
end

ClientMonthCard:init()