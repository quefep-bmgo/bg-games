local handler = class("CommonPacketHandler", EventObservable)

function handler:init()
    self:registerDataCallBack("UseActionSuccess", function(data)
        self.onOtherPlayerUseAction(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("MoneyCount", function(data)
        local type = data:getNumberParam("type")
        local count = data:getNumberParam("count")
        PlayerWallet:setMoneyCount(type, count)
    end, DataBuilderProcessor)

    self:registerDataCallBack("FakeDiamondsNum", function(data)
        local num = data:getNumberParam("num")
        PlayerWallet:setMoneyCount(Define.Money.FAKE_DIAMOND, num)
    end, DataBuilderProcessor)

    self:registerDataCallBack("TransformDress", function(data)
        self.onTransformOldDress(data)
    end, JsonBuilderProcessor)

    self:registerDataCallBack("BedWarShowReward", function(data)
        self.onShowReward(data)
    end, JsonBuilderProcessor)

    self:registerDataCallBack("IsEquipNinjaShoes", function(data)
        self.isEquipNinjaShoes(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("TryChangeSuitInHallState", function(data)
        self.tryChangeSuitInHallState(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("SyncPetLvData", function(data)
        self.syncPetLvData(data)
    end, JsonBuilderProcessor)
end

function handler.onOtherPlayerUseAction(data)
    local serverId = data:getNumberParam("serverId")
    local actionId = data:getNumberParam("actionId")
    local otherPlayer = PlayerManager:getPlayerByServerId(serverId)

    local entityRender = EntityRenderManager.Instance()
    if not entityRender then
        return
    end
    if otherPlayer and otherPlayer.userId ~= PlayerManager:getClientPlayer().userId then
        local config = ActionEmojiConfig:getConfig(actionId)
        if config then
            otherPlayer:setPlayerActionName(tostring(config.name))
            otherPlayer:setUpperAction1(1012)
        end
    end
end

function handler.onTransformOldDress(data)
    local oldChipInfo = data.oldChipInfo
    local newChipCount = data.newChipCount
    if #oldChipInfo > 0 and newChipCount > 0 then
        TransformChipContent:setTransformData(oldChipInfo, newChipCount)
        PopUpWindows.builder()
                    .setTitleText("TransformChip_Title")
                    .setContentView(TransformChipContent)
                    .show()
    end
end

function handler.onShowReward(data)
    local result = {}
    local counts = {}
    for rewardId, count in pairs(data or {}) do
        if count ~= 0 then
            local rewardConfig = RewardConfig.findRewardById(rewardId)
            if rewardConfig then
                table.insert(result, rewardConfig)
                counts[rewardConfig.Id] = count
            else
                assert(false, "rewardId not exist ,id = " .. rewardId)
            end
        end
    end

    GUIRewardResult:onShowRewardsTip(result, true, nil, counts)
end

function handler.isEquipNinjaShoes(data)
    local isEquip = data:getBoolParam("isEquip")
    ---@type ClientPlayer
    local player = PlayerManager:getClientPlayer()
    if player and player.Player then
        if isEquip then
            local height = data:getNumberParam("height")
            local curHeight = player.Player:getFloatProperty("JumpHeight")
            player.Player:setFloatProperty("JumpHeight", math.max(height, curHeight))
            player.doubleJumpCount = 2
        else
            if player.petDoubleJump and player.petDoubleJump > 0 then
                return
            end
            player.Player:setFloatProperty("JumpHeight", 0.42)
            player.doubleJumpCount = 1
        end
    end
end

function handler.tryChangeSuitInHallState(data)
    local isShow = data:getBoolParam("isShow")
    CustomDialog.builder()
                .setTitleText("gui_try_change_suit_in_hall_state_tip_title")
                .setContentText(Lang:getString("gui_try_change_suit_in_hall_state_tip"))
                .setCloseVisible(false)
                .setRightClickListener(function()
        GUIArmorPanel:changeSuitState(isShow)
    end)
                .showNoShowTip(function(status)
        if status then
            CommonPacketSender:sendNoShowSuitTipToday()
            return
        end
    end)
                .show()
end

function handler.syncPetLvData(data)
    ---@type ClientPlayer
    local player = PlayerManager:getClientPlayer()
    if player then
        if not player.petData then
            player.petData = {}
        end
        for petId, lv in pairs(data) do
            player.petData[petId] = lv
        end
    end
    if GUICustomShop:isShow() then
        GUICustomShop:updateListUI()
    end
    GUIPlayerInfo:updatePetImbueInfo()
end

handler:init()