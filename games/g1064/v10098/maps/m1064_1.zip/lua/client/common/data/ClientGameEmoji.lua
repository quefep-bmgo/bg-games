---@class ClientGameEmoji
ClientGameEmoji = {}
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

function ClientGameEmoji:init()
    self.emojiData = {}
    EventObservable:registerDataCallBack("UpdateGameEmojiData", function(data)
        self.emojiData = data
        Events.UpdateGameEmojiDataEvent:invoke()
        if data.redDotId then
            local cfg = EmojiConfig:getCfgById(tostring(data.redDotId))
            UIUtils.updateRedDotCount(Define.RedDotKey.ChatMsgTab .. "emoji" .. cfg.tabId, 1)
            UIUtils.updateRedDotCount(Define.RedDotKey.ChatMsgTab.."emojiBtn", 1)
            self.emojiData.redDotId = nil
        end
    end, JsonBuilderProcessor)
end

function ClientGameEmoji:getGameEmojiData()
    return self.emojiData
end

ClientGameEmoji:init()