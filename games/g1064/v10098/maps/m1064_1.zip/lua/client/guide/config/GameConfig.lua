require "common.config.BoxLotteryConfig"
GameConfig = {}

function GameConfig:loadConfig()
    local config = FileUtil.getConfigFromYml("setting/ClientConfig.yml")
    GameConfig.useNewLottery = config.useNewLottery or 1
    GameConfig.mainTabRedPoint = config.mainTabRedPoint or 5
    GameConfig.useTransparentCamera = tonumber(config.useTransparentCamera or "0") == 1
    GameConfig.specialTransparentAlpha = tonumber(config.specialTransparentAlpha) or 0.5
    GameConfig.bowSensitiveMultiplier = config.bowSensitiveMultiplier or 1
    GameConfig.bowSpeedMultiplier = config.bowSpeedMultiplier or 1
    GameConfig.bowFOVMultiplier = config.bowFOVMultiplier or 1
    GameConfig.NinjaShoesJumpHeight = config.NinjaShoesJumpHeight or 0.42
    GameConfig.placeBlockMaxDepth = config.placeBlockMaxDepth or 1
    GameConfig.placeBlockMaxBuildDistance = config.placeBlockMaxBuildDistance or 3
    GameConfig.buildRoadModeMaxDistance = config.buildRoadModeMaxDistance or 5
    GameConfig:loadGameConfig()
    require "common.config.DressStoreConfig"

    ClientHelper.putBoolPrefs("IsTransparentCamera", GameConfig.useTransparentCamera)
    Blockman.Instance():setBlockSpecialTransparentAlpha(GameConfig.specialTransparentAlpha)
end

function GameConfig:loadGameConfig()
    GUIBoxLotteryConfig.loadBoxConfig()
    GUIBoxLotteryConfig.loadRewardConfig()
    require "guide.config.GuideNodesSettingConfig"
    require "guide.config.GuideProcessSettingConfig"
    require "common.config.PrivilegeConfig"
end