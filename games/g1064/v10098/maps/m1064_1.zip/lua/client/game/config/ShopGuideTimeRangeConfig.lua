---@class ShopGuideTimeRangeConfig
local ShopGuideTimeRangeConfig = T(Global, "ShopGuideTimeRangeConfig")
---@type ShopGuideTimeRangeData[]
local Settings = {}

function ShopGuideTimeRangeConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/ShopGuideTimeRange.csv")
    for _, item in pairs(config) do
        ---@class ShopGuideTimeRangeData
        local data = {
            groupId = item.groupId,
            timeRange = StringUtil.split(item.timeRange, "#", false, true),
        }
        table.insert(Settings, data)
    end
end

function ShopGuideTimeRangeConfig:getAllCfg()
    return Settings
end

---@return ShopGuideTimeRangeData
function ShopGuideTimeRangeConfig:getCfgById(id)
    return Settings[id]
end

ShopGuideTimeRangeConfig:init()
