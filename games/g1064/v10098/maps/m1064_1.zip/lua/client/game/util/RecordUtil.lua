---@class CRecordUtil
local CRecordUtil = T(Global, "CRecordUtil")
local RecordKey = {
    AttackDis = "attackDis",
    AttackFrequency = "attackFrequency",
    MoveDis = "moveDis",
    FloatTime = "floatTime"
}

local function checkOnMount()
    local entityPlayer = PlayerManager:getClientPlayer().Player
    if entityPlayer then
        if entityPlayer:isOnFloatingMount() or entityPlayer:isOnFlyingMount() then
            return true
        end
    end
    return false
end

---@private
function CRecordUtil:init()
    self.recordData = {}
    LuaTimer:scheduleTimer(function()
        self:syncRecordData()
    end, 60000)
    LuaTimer:scheduleTimer(function()
        self:recordAttackFrequency()
        self:recordFloatTime()
    end, 1000)
    LuaTimer:scheduleTicker(function()
        self:recordOnPlayerMove()
    end, 1)
end

function CRecordUtil:recordOnPlayerAttack(targetPos)
    local disRecord = self.recordData[RecordKey.AttackDis] or {}
    local dis = math.floor(VectorUtil.distance(PlayerManager:getClientPlayer():getPosition(), targetPos))
    if not disRecord[tostring(dis)] then
        disRecord[tostring(dis)] = 0
    end
    disRecord[tostring(dis)] = disRecord[tostring(dis)] + 1
    self.recordData[RecordKey.AttackDis] = disRecord
    self.attackTimes = (self.attackTimes or 0) + 1
    self.dataChange = true
end

function CRecordUtil:recordOnPlayerMove()
    if not isGameStart then
        return
    end
    self:checkPlayerFloat()
    if not self.lastPos then
        self.lastPos = PlayerManager:getClientPlayer():getPosition()
        return
    end
    local cur = PlayerManager:getClientPlayer():getPosition()
    local dis = VectorUtil.distanceXZ(self.lastPos, cur)
    if dis <= 0 then
        return
    end
    self.lastPos = cur
    self.recordData[RecordKey.MoveDis] = (self.recordData[RecordKey.MoveDis] or 0) + dis
    self.dataChange = true
end

function CRecordUtil:checkPlayerFloat()
    local player = PlayerManager:getClientPlayer()
    local cur = player:getPosition()
    local info = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
    if not info then
        return
    end
    local lifeStatus = info:getBoolValue("lifeStatus")
    if lifeStatus
            and not checkOnMount()
            and EngineWorld:getBlockId(VectorUtil.add3(cur, VectorUtil.newVector3(0, -2, 0))) == BlockID.AIR
            and EngineWorld:getBlockId(VectorUtil.add3(cur, VectorUtil.newVector3(0, -3, 0))) == BlockID.AIR then
        if not self.floatTime or self.floatTime == 0 then
            self.floatTime = os.time()
            return
        end
    else
        self:recordFloatTime()
    end
end

function CRecordUtil:recordFloatTime()
    if not isGameStart or not self.floatTime or self.floatTime == 0 then
        return
    end
    self.recordData[RecordKey.FloatTime] = (self.recordData[RecordKey.FloatTime] or 0) + (os.time() - self.floatTime)
    self.floatTime = 0
    self.dataChange = true
end

function CRecordUtil:recordAttackFrequency()
    if not isGameStart or not self.attackTimes or self.attackTimes <= 0 then
        return
    end
    local frequencyRecord = self.recordData[RecordKey.AttackFrequency] or {}
    if not frequencyRecord[tostring(self.attackTimes)] then
        frequencyRecord[tostring(self.attackTimes)] = 0
    end
    frequencyRecord[tostring(self.attackTimes)] = frequencyRecord[tostring(self.attackTimes)] + 1
    self.recordData[RecordKey.AttackFrequency] = frequencyRecord
    self.attackTimes = 0
    self.dataChange = true
end

function CRecordUtil:syncRecordData()
    if not isGameStart or not self.dataChange then
        return
    end
    PlayerManager:getClientPlayer():sendPacket({
        pid = "syncRecordData",
        data = json.encode(self.recordData)
    })
    self.dataChange = false
end

CRecordUtil:init()