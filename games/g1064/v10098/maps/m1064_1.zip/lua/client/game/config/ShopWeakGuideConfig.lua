---@class ShopWeakGuideConfig
local ShopWeakGuideConfig = T(Global, "ShopWeakGuideConfig")
---@type ShopWeakGuideData[]
local Settings = {}

function ShopWeakGuideConfig:loadConfig()
    local config = FileUtil.getConfigFromCsv("setting/ShopWeakGuide.csv")
    for _, item in pairs(config) do
        ---@class ShopWeakGuideData
        local data = {
            index = item.index,
            groupId = tonumber(item.groupId),
            goodsId = tonumber(item.goodsId),
            itemId = tonumber(item.itemId),
            preItem = StringUtil.split(item.preItem, "#"),
            excludeItem = StringUtil.split(item.excludeItem, "#"),
            maxNum = item.maxNum,
            weights = tonumber(item.weights),
        }
        table.insert(Settings, data)
    end
end

function ShopWeakGuideConfig:getAllCfg()
    return Settings
end

---@return ShopWeakGuideData
function ShopWeakGuideConfig:getCfgById(id)
    return Settings[id]
end

ShopWeakGuideConfig:loadConfig()
