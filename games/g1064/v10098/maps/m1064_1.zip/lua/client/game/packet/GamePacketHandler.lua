---@class GamePacketHandler : EventObservable
local handler = class("GamePacketHandler", EventObservable)
---@type CPacketHandlers
local CPacketHandlers = T(Global, "PacketHandlers")

Trigger = {}
Trigger.isFirstOpen = true

function handler:init()
    self:registerDataCallBack("OpenLottery", self.onOpenLottery)
    self:registerDataCallBack("MoveLimitCheck", self.onMoveLimitCheck)

    self:registerDataCallBack("LotteryResult", function(data)
        self.onLotteryResult(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("LotteryRefreshResult", function(data)
        self.onLotteryRefreshResult(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("ResourceUpgrade", function(pointId)
        self.onResourceUpgrade(pointId)
    end)

    self:registerDataCallBack("PlayerIntoTeamResource", function(data)
        self.onPlayerIntoTeamResource(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("NotPlayerTeamResource", function(data)
        self.onNotPlayerIntoTeamResource(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("ShowSurvey", function()
        self.onShowSurvey()
    end)
end

function handler.onLotteryResult(data)
    local rewardId = data:getNumberParam("rewardId")
    local price = data:getNumberParam("price")
    local seq = data:getNumberParam("seq")
    GUILottery:onGetReward(rewardId, price, seq)
end

function handler.onLotteryRefreshResult(data)
    local result = data:getParam("reward")
    local refreshPrice = data:getNumberParam("refreshPrice")
    local lotteryPrice = data:getNumberParam("lotteryPrice")
    local getRewardIds = StringUtil.split(data:getParam("getRewardIds") or "", ",")
    local cardRewardId = StringUtil.split(data:getParam("cardRewardId") or "", ",")

    GUILottery:onGetRefreshResult(result, refreshPrice, lotteryPrice, getRewardIds, cardRewardId)
end

function handler.onOpenLottery()
    if GameType == "g1008" then
        local openLotteryKey = tostring(Game:getPlatformUserId()) .. "g1008_onOpenLottery"
        local value = ClientHelper.getStringForKey(openLotteryKey, "0")
        if value ~= "1" then
            ClientHelper.putStringForKey(openLotteryKey, "1")
            return
        end
    end
    GUIBedWarToolBar:onLotteryBtn()
end

function handler.onMoveLimitCheck(data)
    local builder = DataBuilder.new():fromData(data)
    ClientHelper.putIntPrefs("RunLimitCheck", builder:getNumberParam("runLimitCheck"))
    ClientHelper.putIntPrefs("SprintLimitCheck", builder:getNumberParam("sprintLimitCheck"))
end

function handler.onResourceUpgrade(pointId)
    if ResourcePointConfig == nil then
        LuaTimer:schedule(function()
            handler.onResourceUpgrade(pointId)
        end, 100)
        return
    end
    ResourcePointConfig:UpgradeResource(pointId)
end

function handler.onPlayerIntoTeamResource(data)
    local userId = data:getParam("userId")
    local pointId = data:getNumberParam("pointId")
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    ResourcePointConfig:onPlayerIntoTeamResource(player:getEntityId(), pointId)
end

function handler.onNotPlayerIntoTeamResource(data)
    local pointId = data:getNumberParam("pointId")
    ResourcePointConfig:onNotPlayerIntoResource(pointId)
end

function handler.onShowSurvey()
    if GUIBedWarSurvey then
        GUIBedWarSurvey:show(true)
    end
end

function CPacketHandlers:S2COperateExitGame(packet)
    GameInfoManager:clearInfo("PlayerInfo", packet.userId)
end

function CPacketHandlers:SyncIronConversion(packet)
    if GUIBedWarIronCompensationLayout:isShow() then
        GUIBedWarIronCompensationLayout:hide()
    end
    GUIBedWarIronCompensationLayout:show(packet.data)
end

handler:init()