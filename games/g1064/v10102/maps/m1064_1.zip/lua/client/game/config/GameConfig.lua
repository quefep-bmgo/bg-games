require "game.config.LotteryConfig"
require "common.config.BoxLotteryConfig"
require "common.config.WatchADSwitch"

GameConfig = {}

function GameConfig:loadConfig()
    local config = FileUtil.getConfigFromYml("setting/ClientConfig.yml")
    GameConfig.useNewLottery = config.useNewLottery or 1
    GameConfig.mainTabRedPoint = config.mainTabRedPoint or 5
    GameConfig.useTransparentCamera = tonumber(config.useTransparentCamera or "0") == 1
    GameConfig.specialTransparentAlpha = tonumber(config.specialTransparentAlpha) or 0.5
    GameConfig.bowSensitiveMultiplier = config.bowSensitiveMultiplier or 1
    GameConfig.bowSpeedMultiplier = config.bowSpeedMultiplier or 1
    GameConfig.bowFOVMultiplier = config.bowFOVMultiplier or 1
    GameConfig.NinjaShoesJumpHeight = config.NinjaShoesJumpHeight or 0.42
    GameConfig.hidePosGuideTime = config.hidePosGuideTime or 120
    GameConfig.minBuildBlockNum = config.minBuildBlockNum or 10
    GameConfig.leaveHomeTipTime = config.leaveHomeTipTime or 60
    GameConfig.WeakGuideTimes = config.WeakGuideTimes or 10
    GameConfig.CustomSceneLoadRadius = config.CustomSceneLoadRadius or 50
    WorldMeshRender.Instance():setRenderDistance(GameConfig.CustomSceneLoadRadius)
    GameConfig:loadGameConfig()
    WatchADSwitch:init()
    require "common.config.DressStoreConfig"

    ClientHelper.putBoolPrefs("IsTransparentCamera", GameConfig.useTransparentCamera)
    Blockman.Instance():setBlockSpecialTransparentAlpha(GameConfig.specialTransparentAlpha)
end

function GameConfig:loadGameConfig()
    LotteryConfig.loadConfig()
    GUIBoxLotteryConfig.loadBoxConfig()
    GUIBoxLotteryConfig.loadRewardConfig()
    require "common.config.PrivilegeConfig"
    require "game.config.ShopWeakGuideConfig"
    require "game.config.ShopGuideTimeRangeConfig"
    require "common.config.FastChatConfig"
    require "common.config.EmojiConfig"
    require "common.config.ArmorEffectConfig"
end