---@class GUIGameDiscountShopSelectGoodsWindow : IGUIWindow
local GUIGameDiscountShopSelectGoodsWindow = class("GUIGameDiscountShopSelectGoodsWindow", IGUIWindow)

local baseIconArea = {x = 0, y = 12, width = 110, height = 110}

local IconOffsetCfg = {
    [1] = {x = 0, y = -5, scale = 1.15},
    [2] = {x = 0, y = 5, scale = 1.1},
    [3] = {x = 0, y = 17, scale = 1},
    [4] = {x = 0, y = 20, scale = 1},
    [5] = {x = 0, y = 30, scale = 0.8},
    [6] = {x = 0, y = 30, scale = 0.8},
    [7] = {x = 0, y = 10, scale = 1.2},
    [8] = {x = 0, y = 25, scale = 0.9},
    [9] = {x = 0, y = 25, scale = 0.9},
}

---@private
function GUIGameDiscountShopSelectGoodsWindow:ctor(_, mgr)
    self.super.ctor(self, "GameDiscountShopSelectGoods.json", mgr)
end

---@private
---@param mgr CDiscountShopActivityMgr
function GUIGameDiscountShopSelectGoodsWindow:onLoad(mgr)
    self.mgr = mgr
    self.stSelectItemText = self:getChildWindowByName("GameDiscountShopSelectGoods-SelectItemText", GUIType.StaticText)
    self.siFlag = self:getChildWindowByName("GameDiscountShopSelectGoods-Flag", GUIType.StaticImage)
    self.siTag = self:getChildWindowByName("GameDiscountShopSelectGoods-Tag", GUIType.StaticImage)
    self.siOff = self:getChildWindowByName("GameDiscountShopSelectGoods-Off", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameDiscountShopSelectGoods-Image", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("GameDiscountShopSelectGoods-Effect", GUIType.StaticImage)
    self.siDiscountPriceIcon = self:getChildWindowByName("GameDiscountShopSelectGoods-DiscountPriceIcon", GUIType.StaticImage)
    self.stDiscountPrice = self:getChildWindowByName("GameDiscountShopSelectGoods-DiscountPrice", GUIType.StaticText)
    self.siRealPriceIcon = self:getChildWindowByName("GameDiscountShopSelectGoods-RealPriceIcon", GUIType.StaticImage)
    self.siMask = self:getChildWindowByName("GameDiscountShopSelectGoods-Mask", GUIType.StaticImage)
    self.stRealPrice = self:getChildWindowByName("GameDiscountShopSelectGoods-RealPrice", GUIType.StaticText)
    self.llRedLine = self:getChildWindowByName("GameDiscountShopSelectGoods-RedLine", GUIType.Layout)
    self.stItemName = self:getChildWindowByName("GameDiscountShopSelectGoods-ItemName", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameDiscountShopSelectGoodsWindow:initView()
    self.stSelectItemText:SetText(Lang:getString("gui.select.item"))
end

---@private
function GUIGameDiscountShopSelectGoodsWindow:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        self.mgr:onSelectGoods(self.data)
    end)
end

---@param data DiscountShopGoodsData
function GUIGameDiscountShopSelectGoodsWindow:onDataChanged(data, index, discount)
    self.data = data
    self.stSelectItemText:SetVisible(self.data == nil)
    self.siFlag:SetVisible(self.data ~= nil)
    self.siImage:SetVisible(self.data ~= nil)
    self.siDiscountPriceIcon:SetVisible(self.data ~= nil)
    self.siRealPriceIcon:SetVisible(self.data ~= nil)
    self.stItemName:SetText("")

    if index == 1 then
        self.siEffect:SetArea({0,-10},{0,0}, {1.65,0}, {0,166})
    elseif index == 2 then
        self.siEffect:SetArea({0,-10},{0,0}, {1.5,0}, {0,166})
    else
        self.siEffect:SetArea({0,-10},{0,0}, {1.55,0}, {0,166})
    end

    if not self.data then
        return
    end
    local detailData = self.mgr:getRandomStoreDetailData(data.id)
    self.siImage:SetImage(detailData.reward.image)
    self.stDiscountPrice:SetText(math.floor(detailData.randomStoreCfg.price * discount))
    self.stRealPrice:SetText(detailData.randomStoreCfg.price)
    self.llRedLine:SetWidth({ 0, self.stRealPrice:GetTextWidth() + 4 })
    self.stItemName:SetText(Lang:getString(detailData.reward.name))
    local offsetCfg = IconOffsetCfg[data.index] or {x = 0, y = 0, scale = 1}
    if offsetCfg then
        local posX = {0, baseIconArea.x + offsetCfg.x}
        local posy = {0, baseIconArea.y + offsetCfg.y}
        self.siImage:SetArea(posX, posy, {0, baseIconArea.width * offsetCfg.scale}, {0, baseIconArea.height * offsetCfg.scale})
    end

    if detailData.reward.needMask and detailData.reward.needMask > 0 then
        self.siMask:SetVisible(true)
    else
        self.siMask:SetVisible(false)
    end
    if discount == 0.5 then
        self.siTag:SetImage("set:game_activity_discount_store_2.json image:lbl_0_50")
    elseif discount == 0.4 then
        self.siTag:SetImage("set:game_activity_discount_store_2.json image:lbl_0_60")
    elseif discount == 0.3 then
        self.siTag:SetImage("set:game_activity_discount_store_2.json image:lbl_0_70")
    end
    if index == 1 then
        self.siFlag:SetImage("set:game_activity_discount_store_2.json image:img_0_salebd_left")
        self.siTag:SetXPosition({ 0, 0 })
        self.siOff:SetXPosition({ 0, 0 })
        self.stItemName:SetXPosition({ 0, -8 })
    elseif index == 2 then
        self.siFlag:SetImage("set:game_activity_discount_store_2.json image:img_0_salebd_center")
        self.siTag:SetXPosition({ 0, 4 })
        self.siOff:SetXPosition({ 0, 4 })
        self.siFlag:SetXPosition({ 0, -16 })
        self.stItemName:SetXPosition({ 0, -8 })
    else
        self.siFlag:SetImage("set:game_activity_discount_store_2.json image:img_0_salebd_right")
        self.siTag:SetXPosition({ 0, 4 })
        self.siOff:SetXPosition({ 0, 4 })
        self.siFlag:SetXPosition({ 0, -16 })
        self.stItemName:SetXPosition({ 0, -8 })
    end
end

return GUIGameDiscountShopSelectGoodsWindow
