---@class GUITreasureHuntWindow : IGUIWindow
local GUITreasureHuntWindow = class("GUITreasureHuntWindow", GUICommonActivityPanel)

---@private
function GUITreasureHuntWindow:ctor(...)
	self.super.ctor(self, "TreasureHunt.json", ...)
end

---@private
function GUITreasureHuntWindow:onChildLoad()
	self.siBg = self:getChildWindowByName("TreasureHunt-Bg", GUIType.StaticImage)
	self.llTip = self:getChildWindowByName("TreasureHunt-Tip", GUIType.Layout)
	self.stTipText = self:getChildWindowByName("TreasureHunt-Tip-Text", GUIType.StaticText)
	self.stTitle = self:getChildWindowByName("TreasureHunt-Title", GUIType.StaticText)

	self.btnHelp = self:getChildWindowByName("TreasureHunt-Help", GUIType.Button)

	self:initView()
	self:initEvent()
end

---@private
function GUITreasureHuntWindow:initView()
	self.stTitle:SetText(Lang:getString("gui_activity_treasure_hunt_tip"))
	self.stTipText:SetText(Lang:getString("gui_activity_treasure_hunt_title"))
end

---@private
function GUITreasureHuntWindow:initEvent()
	self.btnHelp:registerEvent(GUIEvent.ButtonClick, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("diamond.gift.help.title")
					.setContentText(Lang:getString("treasure.hunt.help.content"))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)
end

return GUITreasureHuntWindow
