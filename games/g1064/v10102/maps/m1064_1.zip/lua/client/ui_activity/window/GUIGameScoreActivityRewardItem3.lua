---@class GUIGameScoreActivityRewardItem3Window : IGUIWindow
local GUIGameScoreActivityRewardItem3Window = class("GUIGameScoreActivityRewardItem3Window", IGUIWindow)

---@private
function GUIGameScoreActivityRewardItem3Window:ctor(_, mgr)
    self.super.ctor(self, "GameScoreActivityRewardItem3.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItem3Window:onLoad(mgr)
    self.mgr = mgr
    self.stName = self:getChildWindowByName("GameScoreActivityRewardItem3-Name", GUIType.StaticText)
    self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem3-Image", GUIType.StaticImage)
    self.btnExchange = self:getChildWindowByName("GameScoreActivityRewardItem3-Exchange", GUIType.Button)
    self.ivReceived = self:getChildWindowByName("GameScoreActivityRewardItem3-Received", GUIType.StaticImage)
    self.stReceivedText = self:getChildWindowByName("GameScoreActivityRewardItem3-ReceivedText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItem3Window:initView()
    self.btnExchange:SetText(Lang:getString("gui.exchange"))
    self.stReceivedText:SetText(Lang:getString("gui_bed_war_hall_task_over"))
end

---@private
function GUIGameScoreActivityRewardItem3Window:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        GUICommonActivityRewardDetail:show(self.data.reward.showDetailId)
    end)
    self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
        local limit = self.mgr:getRewardLimit(self.data)
        if limit <= 0 then
            return
        end
        if self.mgr:getScore() < self.data.score then
            CustomDialog.builder()
                        .setContentText(Lang:getString("gui.lack.of.score." .. self.mgr.config.id))
                        .setHideLeftButton()
                        .show()
            return
        end
        self.mgr:tryGetReward(self.data.id)
    end)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityRewardItem3Window:onDataChanged(data)
    self.data = data
    self.stName:SetText(Lang:getString(data.reward.name))
    local x, y = UIHelper:getImageSize(data.reward.image, 1280, 720)
    self.siImage:SetArea({ 0, 0 }, { 0, 0 }, x, y)
    self.siImage:SetImage(data.reward.image)
    local limit = self.mgr:getRewardLimit(data)
    self.btnExchange:SetVisible(limit > 0)
    self.ivReceived:SetVisible(limit <= 0)
end

return GUIGameScoreActivityRewardItem3Window
