---@class GUIGameCardLotteryItemWindow : IGUIWindow
local GUIGameCardLotteryItemWindow = class("GUIGameCardLotteryItemWindow", IGUIWindow)
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function GUIGameCardLotteryItemWindow:ctor(...)
    self.super.ctor(self, "GameCardLotteryItem.json", ...)
end

---@private
function GUIGameCardLotteryItemWindow:onLoad()
    self.siBackOpen = self:getChildWindowByName("GameCardLotteryItem-BackOpen", GUIType.StaticImage)
    self.siIconBg = self:getChildWindowByName("GameCardLotteryItem-Icon-Bg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("GameCardLotteryItem-Icon", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("GameCardLotteryItem-Name", GUIType.StaticText)
    self.siBack = self:getChildWindowByName("GameCardLotteryItem-Back", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameCardLotteryItem-Price", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("GameCardLotteryItem-Price-Icon", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameCardLotteryItemWindow:initView()
    self.stName:SetText("")
    self.siBackOpen:SetVisible(false)
    self.siBack:SetVisible(false)
end

---@private
function GUIGameCardLotteryItemWindow:initEvent()

end

---@param reward CommonActivityRewardData
function GUIGameCardLotteryItemWindow:setReward(reward)
    self.reward = reward
    if self.isLotteryAnim then
        return
    end
    local showDetail = RewardItemShowDetailConfig:getConfigById(reward.showDetailId)
    if not showDetail then
        return
    end
    self.siIcon:SetImage(showDetail.image)
    self.stName:SetText(Lang:getString(showDetail.name))
    self.siBack:SetVisible(false)
    self.siBackOpen:SetVisible(true)
end

---@param price CardPriceData
function GUIGameCardLotteryItemWindow:setPrice(price)
    if self.reward then
        return
    end
    self.siBack:SetVisible(true)
    self.siBackOpen:SetVisible(false)
    self.stPrice:SetText(price.price)
    self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(price.moneyType))
end

function GUIGameCardLotteryItemWindow:startLotteryAnim()
    self.isLotteryAnim = true
    self.stPrice:SetVisible(false)
    self.siBackOpen:SetVisible(false)
    local sizeW = 1
    self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
        sizeW = sizeW - 0.1
        self.siBack:SetWidth({ sizeW, 0 })
    end, function()
        self.siBack:SetVisible(false)
        self.siBackOpen:SetWidth({ sizeW, 0 })
        self.siBackOpen:SetVisible(true)
        self.stName:SetVisible(false)
        self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
            sizeW = sizeW + 0.1
            self.siBackOpen:SetWidth({ sizeW, 0 })
            self.isLotteryAnim = false
            if self.reward then
                self:setReward(self.reward)
            end
        end, function()
            self.stName:SetVisible(true)
        end, 1, 10))
    end, 1, 10))
end

return GUIGameCardLotteryItemWindow
