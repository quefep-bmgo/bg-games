---@class GUIGameScoreActivityRewardItem5Window : IGUIWindow
local GUIGameScoreActivityRewardItem5Window = class("GUIGameScoreActivityRewardItem5Window", IGUIWindow)
---@type CustomGoodsTicketConfig
local CustomGoodsTicketConfig = T(Global, "CustomGoodsTicketConfig")

---@private
function GUIGameScoreActivityRewardItem5Window:ctor(_, mgr)
    self.super.ctor(self, "GameScoreActivityRewardItem5.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItem5Window:onLoad(mgr)
    self.mgr = mgr
    self.siBg = self:getChildWindowByName("GameScoreActivityRewardItem5", GUIType.Layout)
    self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem5-Image", GUIType.StaticImage)
    self.siLimitIcon = self:getChildWindowByName("GameScoreActivityRewardItem5-LimitIcon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("GameScoreActivityRewardItem5-Limit", GUIType.StaticText)
    self.stCount = self:getChildWindowByName("GameScoreActivityRewardItem5-Count", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("GameScoreActivityRewardItem5-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameScoreActivityRewardItem5-Price", GUIType.StaticText)
    self.llMask = self:getChildWindowByName("GameScoreActivityRewardItem5-Mask", GUIType.StaticImage)
    self.siSelected = self:getChildWindowByName("GameScoreActivityRewardItem5-Selected", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItem5Window:initView()

end

---@private
function GUIGameScoreActivityRewardItem5Window:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if not self.data then
            return
        end
        Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
    end)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityRewardItem5Window:onDataChanged(data)
    self.data = data
    self.siImage:SetImage(data.reward.image)
    if data.reward.imageYOffset ~= "#" then
        self.siImage:SetYPosition({0, data.reward.imageYOffset})
    end
    if data.reward.numLang ~= "#" then
        self.stCount:SetText("x" .. Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    if data.price > 0 then
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
        self.stPrice:SetText(data.price)
    else
        self.stPrice:SetText(data.score)
    end
    if data.limit <= 0 then
        self.siLimitIcon:SetVisible(false)
    else
        self.siLimitIcon:SetVisible(data.limit > 1)
        local limit = self.mgr:getRewardLimit(data)
        if limit > 0 then
            self.stLimit:SetText(limit .. "/" .. data.limit)
            self.llMask:SetVisible(false)
        else
            self.llMask:SetVisible(true)
            self.stLimit:SetText(TextFormat.colorRed .. "0" .. TextFormat.colorWrite .. "/" .. data.limit)
        end
        --self.siLimitIcon:SetXPosition({ 0, -self.stLimit:GetTextWidth() - 25 })
    end
    self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)
    self:onSetTag()
    if not self.first then
        self.first = true
        if data.isGrandPrize then
            Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
        end
    end
end

function GUIGameScoreActivityRewardItem5Window:onSetTag()
    if self.llTag then
        self.llTag.root:SetVisible(false)
    end
    local reward = self.data.reward
    if reward.type ~= "RewardSetting" then
        return
    end
    local realReward = RewardConfig:getRewardById(reward.realId)
    if not realReward or realReward.RewardType ~= Define.RewardType.CustomGoodsTicket then
        return
    end
    local item = CustomGoodsTicketConfig:getTicketConfig(realReward.RewardId)
    if item then
        if not self.llTag then
            ---@type GUIBedWarItemTagWindow
            self.llTag = UIHelper.newGameGUIWindow("GUIBedWarItemTag", "BedWarItemTag.json")
            self.llTag.root:SetArea({0, 5}, {0, 5}, {0, 82}, {0, 32})
            self.root:AddChildWindow(self.llTag.root)
        end
        self.llTag.root:SetVisible(true)
        self.llTag:onDataChanged({
            bg = "set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(item.level),
            text = item.day .. Lang:getString("gui.day")
        })
    end
end

return GUIGameScoreActivityRewardItem5Window
