---@class GUIGameScoreActivityRewardItem4Window : IGUIWindow
local GUIGameScoreActivityRewardItem4Window = class("GUIGameScoreActivityRewardItem4Window", IGUIWindow)

---@private
function GUIGameScoreActivityRewardItem4Window:ctor(_, mgr)
    self.super.ctor(self, "GameScoreActivityRewardItem4.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItem4Window:onLoad(mgr)
    self.mgr = mgr
    self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem4-Image", GUIType.StaticImage)
    self.siLimitIcon = self:getChildWindowByName("GameScoreActivityRewardItem4-LimitIcon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("GameScoreActivityRewardItem4-Limit", GUIType.StaticText)
    self.stCount = self:getChildWindowByName("GameScoreActivityRewardItem4-Count", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("GameScoreActivityRewardItem4-Score", GUIType.StaticText)
    self.stPriceAdd = self:getChildWindowByName("GameScoreActivityRewardItem4-Add", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("GameScoreActivityRewardItem4-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameScoreActivityRewardItem4-Price", GUIType.StaticText)
    self.llMask = self:getChildWindowByName("GameScoreActivityRewardItem4-Mask", GUIType.StaticImage)
    self.siSelected = self:getChildWindowByName("GameScoreActivityRewardItem4-Selected", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItem4Window:initView()
    self.stPriceAdd:SetText("+")
end

---@private
function GUIGameScoreActivityRewardItem4Window:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if not self.data then
            return
        end
        Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
    end)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityRewardItem4Window:onDataChanged(data)
    self.data = data
    self.siImage:SetImage(data.reward.image)
    if data.reward.numLang ~= "#" then
        self.stCount:SetText("x" .. Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    self.stScore:SetText(data.score)
    if data.price <= 0 then
        self.siPriceIcon:SetVisible(false)
        self.stPriceAdd:SetVisible(false)
    else
        self.stPriceAdd:SetVisible(true)
        self.siPriceIcon:SetVisible(true)
        local width = self.stScore:GetTextWidth()
        self.stPriceAdd:SetXPosition({ 0, 47 + width })
        self.siPriceIcon:SetXPosition({ 0, 67 + width })
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
        self.stPrice:SetText(data.price)
    end
    if data.limit <= 0 then
        self.siLimitIcon:SetVisible(false)
    else
        self.siLimitIcon:SetVisible(data.limit > 1)
        local limit = self.mgr:getRewardLimit(data)
        if limit > 0 then
            self.stLimit:SetText(limit .. "/" .. data.limit)
            self.llMask:SetVisible(false)
        else
            self.llMask:SetVisible(true)
            self.stLimit:SetText(TextFormat.colorRed .. "0" .. TextFormat.colorWrite .. "/" .. data.limit)
        end
        self.siLimitIcon:SetXPosition({ 0, -self.stLimit:GetTextWidth() - 25 })
    end
    self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)
end

return GUIGameScoreActivityRewardItem4Window
