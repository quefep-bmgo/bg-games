---@class GUIGameScoreActivityRewardItem9Window : IGUIWindow
local GUIGameScoreActivityRewardItem9Window = class("GUIGameScoreActivityRewardItem9Window", IGUIWindow)

local QualityBgImage = {
    [1] = "set:game_activity_score_9.json image:img_0_itembd_blue",
    [2] = "set:game_activity_score_9.json image:img_0_itembd_purple",
    [3] = "set:game_activity_score_9.json image:img_0_itembd_yellow",
}

---@private
function GUIGameScoreActivityRewardItem9Window:ctor(_, mgr)
    self.super.ctor(self, "GameScoreActivityRewardItem9.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItem9Window:onLoad(mgr)
    self.mgr = mgr
    self.siBg = self:getChildWindowByName("GameScoreActivityRewardItem9", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem9-Image", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("GameScoreActivityRewardItem9-Count", GUIType.StaticText)
    self.siLimitIcon = self:getChildWindowByName("GameScoreActivityRewardItem9-LimitIcon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("GameScoreActivityRewardItem9-Limit", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("GameScoreActivityRewardItem9-Score", GUIType.StaticText)
    self.stPriceAdd = self:getChildWindowByName("GameScoreActivityRewardItem9-Add", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("GameScoreActivityRewardItem9-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameScoreActivityRewardItem9-Price", GUIType.StaticText)
    self.llMask = self:getChildWindowByName("GameScoreActivityRewardItem9-Mask", GUIType.Layout)
    self.siSelected = self:getChildWindowByName("GameScoreActivityRewardItem9-Selected", GUIType.StaticImage)
    self.siTag = self:getChildWindowByName("GameScoreActivityRewardItem9-Tag", GUIType.StaticImage)
    self.stDay = self:getChildWindowByName("GameScoreActivityRewardItem9-Day", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItem9Window:initView()
    self.stPriceAdd:SetText("+")
end

---@private
function GUIGameScoreActivityRewardItem9Window:initEvent()
    self.siBg:registerEvent(GUIEvent.Click, function()
        if not self.data then
            return
        end
        Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
    end)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityRewardItem9Window:onDataChanged(data)
    self.data = data
    self.siImage:SetImage(data.reward.image)
    if data.reward.numLang ~= "#" then
        self.stCount:SetText("x" .. Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    self.stScore:SetText(data.score)
    if data.price <= 0 then
        self.siPriceIcon:SetVisible(false)
        self.stPriceAdd:SetVisible(false)
    else
        self.stPriceAdd:SetVisible(true)
        self.siPriceIcon:SetVisible(true)
        local width = self.stScore:GetTextWidth()
        self.stPriceAdd:SetXPosition({ 0, 32 + width })
        self.siPriceIcon:SetXPosition({ 0, 52 + width })
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
        self.stPrice:SetText(data.price)
    end
    if data.limit <= 0 then
        self.siLimitIcon:SetVisible(false)
    else
        self.siLimitIcon:SetVisible(data.limit > 1)
        local limit = self.mgr:getRewardLimit(data)
        if limit > 0 then
            self.stLimit:SetText(limit .. "/" .. data.limit)
            self.llMask:SetVisible(false)
        else
            self.llMask:SetVisible(true)
            self.stLimit:SetText(TextFormat.colorRed .. "0" .. TextFormat.colorWrite .. "/" .. data.limit)
        end
        self.siLimitIcon:SetXPosition({ 0, -self.stLimit:GetTextWidth() - 8 })
    end
    self.siBg:SetImage(QualityBgImage[self.data.quality] or QualityBgImage[1])
    self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)

    local reward = RewardConfig:getRewardById(data.reward.realId)
    self.siTag:SetVisible(false)
    if reward and reward.RewardType == Define.RewardType.CustomGoodsTicket then
        ---@type CustomGoodsTicketConfig
        local CustomGoodsTicketConfig = T(Global, "CustomGoodsTicketConfig")
        local item = CustomGoodsTicketConfig:getTicketConfig(reward.RewardId)
        if item then
            self.siTag:SetVisible(true)
            self.siTag:SetImage("set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(item.level))
            self.stDay:SetText(item.day .. Lang:getString("gui.day"))
        end
    end
end

return GUIGameScoreActivityRewardItem9Window
