---@class GUIActivityRewardItemWindow : IGUIWindow
local GUIActivityRewardItemWindow = class("GUIActivityRewardItemWindow", IGUIWindow)

---@type CustomGoodsTicketConfig
local CustomGoodsTicketConfig = T(Global, "CustomGoodsTicketConfig")
---@private
function GUIActivityRewardItemWindow:ctor(...)
    self.super.ctor(self, "ActivityRewardItem.json", ...)
end

---@private
function GUIActivityRewardItemWindow:onLoad()
    self.root:SetVerticalAlignment(VerticalAlignment.Center)
    self.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.siBg = self:getChildWindowByName("ActivityRewardItem-Bg", GUIType.StaticImage)
    self.siLight = self:getChildWindowByName("ActivityRewardItem-Light", GUIType.StaticImage)
    self.siItemImage = self:getChildWindowByName("ActivityRewardItem-Item-Image", GUIType.StaticImage)
    self.stItemName = self:getChildWindowByName("ActivityRewardItem-Item-Name", GUIType.StaticText)
    self.stCount = self:getChildWindowByName("ActivityRewardItem-Count", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIActivityRewardItemWindow:initView()

end

---@private
function GUIActivityRewardItemWindow:initEvent()

end

---@param data table
function GUIActivityRewardItemWindow:onDataChanged(data)

end

---@param reward CommonActivityRewardData
function GUIActivityRewardItemWindow:onSetTag(reward)
    if self.llTag then
        self.llTag.root:SetVisible(false)
    end
    if reward.type ~= "RewardSetting" then
        return
    end
    local realReward = RewardConfig:getRewardById(reward.realId)
    if not realReward or realReward.RewardType ~= Define.RewardType.CustomGoodsTicket then
        return
    end
    local item = CustomGoodsTicketConfig:getTicketConfig(realReward.RewardId)
    if item then
        if not self.llTag then
            ---@type GUIBedWarItemTagWindow
            self.llTag = UIHelper.newGameGUIWindow("GUIBedWarItemTag", "BedWarItemTag.json")
            self.siItemImage:AddChildWindow(self.llTag.root)
        end
        self.llTag.root:SetVisible(true)
        self.llTag:onDataChanged({
            bg = "set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(item.level),
            text = item.day .. Lang:getString("gui.day")
        })
    end
end

return GUIActivityRewardItemWindow
