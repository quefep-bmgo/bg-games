---@class GUIGameActivityDirectSaleItemWindow : IGUIWindow
local GUIGameActivityDirectSaleItemWindow = class("GUIGameActivityDirectSaleItemWindow", IGUIWindow)

---@private
function GUIGameActivityDirectSaleItemWindow:ctor(...)
	self.super.ctor(self, "GameActivityDirectSaleItem.json", ...)
end

---@private
function GUIGameActivityDirectSaleItemWindow:onLoad()
	self.siBg = self:getChildWindowByName("GameActivityDirectSaleItem-Bg", GUIType.StaticImage)
	self.siIcon = self:getChildWindowByName("GameActivityDirectSaleItem-Icon", GUIType.StaticImage)
	self.siEffect = self:getChildWindowByName("GameActivityDirectSaleItem-Effect", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameActivityDirectSaleItemWindow:initView()

end

---@private
function GUIGameActivityDirectSaleItemWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		self.parent:clickItem(self)
	end)
end

---@param data table
function GUIGameActivityDirectSaleItemWindow:onDataChanged(data)
	self.parent = data.parent
	self.reward = data.reward
	local image = self.reward.image
	self.siIcon:SetImage(image)
end

return GUIGameActivityDirectSaleItemWindow
