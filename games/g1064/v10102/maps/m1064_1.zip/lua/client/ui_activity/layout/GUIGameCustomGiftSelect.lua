---@class UIGameCustomGiftSelectLayout : IGUILayout
local UIGameCustomGiftSelectLayout = class("UIGameCustomGiftSelectLayout", IGUILayout)
---@type GUIGameCustomGiftPoolItemWindow
local GUIGameCustomGiftPoolItem = UIHelper.requireGUIWindow("GUIGameCustomGiftPoolItem", false, "ui_activity")

local ItemHeight = 87
local ItemSpace = 10

---@private
function UIGameCustomGiftSelectLayout:ctor(parent)
	self.super.ctor(self, "GameCustomGiftSelect.json", parent)
end

---@private
function UIGameCustomGiftSelectLayout:isDelayLoad()
	return true
end

---@private
function UIGameCustomGiftSelectLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGameCustomGiftSelectLayout:initCreateEvent()

end

---@private
function UIGameCustomGiftSelectLayout:onLoad()
	self.siCloseBg = self:getChildWindow("GameCustomGiftSelect-Close-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("GameCustomGiftSelect-Content", GUIType.Layout)
	self.stTop = self:getChildWindow("GameCustomGiftSelect-Top", GUIType.StaticText)
	self.btnClose = self:getChildWindow("GameCustomGiftSelect-Close", GUIType.Button)
	self.btnSureBtn = self:getChildWindow("GameCustomGiftSelect-SureBtn", GUIType.Button)
	self.stTopTips = self:getChildWindow("GameCustomGiftSelect-TopTips", GUIType.StaticText)
	self.llListContent = self:getChildWindow("GameCustomGiftSelect-ListContent", GUIType.Layout)
	self.siSelectBg = self:getChildWindow("GameCustomGiftSelect-SelectBg", GUIType.StaticImage)
	self.stSelectTitle = self:getChildWindow("GameCustomGiftSelect-SelectTitle", GUIType.StaticText)
	self.siPoolBg = self:getChildWindow("GameCustomGiftSelect-PoolBg", GUIType.StaticImage)
	self.stPoolTitle = self:getChildWindow("GameCustomGiftSelect-PoolTitle", GUIType.StaticText)
	self.ltItemList = self:getChildWindow("GameCustomGiftSelect-ItemList", GUIType.List)
	self.ltItemList:SetInterval(ItemSpace)
	self:initView()
	self:initEvent()
end

---@private
function UIGameCustomGiftSelectLayout:initView()
	self.stTop:SetText(Lang:getString("gui.activity.custom.gift.edit.title"))
	self.stTopTips:SetText(Lang:getString("gui.activity.custom.gift.edit.tips"))
	self.stSelectTitle:SetText(Lang:getString("gui.activity.custom.gift.edit.my.select"))
	self.stPoolTitle:SetText(Lang:getString("gui.activity.custom.gift.edit.pool"))
	self.btnSureBtn:SetText(Lang:getString("gui.sure"))
end

---@private
function UIGameCustomGiftSelectLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self.mgr:clearCacheChooseResult()
		self:hide()
	end)

	self.btnSureBtn:registerEvent(GUIEvent.ButtonClick, function()
		self.mgr:submitChooseResult()
		self:hide()
	end)
end

function UIGameCustomGiftSelectLayout:initPoolList()
	local rewardCount = #self.giftConfig.rewardCellList
	local contentListHeight = math.min(rewardCount * ItemHeight + ItemSpace * (rewardCount - 1) + 40, 420)
	local listParentHeight = math.min(contentListHeight + 230, 650)
	self.llListContent:SetHeight({0, contentListHeight})
	self.llContent:SetHeight({0, listParentHeight})

	for _, cellId in ipairs(self.giftConfig.rewardCellList) do
		local item = GUIGameCustomGiftPoolItem.new(self.mgr)
		item:setData(self.giftConfig.id, cellId)
		self.ltItemList:AddItem(item.root)
	end
end

function UIGameCustomGiftSelectLayout:onShow(giftConfig, mgr)
	self.giftConfig = giftConfig
	self.mgr = mgr
	self:initPoolList()
end

return UIGameCustomGiftSelectLayout
