---@class GUIGameBlindBoxRewardItemWindow : IGUIWindow
local GUIGameBlindBoxRewardItemWindow = class("GUIGameBlindBoxRewardItemWindow", IGUIWindow)

---@type EventUtil
local EventUtil = T(Global, "EventUtil")

---@private
function GUIGameBlindBoxRewardItemWindow:ctor(...)
    self.super.ctor(self, ...)
end

---@private
---@param mgr CBlindBoxMgr
function GUIGameBlindBoxRewardItemWindow:onLoad(mgr, ...)
    self.mgr = mgr

    self.eventList = {}
    self.eventList[#self.eventList + 1] = self.mgr:registerEvent("mainDataCacheChange", function()
        if self.stopUpdateStatus then
            return
        end
        self:onChangeRewardStatus()
    end)

    self.eventList[#self.eventList + 1] = self.mgr:registerEvent("setCanUpdateRewardStatus", function(flag)
        self.stopUpdateStatus = not flag
    end)

    self.siIcon = self:getChildWindowByName("GameBlindBoxRewardItem-Icon", GUIType.StaticImage)
    self.siHas = self:getChildWindowByName("GameBlindBoxRewardItem-Has", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameBlindBoxRewardItemWindow:initView()
    self:showHas(false)
end

function GUIGameBlindBoxRewardItemWindow:showHas(flag)
    if self.siHas:IsVisible() ~= flag then
        self.siHas:SetVisible(flag)
    end
end

---@private
function GUIGameBlindBoxRewardItemWindow:initEvent()

end

function GUIGameBlindBoxRewardItemWindow:onChangeRewardStatus()
    if self.mgr:isGetReward(self.reward) then
        self:showHas(true)
        self.siIcon:SetDrawColor({0.5, 0.5, 0.5, 1})
    else
        self:showHas(false)
        self.siIcon:SetDrawColor({1, 1, 1, 1})
    end
end

---@param reward CommonActivityRewardWeightData
function GUIGameBlindBoxRewardItemWindow:onDataChanged(reward)
    self:setReward(reward.reward)

    if self.mgr:isGetReward(reward.reward) then
        self:showHas(true)
        self.siIcon:SetDrawColor({0.5, 0.5, 0.5, 1})
    else
        self:showHas(false)
        self.siIcon:SetDrawColor({1, 1, 1, 1})
    end
end

---@param reward CommonActivityRewardData
function GUIGameBlindBoxRewardItemWindow:setReward(reward)
    self.reward = reward
    self.siIcon:SetImage(reward.image)
end

function GUIGameBlindBoxRewardItemWindow:onDestroy()
    for i, event in pairs(self.eventList) do
        event()
    end
    self.eventList = {}
end

return GUIGameBlindBoxRewardItemWindow
