---@class GUIGameCustomGiftCellWindow : IGUIWindow
local GUIGameCustomGiftCellWindow = class("GUIGameCustomGiftCellWindow", IGUIWindow)

---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

---@private
function GUIGameCustomGiftCellWindow:ctor(...)
	self.super.ctor(self, "GameCustomGiftCell.json", ...)
end

---@private
function GUIGameCustomGiftCellWindow:onLoad(mgr)
	self.mgr = mgr
	self.llRewardContent = self:getChildWindowByName("GameCustomGiftCell-RewardContent", GUIType.Layout)
	self.siBg = self:getChildWindowByName("GameCustomGiftCell-Bg", GUIType.StaticImage)
	self.siIcon = self:getChildWindowByName("GameCustomGiftCell-Icon", GUIType.StaticImage)
	self.siMask = self:getChildWindowByName("GameCustomGiftCell-Mask", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("GameCustomGiftCell-Num", GUIType.StaticText)
	self.stName = self:getChildWindowByName("GameCustomGiftCell-Name", GUIType.StaticText)
	self.siTag = self:getChildWindowByName("GameCustomGiftCell-Tag", GUIType.StaticImage)
	self.stTagTime = self:getChildWindowByName("GameCustomGiftCell-Tag-Time", GUIType.StaticText)
	self.siAddReward = self:getChildWindowByName("GameCustomGiftCell-AddReward", GUIType.StaticImage)
	self.btnClickArea = self:getChildWindowByName("GameCustomGiftCell-ClickArea", GUIType.Button)
	self.siAnimImg = self:getChildWindowByName("GameCustomGiftCell-AnimImg", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameCustomGiftCellWindow:initView()
end

---@private
function GUIGameCustomGiftCellWindow:initEvent()
	self.eventList = {}

	self.btnClickArea:registerEvent(GUIEvent.ButtonClick, function()
		if self.mgr:isGiftBuyLimit(self.giftConfig.id) then
			CustomDialog.builder()
						.setContentText(Lang:getString("gui.activity.custom.gift.soldout"))
						.setHideLeftButton()
						.show()
			return
		end
		UIGameCustomGiftSelectLayout:show(self.giftConfig, self.mgr)
	end)

	self.eventList[#self.eventList + 1] = self.mgr:registerEvent("CustomGiftRefreshReward", function(chooseChangeData)
		if self.giftConfig.id == chooseChangeData.giftId then
			local changeCellIndex = chooseChangeData.cellIndexMap[self.cellId]
			if changeCellIndex then
				self:refreshCellRewardData(self.giftConfig.id, self.cellId, changeCellIndex)
			end
		end
	end)
end

function GUIGameCustomGiftCellWindow:refreshCellRewardData(giftId, cellId, index)
	local rewardData = self.mgr:getGiftCellChooseRewardData(giftId, cellId, index)
	if rewardData and next(rewardData) then
		self.llRewardContent:SetVisible(true)
		self.siAddReward:SetVisible(false)
		if not self.commonRewardItem then
			self.commonRewardItem = GUIGameActivityRewardItem.new()
			self.llRewardContent:AddChildWindow(self.commonRewardItem.root)
			self.commonRewardItem.root:SetWidth({1, 0})
			self.commonRewardItem.root:SetHeight({1, 0})
		end
		local rewardCfg = TableUtil.copyTable(CommonActivityConfig:getRewardById(rewardData.rewardId))
		rewardCfg.num = rewardData.num
		local showNum = tonumber(rewardCfg.numLang)
		if showNum then
			rewardCfg.numLang = tostring(rewardData.num)
		end
		self.commonRewardItem:setRewardData(rewardCfg)
		self.commonRewardItem:SetUpEffect(rewardCfg.upProbability)
	else
		self:playAddTipsAnim()
		self.llRewardContent:SetVisible(false)
		self.siAddReward:SetVisible(true)
	end
end

function GUIGameCustomGiftCellWindow:line_lerp(val, targetVal, t)
	if t <= 0 then
		return val
	elseif t >= 1 then
		return targetVal
	end
	return val + (targetVal - val) * t
end

function GUIGameCustomGiftCellWindow:playAddTipsAnim()
	if self.animTimer then
		LuaTimer:cancel(self.animTimer)
	end
	local pingpong = 1
	local startAlpha = 1
	local endAlpha = 0.5
	local curAlpha = startAlpha
	local offset = 1 / 40
	local dt = 0
	self.animTimer = self:addTimer(LuaTimer:scheduleTicker(function()
		dt = dt + offset
		if pingpong % 2 == 1 then
			curAlpha = self:line_lerp(curAlpha, endAlpha, dt)
		else
			curAlpha = self:line_lerp(curAlpha, startAlpha, dt)
		end
		self.siAnimImg:SetAlpha(curAlpha)
		if dt >= 1 then
			pingpong = pingpong + 1
			dt = 0
		end
	end, 1, -1))
end

---@param data table
function GUIGameCustomGiftCellWindow:setData(cellId, giftConfig)
	self.cellId = cellId
	self.giftConfig = giftConfig
	self:refreshCellRewardData(self.giftConfig.id, self.cellId)
end

function GUIGameCustomGiftCellWindow:onDestroy()
	for _, event in pairs(self.eventList) do
		event()
	end
	self.eventList = {}
end

return GUIGameCustomGiftCellWindow
