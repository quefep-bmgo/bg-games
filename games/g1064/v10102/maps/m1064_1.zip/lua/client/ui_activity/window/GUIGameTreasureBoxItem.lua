---@class GUIGameTreasureBoxItem1Window : IGUIWindow
local GUIGameTreasureBoxItem1Window = class("GUIGameTreasureBoxItem1Window", IGUIWindow)

---@type TreasureBoxConfig
local TreasureBoxConfig = Plugins.Require("activity", "common.config.TreasureBoxConfig")

---@private
function GUIGameTreasureBoxItem1Window:ctor(...)
    self.super.ctor(self, "GameTreasureBoxItem1.json", ...)
end

---@private
function GUIGameTreasureBoxItem1Window:onLoad()
    self.siFreeIcon = self:getChildWindowByName("GameTreasureBoxItem1-FreeIcon", GUIType.StaticImage)
    self.siFreeBoxEffect = self:getChildWindowByName("GameTreasureBoxItem1-FreeBoxEffect", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("GameTreasureBoxItem1-Icon", GUIType.StaticImage)
    self.siLock = self:getChildWindowByName("GameTreasureBoxItem1-Lock", GUIType.StaticImage)
    self.siBoxEffect = self:getChildWindowByName("GameTreasureBoxItem1-BoxEffect", GUIType.StaticImage)

    self:initView()
    self:initEvent()
end

---@private
function GUIGameTreasureBoxItem1Window:initView()

end

---@private
function GUIGameTreasureBoxItem1Window:initEvent()
    self.siFreeIcon:registerEvent(GUIEvent.Click, function()
        if self.freeBoxData and self.freeBoxData.status > 0 then
            if not self.freeBoxData.haveUse then
                self.mgr:onUseBox(self.index, "free")
            else
                local boxItem = TreasureBoxConfig:getBoxItem(self.freeBoxData.boxId)
                GUIBoxDetail:showDetail(boxItem.boxSettingId)
            end
        end
    end)
    self.siIcon:registerEvent(GUIEvent.Click, function()
        if self.boxData and self.boxData.status > 0 then
            local boxItem = TreasureBoxConfig:getBoxItem(self.boxData.boxId)
            local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
            if cache.haveBuy then
                if not self.boxData.haveUse then
                    self.mgr:onUseBox(self.index)
                else
                    GUIBoxDetail:showDetail(boxItem.boxSettingId)
                end
            else
                GUIBoxDetail:showDetail(boxItem.boxSettingId)
            end
        end
    end)
end

---@param mgr CTreasureBoxMgr
---@param boxData TreasureBoxItemDBData
function GUIGameTreasureBoxItem1Window:onDataChanged(mgr, index)
    local cache = mgr:getPlayerCache(PlayerManager:getClientPlayer())
    if not cache.boxList[index] then
        return
    end
    self.mgr = mgr
    self.boxData = cache.boxList[index]
    self.freeBoxData = cache.freeBoxList[index]
    self.index = index
    local boxCfg = TreasureBoxConfig:getBoxItem(self.boxData.boxId)
    if self.boxData.status == 0 then
        self.siBoxEffect:SetVisible(false)
        self.siIcon:SetImage("")
    elseif self.boxData.status == 1 then
        if cache.haveBuy then
            self.siBoxEffect:SetVisible(true)
            self.siBoxEffect:SetEffectName(boxCfg.openTipEffect)
            self.siIcon:SetImage("")
            if self.boxData.boxId == 1 then
                self.siBoxEffect:SetYPosition({0, -80})
            else
                self.siBoxEffect:SetYPosition({0, -90})
            end
        else
            self.siBoxEffect:SetVisible(false)
            self.siIcon:SetImage(boxCfg.normalImage)
        end
    else
        self.siBoxEffect:SetVisible(false)
        self.siIcon:SetImage(boxCfg.openImage)
    end
    self.siLock:SetVisible(self.boxData.status ~= 0 and not cache.haveBuy)

    local freeBoxCfg = TreasureBoxConfig:getBoxItem(self.freeBoxData.boxId)
    if self.freeBoxData.status == 0 then
        self.siFreeBoxEffect:SetVisible(false)
        self.siFreeIcon:SetImage("")
    elseif self.freeBoxData.status == 1 then
        self.siFreeBoxEffect:SetVisible(true)
        self.siFreeBoxEffect:SetEffectName(freeBoxCfg.openTipEffect)
        self.siFreeIcon:SetImage("")
    else
        self.siFreeBoxEffect:SetVisible(false)
        self.siFreeIcon:SetImage(freeBoxCfg.openImage)
    end
end

return GUIGameTreasureBoxItem1Window
