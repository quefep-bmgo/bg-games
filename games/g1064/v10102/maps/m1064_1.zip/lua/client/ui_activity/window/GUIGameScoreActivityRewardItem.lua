---@class GUIGameScoreActivityRewardItemWindow : IGUIWindow
local GUIGameScoreActivityRewardItemWindow = class("GUIGameScoreActivityRewardItemWindow", IGUIWindow)

---@private
function GUIGameScoreActivityRewardItemWindow:ctor(_, mgr)
    self.super.ctor(self, "GameScoreActivityRewardItem.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItemWindow:onLoad(mgr)
    self.mgr = mgr
    self.siBg = self:getChildWindowByName("GameScoreActivityRewardItem-Bg", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem-Image", GUIType.StaticImage)
    self.siTag = self:getChildWindowByName("GameScoreActivityRewardItem-Tag", GUIType.StaticImage)
    self.stDay = self:getChildWindowByName("GameScoreActivityRewardItem-Day", GUIType.StaticText)
    self.stCount = self:getChildWindowByName("GameScoreActivityRewardItem-Count", GUIType.StaticText)
    self.siEffect = self:getChildWindowByName("GameScoreActivityRewardItem-Effect", GUIType.StaticImage)
    self.siMask = self:getChildWindowByName("GameScoreActivityRewardItem-Mask", GUIType.StaticImage)
    self.siSuperReward = self:getChildWindowByName("GameScoreActivityRewardItem-SuperReward", GUIType.StaticImage)
    self.siSelected = self:getChildWindowByName("GameScoreActivityRewardItem-Selected", GUIType.StaticImage)
    self.siScoreBg = self:getChildWindowByName("GameScoreActivityRewardItem-Score-Bg", GUIType.StaticImage)
    self.stScore = self:getChildWindowByName("GameScoreActivityRewardItem-Score", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItemWindow:initView()

end

---@private
function GUIGameScoreActivityRewardItemWindow:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        if not self.data then
            return
        end
        local score = self.mgr:getScore()
        if score >= self.data.score then
            if self.mgr:isRewardReceived(self.data.id) then
                Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
            else
                self.mgr:tryGetReward(self.data.id)
            end
        else
            Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
        end
    end)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityRewardItemWindow:onDataChanged(data)
    if not data.reward then
        self.data = nil
        self.root:SetVisible(false)
        return
    end
    self.data = data
    self.siImage:SetImage(data.reward.image)
    if data.reward.numLang ~= "#" then
        self.stCount:SetText(Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    local reward = RewardConfig:getRewardById(data.reward.realId)
    self.siTag:SetVisible(false)
    if reward and reward.RewardType == Define.RewardType.CustomGoodsTicket then
        ---@type CustomGoodsTicketConfig
        local CustomGoodsTicketConfig = T(Global, "CustomGoodsTicketConfig")
        local item = CustomGoodsTicketConfig:getTicketConfig(reward.RewardId)
        if item then
            self.siTag:SetVisible(true)
            self.siTag:SetImage("set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(item.level))
            self.stDay:SetText(item.day .. Lang:getString("gui.day"))
        end
    end
    if self.mgr:isRewardReceived(data.id) then
        self.siMask:SetVisible(true)
        self.siEffect:SetVisible(false)
    else
        self.siMask:SetVisible(false)
        self.siEffect:SetVisible(self.mgr:getScore() >= data.score)
    end
    if self.mgr:getScore() >= data.score then
        self.siScoreBg:SetImage("set:game_activity_score_1.json image:img_0_bardot_get")
        self.stScore:SetText("▢FF77320D" .. data.score)
    else
        self.siScoreBg:SetImage("set:game_activity_score_1.json image:img_0_bardot_normal")
        self.stScore:SetText("▢FFFFEBCC" .. data.score)
    end
    if data.isGrandPrize then
        self.siEffect:SetEffectName("g1008_effect_ui_shenzhuan_1.effect")
        self.siBg:SetImage("set:game_activity_score_1.json image:img_0_itembd_yellow")
    else
        self.siEffect:SetEffectName("g1008_effect_ui_shenzhuan_2.effect")
        self.siBg:SetImage("set:game_activity_score_1.json image:img_0_itembd_blue")
    end
    self.siSuperReward:SetVisible(data.quality>=3)
    self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)
end

return GUIGameScoreActivityRewardItemWindow
