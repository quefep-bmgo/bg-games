---@class GUIGameCustomGiftPoolSelectItemWindow : IGUIWindow
local GUIGameCustomGiftPoolSelectItemWindow = class("GUIGameCustomGiftPoolSelectItemWindow", IGUIWindow)

---@type CustomGiftConfig
local CustomGiftConfig = T(Global, "CustomGiftConfig")
---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

---@private
function GUIGameCustomGiftPoolSelectItemWindow:ctor(...)
	self.super.ctor(self, "GameCustomGiftPoolSelectItem.json", ...)
end

---@private
function GUIGameCustomGiftPoolSelectItemWindow:onLoad(mgr)
	self.mgr = mgr
	self.llRewardRoot = self:getChildWindowByName("GameCustomGiftPoolSelectItem-RewardRoot", GUIType.Layout)
	self.siSelectMask = self:getChildWindowByName("GameCustomGiftPoolSelectItem-SelectMask", GUIType.StaticImage)
	self.llClickArea = self:getChildWindowByName("GameCustomGiftPoolSelectItem-ClickArea", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameCustomGiftPoolSelectItemWindow:initView()

end

---@private
function GUIGameCustomGiftPoolSelectItemWindow:initEvent()
	self.eventList = {}
	self.llClickArea:registerEvent(GUIEvent.Click, function()
		if not self.mgr:isChooseReward(self.giftId, self.cellId, self.index) then
			self.mgr:cacheChooseResult(self.giftId, self.cellId, self.index)
			self.mgr:emitEvent("CustomGiftRewardChoose", self.giftId, self.cellId, self.index)
		end
	end)

	self.llClickArea:registerEvent(GUIEvent.TouchUp, function()
		self:cancelTimer()
	end)

	self.llClickArea:registerEvent(GUIEvent.Release, function()
		self:cancelTimer()
	end)

	self.llClickArea:registerEvent(GUIEvent.TouchMove, function()
		self:cancelTimer()
	end)

	self.llClickArea:registerEvent(GUIEvent.LongTouchStart, function()
		self.showDetailTimer = LuaTimer:scheduleTimer(function()
			local rewardCfg = TableUtil.copyTable(CommonActivityConfig:getRewardById(self.rewardData.rewardId))
			GUICommonActivityRewardDetail:show(rewardCfg.showDetailId)
		end, 300, 1)
	end)

	self.eventList[#self.eventList + 1] = self.mgr:registerEvent("CustomGiftRewardChoose", function(giftId, cellId, index)
		if self.giftId == giftId and self.cellId == cellId then
			self.siSelectMask:SetVisible(self.index == index)
		end
	end)
end

function GUIGameCustomGiftPoolSelectItemWindow:cancelTimer()
	if self.showDetailTimer then
		LuaTimer:cancel(self.showDetailTimer)
		self.showDetailTimer = nil
	end
end

function GUIGameCustomGiftPoolSelectItemWindow:initCellData()
	local commonRewardItem = GUIGameActivityRewardItem.new()
	self.llRewardRoot:AddChildWindow(commonRewardItem.root)
	commonRewardItem.root:SetWidth({1, 0})
	commonRewardItem.root:SetHeight({1, 0})
	local rewardCfg = TableUtil.copyTable(CommonActivityConfig:getRewardById(self.rewardData.rewardId))
	rewardCfg.num = self.rewardData.num
	local showNum = tonumber(rewardCfg.numLang)
	if showNum then
		rewardCfg.numLang = tostring(self.rewardData.num)
	end
	commonRewardItem:setRewardData(rewardCfg)
	commonRewardItem:SetUpEffect(rewardCfg.upProbability)
	self.siSelectMask:SetVisible(self.mgr:isChooseReward(self.giftId, self.cellId, self.index))
end

---@param data table
function GUIGameCustomGiftPoolSelectItemWindow:setData(giftId, cellId, index)
	self.giftId = giftId
	self.cellId = cellId
	self.index = index
	self.rewardData = CustomGiftConfig:getCellRewardDataByIndex(self.cellId, self.index)
	self:initCellData()
end

function GUIGameCustomGiftPoolSelectItemWindow:onDestroy()
	for i, event in pairs(self.eventList) do
		event()
	end
	self.eventList = {}
	self:cancelTimer()
end

return GUIGameCustomGiftPoolSelectItemWindow
