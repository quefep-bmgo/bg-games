---@class GUIDebrisItemWindow : IGUIWindow
local GUIDebrisItemWindow = class("GUIDebrisItemWindow", IGUIWindow)

---@private
function GUIDebrisItemWindow:ctor(_,mgr)
	self.super.ctor(self, "DebrisItem.json", mgr)
end

---@private
function GUIDebrisItemWindow:onLoad(mgr)
	self.mgr=mgr
	self.siDebrisImage = self:getChildWindowByName("DebrisItem-DebrisImage", GUIType.StaticImage)
	self.stDebrisCount = self:getChildWindowByName("DebrisItem-DebrisCount", GUIType.StaticText)
	self.siDebrisMast = self:getChildWindowByName("DebrisItem-DebrisMast", GUIType.StaticImage)
	self.btnDebrisButton = self:getChildWindowByName("DebrisItem-DebrisButton", GUIType.Button)
	self.stDebrisButtonText = self:getChildWindowByName("DebrisItem-DebrisButtonText", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIDebrisItemWindow:initView()

end

---@private
function GUIDebrisItemWindow:initEvent()

end

---@private
function GUIDebrisItemWindow:refreshLangUI()
	self.stDebrisButtonText:SetText(Lang:getString("activity.activateButton"))
end

function GUIDebrisItemWindow:addClickEvent(panel)
	self.btnDebrisButton:registerEvent(GUIEvent.ButtonClick, function()
		local activated = self.cache.activated or false
		local count = self.cache.count or 0
		local isActivate = false
		if not activated and count>0 then
			isActivate = true
		end
		panel:DebrisByClick(self.data.debrisId,isActivate)
	end)
end

---@param data table
function GUIDebrisItemWindow:onDataChanged(data)
	self.data=data
	self.siDebrisImage:SetImage(data.image)
	self.siDebrisMast:SetEffectName("g1008_ui_pingtu_0"..data.groupSeq..".effect")
end

function GUIDebrisItemWindow:onCacheChanged(cache)
	self.cache = self.cache or {}
	local activated = cache.activated or false
	local count = cache.count or 0
	if self.cache.activated ~= activated then
		if activated then
			self.siDebrisImage:SetImage(self.data.image.."_light")
		else
			self.siDebrisImage:SetImage(self.data.image)
		end
	end
	if self.cache.count ~= count then
		self.stDebrisCount:SetText(count)
	end
	self.btnDebrisButton:SetVisible(not activated and count > 0)
	self.siDebrisMast:SetVisible(not activated and count > 0)
	self.cache = TableUtil.copyTable(cache)
end

return GUIDebrisItemWindow
