---@class GUIGameDiscountShopGoodsWindow : IGUIWindow
local GUIGameDiscountShopGoodsWindow = class("GUIGameDiscountShopGoodsWindow", IGUIWindow)

require "client.ui_activity.window.GUICommonActivityRewardItem"

local baseIconArea = {x = 0, y = 3, width = 77, height = 77}

local IconOffsetCfg = {
    [1] = {x = 5, y = -6, scale = 1.15},
    [2] = {x = 0, y = 2, scale = 1},
    [3] = {x = 0, y = 0, scale = 1},
    [4] = {x = 0, y = 0, scale = 1},
    [5] = {x = 0, y = 11, scale = 0.8},
    [6] = {x = 0, y = 11, scale = 0.8},
    [7] = {x = 0, y = -2, scale = 1.15},
    [8] = {x = 0, y = 7, scale = 0.9},
    [9] = {x = 0, y = 8, scale = 0.9},
}

---@private
function GUIGameDiscountShopGoodsWindow:ctor(_, mgr)
    self.super.ctor(self, "GameDiscountShopGoods.json", mgr)
end

---@private
---@param mgr CDiscountShopActivityMgr
function GUIGameDiscountShopGoodsWindow:onLoad(mgr)
    self.mgr = mgr
    self.siTray = self:getChildWindowByName("GameDiscountShopGoods-Tray", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameDiscountShopGoods-Image", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("GameDiscountShopGoods-Effect", GUIType.StaticImage)
    self.llSelectClick = self:getChildWindowByName("GameDiscountShopGoods-SelectClick", GUIType.Layout)
    self.siCheckBg = self:getChildWindowByName("GameDiscountShopGoods-CheckBg", GUIType.StaticImage)
    self.siCheck = self:getChildWindowByName("GameDiscountShopGoods-Check", GUIType.StaticImage)
    self.siPriceIcon = self:getChildWindowByName("GameDiscountShopGoods-PriceIcon", GUIType.StaticImage)
    self.siMask = self:getChildWindowByName("GameDiscountShopGoods-Mask", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameDiscountShopGoods-Price", GUIType.StaticText)
    self.stSaleOut = self:getChildWindowByName("GameDiscountShopGoods-SaleOut", GUIType.StaticText)
    self.stChooseText = self:getChildWindowByName("GameDiscountShopGoods-ChooseText", GUIType.StaticText)
    self.stCountText = self:getChildWindowByName("GameDiscountShopGoods-Count", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameDiscountShopGoodsWindow:initView()
    self.stSaleOut:SetText(Lang:getString("gui.sale.out"))
    self.stChooseText:SetText(Lang:getString("gui.choose"))
end

---@private
function GUIGameDiscountShopGoodsWindow:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        GUICommonActivityRewardDetail:show(self.detailData.reward.showDetailId)
    end)

    self.llSelectClick:registerEvent(GUIEvent.Click, function()
        self.mgr:onSelectGoods(self.data)
    end)
end

---@param data DiscountShopGoodsData
function GUIGameDiscountShopGoodsWindow:onDataChanged(data)
    self.data = data
    self.detailData = self.mgr:getRandomStoreDetailData(data.id)
    local offsetCfg = IconOffsetCfg[data.index] or {x = 0, y = 0, scale = 1}
    if offsetCfg then
        local posX = {0, baseIconArea.x + offsetCfg.x}
        local posy = {0, baseIconArea.y + offsetCfg.y}
        self.siImage:SetArea(posX, posy, {0, baseIconArea.width * offsetCfg.scale}, {0, baseIconArea.height * offsetCfg.scale})
    end
    local rewardCount = self.detailData.randomStoreCfg.rewardCount
    if rewardCount > 1 then
        self.stCountText:SetText(rewardCount)
    else
        self.stCountText:SetText("")
    end
    self.siImage:SetImage(self.detailData.reward.image)
    self.stPrice:SetText(self.detailData.randomStoreCfg.price)
    self.siPriceIcon:SetXPosition({ 0, -(self.stPrice:GetTextWidth() / 2 + 8) })
    if self.detailData.reward.needMask and self.detailData.reward.needMask > 0 then
        self.siMask:SetVisible(true)
    else
        self.siMask:SetVisible(false)
    end
    if self.mgr:getGoodsLimit(self.data) == 0 then
        self.siTray:SetImage("set:game_activity_discount_store_2.json image:img_0_itembd_saleout")
        self.siCheckBg:SetVisible(false)
        self.siPriceIcon:SetVisible(false)
        self.stSaleOut:SetVisible(true)
    else
        self.siTray:SetImage("set:game_activity_discount_store_2.json image:img_0_itembd_normal")
        self.siCheckBg:SetVisible(true)
        self.siCheck:SetVisible(self.mgr:isGoodsSelect(self.data))
        self.stChooseText:SetVisible(not self.mgr:isGoodsSelect(self.data))
        self.siPriceIcon:SetVisible(true)
        self.stSaleOut:SetVisible(false)
    end
end

return GUIGameDiscountShopGoodsWindow
