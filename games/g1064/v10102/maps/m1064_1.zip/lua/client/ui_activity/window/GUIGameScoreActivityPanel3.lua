---@class GUIGameScoreActivityPanel3Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameScoreActivityPanel3Window = class("GUIGameScoreActivityPanel3Window", GUICommonActivityPanel)
---@type ScoreActivityConfig
local ScoreActivityConfig = T(Global, "ScoreActivityConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameScoreActivityPanel3Window:ctor(...)
    self.json_name = "GameScoreActivityPanel3.json"
    self.super.ctor(self, "GameScoreActivityPanel3.json", ...)
end

---@private
function GUIGameScoreActivityPanel3Window:onChildLoad()
    ---@type CScoreActivityMgr
    self.mgr = self.mgr
    self.siQuestion = self:getChildWindowByName("GameScoreActivityPanel3-Question", GUIType.StaticImage)
    self.stScoreValue = self:getChildWindowByName("GameScoreActivityPanel3-ScoreValue", GUIType.StaticText)
    self.llGift = self:getChildWindowByName("GameScoreActivityPanel3-Gift", GUIType.Layout)
    self.llTask = self:getChildWindowByName("GameScoreActivityPanel3-Task", GUIType.Layout)
    self.stTaskRewardCount = self:getChildWindowByName("GameScoreActivityPanel3-TaskRewardCount", GUIType.StaticText)
    self.stTaskDesc = self:getChildWindowByName("GameScoreActivityPanel3-TaskDesc", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

function GUIGameScoreActivityPanel3Window:onShow()
    GUIGameActivityLayout:hideTitle()
    self:refreshUI()
end

---@private
function GUIGameScoreActivityPanel3Window:initView()
    self.mgr:registerCacheChange(function(main)
        if self:isShow() then
            self:refreshUI()
        else
            self:updateRedPoint()
        end
        if main then
            return
        end
        if self.curScore and self.curScore < self.mgr:getScore() then
            local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId)
            if not TableUtil.isEmpty(tasks) and self.curTaskId == tasks[1].Id then
                return
            end

            GUIRewardResult:onShowRewards(self.mgr.config.npcDialogRewardId, nil, function()
                GUIGameActivityLayout:show(self.mgr.config.id)
            end)
        end
        self.curScore = self.mgr:getScore()
    end)
    local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
    self.rewards = rewards
    self.lvGifts = IGUIListView.new("GameScoreActivityPanel-Gift" .. self.activity.activityId, self.llGift, nil, Orientation.Horizontal)
    self.lvGifts:setItemSpace(14)
    ---@type GUIGameScoreActivityRewardItem3Window
    local GUIGameScoreActivityRewardItem3 = UIHelper.requireGUIWindow("GUIGameScoreActivityRewardItem3", false, "ui_activity")
    for _, reward in pairs(rewards) do
        local window = GUIGameScoreActivityRewardItem3.new("", self.mgr)
        window:onDataChanged(reward)
        self.lvGifts:addItem(window)
    end
end

---@private
function GUIGameScoreActivityPanel3Window:initEvent()
    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("score.activity.help.title.3")
                    .setContentText(Lang:getString("score.activity.help.content.3"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self:registerEvent(Events.ScoreActivityTaskUpdateEvent, function(activityId, taskId, progress, _)
        if self:getActivityById() ~= activityId then
            return
        end
        local task = TaskConfig:getTaskById(taskId)
        if not task then
            self.llTask:SetVisible(false)
            return
        end
        self.curTaskId = taskId
        self.llTask:SetVisible(true)
        self.stTaskRewardCount:SetText(task.Reward)
        local progressText = "(▢FFCE4545" .. tostring(math.min(progress, task.GoalNum)) .. "▢FF2A4269/" .. tostring(task.GoalNum) .. ")   "
        self.stTaskDesc:SetText(progressText .. Lang:getString(task.Desc))
    end)
end

---@private
function GUIGameScoreActivityPanel3Window:updateRedPoint()
    local count = 0
    for _, reward in pairs(self.rewards) do
        local limit = self.mgr:getRewardLimit(reward)
        if (limit > 0 or limit < 0)
                and self.mgr:getScore() >= reward.score
                and reward.price <= 0 then
            count = count + 1
        end
    end
    UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
end

---@private
function GUIGameScoreActivityPanel3Window:refreshUI()
    self:updateRedPoint()
    self.stScoreValue:SetText(self.mgr:getScore())
    ---@param item GUIGameScoreActivityRewardItem3Window
    for _, item in pairs(self.lvGifts.items) do
        item:onDataChanged(item.data)
    end
end

return GUIGameScoreActivityPanel3Window
