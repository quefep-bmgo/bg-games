---@class GUIGameTurntableActivityRewardItem3Window : IGUIWindow
local GUIGameTurntableActivityRewardItem3Window = class("GUIGameTurntableActivityRewardItem3Window", IGUIWindow)
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type CustomGoodsTicketConfig
local CustomGoodsTicketConfig = T(Global, "CustomGoodsTicketConfig")

---@private
function GUIGameTurntableActivityRewardItem3Window:ctor(_, mgr)
    self.super.ctor(self, "GameTurntableActivityRewardItem3.json", mgr)
end

---@private
---@param mgr CTurntableActivityMgr
function GUIGameTurntableActivityRewardItem3Window:onLoad(mgr)
    self.seq = 0
    self.mgr = mgr
    self.siBackOpen = self:getChildWindowByName("GameTurntableActivityRewardItem3-BackOpen", GUIType.StaticImage)
    self.siIconBg = self:getChildWindowByName("GameTurntableActivityRewardItem3-Icon-Bg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("GameTurntableActivityRewardItem3-Icon", GUIType.StaticImage)
    self.stIconCount = self:getChildWindowByName("GameTurntableActivityRewardItem3-Icon-Count", GUIType.StaticText)
    self.stName = self:getChildWindowByName("GameTurntableActivityRewardItem3-Name", GUIType.StaticText)
    self.siBack = self:getChildWindowByName("GameTurntableActivityRewardItem3-Back", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameTurntableActivityRewardItem3-Price", GUIType.StaticText)
    self.stOpenText = self:getChildWindowByName("GameTurntableActivityRewardItem3-Open-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameTurntableActivityRewardItem3Window:initView()
    self.stName:SetText("")
    self.siBackOpen:SetVisible(false)
    self.siBack:SetVisible(true)
    self.stOpenText:SetText(Lang:getString("click.to.close"))
end

---@private
function GUIGameTurntableActivityRewardItem3Window:initEvent()
    self.siIcon:registerEvent(GUIEvent.Click, function()
        self:onShow()
    end)
    self.siBack:registerEvent(GUIEvent.Click, function()
        if self.isAnimPlaying then
            return
        end
        self.mgr:tryLottery(function(data)
            self:startLotteryAnim()
        end, self.seq)
    end)
end

---@param reward CommonActivityRewardData
function GUIGameTurntableActivityRewardItem3Window:setReward(reward)
    self.reward = reward
    if self.mgr:getIsLotteryAnim() then
        return
    end
    local showDetail = RewardItemShowDetailConfig:getConfigById(reward.showDetailId)
    if not showDetail then
        return
    end
    self:onSetTag(reward)
    self.siIcon:SetImage(showDetail.image)
    self.stName:SetText(Lang:getString(showDetail.name))
    self.siBack:SetVisible(false)
    self.siBackOpen:SetVisible(true)
    self:onShow()
end

function GUIGameTurntableActivityRewardItem3Window:onShow()
    if self.reward then
        local count = self.reward.num
        if count then
            if count > 1 then
                self.stIconCount:SetText(tostring("x"..count))
                self.stIconCount:SetXPosition({0, 7})
                self.stIconCount:SetYPosition({0, -9})
            else
                self.stIconCount:SetText(tostring(""))
            end
        end
    end
end

function GUIGameTurntableActivityRewardItem3Window:setIndex(seq)
    self.seq = seq
end

function GUIGameTurntableActivityRewardItem3Window:startLotteryAnim()
    self.mgr:setIsLotteryAnim(true)
    self.stPrice:SetVisible(false)
    self.stOpenText:SetVisible(false)
    self.siBackOpen:SetVisible(false)
    self.siIconBg:SetVisible(false)
    local sizeW = 1
    self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
        sizeW = sizeW - 0.1
        self.siBack:SetWidth({ sizeW, 0 })
    end, function()
        self.siBack:SetVisible(false)
        self.siBackOpen:SetWidth({ sizeW, 0 })
        self.siBackOpen:SetVisible(true)
        self.stName:SetVisible(false)
        self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
            sizeW = sizeW + 0.1
            self.siBackOpen:SetWidth({ sizeW, 0 })
            if self.reward then
                self:setReward(self.reward)
            end
        end, function()
            self.mgr:setIsLotteryAnim(false)
            self.siIconBg:SetVisible(true)
            self.stName:SetVisible(true)
            if self.reward then
                self:setReward(self.reward)
            end
            LuaTimer:schedule(function()
                GameActivityShowReward.builder()
                                      .setRewardView({ self.reward })
                                      .setHideLeftButton()
                                      .setRightButton("common.activity.sure")
                                      .show()
            end, 70)
        end, 1, 10))
    end, 1, 10))
end

function GUIGameTurntableActivityRewardItem3Window:onSetTag(reward)
    if self.llTag then
        self.llTag.root:SetVisible(false)
    end
    self.siIconBg:SetImage("")
    if reward.type ~= "RewardSetting" then
        return
    end
    local realReward = RewardConfig:getRewardById(reward.realId)
    if not realReward or realReward.RewardType ~= Define.RewardType.CustomGoodsTicket then
        return
    end
    local item = CustomGoodsTicketConfig:getTicketConfig(realReward.RewardId)
    if item then
        if not self.llTag then
            ---@type GUIBedWarItemTagWindow
            self.llTag = UIHelper.newGameGUIWindow("GUIBedWarItemTag", "BedWarItemTag.json")
            self.siIconBg:AddChildWindow(self.llTag.root)
        end
        self.siIconBg:SetImage("set:bed_war_3_dress_store.json image:img_0_ticket_" .. tostring(item.level))
        self.llTag.root:SetVisible(true)
        self.llTag:onDataChanged({
            bg = "set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(item.level),
            text = item.day .. Lang:getString("gui.day")
        })
    end
end

return GUIGameTurntableActivityRewardItem3Window
