---@class GUIGameCardLotteryRewardItemWindow : IGUIWindow
local GUIGameCardLotteryRewardItemWindow = class("GUIGameCardLotteryRewardItemWindow", IGUIWindow)

---@private
function GUIGameCardLotteryRewardItemWindow:ctor(...)
    self.super.ctor(self, "GameCardLotteryRewardItem.json", ...)
end

---@private
function GUIGameCardLotteryRewardItemWindow:onLoad()
    self.siBg = self:getChildWindowByName("GameCardLotteryRewardItem-Bg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("GameCardLotteryRewardItem-Icon", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameCardLotteryRewardItemWindow:initView()

end

---@private
function GUIGameCardLotteryRewardItemWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if self.reward then
            GUICommonActivityRewardDetail:show(self.reward.showDetailId)
        end
    end)
end

---@param reward CommonActivityRewardData
function GUIGameCardLotteryRewardItemWindow:setReward(reward)
    self.reward = reward
    self.siIcon:SetImage(reward.image)
end

return GUIGameCardLotteryRewardItemWindow
