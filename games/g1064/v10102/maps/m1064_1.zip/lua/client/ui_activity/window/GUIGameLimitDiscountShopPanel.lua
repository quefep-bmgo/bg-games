---@class GUIGameLimitDiscountShopPanelWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameLimitDiscountShopPanelWindow = class("GUIGameLimitDiscountShopPanelWindow", GUICommonActivityPanel)
---@type LimitDiscountShopConfig
local LimitDiscountShopConfig = Plugins.Require("activity", "common.config.LimitDiscountShopConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameLimitDiscountShopPanelWindow:ctor(...)
	self.json_name = "GameLimitDiscountShopPanel.json"
	self.super.ctor(self, "GameLimitDiscountShopPanel.json", ...)
end

---@private
function GUIGameLimitDiscountShopPanelWindow:onChildLoad()
	---@type CLimitDiscountShopMgr
	self.mgr = self.mgr
	self.items = {}
	self.endTime = self.mgr.mainConfig.endTime
	self.siTitle = self:getChildWindowByName("GameLimitDiscountShopPanel-Title-Img", GUIType.StaticImage)
	self.siTipIcon = self:getChildWindowByName("GameLimitDiscountShopPanel-Tip-Icon", GUIType.StaticImage)
	self.stCountDown = self:getChildWindowByName("GameLimitDiscountShopPanel-Count-Down", GUIType.StaticText)
	self.siBg = self:getChildWindowByName("GameLimitDiscountShopPanel-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindowByName("GameLimitDiscountShopPanel-Content", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameLimitDiscountShopPanelWindow:initView()
	local rewards = LimitDiscountShopConfig:getDiscountShopItems(self.mgr.config.groupId)
	local num = #rewards
	local contentWidth = self.llContent:GetPixelSize().x
	local interval = 22
	local itemX = 0
	local offset = 0
	local itemWidth = (contentWidth - (num - 1) * interval) / num
	for i = 1, num do
		---@type GUIGameLimitDiscountShopItemWindow
		local item = UIHelper.requireGUIWindow("GUIGameLimitDiscountShopItem", false, "ui_activity").new("", self.mgr)
		self.llContent:AddChildWindow(item.root)
		if i > 1 then
			itemX = itemX + interval + itemWidth + (i - 1) * 5
			offset = (i - 1) * -3
		end
		item:onDataChanged(rewards[i], offset)
		item.root:SetArea({ 0, itemX}, { 0, 0 }, { 0, itemWidth }, { 1, 0 })
		self.items[tostring(rewards[i].id)] = item
	end
	--if self.mgr.config.titleImageFile ~= "#" then
	--	local image = "set:" .. self.mgr.config.titleImageFile .. ".json image:text"
	--	UIHelper:setImageAdjustSize(self.siTitle, UIUtils.GetLangImage(image), 9999, 9999)
	--end
end

---@private
function GUIGameLimitDiscountShopPanelWindow:initEvent()
	self.siTipIcon:registerEvent(GUIEvent.Click, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("limit.discount.shop.info.title")
					.setContentText(Lang:getString(self.mgr.mainConfig.descLang))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)
	self.mgr:registerCacheChange(function()
		if not self:isShow() then
			return
		end
		self:refreshUI()
	end)
end

function GUIGameLimitDiscountShopPanelWindow:onShow()
	if not self.first then
		self:refreshUI()
		self.first = true
	end
	for id, item in pairs(self.items) do
		item:onWindowShow()
	end
	--GUIGameActivityLayout.llKeyMoney.root:SetVisible(false)
end

function GUIGameLimitDiscountShopPanelWindow:onSecondTick()
	if not self:isShow() then
		return
	end
	self.lastTime = self.endTime - os.time()
	if self.lastTime <= 0 then
		return
	end
	if self.lastTime >= DateUtil.getDaySeconds() then
		local text = Lang:format("common.activity.day", tostring(math.floor(self.lastTime / DateUtil.getDaySeconds())))
		self.stCountDown:SetText(text)
	else
		self.stCountDown:SetText(DateUtil.getFormatTime(self.lastTime))
	end
end

function GUIGameLimitDiscountShopPanelWindow:refreshUI()
	local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
	if not self.items or not cache then
		return
	end
	for id, item in pairs(self.items) do
		local itemCache = cache.buyItems[tostring(id)]
		if itemCache then
			item:setCannotBuy()
		end
	end
end

function GUIGameLimitDiscountShopPanelWindow:onHide()
	for id, item in pairs(self.items) do
		item:onWindowHide()
	end
	--GUIGameActivityLayout.llKeyMoney.root:SetVisible(true)
end

return GUIGameLimitDiscountShopPanelWindow
