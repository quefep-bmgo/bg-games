---@class GUIGameCustomGiftWindow : IGUIWindow
local GUIGameCustomGiftWindow = class("GUIGameCustomGiftWindow", GUICommonActivityPanel)

---@type CustomGiftConfig
local CustomGiftConfig = Plugins.Require("activity", "common.config.CustomGiftConfig")

---@private
function GUIGameCustomGiftWindow:ctor(...)
	self.super.ctor(self, "GameCustomGift.json", ...)
end

---@private
function GUIGameCustomGiftWindow:onChildLoad()
	self.stTitle = self:getChildWindowByName("GameCustomGift-Title", GUIType.StaticText)
	self.btnHelp = self:getChildWindowByName("GameCustomGift-Help", GUIType.Button)
	self.stTime = self:getChildWindowByName("GameCustomGift-Time", GUIType.StaticText)
	self.stTipsTime = self:getChildWindowByName("GameCustomGift-TipsText", GUIType.StaticText)
	self.llRewardListPanel = self:getChildWindowByName("GameCustomGift-RewardListPanel", GUIType.Layout)

	self.lvShowRewardList = IGUIListView.new("GameCustomGift-gift-List-".. self.mgr.mainConfig.id , self.llRewardListPanel, nil, Orientation.Vertical)
	self.lvShowRewardList:setItemSpace(10)

	self.showItemAdapt = UIHelper.requireAdapter("GameCustomGiftAdapt", false, "ui_activity").new()
	self.showItemAdapt:setItemSize(562, 124)
	self.showItemAdapt:setMgr(self.mgr)
	self.lvShowRewardList:setAdapter(self.showItemAdapt)

	self:initView()
	self:initEvent()
end

---@private
function GUIGameCustomGiftWindow:initView()
	self.showItemAdapt:setData(self.mgr.config)
	self.stTipsTime:SetText(Lang:getString("gui.activity.custom.gift.tip"))
end

---@private
function GUIGameCustomGiftWindow:initEvent()
	self.mgr:registerCacheChange(function()
		if self:isShow() then
		end
	end)

	self.btnHelp:registerEvent(GUIEvent.ButtonClick, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("diamond.consume.help.title")
					.setContentText(Lang:getString("gui.activity.custom.gift.help"))
					.setHideLeftButton()
					.show()
	end)
end

function GUIGameCustomGiftWindow:onDestroy()
	if self.mgr and self.mgr.registerCacheChange then
		self.mgr:registerCacheChange(nil)
	end
	self.super:onDestroy()
end


return GUIGameCustomGiftWindow
