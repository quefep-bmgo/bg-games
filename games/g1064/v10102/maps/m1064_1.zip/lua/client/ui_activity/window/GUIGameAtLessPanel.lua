---@class GUIGameAtLessPanelWindow : GUICommonActivityPanel
local GUIGameAtLessPanelWindow = class("GUIGameAtLessPanelWindow", GUICommonActivityPanel)

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameAtLessPanelWindow:ctor(...)
    ---@type CAtLessLotteryMgr
    self.mgr = self.mgr
    self.super.ctor(self, "GameAtLessPanel.json", ...)
end

function GUIGameAtLessPanelWindow:onChildLoad()
    self.siTitleImage = self:getChildWindowByName("GameAtLessPanel-Title-Image", GUIType.StaticImage)
    self.stDailyText = self:getChildWindowByName("GameAtLessPanel-Daily-Text", GUIType.StaticText)
    self.btnJump = self:getChildWindowByName("GameAtLessPanel-Jump", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameAtLessPanelWindow:initView()
    UIHelper:setImageAdjustSize(self.siTitleImage, UIUtils.GetLangImage("set:game_activity_at_less_1.json image:text"), 9999, 9999)

    self.btnJump:SetText(Lang:getString("gui.activity.at.less.jump"))
end

---@private
function GUIGameAtLessPanelWindow:initEvent()
    self.btnJump:registerEvent(GUIEvent.ButtonClick, function()
        ---@type TeamService
        local TeamService = T(Global, "TeamService")
        TeamService:sendCreateTeam("g1008", Define.GameMode.Qualifying)

        GUIGameActivityLayout:hide(true)
    end)
end

function GUIGameAtLessPanelWindow:onShow()
    local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
    local text = Lang:getString("gui.activity.at.less.count")
    local haveTimes = math.floor((self.mgr.config.dailyTimes - cache.dailyTimes))
    local totalTimes = math.floor(self.mgr.config.dailyTimes)
    local count = haveTimes .. "/" .. totalTimes
    if self.mgr.config.dailyTimes == cache.dailyTimes then
        text = text .. TextFormat.colorRed .. count
    else
        text = text .. TextFormat.colorGreen .. count
    end
    self.stDailyText:SetText(text)
    GUIGameActivityLayout:hideTitle()
end

return GUIGameAtLessPanelWindow
