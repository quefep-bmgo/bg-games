require "client.ui_activity.window.GUIGameBlindBoxItem"

---@class GUIBlindBoxPanel4 : GUICommonActivityPanel
local GUIBlindBoxPanel4 = class("GUIBlindBoxPanel4", GUICommonActivityPanel)

function GUIBlindBoxPanel4:ctor(...)
    ---@type CBlindBoxMgr
    self.mgr = self.mgr
    self.json_name = "BlindBoxPanel.json"
    self.super.ctor(self, "GameBlindBoxPanel4.json", ...)
end

function GUIBlindBoxPanel4:onChildLoad()
    self.btnHelp = self:getChildWindowByName("BlindBoxPanel-Help", GUIType.Button)
    self.btnHelp:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("blind.box.help.title")
                    .setContentText(Lang:getString("blind.box.help.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)

    ---@type GUIGameBlindBoxItem[]
    self.items = {}
    self.itemBoxLayout = {}
    self.itemBoxLayout[1] = self:getChildWindowByName("BlindBoxPanel-Left-Box", GUIType.Layout)
    self.itemBoxLayout[2] = self:getChildWindowByName("BlindBoxPanel-Center-Box", GUIType.Layout)
    self.itemBoxLayout[3] = self:getChildWindowByName("BlindBoxPanel-Right-Box", GUIType.Layout)
    self:initBoxList()
end

function GUIBlindBoxPanel4:isShowAnim()
    return false
end

function GUIBlindBoxPanel4:initBoxList()
    local blindBoxList = self.mgr.boxConfigList
    for pos, blindBox in pairs(blindBoxList) do
        ---@type GUIGameBlindBoxItem
        local item = GUIGameBlindBoxItem.new("GameBlindBoxItem4.json", self.mgr)
        item:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
        item:onDataChanged(blindBox)
        self.items[blindBox.id] = item
        self.itemBoxLayout[pos]:AddChildWindow(item.root)
    end
end
function GUIBlindBoxPanel4:refreshUI()

    local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
    for _, item in pairs(self.items) do
        item.data.dayEndTime = cache.dayEndTime
        local boxCache = cache.blindBoxList[tostring(item.data.id)]
        if boxCache then
            item.data.dayOpenTimes = cache.blindBoxList[tostring(item.data.id)].dayOpenTimes
            item.data.openTimes = cache.blindBoxList[tostring(item.data.id)].openTimes
            item:onDataChanged(item.data)
            item:updateTimeOrTimes(item.data)
        end
    end
end

function GUIBlindBoxPanel4:resetBoxTimes()
    ---@param item GUIBlindBoxItem
    for _, item in pairs(self.items) do
        item.data.openTimes = 0
    end
end

function GUIBlindBoxPanel4:onSecondTick()
    if not self:isShow() then
        return
    end
    self.super.onSecondTick(self)
    ---@param item GUIBlindBoxItem
    for _, item in pairs(self.items) do
        item:updateTimeOrTimes()
    end
end

function GUIBlindBoxPanel4:onBlindBoxOpenResult(data)
    ---计算魔方价值
    local worth = 0
    for _, item in pairs(data.results) do
        local reward = CommonActivityRewardConfig:getRewardById(item.rewardId)
        if reward then
            worth = worth + reward.price
        end
    end
    local config = BlindBoxConfig:getBlindBoxById(data.boxId)
    if not config then
        return
    end
    local percent = BlindBoxRewardConfig:getRewardPercentByWorth(config.worthGroupId, worth) .. "%"
    local text = Lang:format("blind.box.reward.tip", worth, percent)
    GameActivityShowReward.builder()
                          .setBottomTip(text)
                          .setRewardView(data.results)
                          .setHideLeftButton()
                          .setRightButton("common.activity.sure")
                          .show()
    config.openTimes = data.openTimes
    config.dayOpenTimes = data.dayOpenTimes
    local item = self.items[data.boxId] ---@type GUIBlindBoxItem
    if item then
        item:updateTimeOrTimes()
    end
end

return GUIBlindBoxPanel4