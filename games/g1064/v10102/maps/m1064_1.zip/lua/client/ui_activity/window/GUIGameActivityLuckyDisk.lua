---@class GUIGameActivityLuckyDiskWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameActivityLuckyDiskWindow = class("GUIGameActivityLuckyDiskWindow", GUICommonActivityPanel)

---@private
function GUIGameActivityLuckyDiskWindow:ctor(...)
	self.super.ctor(self, "GameActivityLuckyDisk.json", ...)
end

---@private
function GUIGameActivityLuckyDiskWindow:onChildLoad()
	self.siBg = self:getChildWindowByName("GameActivityLuckyDisk-Bg", GUIType.StaticImage)
	self.siEffect1 = self:getChildWindowByName("GameActivityLuckyDisk-Effect1", GUIType.StaticImage)
	self.siEffect2 = self:getChildWindowByName("GameActivityLuckyDisk-Effect2", GUIType.StaticImage)
	self.btnHint = self:getChildWindowByName("GameActivityLuckyDisk-Hint", GUIType.Button)
	self.stTitle = self:getChildWindowByName("GameActivityLuckyDisk-Title", GUIType.StaticText)
	self.siTimeIcon = self:getChildWindowByName("GameActivityLuckyDisk-TimeIcon", GUIType.StaticImage)
	self.stTime = self:getChildWindowByName("GameActivityLuckyDisk-Time", GUIType.StaticText)
	self.siDiskBg = self:getChildWindowByName("GameActivityLuckyDisk-Disk-Bg", GUIType.StaticImage)
	self.btnClick = self:getChildWindowByName("GameActivityLuckyDisk-Click", GUIType.Button)
	self.stClickTxt = self:getChildWindowByName("GameActivityLuckyDisk-Click-Txt", GUIType.StaticText)
	self.siClickOffPrice = self:getChildWindowByName("GameActivityLuckyDisk-Click-Off-Price", GUIType.StaticImage)
	self.siClickPriceIcon = self:getChildWindowByName("GameActivityLuckyDisk-Click-Price-Icon", GUIType.StaticImage)
	self.stClickPriceTxt = self:getChildWindowByName("GameActivityLuckyDisk-Click-Price-Txt", GUIType.StaticText)
	self.btnPool = self:getChildWindowByName("GameActivityLuckyDisk-Pool", GUIType.Button)
	self.stPoolTxt = self:getChildWindowByName("GameActivityLuckyDisk-Pool-Txt", GUIType.StaticText)
	self.btnReset = self:getChildWindowByName("GameActivityLuckyDisk-Reset", GUIType.Button)
	self.stResetTxt = self:getChildWindowByName("GameActivityLuckyDisk-Reset-Txt", GUIType.StaticText)
	self.siResetPriceIcon = self:getChildWindowByName("GameActivityLuckyDisk-Reset-Price-Icon", GUIType.StaticImage)
	self.stResetPriceValue = self:getChildWindowByName("GameActivityLuckyDisk-Reset-Price-Value", GUIType.StaticText)
	self.stResetTime = self:getChildWindowByName("GameActivityLuckyDisk-Reset-Time", GUIType.StaticText)
	self.siMainBg = self:getChildWindowByName("GameActivityLuckyDisk-MainBg", GUIType.StaticImage)
	self.awActor = self:getChildWindowByName("GameActivityLuckyDisk-Actor", GUIType.ActorWindow)
	self.stItemName = self:getChildWindowByName("GameActivityLuckyDisk-ItemName", GUIType.StaticText)
	self.llActorSlideBlock = self:getChildWindowByName("GameActivityLuckyDisk-Actor-Slide-Block", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameActivityLuckyDiskWindow:initView()
	self.stTitle:SetText(Lang:getString(self.mgr.mainConfig.titleLang))
	self.stClickTxt:SetText(Lang:getString("gui.lucky.disk.click.txt"))
	self.stPoolTxt:SetText(Lang:getString("gui.lucky.disk.reward.pool"))
	self.stResetTxt:SetText(Lang:getString("gui.lucky.disk.reset.reward.pool"))
	self.siClickOffPrice:SetVisible(false)

	self.itemsList = {}
	for i = 1, 6 do
		self.itemsList[i] = {
			bg = self:getChildWindowByName("GameActivityLuckyDisk-Item" .. i, GUIType.StaticImage),
			light = self:getChildWindowByName("GameActivityLuckyDisk-Item" .. i .."-Light", GUIType.StaticImage),
			icon = self:getChildWindowByName("GameActivityLuckyDisk-Item" .. i .."-Icon", GUIType.StaticImage),
			num = self:getChildWindowByName("GameActivityLuckyDisk-Item" .. i .."-Num", GUIType.StaticText),
			receive = self:getChildWindowByName("GameActivityLuckyDisk-Item" .. i .."-Icon-Receive", GUIType.StaticImage),
			click = self:getChildWindowByName("GameActivityLuckyDisk-Item" .. i .."-Click", GUIType.StaticImage),
		}
		self.itemsList[i].light:SetVisible(false)
		self.itemsList[i].receive:SetVisible(false)
	end
end

---@private
function GUIGameActivityLuckyDiskWindow:initEvent()
	self.btnHint:registerEvent(GUIEvent.ButtonClick, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("gui.lucky.disk.info.title")
					.setContentText(Lang:getString("gui.lucky.disk.info.text"))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)
	self.btnClick:registerEvent(GUIEvent.ButtonClick, function()
		local cache = self.mgr:getPlayerCache()
		if cache.buyTimes > 6 then
			self.mgr:tryBuy()
			return
		end
		local buyPriceCfg = self.mgr:getBuyPricesCfg(cache.buyTimes)
		PayHelper.checkMoney(buyPriceCfg.type, buyPriceCfg.price, function(success)
			if success then
				self.mgr:tryBuy()
			end
		end).setRechargeFunc(function()
			ClientHelper.onRecharge(1, "activity_lucky_disk_" .. self.mgr.mainConfig.id)
		end)
	end)
	self.btnPool:registerEvent(GUIEvent.ButtonClick, function()
		local rewardPool = self.mgr:getRewardCfg()
		local showRewardPool = {}
		for _, v in pairs(rewardPool) do
			local data = {
				id = v.reward.rewardId,
				num = v.reward.num,
				groupSeq = v.groupSeq,
				isCore = v.isCore,
			}
			table.insert(showRewardPool, data)
		end
		table.sort(showRewardPool, function(a, b)
			return a.groupSeq < b.groupSeq
		end)
		UIGameActivityAceMinerBoxDetailLayout:show(showRewardPool)
		UIGameActivityAceMinerBoxDetailLayout:setData({
			title = "gui.lucky.disk.list.title"
		})
	end)
	self.btnReset:registerEvent(GUIEvent.ButtonClick, function()
		local cache = self.mgr:getPlayerCache()
		local refreshPriceCfg = self.mgr:getRefreshPricesCfg(cache.refreshTimes)
		PayHelper.checkMoney(refreshPriceCfg.type, refreshPriceCfg.price, function(success)
			if success then
				self.mgr:refreshPool()
			end
		end).setRechargeFunc(function()
			ClientHelper.onRecharge(1, "activity_lucky_disk_" .. self.mgr.mainConfig.id)
		end)
	end)
	self.mgr:registerCacheChange(function()
		if self:isShow() then
			self:refreshUI()
		end
	end)
	for index, siItem in pairs(self.itemsList) do
		siItem.click:registerEvent(GUIEvent.Click, function()
			self:updateLeftSide(index)
		end)
	end
	Events.LuckyDiskPoolRefreshEvent:registerCallBack(function()
		self:updateLeftSide(1)
	end)
end

function GUIGameActivityLuckyDiskWindow:updateLeftSide(index)
	local cache = self.mgr:getPlayerCache()
	local storeList = cache.storeList
	if self.mgr.mainConfig.mainRewardId ~= storeList[index] then
		local rewardCfg = self.mgr:getRewardCfgById(storeList[index])
		self.mgr.mainConfig.mainRewardId = rewardCfg.reward.showDetailId
		self.stItemName:SetText(Lang:getString(rewardCfg.reward.name))
		self.super.showRewardDetail(self)
	end
end

function GUIGameActivityLuckyDiskWindow:onShow()
	self:refreshUI()
	self:updateLeftSide(1)
end

local function resetItemUI(self)
	for i, item in pairs(self.itemsList) do
		item.bg:SetDrawColor({1, 1, 1, 1})
		item.icon:SetDrawColor({1, 1, 1, 1})
		item.receive:SetVisible(false)
	end
end

local function setCountDownTime(self)
	if self.timer then
		LuaTimer:cancel(self.timer)
		self.timer = nil
	end

	self.timer = LuaTimer:scheduleTimer(function()
		local startTime = self.mgr:getNextDayStartTime()
		local diff = startTime - os.time()
		local timeTxt = DateUtil.getFormatTimeWithDay(diff)
		self.stResetTime:SetText(timeTxt)
	end, 1000)
end

function GUIGameActivityLuckyDiskWindow:refreshUI()
	self.super.refreshUI(self)
	resetItemUI(self)
	local cache = self.mgr:getPlayerCache()
	for i, id in pairs(cache.storeList) do
		local cfg = self.mgr:getRewardCfgById(id)
		self.itemsList[i].icon:SetImage(cfg.reward.image)
		self.itemsList[i].num:SetText(cfg.reward.num)
		
		if i == 4 then
			if cfg.isCore == 2 then
				self.itemsList[i].bg:SetImage("set:game_activity_lucky_disk.json image:img_0_block_4")
			else
				self.itemsList[i].bg:SetImage("set:game_activity_lucky_disk.json image:img_0_block_4_2")
			end
		end
	end
	local refreshPriceCfg = self.mgr:getRefreshPricesCfg(cache.refreshTimes)
	self.stResetPriceValue:SetText("x".. refreshPriceCfg.price)

	local buyPriceCfg = self.mgr:getBuyPricesCfg(cache.buyTimes)
	if cache.buyTimes > 6 then
		self.stClickTxt:SetText(Lang:getString("gui.lucky.disk.refresh.free"))
		self.stClickTxt:SetYPosition({0, 0})
		self.stResetTxt:SetText(Lang:getString("gui.lucky.disk.refresh.free"))
		self.siClickPriceIcon:SetVisible(false)
		self.siResetPriceIcon:SetVisible(false)
	else
		self.siClickPriceIcon:SetImage(PayHelper.getMoneyIcon(buyPriceCfg.type))
		self.stClickPriceTxt:SetText(buyPriceCfg.price)
		self.stClickTxt:SetText(Lang:getString("gui.lucky.disk.click.txt"))
		self.stClickTxt:SetYPosition({0, -10})
		self.stResetTxt:SetText(Lang:getString("gui.lucky.disk.reset.reward.pool"))
		self.siClickPriceIcon:SetVisible(true)
		self.siResetPriceIcon:SetVisible(true)
	end

	for _, id in pairs(cache.curSelectId) do
		for index, sId in pairs(cache.storeList) do
			if id == sId then
				self.itemsList[index].bg:SetDrawColor({0.5, 0.5, 0.5, 1})
				self.itemsList[index].icon:SetDrawColor({0.5, 0.5, 0.5, 1})
				self.itemsList[index].receive:SetVisible(true)
				break
			end
		end
	end
	
	setCountDownTime(self)
end

function GUIGameActivityLuckyDiskWindow:onHide()
	if self.timer then
		LuaTimer:cancel(self.timer)
		self.timer = nil
	end
end

return GUIGameActivityLuckyDiskWindow
