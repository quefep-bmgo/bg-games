---@class GUIGameCustomGiftItemWindow : IGUIWindow
local GUIGameCustomGiftItemWindow = class("GUIGameCustomGiftItemWindow", IGUIWindow)
---@type GUIGameCustomGiftCellWindow
local GUIGameCustomGiftCell = UIHelper.requireGUIWindow("GUIGameCustomGiftCell", false, "ui_activity")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@private
function GUIGameCustomGiftItemWindow:ctor(_, mgr)
	self.super.ctor(self, "GameCustomGiftItem.json", mgr)
end

---@private
function GUIGameCustomGiftItemWindow:onLoad(mgr)
	self.mgr = mgr
	self.siBg = self:getChildWindowByName("GameCustomGiftItem-Bg", GUIType.StaticImage)
	self.stTitle = self:getChildWindowByName("GameCustomGiftItem-Title", GUIType.StaticText)
	self.btnBuyBtn = self:getChildWindowByName("GameCustomGiftItem-BuyBtn", GUIType.Button)
	self.stBtnTxt = self:getChildWindowByName("GameCustomGiftItem-BtnTxt", GUIType.StaticText)
	self.siCoinIcon = self:getChildWindowByName("GameCustomGiftItem-CoinIcon", GUIType.StaticImage)
	self.siBuyLimitBg = self:getChildWindowByName("GameCustomGiftItem-BuyLimitBg", GUIType.StaticImage)
	self.stBuyLimitCount = self:getChildWindowByName("GameCustomGiftItem-BuyLimitCount", GUIType.StaticText)
	self.llCellContent = self:getChildWindowByName("GameCustomGiftItem-CellContent", GUIType.Layout)
	self.siRedDot = self:getChildWindowByName("GameCustomGiftItem-RedDot", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameCustomGiftItemWindow:initView()
end

---@private
function GUIGameCustomGiftItemWindow:initEvent()
	self.eventList = {}
	self.btnBuyBtn:registerEvent(GUIEvent.ButtonClick, function()
		if self.mgr:isGiftNeedChoose(self.giftConfig.id) then
			UIGameCustomGiftSelectLayout:show(self.giftConfig, self.mgr)
		else
			PayHelper.checkMoney(Define.Money.DIAMOND, self.giftConfig.price, function(canBuy)
				if canBuy then
					self.mgr:buyCustomGift(self.giftConfig.id)
				end
			end)

		end
	end)

	self.eventList[#self.eventList + 1] = self.mgr:registerEvent("CustomGiftCacheDataChange", function()
		self:refreshBuyLimit()
	end)
end

function GUIGameCustomGiftItemWindow:refreshBuyLimit()
	local buyCount = self.mgr:getGiftBuyCount(self.giftConfig.id)
	if buyCount >= self.giftConfig.limitBuyCount then
		self.btnBuyBtn:SetDrawColor({1, 1, 1, 1})
		self.btnBuyBtn:SetAlpha(1)
		self.btnBuyBtn:SetNormalImage("set:game_activity_diamond_gift.json image:btn_0_received2")
		self.btnBuyBtn:SetTouchable(false)
		self.siCoinIcon:SetVisible(false)

		self.stBtnTxt:SetTextColor({209 / 255,  157 / 255, 96 / 255, 1})
		self.stBtnTxt:SetText(Lang:getString("diamond_gift.reward.received"))
		self.stBtnTxt:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
		self.siRedDot:SetVisible(false)
	else
		self.btnBuyBtn:SetDrawColor({1, 1, 1, 1})
		self.btnBuyBtn:SetAlpha(1)
		self.btnBuyBtn:SetNormalImage("set:game_activity_diamond_gift.json image:btn_0_received")
		self.btnBuyBtn:SetTouchable(true)
		self.siCoinIcon:SetVisible(true)
		if self.giftConfig.price == 0 then
			self.siRedDot:SetVisible(true)
		else
			self.siRedDot:SetVisible(false)
		end

		self.stBtnTxt:SetArea({ 0, 61 }, { 0, 0 }, { 0, 78 }, { 1, 0 })
		if self.giftConfig.price > 0 then
			self.stBtnTxt:SetText(self.giftConfig.price)
			self.stBtnTxt:SetTextColor({ 1, 1, 1, 1 })
		else
			self.stBtnTxt:SetText(Lang:getString("bed.war.free.box.lottery"))
			self.stBtnTxt:SetTextColor({ 0, 1, 0, 1 })
		end
	end
	local limitBuyCount = self.giftConfig.limitBuyCount
	self.stBuyLimitCount:SetText((limitBuyCount - buyCount).."/"..limitBuyCount)
end

---@param data table
function GUIGameCustomGiftItemWindow:onDataChanged(data)
	self.giftConfig = data
	local size = 71
	local xSpace = 10
	for i, cellId in pairs(data.rewardCellList) do
		local item = GUIGameCustomGiftCell.new(self.mgr)
		item:setData(cellId, self.giftConfig)
		item:setArea({ 0, (size + xSpace) * (i - 1) }, { 0, 0 }, { 0, size }, { 0, size })
		self.llCellContent:AddChildWindow(item.root)
	end
	self.stTitle:SetText(Lang:getString(self.giftConfig.name))
	self:refreshBuyLimit()
end

function GUIGameCustomGiftItemWindow:onDestroy()
	for i, event in pairs(self.eventList) do
		event()
	end
	self.eventList = {}
end

return GUIGameCustomGiftItemWindow
