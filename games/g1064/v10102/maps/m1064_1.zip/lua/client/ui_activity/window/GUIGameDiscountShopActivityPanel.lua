---@class GUIGameDiscountShopActivityPanelWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameDiscountShopActivityPanelWindow = class("GUIGameDiscountShopActivityPanelWindow", GUICommonActivityPanel)
---@type DiscountShopConfig
local DiscountShopConfig = T(Global, "DiscountShopConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameDiscountShopActivityPanelWindow:ctor(...)
    self.json_name = "GameDiscountShopActivityPanel.json"
    self.super.ctor(self, "GameDiscountShopActivityPanel.json", ...)
end

---@private
function GUIGameDiscountShopActivityPanelWindow:onChildLoad()
    ---@type CDiscountShopActivityMgr
    self.mgr = self.mgr
    self.siTitleImage = self:getChildWindowByName("GameDiscountShopActivityPanel-TitleImage", GUIType.StaticImage)
    self.siQuestion = self:getChildWindowByName("GameDiscountShopActivityPanel-Question", GUIType.StaticImage)
    self.pbDiscountProgress = self:getChildWindowByName("GameDiscountShopActivityPanel-DiscountProgress", GUIType.ProgressBar)
    self.siStar1 = self:getChildWindowByName("GameDiscountShopActivityPanel-Star1", GUIType.StaticImage)
    self.siStar2 = self:getChildWindowByName("GameDiscountShopActivityPanel-Star2", GUIType.StaticImage)
    self.siStar3 = self:getChildWindowByName("GameDiscountShopActivityPanel-Star3", GUIType.StaticImage)
    self.stDiscountPrice = self:getChildWindowByName("GameDiscountShopActivityPanel-DiscountPrice", GUIType.StaticText)
    self.stRealPrice = self:getChildWindowByName("GameDiscountShopActivityPanel-RealPrice", GUIType.StaticText)
    self.btnBuy = self:getChildWindowByName("GameDiscountShopActivityPanel-Buy", GUIType.Button)
    self.llPriceLayout = self:getChildWindowByName("GameDiscountShopActivityPanel-PriceLayout", GUIType.Layout)
    self.llSelectGoods = self:getChildWindowByName("GameDiscountShopActivityPanel-SelectGoods", GUIType.Layout)
    self.llGoods = self:getChildWindowByName("GameDiscountShopActivityPanel-Goods", GUIType.Layout)
    self.stRefreshTimeText = self:getChildWindowByName("GameDiscountShopActivityPanel-RefreshTimeText", GUIType.StaticText)
    self.siDiscount1 = self:getChildWindowByName("GameDiscountShopActivityPanel-Discount1", GUIType.StaticImage)
    self.siDiscount2 = self:getChildWindowByName("GameDiscountShopActivityPanel-Discount2", GUIType.StaticImage)
    self.siDiscount3 = self:getChildWindowByName("GameDiscountShopActivityPanel-Discount3", GUIType.StaticImage)
    self.siPriceIcon = self:getChildWindowByName("GameDiscountShopActivityPanel-PriceIcon", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

function GUIGameDiscountShopActivityPanelWindow:onShow()
    self:refreshUI()
end

---@private
function GUIGameDiscountShopActivityPanelWindow:initView()
    self.btnBuy:SetText(Lang:getString("shop_btn_buy"))
    self.siTitleImage:SetImage(UIUtils.GetLangImage("set:game_activity_discount_store_2.json image:text"))

    self.siDiscount1:SetImage("set:game_activity_discount_store_2.json image:lbl_0_50")
    self.siDiscount2:SetImage("set:game_activity_discount_store_2.json image:lbl_0_60")
    self.siDiscount3:SetImage("set:game_activity_discount_store_2.json image:lbl_0_70")

    self.gvGoodsList = IGUIGridView.new("GameDiscountShopActivityPanel-GoodsList" .. self.activity.activityId, self.llGoods)
    self.gvGoodsList:setConfig(18, 6, 3)
    ---@type DiscountGoodsAdapter
    self.goodsAdapter = UIHelper.requireAdapter("DiscountGoodsAdapter", false, "ui_activity").new()
    self.goodsAdapter:setActivityMgr(self.mgr)
    self.gvGoodsList:setAdapter(self.goodsAdapter)
    --self.goodsList = DiscountShopConfig:getGoodsGroup(self.mgr.config.goodsGroupId)

    self.lvSelectGoodsList = IGUIListView.new("GameDiscountShopActivityPanel-SelectGoodsList" .. self.activity.activityId, self.llSelectGoods, nil, Orientation.Horizontal)
    self.lvSelectGoodsList:setItemSpace(5)
    self.lvSelectGoodsList.root:SetMoveAble(false)
    ---@type GUIGameDiscountShopSelectGoodsWindow
    local GUIGameDiscountShopSelectGoods = UIHelper.requireGUIWindow("GUIGameDiscountShopSelectGoods", false, "ui_activity")
    for index = 1, 3 do
        local item = GUIGameDiscountShopSelectGoods.new("", self.mgr)
        item:onDataChanged(nil, index, 1)
        self.lvSelectGoodsList:addItem(item)
    end
end

---@private
function GUIGameDiscountShopActivityPanelWindow:initEvent()
    self.mgr:registerCacheChange(function()
        if not self:isShow() then
            return
        end
        self:refreshUI()
    end)
    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("discount.shop.activity.help.title")
                    .setContentText(Lang:getString("discount.shop.activity.help.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
        local goodsList = self.mgr:getSelectGoods()
        if #goodsList <= 0 then
            return
        end
        local discountPrice, _ = self.mgr:getSelectGoodsPrice()
        local rewardList = {}
        for _, data in pairs(goodsList) do
            local detailData = self.mgr:getRandomStoreDetailData(data.id)
            table.insert(rewardList, {reward = detailData.reward})
        end
        DiscountShopConfirmContent:setGoodsList(rewardList, discountPrice)
        CustomDialog.builder()
                    .setTitleText("discount.shop.buy.title")
                    .setContentView(DiscountShopConfirmContent)
                    .setRightClickListener(function()
            LuaTimer:scheduleTicker(function()
                PayHelper.checkMoney(CurrencyId.GCube, discountPrice, function(success)
                    if success then
                        local result = {}
                        for _, goods in pairs(goodsList) do
                            local detailData = self.mgr:getRandomStoreDetailData(goods.id)
                            table.insert(result, { rewardId = detailData.reward.rewardId})
                        end
                        GameActivityShowReward.builder()
                                              .setRewardView(result)
                                              .setHideLeftButton()
                                              .setRightButton("common.activity.sure")
                                              .show()
                        self.mgr:tryBuyGoods()
                    end
                end)
            end, 1, 1)
        end)        .show()
    end)
end

function GUIGameDiscountShopActivityPanelWindow:onSecondTick()
    if not self:isShow() then
        return
    end
    self.super.onSecondTick(self)
    self:setCountDownTime()
end

function GUIGameDiscountShopActivityPanelWindow:setCountDownTime()
    local dayEndTime = DateUtil.getGreenwichDayLastTime()
    local leftTime = dayEndTime - os.time()
    self.stRefreshTimeText:SetText(DateUtil.getFormatTimeWithDay(leftTime))
end

---@private
function GUIGameDiscountShopActivityPanelWindow:refreshUI()
    self.super.refreshUI(self)
    self:setCountDownTime()
    if not self.mgr.dataCache then
        return
    end
    local list = {}
    for i, v in ipairs(self.mgr.dataCache.storeList or {}) do
        local data = TableUtil.copyTable(v)
        data.index = i
        table.insert(list, data)
    end
    self.goodsAdapter:setData(list)
    self.goodsAdapter:notifyDataChange()

    local count = self.mgr:getSelectGoodsCount()
    local activity, normal = "set:game_activity_discount_shop_1.json image:img_0_dot_activity", "set:game_activity_discount_shop_1.json image:img_0_dot_normal"
    self.siStar1:SetImage(count >= 1 and activity or normal)
    self.siStar2:SetImage(count >= 2 and activity or normal)
    self.siStar3:SetImage(count >= 3 and activity or normal)
    self.stRealPrice:SetVisible(true)
    self.btnBuy:SetVisible(count > 0)
    self.llPriceLayout:SetVisible(count > 0)
    local discount = 1
    if count == 1 then
        self.pbDiscountProgress:SetProgress(0.33)
        discount = 0.5
    elseif count == 2 then
        self.pbDiscountProgress:SetProgress(0.67)
        discount = 0.4
    elseif count == 3 then
        self.pbDiscountProgress:SetProgress(1)
        discount = 0.3
    else
        self.pbDiscountProgress:SetProgress(0.05)
        self.stRealPrice:SetVisible(false)
    end
    local discountPrice, realPrice = self.mgr:getSelectGoodsPrice()
    self.stDiscountPrice:SetText(discountPrice)
    self.stDiscountPrice:SetWidth({ 0, self.stDiscountPrice:GetTextWidth() })
    self.stRealPrice:SetText(realPrice)
    self.stRealPrice:SetWidth({ 0, self.stRealPrice:GetTextWidth() })
    local goodsList = self.mgr:getSelectGoods()
    ---@param item GUIGameDiscountShopSelectGoodsWindow
    for index, item in pairs(self.lvSelectGoodsList.items) do
        item:onDataChanged(goodsList[index], index, discount)
    end
end

return GUIGameDiscountShopActivityPanelWindow
