---@class GUIGameLimitDiscountShopItem2Window : IGUIWindow
local GUIGameLimitDiscountShopItem2Window = class("GUIGameLimitDiscountShopItem2Window", IGUIWindow)
---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function GUIGameLimitDiscountShopItem2Window:ctor(_, mgr)
	self.super.ctor(self, "GameLimitDiscountShopItem2.json", mgr)
end

---@private
---@param mgr CLimitDiscountShopMgr
function GUIGameLimitDiscountShopItem2Window:onLoad(mgr)
	self.mgr = mgr
	self.btnBuy = self:getChildWindowByName("GameLimitDiscountShopItem2-Buy", GUIType.Button)
	self.siMoneyIcon = self:getChildWindowByName("GameLimitDiscountShopItem2-Money-Icon", GUIType.StaticImage)
	self.stDiscountPrice = self:getChildWindowByName("GameLimitDiscountShopItem2-Discount-Price", GUIType.StaticText)
	self.stPrice = self:getChildWindowByName("GameLimitDiscountShopItem2-Price", GUIType.StaticText)
	self.siLine = self:getChildWindowByName("GameLimitDiscountShopItem2-Line", GUIType.StaticImage)
	self.siStar = self:getChildWindowByName("GameLimitDiscountShopItem2-Star", GUIType.StaticImage)
	self.siEffect = self:getChildWindowByName("GameLimitDiscountShopItem2-Effect", GUIType.StaticImage)
	self.stName = self:getChildWindowByName("GameLimitDiscountShopItem2-Name", GUIType.StaticText)
	self.siClick = self:getChildWindowByName("GameLimitDiscountShopItem2-Click", GUIType.StaticImage)
	self.siMask = self:getChildWindowByName("GameLimitDiscountShopItem2-Mask", GUIType.StaticImage)
	self.awItem = self:getChildWindowByName("GameLimitDiscountShopItem2-Item", GUIType.ActorWindow)
	self.stSellOut = self:getChildWindowByName("GameLimitDiscountShopItem2-Sell-Out", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function GUIGameLimitDiscountShopItem2Window:initView()
	self.siMask:SetVisible(false)
	self.stSellOut:SetText(Lang:getString("gui_activity_limit_discount_sell_out"))
end

---@private
function GUIGameLimitDiscountShopItem2Window:initEvent()
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		self:onBuyClick()
	end)

	self.siClick:registerEvent(GUIEvent.Click, function()
		GUICommonActivityRewardDetail:show(self.detailId or 0)
	end)
end

---@param data LimitDiscountShopItemData
function GUIGameLimitDiscountShopItem2Window:onDataChanged(data, offset)
	self.siStar:SetXPosition({0, offset})
	self.siEffect:SetXPosition({0, offset})
	self.awItem:SetXPosition({0, offset})
	if not data then
		return
	end
	self.data = data
	local reward = CommonActivityConfig:getRewardById(data.rewardId)
	if not reward then
		return
	end
	self.detailId = reward.showDetailId
	self.stDiscountPrice:SetText(data.discountPrice)
	local width = self.stDiscountPrice:GetTextWidth()
	self.stDiscountPrice:SetWidth({0, width + 5})

	self.stPrice:SetText(data.price)
	self.stName:SetText(Lang:getString(reward.name))
	self.siMoneyIcon:SetVisible(true)

	local detailConfig = RewardItemShowDetailConfig:getConfigById(self.detailId)
	RewardItemShowDetailConfig:showActorSkill(self.awItem, detailConfig)
end

function GUIGameLimitDiscountShopItem2Window:setCannotBuy()
	self.btnBuy:SetTouchable(false)
	self.siMoneyIcon:SetVisible(false)
	self.siMask:SetVisible(true)
end

function GUIGameLimitDiscountShopItem2Window:onBuyClick()
	local reward = CommonActivityConfig:getRewardById(self.data.rewardId)
	if not reward then
		return
	end
	GameActivityBuyItemContentLayout:setView({image = reward.image, num = reward.num, scale = 2})
	CustomDialog.builder()
				.setContentView(GameActivityBuyItemContentLayout)
				.setTitleText("gui.store.purchase.title")
				.setRightIcon("set:bed_war_3_icon.json image:img_0_magic_cube")
				.setRightText(tostring(self.data.discountPrice))
				.setRightClickListener(function()
		return self.mgr:onPlayerBuy(self.data.id)
	end)
				.show()
end

function GUIGameLimitDiscountShopItem2Window:onDestroy()
    RewardItemShowDetailConfig:onWindowHide(self.awItem)
    self.super:onDestroy()
end

function GUIGameLimitDiscountShopItem2Window:onWindowShow()
	local detailConfig = RewardItemShowDetailConfig:getConfigById(self.detailId)
	RewardItemShowDetailConfig:showActorSkill(self.awItem, detailConfig)
end

function GUIGameLimitDiscountShopItem2Window:onWindowHide()
	RewardItemShowDetailConfig:onWindowHide(self.awItem)
end

return GUIGameLimitDiscountShopItem2Window
