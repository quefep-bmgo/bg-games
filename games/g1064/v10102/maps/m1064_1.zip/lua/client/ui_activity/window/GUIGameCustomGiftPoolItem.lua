---@class GUIGameCustomGiftPoolItemWindow : IGUIWindow
local GUIGameCustomGiftPoolItemWindow = class("GUIGameCustomGiftPoolItemWindow", IGUIWindow)
---@type CustomGiftConfig
local CustomGiftConfig = T(Global, "CustomGiftConfig")
---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")
---@type GUIGameCustomGiftPoolSelectItemWindow
local GUIGameCustomGiftPoolSelectItem = UIHelper.requireGUIWindow("GUIGameCustomGiftPoolSelectItem", false, "ui_activity")

---@private
function GUIGameCustomGiftPoolItemWindow:ctor(...)
	self.super.ctor(self, "GameCustomGiftPoolItem.json", ...)
end

---@private
function GUIGameCustomGiftPoolItemWindow:onLoad(mgr)
	self.mgr = mgr
	self.siSelectBg = self:getChildWindowByName("GameCustomGiftPoolItem-SelectBg", GUIType.StaticImage)
	self.llRewardRoot = self:getChildWindowByName("GameCustomGiftPoolItem-RewardRoot", GUIType.Layout)
	self.siArrow = self:getChildWindowByName("GameCustomGiftPoolItem-Arrow", GUIType.StaticImage)
	self.siItemListBg = self:getChildWindowByName("GameCustomGiftPoolItem-ItemListBg", GUIType.StaticImage)
	self.siAddContent = self:getChildWindowByName("GameCustomGiftPoolItem-AddContent", GUIType.StaticImage)
	self.lhItemList = self:getChildWindowByName("GameCustomGiftPoolItem-ItemList", GUIType.ListHorizontal)
	self.lhItemList:SetInterval(10)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameCustomGiftPoolItemWindow:initView()

end

---@private
function GUIGameCustomGiftPoolItemWindow:initEvent()
	self.eventList = {}
	self.eventList[#self.eventList + 1] = self.mgr:registerEvent("CustomGiftRewardChoose", function(giftId, cellId, index)
		if self.giftId == giftId and self.cellId == cellId then
			self:setChooseRewardData(cellId, index)
		end
	end)
end

function GUIGameCustomGiftPoolItemWindow:setChooseRewardData(cellId, index)
	self.siAddContent:SetVisible(false)
	self.llRewardRoot:SetVisible(true)
	local rewardData = CustomGiftConfig:getCellRewardDataByIndex(cellId, index)
	self:refreshChooseReward(rewardData)
end

function GUIGameCustomGiftPoolItemWindow:refreshChooseReward(rewardData)
	if not self.commonRewardItem then
		self.commonRewardItem = GUIGameActivityRewardItem.new()
		self.llRewardRoot:AddChildWindow(self.commonRewardItem.root)
		self.commonRewardItem.root:SetWidth({1, 0})
		self.commonRewardItem.root:SetHeight({1, 0})
	end
	local rewardCfg = TableUtil.copyTable(CommonActivityConfig:getRewardById(rewardData.rewardId))
	rewardCfg.num = rewardData.num
	local showNum = tonumber(rewardCfg.numLang)
	if showNum then
		rewardCfg.numLang = tostring(rewardData.num)
	end
	self.commonRewardItem:setRewardData(rewardCfg)
	self.commonRewardItem:SetUpEffect(rewardCfg.upProbability)
end

function GUIGameCustomGiftPoolItemWindow:initPoolRewardItem(rewardPool)
	for index, _ in ipairs(rewardPool) do
		local item = GUIGameCustomGiftPoolSelectItem.new(self.mgr)
		item:setData(self.giftId, self.cellId, index)
		self.lhItemList:AddItem(item.root)
	end
end

function GUIGameCustomGiftPoolItemWindow:initChooseRewardData()
	local rewardData = self.mgr:getGiftCellChooseRewardData(self.giftId, self.cellId)
	if next(rewardData) then
		self.siAddContent:SetVisible(false)
		self.llRewardRoot:SetVisible(true)
		self:refreshChooseReward(rewardData)
	else
		self.siAddContent:SetVisible(true)
		self.llRewardRoot:SetVisible(false)
	end
end

---@param data table
function GUIGameCustomGiftPoolItemWindow:setData(giftId, cellId)
	self.giftId = giftId
	self.cellId = cellId
	local cellCfg = CustomGiftConfig:getCellCfg(cellId)
	self:initChooseRewardData()
	self:initPoolRewardItem(cellCfg.rewardPool)
end

function GUIGameCustomGiftPoolItemWindow:onDestroy()
	for i, event in pairs(self.eventList) do
		event()
	end
	self.eventList = {}
end

return GUIGameCustomGiftPoolItemWindow
