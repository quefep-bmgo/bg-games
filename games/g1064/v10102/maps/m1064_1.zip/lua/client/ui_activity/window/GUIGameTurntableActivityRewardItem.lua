---@class GUIGameTurntableActivityRewardItemWindow : IGUIWindow
local GUIGameTurntableActivityRewardItemWindow = class("GUIGameTurntableActivityRewardItemWindow", IGUIWindow)

---@private
function GUIGameTurntableActivityRewardItemWindow:ctor(...)
	self.super.ctor(self, "GameTurntableActivityRewardItem.json", ...)
end

---@private
function GUIGameTurntableActivityRewardItemWindow:onLoad()
	self.siIcon = self:getChildWindowByName("GameTurntableActivityRewardItem-Icon", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("GameTurntableActivityRewardItem-Num", GUIType.StaticText)
	self.siMask = self:getChildWindowByName("GameTurntableActivityRewardItem-Mask", GUIType.StaticImage)
	self.siSelect = self:getChildWindowByName("GameTurntableActivityRewardItem-Select", GUIType.StaticImage)

	self:initView()
	self:initEvent()
end

---@private
function GUIGameTurntableActivityRewardItemWindow:initView()
	self.siMask:SetVisible(false)
	self.siSelect:SetVisible(false)
	self.stNum:SetXPosition({0, -25})
	self.stNum:SetYPosition({0, -30})
end

---@private
function GUIGameTurntableActivityRewardItemWindow:initEvent()
	self.siIcon:registerEvent(GUIEvent.Click, function()
		if self.data then
			GUICommonActivityRewardDetail:show(self.data.reward.showDetailId)
		end
	end)
end

---@param data CommonActivityRewardWeightData
function GUIGameTurntableActivityRewardItemWindow:onDataChanged(data)
	self.data = data
	self.siIcon:SetImage(data.reward.image)
	if data.reward.imageScale ~= "#" then
		self.siIcon:SetArea({ 0, 0 }, { 0, 0 }, { data.reward.imageScale, 0 }, { data.reward.imageScale, 0 })
	end
	self.stNum:SetVisible(data.reward.num > 1)
	self.stNum:SetText("X" .. data.reward.numLang)
end

function GUIGameTurntableActivityRewardItemWindow:showMask(isShow)
	self.siMask:SetVisible(isShow)
end

function GUIGameTurntableActivityRewardItemWindow:showSelect(isShow, time)
	LuaTimer:cancel(self.selectTimer or 0)
	self.siSelect:SetVisible(isShow)
	if isShow and time and time > 0 then
		self.selectTimer = LuaTimer:schedule(function()
			self.siSelect:SetVisible(false)
		end, time)
	end
end

return GUIGameTurntableActivityRewardItemWindow
