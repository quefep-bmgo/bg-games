---@class GUIGameScoreActivityRewardItem6Window : IGUIWindow
local GUIGameScoreActivityRewardItem6Window = class("GUIGameScoreActivityRewardItem6Window", IGUIWindow)

---@private
function GUIGameScoreActivityRewardItem6Window:ctor(_, mgr)
    self.super.ctor(self, "GameScoreActivityRewardItem6.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItem6Window:onLoad(mgr)
    self.mgr = mgr
    self.siBg = self:getChildWindowByName("GameScoreActivityRewardItem6", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem6-Image", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("GameScoreActivityRewardItem6-Count", GUIType.StaticText)
    self.siLimitBg = self:getChildWindowByName("GameScoreActivityRewardItem6-Limit-Bg", GUIType.StaticImage)
    self.siLimitIcon = self:getChildWindowByName("GameScoreActivityRewardItem6-LimitIcon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("GameScoreActivityRewardItem6-Limit", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("GameScoreActivityRewardItem6-Score", GUIType.StaticText)
    self.stPriceAdd = self:getChildWindowByName("GameScoreActivityRewardItem6-Add", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("GameScoreActivityRewardItem6-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameScoreActivityRewardItem6-Price", GUIType.StaticText)
    self.llMask = self:getChildWindowByName("GameScoreActivityRewardItem6-Mask", GUIType.Layout)
    self.siSelected = self:getChildWindowByName("GameScoreActivityRewardItem6-Selected", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItem6Window:initView()
    self.stPriceAdd:SetText("+")
end

---@private
function GUIGameScoreActivityRewardItem6Window:initEvent()
    self.siBg:registerEvent(GUIEvent.Click, function()
        if not self.data then
            return
        end
        Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
    end)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityRewardItem6Window:onDataChanged(data)
    self.data = data
    UIHelper:setImageAdjustSize(self.siImage, data.reward.image, 100, 100, tonumber(data.reward.imageScale))
    if data.reward.numLang ~= "#" then
        self.stCount:SetText("x" .. Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    self.stScore:SetText(data.score)
    if data.price <= 0 then
        self.siPriceIcon:SetVisible(false)
        self.stPriceAdd:SetVisible(false)
    else
        self.stPriceAdd:SetVisible(true)
        self.siPriceIcon:SetVisible(true)
        local width = self.stScore:GetTextWidth()
        self.stPriceAdd:SetXPosition({ 0, 32 + width })
        self.siPriceIcon:SetXPosition({ 0, 52 + width })
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
        self.stPrice:SetText(data.price)
    end
    if data.limit <= 0 then
        self.siLimitBg:SetVisible(false)
    else
        self.siLimitBg:SetVisible(data.limit > 1)
        local limit = self.mgr:getRewardLimit(data)
        if limit > 0 then
            self.stLimit:SetText(limit .. "/" .. data.limit)
            self.llMask:SetVisible(false)
        else
            self.llMask:SetVisible(true)
            self.stLimit:SetText(TextFormat.colorRed .. "0" .. TextFormat.colorWrite .. "/" .. data.limit)
        end
    end
    self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)
    if not self.first then
        self.first = true
        if data.isGrandPrize then
            Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
        end
    end
end

return GUIGameScoreActivityRewardItem6Window
