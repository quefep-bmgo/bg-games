local handler = class("CommonPacketHandler", EventObservable)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")

function handler:init()
    self:registerDataCallBack("OpenLotteryBox", self.onPlayerOpenLotteryBox)
    self:registerDataCallBack("UseMovieTicket", self.onPlayerUseMovieTicket)
    self:registerDataCallBack("ReportFriendCount", self.onReportFriendCount)
    self:registerDataCallBack("NoShowSuitTipToday", self.onNoShowSuitTipToday)
    self:registerDataCallBack("TeleportHallInitPos", self.onTeleportHallInitPos)
    self:registerDataCallBack("UpgradePet", self.onUpgradePet)
    self:registerDataCallBack("SavePetRandomSkill", self.onSavePetRandomSkill)
    self:registerDataCallBack("BuyPetRandomSkill", self.onBuyPetRandomSkill)
    self:registerDataCallBack("SavePetRedDotRecord", self.onSavePetRedDotRecord)
end

function handler.onPlayerOpenLotteryBox(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local chestId = builder:getNumberParam("chestId")
    local num = builder:getNumberParam("num")
    GameChestLottery:onPlayerOpenLotteryChest(player, chestId, math.max(num, 1))
end

function handler.onPlayerUseMovieTicket(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    if player:subTicket(1) then
        local params = DataBuilder.new():fromData(data):getNumberParam("params")
        local type =DataBuilder.new():fromData(data):getNumberParam("type")
        CEvents.WatchAdvertFinishedEvent:invoke(player.rakssid, type, params, 1)
    end
end

function handler.onReportFriendCount(userId, data)
    local FriendCount = DataBuilder.new():fromData(data):getNumberParam("count")
    PlayerCustomInfoUtil:reportCustomInfo(userId, "int", Define.PlayerCustomInfo.FriendCount, FriendCount, "2")
end

function handler.onNoShowSuitTipToday(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    player.noShowSuitChangeTip = true
end

function handler.onTeleportHallInitPos(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local randomPos = MathUtil:randomDoubleInCircle(GameConfig.waitPos, GameConfig.initPosRange)
    player:teleportPos({x = math.floor(randomPos.x), y = math.floor(randomPos.y), z = math.floor(randomPos.z)})
end

function handler.onUpgradePet(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    PetUpgradeShop:onUpgradePet(player, data)
end

--宠物保存随机技能结果
function handler.onSavePetRandomSkill(userId, petId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    PetUpgradeShop:onSavePetRandomSkill(player, petId)
end

--宠物购买随机技能
function handler.onBuyPetRandomSkill(userId, petId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    PetUpgradeShop:onBuyPetRandomSkill(player, petId)
end

function handler.onSavePetRedDotRecord(userId, redDotType)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local petRedDotData = player.petRedDotData
    if not petRedDotData then
        petRedDotData = {}
        player.petRedDotData = petRedDotData
    end
    petRedDotData[redDotType] = 0
end

handler:init()