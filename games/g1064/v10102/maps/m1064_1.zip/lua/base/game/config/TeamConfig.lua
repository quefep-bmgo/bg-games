---
--- Created by Jimmy.
--- DateTime: 2017/10/20 0020 14:49
---
local Teams = {}
---@type IArea[]
local TeamAreas = {}

TeamConfig = {}

local function initTeams(teams)
    for _, item in pairs(teams) do
        if tonumber(GameConfig.mapId) == tonumber(item.mapId) then
            local id = tonumber(item.id)
            ---@class TeamConfigInfo
            local info = {}
            Teams[id] = info
            info.id = id
            info.name = tostring(item.name)
            info.initPos = VectorUtil.str2Vector3i(item.initPos)
            info.initYaw = item.initYaw or 0
            info.resourcePointId = StringUtil.split(item.resourcePointId, "#")

            info.bedPos = {}
            if item.bedPos then
                local bedPos = StringUtil.split(item.bedPos, "#")
                info.bedPos[1] = VectorUtil.str2Vector3i(bedPos[1])
                info.bedPos[2] = VectorUtil.str2Vector3i(bedPos[2])
            else
                info.bedPos[1] = VectorUtil.newVector3i(item.bedStartPosX, item.bedStartPosY, item.bedStartPosZ)
                info.bedPos[2] = VectorUtil.newVector3i(item.bedEndPosX, item.bedEndPosY, item.bedEndPosZ)
            end

            if isClient then
                local bedBlock = cBlockManager.cGetBlockById(BlockID.BED)
                if bedBlock then
                    bedBlock:setPositionValue(info.bedPos[1], id - 1)
                    bedBlock:setPositionValue(info.bedPos[2], id - 1)
                end
            end

            info.bedYaw = tonumber(item.bedYaw or 0)
            info.schemeticGroupId = tonumber(item.schemeticGroupId or 0)
            info.clothBlockId = tonumber(item.clothBlockId or 35)
            info.doubleDummyId = tonumber(item.doubleDummyId or ItemID.DOUBLE_DUMMY)
            if item.cannotPlaceBlock then
                local cannotPlacePos = StringUtil.split(tostring(item.cannotPlaceBlock), "#")
                local area = IArea.new()
                area:initByPos(VectorUtil.str2Vector3(cannotPlacePos[1]), VectorUtil.str2Vector3(cannotPlacePos[2]))
                TeamAreas[id] = area
            end
            info.playerInArea = {}
            info.initItems = StringUtil.split(tostring(item.initItems), "#", false, true)
            local homePos = StringUtil.split(tostring(item.homeAreaPos), "#")
            if #homePos < 2 then
                homePos = { "0,0,0", "0,0,0" }
            end
            local homeArea = IArea.new()
            homeArea:initByPos(VectorUtil.str2Vector3(homePos[1]), VectorUtil.str2Vector3(homePos[2]))
            info.homeArea = homeArea
        end
    end
end

function TeamConfig:getTeams()
    return Teams
end

function TeamConfig:getTeamCount()
    return #Teams
end

function TeamConfig:getTeam(id)
    local team = Teams[tonumber(id)]
    if team == nil then
        team = Teams[1]
    end
    return team
end

function TeamConfig:isInTeamArea(vec3)
    for _, area in pairs(TeamAreas) do
        local inArea = area:inArea(vec3)
        if inArea then
            return true
        end
    end
    return false
end

function TeamConfig:onPlayerMove(player, x, y, z)
    if not isGameStart then
        return
    end
    for teamId, team in pairs(Teams) do
        ---检查玩家是否在家.
        if tostring(teamId) == tostring(player.teamId) then
            if team.homeArea:inArea(VectorUtil.newVector3(x, y, z)) then
                player.info:setValue("inHome", "1")
            else
                player.info:setValue("inHome", "0")
            end
        end
    end
end

function TeamConfig:isBeChecked(id, playerInArea)
    for _, userId in pairs(playerInArea) do
        if id == userId then
            return true
        end
    end
    return false
end

function TeamConfig:getTeamMaxMinDiff()
    local max = 0
    local min = 9999
    if Teams then
        for _, team in pairs(Teams) do
            local teamInfo = GameMatch.Teams[team.id]
            if teamInfo then
                if teamInfo.curPlayers and teamInfo.curPlayers > max then
                    max = teamInfo.curPlayers
                end
                if teamInfo.curPlayers and teamInfo.curPlayers < min then
                    min = teamInfo.curPlayers
                end
            else
                min = 0
            end
        end
        if max - min >= 0 then
            return max - min
        else
            return -1
        end
    end
    return -1
end

function TeamConfig:getTeamHeadItemId(teamId)
    local team = Teams[teamId]
    if not team then
        return 298
    end
    for _, itemId in pairs(team.initItems) do
        if ItemMapping:getOldItemId(itemId) == ItemID.HELMET_LEATHER then
            return itemId
        end
    end
    return 298
end

initTeams(FileUtil.getConfigFromCsv("setting/TeamConfig.csv"))
