--- @class System
local System = class("System")

--- @param world GameWorld
function System:ctor(world)
    self.enabled = true
    self.world = world
end

function System:isEnabled()
    return self.enabled
end

function System:getWorld()
    return self.world
end

function System:setEnabled(enable)
    if not self.enabled and enable then
        self.enabled = true
        self:onEnabled()

    elseif self.enabled and not enable then
        self.enabled = false
        self:onDisabled()
    end
    return self
end

function System:onEnabled()

end

function System:onUpdate(frameTime)

end

function System:onDisabled()

end

return System