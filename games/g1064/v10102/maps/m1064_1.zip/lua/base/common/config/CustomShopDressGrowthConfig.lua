---@class CustomShopDressGrowthConfig
local CustomShopDressGrowthConfig = T(Global, "CustomShopDressGrowthConfig")
---@type CustomShopDressGrowthData[]
local GrowthInfo = {}

function CustomShopDressGrowthConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/CustomShopDressGrowth.csv")
    for _, item in pairs(config) do
        ---@class CustomShopDressGrowthData
        local data = {
            index = tonumber(item.index),
            itemId = tonumber(item.itemId),
            type = tonumber(item.type),
            lv = tonumber(item.lv),
            exp = tonumber(item.exp),
            isMaxLv = item.exp == "#" and true,
            params = StringUtil.split(item.params or "", "#"),
            lang = item.lang,
        }
        if not GrowthInfo[tostring(data.itemId)] then
            GrowthInfo[tostring(data.itemId)] = {}
        end
        table.insert(GrowthInfo[tostring(data.itemId)], data)
    end
    for _, info in pairs(GrowthInfo) do
        table.sort(info, function(a, b)
            return a.lv < b.lv
        end)
    end
end

function CustomShopDressGrowthConfig:getAllCfg()
    return GrowthInfo
end

function CustomShopDressGrowthConfig:getDressGrowthInfoByItemId(itemId)
    if not GrowthInfo[tostring(itemId)] then
        return
    end
    return TableUtil.copyTable(GrowthInfo[tostring(itemId)])
end

function CustomShopDressGrowthConfig:getDressGrowthTypeByItemId(itemId)
    local type = 0
    if not GrowthInfo[tostring(itemId)] then
        return type
    end
    for _, v in pairs(GrowthInfo[tostring(itemId)]) do
        type = v.type
        break
    end
    return type
end

function CustomShopDressGrowthConfig:getDressMaxGrowthInfoByItemId(itemId)
    if not GrowthInfo[tostring(itemId)] then
        return
    end
    local data = {}
    for _, v in pairs(GrowthInfo[tostring(itemId)]) do
        if v.isMaxLv then
            data = v
        end
    end
    return TableUtil.copyTable(data)
end

function CustomShopDressGrowthConfig:getDressGrowthInfoByItemIdAndProgress(itemId, progress)
    if not GrowthInfo[tostring(itemId)] then
        return
    end
    if not progress then
        progress = 0
    end
    local data
    local curExp = 0
    local curProgress = 0
    for _, info in pairs(GrowthInfo[tostring(itemId)]) do
        local oldExp = curExp
        if info.isMaxLv then
            if oldExp <= progress then
                curProgress = progress - oldExp
                data = info
                break
            end
        else
            curExp = curExp + info.exp
            if oldExp <= progress and curExp > progress then
                curProgress = progress - oldExp
                data = info
                break
            end
        end
    end
    return data, curProgress
end

CustomShopDressGrowthConfig:init()
