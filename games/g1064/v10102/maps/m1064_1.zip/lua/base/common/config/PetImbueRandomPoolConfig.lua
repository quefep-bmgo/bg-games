

---@class PetImbueRandomPoolConfig
local PetImbueRandomPoolConfig = T(Global, "PetImbueRandomPoolConfig")
local Config = {}

function PetImbueRandomPoolConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/PetImbueRandomPool.csv")
    for _, vConfig in pairs(config) do
        local data = {
            id = tonumber(vConfig.id),
            imbueGroupId = tonumber(vConfig.imbueGroupId),
            weight = tonumber(vConfig.weight),
            isNew = tonumber(vConfig.isNew),
        }
        Config[data.id] = data
    end
end

function PetImbueRandomPoolConfig:randomWeightsPool(pool, num, ifReduce, ignoreImbueGroupId)
    local _pool = {}
    local weightSum = 0
    for _, item in pairs(pool) do
        if ignoreImbueGroupId ~= item.imbueGroupId then
            weightSum = weightSum + item.weight
            table.insert(_pool, item)
        end
    end
    if #_pool == 0 then
        return nil
    end
    local ret = {}
    for i=1, num do
        local random = math.random(1, weightSum)
        local weightTag = 0
        for index, item in pairs(_pool) do
            weightTag = weightTag + item.weight
            if weightTag >= random then
                table.insert(ret, item)
                if ifReduce then
                    table.remove(_pool, index)
                    weightSum = weightSum - item.weight
                end
                break
            end
        end
    end
    return ret
end

function PetImbueRandomPoolConfig:getRandomResult(ignoreImbueGroupId)
    return self:randomWeightsPool(Config, 1, false, ignoreImbueGroupId)
end

function PetImbueRandomPoolConfig:getAllCfgs()
    return Config
end

if GameType ~= "g1064" then
    PetImbueRandomPoolConfig:init()
end

return PetImbueRandomPoolConfig