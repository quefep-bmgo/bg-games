
local GameObject = require "common.entity_extend.gameobject"

---@class EntityExtendUtils
EntityExtendUtils = {}

function EntityExtendUtils.extendGameObject(target)
    if not target._components then
        return GameObject.extend(target)
    end
    return target
end
