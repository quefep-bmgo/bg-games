---@class ArmorEffectConfig
local ArmorEffectConfig = T(Global, "ArmorEffectConfig")
---@type ArmorEffectData[]
local Settings = {}

local ArmorEffectMap = {}

function ArmorEffectConfig:init()
	local config = FileUtil.getConfigFromCsv("setting/ArmorEffect.csv", 2, true, true)
	for _, item in pairs(config or {}) do
		---@class ArmorEffectData
		local data = {
			index = tonumber(item.index),
			armorIds = StringUtil.split(item.armorIds, "#", false, true),
			mainArmorId = tonumber(item.mainArmorId),
			effect = item.effect or "",
			duration = tonumber(item.duration),
			cd = tonumber(item.cd),
			scale = tonumber(item.scale),
		}
		Settings[data.mainArmorId] = data
		for _, armorId in pairs(data.armorIds) do
			ArmorEffectMap[armorId] = data
		end
	end
end

function ArmorEffectConfig:getAllCfg()
	return Settings
end

function ArmorEffectConfig:getArmorEffectByIds(ids)
	for _, id in pairs(ids or {}) do
		if Settings[id] then
			return TableUtil.copyTable(Settings[id])
		end
	end

	for _, id in pairs(ids or {}) do
		if ArmorEffectMap[id] then
			return TableUtil.copyTable(ArmorEffectMap[id])
		end
	end
	return
end

ArmorEffectConfig:init()
