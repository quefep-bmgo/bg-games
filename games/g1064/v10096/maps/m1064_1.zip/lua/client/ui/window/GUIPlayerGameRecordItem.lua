---@class GUIPlayerGameRecordItemWindow : IGUIWindow
local GUIPlayerGameRecordItemWindow = class("GUIPlayerGameRecordItemWindow", IGUIWindow)

---@private
function GUIPlayerGameRecordItemWindow:ctor(...)
	self.super.ctor(self, "PlayerGameRecordItem.json", ...)
end

---@private
function GUIPlayerGameRecordItemWindow:onLoad()
	self.stRecordGameCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Game-Count", GUIType.StaticText)
	self.stRecordGameDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Game-Desc", GUIType.StaticText)
	self.siRecordGameIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Game-Icon", GUIType.StaticImage)
end

function GUIPlayerGameRecordItemWindow:onDataChanged(info)
	self.stRecordGameCount:SetText(info.count)
	self.stRecordGameDesc:SetText(Lang:getString(info.desc))
	self.siRecordGameIcon:SetImage(info.icon)
end

return GUIPlayerGameRecordItemWindow
