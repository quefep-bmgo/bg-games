---@class GUIQualifyingInTeamPlayerItemWindow : IGUIWindow
local GUIQualifyingInTeamPlayerItemWindow = class("GUIQualifyingInTeamPlayerItemWindow", IGUIWindow)
---@type TeamService
local TeamService = T(Global, "TeamService")
---@type FriendManager
local FriendManager = T(Global, "FriendManager")
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

---@private
---@param parent UIBedWarQualifyingLayout
function GUIQualifyingInTeamPlayerItemWindow:ctor(parent)
    self.super.ctor(self, "QualifyingInTeamPlayerItem.json")
    self.parent = parent
end

---@private
function GUIQualifyingInTeamPlayerItemWindow:onLoad()
    self.siWait = self:getChildWindowByName("QualifyingInTeamPlayerItem-Wait", GUIType.StaticImage)
    self.llInfo = self:getChildWindowByName("QualifyingInTeamPlayerItem-Info", GUIType.Layout)
    self.awActor = self:getChildWindowByName("QualifyingInTeamPlayerItem-Actor", GUIType.ActorWindow)
    self.siNameBg = self:getChildWindowByName("QualifyingInTeamPlayerItem-Name-Bg", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("QualifyingInTeamPlayerItem-Name", GUIType.StaticText)
    self.siHonorIcon = self:getChildWindowByName("QualifyingInTeamPlayerItem-HonorIcon", GUIType.StaticImage)
    self.stHonorText = self:getChildWindowByName("QualifyingInTeamPlayerItem-HonorText", GUIType.StaticText)
    self.btnAddFriend = self:getChildWindowByName("QualifyingInTeamPlayerItem-AddFriend", GUIType.StaticImage)
    self.siChatBubble = self:getChildWindowByName("QualifyingInTeamPlayerItem-Chat-Bubble", GUIType.StaticImage)
    self.stChatText = self:getChildWindowByName("QualifyingInTeamPlayerItem-Chat-Text", GUIType.StaticText)
    self.siChatEmoji = self:getChildWindowByName("QualifyingInTeamPlayerItem-Chat-Emoji", GUIType.StaticImage)
    self.siKickOut = self:getChildWindowByName("QualifyingInTeamPlayerItem-KickOut", GUIType.StaticImage)
    self.llTitle = self:getChildWindowByName("QualifyingInTeamPlayerItem-Title", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIQualifyingInTeamPlayerItemWindow:initView()
    self.siChatBubble:SetVisible(false)

    ---@type GUIBedWarPersonalTitleShowItem
    self.showTitleItem = UIHelper.newGameGUIWindow("GUIBedWarPersonalTitleShowItem")
    self.llTitle:AddChildWindow(self.showTitleItem.root)
end

---@private
function GUIQualifyingInTeamPlayerItemWindow:initEvent()
    self.btnAddFriend:registerEvent(GUIEvent.Click, function()
        self.btnAddFriend:SetVisible(false)
        FriendManager.FriendOperation(Define.FriendOperationType.Request, self.userId)
        self:updateAddFriendAndKickBtnPos()
    end)
    self.siKickOut:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.kick.out.team.tip"))
                    .setRightClickListener(function()
            if self.userId then
                TeamService:kickOutTeammate(self.userId)
            end
        end)        .show()
    end)
    self.siWait:registerEvent(GUIEvent.Click, function()
        GUISelectTeamInviteListLayout:show(self.parent.root, true)
    end)
end

---@private
function GUIQualifyingInTeamPlayerItemWindow:updateAddFriendAndKickBtnPos()
    local friendVisible = self.btnAddFriend:IsVisible()
    local kickVisible = self.siKickOut:IsVisible()

    if (friendVisible and kickVisible) or (not friendVisible and not kickVisible) then
        self.btnAddFriend:SetXPosition({0, -28})
        self.siKickOut:SetXPosition({0, 28})
    elseif not friendVisible and kickVisible then
        self.siKickOut:SetXPosition({0, 0})

    elseif friendVisible and not kickVisible then
        self.btnAddFriend:SetXPosition({0, 0})
    end
end

---@param data BedWarUserInfo
function GUIQualifyingInTeamPlayerItemWindow:onDataChanged(data, index)
    if not data then
        self.llInfo:SetVisible(false)
        self.siWait:SetVisible(TeamService:getTeammateCount() == index - 1)
        self.userId = nil
        return
    end
    self.userId = data.userId
    self.siWait:SetVisible(false)
    self.llInfo:SetVisible(true)
    -- 引擎关于 ArmorHeadNoFaceMap 有bug, 原来的逻辑是最后才根据配置设置 GUICustomShop:useBodyPart("custom_face", "")
    -- 后来被改成了根据穿戴的装备去覆盖预览的装备
    -- 某些 actorWindow需要, 某些actorWindow不需要
    if not next(ArmorHeadNoFaceMap) then
        ArmorHeadNoFaceMap = TableUtil.copyTable(PlayerManager:getClientPlayer().ArmorHeadNoFaceMap)
    end
    self.awActor:SetActorByUserId(data.userId)
    --if index == 3 then
    --    self.awActor:SetWidth({ 0.65, 0 })
    --    self.siNameBg:SetYPosition({ 0.3, 0 })
    --    self.llTitle:SetYPosition({ 0.3, -110 })
    --else
    --    self.awActor:SetWidth({ 0.9 - (index - 1) * 0.1, 0 })
    --    self.siNameBg:SetYPosition({ (index - 3) * 0.1, 0 })
    --    self.llTitle:SetYPosition({ (index - 3) * 0.1, -110 })
    --end

    self.root:SetWidth({0, 160 * (1 - ((index - 1) * 0.1)) })
    self.root:SetHeight({0, 370 * (1 - ((index - 1) * 0.1)) })
    --self.siNameBg:SetYPosition({ (index - 1) * 0.1, 0 })

    self.stName:SetText(TextFormat.colorGreen .. "Lv." .. (data.playerLevel or 1) .. TextFormat.colorWrite .. "   " .. data.name)
    self.siNameBg:SetWidth({ 0, self.stName:GetTextWidth() + 30 })
    self.btnAddFriend:SetVisible(data.userId ~= Game:getPlatformUserId() and not data.friend)
    self.siKickOut:SetVisible(data.userId ~= Game:getPlatformUserId() and TeamService:isOwner())
    QualifyingTool.setQualifyingSegmentInListUI(self.siHonorIcon, self.stHonorText, data.qualifyingData)

    self.showTitleItem:onDataChanged(data.currTitle)
    PlayerCustomInfoUtil:getPlayerCustomInfo(data.userId, { Define.PlayerCustomInfo.CurrTitle }, function()
        if self.isDestroy then
            return
        end
        local userInfo = UserInfoCache:GetCache(self.userId)
        if userInfo then
            self.showTitleItem:onDataChanged(userInfo.currTitle)
        end
    end)

    self:updateAddFriendAndKickBtnPos()
end

---@param chatMsg ChatMsgData
function GUIQualifyingInTeamPlayerItemWindow:tryShowChatText(chatMsg)
    if chatMsg.sendId ~= self.userId then
        return
    end
    if chatMsg.type == Define.ChatMsgType.TextMsg then
        local text = chatMsg.data.content
        local width = math.min(200, math.max(self.stChatText:GetFont():GetTextExtent(text, 1) + 25, 90))
        self.siChatBubble:SetWidth({ 0, width })
        self.stChatText:SetVisible(true)
        self.siChatEmoji:SetVisible(false)
        self.stChatText:SetText(text)
        self.siChatBubble:SetHeight({ 0, math.max(62, self.stChatText:GetTextHeight() + 30) })
    elseif chatMsg.type == Define.ChatMsgType.CustomMsg and chatMsg.data.content.type == Define.CustomChatMsgType.EmojiMsg then
        self.stChatText:SetVisible(false)
        self.siChatEmoji:SetVisible(true)
        self.siChatBubble:SetWidth({ 0, 100 })
        self.siChatBubble:SetHeight({ 0, 115 })
        local config = EmojiConfig:getCfgById(chatMsg.data.content.emojiId)
        self.siChatEmoji:SetImage(config.icon)
    else
        return
    end
    LuaTimer:cancel(self.chatTimerKey)
    self.siChatBubble:SetVisible(true)
    self.chatTimerKey = LuaTimer:schedule(function()
        self.siChatBubble:SetVisible(false)
    end, 5000)
end

function GUIQualifyingInTeamPlayerItemWindow:onDestroy()
    self.isDestroy = true
end

return GUIQualifyingInTeamPlayerItemWindow
