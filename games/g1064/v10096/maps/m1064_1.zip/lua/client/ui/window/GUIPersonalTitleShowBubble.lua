---@class PersonalTitleShowBubbleWindow : IGUIWindow
local PersonalTitleShowBubbleWindow = class("PersonalTitleShowBubbleWindow", IGUIWindow)

---@private
function PersonalTitleShowBubbleWindow:ctor(...)
    self.super.ctor(self, "PersonalTitleShowBubble.json", ...)
end

---@private
function PersonalTitleShowBubbleWindow:onLoad()
    ---@type GUIBedWarPersonalTitleShowItem
    self.showTitleItem = UIHelper.newGameGUIWindow("GUIBedWarPersonalTitleShowItem")
    self.root:AddChildWindow(self.showTitleItem.root)
end

function PersonalTitleShowBubbleWindow:showTitle(userId, titleId)
    self.showTitleItem:showEffect()
    self.showTitleItem:onDataChanged(titleId)

    ---@type ClientPlayer
    local player = PlayerManager:getPlayerByUserId(userId)
    if player then
        self.root:SetVisible(false)
        player:showPlayerSceneUI(self)

        self.luaKey = LuaTimer:schedule(function()
            self.luaKey = nil
            ---@type ClientPlayer
            local player = PlayerManager:getPlayerByUserId(userId)
            if player then
                player:hidePlayerSceneUI(self)
                self:tryDestroy()
            end
        end, 5000)
    end
end

function PersonalTitleShowBubbleWindow:updateSceneUI(visible, screenPos, distance)
    if not visible then
        self.root:SetVisible(false)
        return
    end

    self.root:SetVisible(true)

    local x = math.max(1, 256 * (1 - distance * 0.03))
    local y = math.max(1, 128 * (1 - distance * 0.03))

    --self.root:SetXPosition({ screenPos.x, -0.5 * x })
    local halfOffset = 0.5 * y
    local offsetY = halfOffset + halfOffset * (distance / 30)
    --self.root:SetYPosition({ screenPos.y, -offsetY })

    self.root:SetArea({ screenPos.x, -0.5 * x }, { screenPos.y, -offsetY - (60 / distance) }, {0, x}, {0, y} )
end

function PersonalTitleShowBubbleWindow:onDataChanged()

end

function PersonalTitleShowBubbleWindow:tryDestroy()
    if self.luaKey then
        LuaTimer:cancel(self.luaKey)
        self.luaKey = nil
    end
    GUIManager:destroyGUIWindow(self.root)
end

return PersonalTitleShowBubbleWindow
