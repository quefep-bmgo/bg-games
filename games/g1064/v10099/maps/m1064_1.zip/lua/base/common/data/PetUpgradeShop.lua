---@class PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")
---@type PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")
---@type PetImbueRandomPoolConfig
local PetImbueRandomPoolConfig = T(Global, "PetImbueRandomPoolConfig")

function PetUpgradeShop:init()

end

function PetUpgradeShop:onUpgradePet(player, petId)
    local data = player.petData
    local lv = data[tostring(petId)] or -1
    if PetLvConfig:isMaxLv(petId, lv) then
        return
    end
    local nextLv = lv + 1
    local imbueGroupId = player.randomSkillData[tostring(petId)] or PetLvConfig:getPetDefaultImbueGroupId(petId)
    local config = PetLvConfig:getConfigByLv(petId, nextLv, imbueGroupId)
    if isClient then
        PayHelper.checkMoney(config.moneyType, config.price, function(canBuy)
            if canBuy then
                CommonPacketSender:sendUpgradePet(petId)
            else
            end
        end)
    else
        if config.moneyType == Define.Money.PET_CANDY and MoneyUtil:checkHasMoney(player, config.moneyType, config.price) then
            if player:subPetCandy(config.price) then
                self:onUpgradePetSuss(player, petId)
            end
        end
    end
end

function PetUpgradeShop:onUpgradePetSuss(player, petId)
    local data = player.petData
    local lv = data[tostring(petId)] or -1
    if PetLvConfig:isMaxLv(petId, lv) then        return
    end
    player.petData[tostring(petId)] = lv + 1
    local params = {}
    params[tostring(petId)] = lv + 1
    ServerReportEvent.pet_upgrade(player, tonumber(petId), lv + 1)
    CommonPacketSender:sendSyncPetLvData(player.rakssid, params)
end

function PetUpgradeShop:isMaxLv(player, petId)
    local data = player.petData
    local lv = data[tostring(petId)] or -1
    return PetLvConfig:isMaxLv(petId, lv)
end

function PetUpgradeShop:syncPetLvData(player)
    CommonPacketSender:sendSyncPetLvData(player.rakssid, player.petData)
end

function PetUpgradeShop:syncSyncPetChangeSkillData(player)
    CommonPacketSender:sendSyncPetChangeSkillData(player.rakssid, player.randomSkillData)
end

function PetUpgradeShop:checkCanEquip(player, petId, ignoreIndex)
    local canEquipSame = PetLvConfig:getCanEquipSame(petId)
    if not canEquipSame then
        local data = player.petData
        local lv = data[tostring(petId)] or 0
        local imbueGroupId = player.randomSkillData[tostring(petId)] or PetLvConfig:getPetDefaultImbueGroupId(petId)
        local config = PetLvConfig:getConfigByLv(petId, lv, imbueGroupId)
        local info = isClient and GameInfoManager:getPlayerInfo(Game:getPlatformUserId()) or player.info
        if not info then
            return true
        end
        local petsStr = info:getValue("curPets")
        local pets = StringUtil.split(petsStr, ",", false, true)
        ignoreIndex = ignoreIndex or 0
        if type(pets) == "table" then
            for index, _petId in pairs(pets) do
                if _petId ~= 0 and index ~= ignoreIndex then
                    local _lv = data[tostring(_petId)] or 0
                    local imbueGroupId = player.randomSkillData[tostring(petId)] or PetLvConfig:getPetDefaultImbueGroupId(petId)
                    local _config = PetLvConfig:getConfigByLv(_petId, _lv, imbueGroupId)
                    if config.imbueType == _config.imbueType then
                        return false
                    end
                end
            end
        end
    end
    return true
end

function PetUpgradeShop:onPetChangeSkill(player, petId)

end

function PetUpgradeShop:onBuyPetRandomSkill(player, petId)
    if isClient then
        --local money = PlayerWallet.getMoneyByCoinId(Define.Money.PET_SKILL_STONE)
        --local price = Define.PET_RANDOM_SKILL_PRICE
        --if money < price then
        --    ---货币不足
        --    local count = price - money
        --    local listener = function()
        --        if GUIGameActivityLayout:showActivity(927) then
        --            GUIGameActivityLayout:show()
        --        else
        --            GUIGameActivityLayout:show()
        --        end
        --        --GUILicense:show()
        --    end
        --    CustomDialog.builder()
        --                .setTitleText("lack_of_money")
        --                .setContentView(CheckMoneyContent)
        --                .setRightClickListener(listener)
        --                .show()
        --
        --    CheckMoneyContent:setCurrencyInfo(PayHelper.getMoneyIcon(Define.Money.PET_SKILL_STONE), count)
        --    CheckMoneyContent:setContentText(Lang:getString(Lang:getString("gui.get.pet.skill.stone.tips")))
        --else
        --    CommonPacketSender:sendBuyPetRandomSkill(petId)
        --end
        PayHelper.checkMoney(Define.Money.PET_SKILL_STONE, Define.PET_RANDOM_SKILL_PRICE, function(canBuy)
            if canBuy then
                CommonPacketSender:sendBuyPetRandomSkill(petId)
            end
        end )
    else
        if MoneyUtil:checkHasMoney(player, Define.Money.PET_SKILL_STONE, Define.PET_RANDOM_SKILL_PRICE) then
            if player:subPetSkillStone(Define.PET_RANDOM_SKILL_PRICE) then
                local newImbueGroupId = self:getRandomImbueGroupId(player, petId)
                if newImbueGroupId then
                    self:petRandomSkillStorage(player, petId, newImbueGroupId)
                    local params = {}
                    params.petId = petId
                    params.imbueGroupId = newImbueGroupId
                    CommonPacketSender:sendSyncPetRandomSkillResult(player.rakssid, params)
                end
            end
        end
    end
end

function PetUpgradeShop:getRandomImbueGroupId(player, petId)
    local defaultImbueGroupId = PetLvConfig:getPetDefaultImbueGroupId(petId)
    local oldImbueGroupId = player.randomSkillData[tostring(petId)] or defaultImbueGroupId
    local result = PetImbueRandomPoolConfig:getRandomResult(oldImbueGroupId)
    if result and #result > 0 then
        return result[1].imbueGroupId
    end
end

function PetUpgradeShop:petRandomSkillStorage(player, petId, imbueGroupId)
    local storage = player.imbueGroupIdStorage
    if not storage then
        storage = {}
        player.imbueGroupIdStorage = storage
    end
    storage[tostring(petId)] = imbueGroupId
end

function PetUpgradeShop:onSavePetRandomSkill(player, petId)
    if isClient then
        CommonPacketSender:sendSavePetRandomSkill(petId)
    else
        local storage = player.imbueGroupIdStorage
        if not storage then
            return
        end
        local imbueGroupId = storage[tostring(petId)]
        if imbueGroupId then
            player.randomSkillData[tostring(petId)] = imbueGroupId
            local params = {}
            params.petId = petId
            params.imbueGroupId = imbueGroupId
            CommonPacketSender:sendSyncPetChangeSkillSuccess(player.rakssid, params)
            storage[tostring(petId)] = nil
        end
    end
end