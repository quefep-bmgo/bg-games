---@class GUIBedWarHallChatEmojiItemWindow : IGUIWindow
local GUIBedWarHallChatEmojiItemWindow = class("GUIBedWarHallChatEmojiItemWindow", IGUIWindow)

local STATUS = {
	Lock = 1,	-- 锁住
	Unlock = 2, -- 解锁
}

---@private
function GUIBedWarHallChatEmojiItemWindow:ctor(...)
	self.super.ctor(self, "BedWarHallChatEmojiItem.json", ...)
end

---@private
function GUIBedWarHallChatEmojiItemWindow:onLoad()
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarHallChatEmojiItemWindow:initView()
	self.root = self:getChildWindowByName("BedWarHallChatEmojiItem", GUIType.StaticImage)
	self.siLock = self:getChildWindowByName("BedWarHallChatEmojiItem-Lock", GUIType.StaticImage)
end

function GUIBedWarHallChatEmojiItemWindow:setItemStatus(status)
	if status == STATUS.Lock then
		self.siLock:SetVisible(true)
		self.root:SetDrawColor({0.5, 0.5, 0.5, 1})
	else
		self.siLock:SetVisible(false)
		self.root:SetDrawColor({1, 1, 1, 1})
	end
end

---@private
function GUIBedWarHallChatEmojiItemWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		local emojiData = ClientGameEmoji:getGameEmojiData()
		if self.data.price > 0 and emojiData[tostring(self.data.id)] == nil then
			CustomDialog.builder()
						.setContentText(Lang:getString("gui_dialog_tip_buy_action"))
						.setExtraInfo(PayHelper.getMoneyIcon(self.data.moneyType), tostring(self.data.price))
						.setTitleText("gui_dialog_tip_title_tip")
						.setRightText("gui_dialog_tip_btn_sure")
						.setRightClickListener(function()
				LuaTimer:schedule(function()
					PayHelper.checkMoney(self.data.moneyType, self.data.price, function(success)
						if success then
							CommonPacketSender:sendBuyEmoji(self.data.id)
						end
					end)
				end, 100)
			end)
						.setLeftText("gui_dialog_tip_btn_cancel")
						.show()
			return
		end
		---发表情
		GUIBedWarHallChatLayout:sendGameEmojiMsg(self.data.icon)
	end)
end

---@param data EmojiData
function GUIBedWarHallChatEmojiItemWindow:onDataChanged(data)
	self.data = data
	self.root:SetImage(data.icon)
	self:setItemStatus(STATUS.Lock)
	if data.price <= 0 then
		self:setItemStatus(STATUS.Unlock)
	else
		local emojiData = ClientGameEmoji:getGameEmojiData()
		if emojiData[tostring(data.id)] ~= nil then
			self:setItemStatus(STATUS.Unlock)
		end
	end
end

return GUIBedWarHallChatEmojiItemWindow
