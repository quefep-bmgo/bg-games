---@class UIBedWarPictureFrameShopLayout : IGUILayout
local UIBedWarPictureFrameShopLayout = class("UIBedWarPictureFrameShopLayout", IGUILayout)
---@type HeadFrameShopConfig
local HeadFrameShopConfig = T(Global, "HeadFrameShopConfig")
---@type ClientHeadFrameShop
local HeadFrameShop = T(Global, "HeadFrameShop")
---@type HeadImageShopConfig
local HeadImageShopConfig = T(Global, "HeadImageShopConfig")
---@type ClientHeadImageShop
local HeadImageShop = T(Global, "HeadImageShop")
local HeadTabText = {
	"gui.head.frame.txt",
	"gui.head.txt",
}

---@private
function UIBedWarPictureFrameShopLayout:ctor(parent)
	self.super.ctor(self, "BedWarPictureFrameShop.json", parent)
end

---@private
function UIBedWarPictureFrameShopLayout:onLoad()
	self.llBack = self:getChildWindow("BedWarHallPictureFrameShop-Back", GUIType.Layout)
	self.siBg = self:getChildWindow("BedWarHallPictureFrameShop-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("BedWarHallPictureFrameShop-Content", GUIType.Layout)
	self.llInfo = self:getChildWindow("BedWarHallPictureFrameShop-Info", GUIType.Layout)
	self.siInfoIcon = self:getChildWindow("BedWarHallPictureFrameShop-Info-Icon", GUIType.StaticImage)
	self.siCur = self:getChildWindow("BedWarHallPictureFrameShop-Cur", GUIType.StaticImage)
	self.stName = self:getChildWindow("BedWarHallPictureFrameShop-Name", GUIType.StaticText)
	self.btnUse = self:getChildWindow("BedWarHallPictureFrameShop-Use", GUIType.Button)
	self.stWay = self:getChildWindow("BedWarHallPictureFrameShop-Way", GUIType.StaticText)
	self.btnClose = self:getChildWindow("BedWarHallPictureFrameShop-Close", GUIType.Button)
	self.siPrice = self:getChildWindow("BedWarHallPictureFrameShop-Price", GUIType.StaticImage)
	self.siMoneyIcon = self:getChildWindow("BedWarHallPictureFrameShop-Money-Icon", GUIType.StaticImage)
	self.stPriceText = self:getChildWindow("BedWarHallPictureFrameShop-Price-Text", GUIType.StaticText)
	self.siCanNotBuyBg = self:getChildWindow("BedWarHallPictureFrameShop-Can-Not-Buy", GUIType.StaticImage)
	self.stCanNotBuy = self:getChildWindow("BedWarHallPictureFrameShop-Can-Not-Buy-Text", GUIType.StaticText)
	self.lhTabList = self:getChildWindow("BedWarHallPictureFrameShop-TabList", GUIType.ListHorizontal)

	self:initView()
	self:initEvent()
end

---@private
function UIBedWarPictureFrameShopLayout:isDelayLoad()
	return true
end

---@private
function UIBedWarPictureFrameShopLayout:onCreate()
	local configs = HeadFrameShopConfig:getShopConfigs()
	self.curSelectItem = configs[1]
end

local function setFrameAdaptData(self)
	local configs = HeadFrameShopConfig:getShopConfigs()
	local dataList = {}
	for i, v in ipairs(configs) do
		table.insert(dataList, v)
	end
	for i = 1, 4 do
		table.insert(dataList, {})
	end
	self.frameAdapter:setData(dataList)
end

local function setImageAdaptData(self)
	local configs = HeadImageShopConfig:getShopConfigs()
	local dataList = {}
	for i, v in ipairs(configs) do
		local isOwn = HeadImageShop:checkHeadImageStatus(v.RewardId)
		v.isOwn = isOwn and 1 or 0
		if v.Id == 0 then
			v.isOwn = 1
		end
		table.insert(dataList, v)
	end

	table.sort(dataList, function(a, b)
		if a.isOwn == b.isOwn then
			return a.Rank < b.Rank
		end
		return a.isOwn > b.isOwn
	end)

	for i = 1, 4 do
		table.insert(dataList, {})
	end
	self.imageAdapter:setData(dataList)
end

---@private
function UIBedWarPictureFrameShopLayout:initView()
	self.stCanNotBuy:SetText(Lang:getString("gui_picture_frame_can_not_buy"))

	self.lvFrameList = IGUIGridView.new("BedWarHallPictureFrameShop-Frame-List", self.llContent)
	self.lvFrameList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, -15 }, { 1, -15 })
	self.lvFrameList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvFrameList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvFrameList:setConfig(10, 10, 4)
	self.lvFrameList.root:SetClipChild(true)
	self.llContent:SetClipChild(true)

	self.lvImageList = IGUIGridView.new("BedWarHallPictureFrameShop-Image-List", self.llContent)
	self.lvImageList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, -15 }, { 1, -15 })
	self.lvImageList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvImageList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvImageList:setConfig(10, 10, 4)
	self.lvImageList.root:SetClipChild(true)
	self.llContent:SetClipChild(true)

	---@type BedWarHeadItemAdapter
	self.frameAdapter = UIHelper.newGameAdapter("BedWarHeadItemAdapter")
	local itemWidth = 100 -- (self.lvFrameList.root:GetPixelSize().x - 90) /  4
	self.frameAdapter:setItemSize(itemWidth, itemWidth)
	self.lvFrameList:setAdapter(self.frameAdapter)
	setFrameAdaptData(self)

	---@type BedWarHeadImageItemAdapter
	self.imageAdapter = UIHelper.newGameAdapter("BedWarHeadImageItemAdapter")
	itemWidth = 100
	self.imageAdapter:setItemSize(itemWidth, itemWidth)
	self.lvImageList:setAdapter(self.imageAdapter)
	setImageAdaptData(self)

	---@type GUIBedWarHeadFrameItem
	self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHeadFrameItem")
	self.winHead.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.winHead.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.winHead.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.siCur:AddChildWindow(self.winHead.root)
	self.winHead:setCanNotBeSelect()

	---@type GUIBedWarHeadImageItem
	self.winHeadImage = UIHelper.newGameGUIWindow("GUIBedWarHeadImageItem")
	self.winHeadImage.root:SetArea({ 0, 0 }, { 0, 0 }, { 1.2, 0 }, { 1.2, 0 })
	self.winHeadImage.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.winHeadImage.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.siCur:AddChildWindow(self.winHeadImage.root)
	self.winHeadImage:setCanNotBeSelect()

	self.lhTabList:SetProperty("BetweenDistance", 7)
	---@type GUIWindow[]
	self.headTabList = {}
	for index = 1, 2 do
		local tab = GUIManager:createGUIWindow(GUIType.CheckBox, "BedWarHallPictureFrameShop-Tab" .. index)
		tab:SetTextColor(Define.TabTextColor.Normal)
		tab:SetNormalImage("set:bed_war_3_common_part.json image:chb_9_normal")
		tab:SetPushedImage("set:bed_war_3_common_part.json image:chb_9_selected")
		tab:SetHeight({ 0, 56 })
		tab:SetWidth({ 0, 201 })
		tab:SetText(Lang:getString(HeadTabText[index]))
		tab:registerEvent(GUIEvent.CheckStateChanged, function()
			if not tab:GetChecked() then
				return
			end
			self:setHeadTabSelect(index)
		end)
		self.lhTabList:AddItem(tab)
		self.headTabList[index] = tab
	end

	self.tab1SelectId = 1
	self.tab2SelectId = 1

	self:setHeadTabSelect(1)
end

function UIBedWarPictureFrameShopLayout:setHeadTabSelect(index)
	if self.curSelectTabIndex == index then
		return
	end
	if self.curSelectTabIndex then
		local oldTab = self.headTabList[self.curSelectTabIndex]
		oldTab:SetTextColor(Define.TabTextColor.Normal)
	end
	self.curSelectTabIndex = index
	local newTab = self.headTabList[self.curSelectTabIndex]
	newTab:SetTextColor(Define.TabTextColor.Select)
	for id, tab in pairs(self.headTabList) do
		tab:SetTouchable(id ~= index)
		tab:SetChecked(id == index)
	end
	self.lvFrameList.root:SetVisible(index == 1)
	self.lvImageList.root:SetVisible(index == 2)
	self.winHead.root:SetVisible(index == 1)
	self.winHeadImage.root:SetVisible(index == 2)

	local id = self.tab1SelectId
	if self.curSelectTabIndex == 2 then
		id = self.tab2SelectId
	end
	self:onSelectItemChange(id)
end

---@private
function UIBedWarPictureFrameShopLayout:initEvent()
	self.btnUse:registerEvent(GUIEvent.ButtonClick, function()
		self:onBtnClick()
	end)

	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		GUIBedWarPictureFrameShopLayout:hide()
	end)

	self.llBack:registerEvent(GUIEvent.Click, function()
		GUIBedWarPictureFrameShopLayout:hide()
	end)

	self:registerEvent(Events.HeadFrameItemSelectEvent, function(id)
		self:onSelectItemChange(id)
		self.tab1SelectId = id
	end)

	self:registerEvent(Events.HeadImageItemSelectEvent, function(id)
		self:onSelectItemChange(id)
		self.tab2SelectId = id
	end)
end

---@param id number
function UIBedWarPictureFrameShopLayout:onSelectItemChange(id)
	local config = nil
	if self.curSelectTabIndex == 1 then
		---@type HeadFrameShopItem
		config = HeadFrameShopConfig:getShopConfigById(id)
	elseif self.curSelectTabIndex == 2 then
		---@type HeadImageShopItem
		config = HeadImageShopConfig:getShopConfigById(id)
	end
	if not config then
		return
	end
	self.curSelectItem = config
	if self.curSelectTabIndex == 1 then
		self.winHead:onDataChanged(config)
	else
		self.winHeadImage:onDataChanged(config)
	end
	local reward = RewardConfig.findRewardById(config.RewardId)
	self.stName:SetText(Lang:getString(reward and reward.ShowDetail and reward.ShowDetail.name or "gui_head_frame_default_name"))
	self.stWay:SetText(Lang:getString(reward and reward.ShowDetail and reward.ShowDetail.desc or "gui_head_frame_default_desc"))
	self:setBtnStatus(config)
end

function UIBedWarPictureFrameShopLayout:updateListUI()
	if self:isShow() and self.curSelectItem then
		self:setBtnStatus(self.curSelectItem)
	end
end

---@param config HeadFrameShopItem
function UIBedWarPictureFrameShopLayout:setBtnStatus(config)
	if self.curSelectTabIndex == 1 then
		self.siPrice:SetVisible(false)
		self.siCanNotBuyBg:SetVisible(false)
		if config.Default then
			local isEquip = HeadFrameShop.curHeadFrame == 0
			self.btnUse:SetVisible(not isEquip)
			if not isEquip then
				self.btnUse:SetText(Lang:getString("gui_equip"))
			end
			return
		end
		self.btnUse:SetVisible(config.CanBuy)
		self.btnUse:SetText(config.CanBuy and Lang:getString("gui_buy_text") or "")
		local reward = RewardConfig.findRewardById(config.RewardId)
		if not reward then
			self.btnUse:SetVisible(false)
			return
		end
		local isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
		self.siCanNotBuyBg:SetVisible(not config.CanBuy and not isOwn)
		self.stCanNotBuy:SetText(Lang:getString(config.GetWayDesc or "gui_picture_frame_can_not_buy"))
		self.siPrice:SetVisible(config.CanBuy and not isOwn)
		if isOwn then
			self.btnUse:SetVisible(reward.RewardId ~= HeadFrameShop.curHeadFrame)
			self.btnUse:SetText(Lang:getString(reward.RewardId ~= HeadFrameShop.curHeadFrame and "gui_equip" or ""))
		else
			self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(config.CoinId))
			self.stPriceText:SetText(config.Price)
		end
	else
		self.siPrice:SetVisible(false)
		self.siCanNotBuyBg:SetVisible(false)
		if config.Default then
			local isEquip = HeadImageShop.curHeadImage == 0
			self.btnUse:SetVisible(not isEquip)
			if not isEquip then
				self.btnUse:SetText(Lang:getString("gui_equip"))
			end
			return
		end
		self.btnUse:SetVisible(config.CanBuy)
		self.btnUse:SetText(config.CanBuy and Lang:getString("gui_buy_text") or "")
		local reward = RewardConfig.findRewardById(config.RewardId)
		if not reward then
			self.btnUse:SetVisible(false)
			return
		end
		local isOwn = HeadImageShop:checkHeadImageStatus(reward.RewardId)
		self.siCanNotBuyBg:SetVisible(not config.CanBuy and not isOwn)
		self.stCanNotBuy:SetText(Lang:getString(config.GetWayDesc or "gui_picture_frame_can_not_buy"))
		self.siPrice:SetVisible(config.CanBuy and not isOwn)
		if isOwn then
			self.btnUse:SetVisible(reward.RewardId ~= HeadImageShop.curHeadImage)
			self.btnUse:SetText(Lang:getString(reward.RewardId ~= HeadImageShop.curHeadImage and "gui_equip" or ""))
		else
			self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(config.CoinId))
			self.stPriceText:SetText(config.Price)
		end
	end
end

function UIBedWarPictureFrameShopLayout:onBtnClick()
	if self.curSelectTabIndex == 1 then
		if self.curSelectItem.Default then
			local isEquip = HeadFrameShop.curHeadFrame == 0
			if not isEquip then
				HeadFrameShop:onEquipGoods(self.curSelectItem)
			end
			return
		end
		local reward = RewardConfig.findRewardById(self.curSelectItem.RewardId)
		local isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
		if isOwn then
			if reward.RewardId ~= HeadFrameShop.curHeadFrame then
				HeadFrameShop:onEquipGoods(self.curSelectItem)
			end
		else
			if self.curSelectItem.CanBuy then
				HeadFrameShop:onBuyGoods(self.curSelectItem)
			end
		end
	else
		if self.curSelectItem.Default then
			local isEquip = HeadImageShop.curHeadImage == 0
			if not isEquip then
				HeadImageShop:onEquipGoods(self.curSelectItem)
			end
			return
		end
		local reward = RewardConfig.findRewardById(self.curSelectItem.RewardId)
		local isOwn = HeadImageShop:checkHeadImageStatus(reward.RewardId)
		if isOwn then
			if reward.RewardId ~= HeadImageShop.curHeadImage then
				HeadImageShop:onEquipGoods(self.curSelectItem)
			end
		else
			if self.curSelectItem.CanBuy then
				HeadImageShop:onBuyGoods(self.curSelectItem)
			end
		end
	end
end

function UIBedWarPictureFrameShopLayout:getCurSelectId()
	return self.curSelectItem.Id or 0
end

function UIBedWarPictureFrameShopLayout:onShow()
	if not self.firstInit then
		Events.HeadFrameItemSelectEvent:invoke(self.curSelectItem.Id)
		self.firstInit = true
	else
		self:updateListUI()
	end
end

return UIBedWarPictureFrameShopLayout
