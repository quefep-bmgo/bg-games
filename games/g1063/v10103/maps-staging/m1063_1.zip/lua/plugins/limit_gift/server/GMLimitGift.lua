---@type SLimitGiftManager
local SLimitGiftManager = T(Global, "SLimitGiftManager")

function GMHelper:onLimitGiftTrigger(player, type)
    SLimitGiftManager:onGiftTrigger(player, type)
end

function GMHelper:cleanLimitGift(player)
    SLimitGiftManager:cleanLimitGift(player)
end