---@class DragonEggConfig
local DragonEggConfig = T(Global, "DragonEggConfig")
local s_hatchTime = 60 * 1000
local s_delayShowHatchProgressTime = 50
local s_eggItemId = 547
local s_damageHash = 1
local s_weightEnd = 0
DragonEggConfig.rewardConfig = {}
DragonEggConfig.allEggs = {}

function DragonEggConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/DragonEggReward.csv", 2, true)
    local weightBegin = 0
    for _, config in pairs(configs) do
        --print("add DragonEggConfig config: " .. StringUtil.v2s(config))
        local reward = {}
        reward.itemId = tonumber(config.ItemId)
        reward.count = tonumber(config.Count)
        reward.weightBegin = weightBegin
        reward.weightEnd = weightBegin + tonumber(config.weight) * 1000
        weightBegin = reward.weightEnd
        table.insert(self.rewardConfig, reward)
        --print("add DragonEggConfig: " .. StringUtil.v2s(reward))
    end

    s_weightEnd = weightBegin

    local this = self
    CEvents.InventoryStackChange:registerCallBack(function(playerSsid, inventoryId)
        this:onInventoryStackChange(playerSsid, inventoryId)
    end)

    -- CEvents.PlayerInventorySwapItemEvent:registerCallBack(function (userId, index1, index2)
    --     --return this:onPlayerInventorySwapItem(userId, index1, index2)
    --      return true
    --  end
    --  )

    CEvents.PlayerDieEvent:registerCallBack(function(diePlayer, _, killPlayer)
        return this:onPlayerDied(diePlayer, _, killPlayer)
    end
    )

    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, function(player)
        this:onPlayerLogout(player)
    end)
end

function DragonEggConfig:onPlayerDropItem()

end

function DragonEggConfig:onPlayerDied(diePlayer, _, killPlayer)
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByPlayerMP2(diePlayer)
    if not player then
        return true
    end
    local userId = player.userId
    for i, v in pairs(self.allEggs) do
        if v.userId == userId then
            v.disable = true
            local inv = player:getInventory()
            if v.inventoryId ~= nil then
                if inv ~= nil then
                    inv:decrStackSize(v.inventoryId, 1)
                end
                self:notifyCloseProgess(userId, v.inventoryId)
            end
            self.allEggs[i] = nil
        end
    end
    return true
end

function DragonEggConfig:getRewardItem()

    local randomData = HostApi.random("DragonEgg_Reward", 0, s_weightEnd)
    local randomItem = 1
    for i, k in pairs(self.rewardConfig) do
        if k.weightBegin <= randomData and k.weightEnd >= randomData then
            randomItem = i
        end
    end
    return self.rewardConfig[randomItem]
end

---@param player GamePlayer
function DragonEggConfig:onAddItemToPlayer(player, itemId, count, damage)
    if itemId == s_eggItemId then
        if count > 1 then
            player:tryAddItem(itemId, count - 1, damage)
        end
        local curDamage = s_damageHash
        s_damageHash = s_damageHash + 1
        self.allEggs[curDamage] = { metaHash = curDamage, userId = player.userId, inventoryId = nil, hatchBeginTime = nil, reward = nil, disable = false }
        return curDamage, 1
    end
    return damage, count
end

function DragonEggConfig:onPlayerInventorySwapItem(userId, index1, index2)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return true
    end
    local inv = player:getInventory()
    if not inv then
        return true
    end
    local info1 = inv:getItemStackInfo(index1)
    local info2 = inv:getItemStackInfo(index2)
    if info1.id == s_eggItemId or info2.id == s_eggItemId then
        return false
    end
    return true
end

function DragonEggConfig:onInventoryStackChange(playerSSId, inventoryId)
    local player = PlayerManager:getPlayerByRakssid(playerSSId)
    if player == nil then
        return
    end
    local inv = player:getInventory()
    if not inv then
        return
    end
    local info = inv:getItemStackInfo(inventoryId)
    if info and info.id == s_eggItemId then
        local eggInfo = self.allEggs[info.meta]
        if eggInfo ~= nil then
            if eggInfo.inventoryId == nil then
                self:onBuyDragonEgg(player, info.meta, inventoryId)
            else
                self:onEggChangeInventory(info.meta, inventoryId)
            end
        else
            print("DragonEggConfig:onInventoryStackChange find invalid eggInfo " .. tostring(info.meta))
        end
    end
end

function DragonEggConfig:onEggChangeInventory(itemMeta, newInv)
    local eggInfo = self.allEggs[itemMeta]
    local oldInv = eggInfo.inventoryId
    self:notifyCloseProgess(eggInfo.userId, oldInv)
    self.allEggs[itemMeta].inventoryId = newInv
    local curUseHachTime = Root.Instance():getCurrentTime() - eggInfo.hatchBeginTime
    local player = PlayerManager:getPlayerByUserId(eggInfo.userId)
    local time = player.dragonEggTime[tostring(itemMeta)] or s_hatchTime
    self:notifyShowProgress(eggInfo.userId, newInv, curUseHachTime, time)
end

function DragonEggConfig:onBuyDragonEgg(player, metaHash, inventoryId)
    local userId = player.userId
    local bugEggInfo = self.allEggs[metaHash]
    bugEggInfo.userId = userId
    bugEggInfo.reward = self:getRewardItem()
    bugEggInfo.inventoryId = inventoryId
    bugEggInfo.hatchBeginTime = Root.Instance():getCurrentTime()
    local time = player.dragonEggTime[tostring(metaHash)] or s_hatchTime
    self:notifyShowProgress(bugEggInfo.userId, inventoryId, 0, time)
    self:prepareGiveReward(bugEggInfo)
end

function DragonEggConfig:notifyShowProgress(userId, inventoryId, curTime, allTime)
    local this = self
    LuaTimer:schedule(function()
        this:sendShowProgressPacket(userId, inventoryId, curTime, allTime)
    end, s_delayShowHatchProgressTime
    )
end

function DragonEggConfig:notifyCloseProgess(userId, inventoryId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player ~= nil and player.sendPacket ~= nil then
        player:sendPacket({
            pid = "CloseSlotCDLoop",
            slot = inventoryId,
        })
    end
end

function DragonEggConfig:sendShowProgressPacket(userId, inventoryId, curTime, allTime)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player ~= nil and player.sendPacket ~= nil then
        player:sendPacket({
            pid = "UpdateSlotCDLoop",
            slot = inventoryId,
            totalTime = allTime,
            curTime = curTime,
            onceTime = 1000
        })
    end
end

function DragonEggConfig:prepareGiveReward(bugEggInfo)
    local this = self
    local player = PlayerManager:getPlayerByUserId(bugEggInfo.userId)
    local time = player.dragonEggTime[tostring(bugEggInfo.metaHash)] or s_hatchTime
    LuaTimer:schedule(function()
        this:giveReward(bugEggInfo)
    end, time)
end

function DragonEggConfig:giveReward(bugEggInfo)
    local player = PlayerManager:getPlayerByUserId(bugEggInfo.userId)
    if player ~= nil and bugEggInfo.disable ~= true then
        local inv = player:getInventory()
        if inv ~= nil then
            inv:decrStackSize(bugEggInfo.inventoryId, 1)
        end
        local itemId = bugEggInfo.reward.itemId
        local count = bugEggInfo.reward.count
        if itemId == ItemID.INGOT_IRON and not SpecialMode:moduleInfo(Define.ModeLimiterType.AlterIronLimiter) then
            itemId = ItemID.INGOT_GOLD
            count = math.ceil(count / 8)
        end
        player:addItem(itemId, count)
        player:sendPacket({
            pid = "ShowGetDragonEggRewardTips",
            itemId = itemId,
            itemCount = count
        })
    end
    self.allEggs[bugEggInfo.metaHash] = nil
end

function DragonEggConfig:onPlayerLogout(player)
    ---@type GamePlayer
    if not player then
        return true
    end
    local userId = player.userId
    for i, v in pairs(self.allEggs) do
        if v.userId == userId then
            v.disable = true
            if v.inventoryId ~= nil then
                self:notifyCloseProgess(userId, v.inventoryId)
            end
            self.allEggs[i] = nil
        end
    end
    return true
end