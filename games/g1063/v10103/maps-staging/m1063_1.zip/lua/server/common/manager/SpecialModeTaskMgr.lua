---@class SpecialModeTaskMgr
local SpecialModeTaskMgr = T(Global, "SpecialModeTaskMgr")
---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

function SpecialModeTaskMgr:init()
    if GameType == "g1063" or GameType == "g1064" then
        return
    end
    ---@param task GameTask
    Events.PlayerTaskProcessChangeEvent:registerCallBack(function(userId, key, task)
        if not string.find(key, "SpecialModeTask") then
            return
        end
        local player = PlayerManager:getPlayerByUserId(userId)
        if not player then
            return
        end
        if PlayerManager:isAIPlayer(player) then
            return
        end
        local activityId = StringUtil.split(key, ":")[2]
        player:sendPacket({
            pid = "SpecialModeTaskUpdate",
            data = {
                activityId = tonumber(activityId),
                taskId = task.taskId,
                progress = task.progress,
                status = task.status,
            }
        })
    end)

    self:setDailyTimer()
end

function SpecialModeTaskMgr:setDailyTimer()
    local lastTime = DateUtil.getGreenwichDayLastTime() - os.time()
    LuaTimer:schedule(function()
        local players = PlayerManager:getPlayers()
        for _, player in pairs(players) do
            if player:checkReady() then
                self:initPlayerTask(player)
            end
        end
        self:setDailyTimer()
    end, lastTime * 1000)
end

SpecialModeTaskMgr:init()

---@param player GamePlayer
function SpecialModeTaskMgr:initPlayerTask(player)
    if PlayerManager:isAIPlayer(player) then
        return
    end

    local activity = SpecialMode:getAllCfg()
    local keys = {}
    for key, _ in pairs(player.taskController.dailyTasks) do
        if string.find(key, "SpecialModeTask") then
            table.insert(keys, key)
        end
    end
    local curTime = os.time()
    for _, cfg in pairs(activity) do
        if cfg.openOsDate <= curTime and curTime < cfg.closeOsDate then
            local key = "SpecialModeTask:" .. cfg.id
            local taskConfig = SpecialMode:getTaskByGroup(cfg.taskGroup)
            local taskIds = {}
            for _, v in pairs(taskConfig) do
                table.insert(taskIds, v.taskId)
            end
            player.taskController:refreshDailyTaskByTaskIdList(key, taskIds)
            TableUtil.tableRemove(keys, key)
        end
    end

    for _, key in pairs(keys) do
        player.taskController:removeTaskGroup(key)
    end
end

---@param player GamePlayer
function SpecialModeTaskMgr:finishTask(player, activityId, taskIds)
    local key = "SpecialModeTask:" .. activityId
    local tasks = player.taskController:getDailyTasks(key) or {}
    local ids = {}
    local cfg = SpecialMode:getCfgById(activityId)
    if not cfg then
        return
    end
    for _, taskId in pairs(taskIds or {}) do
        local taskConfig = SpecialMode:getTaskByGroupAndTaskId(cfg.taskGroup, taskId)
        for _, task in pairs(tasks) do
            if taskConfig and task.taskId == tonumber(taskId) and task:receiveTaskReward(player) then
                local _reward = RewardConfig:getRewardById(taskConfig.rewardId)
                if _reward then
                    _reward = TableUtil.copyTable(_reward)
                    GameReward:onPlayerGetReward(player, _reward)
                    table.insert(ids, taskConfig.rewardId)
                end
                Events.PlayerTaskProcessChangeEvent:invoke(player.userId, key, task)
                ReportEvent.task_get_reward(player, tonumber(taskId), tonumber(activityId))
                goto CONTINUE
            end
        end
        :: CONTINUE ::
    end
    if next(ids) then
        CommonPacketSender:sendBedWarRewardResult(player.rakssid, table.concat(ids, "#"))
    end
end