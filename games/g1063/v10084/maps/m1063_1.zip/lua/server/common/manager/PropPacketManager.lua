---@type SRankUtil
local SRankUtil = T(Global, "SRankUtil")

local PropRankScoreMapping = {
    [266] = 0.25, [265] = 0.05, [590] = 3, [593] = 30,
    [369] = 8, [46] = 5, [368] = 1, [467] = 1.5, [506] = 2,
    [508] = 1, [594] = 1.5, [591] = 1, [507] = 3, [583] = 1,
    [585] = 1, [584] = 1, [2418] = 1, [2417] = 1, [326] = 1,
    [595] = 0.2, [514] = 1, [512] = 2, [519] = 1,
}

---@class PropPacketManager
local PropPacketManager = {}
local UnloadIndex = -1

---@class ItemPropData
---@field itemId number
---@field count number
---@field equipIndex number
---@field damage number
---@field needSync boolean

---@param player SBasePlayer
function PropPacketManager:onPlayerReady(player)
    ---@type table <string , ItemPropData>
    player.propPacketData = player.propPacketData or {}
    ---@type table <string , number>
    player.propEquipData = {}
    PropPacketManager:onPlayerRespawn(player)
end

---@param player SBasePlayer
function PropPacketManager:onPlayerRespawn(player)
    if not player.propPacketData then
        return
    end
    player.propEquipData = {}
    local score = 0
    for key, packetData in pairs(player.propPacketData) do
        if packetData.count == nil or packetData.count < 0 then
            player.propPacketData[key] = nil
        elseif packetData.equipIndex ~= UnloadIndex then
            if not player.propEquipData[tostring(packetData.equipIndex)] then
                player.propEquipData[tostring(packetData.equipIndex)] = packetData.itemId
            else
                packetData.equipIndex = UnloadIndex
            end
        end
        if packetData.itemId and packetData.count and packetData.count > 0 then
            score = score + (PropRankScoreMapping[packetData.itemId or 0] or 0) * packetData.count
        end
        packetData.needSync = true
    end
    SRankUtil:reportPropPacketRank(player.userId, score)
    PropPacketManager:updateEnginePacket(player)
    PropPacketManager:syncPacketData(player)
end

---@param player SBasePlayer
function PropPacketManager:onPlayerDied(player)
    player.propEquipData = {}
    PropPacketManager:updateEnginePacket(player)
end

---@param player SBasePlayer
---@param itemId number
---@param count number
function PropPacketManager:onAddItem(player, itemId, count)
    itemId = player.equip_dress[tostring(itemId)] or itemId
    local item = Item.getItemById(itemId)
    if not player.propPacketData[tostring(itemId)] then
        player.propPacketData[tostring(itemId)] = {
            itemId = itemId,
            count = 0,
            equipIndex = UnloadIndex,
        }
        if item and item:getMaxDamage() > 0 then
            player.propPacketData[tostring(itemId)].damage = 0
        end
    end
    local propData = player.propPacketData[tostring(itemId)]
    if propData.count == 0 then
        PropPacketManager:onEquipItem(player, itemId)
    end
    propData.needSync = true
    propData.count = propData.count + count
    PropPacketManager:updateEnginePacket(player, propData.equipIndex)
    PropPacketManager:syncPacketData(player)
    return propData
end

---@param player SBasePlayer
---@param oldDressId number
---@param newDressId number
function PropPacketManager:onItemDressChange(player, oldDressId, newDressId)
    local propData = player.propPacketData[tostring(oldDressId)]
    if propData then
        propData.needSync = true
        local newPropData = TableUtil.copyTable(propData)
        newPropData.itemId = newDressId
        player.propPacketData[tostring(newDressId)] = newPropData
        if propData.equipIndex ~= UnloadIndex then
            player.propEquipData[tostring(propData.equipIndex)] = newDressId
            PropPacketManager:updateEnginePacket(player, propData.equipIndex)
        end
        propData.equipIndex = UnloadIndex
        propData.count = 0

        PropPacketManager:syncPacketData(player)
    end
end

---@param player SBasePlayer
---@param itemId number
function PropPacketManager:onEquipItem(player, itemId)
    if GameType ~= "g1046" and not player.info:getBoolValue("lifeStatus") then
        return
    end
    local propData = player.propPacketData[tostring(itemId)]
    if not propData or propData.equipIndex ~= UnloadIndex then
        return
    end
    for slot = Define.PROP_INDEX_START, Define.PROP_INDEX_END do
        local nowIndex = slot - Define.PROP_INDEX_START
        if not player.propEquipData[tostring(nowIndex)] then
            propData.equipIndex = nowIndex
            player.propEquipData[tostring(nowIndex)] = itemId
            PropPacketManager:updateEnginePacket(player, nowIndex)
            propData.needSync = true
            break
        end
    end

    PropPacketManager:syncPacketData(player)
end

---@param player SBasePlayer
---@param itemId number
function PropPacketManager:onUnloadItem(player, itemId)
    if GameType ~= "g1046" and not player.info:getBoolValue("lifeStatus") then
        return
    end
    local propData = player.propPacketData[tostring(itemId)]
    if not propData or propData.equipIndex == UnloadIndex then
        return
    end
    local oldIndex = propData.equipIndex
    ---由于引擎背包变化的事件需要, 下一帧才同步. 所以当当卸载道具时, 需要及时同步一下背包状态
    PropPacketManager:updateLuaPacket(player, Define.PROP_INDEX_START + oldIndex)

    player.propEquipData[tostring(oldIndex)] = nil
    propData.equipIndex = UnloadIndex
    propData.needSync = true
    PropPacketManager:updateEnginePacket(player, oldIndex)
    PropPacketManager:syncPacketData(player)
end

---@param player SBasePlayer
function PropPacketManager:syncPacketData(player)
    LuaTimer:cancel(player.syncPacketDataKey or 0)
    player.syncPacketDataKey = LuaTimer:schedule(function()
        local data = {}
        for key, propData in pairs(player.propPacketData) do
            if propData.needSync then
                data[key] = propData
                propData.needSync = nil
            end
        end
        player:sendPacket({
            pid = "PropPacketData",
            data = data
        })
    end, 0)
end

---@param player SBasePlayer
function PropPacketManager:updateEnginePacket(player, index)
    if index == UnloadIndex then
        return
    end
    local updateByIndex = function(propIndex)
        local propItemId = player.propEquipData[tostring(propIndex)]
        if propItemId then
            local propData = player.propPacketData[tostring(propItemId)]
            if Item.getItemById(propData.itemId) then
                if propData.itemId == ItemID.BLAZE_ROD then
                    local EnchantList = ItemEnchantment:getEnchantmentList({ "5" })
                    player:replaceEchantmentItem(propData.itemId, propData.count, propData.damage or 0, EnchantList, propData.equipIndex + Define.PROP_INDEX_START)
                else
                    player:replaceItem(propData.itemId, propData.count, propData.damage or 0, propData.equipIndex + Define.PROP_INDEX_START)
                end
            else
                player:replaceItem(BlockManager.getItemBlockId(propData.itemId), propData.count, propData.damage or 0, propData.equipIndex + Define.PROP_INDEX_START)
            end
        else
            local slot = propIndex + Define.PROP_INDEX_START
            local info = player:getInventory():getItemStackInfo(slot)
            if info.id ~= 0 then
                player:decrStackSize(slot, info.num)
            end
        end
    end

    if index then
        updateByIndex(index)
        return
    end
    for slot = Define.PROP_INDEX_START, Define.PROP_INDEX_END do
        updateByIndex(slot - Define.PROP_INDEX_START)
    end
end

---@param player SBasePlayer
---@param slot number
function PropPacketManager:updateLuaPacket(player, slot)
    if slot < Define.PROP_INDEX_START or slot > Define.PROP_INDEX_END then
        return
    end
    if not player.propEquipData or not player.propPacketData then
        return
    end
    local index = slot - Define.PROP_INDEX_START
    local itemId = player.propEquipData[tostring(index)]
    if not itemId then
        return
    end
    local propData = player.propPacketData[tostring(itemId)]
    if not propData then
        return
    end

    local inv = player:getInventory()
    if inv then
        local info = inv:getItemStackInfo(slot)
        local realId = propData.itemId
        if not Item.getItemById(realId) then
            realId = BlockManager.getItemBlockId(realId)
        end
        if info.id == 0 or info.id == realId then
            if propData.count > info.num then
                propData.count = info.num
            end
            if propData.damage then
                propData.damage = info.meta
            end
            if propData.count == 0 then
                player.propEquipData[tostring(index)] = nil
                propData.equipIndex = UnloadIndex
            end
            propData.needSync = true
            PropPacketManager:syncPacketData(player)
        end
    end
end

---@param player SBasePlayer
function PropPacketManager:clearEquipProp(player)
    for index, itemId in pairs(player.propEquipData) do
        local propData = player.propPacketData[tostring(itemId)]
        player:removeItem(propData.itemId, propData.count, propData.damage)
        propData.count = 0
        propData.needSync = true
        propData.equipIndex = UnloadIndex
        player.propEquipData[tostring(index)] = nil
    end
    PropPacketManager:syncPacketData(player)
end

return PropPacketManager