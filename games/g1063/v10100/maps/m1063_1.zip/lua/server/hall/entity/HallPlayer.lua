---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
---@type ServerPlayer
local ServerPlayer = require "common.entity.ServerPlayer"
---@class HallPlayer : ServerPlayer
local HallPlayer = class("HallPlayer", ServerPlayer)
---@type RecentPlayUtil
local RecentPlayUtil = T(Global, "RecentPlayUtil")
---@type ServerHeadFrameShop
local HeadFrameShop = T(Global, "HeadFrameShop")
---@type ServerHeadImageShop
local HeadImageShop = T(Global, "HeadImageShop")
---@type RuneHelper
local RuneHelper = T(Global, "RuneHelper")
---@type SRankUtil
local SRankUtil = T(Global, "SRankUtil")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type ScoreActivityTaskMgr
local ScoreActivityTaskMgr = T(Global, "ScoreActivityTaskMgr")
---@type SGameLicense
local SGameLicense = T(Global, "SGameLicense")
---@type SGamePass
local SGamePass = T(Global, "SGamePass")
---@type TurntableActivityTaskMgr
local TurntableActivityTaskMgr = T(Global, "TurntableActivityTaskMgr")
---@type PuzzleActivityTaskMgr
local PuzzleActivityTaskMgr = T(Global, "PuzzleActivityTaskMgr")
---@type ServerBackgroundShop
local BackgroundShop = T(Global, "BackgroundShop")
---@type PetUpgradeShop
local PetUpgradeShop = T(Global, "PetUpgradeShop")
---@type PropPacketManager
local PropPacketManager = T(Global, "PropPacketManager")
---@type TalentHelper
local TalentHelper = T(Global, "TalentHelper")

function HallPlayer:init()
    ServerPlayer.init(self)
    self:initStaticAttr(0)
    self.chest_integral = 0
    self.fragment_jindu = {}
    self.chests = {}
    self.running_guides = {}
    self.finish_ids = {}
    self.addHealth = 0
    self.addDefense = 0
    self.maxHealth = 0
    self.spDays = 0
    self.spGetAway = false
    self.isShowSuitInHall = false
    self.noShowSuitChangeTip = false
    self.lastEquipSuitRecord = {}

    self.privilegeCard = {}
    self.init_reward_finished = false
    self.video_ad_data = {
        box_lottery_key = 0
    }

    self.props_rewards = {}

    self.free_cube_data = {
        day_key = 0,
        times = 0
    }
    self.challenges = {}
    self.needNewChallengeTip = false
    self.challenge_ad = false

    self.license_season = 0
    self.license_buy = 0
    self.license_exp = 0
    self.license_level = 1
    self.get_free_reward = {}
    self.get_pay_reward = {}
    self.exchange_reward = {}
    self.refresh_times = 1
    self.license_week_exp = 0
    self.license_week = 0
    self.free_upgrade_time = 0
    self.show_effect_task = {}

    self.pass_season = 0
    self.pass_buy = 0
    self.pass_exp = 0
    self.pass_level = 1
    self.get_pass_free_reward = {}
    self.get_pass_pay_reward = {}
    self.pass_exchange_reward = {}
    self.pass_week_exp = 0
    self.pass_week = 0
    self.pass_free_upgrade_time = 0
    self.show_pass_effect_task = {}

    self.free_gift_refresh_time = DateUtil.getYearDay()
    self.free_gift = {}

    self.changeTaskId = -1
    self.curGuideNodeId = 0

    self.goodsValue = 0
    self.skinNum = 0

    self.isNew = false
    self.consecutiveLoginDays = 1
    self.newBattleRecord = {}
    self.aiGameRecord = {}
    self.lastFiveRecord = {}

    self.rechargeReportKey = ""

    self.firstLogin = false

    self.old_lv_info = {}

    self.passPageTime = 0
    self.licensePageTime = 0
    self.registrationTimeKey = 0
    self.taskController = GameTaskController.new(self)

    self.activityPageData = {}

    self.compensationCompletion = {}
end

function HallPlayer:initDBDataFinished()
    CreditScoreUtil:onPlayerLogin(self)
    CustomShop:transformOldDress(self)
    CustomShop:transformOldBlockSkin(self)
    CustomShop:onSyncPlayerAllGoods(self)
    TreasureChallenge:onPlayerReady(self)
    self.taskController:init()
    TreasureChallenge:refreshChallengeTask(self)
    ScoreActivityTaskMgr:initPlayerTask(self)
    TurntableActivityTaskMgr:initPlayerTask(self)
    PuzzleActivityTaskMgr:initPlayerTask(self)
    SGameLicense:updatePlayerData(self)
    SGamePass:updatePlayerData(self)
    PetUpgradeShop:syncPetLvData(self)
    PetUpgradeShop:syncSyncPetChangeSkillData(self)
    CommonPacketSender:sendPetRedDot(self.rakssid, self.petRedDotData)
    if self.play_days == 0 then
        self.isNew = true
        self.registrationTimeKey = os.time()
    end
    if tonumber(self.play_week_key) < tonumber(DateUtil.getYearWeek()) then
        SRankUtil:clearWeeklyData(self)
        self.play_week_key = DateUtil.getYearWeek()
    end
    if tonumber(self.play_day_key) < tonumber(DateUtil.getYearDay()) then
        if tonumber(self.play_day_key) ~= 0 and self.isNew then
            if tonumber(DateUtil.getYearDay()) - tonumber(self.play_day_key) > 1 then
                self.isNew = false
            else
                self.consecutiveLoginDays = self.consecutiveLoginDays + 1
            end
        end
        self.firstLogin = true
        self.play_days = self.play_days + 1
        self.day_play_times = 0
        self.day_play_time = 0
        self.play_day_key = DateUtil.getYearDay()
        self.taskController:packingProgressData(Define.TaskType.GrowUp.DailyLogin, nil, 1)
        GamePacketSender:sendIndieDailyLogin(self.rakssid)
        TreasureChallenge:resetTreasureAd(self)
        CreditScoreUtil:addLoginCreditScore(self)
        self.dailyOnlineTime = 0
        self.dailyCreditScore = 0
        self.noShowSuitChangeTip = false
        self.licensePageTime = 0
        self.passPageTime = 0
    end
    if #self.chests == 0 then
        GameChestLottery:initChestLotteryData(self)
    end
    self:setShowName(self:buildShowName())
    self:syncLevelInfo()
    GameChestLottery:syncChestLotteryData(self)
    VideoAdHelper:syncBoxLotteryAd(self)
    InitRewardConfig:initPlayer(self)
    GameGuide:sendDataToClient(self)
    RewardUtil:tryConsumeRewards(self)
    local todayKey = DateUtil.getYearDay()
    if self.free_cube_data.day_key ~= todayKey then
        self.free_cube_data.day_key = todayKey
        self.free_cube_data.times = 0
    end
    if self.free_cube_data.times >= 2 then
        GamePacketSender:sendBedWarFreeCubeLimit(self.rakssid)
    end
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level, 0)
    self:checkTriggerGift()
    SGameLicense:getHadDress(self)
    SGamePass:getHadDress(self)
    Privilege.syncPrivilegeTime(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TALENT_ESSENCE, self.talent_essence)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.PET_CANDY, self.pet_candy)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.PET_SKILL_STONE, self.pet_skill_stone)
    RecentPlayUtil:sendPlayRecord(self)
    HeadFrameShop:onSyncPlayerAllGoods(self)
    HeadImageShop:onSyncPlayerAllGoods(self)
    BackgroundShop:onSyncPlayerAllGoods(self)
    self:syncLvUpInfo()
    SRankUtil:syncRankScore(self)
    SRankUtil:reportKeyRank(self.userId, self.yaoshi)
    SRankUtil:calculateCustomRankData(self)
    if self.isShowSuitInHall then
        CustomShopSuit:showPlayerSuit(self)
    end
    SGameLicense:syncLicensePageTime(self)
    SGamePass:syncPassPageTime(self)
    SRankUtil:reportHornNumRank(self.userId, self.had_horn)
    SRankUtil:reportChipNumRank(self.userId, self.commonChip)
    SRankUtil:calculateChestRankData(self)
    Plugins.CallTargetPluginFunc("fishing", "onPlayerInit", self)
    self:checkOverdueDiamondConsumeRecord()
    ServerPlayer.initDBDataFinished(self)
    Plugins.CallTargetPluginFunc("vf_app_activity", "addGameBadge", self)
    self:sendPacket({
        pid = "syncCustomGameSetting",
        data = self.customGameSetting
    })
    if self.customGameSetting and self.customGameSetting.needPop then
        self:sendPacket({
            pid = "popCollimatorSelectUI"
        })
        self.customGameSetting.needPop = nil
    end
    RuneHelper:onRuneConversion(self)
    PropPacketManager:onIronConversion(self)
    self:syncActivityPageData()
    Plugins.CallTargetPluginFunc("activity", "initDBDataFinished", self)
    self:checkUECompensate()
    self:getPlatformPurchase()

    TalentHelper:reportLoginTalentLevelData(self)
end

function HallPlayer:buildShowName()
    local nameList = {}
    local namePrefix = TextFormat.colorGreen .. "LV" .. self.level .. "  "
    local disName = self.name
    PlayerIdentityCache:buildNameList(self, nameList, disName, namePrefix)
    return nameList
end

function HallPlayer:getLevelInfo()
    local lv = self.level or 1
    local cur_exp = self.cur_exp or 0
    local max_exp, is_max = ExpConfig:getMaxExp(self.level)
    return lv, cur_exp, max_exp, is_max
end

function HallPlayer:syncLevelInfo()
    local lv, cur_exp, max_exp, is_max = self:getLevelInfo()
    GamePacketSender:sendBedWarLevelInfo(self.rakssid, lv, cur_exp, max_exp, is_max)

    -- 2101 对应 CommonActivity.csv 里的成长基金活动id
    Plugins.CallTargetPluginFunc("activity", "onUpdateLevel", self, 2101, lv)
    Plugins.CallTargetPluginFunc("activity", "onUpdateLevel", self, 2102, lv)
end

function HallPlayer:addExp(exp)
    local oldLv = self.level
    local cur_max, is_max = ServerPlayer.addExp(self, exp)
    if oldLv ~= self.level then
        GameGuide:sendDataToClient(self)
        RuneHelper:levelUpUnlockRuneTrough(self, self.level)
        Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level, 0)
    end
    if self.hasReport == true then
        GameAnalytics:design(self.userId, 1, { "Player_Lv", self.level })
        GameAnalytics:design(self.userId, -1, { "Player_Lv", self.level - 1 })
    end
    self:syncLevelInfo()
    self:setShowName(self:buildShowName())
    self:syncLvUpInfo()
    return cur_max, is_max
end

function HallPlayer:equipNinjaShoes(isEquip)
    self:setSpeedAddition(isEquip and (GameConfig.NinjaShoesSpeedLevel or 500) or 0)
    CommonPacketSender:sendIsEquipNinjaShoes(self.rakssid, isEquip)
end

function HallPlayer:onUseCustomProp(propId, itemId)
    local reward = RewardConfig:getRewardById(itemId)
    if not reward then
        if not self:checkReady() then
            table.insert(self.props_rewards, reward)
            return
        end
        local rewardId = GameReward:onPlayerGetReward(self, reward)
        if not rewardId then
            return
        end
        CommonPacketSender:sendBedWarRewardResult(self.rakssid, rewardId)
    end
end

function HallPlayer:doPlayerQuit()
    BaseListener.onPlayerLogout(self.userId)
    HostApi.sendGameover(self.rakssid, IMessages:msgGameOver(), GameOverCode.GameOver)
end

function HallPlayer:reportRankOnQuit()
    if self:checkReady() then
        SRankUtil:reportKeyConsumeRank(self.userId, self.keyConsume)
        SRankUtil:reportDiamondConsumeRank(self.userId, self.diamondConsume)
    end
    RuneHelper:onPlayerLogout(self)
end

function HallPlayer:checkTriggerGift()
    Plugins.CallTargetPluginFunc("trigger_gift", "checkTriggerGiftStatus", self)
end

function HallPlayer:syncLvUpInfo()
    local data = {}
    if not TableUtil.isEmpty(self.old_lv_info) then
        data.oldLv = self.old_lv_info.lv
        data.oldExp = self.old_lv_info.exp
        self.old_lv_info = {}
    end
    data.lvUpRewards = self.lv_up_rewards
    GamePacketSender:sendBedWarPlayerLvUpInfo(self.rakssid, data)
end

function HallPlayer:receiveLvUpReward(lv)
    if lv > self.level or not TableUtil.include(self.lv_up_rewards, lv) then
        return
    end
    local rewards = ExpConfig:getLevelReward(lv)
    local ids = {}
    local counts = {}
    for _, reward in pairs(rewards) do
        local _reward = RewardConfig:getRewardById(reward.RewardId)
        if _reward then
            _reward = TableUtil.copyTable(_reward)
            _reward.Count = reward.Count
            GameReward:onPlayerGetReward(self, _reward)
            table.insert(ids, reward.RewardId)
            counts[tostring(reward.RewardId)] = reward.Count
        end
    end
    CommonPacketSender:sendBedWarRewardResult(self.rakssid, table.concat(ids, "#"), counts)
    TableUtil.tableRemove(self.lv_up_rewards, lv)
    self:syncLvUpInfo()
end

function HallPlayer:showIronConversion(ironNum)
    self:sendPacket({
        pid = "SyncIronConversion",
        data = {
            iron = ironNum,
            page = 3
        }
    })
end

function HallPlayer:syncActivityPageData()
    local today = DateUtil.getYearDay()
    local function renewalActivityPageData(data)
        for i, v in pairs(data) do
            if v.popUpType then
                if v.popUpType == "1" and today ~= v.day then
                    data[i] = nil
                end
            else
                data[i] = nil
            end
        end
    end
    renewalActivityPageData(self.activityPageData)
    self:sendPacket({
        pid = "SyncActivityPageData",
        data = self.activityPageData
    })
end

function HallPlayer:checkUECompensate()
    if not self.ueCompensate then
        return
    end
    local allCompensate = CommonCompensateConfig:getAllCompensate()
    for key, compensate in pairs(allCompensate) do
        if self.ueCompensate[key] and not self.compensationCompletion[key] and self.ueCompensate[key] > 0 then
            --- 开始补偿
            local result = self:startUECompensate(compensate, self.ueCompensate[key])
            if result then
                self.compensationCompletion[key] = true
            end
        end
    end
end

function HallPlayer:startUECompensate(compensateInfo, count)
    if not compensateInfo then
        return
    end
    if compensateInfo.maxNum and compensateInfo.maxNum > -1 then
        count = math.min(count, compensateInfo.maxNum)
    end
    local itemInfo = compensateInfo.itemInfo
    local rewardIds = {}
    local counts = {}
    for realId, num in pairs(itemInfo) do
        table.insert(rewardIds, realId)
        counts[tostring(realId)] = num * count
        Events.CommonReceiveRewardEvent:invoke(self, "RewardSetting", realId, num * count)
    end
    CommonPacketSender:sendBedWarCompensateResult(self.rakssid, table.concat(rewardIds, "#"), counts, compensateInfo.title, compensateInfo.dec)
    return true
end

return HallPlayer

--endregion


