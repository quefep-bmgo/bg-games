local CGameTimeTask = class("GameTimeTask", ITask)
CGameTimeTask.GameStage = 0
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type GameStateReport
local GameStateReport = T(Global, "GameStateReport")
---@type GameResourceManager
local GameResourceManager = T(Global, "GameResourceManager")
---@type MapUtil
local MapUtil = T(Global, "MapUtil")
---@type RuneManager
local RuneManager = T(Global, "RuneManager")

function CGameTimeTask:onTick(ticks)
    if ticks >= GameConfig.gameTime then
        self:stop()
        return
    end
    if ticks == tonumber(GameConfig:getStatusTime(self.GameStage + 1)) then
        self.GameStage = self.GameStage + 1
        GameResourceManager:onGameStageChange(self.GameStage)
    end
    self:onGameTick(ticks)
    MapUtil:tryRollbackBlock()
    --GoldIngotPrivilege:onTick(ticks)
    AddHPGain:onTick(ticks)
    MountManager:onTick()
    SkillManager:onSecond()
    WorldInfo:onTick(ticks)
    GameMatch:checkInArea()
    GameMatch:checkDisconnectPlayer(ticks)
    if CollisionManager then
        CollisionManager:checkCollision()
    end
    for _, team in pairs(GameMatch.Teams) do
        team:getRealLifePlayerCount()
    end
    CreditScoreUtil:checkPlayerActive()
end

function CGameTimeTask:onGameTick(ticks)
    local players = PlayerManager:getPlayers()
    local countDown = GameConfig.autoAddHp[1].countDown
    local addHpValue = GameConfig.autoAddHp[1].addHpValue
    for _, player in pairs(players) do
        if player.isLife or player.realLife then
            countDown = countDown * (1 - player.info:getValue("autoAddHpTimeRate", true))
            if countDown > 0 and ticks % countDown < 1 and not player.banCureBuff then
                local subReplyLv = player:getCurativeRate()
                local addHp = addHpValue * (1 + (player.info:getValue("autoAddHpRate", true))) * subReplyLv
                player:addHealth(addHp)
            end
            RuneManager:onTick(player, ticks)
            Plugins.CallTargetPluginFunc("imbue", "onTick", player, ticks)
            player.isRespawn = false
        end
    end
end

function CGameTimeTask:stop()
    SecTimer.stopTimer(self.timer)
    GameMatch:endMatch()
end

function CGameTimeTask:onCreate()
    WorldInfo:init()
    GameResourceManager:onGameStart()
    GameStateReport:reportGameStart()
end

GameTimeTask = CGameTimeTask.new(GameMatch.Status.GameRunning)

return GameTimeTask
