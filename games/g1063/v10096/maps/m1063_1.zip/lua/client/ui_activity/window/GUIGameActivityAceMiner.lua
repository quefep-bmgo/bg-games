---@class GUIGameActivityAceMinerWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameActivityAceMinerWindow = class("GUIGameActivityAceMinerWindow", GUICommonActivityPanel)
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function GUIGameActivityAceMinerWindow:ctor(...)
	self.super.ctor(self, "GameActivityAceMiner.json", ...)
end

local maskOffset = {
	620,
	720,
	820,
	880,
	960,
	1020,
	1180,
	1200
}

local minerOffset = {
	-300,
	-200,
	-100,
	-40,
	40,
	100,
	260,
	500
}

---@private
function GUIGameActivityAceMinerWindow:onChildLoad()
	self.siBg = self:getChildWindowByName("GameActivityAceMiner-Bg", GUIType.StaticImage)
	self.siLightEffect1 = self:getChildWindowByName("GameActivityAceMiner-light_Effect_1", GUIType.StaticImage)
	self.siLight1 = self:getChildWindowByName("GameActivityAceMiner-light_1", GUIType.StaticImage)
	self.siLightEffect2 = self:getChildWindowByName("GameActivityAceMiner-light_Effect_2", GUIType.StaticImage)
	self.siLight2 = self:getChildWindowByName("GameActivityAceMiner-light_2", GUIType.StaticImage)
	self.siLightEffect3 = self:getChildWindowByName("GameActivityAceMiner-light_Effect_3", GUIType.StaticImage)
	self.siLight3 = self:getChildWindowByName("GameActivityAceMiner-light_3", GUIType.StaticImage)
	self.siLightEffect4 = self:getChildWindowByName("GameActivityAceMiner-light_Effect_4", GUIType.StaticImage)
	self.siLight4 = self:getChildWindowByName("GameActivityAceMiner-light_4", GUIType.StaticImage)
	self.siMask = self:getChildWindowByName("GameActivityAceMiner-Mask", GUIType.StaticImage)
	self.siMask2 = self:getChildWindowByName("GameActivityAceMiner-Mask2", GUIType.StaticImage)
	self.stTitle = self:getChildWindowByName("GameActivityAceMiner-Title", GUIType.StaticText)
	self.siCountDownIcon = self:getChildWindowByName("GameActivityAceMiner-CountDown-Icon", GUIType.StaticImage)
	self.stTime = self:getChildWindowByName("GameActivityAceMiner-Time", GUIType.StaticText)
	self.siDescBg = self:getChildWindowByName("GameActivityAceMiner-Desc-Bg", GUIType.StaticImage)
	self.stDescContent = self:getChildWindowByName("GameActivityAceMiner-Desc-Content", GUIType.StaticText)
	self.btnBuy = self:getChildWindowByName("GameActivityAceMiner-Buy", GUIType.Button)
	self.stBuyTxt = self:getChildWindowByName("GameActivityAceMiner-Buy-Txt", GUIType.StaticText)
	self.siBuyImage = self:getChildWindowByName("GameActivityAceMiner-Buy-Image", GUIType.StaticImage)
	self.stBuyFree = self:getChildWindowByName("GameActivityAceMiner-Buy-Free", GUIType.StaticText)
	self.siBuyPriceIcon = self:getChildWindowByName("GameActivityAceMiner-Buy-Price-Icon", GUIType.StaticImage)
	self.stBuyPriceTxt = self:getChildWindowByName("GameActivityAceMiner-Buy-Price-Txt", GUIType.StaticText)
	self.stBuyShowPriceTxt = self:getChildWindowByName("GameActivityAceMiner-Buy-Show-Price-Txt", GUIType.StaticText)
	self.siBuyCountDownIcon = self:getChildWindowByName("GameActivityAceMiner-Buy-CountDown-Icon", GUIType.StaticImage)
	self.stBuyCountDown = self:getChildWindowByName("GameActivityAceMiner-Buy-CountDown", GUIType.StaticText)
	self.siBuyRedDot = self:getChildWindowByName("GameActivityAceMiner-Buy-RedDot", GUIType.StaticImage)
	self.siMiner = self:getChildWindowByName("GameActivityAceMiner-Miner", GUIType.StaticImage)
	self.siChat = self:getChildWindowByName("GameActivityAceMiner-Chat", GUIType.StaticImage)
	self.stChatTxt = self:getChildWindowByName("GameActivityAceMiner-Chat-Txt", GUIType.StaticText)
	self.siPath1 = self:getChildWindowByName("GameActivityAceMiner-Path1", GUIType.StaticImage)
	self.siPath2 = self:getChildWindowByName("GameActivityAceMiner-Path2", GUIType.StaticImage)
	self.siPath3 = self:getChildWindowByName("GameActivityAceMiner-Path3", GUIType.StaticImage)
	self.siPath4 = self:getChildWindowByName("GameActivityAceMiner-Path4", GUIType.StaticImage)
	self.siPath5 = self:getChildWindowByName("GameActivityAceMiner-Path5", GUIType.StaticImage)
	self.siPath6 = self:getChildWindowByName("GameActivityAceMiner-Path6", GUIType.StaticImage)
	self.siItem1Shadow = self:getChildWindowByName("GameActivityAceMiner-Item1_Shadow", GUIType.StaticImage)
	self.siItem1Image = self:getChildWindowByName("GameActivityAceMiner-Item1_Image", GUIType.StaticImage)
	self.stItem1Num = self:getChildWindowByName("GameActivityAceMiner-Item1_Num", GUIType.StaticText)
	self.siItem2Shadow = self:getChildWindowByName("GameActivityAceMiner-Item2_Shadow", GUIType.StaticImage)
	self.siItem2Image = self:getChildWindowByName("GameActivityAceMiner-Item2_Image", GUIType.StaticImage)
	self.stItem2Num = self:getChildWindowByName("GameActivityAceMiner-Item2_Num", GUIType.StaticText)
	self.siItem3Shadow = self:getChildWindowByName("GameActivityAceMiner-Item3_Shadow", GUIType.StaticImage)
	self.siItem3Image = self:getChildWindowByName("GameActivityAceMiner-Item3_Image", GUIType.StaticImage)
	self.stItem3Num = self:getChildWindowByName("GameActivityAceMiner-Item3_Num", GUIType.StaticText)
	self.siItem4Shadow = self:getChildWindowByName("GameActivityAceMiner-Item4_Shadow", GUIType.StaticImage)
	self.siItem4Image = self:getChildWindowByName("GameActivityAceMiner-Item4_Image", GUIType.StaticImage)
	self.stItem4Num = self:getChildWindowByName("GameActivityAceMiner-Item4_Num", GUIType.StaticText)
	self.siItem5Shadow = self:getChildWindowByName("GameActivityAceMiner-Item5_Shadow", GUIType.StaticImage)
	self.siItem5Image = self:getChildWindowByName("GameActivityAceMiner-Item5_Image", GUIType.StaticImage)
	self.stItem5Num = self:getChildWindowByName("GameActivityAceMiner-Item5_Num", GUIType.StaticText)
	self.siItem6Shadow = self:getChildWindowByName("GameActivityAceMiner-Item6_Shadow", GUIType.StaticImage)
	self.siItem6Image = self:getChildWindowByName("GameActivityAceMiner-Item6_Image", GUIType.StaticImage)
	self.stItem6Num = self:getChildWindowByName("GameActivityAceMiner-Item6_Num", GUIType.StaticText)
	self.siItem7 = self:getChildWindowByName("GameActivityAceMiner-Item7", GUIType.StaticImage)
	self.siEffect = self:getChildWindowByName("GameActivityAceMiner-Effect", GUIType.StaticImage)
	self.siFrontGround = self:getChildWindowByName("GameActivityAceMiner-FrontGround", GUIType.StaticImage)
	self.awActorItem = self:getChildWindowByName("GameActivityAceMiner-ActorItem", GUIType.ActorWindow)
	self.siFlyImage = self:getChildWindowByName("GameActivityAceMiner-FlyImage", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameActivityAceMinerWindow:initView()
	self.stTitle:SetText(Lang:getString(self.mgr.mainConfig.titleLang))
	self.stDescContent:SetText(Lang:getString("gui.aceMiner.desc"))
	self.stBuyTxt:SetText(Lang:getString("gui.aceMiner.buy"))
	self.stBuyFree:SetText(Lang:getString("gui.aceMiner.free"))

	self.siBuyCountDownIcon:SetVisible(false)
	self.siBuyPriceIcon:SetVisible(false)
	self.stBuyFree:SetVisible(false)
	self.siFlyImage:SetVisible(false)

	self.boxList = {
		self.siItem1Shadow,
		self.siItem2Shadow,
		self.siItem3Shadow,
		self.siItem4Shadow,
		self.siItem5Shadow,
		self.siItem6Shadow,
		self.siItem7,
	}

	self.pathList = {
		self.siPath1,
		self.siPath2,
		self.siPath3,
		self.siPath4,
		self.siPath5,
		self.siPath6,
	}

	self.boxListImage = {
		self.siItem1Image,
		self.siItem2Image,
		self.siItem3Image,
		self.siItem4Image,
		self.siItem5Image,
		self.siItem6Image,
		self.siItem7,
	}

	self.itemNumList = {
		self.stItem1Num,
		self.stItem2Num,
		self.stItem3Num,
		self.stItem4Num,
		self.stItem5Num,
		self.stItem6Num,
	}

	for i, v in pairs(self.itemNumList) do
		v:SetVisible(false)
	end
end

local function setBuyButtonEnable(self, isEnable)
	self.btnBuy:SetTouchable(isEnable)
	if isEnable then
		self.btnBuy:SetDrawColor({1, 1, 1, 1})
		self.siBuyImage:SetDrawColor({1, 1, 1, 1})
		self.stBuyTxt:SetTextColor({255 / 255, 254 / 255, 205 / 255, 1})
	else
		self.stBuyTxt:SetTextColor({128 / 255, 128 / 255, 128 / 255, 1})
		self.btnBuy:SetDrawColor({0.5, 0.5, 0.5, 1})
		self.siBuyImage:SetDrawColor({0.5, 0.5, 0.5, 1})
	end
end

local function setFlyAnimation(self, callback)
	if self.flyTimer then
		LuaTimer:cancel(self.flyTimer)
		self.flyTimer = nil
	end
	self.btnBuy:SetTouchable(false)
	self.siFlyImage:SetVisible(true)
	self.siFlyImage:SetArea({0, 127}, {0, 260}, {0, 68}, {0, 70})
	local xPos = self.siMiner:GetXPosition()[2]
	local yPos = self.siMiner:GetYPosition()[2]
	local selfXPos = self.siFlyImage:GetXPosition()[2]
	local selfYPos = self.siFlyImage:GetYPosition()[2]

	local count = 1000
	local diffX = (xPos - selfXPos ) / count
	local diffY = (yPos - selfYPos) / count
	local diffWidth = 50 / count
	local diffHeight = 50 / count
	local index = 1
	self.flyTimer = LuaTimer:scheduleTimer(function()
		selfXPos = self.siFlyImage:GetXPosition()[2] + diffX
		selfYPos = self.siFlyImage:GetYPosition()[2] + diffY
		self.siFlyImage:SetXPosition({0, selfXPos})
		self.siFlyImage:SetYPosition({0, selfYPos})
		local selfWidth = self.siFlyImage:GetWidth()[2]
		local selfHeight = self.siFlyImage:GetHeight()[2]
		selfWidth = selfWidth - diffWidth
		selfHeight = selfHeight - diffHeight
		self.siFlyImage:SetWidth({0, selfWidth})
		self.siFlyImage:SetHeight({0, selfHeight})

		if index == count then
			if callback then
				callback()
			end
			self.siFlyImage:SetVisible(false)
			LuaTimer:cancel(self.flyTimer)
			self.flyTimer = nil
		end
		index = index + 1
	end, 1)
end

local function setBoxImage(self, index)
	if index == self.mgr:getMaxBoxNum() then
		return
	end
	local cfg = self.mgr:getActivityCfgByBoxId(index)
	local rewardPool = cfg.showRewardPool
	if not rewardPool then
		return
	end
	local rewardId = rewardPool[1] and rewardPool[1].id or 0
	if rewardId == 0 then
		return
	end
	local rewardCfg = CommonActivityConfig:getRewardById(rewardId)
	self.boxListImage[index]:SetImage(rewardCfg.image)
	self.boxList[index]:SetImage(rewardCfg.image)
	self.boxList[index]:SetWidth({0, self.mgr.config[index].imageWidth})
	self.boxList[index]:SetHeight({0, self.mgr.config[index].imageHeight})
	local num = rewardPool[1].num
	if num > 1 then
		self.itemNumList[index]:SetVisible(true)
		self.itemNumList[index]:SetText("x"..num)
	end
	local reward = RewardConfig:getRewardById(rewardId)
	if not reward then
		return
	end
	if reward.RewardType == Define.RewardType.HEAD_IMAGE then
		local frame = GUIManager:createGUIWindow(GUIType.StaticImage, "GameActivityAceMiner-Item" .. index .. "_Frame")
		frame:SetImage("set:bed_war_3_common_part.json image:edge")
		frame:SetTouchable(false)
		frame:SetProperty("Material", "CullBackLinear")
		frame:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
		frame:SetHorizontalAlignment(HorizontalAlignment.Center)
		frame:SetVerticalAlignment(VerticalAlignment.Center)
		self.boxListImage[index]:AddChildWindow(frame)
	end
end

---@private
function GUIGameActivityAceMinerWindow:initEvent()
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		local cache = self.mgr.dataCache
		if cache.receiveCount >= self.mgr:getMaxBoxNum() then
			return
		end
		local num = cache.receiveCount + 1
		PayHelper.checkMoney(CurrencyId.GCube, self.mgr.config[num].price, function(success)
			if success then
				if self.mgr.config[num].price > 0 then
					CustomDialog.builder()
								.setTitleText("gui.store.purchase.title")
								.setContentText(Lang:getString("gui.store.purchase.tip"))
								.setRightIcon(PayHelper.getMoneyIcon(CurrencyId.GCube))
								.setRightText(tostring(self.mgr.config[num].price))
								.setRightClickListener(function()
						setFlyAnimation(self, function()
							self.mgr:buy()
							local soundId = 381
							SoundUtil.playSound(soundId)
							self.siMiner:SetEffectName("g1008_ui_miner_wukuang.effect")
							self.siChat:SetVisible(false)
						end)
					end).show()
				else
					setFlyAnimation(self, function()
						self.mgr:buy()
						local soundId = 381
						SoundUtil.playSound(soundId)
						self.siMiner:SetEffectName("g1008_ui_miner_wukuang.effect")
						self.siChat:SetVisible(false)
					end)
				end
			end
		end).setRechargeFunc(function()
			ClientHelper.onRecharge(1, "activity_level_" .. self.mgr.mainConfig.id)
		end)
	end)

	self.mgr:registerCacheChange(function()
		self:updateRedPoint()
	end)

	for index, box in pairs(self.boxListImage) do
		box:registerEvent(GUIEvent.Click, function()
			local cfg = self.mgr:getActivityCfgByBoxId(index)
			local rewardPool = cfg.showRewardPool
			--if index ~= self.mgr:getMaxBoxNum() then
			--	UIGameActivityAceMinerBoxDetailLayout:show(rewardPool)
			--	UIGameActivityAceMinerBoxDetailLayout:setData({
			--		title = "gui.aceMiner.reward.list.title"
			--	})
			--else
				if not rewardPool then
					return
				end
				local rewardId = rewardPool[1] and rewardPool[1].id or 0
				if rewardId == 0 then
					return
				end
				local rewardCfg = CommonActivityConfig:getRewardById(rewardId)
				GUICommonActivityRewardDetail:show(rewardCfg.showDetailId)
			--end
		end)
		setBoxImage(self, index)
	end

	self:registerEvent(Events.UpdateAceMinerActivityAnimation, function(start)
		if start then
			self.siMiner:SetEffectName("g1008_ui_miner_wukuang.effect")
		else
			self.siMiner:SetEffectName("g1008_ui_miner_wukuang_1.effect")
			self:refreshUI()
		end
	end)
end

local function setFinalRewardImage(self)
	if self.iconMoveTimer then
		LuaTimer:cancel(self.iconMoveTimer)
		self.iconMoveTimer = nil
	end
	if self.mgr:isGetAllReward() then
		return
	end
	local cfg = self.mgr:getActivityCfgByBoxId(self.mgr:getMaxBoxNum())
	local rewardPool = cfg.rewardPool
	if not rewardPool then
		return
	end
	local rewardId = rewardPool[1] and rewardPool[1].id or 0
	if rewardId == 0 then
		return
	end
	local rewardCfg = CommonActivityConfig:getRewardById(rewardId)
	if not rewardCfg or not rewardCfg.image then
		return
	end
	local detail = RewardItemShowDetailConfig:getConfigById(rewardCfg.showDetailId)
	if detail and detail.actorBodyId and detail.actorBodyId[1] then
		RewardItemShowDetailConfig:showActorSkill(self.awActorItem, detail, nil)
	end
end

function GUIGameActivityAceMinerWindow:refreshUI()
	self.super.refreshUI(self)
	self.siMask:SetVisible(true)
	setBuyButtonEnable(self, true)
	local cache = self.mgr:getPlayerCache()
	local count = cache.receiveCount
	local offset = maskOffset[count + 1]
	self.siMask:SetXPosition({0, offset})
	local offset2 = minerOffset[count + 1]
	self.siMiner:SetXPosition({0, offset2})
	if count == self.mgr:getMaxBoxNum() then
		self.siMask:SetVisible(false)
	end
	for index, v in pairs(self.boxList) do
		if index <= count then
			v:SetVisible(false)
		end
	end

	for index, v in pairs(self.pathList) do
		if index <= count then
			v:SetVisible(false)
		end
	end
	
	setFinalRewardImage(self)
	self:updateRedPoint()
	self.siChat:SetVisible(true)
	if self.mgr:isGetAllReward() then
		self.stChatTxt:SetText(Lang:getString("gui.aceMiner.chat.3"))
		-- 全部领取完了
		self.stBuyFree:SetVisible(false)
		self.siBuyPriceIcon:SetVisible(false)
		self.siBuyCountDownIcon:SetVisible(false)
		setBuyButtonEnable(self, false)
		return
	end

	--if self.mgr:checkCanReceive() then
		-- 当前能购买
		self.stChatTxt:SetText(Lang:getString("gui.aceMiner.chat.1"))
		local price = self.mgr:getCurrentCountPrice()
		if price == 0 then
			-- 价格为0,免费送
			self.stBuyFree:SetVisible(true)
			self.siBuyPriceIcon:SetVisible(false)
			self.siBuyCountDownIcon:SetVisible(false)
			setBuyButtonEnable(self, true)
		else
			-- 正常标价
			self.stBuyFree:SetVisible(false)
			self.siBuyPriceIcon:SetVisible(true)
			self.siBuyCountDownIcon:SetVisible(false)
			self.stBuyPriceTxt:SetText(self.mgr:getCurrentCountPrice())
			self.stBuyShowPriceTxt:SetVisible(self.mgr:getCurrentCountShowPrice() ~= 0)
			self.stBuyShowPriceTxt:SetText(self.mgr:getCurrentCountShowPrice())
			setBuyButtonEnable(self, true)
		end
	--else
	--	self.stChatTxt:SetText(Lang:getString("gui.aceMiner.chat.2"))
	--	-- 时间没到
	--	self.stBuyFree:SetVisible(false)
	--	self.siBuyPriceIcon:SetVisible(false)
	--	self.siBuyCountDownIcon:SetVisible(true)
	--	setBuyButtonEnable(self, false)
	--	if self.timer then
	--		LuaTimer:cancel(self.timer)
	--		self.timer = nil
	--	end
	--	self.timer = LuaTimer:schedule(function()
	--		local startTime = self.mgr:getNextDayStartTime()
	--		local diff = startTime - os.time()
	--		local timeTxt = DateUtil.getFormatTimeWithDay(diff)
	--		self.stBuyCountDown:SetText(timeTxt)
	--		if diff <= 0 then
	--			setBuyButtonEnable(self, true)
	--			LuaTimer:cancel(self.timer)
	--			self.timer = nil
	--		end
	--	end, 0, 1000)
	--end
end

function GUIGameActivityAceMinerWindow:updateRedPoint()
	local count = 0
	local price = self.mgr:getCurrentCountPrice()
	if price == 0 and not self.mgr:isGetAllReward() then
		count = 1
	end
	UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
	self.siBuyRedDot:SetVisible(count > 0 )
end

function GUIGameActivityAceMinerWindow:onShow()
	self:refreshUI()
	self.siMiner:SetEffectName("g1008_ui_miner_wukuang_1.effect")
end

function GUIGameActivityAceMinerWindow:onHide()
	if self.timer then
		LuaTimer:cancel(self.timer)
		self.timer = nil
	end
	if self.iconMoveTimer then
		LuaTimer:cancel(self.iconMoveTimer)
		self.iconMoveTimer = nil
	end
	if self.flyTimer then
		LuaTimer:cancel(self.flyTimer)
		self.flyTimer = nil
	end
	self.siFlyImage:SetVisible(false)
end

return GUIGameActivityAceMinerWindow
