---@class GUIGameLevelActivityPanelWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameLevelActivityPanelWindow = class("GUIGameLevelActivityPanelWindow", GUICommonActivityPanel)
---@type LevelActivityConfig
local LevelActivityConfig = T(Global, "LevelActivityConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameLevelActivityPanelWindow:ctor(...)
	self.super.ctor(self, "GameLevelActivityPanel.json", ...)
end

---@private
function GUIGameLevelActivityPanelWindow:onChildLoad()
	self.siBg = self:getChildWindowByName("GameLevelActivityPanel-Bg", GUIType.StaticImage)
	self.siTreasureBoxIcon = self:getChildWindowByName("GameLevelActivityPanel-TreasureBoxIcon", GUIType.StaticImage)
	self.siTitle = self:getChildWindowByName("GameLevelActivityPanel-Title", GUIType.StaticImage)
	self.stDescTitle = self:getChildWindowByName("GameLevelActivityPanel-Desc-Title", GUIType.StaticText)
	self.stDesc = self:getChildWindowByName("GameLevelActivityPanel-Desc", GUIType.StaticText)
	self.siHead = self:getChildWindowByName("GameLevelActivityPanel-Head", GUIType.StaticImage)
	self.siHeadBg = self:getChildWindowByName("GameLevelActivityPanel-HeadBg", GUIType.StaticImage)
	self.stLevelTitle = self:getChildWindowByName("GameLevelActivityPanel-Level-Title", GUIType.StaticText)
	self.stLevel = self:getChildWindowByName("GameLevelActivityPanel-Level", GUIType.StaticText)
	self.btnBuy = self:getChildWindowByName("GameLevelActivityPanel-Buy", GUIType.Button)
	self.siGDiamond = self:getChildWindowByName("GameLevelActivityPanel-GDiamond", GUIType.StaticImage)
	self.stPrice = self:getChildWindowByName("GameLevelActivityPanel-Price", GUIType.StaticText)
	self.stText = self:getChildWindowByName("GameLevelActivityPanel-Text", GUIType.StaticText)
	self.stReceive = self:getChildWindowByName("GameLevelActivityPanel-Receive", GUIType.StaticText)
	self.stLimitTitle = self:getChildWindowByName("GameLevelActivityPanel-Limit-Title", GUIType.StaticText)
	self.stLimit = self:getChildWindowByName("GameLevelActivityPanel-Limit", GUIType.StaticText)
	self.siGameLevelActivityPanelRewardPanel = self:getChildWindowByName("GameLevelActivityPanel-GameLevelActivityPanel-RewardPanel", GUIType.StaticImage)
	self.llContainer = self:getChildWindowByName("GameLevelActivityPanel-Container", GUIType.Layout)
	self.pbLevelProgress = self:getChildWindowByName("GameLevelActivityPanel-Level-Progress", GUIType.ProgressBar)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameLevelActivityPanelWindow:ScrollMoveChangeListener(args)
	if self.curOffset ~= args.offset then
		self.curOffset = args.offset
		if self.curOffset < -self.maxOffset then
			self.curOffset = -self.maxOffset
			self.lvRewards.root:SetScrollOffset(self.curOffset)
		end
		self:updateLevelLineUI()
	end
end

function GUIGameLevelActivityPanelWindow:showFirstCanReceiveRewardPosition()
	local firstReceivedIndex = -1
	for index, reward in pairs(self.rewards) do
		if not self.mgr:isRewardReceived(reward.id) then
			firstReceivedIndex = index
			break
		end
	end
	if firstReceivedIndex == -1 then
		firstReceivedIndex = #self.rewards - 1
	else
		firstReceivedIndex = firstReceivedIndex - 4 -- - 1  -- 这个-4而不是-1,因为策划需求要把物品放中间，大概是4个位置
	end
	local offset = -math.min(firstReceivedIndex * 150, self.maxOffset)
	local times = math.floor(math.abs((offset - self.curOffset) / 300))
	if times <= 0 then
		return
	end
	LuaTimer:scheduleTickerWithEnd(function()
		self.rewardAdapter:setScrollOffset(self.curOffset - 300)
	end, function()
		local scoreOffset = self.lvRewards.root:GetScrollOffset()
		if scoreOffset > offset then
			self.rewardAdapter:setScrollOffset(scoreOffset + 78)
			self.rewardAdapter:setScrollOffset(offset)
		else
			self.rewardAdapter:setScrollOffset(offset)
		end
	end, 1, times)
end

function GUIGameLevelActivityPanelWindow:updateLevelLineUI()
	local items = self.rewards
	if #items == 0 then
		return
	end
	self.pbLevelProgress:SetXPosition({ 0, math.min(self.curOffset, 0) })
	local level = self.mgr:getLevel()
	if level == 0 then
		self.pbLevelProgress:SetProgress(0)
		return
	end
	if level >= items[#items].level then
		self.pbLevelProgress:SetProgress(1)
		return
	end
	local count = #items
	local percent = 1 / (count * 2 - 1)
	local progress = -percent
	percent = percent * 2
	local offset = self.lvRewards.root:GetScrollOffset()
	if offset > 0 then
		progress = progress + (offset / 150) * percent
	end
	for i, item in pairs(items) do
		if item.level <= level then
			progress = progress + percent
		else
			if i == 1 then
				progress = progress + (level / item.level) * percent
			else
				local pre = items[i - 1]
				progress = progress + ((level - pre.level) / (item.level - pre.level)) * percent
			end
			break
		end
	end
	self.pbLevelProgress:SetProgress(math.max(progress, 0))
end

---@private
function GUIGameLevelActivityPanelWindow:initView()
	self.siTitle:SetImage(UIUtils.GetLangImage("set:game_activity_level_1.json image:text"))

	self.stDescTitle:SetText(Lang:getString("gui.activity.level.desc.title"))
	self.stDesc:SetText(Lang:getString("gui.activity.level.desc.content"))
	self.stLevelTitle:SetText(Lang:getString("gui.activity.level.curLevel"))
	self.stText:SetText(Lang:getString("gui.activity.level.buy"))
	self.stReceive:SetText(Lang:getString("gui.one.key.receive"))
	self.stLimit:SetText(Lang:getString("gui.activity.level.limit.buy"))
	self.stLimitTitle:SetText(Lang:getString("gui.activity.level.limit.title"))

	self.siGDiamond:SetVisible(false)
	self.stText:SetVisible(false)
	--self.stLimit:SetVisible(false)
	self.stReceive:SetVisible(false)
	self.stPrice:SetText(self.mgr.config.price)

	local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
	self.headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
	self.headItem:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.siHead:AddChildWindow(self.headItem.root)
	self.headItem:setUserInfo(userInfo)
	self.headItem:setCanOpenPersonalHome(false)

	local rewards = LevelActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
	self.lvRewards = IGUIListView.new("GameLevelActivityPanel-Rewards" .. self.activity.activityId, self.llContainer, nil, Orientation.Horizontal)
	---@type LevelActivityRewardAdapter
	self.rewardAdapter = UIHelper.requireAdapter("LevelActivityRewardAdapter", false, "ui_activity").new()
	self.rewardAdapter:setActivityMgr(self.mgr)
	self.lvRewards:setAdapter(self.rewardAdapter)
	self.rewards = rewards
	self.rewardAdapter:setData(self.rewards)

	self.curOffset = 0
	local normalLength = self.lvRewards:getItemCount() * 150
	self.lineLength = normalLength - 68
	self.maxOffset = normalLength - self.lvRewards.root:GetPixelSize().x

	self.lvRewards.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
		return self:ScrollMoveChangeListener(args)
	end)

	self.pbLevelProgress:SetWidth({ 0, self.lineLength })

	self:refreshUI()
end

local function getKeyCount(rewards, level)
	local nowReceive = 0
	local totalReceive = 0
	for _, v in pairs(rewards) do
		if v.reward.type == "Key" then
			totalReceive = totalReceive + v.reward.num
			if level >= v.level then
				nowReceive = nowReceive + v.reward.num
			end
		end
	end

	return nowReceive, totalReceive
end

---@private
function GUIGameLevelActivityPanelWindow:initEvent()
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		local cache = self.mgr:getPlayerCache()
		if not cache.haveBuy then
			local nowReceive, totalReceive = getKeyCount(self.rewards, cache.level)
			local data = {
				price = self.mgr.config.price,
				num1 = nowReceive,
				num2 = totalReceive,
				successCallBack = function()
					PayHelper.checkMoney(self.mgr.config.moneyType, self.mgr.config.price, function(success)
						if success then
							self.mgr:onBuyPrivilege()
						end
					end).setRechargeFunc(function()
						ClientHelper.onRecharge(1, "activity_level_" .. self.mgr.mainConfig.id)
					end)
				end
			}
			---@type UIGameLevelActivityDialogLayout
			if not LevelActivityDialogLayout then
				LevelActivityDialogLayout = UIHelper.newGameGUILayout("GUIGameLevelActivityDialog")
			end
			LevelActivityDialogLayout:show(data)
		else
			local result = {}
			local level = self.mgr:getLevel()
			for _, reward in pairs(self.rewards) do
				if level >= reward.level and not self.mgr:isRewardReceived(reward.id)  then
					table.insert(result, reward)
				end
			end
			if #result > 0 then
				self.mgr:tryGetReward(0)
			end
		end
	end)

	self.mgr:registerCacheChange(function()
		if self:isShow() then
			self:refreshUI()
		else
			self:updateRedPoint()
		end
	end)
end

function GUIGameLevelActivityPanelWindow:refreshUI()
	self.super.refreshUI(self)

	local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
	local haveBuy = cache.haveBuy
	self.siGDiamond:SetVisible(not haveBuy)
	self.stText:SetVisible(not haveBuy)
	--self.stLimit:SetVisible(not haveBuy)
	self.stReceive:SetVisible(haveBuy)
	self.btnBuy:SetVisible(true)
	self.stLevel:SetText("Lv." .. cache.level)
	if haveBuy then
		local count = self:updateRedPoint()
		--self.btnBuy:SetVisible(count > 0)
	end
	local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
	self.headItem:setUserInfo(userInfo)
	if self.rewardAdapter then
		self.rewardAdapter:notifyDataChange()
	end
	self:updateLevelLineUI()
end

function GUIGameLevelActivityPanelWindow:updateRedPoint()
	local count = 0
	local level = self.mgr:getLevel()
	local cache = self.mgr:getPlayerCache()
	for _, reward in pairs(self.rewards) do
		if not self.mgr:isRewardReceived(reward.id) and level >= reward.level and cache.haveBuy then
			count = count + 1
		end
	end
	UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
	return count
end

function GUIGameLevelActivityPanelWindow:onShow()
	self:refreshUI()
	self:showFirstCanReceiveRewardPosition()
	self.mgr:updateLastOpenUIDate()
end

return GUIGameLevelActivityPanelWindow
