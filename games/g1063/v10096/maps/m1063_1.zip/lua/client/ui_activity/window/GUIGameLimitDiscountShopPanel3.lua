---@class GUIGameLimitDiscountShopPanel3Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameLimitDiscountShopPanel3Window = class("GUIGameLimitDiscountShopPanel3Window", GUICommonActivityPanel)
---@type LimitDiscountShopConfig
local LimitDiscountShopConfig = Plugins.Require("activity", "common.config.LimitDiscountShopConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameLimitDiscountShopPanel3Window:ctor(...)
    self.json_name = "GameLimitDiscountShopPanel3.json"
    self.super.ctor(self, "GameLimitDiscountShopPanel3.json", ...)
end

---@private
function GUIGameLimitDiscountShopPanel3Window:onChildLoad()
    ---@type CLimitDiscountShopMgr
    self.mgr = self.mgr
    self.items = {}
    self.endTime = self.mgr.mainConfig.endTime
    self.siTitle = self:getChildWindowByName("GameLimitDiscountShopPanel3-Title-Img", GUIType.StaticImage)
    self.siTipIcon = self:getChildWindowByName("GameLimitDiscountShopPanel3-Tip-Icon", GUIType.StaticImage)
    self.stCountDown = self:getChildWindowByName("GameLimitDiscountShopPanel3-Count-Down", GUIType.StaticText)
    self.siBg = self:getChildWindowByName("GameLimitDiscountShopPanel3-Bg", GUIType.StaticImage)
    self.llContent = self:getChildWindowByName("GameLimitDiscountShopPanel3-Content", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameLimitDiscountShopPanel3Window:initView()
    local rewards = LimitDiscountShopConfig:getDiscountShopItems(self.mgr.config.groupId)
    local num = #rewards
    local contentWidth = self.llContent:GetPixelSize().x
    local interval = 0
    local itemX = 0
    local offset = 0
    local itemWidth = (contentWidth - (num - 1) * interval) / num
    for i = 1, num do
        ---@type GUIGameLimitDiscountShopItem2Window
        local item = UIHelper.requireGUIWindow("GUIGameLimitDiscountShopItem3", false, "ui_activity").new("", self.mgr)
        self.llContent:AddChildWindow(item.root)
        if i > 1 then
            itemX = itemX + interval + itemWidth
            offset = (i - 1) * -3
        end
        item:onDataChanged(rewards[i], offset)
        item.root:SetArea({ 0, itemX }, { 0, 0 }, { 0, itemWidth }, { 1, 0 })
        self.items[tostring(rewards[i].id)] = item
    end
    --if self.mgr.config.titleImageFile ~= "#" then
    --	local image = "set:" .. self.mgr.config.titleImageFile .. ".json image:text"
    --	UIHelper:setImageAdjustSize(self.siTitle, UIUtils.GetLangImage(image), 9999, 9999)
    --end
end

---@private
function GUIGameLimitDiscountShopPanel3Window:initEvent()
    self.siTipIcon:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("limit.discount.shop.info.title")
                    .setContentText(Lang:getString(self.mgr.mainConfig.descLang))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self.mgr:registerCacheChange(function()
        if not self:isShow() then
            return
        end
        self:refreshUI()
    end)
end

function GUIGameLimitDiscountShopPanel3Window:onShow()
    if not self.first then
        self:refreshUI()
        self.first = true
    end
    for id, item in pairs(self.items) do
        item:onWindowShow()
    end
end

function GUIGameLimitDiscountShopPanel3Window:onSecondTick()
    if not self:isShow() then
        return
    end
    self.lastTime = self.endTime - os.time()
    if self.lastTime <= 0 then
        return
    end
    if self.lastTime >= DateUtil.getDaySeconds() then
        local text = Lang:format("common.activity.day", tostring(math.floor(self.lastTime / DateUtil.getDaySeconds())))
        self.stCountDown:SetText(text)
    else
        self.stCountDown:SetText(DateUtil.getFormatTime(self.lastTime))
    end
end

function GUIGameLimitDiscountShopPanel3Window:refreshUI()
    local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
    if not self.items or not cache then
        return
    end
    for id, item in pairs(self.items) do
        local itemCache = cache.buyItems[tostring(id)]
        if itemCache then
            item:setCannotBuy()
        end
    end
end

function GUIGameLimitDiscountShopPanel3Window:onHide()
    for id, item in pairs(self.items) do
        item:onWindowHide()
    end
end

return GUIGameLimitDiscountShopPanel3Window
