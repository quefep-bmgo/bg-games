---@class GUIGameActivityDirectSaleWindow : GUIGameActivityPanel
------@field super GUIGameActivityPanel
local GUIGameActivityDirectSaleWindow = class("GUIGameActivityDirectSaleWindow", GUICommonActivityPanel)
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type DirectSaleConfig
local DirectSaleConfig = Plugins.Require("activity", "common.config.DirectSaleConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function GUIGameActivityDirectSaleWindow:ctor(...)
	self.super.ctor(self, "GameActivityDirectSale.json", ...)
end

---@private
function GUIGameActivityDirectSaleWindow:onChildLoad()
	self.siBg = self:getChildWindowByName("GameActivityDirectSale-Bg", GUIType.StaticImage)
	self.stTitle = self:getChildWindowByName("GameActivityDirectSale-Title", GUIType.StaticText)
	self.siCountDownIcon = self:getChildWindowByName("GameActivityDirectSale-CountDown-Icon", GUIType.StaticImage)
	self.awActor = self:getChildWindowByName("GameActivityDirectSale-Actor", GUIType.ActorWindow)
	self.stDesc = self:getChildWindowByName("GameActivityDirectSale-Desc", GUIType.StaticText)
	self.llItems = self:getChildWindowByName("GameActivityDirectSale-Items", GUIType.Layout)
	self.siDiscount = self:getChildWindowByName("GameActivityDirectSale-Discount", GUIType.StaticImage)
	self.btnBuy = self:getChildWindowByName("GameActivityDirectSale-Buy", GUIType.Button)
	self.siGCube = self:getChildWindowByName("GameActivityDirectSale-GCube", GUIType.StaticImage)
	self.stPrice = self:getChildWindowByName("GameActivityDirectSale-Price", GUIType.StaticText)
	self.stOriginPrice = self:getChildWindowByName("GameActivityDirectSale-OriginPrice", GUIType.StaticText)
	self.siLine = self:getChildWindowByName("GameActivityDirectSale-line", GUIType.StaticImage)
	self.stHaveBuy = self:getChildWindowByName("GameActivityDirectSale-Have-Buy", GUIType.StaticText)
	self.llSlide = self:getChildWindowByName("GameActivityDirectSale-Actor-Slide", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameActivityDirectSaleWindow:initView()
	self.stTitle:SetText(Lang:getString(self.mgr.mainConfig.titleLang))
	self.stDesc:SetText(Lang:getString("gui.direct.sale.content"))
	self.stHaveBuy:SetText(Lang:getString("gui.direct.sale.have.buy"))
	self.stPrice:SetText(self.mgr.config.price)
	self.stOriginPrice:SetText(self.mgr.config.originPrice)

	---@type GUICommonActivityRewardFloat
	self.wFloatReward = UIHelper.newEngineGUIWindow("GUICommonActivityRewardFloat")
	self.root:AddChildWindow(self.wFloatReward.root)

	local directSaleItemWindow = UIHelper.requireGUIWindow("GUIGameActivityDirectSaleItem", false, "ui_activity")
	local xPos = 0
	local offset = 20
	local rewards = DirectSaleConfig:getRewardGroup(self.mgr.config.rewardGroupId)
	for _, cfg in pairs(rewards) do
		local data = DirectSaleConfig:getRewardById(cfg.id)
		if data then
			if not self.showDetail then
				self.showDetail = RewardItemShowDetailConfig:getConfigById(data.reward.showDetailId)
			end
			local item = directSaleItemWindow.new()
			item:onDataChanged({ parent = self, reward = data.reward })
			item:setXPosition({0, xPos})
			xPos = xPos + offset + 83
			self.llItems:AddChildWindow(item.root)
		end
	end
end

---@private
function GUIGameActivityDirectSaleWindow:initEvent()
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		local cache = self.mgr:getPlayerCache()
		if cache.haveBuy then
			return
		end
		CustomDialog.builder()
					.setTitleText("gui.store.purchase.title")
					.setContentText(Lang:getString("gui.store.purchase.tip"))
					.setRightIcon(PayHelper.getMoneyIcon(self.mgr.config.moneyType))
					.setRightText(tostring(self.mgr.config.price))
					.setRightClickListener(function()
			LuaTimer:schedule(function()
				PayHelper.checkMoney(self.mgr.config.moneyType, self.mgr.config.price, function(success)
					if success then
						self.mgr:onBuyDirectSale()
					end
				end)
			end, 50)
		end).show()
	end)

	self.mgr:registerCacheChange(function()
		if self:isShow() then
			self:refreshUI()
		end
	end)
end

function GUIGameActivityDirectSaleWindow:onSecondTick()
	self.super.onSecondTick(self)
end

function GUIGameActivityDirectSaleWindow:refreshUI()
	self.super.refreshUI(self)

	self.siGCube:SetVisible(true)
	self.stOriginPrice:SetVisible(true)
	self.stHaveBuy:SetVisible(false)
	self.btnBuy:SetTouchable(true)
	self.btnBuy:SetDrawColor({1, 1, 1, 1})

	local cache = self.mgr:getPlayerCache()
	if cache.haveBuy then
		self.btnBuy:SetTouchable(false)
		self.btnBuy:SetDrawColor({0.5, 0.5, 0.5, 1})
		self.siGCube:SetVisible(false)
		self.stOriginPrice:SetVisible(false)
		self.stHaveBuy:SetVisible(true)
	end
end

function GUIGameActivityDirectSaleWindow:clickItem(item)
	self.wFloatReward:showReward(item.reward, item.root)
end

function GUIGameActivityDirectSaleWindow:onShow()
	self:refreshUI()
	RewardItemShowDetailConfig:showActorSkill(self.awActor, self.showDetail, self.llSlide)
end

return GUIGameActivityDirectSaleWindow
