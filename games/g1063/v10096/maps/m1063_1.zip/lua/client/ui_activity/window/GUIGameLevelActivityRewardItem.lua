---@class GUIGameLevelActivityRewardItemWindow : IGUIWindow
local GUIGameLevelActivityRewardItemWindow = class("GUIGameLevelActivityRewardItemWindow", IGUIWindow)
---@type LevelActivityConfig
local LevelActivityConfig = T(Global, "LevelActivityConfig")

---@private
function GUIGameLevelActivityRewardItemWindow:ctor(_, mgr)
	self.super.ctor(self, "GameLevelActivityRewardItem.json", mgr)
end

---@private
function GUIGameLevelActivityRewardItemWindow:onLoad(mgr)
	self.mgr = mgr
	self.siLevel = self:getChildWindowByName("GameLevelActivityRewardItem-Level", GUIType.StaticImage)
	self.stLevelText = self:getChildWindowByName("GameLevelActivityRewardItem-Level-Text", GUIType.StaticText)
	self.siItemBg = self:getChildWindowByName("GameLevelActivityRewardItem-Item-Bg", GUIType.StaticImage)
	self.siItemIcon = self:getChildWindowByName("GameLevelActivityRewardItem-Item-Icon", GUIType.StaticImage)
	self.siReceive = self:getChildWindowByName("GameLevelActivityRewardItem-Receive", GUIType.StaticImage)
	self.siLock = self:getChildWindowByName("GameLevelActivityRewardItem-Lock", GUIType.StaticImage)
	self.siMask = self:getChildWindowByName("GameLevelActivityRewardItem-Mask", GUIType.StaticImage)
	self.siLevelMask = self:getChildWindowByName("GameLevelActivityRewardItem-LevelMask", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("GameLevelActivityRewardItem-Num", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameLevelActivityRewardItemWindow:initView()
	self.siReceive:SetVisible(false)
	self.siMask:SetVisible(true)
	self.siLevelMask:SetVisible(true)
	self.siLock:SetVisible(true)
end

local function getKeyCount(self)
	local nowReceive = 0
	local totalReceive = 0
	local rewards = LevelActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
	for _, v in pairs(rewards) do
		if v.reward.type == "Key" then
			totalReceive = totalReceive + v.reward.num
			if self.mgr:getLevel() >= v.level then
				nowReceive = nowReceive + v.reward.num
			end
		end
	end
	return nowReceive, totalReceive
end

local function showDialog(self)
	local nowReceive, totalReceive = getKeyCount(self)
	local data = {
		price = self.mgr.config.price,
		num1 = nowReceive,
		num2 = totalReceive,
		successCallBack = function()
			PayHelper.checkMoney(self.mgr.config.moneyType, self.mgr.config.price, function(success)
				if success then
					self.mgr:onBuyPrivilege()
				end
			end).setRechargeFunc(function()
				ClientHelper.onRecharge(1, "activity_level_" .. self.mgr.mainConfig.id)
			end)
		end
	}
	---@type UIGameLevelActivityDialogLayout
	if not LevelActivityDialogLayout then
		LevelActivityDialogLayout = UIHelper.newGameGUILayout("GUIGameLevelActivityDialog")
	end
	LevelActivityDialogLayout:show(data)
end

---@private
function GUIGameLevelActivityRewardItemWindow:initEvent()
	self.siItemBg:registerEvent(GUIEvent.Click, function()
		if not self.data then
			return
		end
		if self.data.level > self.mgr:getLevel() then
			-- todo: 提示
			UIHelper.showToast(Lang:format("gui.activity.level.reward.unlock", tostring(self.data.level)))
			return
		end
		local cache = self.mgr:getPlayerCache()
		if not cache.haveBuy then
			showDialog(self)
			return
		end
		if self.mgr:isRewardReceived(self.data.id) then
			UIHelper.showToast(Lang:getString("gui.activity.level.reward.have.receive"))
			return
		end
		self.mgr:tryGetReward(self.data.id)
	end)
end

---@param data table
function GUIGameLevelActivityRewardItemWindow:onDataChanged(data)
	self.siMask:SetVisible(true)
	self.siLevelMask:SetVisible(true)
	self.siLock:SetVisible(true)
	self.siReceive:SetVisible(false)

	if not data.reward then
		self.data = nil
		self.root:SetVisible(false)
		return
	end
	self.data = data
	local image = data.reward.image
	local num = data.reward.num
	local effect = data.reward.effect
	self.siItemIcon:SetImage(image)
	self.stNum:SetText(num)
	self.stLevelText:SetText("Lv." .. data.level)
	local level = self.mgr:getLevel()
	local cache = self.mgr:getPlayerCache()
	if cache.haveBuy then
		self.siLock:SetVisible(false)
	end
	if level >= data.level then
		self.siMask:SetVisible(false)
		self.siLevelMask:SetVisible(false)
	end
	if self.mgr:isRewardReceived(data.id) then
		self.siReceive:SetVisible(true)
	end
end

return GUIGameLevelActivityRewardItemWindow
