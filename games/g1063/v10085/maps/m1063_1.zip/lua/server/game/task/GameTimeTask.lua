local CGameTimeTask = class("GameTimeTask", ITask)
CGameTimeTask.GameStage = 0
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")

function CGameTimeTask:onTick(ticks)
    if ticks >= GameConfig.gameTime then
        self:stop()
        return
    end
    if ticks == tonumber(GameConfig:getStatusTime(self.GameStage + 1)) then
        self.GameStage = self.GameStage + 1
        GameResourceManager:onGameStageChange(self.GameStage)
    end
    self:onGameTick(ticks)
    self:cannotPlaceBlock()
    GoldIngotPrivilege:onTick(ticks)
    AddHPGain:onTick(ticks)
    MountManager:onTick()
    BackHallManager:onTick()
    WorldInfo:onTick(ticks)
    BuffManager:onTick(ticks)
    GameMatch:checkInArea()
    if CollisionManager then
        CollisionManager:checkCollision()
    end
    for _, team in pairs(GameMatch.Teams) do
        team:getRealLifePlayerCount()
    end
    CreditScoreUtil:checkPlayerActive()
end

function CGameTimeTask:cannotPlaceBlock()
    for _, blockPos in pairs(GameMatch.cannotPlaceBlock) do
        EngineWorld:setBlock(blockPos, 0, 0, 3, true)
    end
    GameMatch.cannotPlaceBlock = {}
end

function CGameTimeTask:onGameTick(ticks)
    local players = PlayerManager:getPlayers()
    local countDown = GameConfig.autoAddHp[1].countDown
    local addHpValue = GameConfig.autoAddHp[1].addHpValue
    for _, player in pairs(players) do
        if player.isLife or player.realLife then
            if countDown > 0 and ticks % countDown == 0 and not player.banCureBuff then
                player:addHealth(addHpValue)
            end
            RuneManager:onTick(player, ticks)
            player.isRespawn = false
        end
    end
end

function CGameTimeTask:stop()
    SecTimer.stopTimer(self.timer)
    GameMatch:endMatch()
end

function CGameTimeTask:onCreate()
    GameMatch.curStatus = self.status
    WorldInfo:init()
    GameResourceManager:onGameStart()
end

GameTimeTask = CGameTimeTask.new(GameMatch.Status.GameTime)

return GameTimeTask

--endregion
