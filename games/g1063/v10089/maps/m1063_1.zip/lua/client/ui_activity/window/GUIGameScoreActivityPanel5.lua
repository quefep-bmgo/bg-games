---@class GUIGameScoreActivityPanel5Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameScoreActivityPanel5Window = class("GUIGameScoreActivityPanel5Window", GUICommonActivityPanel)
---@type ScoreActivityConfig
local ScoreActivityConfig = T(Global, "ScoreActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@private
function GUIGameScoreActivityPanel5Window:ctor(...)
    self.json_name = "GameScoreActivityPanel5.json"
    self.super.ctor(self, "GameScoreActivityPanel5.json", ...)
end

---@private
function GUIGameScoreActivityPanel5Window:onChildLoad()
    ---@type CScoreActivityMgr
    self.mgr = self.mgr
    self.iconMovePos = 35
    self.iconMoveGap = 2
    self.siTitleImage = self:getChildWindowByName("GameScoreActivityPanel5-TitleImage", GUIType.StaticImage)
    self.siQuestion = self:getChildWindowByName("GameScoreActivityPanel5-Question", GUIType.StaticImage)
    self.btnExchange = self:getChildWindowByName("GameScoreActivityPanel5-Exchange", GUIType.Button)
    self.siImage = self:getChildWindowByName("GameScoreActivityPanel5-Image", GUIType.StaticImage)
    self.siImageBack = self:getChildWindowByName("GameScoreActivityPanel5-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindowByName("GameScoreActivityPanel5-Image-Top", GUIType.StaticImage)
    self.stScoreText = self:getChildWindowByName("GameScoreActivityPanel5-ScoreText", GUIType.StaticText)
    self.llTaskPanelClip = self:getChildWindowByName("GameScoreActivityPanel5-TaskPanel-Clip", GUIType.Layout)
    self.siTaskPanel = self:getChildWindowByName("GameScoreActivityPanel5-TaskPanel", GUIType.StaticImage)
    self.llTaskPanelTouch = self:getChildWindowByName("GameScoreActivityPanel5-TaskPanel-Touch", GUIType.Layout)
    self.stDailyTaskText = self:getChildWindowByName("GameScoreActivityPanel5-DailyTaskText", GUIType.StaticText)
    self.stTaskTimeText = self:getChildWindowByName("GameScoreActivityPanel5-Task-Time-Text", GUIType.StaticText)
    self.llTaskContent = self:getChildWindowByName("GameScoreActivityPanel5-TaskContent", GUIType.Layout)
    self.stRewardName = self:getChildWindowByName("GameScoreActivityPanel5-Reward-Name", GUIType.StaticText)
    ---@type GUIGameScoreActivityRewardItem5Window[]
    self.rewardItems = {}
    self:initEvent()
    self:initView()
end

function GUIGameScoreActivityPanel5Window:onShow()
    GUIGameActivityLayout:hideTitle()
    self.btnExchange:SetEnabled(false)
    self.siImage:SetVisible(false)
    self.awActor:SetVisible(false)
    self.super.showRewardDetail(self)
    self:refreshUI()
    ReportEvent.display_discount_shop_panel(self.mgr.config.id)
end

---@private
function GUIGameScoreActivityPanel5Window:initView()
    self.siImage:SetVisible(false)
    self.btnExchange:SetText(Lang:getString("gui.exchange"))
    --self.siTitleImage:SetImage(UIUtils.GetLangImage("set:game_activity_score_5.json image:text"))

    self:initTasks()

    local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
    self.rewards = rewards
    ---@type GUIGameScoreActivityRewardItem5Window
    local GUIGameScoreActivityRewardItem5 = UIHelper.requireGUIWindow("GUIGameScoreActivityRewardItem5", false, "ui_activity")
    for index, reward in pairs(self.rewards) do
        if index > 6 then
            return
        end
        local llReward = self:getChildWindowByName("GameScoreActivityPanel5-Reward" .. index, GUIType.Layout)
        if llReward then
            local item = GUIGameScoreActivityRewardItem5.new("", self.mgr)
            item:onDataChanged(reward)
            llReward:AddChildWindow(item.root)
            self.rewardItems[index] = item
        end
    end
end

---@private
function GUIGameScoreActivityPanel5Window:initTasks()
    self.isTaskPanelOpen = false
    self.siTaskPanel:SetImage("")
    self.stDailyTaskText:SetText(Lang:getString("gui.daily.task"))

    local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId) or {}
    table.sort(tasks, function(t1, t2)
        return t1.Id < t2.Id
    end)
    for i = #tasks, 1, -1 do
        local task = tasks[i]
        task.Image = Define.DailyTaskIcon[task.TaskTypeId]
    end
    local count = math.min(#tasks, 6)
    self.llTaskPanelClip:SetHeight({ 0, count * 74 - 2 })
    self.siTaskPanel:SetHeight({ 0, count * 74 + 40 })
    self.lvTaskList = IGUIListView.new("GameScoreActivityPanel5-TaskList" .. self.activity.activityId, self.llTaskContent)
    self.lvTaskList:setItemSpace(6)
    for _, task in pairs(tasks) do
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = UIHelper.requireGUIWindow("GUIGameScoreActivityTaskItem", false, "ui_activity").new(self)
        item:setUIStyle(
                "set:game_activity_score_5.json image:img_0_icon_hat", VectorUtil.newVector2(41 , 47),
                "set:game_activity_score_5.json image:img_0_icon_frame", VectorUtil.newVector2(62, 72),
                { 81 / 255, 44 / 255, 43 / 255, 0.5 })
        item.stDesc:SetTextColor({ 248 / 255, 215 / 255, 196 / 255, 1 })
        item.stScore:SetTextColor({ 1, 1, 1, 1 })
        item.stScore:SetBordered(true)
        item.stScore:SetXPosition({0, 30})
        item.root:SetHeight({ 0, 68 })
        item.siTaskIcon:SetXPosition({ 0, -2 })
        item.siMaskYes:SetXPosition({ 0, -2 })
        item:onDataChanged(task)
        self.lvTaskList:addItem(item)
    end
end

---@private
function GUIGameScoreActivityPanel5Window:initEvent()
    self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
        if not self.curShowReward then
            return
        end
        if self.mgr:getScore() < self.curShowReward.score then
            CustomDialog.builder()
                        .setContentText(Lang:getString("gui.lack.of.score." .. self:getActivityById()))
                        .setHideLeftButton()
                        .show()
            return
        end
        local function tryGetReward()
            CustomDialog.builder()
                        .setTitleText("discount.shop.buy.title")
                        .setContentView(DiscountShopConfirmContent)
                        .setRightClickListener(function()
                self.mgr:tryGetReward(self.curShowReward.id)
            end)        .show()
        end
        if self.curShowReward.price > 0 then
            PayHelper.checkMoney(self.curShowReward.priceType, self.curShowReward.price, function(success)
                if success then
                    DiscountShopConfirmContent:setGoodsList({ self.curShowReward }, self.curShowReward.price, PayHelper.getMoneyIcon(self.curShowReward.priceType))
                    tryGetReward()
                else
                    if self.mgr.config.lackTipType ~= 0 then
                        CustomDialog.builder()
                                    .setContentText(Lang:getString("gui_score_lack_money_" .. self.mgr.mainConfig.moneyType))
                                    .setHideLeftButton()
                                    .setRightText("gui_score_lack_money_go_tip")
                                    .setRightClickListener(function()
                            if Plugins.CallTargetPluginFunc("cable_car", "checkPlayerOnCableCar", Game:getPlatformUserId()) then
                                return
                            end
                            if self.mgr.config.lackTipType ~= 0 then
                                PlayerManager:getClientPlayer():sendPacket({
                                    pid = "PlayerTicketTipGo",
                                    type = self.mgr.config.lackTipType,
                                    param = self.mgr.config.lackTipParam
                                })
                                GUIGameActivityLayout:hide(true)
                            end
                        end)
                                    .show()
                    else
                        CustomDialog.builder()
                                    .setContentText(Lang:getString("gui.lack.of.score." .. self:getActivityById()))
                                    .setHideLeftButton()
                                    .show()
                        return
                    end
                end
            end)
        else
            DiscountShopConfirmContent:setGoodsList({ self.curShowReward }, self.curShowReward.score, "set:game_activity_score_5.json image:img_0_icon_hat")
            tryGetReward()
        end
    end)

    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("score.activity.help.title.5")
                    .setContentText(Lang:getString(self.mgr.mainConfig.descLang))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)

    self.mgr:registerCacheChange(function()
        if self:isShow() then
            self:refreshUI()
        else
            self:updateRedPoint()
        end
    end)

    self:registerEvent(Events.ShowScoreActivityRewardDetailEvent, function(activityId, data)
        if self:getActivityById() ~= activityId then
            return
        end
        self:showCurRewardDetail(data)
    end)

    self.llTaskPanelTouch:registerEvent(GUIEvent.Click, function(events)
        if self.isTaskPanelOpen then
            self:changeTaskPanel()
            Game:handleTouchClick(events.position.x, events.position.y)
        end
    end)

    self:registerEvent(Events.ScoreActivityTaskUpdateEvent, function(activityId, taskId, progress, status)
        if self:getActivityById() ~= activityId then
            return
        end
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = self.lvTaskList:getItem("taskId", taskId)
        if item then
            item:setTaskInfo(progress, status)
        end
    end)
end

---@private
function GUIGameScoreActivityPanel5Window:refreshUI()
    if self.curShowReward then
        self:showCurRewardDetail(self.curShowReward)
    else
        for _, item in pairs(self.rewardItems) do
            item:onDataChanged(item.data)
        end
    end
    self:updateRedPoint()
    self.stScoreText:SetText(self.mgr:getScore())
end

---@private
function GUIGameScoreActivityPanel5Window:updateRedPoint()
    local count = 0
    if self.mgr.mainConfig.moneyType == 0 then
        for _, reward in pairs(self.rewards) do
            if not self.mgr:isRewardReceived(reward.id) and self.mgr:getScore() >= reward.score then
                count = count + 1
            end
        end
    else
        local money = PlayerWallet.getMoneyByCoinId(self.mgr.mainConfig.moneyType)
        for _, reward in pairs(self.rewards) do
            local limit = self.mgr:getRewardLimit(reward)
            if (limit > 0 or limit < 0)
                    and money >= reward.price then
                count = count + 1
            end
        end
    end
    UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityPanel5Window:showCurRewardDetail(data)
    self.curShowReward = data
    self.btnExchange:SetVisible(true)
    self.btnExchange:SetEnabled(self.mgr:getRewardLimit(self.curShowReward) > 0)
    self.mgr.curShowRewardId = self.curShowReward.id
    for _, item in pairs(self.rewardItems) do
        item:onDataChanged(item.data)
    end
    local rewardDetail = RewardItemShowDetailConfig:getConfigById(data.reward.showDetailId)
    if not rewardDetail then
        self:setIcon(data.reward)
        self.stRewardName:SetText("")
        self.siImage:SetVisible(true)
        self.awActor:SetVisible(false)
        return
    end
    self.stRewardName:SetText(Lang:getString(rewardDetail.name))
    self.siImage:SetVisible(rewardDetail.showType == Define.ShowDetailType.Icon)
    self.awActor:SetVisible(rewardDetail.showType == Define.ShowDetailType.Actor)
    if rewardDetail.showType == Define.ShowDetailType.Icon then
        self:setIcon(rewardDetail)
    elseif rewardDetail.showType == Define.ShowDetailType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, rewardDetail, self.llSlideBlock)
    end
end

function GUIGameScoreActivityPanel5Window:setActorVisible(value)
    if self.curShowReward then
        local rewardDetail = RewardItemShowDetailConfig:getConfigById(self.curShowReward.reward.showDetailId)
        if rewardDetail and rewardDetail.showType == Define.ShowDetailType.Icon then
            return
        end
    end
    self.awActor:SetVisible(value)
end

---@private
---@param rewardDetail RewardItemShowDetailItem
function GUIGameScoreActivityPanel5Window:setIcon(rewardDetail)
    self.siImage:SetYPosition({ 0, self.iconMovePos })
    self.siImage:SetImage("")
    if rewardDetail.scale and rewardDetail.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180, rewardDetail.scale)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180, rewardDetail.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180)
    end
    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos - 35) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ 0, self.iconMovePos })
    end, 100)
    self:addTimer(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel5Window:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel5Window:onTick()
    --self.stScoreText:SetText(tostring(PlayerWallet.getMoneyByCoinId(self.mgr.mainConfig.moneyType)))
    if not self.isTaskPanelOpen then
        return
    end
    local lastTime = DateUtil.getDayLeftSeconds()
    self.stTaskTimeText:SetText(DateUtil.getFormatTime(lastTime))
end

function GUIGameScoreActivityPanel5Window:changeTaskPanel()
    if self.locked then
        return
    end
    self.locked = true
    self.isTaskPanelOpen = not self.isTaskPanelOpen
    self.llTaskPanelTouch:SetVisible(self.isTaskPanelOpen)
    local count = math.min(self.lvTaskList:getChildCount(), 6)
    local startW, endW, startH, endH
    if self.isTaskPanelOpen then
        startW = 79
        endW = 352
        startH = count * 74 - 2
        endH = count * 74 + 40
        self.llTaskPanelClip:SetXPosition({ 0, -7 })
        self.llTaskPanelClip:SetYPosition({ 0, 68 })
        self.siTaskPanel:SetXPosition({ 0, 0 })
        self.siTaskPanel:SetYPosition({ 0, 0 })
        self:updateTaskUI()
    else
        startW = 352
        endW = 79
        startH = count * 74 + 40
        endH = count * 74 - 2
    end
    local offsetW = (endW - startW) / 8
    local offsetH = (endH - startH) / 8
    self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
        startW = startW + offsetW
        startH = startH + offsetH
        self.llTaskPanelClip:SetWidth({ 0, startW })
        self.llTaskPanelClip:SetHeight({ 0, startH })
    end, function()
        self.locked = false
        if not self.isTaskPanelOpen then
            self.siTaskPanel:SetImage("")
            self.llTaskPanelClip:SetXPosition({ 0, -15 })
            self.llTaskPanelClip:SetYPosition({ 0, 76 })
            self.siTaskPanel:SetXPosition({ 0, 8 })
            self.siTaskPanel:SetYPosition({ 0, -8 })
            self.llSlideBlock:SetTouchable(true)
            self.lvTaskList.root:SetScrollOffset(0)
            self:updateTaskUI()
        else
            self.llSlideBlock:SetTouchable(false)
            self.siTaskPanel:SetImage("set:game_activity_score_5.json image:img_9_task_bg")
        end
    end, 1, 8))
end

function GUIGameScoreActivityPanel5Window:updateTaskUI()
    ---@param item GUIGameScoreActivityTaskItemWindow
    for _, item in pairs(self.lvTaskList.items) do
        item:updateUI()
    end
end

return GUIGameScoreActivityPanel5Window
