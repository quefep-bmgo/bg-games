---@class GUIGameTurntableActivityPanelWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameTurntableActivityPanelWindow = class("GUIGameTurntableActivityPanelWindow", GUICommonActivityPanel)

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameTurntableActivityPanelWindow:ctor(...)
	self.json_name = "GameTurntableActivityPanel.json"
	self.super.ctor(self, "GameTurntableActivityPanel.json", ...)
end

---@private
function GUIGameTurntableActivityPanelWindow:onChildLoad()
	---@type CTurntableActivityMgr
	self.mgr = self.mgr
	self.rewardItems = {}
	self.siBg = self:getChildWindowByName("GameTurntableActivityPanel-Bg", GUIType.StaticImage)
	self.siTitleImage = self:getChildWindowByName("GameTurntableActivityPanel-Title-Image", GUIType.StaticImage)
	self.siQuestion = self:getChildWindowByName("GameTurntableActivityPanel-Question", GUIType.StaticImage)
	self.siTimeIcon = self:getChildWindowByName("GameTurntableActivityPanel-TimeIcon", GUIType.StaticImage)
	self.stTime = self:getChildWindowByName("GameTurntableActivityPanel-Time", GUIType.StaticText)
	self.siTurntable = self:getChildWindowByName("GameTurntableActivityPanel-Turntable", GUIType.StaticImage)
	self.siTurntableHolder = self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Holder", GUIType.StaticImage)
	self.stLotteryTimesText = self:getChildWindowByName("GameTurntableActivityPanel-Lottery-Times-Text", GUIType.StaticText)
	self.siTurntableBg = self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Bg", GUIType.StaticImage)
	self.siTurntableArrows = self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Arrows", GUIType.StaticImage)
	self.llTurntableContent = self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Content", GUIType.Layout)
	self.siTurntableSelect = self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Select", GUIType.StaticImage)
	self.siTurntableEffect= self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Effect", GUIType.StaticImage)
	self.btnTurntableStart = self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Start", GUIType.Button)
	self.llTaskPanelClip = self:getChildWindowByName("GameTurntableActivityPanel-TaskPanel-Clip", GUIType.Layout)
	self.llTaskPanelTouch = self:getChildWindowByName("GameTurntableActivityPanel-TaskPanel-Touch", GUIType.Layout)
	self.siTaskPanel = self:getChildWindowByName("GameTurntableActivityPanel-TaskPanel", GUIType.StaticImage)
	self.llTaskTime = self:getChildWindowByName("GameTurntableActivityPanel-Task-Time", GUIType.Layout)
	self.stDailyTaskText = self:getChildWindowByName("GameTurntableActivityPanel-DailyTaskText", GUIType.StaticText)
	self.siTaskTimeIcon = self:getChildWindowByName("GameTurntableActivityPanel-Task-Time-Icon", GUIType.StaticImage)
	self.stTaskTimeText = self:getChildWindowByName("GameTurntableActivityPanel-Task-Time-Text", GUIType.StaticText)
	self.llTaskContent = self:getChildWindowByName("GameTurntableActivityPanel-TaskContent", GUIType.Layout)
	self.siScoreIcon = self:getChildWindowByName("GameTurntableActivityPanel-ScoreIcon", GUIType.StaticImage)
	self.stScoreText = self:getChildWindowByName("GameTurntableActivityPanel-ScoreText", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function GUIGameTurntableActivityPanelWindow:initView()
	---@type GUICurrency
	self.llKeyMoney = UIHelper.newGameGUIWindow("GUICurrency", "GameActivityCurrency.json")
	self.llKeyMoney.root:SetHorizontalAlignment(HorizontalAlignment.Right)
	self.llKeyMoney.root:SetYPosition({0, 12})
	self.llKeyMoney.root:SetXPosition({0, -36})
	self.root:AddChildWindow(self.llKeyMoney.root)
	self.llKeyMoney.btnAddKey:removeEvent(GUIEvent.ButtonClick)
	self.llKeyMoney:onDataChanged({ ItemId = 0, RealId = Define.Money.CHIP, Icon = "set:game_activity_turntable_1.json image:img_0_icon_score" })
	self.llKeyMoney.onTick = function()  end
	self.stDailyTaskText:SetText(Lang:getString("gui.daily.task"))
	self.siTitleImage:SetImage(UIUtils.GetLangImage("set:game_activity_turntable_1.json image:text"))
	self.stScoreText:SetText(tostring(self.mgr.config.needTimes))
	self:initRewards()
	self:initTasks()
end

---@private
function GUIGameTurntableActivityPanelWindow:initRewards()
	local configs = self.mgr.rewardGroup
	---@type GUIGameTurntableActivityRewardItemWindow
	local GUIGameTurntableActivityRewardItemWindow = UIHelper.requireGUIWindow("GUIGameTurntableActivityRewardItem", false, "ui_activity")
	for _, config in pairs(configs) do
		local win = self:getChildWindowByName("GameTurntableActivityPanel-Turntable-Item-" .. config.groupSeq, GUIType.Layout)
		if win then
			local item = GUIGameTurntableActivityRewardItemWindow.new("", self.mgr)
			item:onDataChanged(config)
			win:AddChildWindow(item.root)
			self.rewardItems[config.groupSeq] = item
		end
	end
end

---@private
function GUIGameTurntableActivityPanelWindow:initTasks()
	local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId) or {}
	if #tasks == 0 then
		return
	end
	table.sort(tasks, function(t1, t2)
		return t1.Id < t2.Id
	end)
	for i = #tasks, 1, -1 do
		local task = tasks[i]
		task.Image = Define.DailyTaskIcon[task.TaskTypeId]
	end
	local count = math.min(#tasks, 6)
	self.llTaskPanelClip:SetHeight({ 0, count * 74 - 2 })
	self.siTaskPanel:SetHeight({ 0, count * 74 + 40 })
	self.lvTaskList = IGUIListView.new("GameTurntableActivityPanel-TaskList" .. self.activity.activityId, self.llTaskContent)
	self.lvTaskList:setItemSpace(10)
	for _, task in pairs(tasks) do
		---@type GUIGameScoreActivityTaskItemWindow
		local item = UIHelper.requireGUIWindow("GUIGameScoreActivityTaskItem", false, "ui_activity").new(self)
		item:setUIStyle(
				"set:game_activity_turntable_1.json image:img_0_icon_score", VectorUtil.newVector2(30, 33),
				"set:game_activity_turntable_1.json image:img_0_leaf2", VectorUtil.newVector2(59, 69),
				{ 0.188, 0.8196, 0.784, 0.5 })
		item.root:SetHeight({ 0, 64 })
		item.siScoreIconBg:SetBackgroundColor({26 / 255, 91 / 255, 106 / 255, 1})
		item.siScoreIconBg:SetArea({0, 3}, {0, 0}, {0, 53}, {0, 53})
		item.siScoreIconBg:SetVisible(true)
		item.siScoreIcon:SetXPosition({0, 11.5})
		item.siTaskIcon:SetYPosition({ 0, -2 })
		item.siTaskIcon:SetXPosition({ 0, -2 })
		item.siMaskYes:SetXPosition({ 0, -2 })
		item.siMaskYes:SetYPosition({ 0, -2 })
		--item.stDesc:SetArea({ 0, 0 }, { 0, 0 }, { 1, -74 }, { 1, 0 })
		item.stDesc:SetTextHorzAlign(HorizontalAlignment.Left)
		item.stDesc:SetTextColor({ 112 / 255, 1, 233 / 255, 1 })
		item:onDataChanged(task)
		self.lvTaskList:addItem(item)
	end
end

function GUIGameTurntableActivityPanelWindow:adapterUI()
	for i = 1, self.lvTaskList:getItemCount() do
		---@type GUIGameScoreActivityTaskItemWindow
		local item = self.lvTaskList:getItemByIndex(i)
		item.stScore:SetTextColor({1, 1, 1, 1})
		item.stScore:SetHorizontalAlignment(HorizontalAlignment.Right)
		item.stScore:SetXPosition({0, 10})
		item.stScore:SetYPosition({0, 8})
		item.stScore:SetTextHorzAlign(HorizontalAlignment.Right)
		item.siBg:SetWidth({1, -30})
	end
end

---@private
function GUIGameTurntableActivityPanelWindow:initEvent()
	self.mgr:registerCacheChange(function()
		self:refreshUI()
	end)

	self.btnTurntableStart:registerEvent(GUIEvent.ButtonClick, function()
		if self.isAnimPlaying then
			return
		end
		self.mgr:tryLottery(function(data)
			self:playAnim(data.groupSeq)
		end)
	end)

	self.llTaskPanelTouch:registerEvent(GUIEvent.Click, function(events)
		if self.isTaskPanelOpen then
			self:changeTaskPanel()
			Game:handleTouchClick(events.position.x, events.position.y)
		end
	end)

	self:registerEvent(Events.TurntableActivityTaskUpdateEvent, function(activityId, taskId, progress, status)
		if self:getActivityById() ~= activityId then
			return
		end
		---@type GUIGameScoreActivityTaskItemWindow
		local item = self.lvTaskList:getItem("taskId", taskId)
		if item then
			item:setTaskInfo(progress, status)
		end
	end)

	self.siQuestion:registerEvent(GUIEvent.Click, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("turntable.activity.help.title")
					.setContentText(Lang:getString(self.mgr.mainConfig.descLang))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)
end

function GUIGameTurntableActivityPanelWindow:onTick()
	if not self.isTaskPanelOpen then
		return
	end
	local lastTime = DateUtil.getDayLeftSeconds()
	self.stTaskTimeText:SetText(DateUtil.getFormatTime(lastTime))
end

function GUIGameTurntableActivityPanelWindow:refreshUI()
	self.llKeyMoney.tvMoney:SetText(tostring(self.mgr:getPlayerRestTimes()))
	self.stLotteryTimesText:SetText(Lang:getString("turntable_times_text") .. self.mgr:getPlayerRestTimes())
	local configs = self.mgr.rewardGroup
	if self.mgr:isGetAllReward() then
		self.btnTurntableStart:SetTouchable(false)
		self.btnTurntableStart:SetDrawColor({ 0.25, 0.25, 0.25, 1 })
		self.siScoreIcon:SetDrawColor({ 0.25, 0.25, 0.25, 1 })
		self.stScoreText:SetTextColor({ 0.25, 0.25, 0.25, 1 })
		self.stScoreText:SetProperty("TextBorderColor", "0 0 0 1")
	else
		self.btnTurntableStart:SetTouchable(true)
		self.btnTurntableStart:SetDrawColor({ 1, 1, 1, 1 })
		self.siScoreIcon:SetDrawColor({ 1, 1, 1, 1 })
		self.stScoreText:SetTextColor({ 1, 1, 1, 1 })
		self.stScoreText:SetProperty("TextBorderColor", "0.38 0.2 0.1 1")
	end
	for _, config in pairs(configs) do
		if self.resultIndex ~= config.groupSeq then
			self:setRewardMask(config.groupSeq, self.mgr:isHas(config.groupSeq))
		end
	end
end

function GUIGameTurntableActivityPanelWindow:onShow()
	self:adapterUI()
	GUIGameActivityLayout:hideTitle()
	self:resetUi(self.resultIndex)
	self.resultIndex = nil
	self:refreshUI()
end

function GUIGameTurntableActivityPanelWindow:resetUi(index)
	self.siTurntableEffect:PlayEffect1("")
	self.siTurntableEffect:SetEffectName("g1008_ui_zhuanpan_daiji.effect")
	self.siTurntableSelect:SetVisible(false)
	self.siTurntableArrows:SetRotate(0)
	LuaTimer:cancel(self.aniTimer or 0)
	self.isAnimPlaying = false
	if index then
		self:setRewardMask(index)
	end
end

function GUIGameTurntableActivityPanelWindow:playAnim(index)
	self:resetUi(self.resultIndex)
	self.isAnimPlaying = true
	self.resultIndex = index
	self.siTurntableEffect:PlayEffect1("")
	self.siTurntableEffect:SetEffectName("g1008_zhuanpan_shanshuo.effect")
	local extraAngle = (index - 1) * 45 + 20
	local totalAngle = 1440 + extraAngle
	local times = math.ceil((totalAngle - 300) / 25) + 20
	local curTimes = 1
	local curAngle = 0
	local gap = 5
	self.aniTimer = LuaTimer:scheduleTimerWithEnd(function()
		if curTimes <= 10 then
			gap = gap + (curTimes % 2 == 1 and 0 or 4)
		elseif curTimes > times - 10 then
			gap = math.max(gap - ((times - curTimes) % 2 == 1 and 0 or 4), 5)
		end
		if curAngle + gap > totalAngle then
			gap = math.max(0, totalAngle - curAngle)
		end
		curAngle = curAngle + gap
		if curTimes == times then
			curAngle = curAngle + 2.5
		end
		self.siTurntableArrows:SetRotate(curAngle)
		curTimes = curTimes + 1
	end, function()
		self.siTurntableSelect:SetRotate((index - 1) * 45)
		self.siTurntableSelect:SetVisible(true)
		self.isAnimPlaying = false
		self.siTurntableEffect:PlayEffect1("")
		self.siTurntableEffect:SetEffectName("g1008_ui_zhuanpan_daiji.effect")
		LuaTimer:schedule(function()
			local data = self.mgr.rewardGroup[self.resultIndex]
			GameActivityShowReward.builder()
								  .setRewardView({ data.reward })
								  .setHideLeftButton()
								  .setRightButton("common.activity.sure")
								  .show()
		end, 70)
	end, 25, times)
end

function GUIGameTurntableActivityPanelWindow:setRewardMask(index, visible)
	local mask = GUIManager:getWindowByName('GameTurntableActivityPanel-Reward-Mask' .. index, GUIType.StaticImage)
	if not mask then
		mask = GUIManager:createGUIWindow(GUIType.StaticImage, 'GameTurntableActivityPanel-Reward-Mask' .. index)
		self.llTurntableContent:AddChildWindow(mask)
		mask:SetImage("set:game_activity_turntable_1.json image:img_0_turntable_received")
		mask:SetTouchable(false)
		mask:SetProperty("Material", "CullBackLinear")
		mask:SetHorizontalAlignment(HorizontalAlignment.Center)
		mask:SetVerticalAlignment(VerticalAlignment.Center)
		mask:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
		mask:SetRotate((index - 1) * 45)
	end
	mask:SetVisible(visible)
end

function GUIGameTurntableActivityPanelWindow:changeTaskPanel()
	if self.locked then
		return
	end
	self.locked = true
	self.isTaskPanelOpen = not self.isTaskPanelOpen
	self.llTaskPanelTouch:SetVisible(self.isTaskPanelOpen)
	local count = math.min(self.lvTaskList:getChildCount(), 6)
	local startW, endW, startH, endH
	if self.isTaskPanelOpen then
		startW = 79
		endW = 352
		startH = count * 74 - 2
		endH = count * 74 + 40
		self.llTaskPanelClip:SetXPosition({ 0, -17 })
		self.llTaskPanelClip:SetYPosition({ 0, 70 })
		self.siTaskPanel:SetXPosition({ 0, 0 })
		self.siTaskPanel:SetYPosition({ 0, 0 })
		self:updateTaskUI()
	else
		startW = 352
		endW = 79
		startH = count * 74 + 40
		endH = count * 74 - 2
	end
	local offsetW = (endW - startW) / 8
	local offsetH = (endH - startH) / 8
	self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
		startW = startW + offsetW
		startH = startH + offsetH
		self.llTaskPanelClip:SetWidth({ 0, startW })
		self.llTaskPanelClip:SetHeight({ 0, startH })
	end, function()
		self.locked = false
		if not self.isTaskPanelOpen then
			self.siTaskPanel:SetImage("")
			self.llTaskPanelClip:SetXPosition({ 0, -25 })
			self.llTaskPanelClip:SetYPosition({ 0, 78 })
			self.siTaskPanel:SetXPosition({ 0, 8 })
			self.siTaskPanel:SetYPosition({ 0, -8 })
			self.lvTaskList.root:SetScrollOffset(0)
			self:updateTaskUI()
		else
			self.siTaskPanel:SetImage("set:game_activity_turntable_1.json image:img_9_task_bg")
		end
	end, 1, 8))
end

function GUIGameTurntableActivityPanelWindow:updateTaskUI()
	---@param item GUIGameScoreActivityTaskItemWindow
	for _, item in pairs(self.lvTaskList.items) do
		item:updateUI()
	end
end

return GUIGameTurntableActivityPanelWindow
