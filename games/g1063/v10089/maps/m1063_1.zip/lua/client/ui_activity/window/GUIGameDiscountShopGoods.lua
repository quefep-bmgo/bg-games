---@class GUIGameDiscountShopGoodsWindow : IGUIWindow
local GUIGameDiscountShopGoodsWindow = class("GUIGameDiscountShopGoodsWindow", IGUIWindow)

---@private
function GUIGameDiscountShopGoodsWindow:ctor(_, mgr)
    self.super.ctor(self, "GameDiscountShopGoods.json", mgr)
end

---@private
---@param mgr CDiscountShopActivityMgr
function GUIGameDiscountShopGoodsWindow:onLoad(mgr)
    self.mgr = mgr
    self.siTray = self:getChildWindowByName("GameDiscountShopGoods-Tray", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameDiscountShopGoods-Image", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("GameDiscountShopGoods-Effect", GUIType.StaticImage)
    self.llSelectClick = self:getChildWindowByName("GameDiscountShopGoods-SelectClick", GUIType.Layout)
    self.siCheckBg = self:getChildWindowByName("GameDiscountShopGoods-CheckBg", GUIType.StaticImage)
    self.siCheck = self:getChildWindowByName("GameDiscountShopGoods-Check", GUIType.StaticImage)
    self.siPriceIcon = self:getChildWindowByName("GameDiscountShopGoods-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameDiscountShopGoods-Price", GUIType.StaticText)
    self.stSaleOut = self:getChildWindowByName("GameDiscountShopGoods-SaleOut", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameDiscountShopGoodsWindow:initView()
    self.stSaleOut:SetText(Lang:getString("gui.sale.out"))
end

---@private
function GUIGameDiscountShopGoodsWindow:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        GUICommonActivityRewardDetail:show(self.data.reward.showDetailId)
    end)
    self.llSelectClick:registerEvent(GUIEvent.Click, function()
        self.mgr:onSelectGoods(self.data)
    end)
end

---@param data DiscountShopGoodsData
function GUIGameDiscountShopGoodsWindow:onDataChanged(data)
    self.data = data
    self.siImage:SetImage(data.reward.image)
    self.siEffect:SetVisible(data.showBorder)
    if data.showBorder then
        self.siImage:SetWidth({ 0, 60 })
        self.siImage:SetHeight({ 0, 60 })
    else
        self.siImage:SetWidth({ 0, 77 })
        self.siImage:SetHeight({ 0, 77 })
    end
    self.stPrice:SetText(data.price)
    self.siPriceIcon:SetXPosition({ 0, -(self.stPrice:GetTextWidth() / 2 + 8) })
    if self.mgr:getGoodsLimit(data) == 0 then
        self.siTray:SetImage("set:game_activity_discount_shop_1.json image:img_0_itembd_saleout")
        self.siCheckBg:SetVisible(false)
        self.siPriceIcon:SetVisible(false)
        self.stSaleOut:SetVisible(true)
    else
        self.siTray:SetImage("set:game_activity_discount_shop_1.json image:img_0_itembd_normal")
        self.siCheckBg:SetVisible(true)
        self.siCheck:SetVisible(self.mgr:isGoodsSelect(data))
        self.siPriceIcon:SetVisible(true)
        self.stSaleOut:SetVisible(false)
    end
end

return GUIGameDiscountShopGoodsWindow
