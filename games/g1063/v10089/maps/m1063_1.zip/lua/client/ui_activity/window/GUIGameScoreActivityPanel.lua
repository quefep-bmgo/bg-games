---@class GUIGameScoreActivityPanelWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameScoreActivityPanelWindow = class("GUIGameScoreActivityPanelWindow", GUICommonActivityPanel)
---@type ScoreActivityConfig
local ScoreActivityConfig = T(Global, "ScoreActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameScoreActivityPanelWindow:ctor(...)
    self.json_name = "GameScoreActivityPanel.json"
    self.super.ctor(self, "GameScoreActivityPanel.json", ...)
end

---@private
function GUIGameScoreActivityPanelWindow:onChildLoad()
    ---@type CScoreActivityMgr
    self.mgr = self.mgr
    self.iconMovePos = 0
    self.iconMoveGap = 2
    self.siTitle = self:getChildWindowByName("GameScoreActivityPanel-Title", GUIType.StaticImage)
    self.siQuestion = self:getChildWindowByName("GameScoreActivityPanel-Question", GUIType.StaticImage)
    self.llTaskPanelClip = self:getChildWindowByName("GameScoreActivityPanel-TaskPanel-Clip", GUIType.Layout)
    self.siTaskPanel = self:getChildWindowByName("GameScoreActivityPanel-TaskPanel", GUIType.StaticImage)
    self.llTaskPanelTouch = self:getChildWindowByName("GameScoreActivityPanel-TaskPanel-Touch", GUIType.Layout)
    self.stDailyTaskText = self:getChildWindowByName("GameScoreActivityPanel-DailyTaskText", GUIType.StaticText)
    self.stTaskTimeText = self:getChildWindowByName("GameScoreActivityPanel-Task-Time-Text", GUIType.StaticText)
    self.llTaskContent = self:getChildWindowByName("GameScoreActivityPanel-TaskContent", GUIType.Layout)
    self.siScoreIconEffect = self:getChildWindowByName("GameScoreActivityPanel-ScoreIconEffect", GUIType.StaticImage)
    self.llRewardPanel = self:getChildWindowByName("GameScoreActivityPanel-RewardPanel", GUIType.Layout)
    self.pbScoreProgress = self:getChildWindowByName("GameScoreActivityPanel-Score-Progress", GUIType.ProgressBar)
    self.btnOneKeyReceive = self:getChildWindowByName("GameScoreActivityPanel-OneKeyReceive", GUIType.Button)
    self.siImage = self:getChildWindowByName("GameScoreActivityPanel-Image", GUIType.StaticImage)
    self.siImageEffect = self:getChildWindowByName("GameScoreActivityPanel-Image-Effect", GUIType.StaticImage)
    self.siImageBack = self:getChildWindowByName("GameScoreActivityPanel-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindowByName("GameScoreActivityPanel-Image-Top", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("GameScoreActivityPanel-Name", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

function GUIGameScoreActivityPanelWindow:adaptPosition()
    for i = 1, self.lvTaskList:getItemCount() do
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = self.lvTaskList:getItemByIndex(i)
        item.siTaskIcon:SetYPosition({0, -2})
        item.stTaskProgress:SetYPosition({0, 4})
    end
    self.awActor:SetXPosition({0, 48})

    self.stName = self:getChildWindowByName("GameScoreActivityPanel-Name", GUIType.StaticText)
    self.stName:SetXPosition({0, 48})
end

function GUIGameScoreActivityPanelWindow:onShow()
    self:adaptPosition()
    self.curShowReward = nil
    self.mgr.curShowRewardId = 0
    self.siImage:SetVisible(false)
    self.siImageBack:SetVisible(false)
    self.awActor:SetVisible(false)
    self.super.showRewardDetail(self)
    GUIGameActivityLayout:hideTitle()
    self:refreshUI()
    self:showFirstCanReceiveRewardPosition()
    local item=self.lvRewards:getItemByIndex(1)
    for i = 1, self.lvRewards:getItemCount() do
        item=self.lvRewards:getItemByIndex(i)
        if self.activity.mainRewardId==item.data.reward.rewardId then
            break
        end
    end
    Events.ShowScoreActivityRewardDetailEvent:invoke(item.mgr.mainConfig.activityId, item.data)
end

---@private
function GUIGameScoreActivityPanelWindow:ScrollMoveChangeListener(args)
    if self.curOffset ~=args.offset then
        self.curOffset = args.offset
        if self.curOffset<-self.maxOffset then
            self.curOffset = -self.maxOffset
            self.lvRewards.root:SetScrollOffset(self.curOffset)
        end
        self:updateScoreLineUI()
    end
end

---@private
function GUIGameScoreActivityPanelWindow:initView()
    UIHelper:setImageAdjustSize(self.siTitle, UIUtils.GetLangImage("set:game_activity_score_1.json image:text"), 9999, 9999)
    self.isTaskPanelOpen = true
    self.siImage:SetVisible(false)
    self.stDailyTaskText:SetText(Lang:getString("gui.daily.task"))
    self.btnOneKeyReceive:SetText(Lang:getString("gui.one.key.receive"))
    local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
    self.lvRewards = IGUIListView.new("GameScoreActivityPanel-Rewards" .. self.activity.activityId, self.llRewardPanel, nil, Orientation.Horizontal)
    ---@type ScoreActivityRewardAdapter
    self.rewardAdapter = UIHelper.requireAdapter("ScoreActivityRewardAdapter", false, "ui_activity").new()
    self.rewardAdapter:setActivityMgr(self.mgr)
    self.lvRewards:setAdapter(self.rewardAdapter)
    self.rewards = rewards
    local result = {}
    TableUtil.mergeTable({}, rewards, result)
    self.rewardAdapter:setData(result)
    self.curOffset = 0
    local normalLength = self.lvRewards:getItemCount() * 136
    self.lineLength = normalLength - 68
    self.maxOffset = normalLength - self.lvRewards.root:GetPixelSize().x
    self.lvRewards.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
        return self:ScrollMoveChangeListener(args)
    end)
    self.pbScoreProgress:SetWidth({ 0, self.lineLength })
    local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId) or {}
    if #tasks == 0 then
        return
    end
    table.sort(tasks, function(t1, t2)
        return t1.Id < t2.Id
    end)
    for _, task in pairs(tasks) do
        task.Image = Define.DailyTaskIcon[task.TaskTypeId]
    end
    local count = math.min(#tasks, 6)
    self.llTaskPanelClip:SetHeight({ 0, count * 76 - 2 })
    self.siTaskPanel:SetHeight({ 0, count * 76 + 40 })
    self.lvTaskList = IGUIListView.new("GameScoreActivityPanel-TaskList" .. self.activity.activityId, self.llTaskContent)
    self.lvTaskList:setItemSpace(8)
    for _, task in pairs(tasks) do
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = UIHelper.requireGUIWindow("GUIGameScoreActivityTaskItem", false, "ui_activity").new(self)
        item:onDataChanged(task)
        item.stDesc:SetTextColor({ 218 / 255, 233 / 255, 255 / 255, 1 })
        item.stDesc:SetProperty("Font", "HT12")
        item.stScore:SetTextColor({ 255 / 255, 255 / 255, 255 / 255, 1 })
        item.siScoreIconBg:SetBackgroundColor({48 / 255, 82 / 255, 140 / 255, 0.5})
        item.siScoreIconBg:SetVisible(true)
        item.siBg:SetWidth({1, 0})
        item:setUIStyle(
                "set:game_activity_score_1.json image:img_0_icon_exp", VectorUtil.newVector2(52, 52),
                "set:game_activity_score_1.json image:img_0_icon_bd", VectorUtil.newVector2(52, 65),
                { 63 / 255, 82 / 255, 145 / 255, 0.5 })
        self.lvTaskList:addItem(item)
    end
    self:changeTaskPanel()
end

---@private
---@param items ScoreActivityRewardData[]
function GUIGameScoreActivityPanelWindow:updateScoreLineUI()
    local items=self.rewards
    if #items == 0 then
        return
    end
    self.pbScoreProgress:SetXPosition({ 0, math.min(self.curOffset, 0) })
    local score = self.mgr:getScore()
    if score == 0 then
        self.pbScoreProgress:SetProgress(0)
        return
    end
    if score >= items[#items].score then
        self.pbScoreProgress:SetProgress(1)
        return
    end
    local count = #items
    local percent = 1 / (count * 2 - 1)
    local progress = -percent
    percent = percent * 2
    local offset=self.lvRewards.root:GetScrollOffset()
    if offset > 0 then
        progress = progress + (offset / 136) * percent
    end
    for i, item in pairs(items) do
        if item.score <= score then
            progress = progress + percent
        else
            if i == 1 then
                progress = progress + (score / item.score) * percent
            else
                local pre = items[i - 1]
                progress = progress + ((score - pre.score) / (item.score - pre.score)) * percent
            end
            break
        end
    end
    self.pbScoreProgress:SetProgress(math.max(progress, 0))
end

---@private
function GUIGameScoreActivityPanelWindow:initEvent()
    self.btnOneKeyReceive:registerEvent(GUIEvent.ButtonClick, function()
        local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
        local score = self.mgr:getScore()
        local result = {}
        for _, reward in pairs(rewards) do
            if reward.score <= score and not self.mgr:isRewardReceived(reward.id) then
                table.insert(result, reward)
            end
        end
        if #result > 0 then
            self.mgr:tryGetReward(0)
        end
    end)

    self.llTaskPanelTouch:registerEvent(GUIEvent.Click, function(events)
        if self.isTaskPanelOpen then
            self:changeTaskPanel()
            Game:handleTouchClick(events.position.x, events.position.y)
        end
    end)

    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("score.activity.help.title")
                    .setContentText(Lang:getString("score.activity.help.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self.mgr:registerCacheChange(function()
        if self:isShow() then
            self:refreshUI()
        else
            self:updateRedPoint()
        end
    end)
    self:registerEvent(Events.ShowScoreActivityRewardDetailEvent, function(activityId, data)
        if self:getActivityById() ~= activityId then
            return
        end
        self:showCurRewardDetail(data)
    end)
    self:registerEvent(Events.ScoreActivityTaskUpdateEvent, function(activityId, taskId, progress, status)
        if self:getActivityById() ~= activityId then
            return
        end
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = self.lvTaskList:getItem("taskId", taskId)
        if item then
            item:setTaskInfo(progress, status)
        end
    end)
end

---@private
function GUIGameScoreActivityPanelWindow:refreshUI()
    if self.curShowReward then
        self:showCurRewardDetail(self.curShowReward)
    else
        if self.rewardAdapter then
            self.rewardAdapter:notifyDataChange()
        end
    end
    self:updateScoreLineUI(self.rewards)
    local count = self:updateRedPoint()
    self.btnOneKeyReceive:SetVisible(count > 0)
    self:updateScoreProgress()
end

---@private
function GUIGameScoreActivityPanelWindow:updateRedPoint()
    local count = 0
    local score = self.mgr:getScore()
    for _, reward in pairs(self.rewards) do
        if not self.mgr:isRewardReceived(reward.id) and score >= reward.score then
            count = count + 1
        end
    end
    UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
    return count
end

function GUIGameScoreActivityPanelWindow:showFirstCanReceiveRewardPosition()
    local firstReceivedIndex = -1
    for index, reward in pairs(self.rewards) do
        if not self.mgr:isRewardReceived(reward.id) then
            firstReceivedIndex = index
            break
        end
    end
    if firstReceivedIndex == -1 then
        firstReceivedIndex = #self.rewards - 1
    else
        firstReceivedIndex = firstReceivedIndex - 1
    end
    local offset = -math.min(firstReceivedIndex * 136, self.maxOffset)
    local times = math.floor(math.abs((offset - self.curOffset) / 300))
    if times <= 0 then
        return
    end
    LuaTimer:scheduleTickerWithEnd(function()
        self.rewardAdapter:setScrollOffset(self.curOffset - 300)
    end, function()
        local scoreOffset = self.lvRewards.root:GetScrollOffset()
        if scoreOffset > offset then
            self.rewardAdapter:setScrollOffset(scoreOffset + 78)
            self.rewardAdapter:setScrollOffset(offset)
        else
            self.rewardAdapter:setScrollOffset(offset)
        end
    end, 1, times)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityPanelWindow:showCurRewardDetail(data)
    self.curShowReward = data
    self.siImageEffect:SetVisible(data.quality>=4)
    self.mgr.curShowRewardId = self.curShowReward.id
    if self.rewardAdapter then
        self.rewardAdapter:notifyDataChange()
    end
    local rewardDetail = RewardItemShowDetailConfig:getConfigById(data.reward.showDetailId)
    if not rewardDetail then
        self:setIcon(data.reward)
        self.tvName:SetText(Lang:getString(data.reward.name))
        self.siImage:SetVisible(true)
        self.awActor:SetVisible(false)
        return
    end
    self.tvName:SetText(Lang:getString(rewardDetail.name))
    self.siImage:SetVisible(rewardDetail.showType == Define.ShowDetailType.Icon)
    self.siImageBack:SetVisible(true)
    self.awActor:SetVisible(rewardDetail.showType == Define.ShowDetailType.Actor)
    if rewardDetail.showType == Define.ShowDetailType.Icon then
        self:setIcon(rewardDetail)
    elseif rewardDetail.showType == Define.ShowDetailType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, rewardDetail, self.llSlideBlock)
    end
end

---@private
---@param rewardDetail RewardItemShowDetailItem
function GUIGameScoreActivityPanelWindow:setIcon(rewardDetail)
    self.siImage:SetYPosition({ -0.05, self.iconMovePos })
    self.siImage:SetImage("")
    if rewardDetail.scale and rewardDetail.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180, rewardDetail.scale)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180, rewardDetail.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180)
    end
    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ -0.05, self.iconMovePos })
    end, 100)
    self:addTimer(self.iconMoveTimer)
end

function GUIGameScoreActivityPanelWindow:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

function GUIGameScoreActivityPanelWindow:onTick()
    if not self.isTaskPanelOpen then
        return
    end
    local lastTime = DateUtil.getDayLeftSeconds()
    self.stTaskTimeText:SetText(DateUtil.getFormatTime(lastTime))
end

function GUIGameScoreActivityPanelWindow:changeTaskPanel()
    if self.locked then
        return
    end
    self.locked = true
    self.isTaskPanelOpen = not self.isTaskPanelOpen
    self.llTaskPanelTouch:SetVisible(self.isTaskPanelOpen)
    local count = math.min(self.lvTaskList:getChildCount(), 6)
    local startW, endW, startH, endH
    if self.isTaskPanelOpen then
        startW = 85
        endW = 352
        startH = count * 76 - 2
        endH = count * 76 + 40
        self.llTaskPanelClip:SetXPosition({ 0, -17 })
        self.llTaskPanelClip:SetYPosition({ 0, 37 })
        self.siTaskPanel:SetXPosition({ 0, 0 })
        self.siTaskPanel:SetYPosition({ 0, 0 })
        self:updateTaskUI()
    else
        startW = 352
        endW = 85
        startH = count * 76 + 40
        endH = count * 76 - 2
    end
    local offsetW = (endW - startW) / 8
    local offsetH = (endH - startH) / 8
    self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
        startW = startW + offsetW
        startH = startH + offsetH
        self.llTaskPanelClip:SetWidth({ 0, startW })
        self.llTaskPanelClip:SetHeight({ 0, startH })
    end, function()
        self.locked = false
        if not self.isTaskPanelOpen then
            self.siTaskPanel:SetImage("")
            self.llTaskPanelClip:SetXPosition({ 0, -27 })
            self.llTaskPanelClip:SetYPosition({ 0, 47 })
            self.siTaskPanel:SetXPosition({ 0, 10 })
            self.siTaskPanel:SetYPosition({ 0, -10 })
            self:updateTaskUI()
        else
            self.siTaskPanel:SetImage("set:game_activity_score_1.json image:img_9_task_bg")
        end
    end, 1, 8))
end

function GUIGameScoreActivityPanelWindow:updateTaskUI()
    ---@param item GUIGameScoreActivityTaskItemWindow
    for _, item in pairs(self.lvTaskList.items) do
        item:updateUI()
    end
end

function GUIGameScoreActivityPanelWindow:updateScoreProgress()
    local curPosY = -20
    local score = self.mgr:getScore()
    local lastScore = 0
    local nextScore = 0
    for _, reward in pairs(self.rewards) do
        if reward.score > score then
            nextScore = reward.score
            break
        else
            lastScore = reward.score
        end
    end
    if nextScore ~= 0 then
        local progress = (score - lastScore) / (nextScore - lastScore)
        curPosY = 24 - 40 * progress
    end
    self.siScoreIconEffect:SetYPosition({ 0, curPosY })
end

return GUIGameScoreActivityPanelWindow
