---@class GUIGameAtLessPanel2Window : GUICommonActivityPanel
local GUIGameAtLessPanel2Window = class("GUIGameAtLessPanel2Window", GUICommonActivityPanel)

---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameAtLessPanel2Window:ctor(...)
    ---@type CAtLessLotteryMgr
    self.mgr = self.mgr
    self.super.ctor(self, "GameAtLessPanel2.json", ...)
end

function GUIGameAtLessPanel2Window:onChildLoad()
    self.siTitleImage = self:getChildWindowByName("GameAtLessPanel2-Title-Image", GUIType.StaticImage)
    self.stDailyText = self:getChildWindowByName("GameAtLessPanel2-Daily-Text", GUIType.StaticText)
    self.stRewardName1 = self:getChildWindowByName("GameAtLessPanel2-Reward-Name1", GUIType.StaticText)
    self.stRewardName2 = self:getChildWindowByName("GameAtLessPanel2-Reward-Name2", GUIType.StaticText)
    self.stRewardName3 = self:getChildWindowByName("GameAtLessPanel2-Reward-Name3", GUIType.StaticText)
    self.stRewardName4 = self:getChildWindowByName("GameAtLessPanel2-Reward-Name4", GUIType.StaticText)
    self.stRewardName5 = self:getChildWindowByName("GameAtLessPanel2-Reward-Name5", GUIType.StaticText)
    self.stRewardName6 = self:getChildWindowByName("GameAtLessPanel2-Reward-Name6", GUIType.StaticText)
    self.btnJump = self:getChildWindowByName("GameAtLessPanel2-Jump", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameAtLessPanel2Window:initView()
    UIHelper:setImageAdjustSize(self.siTitleImage, UIUtils.GetLangImage("set:game_activity_at_less_2.json image:text"), 9999, 9999)

    self.btnJump:SetText(Lang:getString("gui.activity.at.less.jump"))

    local detail1 = RewardItemShowDetailConfig:getConfigById(100002011)
    local detail2 = RewardItemShowDetailConfig:getConfigById(60104)
    local detail3 = RewardItemShowDetailConfig:getConfigById(100007005)
    local detail4 = RewardItemShowDetailConfig:getConfigById(60103)
    local detail5 = RewardItemShowDetailConfig:getConfigById(100003031)
    local detail6 = RewardItemShowDetailConfig:getConfigById(2010007)
    self.stRewardName1:SetText(Lang:getString(detail1.name))
    self.stRewardName2:SetText(Lang:getString(detail2.name))
    self.stRewardName3:SetText(Lang:getString(detail3.name))
    self.stRewardName4:SetText(Lang:getString(detail4.name))
    self.stRewardName5:SetText(Lang:getString(detail5.name))
    self.stRewardName6:SetText(Lang:getString(detail6.name))
end

---@private
function GUIGameAtLessPanel2Window:initEvent()
    self.btnJump:registerEvent(GUIEvent.ButtonClick, function()
        ---@type TeamService
        local TeamService = T(Global, "TeamService")
        TeamService:sendCreateTeam("g1008", Define.GameMode.Qualifying)

        GUIGameActivityLayout:hide(true)
    end)
end

function GUIGameAtLessPanel2Window:onShow()
    local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
    local text = Lang:getString("gui.activity.at.less.count")
    local haveTimes = math.floor((self.mgr.config.dailyTimes - cache.dailyTimes))
    local totalTimes = math.floor(self.mgr.config.dailyTimes)
    local count = haveTimes .. "/" .. totalTimes
    if self.mgr.config.dailyTimes == cache.dailyTimes then
        text = text .. TextFormat.colorRed .. count
    else
        text = text .. TextFormat.colorGreen .. count
    end
    self.stDailyText:SetText(text)
    GUIGameActivityLayout:hideTitle()
end

return GUIGameAtLessPanel2Window
