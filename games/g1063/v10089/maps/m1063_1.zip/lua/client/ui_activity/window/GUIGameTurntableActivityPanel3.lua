---@class GUIGameTurntableActivityPanel3Window : GUIGameActivityPanel
local GUIGameTurntableActivityPanel3Window = class("GUIGameTurntableActivityPanel3Window", GUICommonActivityPanel)
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")
require "client.ui_activity.window.GUICommonActivityRewardItem"

---@private
function GUIGameTurntableActivityPanel3Window:ctor(...)
	self.super.ctor(self, "GameTurntableActivityPanel3.json", ...)
end

---@private
function GUIGameTurntableActivityPanel3Window:onChildLoad()
	---@type CTurntableActivityMgr
	self.mgr = self.mgr
	self.iconMovePos = 0
	self.iconMoveGap = 2
	self.siBg = self:getChildWindowByName("GameTurntableActivityPanel3-Bg", GUIType.StaticImage)
	self.llRight = self:getChildWindowByName("GameTurntableActivityPanel3-Right", GUIType.Layout)
	self.siBaseImg = self:getChildWindowByName("GameTurntableActivityPanel3-Base-Img", GUIType.StaticImage)
	self.stTaskText = self:getChildWindowByName("GameTurntableActivityPanel3-Task-Text", GUIType.StaticText)
	self.siEffect = self:getChildWindowByName("GameTurntableActivityPanel3-Effect", GUIType.StaticImage)
	self.siImage = self:getChildWindowByName("GameTurntableActivityPanel3-Image", GUIType.StaticImage)
	self.siImageBack = self:getChildWindowByName("GameTurntableActivityPanel3-Image-Back", GUIType.StaticImage)
	self.siImageTop = self:getChildWindowByName("GameTurntableActivityPanel3-Image-Top", GUIType.StaticImage)
	self.awActor = self:getChildWindowByName("GameTurntableActivityPanel3-Actor", GUIType.ActorWindow)
	self.btnGoto = self:getChildWindowByName("GameTurntableActivityPanel3-Goto", GUIType.Button)
	self.llActorSlideBlock = self:getChildWindowByName("GameTurntableActivityPanel3-Actor-Slide-Block", GUIType.Layout)
	self.llDescLayout = self:getChildWindowByName("GameTurntableActivityPanel3-DescLayout", GUIType.Layout)
	self.stName = self:getChildWindowByName("GameTurntableActivityPanel3-Name", GUIType.StaticText)
	self.llRewardPanel = self:getChildWindowByName("GameTurntableActivityPanel3-RewardPanel", GUIType.Layout)
	self.stTimes = self:getChildWindowByName("GameTurntableActivityPanel3-Times", GUIType.StaticText)
	self.btnRewardTab = self:getChildWindowByName("GameTurntableActivityPanel3-Reward-Tab", GUIType.Button)
	self.stTitle = self:getChildWindowByName("GameTurntableActivityPanel3-Title", GUIType.StaticText)
	self.siQuestion = self:getChildWindowByName("GameTurntableActivityPanel3-Question", GUIType.StaticImage)
	self.siTimeIcon = self:getChildWindowByName("GameTurntableActivityPanel3-TimeIcon", GUIType.StaticImage)
	self.stTime = self:getChildWindowByName("GameTurntableActivityPanel3-Time", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameTurntableActivityPanel3Window:initView()
	self:getChildWindowByName("GameTurntableActivityPanel3-Tab-Text", GUIType.StaticText):SetText(Lang:getString("common.activity.reward.preview.title"))
	self.stTitle:SetText(Lang:getString(self.mgr.mainConfig.titleLang))
	self.btnGoto:SetText(Lang:getString("gui.activity.reward.result.skip"))

	self.lvRewardList = IGUIGridView.new("GameTurntableActivityPanel3-Reward-List" .. self.activity.activityId, self.llRewardPanel, nil)
	self.lvRewardList:setArea({0, 0}, {0, 66}, {1, -36}, {1, -90})
	self.lvRewardList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvRewardList:setConfig(10, 10, 3)
	---@type GUIGameTurntableActivityRewardItem3Window[]
	self.cardItemList = {}
	local configs = self.mgr.rewardGroup
	for seq = 1, #configs do
		---@type GUIGameTurntableActivityRewardItem3Window
		local cardItem = UIHelper.requireGUIWindow("GUIGameTurntableActivityRewardItem3", false, "ui_activity").new("", self.mgr)
		cardItem:setIndex(seq)
		self.lvRewardList:addItemByIndex(cardItem, seq)
		self.cardItemList[seq] = cardItem
	end

	self:initTasks()
end

---@private
function GUIGameTurntableActivityPanel3Window:initEvent()
	self.mgr:registerCacheChange(function()
		self:refreshUI()
	end)

	self.siQuestion:registerEvent(GUIEvent.Click, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("turntable.activity.help.title")
					.setContentText(Lang:getString(self.mgr.mainConfig.descLang))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)

	self.btnGoto:registerEvent(GUIEvent.ButtonClick, function()
		self.mgr:gotoTask()
	end)

	self.btnRewardTab:registerEvent(GUIEvent.ButtonClick, function()
		GameActivityRewardPreview.builder()
								 .setRewardViewByGroupId(self.mgr.config.rewardGroupId, true)
								 .setTitleText("common.activity.reward.preview.title")
								 .show()
	end)
end

---@private
function GUIGameTurntableActivityPanel3Window:initTasks()
	local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId) or {}
	if #tasks == 0 then
		return
	end
	self.stTaskText:SetText(Lang:getString(tasks[1].Desc))
end

---@private
function GUIGameTurntableActivityPanel3Window:showMainReward()
	local mainRewardId = self.mgr.mainConfig.mainRewardId
	local reward = self.mgr:getRewardById(mainRewardId)
	if not reward then
		return
	end
	local rewardDetail = RewardItemShowDetailConfig:getConfigById(reward.showDetailId)
	if not rewardDetail then
		return
	end
	self.stName:SetText(Lang:getString(rewardDetail.name))
	self.siImage:SetVisible(rewardDetail.showType == Define.ShowDetailType.Icon)
	self.awActor:SetVisible(rewardDetail.showType == Define.ShowDetailType.Actor)
	if rewardDetail.showType == Define.ShowDetailType.Icon then
		self:setIcon(rewardDetail)
	elseif rewardDetail.showType == Define.ShowDetailType.Actor then
		RewardItemShowDetailConfig:showActorSkill(self.awActor, rewardDetail, self.llActorSlideBlock)
	end
end

---@private
---@param rewardDetail RewardItemShowDetailItem
function GUIGameTurntableActivityPanel3Window:setIcon(rewardDetail)
	self.siImage:SetYPosition({ -0.05, self.iconMovePos })
	self.siImage:SetImage("")
	if rewardDetail.scale and rewardDetail.scale ~= "#" then
		UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180, rewardDetail.scale)
		UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180, rewardDetail.scale)
	else
		UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180)
		UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180)
	end
	LuaTimer:cancel(self.iconMoveTimer or 0)
	self.iconMoveTimer = LuaTimer:scheduleTimer(function()
		if math.abs(self.iconMovePos) >= 15 then
			self.iconMoveGap = self.iconMoveGap * -1
		end
		self.iconMovePos = self.iconMovePos + self.iconMoveGap
		self.siImage:SetYPosition({ -0.05, self.iconMovePos })
	end, 100)
	self:addTimer(self.iconMoveTimer)
end

function GUIGameTurntableActivityPanel3Window:refreshUI()
	self.stTimes:SetText(Lang:getString("turntable_times_text") .. self.mgr:getPlayerRestTimes())
	local cache = self.mgr:getPlayerCache()
	if self.mgr:isGetAllReward() then
		self.stTimes:SetVisible(false)
	end
	for _, item in pairs(cache.rewardRecord) do
		local reward = self.mgr.rewardGroup[item.groupSeq]
		local win = self.cardItemList[item.seq]
		if win then
			win:setReward(reward.reward)
		end
	end
end

function GUIGameTurntableActivityPanel3Window:onShow()
	GUIGameActivityLayout:hideTitle()
	self:showMainReward()
end

function GUIGameTurntableActivityPanel3Window:onHide()
	LuaTimer:cancel(self.iconMoveTimer or 0)
end

return GUIGameTurntableActivityPanel3Window
