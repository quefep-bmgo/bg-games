---@class GUIGameCardLotteryWindow : GUIGameActivityPanel
local GUIGameCardLotteryWindow = class("GameCardLotteryPanel", GUICommonActivityPanel)
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function GUIGameCardLotteryWindow:ctor(...)
    self.super.ctor(self, "GameCardLotteryPanel.json", ...)
end

function GUIGameCardLotteryWindow:onChildLoad()
    ---@type CCardLotteryMgr
    self.mgr = self.mgr

    self.items = {}
    self.deletes = {}

    self.detail1 = nil
    self.detail2 = nil
    self.detail3 = nil

    self.suitId1 = 0
    self.suitId2 = 0
    self.suitId3 = 0

    local name = self.__name:gsub(".json", "-")
    if self.json_name then
        name = self.json_name:gsub(".json", "-")
    end

    ---LotteryPanel
    self.llLotteryPanel = self:getChildWindowByName(name .. "Lottery-Panel", GUIType.Layout)
    self.ivLotteryPriceIcon = self:getChildWindowByName(name .. "Lottery-Price-Icon", GUIType.StaticImage)
    self.tvLotteryOldPrice = self:getChildWindowByName(name .. "Lottery-Old-Price", GUIType.StaticText)
    self.llLotteryOldPriceLine = self:getChildWindowByName(name .. "Lottery-Old-Price-Line", GUIType.Layout)
    self.tvLotteryNewPrice = self:getChildWindowByName(name .. "Lottery-New-Price", GUIType.StaticText)
    self.btnLottery = self:getChildWindowByName(name .. "Lottery", GUIType.Button)
    self.llCardList = self:getChildWindowByName(name .. "Card-List", GUIType.GridView)
    self.llShowActor = self:getChildWindowByName(name .. "Show-Actor", GUIType.Layout)
    self.llActor1 = self:getChildWindowByName(name .. "Actor1", GUIType.Layout)
    self.llActor2 = self:getChildWindowByName(name .. "Actor2", GUIType.Layout)
    self.llActor3 = self:getChildWindowByName(name .. "Actor3", GUIType.Layout)
    self.llSlide = self:getChildWindowByName(name .. "Big-Reward-Slide", GUIType.Layout)
    self.gvItemLayout1 = self:getChildWindowByName(name .. "Item-Layout1", GUIType.GridView)
    self.gvItemLayout2 = self:getChildWindowByName(name .. "Item-Layout2", GUIType.GridView)
    self.gvItemLayout3 = self:getChildWindowByName(name .. "Item-Layout3", GUIType.GridView)
    self.siTitleImage = self:getChildWindowByName(name .. "TitleImage", GUIType.StaticImage)
    self.siQuestion = self:getChildWindowByName(name .. "Question", GUIType.StaticImage)
    ---MainReward
    self.llMainReward = self:getChildWindowByName(name .. "Main-Reward", GUIType.Layout)
    self.llTop = self:getChildWindowByName(name .. "Top", GUIType.Layout)
    self.stClickTip = self:getChildWindowByName(name .. "Click-Tip", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameCardLotteryWindow:initView()
    self.llShowActor:SetVisible(false)
    self.siTitleImage:SetImage(UIUtils.GetLangImage("set:game_activity_card_1.json image:text"))
    self.stClickTip:SetText(Lang:getString("click.to.close"))

    self.llCardList:InitConfig(24, 22, 6)
    self.llCardList:SetItemAlignment(HorizontalAlignment.Center)
    self.llCardList:SetVerticalAlignment(VerticalAlignment.Center)

    self.gvItemLayout1:SetItemAlignment(HorizontalAlignment.Center)
    self.gvItemLayout1:SetVerticalAlignment(VerticalAlignment.Center)
    self.gvItemLayout2:SetItemAlignment(HorizontalAlignment.Center)
    self.gvItemLayout2:SetVerticalAlignment(VerticalAlignment.Center)
    self.gvItemLayout3:SetItemAlignment(HorizontalAlignment.Center)
    self.gvItemLayout3:SetVerticalAlignment(VerticalAlignment.Center)
    self.gvItemLayout1:SetClipChild(false)
    self.gvItemLayout2:SetClipChild(false)
    self.gvItemLayout3:SetClipChild(false)
    self.gvItemLayout1:InitConfig(20, 0, 4)
    self.gvItemLayout2:InitConfig(20, 0, 4)
    self.gvItemLayout3:InitConfig(25, 0, 4)

    ---@type GUIGameCardLotteryRewardItemWindow[]
    self.rewardItemList1 = {}
    for _ = 1, 4 do
        ---@type GUIGameCardLotteryRewardItemWindow
        local item = UIHelper.requireGUIWindow("GUIGameCardLotteryRewardItem", false, "ui_activity").new()
        item.root:SetArea({ 0, 0 }, { 0, 0 }, { 0, 35 }, { 0, 35 })
        self.gvItemLayout1:AddItem(item.root)
        table.insert(self.rewardItemList1, item)
    end
    ---@type GUIGameCardLotteryRewardItemWindow[]
    self.rewardItemList2 = {}
    for _ = 1, 4 do
        ---@type GUIGameCardLotteryRewardItemWindow
        local item = UIHelper.requireGUIWindow("GUIGameCardLotteryRewardItem", false, "ui_activity").new()
        item.root:SetArea({ 0, 0 }, { 0, 0 }, { 0, 35 }, { 0, 35 })
        self.gvItemLayout2:AddItem(item.root)
        table.insert(self.rewardItemList2, item)
    end
    ---@type GUIGameCardLotteryRewardItemWindow[]
    self.rewardItemList3 = {}
    for _ = 1, 4 do
        ---@type GUIGameCardLotteryRewardItemWindow
        local item = UIHelper.requireGUIWindow("GUIGameCardLotteryRewardItem", false, "ui_activity").new()
        item.root:SetArea({ 0, 0 }, { 0, 0 }, { 0, 50 }, { 0, 50 })
        self.gvItemLayout3:AddItem(item.root)
        table.insert(self.rewardItemList3, item)
    end

    ---@type GUIGameCardLotteryItemWindow[]
    self.cardItemList = {}
    for seq = 1, 12 do
        ---@type GUIGameCardLotteryItemWindow
        local cardItem = UIHelper.requireGUIWindow("GUIGameCardLotteryItem", false, "ui_activity").new()
        self.llCardList:AddItem(cardItem.root)
        table.insert(self.cardItemList, cardItem)
        cardItem.root:registerEvent(GUIEvent.Click, function()
            self:clickLottery(seq)
        end)
    end

    GUIManager:getWindowByName("CommonActivityLayout-Content"):AddChildWindow(self.llTop)
end

---@private
function GUIGameCardLotteryWindow:initEvent()
    self.llActor1:registerEvent(GUIEvent.Click, function()
        local temp = self.detail1
        self.detail1 = self.detail3
        self.detail3 = temp
        temp = self.suitId1
        self.suitId1 = self.suitId3
        self.suitId3 = temp
        self:changeActor()
    end)

    self.llActor2:registerEvent(GUIEvent.Click, function()
        local temp = self.detail2
        self.detail2 = self.detail3
        self.detail3 = temp
        temp = self.suitId2
        self.suitId2 = self.suitId3
        self.suitId3 = temp
        self:changeActor()
    end)

    self.btnLottery:registerEvent(GUIEvent.ButtonClick, function()
        self:openCardLayout(true)
    end)

    self.llTop:registerEvent(GUIEvent.Click, function()
        self:openCardLayout(false)
    end)

    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("card.lottery.help.title")
                    .setContentText(Lang:getString("card.lottery.help.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
end

function GUIGameCardLotteryWindow:onShow()
    self.detail1 = RewardItemShowDetailConfig:getConfigById(self.mgr.config.showRewardDetailIds[1] or 0)
    self.detail2 = RewardItemShowDetailConfig:getConfigById(self.mgr.config.showRewardDetailIds[2] or 0)
    self.detail3 = RewardItemShowDetailConfig:getConfigById(self.mgr.config.showRewardDetailIds[3] or 0)

    self.suitId1 = self.mgr.config.suitIds[1]
    self.suitId2 = self.mgr.config.suitIds[2]
    self.suitId3 = self.mgr.config.suitIds[3]
    self:refreshActor()
end

function GUIGameCardLotteryWindow:changeActor()
    --self.llActor1:SetTouchable(false)
    --self.llActor2:SetTouchable(false)
    self:refreshActor()
end

function GUIGameCardLotteryWindow:refreshActor()
    for index, suitData in pairs(self.mgr:getSuitConfig(self.suitId1)) do
        self.rewardItemList1[index]:setReward(CommonActivityConfig:getRewardById(suitData.rewardId))
    end
    for index, suitData in pairs(self.mgr:getSuitConfig(self.suitId2)) do
        self.rewardItemList2[index]:setReward(CommonActivityConfig:getRewardById(suitData.rewardId))
    end
    for index, suitData in pairs(self.mgr:getSuitConfig(self.suitId3)) do
        self.rewardItemList3[index]:setReward(CommonActivityConfig:getRewardById(suitData.rewardId))
    end

    ---@type RewardItemShowDetailItem
    local detail1 = TableUtil.copyTable(self.detail1)
    detail1.actorShowSkill = "#"
    ---@type RewardItemShowDetailItem
    local detail2 = TableUtil.copyTable(self.detail2)
    detail2.actorShowSkill = "#"
    RewardItemShowDetailConfig:showActorSkill(self.llActor1, detail1)
    RewardItemShowDetailConfig:showActorSkill(self.llActor2, detail2)

    self.llActor3:SetVisible(true)
    self.llShowActor:SetVisible(false)
    RewardItemShowDetailConfig:showActorSkill(self.llActor3, self.detail3, nil, function()
        ---@type RewardItemShowDetailItem
        local detail3 = TableUtil.copyTable(self.detail3)
        detail3.actorShowSkill = "#"
        RewardItemShowDetailConfig:showActorSkill(self.llActor3, detail3, self.llSlide)

        self.llActor1:SetTouchable(true)
        self.llActor2:SetTouchable(true)
        self.llActor3:SetVisible(true)
        self.llShowActor:SetVisible(false)
    end)
end

function GUIGameCardLotteryWindow:refreshUI()
    local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
    if TableUtil.tableContain(cache.rewardRecord, self.lockLotterySeq) then
        self.lockLotterySeq = nil
    end
    for rewardId, seq in pairs(cache.rewardRecord or {}) do
        local cardItem = self.cardItemList[seq]
        local reward = CommonActivityConfig:getRewardById(rewardId)
        if reward and cardItem then
            cardItem:setReward(reward)
        end
    end
    local price = self.mgr:getPriceConfig(PlayerManager:getClientPlayer())
    for _, cardItem in pairs(self.cardItemList) do
        cardItem:setPrice(price)
    end
    if price and price.price > 0 then
        self.btnLottery:SetProperty("BtnTextColor", "0.0470588 0.137255 0.337255 1")
        self.btnLottery:SetText(Lang:getString("gui.main.activity.txt"))
    else
        self.btnLottery:SetProperty("BtnTextColor", "0.9254 0.09 0.83529 1")
        self.btnLottery:SetText(Lang:getString("gui_bed_war_lottery_free"))
    end
end

function GUIGameCardLotteryWindow:openCardLayout(isOpen)
    self.llTop:SetVisible(isOpen)
end

function GUIGameCardLotteryWindow:clickLottery(clickSeq)
    if self.lockLotterySeq then
        return
    end
    ---@type CardLotteryDBData
    local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
    for _, seq in pairs(cache.rewardRecord or {}) do
        if seq == clickSeq then
            return
        end
    end
    local price = self.mgr:getPriceConfig(PlayerManager:getClientPlayer())
    if not price then
        return
    end
    PayHelper.checkMoney(price.moneyType, price.price, function(success)
        if success then
            self.lockLotterySeq = clickSeq
            table.insert(cache.rewardRecord, clickSeq)
            self.cardItemList[clickSeq]:startLotteryAnim()
            self.mgr:lottery(clickSeq)
        end
    end)
end

return GUIGameCardLotteryWindow
