---@class GUIGameDiscountShopSelectGoodsWindow : IGUIWindow
local GUIGameDiscountShopSelectGoodsWindow = class("GUIGameDiscountShopSelectGoodsWindow", IGUIWindow)

---@private
function GUIGameDiscountShopSelectGoodsWindow:ctor(_, mgr)
    self.super.ctor(self, "GameDiscountShopSelectGoods.json", mgr)
end

---@private
---@param mgr CDiscountShopActivityMgr
function GUIGameDiscountShopSelectGoodsWindow:onLoad(mgr)
    self.mgr = mgr
    self.stSelectItemText = self:getChildWindowByName("GameDiscountShopSelectGoods-SelectItemText", GUIType.StaticText)
    self.siFlag = self:getChildWindowByName("GameDiscountShopSelectGoods-Flag", GUIType.StaticImage)
    self.siTag = self:getChildWindowByName("GameDiscountShopSelectGoods-Tag", GUIType.StaticImage)
    self.siOff = self:getChildWindowByName("GameDiscountShopSelectGoods-Off", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameDiscountShopSelectGoods-Image", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("GameDiscountShopSelectGoods-Effect", GUIType.StaticImage)
    self.siDiscountPriceIcon = self:getChildWindowByName("GameDiscountShopSelectGoods-DiscountPriceIcon", GUIType.StaticImage)
    self.stDiscountPrice = self:getChildWindowByName("GameDiscountShopSelectGoods-DiscountPrice", GUIType.StaticText)
    self.siRealPriceIcon = self:getChildWindowByName("GameDiscountShopSelectGoods-RealPriceIcon", GUIType.StaticImage)
    self.stRealPrice = self:getChildWindowByName("GameDiscountShopSelectGoods-RealPrice", GUIType.StaticText)
    self.llRedLine = self:getChildWindowByName("GameDiscountShopSelectGoods-RedLine", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameDiscountShopSelectGoodsWindow:initView()
    self.stSelectItemText:SetText(Lang:getString("gui.select.item"))
end

---@private
function GUIGameDiscountShopSelectGoodsWindow:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        self.mgr:onSelectGoods(self.data)
    end)
end

---@param data DiscountShopGoodsData
function GUIGameDiscountShopSelectGoodsWindow:onDataChanged(data, index, discount)
    self.data = data
    self.stSelectItemText:SetVisible(self.data == nil)
    self.siFlag:SetVisible(self.data ~= nil)
    self.siImage:SetVisible(self.data ~= nil)
    self.siDiscountPriceIcon:SetVisible(self.data ~= nil)
    self.siRealPriceIcon:SetVisible(self.data ~= nil)
    if not self.data then
        return
    end
    self.siImage:SetImage(data.reward.image)
    self.siEffect:SetVisible(data.showBorder)
    if data.showBorder then
        self.siImage:SetWidth({ 0, 64 })
        self.siImage:SetHeight({ 0, 64 })
    else
        self.siImage:SetWidth({ 0, 88 })
        self.siImage:SetHeight({ 0, 88 })
    end
    self.stDiscountPrice:SetText(math.floor(data.price * discount))
    self.stRealPrice:SetText(data.price)
    self.llRedLine:SetWidth({ 0, self.stRealPrice:GetTextWidth() + 4 })
    if discount == 0.45 then
        self.siTag:SetImage("set:game_activity_discount_shop_1.json image:lbl_0_55")
    elseif discount == 0.35 then
        self.siTag:SetImage("set:game_activity_discount_shop_1.json image:lbl_0_65")
    elseif discount == 0.25 then
        self.siTag:SetImage("set:game_activity_discount_shop_1.json image:lbl_0_75")
    end
    if index == 1 then
        self.siFlag:SetImage("set:game_activity_discount_shop_1.json image:img_0_salebd_left")
        self.siTag:SetXPosition({ 0, -4 })
        self.siOff:SetXPosition({ 0, -4 })
    elseif index == 2 then
        self.siFlag:SetImage("set:game_activity_discount_shop_1.json image:img_0_salebd_center")
        self.siTag:SetXPosition({ 0, 4 })
        self.siOff:SetXPosition({ 0, 4 })
    else
        self.siFlag:SetImage("set:game_activity_discount_shop_1.json image:img_0_salebd_right")
        self.siTag:SetXPosition({ 0, 4 })
        self.siOff:SetXPosition({ 0, 4 })
    end
end

return GUIGameDiscountShopSelectGoodsWindow
