---@class GUIGameTurntableActivityPanel2Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameTurntableActivityPanel2Window = class("GUIGameTurntableActivityPanel2Window", GUICommonActivityPanel)

---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIGameTurntableActivityPanel2Window:ctor(...)
	self.json_name = "GameTurntableActivityPanel2.json"
	self.super.ctor(self, "GameTurntableActivityPanel2.json", ...)
end

---@private
function GUIGameTurntableActivityPanel2Window:onChildLoad()
	---@type CTurntableActivityMgr
	self.mgr = self.mgr
	self.rewardItems = {}
	self.siBg = self:getChildWindowByName("GameTurntableActivityPanel2-Bg", GUIType.StaticImage)
	self.siTitleImage = self:getChildWindowByName("GameTurntableActivityPanel2-Title-Image", GUIType.StaticImage)
	self.siQuestion = self:getChildWindowByName("GameTurntableActivityPanel2-Question", GUIType.StaticImage)
	self.siTimeIcon = self:getChildWindowByName("GameTurntableActivityPanel2-TimeIcon", GUIType.StaticImage)
	self.stTime = self:getChildWindowByName("GameTurntableActivityPanel2-Time", GUIType.StaticText)
	self.siTurntable = self:getChildWindowByName("GameTurntableActivityPanel2-Turntable", GUIType.StaticImage)
	self.siTurntableHolder = self:getChildWindowByName("GameTurntableActivityPanel2-Turntable-Holder", GUIType.StaticImage)
	self.stLotteryTimesText = self:getChildWindowByName("GameTurntableActivityPanel2-Lottery-Times-Text", GUIType.StaticText)
	self.siTurntableBg = self:getChildWindowByName("GameTurntableActivityPanel2-Turntable-Bg", GUIType.StaticImage)
	self.llTurntableContent = self:getChildWindowByName("GameTurntableActivityPanel2-Turntable-Content", GUIType.Layout)
	self.btnTurntableStart = self:getChildWindowByName("GameTurntableActivityPanel2-Turntable-Start", GUIType.Button)
	self.llTaskPanelClip = self:getChildWindowByName("GameTurntableActivityPanel2-TaskPanel-Clip", GUIType.Layout)
	self.llTaskPanelTouch = self:getChildWindowByName("GameTurntableActivityPanel2-TaskPanel-Touch", GUIType.Layout)
	self.siTaskPanel = self:getChildWindowByName("GameTurntableActivityPanel2-TaskPanel", GUIType.StaticImage)
	self.llTaskTime = self:getChildWindowByName("GameTurntableActivityPanel2-Task-Time", GUIType.Layout)
	self.stDailyTaskText = self:getChildWindowByName("GameTurntableActivityPanel2-DailyTaskText", GUIType.StaticText)
	self.siTaskTimeIcon = self:getChildWindowByName("GameTurntableActivityPanel2-Task-Time-Icon", GUIType.StaticImage)
	self.stTaskTimeText = self:getChildWindowByName("GameTurntableActivityPanel2-Task-Time-Text", GUIType.StaticText)
	self.llTaskContent = self:getChildWindowByName("GameTurntableActivityPanel2-TaskContent", GUIType.Layout)
	self.siBubbleEffect = self:getChildWindowByName("GameTurntableActivityPanel2-Bubble-Effect", GUIType.StaticImage)
	self.siHandleEffect = self:getChildWindowByName("GameTurntableActivityPanel2-Handle-Effect", GUIType.StaticImage)
	self.siHandle = self:getChildWindowByName("GameTurntableActivityPanel2-Handle", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIGameTurntableActivityPanel2Window:initView()
	self.stDailyTaskText:SetText(Lang:getString("gui.daily.task"))
	self.siTitleImage:SetImage(UIUtils.GetLangImage("set:game_activity_turntable_2.json image:text"))
	self.siHandleEffect:PlayEffect1("")
	self:initRewards()
	self:initTasks()
end

---@private
function GUIGameTurntableActivityPanel2Window:initRewards()
	local configs = self.mgr.rewardGroup
	---@type GUIGameTurntableActivityRewardItemWindow
	local GUIGameTurntableActivityRewardItemWindow = UIHelper.requireGUIWindow("GUIGameTurntableActivityRewardItem", false, "ui_activity")
	for _, config in pairs(configs) do
		local win = self:getChildWindowByName("GameTurntableActivityPanel2-Turntable-Item-" .. config.groupSeq, GUIType.Layout)
		if win then
			local item = GUIGameTurntableActivityRewardItemWindow.new("", self.mgr)
			item.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
			item:onDataChanged(config)
			win:AddChildWindow(item.root)
			self.rewardItems[config.groupSeq] = item
		end
	end
end

---@private
function GUIGameTurntableActivityPanel2Window:initTasks()
	local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId) or {}
	if #tasks == 0 then
		return
	end
	table.sort(tasks, function(t1, t2)
		return t1.Id < t2.Id
	end)
	for i = #tasks, 1, -1 do
		local task = tasks[i]
		task.Image = Define.DailyTaskIcon[task.TaskTypeId]
	end
	local count = math.min(#tasks, 6)
	self.llTaskPanelClip:SetHeight({ 0, count * 74 - 2 })
	self.siTaskPanel:SetHeight({ 0, count * 74 + 40 })
	self.lvTaskList = IGUIListView.new("GameTurntableActivityPanel2-TaskList" .. self.activity.activityId, self.llTaskContent)
	self.lvTaskList:setItemSpace(10)
	for _, task in pairs(tasks) do
		---@type GUIGameScoreActivityTaskItemWindow
		local item = UIHelper.requireGUIWindow("GUIGameScoreActivityTaskItem", false, "ui_activity").new(self)
		item:setUIStyle(
				"", VectorUtil.newVector2(0, 0),
				"set:game_activity_turntable_2.json image:img_0_icon_bg", VectorUtil.newVector2(76.5, 71),
				{ 100 / 255, 122 / 255, 1, 0.5 })
		item.root:SetHeight({ 0, 64 })
		item.siTaskIcon:SetYPosition({ 0, -2 })
		item.siTaskIcon:SetXPosition({ 0, -2 })
		item.siMaskYes:SetXPosition({ 0, -2 })
		item.siMaskYes:SetYPosition({ 0, -2 })
		item.siBg:SetWidth({1, -74})
		item.stDesc:SetArea({ 0, 0 }, { 0, 0 }, { 1, -74 }, { 1, 0 })
		item.stDesc:SetTextHorzAlign(HorizontalAlignment.Center)
		item.stDesc:SetTextColor({ 112 / 255, 1, 233 / 255, 1 })
		item:onDataChanged(task)
		self.lvTaskList:addItem(item)
	end
end

---@private
function GUIGameTurntableActivityPanel2Window:initEvent()
	self.mgr:registerCacheChange(function()
		self:refreshUI()
	end)

	self.btnTurntableStart:registerEvent(GUIEvent.ButtonClick, function()
		if self.isAnimPlaying then
			return
		end
		self.mgr:tryLottery(function(data)
			self:playAnim(data.groupSeq)
		end)
	end)

	self.llTaskPanelTouch:registerEvent(GUIEvent.Click, function(events)
		if self.isTaskPanelOpen then
			self:changeTaskPanel()
			Game:handleTouchClick(events.position.x, events.position.y)
		end
	end)

	self:registerEvent(Events.TurntableActivityTaskUpdateEvent, function(activityId, taskId, progress, status)
		if self:getActivityById() ~= activityId then
			return
		end
		---@type GUIGameScoreActivityTaskItemWindow
		local item = self.lvTaskList:getItem("taskId", taskId)
		if item then
			item:setTaskInfo(progress, status)
		end
	end)

	self.siQuestion:registerEvent(GUIEvent.Click, function()
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("turntable2.activity.help.title")
					.setContentText(Lang:getString(self.mgr.mainConfig.descLang))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)
end

function GUIGameTurntableActivityPanel2Window:onTick()
	if not self.isTaskPanelOpen then
		return
	end
	local lastTime = DateUtil.getDayLeftSeconds()
	self.stTaskTimeText:SetText(DateUtil.getFormatTime(lastTime))
end

function GUIGameTurntableActivityPanel2Window:refreshUI()
	self.stLotteryTimesText:SetText(Lang:getString("turntable_times_text") .. self.mgr:getPlayerRestTimes())
	local configs = self.mgr.rewardGroup
	if self.mgr:isGetAllReward() then
		self.stLotteryTimesText:SetVisible(false)
		self.btnTurntableStart:SetDrawColor({ 0.25, 0.25, 0.25, 1 })
	end
	for _, config in pairs(configs) do
		if self.mgr:isHas(config.groupSeq) and self.resultIndex ~= config.groupSeq then
			self:setRewardMask(config.groupSeq)
		end
	end
end

function GUIGameTurntableActivityPanel2Window:onShow()
	GUIGameActivityLayout:hideTitle()
	self:resetUi(self.resultIndex)
	self.resultIndex = nil
end

function GUIGameTurntableActivityPanel2Window:resetUi(index)
	self.siBubbleEffect:PlayEffect1("")
	self.siBubbleEffect:SetEffectName("g1008_ui_paopao_man.effect")
	self.siHandle:SetImage("set:game_activity_turntable_2.json image:img_0_turntable_1")
	for _, win in pairs(self.rewardItems) do
		win:showSelect(false)
	end
	LuaTimer:cancel(self.aniTimer or 0)
	LuaTimer:cancel(self.rewardTimer or 0)
	LuaTimer:cancel(self.handleTimer or 0)
	self.isAnimPlaying = false
	if index then
		self:setRewardMask(index)
	end
end

function GUIGameTurntableActivityPanel2Window:playAnim(index)
	self:resetUi(self.resultIndex)
	self.isAnimPlaying = true
	self.resultIndex = index
	self.siHandleEffect:PlayEffect1("")
	self.siHandleEffect:SetEffectName("g1008_ui_yaogan.effect")
	self.siHandle:SetImage("")
	local curTimes = 0
	local totalTimes = 32 + index * 2
	self.handleTimer = LuaTimer:schedule(function()
		self.siBubbleEffect:PlayEffect1("")
		self.siBubbleEffect:SetEffectName("g1008_ui_paopao_kuai.effect")
		self.siHandle:SetImage("set:game_activity_turntable_2.json image:img_0_turntable_1")
		self.siHandleEffect:SetEffectName("")
		self.aniTimer = LuaTimer:scheduleTimerWithEnd(function()
			local round = math.ceil(curTimes / 8)
			local _index = curTimes % 8
			if round <= 2 then
				if curTimes % 2 == 1 then
					self:setRewardSelect(math.ceil(curTimes / 2), 160)
				end
			elseif round > 4 then
				if curTimes % 2 == 1 then
					_index = math.ceil((curTimes - 32) / 2)
					local time = _index == index and -1 or 160
					self:setRewardSelect(_index, time)
				end
			else
				self:setRewardSelect(_index == 0 and 8 or _index, 80)
			end
			curTimes = curTimes + 1
		end, function()
			self.isAnimPlaying = false
			self.siBubbleEffect:PlayEffect1("")
			self.siBubbleEffect:SetEffectName("g1008_ui_paopao_man.effect")
			self.rewardTimer = LuaTimer:schedule(function()
				local data = self.mgr.rewardGroup[self.resultIndex]
				if not data then
					return
				end
				GameActivityShowReward.builder()
									  .setRewardView({ data.reward })
									  .setHideLeftButton()
									  .setRightButton("common.activity.sure")
									  .show()
			end, 70)
		end, 80, totalTimes)
	end, 1000)
end

function GUIGameTurntableActivityPanel2Window:changeTaskPanel()
	if self.locked then
		return
	end
	self.locked = true
	self.isTaskPanelOpen = not self.isTaskPanelOpen
	self.llTaskPanelTouch:SetVisible(self.isTaskPanelOpen)
	local count = math.min(self.lvTaskList:getChildCount(), 6)
	local startW, endW, startH, endH
	if self.isTaskPanelOpen then
		startW = 79
		endW = 352
		startH = count * 74 - 2
		endH = count * 74 + 40
		self.llTaskPanelClip:SetXPosition({ 0, -17 })
		self.llTaskPanelClip:SetYPosition({ 0, 70 })
		self.siTaskPanel:SetXPosition({ 0, 0 })
		self.siTaskPanel:SetYPosition({ 0, 0 })
		self:updateTaskUI()
	else
		startW = 352
		endW = 79
		startH = count * 74 + 40
		endH = count * 74 - 2
	end
	local offsetW = (endW - startW) / 8
	local offsetH = (endH - startH) / 8
	self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
		startW = startW + offsetW
		startH = startH + offsetH
		self.llTaskPanelClip:SetWidth({ 0, startW })
		self.llTaskPanelClip:SetHeight({ 0, startH })
	end, function()
		self.locked = false
		if not self.isTaskPanelOpen then
			self.siTaskPanel:SetImage("")
			self.llTaskPanelClip:SetXPosition({ 0, -25 })
			self.llTaskPanelClip:SetYPosition({ 0, 78 })
			self.siTaskPanel:SetXPosition({ 0, 8 })
			self.siTaskPanel:SetYPosition({ 0, -8 })
			self.lvTaskList.root:SetScrollOffset(0)
			self:updateTaskUI()
		else
			self.siTaskPanel:SetImage("set:game_activity_turntable_1.json image:img_9_task_bg")
		end
	end, 1, 8))
end

function GUIGameTurntableActivityPanel2Window:updateTaskUI()
	---@param item GUIGameScoreActivityTaskItemWindow
	for _, item in pairs(self.lvTaskList.items) do
		item:updateUI()
	end
end

function GUIGameTurntableActivityPanel2Window:setRewardMask(index)
	if not self.rewardItems[index] then
		return
	end
	self.rewardItems[index]:showMask(true)
end

function GUIGameTurntableActivityPanel2Window:onHide()
	self:resetUi(self.resultIndex)
end

function GUIGameTurntableActivityPanel2Window:setRewardSelect(index, time)
	if not self.rewardItems[index] then
		return
	end
	self.rewardItems[index]:showSelect(true, time or -1)
end

return GUIGameTurntableActivityPanel2Window
