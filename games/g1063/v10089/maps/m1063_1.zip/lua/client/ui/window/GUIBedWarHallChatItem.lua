---@class GUIBedWarHallChatItemWindow : IGUIWindow
local GUIBedWarHallChatItemWindow = class("GUIBedWarHallChatItemWindow", IGUIWindow)

local ChatContentWindowName = {
    [Define.ChatMsgType.TextMsg] = "GUIBedWarHallChatItemContentText",
    [Define.ChatMsgType.ImageMsg] = "GUIBedWarHallChatItemContentImage",
    [Define.ChatMsgType.VoiceMsg] = "GUIBedWarHallChatItemContentVoice",
    [Define.ChatMsgType.CustomMsg .. "_" .. Define.CustomChatMsgType.EmojiMsg] = "GUIBedWarHallChatItemContentEmoji",
    [Define.ChatMsgType.TeamInviteMsg] = "GUIBedWarHallChatItemContentTeamInvite",
}

---@param msgData ChatMsgData
function GUIBedWarHallChatItemWindow:ctor(msgData)
    if msgData.sendId ~= Game:getPlatformUserId() then
        self.super.ctor(self, "BedWarHallChatItemLeft.json")
    else
        self.super.ctor(self, "BedWarHallChatItemRight.json")
    end
end

function GUIBedWarHallChatItemWindow:onLoad()
    self.llHeadImg = self:getChildWindowByName("BedWarHallChatItem-HeadImg", GUIType.Layout)
    self.siSex = self:getChildWindowByName("BedWarHallChatItem-Sex", GUIType.StaticImage)
    self.siDan = self:getChildWindowByName("BedWarHallChatItem-Dan", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("BedWarHallChatItem-Name", GUIType.StaticText)
    self.stLv = self:getChildWindowByName("BedWarHallChatItem-Lv", GUIType.StaticText)
    self.llContent = self:getChildWindowByName("BedWarHallChatItem-Content", GUIType.Layout)
    self:initView()
    self:initEvent()
end

function GUIBedWarHallChatItemWindow:initView()
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeadImg:GetPixelSize().x)
    self.llHeadImg:AddChildWindow(self.winHead.root)
    self.winHead:setCanOpenPersonalHome(false)
    self.stLv:SetVisible(false)
end

function GUIBedWarHallChatItemWindow:initEvent()
    self.llHeadImg:registerEvent(GUIEvent.Click, function()
        Events.ChatShowPlayerInfoEvent:invoke(self.playerInfo)
    end)
end

---@param data ChatMsgData
function GUIBedWarHallChatItemWindow:onDataChanged(data)
    self.data = data
    self.playerInfo = UserInfoCache:GetCache(data.sendId)
    if self.playerInfo then
        self.winHead:setUserInfo(self.playerInfo)
        self.stName:SetText(self.playerInfo.name)
        self.stLv:SetText("Lv." .. (self.playerInfo.playerLevel or 1))
        QualifyingTool.setQualifyingSegmentInListUI(self.siDan, nil, self.playerInfo.qualifyingData)
        self.siSex:SetImage(Define.SexIcon[self.playerInfo.sex] or Define.SexIcon[Define.SexType.Boy])
    end
    local name = ChatContentWindowName[data.type]
    if data.type == Define.ChatMsgType.CustomMsg then
        name = ChatContentWindowName[data.type .. "_" .. data.data.content.type]
    end
    if not name then
        return
    end
    local wContent = UIHelper.newGameGUIWindow(name)
    if data.sendId == Game:getPlatformUserId() then
        wContent.root:SetHorizontalAlignment(HorizontalAlignment.Right)
    end
    self.llContent:AddChildWindow(wContent.root)
    local height = wContent:onDataChanged(data)
    if not height then
        height = 76
    end
    self.root:SetHeight({ 0, height + 60 })
end

return GUIBedWarHallChatItemWindow
