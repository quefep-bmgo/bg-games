---@class GUIBedWarQualifyingSeasonChallengePanel1Window : IGUIWindow
local GUIBedWarQualifyingSeasonChallengePanel1Window = class("GUIBedWarQualifyingSeasonChallengePanel1Window", IGUIWindow)

---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
---@type QualifyingSeasonChallengeRewardConfig
local QualifyingSeasonChallengeRewardConfig = T(Global, "QualifyingSeasonChallengeRewardConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

---@private
function GUIBedWarQualifyingSeasonChallengePanel1Window:ctor(...)
    self.super.ctor(self, "BedWarQualifyingSeasonChallengePanel1.json", ...)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel1Window:onLoad()
    self.maxShowScore = 99999999
    self.iconMovePos = 0
    self.iconMoveGap = 2
    self.btnQuestion = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Question", GUIType.Button)
    self.awActor = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Actor", GUIType.ActorWindow)
    self.llActorTouch = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-ActorTouch", GUIType.Layout)
    self.llRewardLayout = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Reward-Layout", GUIType.Layout)
    self.stScoreText = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Score-Text", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Score", GUIType.StaticText)
    self.stHint = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Hint", GUIType.StaticText)
    self.llRewardContent = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Reward-Content", GUIType.Layout)
    self.pbScoreLine = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-ScoreLine", GUIType.ProgressBar)
    self.siImage = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Image", GUIType.StaticImage)
    self.siImageBack = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Image-Top", GUIType.StaticImage)
    self.llDesc = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Desc", GUIType.Layout)
    self.tvDescName = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Desc-Name", GUIType.StaticText)
    self.tvDescText = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel1-Desc-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel1Window:initView()
    self.stScoreText:SetText(Lang:getString("gui.qualifying.challenge.score"))
    self.stScore:SetText("0")
    self.stHint:SetText(Lang:getString("gui.qualifying.challenge.score.hint"))
    self.siImage:SetVisible(false)
    self.llDesc:SetVisible(false)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel1Window:initEvent()
    self.btnQuestion:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui.qualifying.challenge.rule.title")
                    .setContentText(Lang:getString("gui.qualifying.challenge.rule.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .setContentAlign(HorizontalAlignment.Left)
                    .show()
    end)
    self:registerEvent(Events.UpdateChallengeReceiveRecordEvent, function()
        if not self.root:IsVisible() or not self.rewardAdapter then
            return
        end
        self.rewardAdapter:notifyDataChange()
        self.stScore:SetText(CQualifyingController:getChallengeScore(Define.GameMode.Qualifying))
        local qualifyingData = CQualifyingController:getQualifyingData()
        if not qualifyingData then
            return
        end
        local items = QualifyingSeasonChallengeRewardConfig:getCfgBySeason(qualifyingData.quarter)
        self:updateScoreLineUI(items)
    end)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel1Window:onShow()
    self.stScore:SetText(math.min(self.maxShowScore, CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)))
    self:initRewardList()
end

function GUIBedWarQualifyingSeasonChallengePanel1Window:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel1Window:initRewardList()
    if self.lvRewardList ~= nil then
        if #self.rewardAdapter.data > 0 then
            local endReward = self.rewardAdapter.data[#self.rewardAdapter.data]
            self.lvRewardList:getItemByIndex(1):setSelectId(endReward.Id)
            self:showRewardDetail(endReward.ShowDetailId)
        end
        return
    end
    self.lvRewardList = IGUIListView.new("BedWarQualifyingSeasonChallenge-Reward-List", self.llRewardContent, nil, Orientation.Horizontal)
    ---@type BedWarQualifyingSeasonChallengeRewardAdapter
    self.rewardAdapter = UIHelper.newGameAdapter("BedWarQualifyingSeasonChallengeRewardAdapter")
    self.lvRewardList:setAdapter(self.rewardAdapter)
    local qualifyingData = CQualifyingController:getQualifyingData()
    if not qualifyingData then
        return
    end
    local items = QualifyingSeasonChallengeRewardConfig:getCfgBySeason(qualifyingData.quarter)
    self.rewardAdapter:setData(items)
    self.curOffset = 0
    self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
        if self.curOffset == args.offset then
            return
        end
        self.curOffset = args.offset
        self:updateScoreLineUI(items)
    end)
    if #items > 0 then
        self.maxShowScore = items[#items].Score
        self.lvRewardList:getItemByIndex(1):setSelectId(items[#items].Id)
        self:showRewardDetail(items[#items].ShowDetailId)
    end
    self.stScore:SetText(math.min(self.maxShowScore, CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)))
    self.pbScoreLine:SetWidth({ 0, self.lvRewardList:getItemCount() * 153 })
    self:updateScoreLineUI(items)
end

---@private
---@param items QualifyingSeasonChallengeRewardData[]
function GUIBedWarQualifyingSeasonChallengePanel1Window:updateScoreLineUI(items)
    self.pbScoreLine:SetXPosition({ 0, math.min(self.curOffset, 0) })
    local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
    if score == 0 then
        self.pbScoreLine:SetProgress(0)
        return
    end
    local count = #items
    local percent = 1 / count
    local progress = -percent / 2
    if self.curOffset > 0 then
        progress = progress + (self.curOffset / 153) * percent
    end
    for i, item in pairs(items) do
        if item.Score <= score then
            progress = progress + percent
        else
            if i == 1 then
                progress = progress + (score / item.Score) * percent
            else
                local pre = items[i - 1]
                progress = progress + ((score - pre.Score) / (item.Score - pre.Score)) * percent
            end
            break
        end
    end
    self.pbScoreLine:SetProgress(progress)
end

function GUIBedWarQualifyingSeasonChallengePanel1Window:showRewardDetail(rewardDetailId)
    local reward = RewardItemShowDetailConfig:getConfigById(rewardDetailId)
    if not reward then
        self:hide()
        return
    end
    self.llDesc:SetVisible(true)
    self.tvDescName:SetText(Lang:getString(reward.name))
    self.tvDescText:SetText(Lang:getString(reward.desc))
    self.siImage:SetVisible(reward.showType == Define.ShowDetailType.Icon)
    self.awActor:SetVisible(reward.showType == Define.ShowDetailType.Actor)
    if reward.showType == Define.ShowDetailType.Icon then
        self:setIcon(reward)
    elseif reward.showType == Define.ShowDetailType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, reward, self.llActorTouch)
    end
    self.rewardAdapter:notifyDataChange()
end

function GUIBedWarQualifyingSeasonChallengePanel1Window:setIcon(reward)
    self.siImage:SetYPosition({ -0.11, self.iconMovePos })
    if reward.scale and reward.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageTop, reward.image, 200, 200, reward.scale)
        UIHelper:setImageAdjustSize(self.siImageBack, reward.image, 200, 200, reward.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageTop, reward.image, 200, 200)
        UIHelper:setImageAdjustSize(self.siImageBack, reward.image, 200, 200)
    end

    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ -0.11, self.iconMovePos })
    end, 100)
end

return GUIBedWarQualifyingSeasonChallengePanel1Window
