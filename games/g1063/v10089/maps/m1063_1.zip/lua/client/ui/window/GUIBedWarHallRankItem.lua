---@class GUIBedWarHallRankItemWindow : IGUIWindow
local GUIBedWarHallRankItemWindow = class("GUIBedWarHallRankItemWindow", IGUIWindow)
---@type RankConfig
local RankConfig = T(Global, "RankConfig")
---@type CRankUtil
local CRankUtil = T(Global, "CRankUtil")

local BgImg = {
    Top = "set:bed_war_3_rank.json image:img_9_top1_bg",
    Other = "set:bed_war_3_rank.json image:img_9_top_otherbg",
    Self = "set:bed_war_3_rank.json image:img_9_top_myselfbg"
}

local TextColor = {
    Top = { 0, 0, 0, 1 },
    Other = { 214 / 255, 240 / 255, 255 / 255, 1 },
    Self = { 1, 1, 1, 1 }
}

local TopNumStr = "set:bed_war_3_rank.json image:img_0_no"
local NorNumStr = "set:bed_war_3_rank.json image:img_0_top_number"
local SelfNumStr = "set:bed_war_3_yellow_num.json image:img_0_myself_number"

---@private
function GUIBedWarHallRankItemWindow:ctor(...)
    self.super.ctor(self, "BedWarHallRankItem.json", ...)
end

---@private
function GUIBedWarHallRankItemWindow:onLoad()
    self.textColor = TextColor.Self

    self.llRank = self:getChildWindowByName("BedWarHallRankItem", GUIType.Layout)
    self.llRankNum = self:getChildWindowByName("BedWarHallRankItem-Rank", GUIType.Layout)
    self.siRankNum1 = self:getChildWindowByName("BedWarHallRankItem-Rank-Num1", GUIType.StaticImage)
    self.siRankNum2 = self:getChildWindowByName("BedWarHallRankItem-Rank-Num2", GUIType.StaticImage)
    self.siRankNum3 = self:getChildWindowByName("BedWarHallRankItem-Rank-Num3", GUIType.StaticImage)
    self.stNoRank = self:getChildWindowByName("BedWarHallRankItem-NoRank", GUIType.StaticText)
    self.siTopRank = self:getChildWindowByName("BedWarHallRankItem-Top-Rank", GUIType.StaticImage)

    self.siHead = self:getChildWindowByName("BedWarHallRankItem-Head", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("BedWarHallRankItem-Name", GUIType.StaticText)
    self.stLv = self:getChildWindowByName("BedWarHallRankItem-Lv", GUIType.StaticText)
    self.stWinRate = self:getChildWindowByName("BedWarHallRankItem-Win-Rate", GUIType.StaticText)
    self.stWinTimes = self:getChildWindowByName("BedWarHallRankItem-Win-Times", GUIType.StaticText)
    self.stPower = self:getChildWindowByName("BedWarHallRankItem-Power", GUIType.StaticText)
    self.siPowerIcon = self:getChildWindowByName("BedWarHallRankItem-Power-Icon", GUIType.StaticImage)
    self.stPowerNum = self:getChildWindowByName("BedWarHallRankItem-Power-Num", GUIType.StaticText)
    self.siDan = self:getChildWindowByName("BedWarHallRankItem-Dan", GUIType.StaticImage)
    self.stDanName = self:getChildWindowByName("BedWarHallRankItem-Dan-Name", GUIType.StaticText)
    self.stStarNum = self:getChildWindowByName("BedWarHallRankItem-Star-Num", GUIType.StaticText)
    self.stScoreDesc = self:getChildWindowByName("BedWarHallRankItem-Score-Desc", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("BedWarHallRankItem-Score", GUIType.StaticText)
    self.siScoreIcon = self:getChildWindowByName("BedWarHallRankItem-Score-Icon", GUIType.StaticImage)
    self.llFollow = self:getChildWindowByName("BedWarHallRankItem-Follow", GUIType.Layout)
    self.btnFollowBtn = self:getChildWindowByName("BedWarHallRankItem-Follow-Btn", GUIType.Button)
    self.siFollowed = self:getChildWindowByName("BedWarHallRankItem-Followed", GUIType.StaticImage)
    self.stFollowedText = self:getChildWindowByName("BedWarHallRankItem-Followed-Text", GUIType.StaticText)
    self.llRune = self:getChildWindowByName("BedWarHallRankItem-Rune", GUIType.Layout)
    self.btnRuneBtn = self:getChildWindowByName("BedWarHallRankItem-Rune-Btn", GUIType.Button)
    self.stOnLine = self:getChildWindowByName("BedWarHallRankItem-OnLine", GUIType.StaticText)

    self.stScoreDesc = self:getChildWindowByName("BedWarHallRankItem-Score-Desc", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("BedWarHallRankItem-Score", GUIType.StaticText)
    self.siScoreIcon = self:getChildWindowByName("BedWarHallRankItem-Score-Icon", GUIType.StaticImage)

    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.siHead:GetPixelSize().x)
    self.siHead:AddChildWindow(self.winHead.root)
    self.winHead:setCanOpenPersonalHome(false)

    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarHallRankItemWindow:initView()
    self.stPower:SetText(Lang:getString("gui_rank_power"))
    self.stFollowedText:SetText(Lang:getString("gui.personal.btn.followed"))
    self.stNoRank:SetText(Lang:getString("gui_rank_no_rank"))

    self:setTextColor(TextColor.Other)
    self.llRank:SetBackImage(BgImg.Other)
end

---@private
function GUIBedWarHallRankItemWindow:initEvent()
    self.btnFollowBtn:registerEvent(GUIEvent.ButtonClick, function()
        if self.userId == Game:getPlatformUserId() then
            return
        end
        WebService:FollowOtherPlayer(self.userId, function(code, data)
            if code == 1 then
                Events.PlayerFollowEvent:invoke(self.userId, Define.FollowOperationType.Follow)
                UIHelper.showToast(Lang:getString("gui_follow_tip_text"))
            end
        end)
    end)

    self.siFollowed:registerEvent(GUIEvent.Click, function()
        if self.userId == Game:getPlatformUserId() then
            return
        end
        CustomDialog.builder()
                    .setTitleText("gui_cancel_follow_tip_title")
                    .setContentText(Lang:getString("gui_cancel_follow_tip_text"))
                    .setRightText("gui_dialog_tip_btn_sure")
                    .setLeftText("gui_dialog_tip_btn_cancel")
                    .setRightClickListener(function()
            WebService:CancelFollowOtherPlayer(self.userId, function(code, data)
                if code == 1 then
                    Events.PlayerFollowEvent:invoke(self.userId, Define.FollowOperationType.CancelFollow)
                end
            end)
        end)
                    .show()
    end)

    self.btnRuneBtn:registerEvent(GUIEvent.ButtonClick, function()
        if self.userId == Game:getPlatformUserId() then
            return
        end
        local cache = UserInfoCache:GetCache(self.userId)
        if not cache[Define.PlayerCustomInfo.EquipRune] then
            WebService:GetPlayerCustomDataValue(self.userId, { Define.PlayerCustomInfo.EquipRune }, function(_, data)
                if not data then
                    local userInfo = {}
                    userInfo.userId = self.userId
                    userInfo[Define.PlayerCustomInfo.EquipRune] = "{}"
                    UserInfoCache:UpdateUserInfos({ userInfo })
                end
                GUIBedWarHallRankLayout:showRuneInfo(self.userId)
            end)
        else
            GUIBedWarHallRankLayout:showRuneInfo(self.userId)
        end
    end)

    self.root:registerEvent(GUIEvent.Click, function()
        if GMHelper.isOpenClearUserRank then
            CustomDialog.builder()
                        .setContentText("确定要删除该玩家的排行榜吗？")
                        .setRightClickListener(function()
                PlayerManager:getClientPlayer():sendPacket({
                    pid = "ClearUserRank",
                    userId = self.userId
                })
            end)        .show()
        end
        if self.userId == Game:getPlatformUserId() then
            return
        end
        local cache = UserInfoCache:GetCache(self.userId)
        if not cache.clanRole then
            WebService:GetUserInfosWithClan({ self.userId }, function()
                GUIBedWarHallRankLayout:showPlayerInfo(self.userId)
            end)
        else
            GUIBedWarHallRankLayout:showPlayerInfo(self.userId)
        end
    end)

    self:registerEvent(Events.PlayerFollowEvent, function(userId, followOperationType)
        if userId ~= self.userId or not GUIBedWarHallRankLayout:isShow() or not self.llFollow:IsVisible() then
            return
        end
        self:updateFollowStatus(followOperationType == Define.FollowOperationType.Follow)
    end)
end

---@param data table
function GUIBedWarHallRankItemWindow:onDataChanged(data, ignoreUI)
    if not data or not data.userId then
        return
    end
    local cache = UserInfoCache:GetCache(data.userId)
    self.userId = data.userId
    self.stName:SetText(data.nickName)
    self.winHead:setUserInfo(cache)
    self.stLv:SetText("Lv." .. (cache.playerLevel or 1))

    --显示类型
    local type = GUIBedWarHallRankLayout.curRankType
    local rankConfig = RankConfig:getRankConfigByKey(GUIBedWarHallRankLayout.curRankKey)

    if not ignoreUI then
        self:updateUI(type, data.isOnline or false, cache.followStatus or false)
    end

    self:setRankNum(data.rank or 0)

    self.stPower:SetVisible(type == Define.RankType.One)
    self.stWinRate:SetVisible(false)
    self.siDan:SetVisible(false)
    self.stScoreDesc:SetVisible(false)
    --显示分数
    if rankConfig and rankConfig.ScoreIcon ~= "#" then
        self.stScoreDesc:SetVisible(true)
        if GUIBedWarHallRankLayout.curSubType == Define.RankSubType.Friend then
            self.stScoreDesc:SetText(Lang:getString(rankConfig.ScoreDesc .. "_" .. Define.RankSubType.Friend))
        elseif rankConfig.Key == Define.RankKey.KeyRank
                or rankConfig.Key == Define.RankKey.NegativeRuneRank
                or rankConfig.Key == Define.RankKey.PropPacketRank
        then
            self.stScoreDesc:SetText(cache.userId)
        else
            self.stScoreDesc:SetText(Lang:getString(rankConfig.ScoreDesc))
        end
        local score = data.score == 0 and 0 or data.score
        if data.rank <= 0 then
            score = CRankUtil:getClientPlayerRankScore(GUIBedWarHallRankLayout.curRankKey, GUIBedWarHallRankLayout.curSubType)
        end
        self.stScore:SetText(score)
        self.siScoreIcon:SetImage(rankConfig.ScoreIcon)
        return
    end

    --按类型显示信息
    if type == Define.RankType.Two and rankConfig.Key == Define.RankKey.QualifyingRank then
        self.siDan:SetVisible(true)
        ---排位信息
        local segment, grade, starNumber = QualifyingTool.rankScore2Segment(data.score)
        local segmentData = {
            segment = segment,
            grade = grade,
            starNumber = starNumber
        }
        if data.rank <= 0 then
            segmentData = cache.qualifyingData
        else
        end
        QualifyingTool.setQualifyingSegmentInListUI(self.siDan, self.stDanName, segmentData)
        self.stStarNum:SetText(starNumber)
    elseif type == Define.RankType.Three then
        self.stWinRate:SetVisible(true)
        local battleRecord = json.decode(cache.battleRecord or "{}")
        local battleInfo = battleRecord and battleRecord[GUIBedWarHallRankLayout.curSubType]
        local win = 0
        local play = 0
        local rate = 0
        if battleInfo then
            win = battleInfo.lastRecord and battleInfo.lastRecord.win or battleInfo.win
            play = battleInfo.lastRecord and battleInfo.lastRecord.play or battleInfo.play
            if CRankUtil:win2Score(win, play) ~= data.score then
                win = battleInfo.win
                play = battleInfo.play
            end
            rate = play ~= 0 and string.format("%.f", win / play * 100) or "0"
        end
        self.stWinRate:SetText(Lang:format("gui_rank_win_rate_text", rate .. "%"))
        self.stWinTimes:SetText(Lang:format("gui_rank_win_times_text", win))
    end
end

function GUIBedWarHallRankItemWindow:updateUI(type, isOnline, followStatus)
    --文字颜色、背景
    local isSelf = self.userId == Game:getPlatformUserId()

    self.stOnLine:SetVisible(type == Define.RankType.Two and not isSelf and GUIBedWarHallRankLayout.curSubType ~= Define.RankSubType.Global)
    self.stOnLine:SetText(Lang:getString(isOnline and "gui.user.status.online" or "gui.user.status.offline"))

    self.llRune:SetVisible((type == Define.RankType.Three
            or GUIBedWarHallRankLayout.curRankKey == Define.RankKey.QualifyingRank
            or GUIBedWarHallRankLayout.curRankKey == Define.RankKey.RuneRank) and not isSelf)
    if GUIBedWarHallRankLayout.curRankKey == Define.RankKey.NegativeRuneRank then
        self.stOnLine:SetVisible(false)
        self.llRune:SetVisible(true)
    end
    self.llFollow:SetVisible(not self.llRune:IsVisible() and not isSelf)

    local isFollow = false
    if self.llFollow:IsVisible() then
        isFollow = followStatus and (followStatus == Define.FollowStatus.Follow or followStatus == Define.FollowStatus.EachFollow) or false
        self:updateFollowStatus(isFollow)
    end
end

function GUIBedWarHallRankItemWindow:initSelfData(data)
    self:setTextColor(TextColor.Self)
    self.llRank:SetBackImage(BgImg.Self)
    self.stOnLine:SetVisible(false)
    self.llRune:SetVisible(false)
    self.llFollow:SetVisible(false)
    self:onDataChanged(data, true)
end

function GUIBedWarHallRankItemWindow:setSelfData(data)
    self:onDataChanged(data, true)
end

function GUIBedWarHallRankItemWindow:setRankNum(rank)
    self.siRankNum1:SetVisible(false)
    self.siRankNum2:SetVisible(false)
    self.siRankNum3:SetVisible(false)
    self.siTopRank:SetVisible(false)
    self.stNoRank:SetVisible(false)
    if rank <= 0 or rank > 999 then
        self.stNoRank:SetVisible(true)
        return
    end

    local numStr = self.userId == Game:getPlatformUserId() and SelfNumStr or NorNumStr
    if rank > 0 and rank < 4 then
        numStr = TopNumStr
        self.siTopRank:SetVisible(true)
        self.siTopRank:SetImage(TopNumStr .. rank)
        return
    end

    local num = tostring(rank)
    local len = string.len(num)
    if len == 1 then
        self.siRankNum2:SetImage(numStr .. num)
        self.siRankNum2:SetVisible(true)
    elseif len == 2 then
        self.siRankNum1:SetImage(numStr .. string.sub(num, 1, 1))
        self.siRankNum3:SetImage(numStr .. string.sub(num, 2, 2))
        self.siRankNum1:SetXPosition({ 0.2, 0 })
        self.siRankNum3:SetXPosition({ -0.2, 0 })
        self.siRankNum1:SetVisible(true)
        self.siRankNum3:SetVisible(true)
    else
        self.siRankNum1:SetImage(numStr .. string.sub(num, 1, 1))
        self.siRankNum2:SetImage(numStr .. string.sub(num, 2, 2))
        self.siRankNum3:SetImage(numStr .. string.sub(num, 3, 3))
        self.siRankNum1:SetXPosition({ 0, 2 })
        self.siRankNum3:SetXPosition({ 0, -2 })
        self.siRankNum1:SetVisible(true)
        self.siRankNum2:SetVisible(true)
        self.siRankNum3:SetVisible(true)
    end
end

function GUIBedWarHallRankItemWindow:updateFollowStatus(isFollow)
    self.btnFollowBtn:SetVisible(not isFollow)
    self.siFollowed:SetVisible(isFollow)
end

---@param textColor table 文字颜色
function GUIBedWarHallRankItemWindow:setTextColor(textColor)
    self.stName:SetTextColor(textColor)
    self.stLv:SetTextColor(textColor)
    self.stWinRate:SetTextColor(textColor)
    self.stWinTimes:SetTextColor(textColor)
    self.stPower:SetTextColor(textColor)
    self.stPowerNum:SetTextColor(textColor)
    self.stDanName:SetTextColor(textColor)
    self.stStarNum:SetTextColor(textColor)
    self.stScoreDesc:SetTextColor(textColor)
    self.stScore:SetTextColor(textColor)
    self.stOnLine:SetTextColor(textColor)
end

return GUIBedWarHallRankItemWindow
