---@class UIBedWarQualifyingSeasonChallengeLayout : IGUILayout
local UIBedWarQualifyingSeasonChallengeLayout = class("UIBedWarQualifyingSeasonChallengeLayout", IGUILayout)
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")

---@private
function UIBedWarQualifyingSeasonChallengeLayout:ctor(parent)
    self.super.ctor(self, "BedWarQualifyingSeasonChallenge.json", parent)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:onLoad()
    self.llPanel = self:getChildWindow("BedWarQualifyingSeasonChallenge-Panel", GUIType.Layout)

    ---@type GUIBedWarQualifyingSeasonChallengePanel1Window
    local windowClass
    local qualifyingData = CQualifyingController:getQualifyingData()
    if qualifyingData then
        local success = pcall(function()
            windowClass = require("client.ui.window.GUIBedWarQualifyingSeasonChallengePanel" .. qualifyingData.quarter)
        end)
        if not success then
            windowClass = nil
        end
    end
    if not windowClass then
        windowClass = require "client.ui.window.GUIBedWarQualifyingSeasonChallengePanel1"
    end
    self.panelWindow = windowClass.new()
    self.llPanel:AddChildWindow(self.panelWindow.root)
    self:initView()
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:initView()
    ---@type GUIBedWarUIReturnControlWindow
    self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.qualifying.season.challenge", function()
        self:hide()
    end)
    self.root:AddChildWindow(self.llReturn.root)
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:initEvent()
end

---@private
function UIBedWarQualifyingSeasonChallengeLayout:onShow()
    if self.panelWindow then
        self.panelWindow.root:SetVisible(true)
        self.panelWindow:onShow()
    end
end

function UIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(rewardDetailId)
    if self.panelWindow then
        self.panelWindow:showRewardDetail(rewardDetailId)
    end
end

function UIBedWarQualifyingSeasonChallengeLayout:onHide()
    if self.panelWindow then
        self.panelWindow.root:SetVisible(false)
        self.panelWindow:onHide()
    end
end

return UIBedWarQualifyingSeasonChallengeLayout
