BaseGameConfig = {}

function BaseGameConfig:init()
    ItemID.DOUBLE_DUMMY = 582
    require "common.CommonHeader"
    require "game.config.BlockConfig"
    require "game.config.GainsConfig"
    require "game.config.TeamConfig"
    require "game.config.ResourceTypeConfig"
    require "game.config.PublicResourceConfig"
    require "game.config.ResourcePointConfig"
    require "common.config.TaskConfig"
    require "common.config.TreasureChallengeConfig"
    require "common.config.ActionEmojiConfig"
    require "common.config.CreditScoreConfig"
    require "game.config.SurveyConfig"
    if not isClient then
        require "game.config.HonourConfig"
    end
end
