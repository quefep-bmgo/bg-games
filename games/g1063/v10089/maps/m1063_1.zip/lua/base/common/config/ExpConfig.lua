local Settings = {}

ExpConfig = {}

function ExpConfig:initConfig(config)
    for _, exp in pairs(config) do
        ---@class ExpConfigItem
        local data = {}
        data.exp_lv = tonumber(exp.exp_lv) or 0
        data.exp_max = exp.exp_max or ""
        if GameType == "g1046" then
            data.rewards = {}
            local rewardIds = tostring(exp.rewardIds) ~= "0" and StringUtil.split(tostring(exp.rewardIds), "#") or {}
            local rewardNum = tostring(exp.rewardNum) ~= "0" and StringUtil.split(tostring(exp.rewardNum), "#") or {}
            local showDetailIds = tostring(exp.showDetailIds) ~= "0" and StringUtil.split(tostring(exp.showDetailIds), "#") or {}
            for i = 1, #rewardIds do
                if tonumber(rewardIds[i]) ~= 0 then
                    ---@class ExpConfigRewardItem
                    local rewardItem = {
                        RewardId = tonumber(rewardIds[i]) or 0,
                        Count = tonumber(rewardNum[i]) or 0,
                        ShowDetailId = tonumber(showDetailIds[i]) or 0
                    }
                    table.insert(data.rewards, rewardItem)
                end
            end
        end
        table.insert(Settings, data)
    end

    table.sort(Settings, function(a, b)
        return a.exp_lv < b.exp_lv
    end)
end

function ExpConfig:getMaxExp(exp_lv)
    for _, exp in pairs(Settings) do
        if tonumber(exp.exp_lv) == tonumber(exp_lv) then
            if tostring(exp.exp_max) == "###" then
                return 1, true
            else
                return tonumber(exp.exp_max), false
            end
        end
    end
    return 1, false
end

function ExpConfig:getPlayerInitLv(level)
    local max_lv = 1
    for _, exp in pairs(Settings) do
        if max_lv < exp.exp_lv then
            max_lv = exp.exp_lv
        end
    end
    if level > max_lv then
        return max_lv
    end
    return math.max(level, 1)
end

---@param lv number
---@return ExpConfigItem
function ExpConfig:getLvSetting(lv)
    for _, exp in pairs(Settings) do
        if tonumber(exp.exp_lv) == tonumber(lv) then
            return exp
        end
    end
end

function ExpConfig:getLvRewardSettings()
    local setting = {}
    for _, exp in pairs(Settings) do
        if #exp.rewards > 0 then
            table.insert(setting, exp)
        end
    end
    return setting
end

function ExpConfig:getIndex(lv)
    local index = 1
    for _, exp in pairs(Settings) do
        if #exp.rewards > 0 then
            if lv == exp.exp_lv then
                return index
            else
                index = index + 1
            end
        end
    end
    return 1
end

function ExpConfig:getLevelReward(lv)
    for _, exp in pairs(Settings) do
        if lv == exp.exp_lv then
            return exp.rewards
        end
    end
    return {}
end

ExpConfig:initConfig(FileUtil.getConfigFromCsv(GameType == "g1046" and "setting/ExpConfigHall.csv" or "setting/ExpConfig.csv", nil, true))

return ExpConfig