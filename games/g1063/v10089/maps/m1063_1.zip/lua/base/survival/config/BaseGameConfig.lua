BaseGameConfig = {}

function BaseGameConfig:init()
    require "common.CommonHeader"
    require "common.config.ActionEmojiConfig"
    require "survival.config.ItemDetailConfig"
end
