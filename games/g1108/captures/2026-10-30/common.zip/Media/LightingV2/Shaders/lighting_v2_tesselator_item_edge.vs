#version 300 es
/// 文件：lighting_v2_tesselator_item_edge.vs
/// 用途：物品描边顶点。沿物品局部径向在屏幕上外扩固定像素，不计算光照。
/// Catalog：mcItem_Edge
/// 特征：Unlit。PS 为 lighting_v2_edge.ps。
/// 顶点 ABI：同 mcItem（packed/127-1）*2。

in vec4 inPosition;

uniform mat4 matWVP;
uniform float edgeWidth; // 描边宽度倍率
uniform vec2 viewportSize; // 视口像素尺寸，用于把像素宽换成 NDC

const float EDGE_PIXEL_WIDTH = 2.0;
const float EDGE_DIR_EPSILON = 0.00001;

void main(void)
{
    vec3 blockPos = (inPosition.xyz / 127.0 - 1.0) * 2.0;
    vec3 localDir = blockPos;
    if (length(localDir) <= EDGE_DIR_EPSILON)
    {
        localDir = vec3(0.0, 1.0, 0.0);
    }

    vec4 baseClip = matWVP * vec4(blockPos, 1.0);
    vec4 normalClip = matWVP * vec4(blockPos + normalize(localDir), 1.0);
    vec2 baseNdc = baseClip.xy / max(abs(baseClip.w), EDGE_DIR_EPSILON);
    vec2 normalNdc = normalClip.xy / max(abs(normalClip.w), EDGE_DIR_EPSILON);
    vec2 screenDir = normalNdc - baseNdc;
    float dirLen = length(screenDir);
    vec2 pixelToNdc = vec2(2.0 / max(viewportSize.x, 1.0), 2.0 / max(viewportSize.y, 1.0));
    if (dirLen > EDGE_DIR_EPSILON)
    {
        // 沿屏幕径向外扩，再乘 clip.w，避免透视除法后宽度随深度变化。
        baseClip.xy += screenDir / dirLen * EDGE_PIXEL_WIDTH * edgeWidth * pixelToNdc * baseClip.w;
    }
    gl_Position = baseClip;
}
