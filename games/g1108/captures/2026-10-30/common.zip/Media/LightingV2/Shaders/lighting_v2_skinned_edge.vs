#version 300 es
/// 文件：lighting_v2_skinned_edge.vs
/// 用途：蒙皮网格描边：先 3 骨蒙皮，再沿屏幕空间法线外扩固定像素。
/// Catalog：SkinedMeshForActorEdge
/// 特征：LinearSceneAware / Unlit。像素着色走 lighting_v2_edge.ps。

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec3 inNormal;
in vec4 inBlendIndices;
in vec3 inBlendWeights;

uniform mat4 matWVP;
uniform vec4 boneMatRows[3*MAX_BONE_NUM];
uniform float edgeWidth;
uniform vec2 viewportSize;

const float EDGE_PIXEL_WIDTH = 2.0;
const float EDGE_DIR_EPSILON = 0.00001;

// 3×4 变换位置（含平移）。
vec3 MulBone4(vec4 vInputPos, int nMatrix, float fBlendWeight)
{
    vec3 vResult;
    vResult.x = dot(vInputPos, boneMatRows[(3*nMatrix)+0].xyzw);
    vResult.y = dot(vInputPos, boneMatRows[(3*nMatrix)+1].xyzw);
    vResult.z = dot(vInputPos, boneMatRows[(3*nMatrix)+2].xyzw);
    return vResult * fBlendWeight;
}

// 3×3 变换法线（不含平移）。
vec3 MulBone3(vec3 vInputNormal, int nMatrix, float fBlendWeight)
{
    vec3 vResult;
    vResult.x = dot(vInputNormal, boneMatRows[(3*nMatrix)+0].xyz);
    vResult.y = dot(vInputNormal, boneMatRows[(3*nMatrix)+1].xyz);
    vResult.z = dot(vInputNormal, boneMatRows[(3*nMatrix)+2].xyz);
    return vResult * fBlendWeight;
}

void main(void)
{
    ivec3 BoneIndices;
    BoneIndices.x = int(inBlendIndices.x);
    BoneIndices.y = int(inBlendIndices.y);
    BoneIndices.z = int(inBlendIndices.z);

    vec3 vPos = MulBone4(inPosition, BoneIndices.x, inBlendWeights.x)
        + MulBone4(inPosition, BoneIndices.y, inBlendWeights.y)
        + MulBone4(inPosition, BoneIndices.z, inBlendWeights.z);
    vec3 vNormal = MulBone3(inNormal, BoneIndices.x, inBlendWeights.x)
        + MulBone3(inNormal, BoneIndices.y, inBlendWeights.y)
        + MulBone3(inNormal, BoneIndices.z, inBlendWeights.z);

    // 蒙皮后再按屏幕空间法线外扩，保证动画中描边像素宽度稳定。
    vec4 baseClip = matWVP * vec4(vPos, 1.0);
    vec4 normalClip = matWVP * vec4(vPos + normalize(vNormal), 1.0);
    vec2 baseNdc = baseClip.xy / max(abs(baseClip.w), EDGE_DIR_EPSILON);
    vec2 normalNdc = normalClip.xy / max(abs(normalClip.w), EDGE_DIR_EPSILON);
    vec2 screenDir = normalNdc - baseNdc;
    float dirLen = length(screenDir);
    vec2 pixelToNdc = vec2(2.0 / max(viewportSize.x, 1.0), 2.0 / max(viewportSize.y, 1.0));
    if (dirLen > EDGE_DIR_EPSILON)
    {
        baseClip.xy += screenDir / dirLen * EDGE_PIXEL_WIDTH * edgeWidth * pixelToNdc * baseClip.w;
    }
    gl_Position = baseClip;
}
