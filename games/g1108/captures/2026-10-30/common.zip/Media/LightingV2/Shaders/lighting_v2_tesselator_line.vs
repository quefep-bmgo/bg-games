#version 300 es
/// 文件：lighting_v2_tesselator_line.vs
/// 用途：调试/选择线顶点。世界坐标直接乘 WVP，颜色原样透传。
/// Catalog：Tess_Line
/// 特征：Unlit / LinearSceneAware
/// 顶点 ABI：inPosition 已是世界坐标；inColor 已是 0~1

in vec3 inPosition;                  // 已是世界坐标
in vec4 inColor;

uniform mat4 matWVP;

out vec4 color;                      // 顶点色原样透传

void main(void)
{
	gl_Position = matWVP * vec4(inPosition, 1.0);

	color = inColor;
}

