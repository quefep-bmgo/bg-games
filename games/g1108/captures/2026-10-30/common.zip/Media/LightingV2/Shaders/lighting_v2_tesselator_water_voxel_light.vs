#version 300 es
/// 文件：lighting_v2_tesselator_water_voxel_light.vs
/// 用途：水体积 Water lighting + 体素遮挡图集。解析灯再乘 voxel atlas 可见度。
/// Catalog：Tess_Water_VoxelLight
/// 特征：Water / VertexPacked / None / VoxelAtlas / LinearSceneAware
/// 顶点 ABI：与 lighting_v2_tesselator_water.vs 相同的 4-bit Probe。

#ifdef GL_FRAGMENT_PRECISION_HIGH
	precision highp float;
#else
	precision mediump float;
#endif

in highp vec4 inPosition;             // .w=packed 4-bit Probe

uniform mat4 matWVP;
uniform vec4 sectionPos;
uniform vec4 fogParam[3];

out vec4 oFogColor;
out vec3 waterLighting;

uniform highp vec3 mainLightDir;
uniform highp vec3 terrainDirectionalRadiance;
uniform highp vec3 terrainSkyRadiance;
uniform highp vec4 terrainLightingParams; // x=天空响应曲线
uniform highp float placedBlockLightStrength; // 放置方块光倍率

const int BM_MAX_DYNAMIC_TERRAIN_LIGHTS = 4;
const float BM_VOXEL_VOLUME_DIM = 33.0;   // 每灯 33³
const float BM_VOXEL_ATLAS_SIZE = 198.0;  // 198² RGBA8
const float BM_VOXEL_ATLAS_TILES = 6.0;   // Z 切成 6 列 tile
uniform highp vec4 dynamicTerrainLight0PosRadius;
uniform highp vec4 dynamicTerrainLight0ColorStrength;
uniform highp vec4 dynamicTerrainLight0ProfileParams;
uniform highp vec4 dynamicTerrainLightPosRadius[BM_MAX_DYNAMIC_TERRAIN_LIGHTS];
uniform highp vec4 dynamicTerrainLightColorStrength[BM_MAX_DYNAMIC_TERRAIN_LIGHTS];
uniform highp vec4 dynamicTerrainLightProfileParams[BM_MAX_DYNAMIC_TERRAIN_LIGHTS];
uniform highp vec4 dynamicTerrainVoxelLightOrigins[BM_MAX_DYNAMIC_TERRAIN_LIGHTS];
uniform highp sampler2D texSampler_dynamicTerrainVoxelLight;

float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

// 体积水：半球固定 0.5，太阳用 0.5×太阳直射门控。
vec3 EvaluateWaterVolumeLighting(vec4 probe, vec3 extraLocal)
{
	float skyBrightness = clamp(probe.x, 0.0, 1.0);
	float curve = clamp(terrainLightingParams.x, 0.0, 10.0);
	float skyResponse = skyBrightness / ((1.0 - skyBrightness) * curve + 1.0);
	vec3 skyAmbient = terrainSkyRadiance
		* skyResponse;
	vec3 staticLocal = probe.yzw * 1.5 * placedBlockLightStrength;
	float sunGate = smoothstep(0.5 / 15.0, 3.5 / 15.0, skyBrightness);
	vec3 sun = terrainDirectionalRadiance * (0.5 * sunGate);
	vec3 lightmapLighting = skyAmbient + (staticLocal + extraLocal);
	return lightmapLighting + sun;
}

// 从体素遮挡图集取可见度。越界/未就绪返回 1，不把灯掐死。
highp float SampleVoxelVisibility(highp vec3 worldPos, highp vec3 faceNormal, int slot)
{
	highp vec4 originValid = dynamicTerrainVoxelLightOrigins[slot];
	if (originValid.w < 0.5)
		return 1.0;

	highp vec3 sampleCell = floor(worldPos + faceNormal * 0.01);
	highp vec3 local = sampleCell - originValid.xyz;
	if (any(lessThan(local, vec3(0.0))) || any(greaterThanEqual(local, vec3(BM_VOXEL_VOLUME_DIM))))
		return 1.0;

	int localZ = int(local.z);
	int tileX = localZ % 6;
	int tileY = localZ / 6;
	highp vec2 texel = vec2(float(tileX) * BM_VOXEL_VOLUME_DIM + local.x,
		float(tileY) * BM_VOXEL_VOLUME_DIM + local.y);
	highp vec4 packed = texture(texSampler_dynamicTerrainVoxelLight,
		(texel + vec2(0.5)) / BM_VOXEL_ATLAS_SIZE);
	return slot == 0 ? packed.r : (slot == 1 ? packed.g : (slot == 2 ? packed.b : packed.a));
}

// 解析衰减 × 体素可见度。动态地形点光不按面向性截断。
highp vec3 ApplyDynamicTerrainLight(highp vec3 dynLight, highp vec3 worldPos,
	highp vec3 faceNormal, highp vec4 posRadius, highp vec4 colorStrength,
	highp vec4 profileParams, int slot)
{
	highp float radius = posRadius.w;
	highp float strength = colorStrength.w;
	if (radius <= 0.001 || strength <= 0.001)
		return dynLight;

	highp vec3 lightDelta = posRadius.xyz - worldPos;
	highp float lightDistance = length(lightDelta);
	highp float sourceRadius = clamp(profileParams.x, 0.0, max(radius - 0.001, 0.0));
	highp float dist01 = clamp(max(lightDistance - sourceRadius, 0.0)
		/ max(radius - sourceRadius, 0.001), 0.0, 1.0);
	highp float distanceExponent = clamp(profileParams.y, 0.5, 8.0);
	highp float responseExponent = clamp(profileParams.z, 0.5, 8.0);
	highp float distancePower;
	if (abs(distanceExponent - 2.0) < 0.001) distancePower = dist01 * dist01;
	else if (abs(distanceExponent - 1.0) < 0.001) distancePower = dist01;
	else distancePower = pow(dist01, distanceExponent);
	highp float base = max(0.0, 1.0 - distancePower);
	highp float atten;
	if (abs(responseExponent - 1.0) < 0.001) atten = base;
	else if (abs(responseExponent - 2.0) < 0.001) atten = base * base;
	else atten = pow(base, responseExponent);
	highp float visibility = profileParams.w > 0.5
		? SampleVoxelVisibility(worldPos, faceNormal, slot) : 1.0; // w=体素遮挡开关
	return dynLight + colorStrength.rgb * (atten * visibility * strength);
}

highp vec3 ComputeDynamicTerrainLights(highp vec3 worldPos, highp vec3 faceNormal)
{
	highp vec3 dynLight = ApplyDynamicTerrainLight(vec3(0.0), worldPos, faceNormal,
		dynamicTerrainLight0PosRadius, dynamicTerrainLight0ColorStrength,
		dynamicTerrainLight0ProfileParams, 0);
	for (int i = 1; i < BM_MAX_DYNAMIC_TERRAIN_LIGHTS; ++i)
		dynLight = ApplyDynamicTerrainLight(dynLight, worldPos, faceNormal,
			dynamicTerrainLightPosRadius[i], dynamicTerrainLightColorStrength[i],
			dynamicTerrainLightProfileParams[i], i);
	return dynLight;
}

void main()
{
	vec3 blockPos = inPosition.xyz / 2048.0 + sectionPos.xyz;
	gl_Position = matWVP * vec4(blockPos, 1.0);
	highp float packedProbe = floor(inPosition.w + 0.5);
	highp vec4 probe;
	probe.x = mod(packedProbe, 16.0) / 15.0;                 // 天空亮度
	probe.y = mod(floor(packedProbe / 16.0), 16.0) / 15.0;    // 静态局部光 R
	probe.z = mod(floor(packedProbe / 256.0), 16.0) / 15.0;
	probe.w = mod(floor(packedProbe / 4096.0), 16.0) / 15.0;
	waterLighting = EvaluateWaterVolumeLighting(probe,
		ComputeDynamicTerrainLights(blockPos, vec3(0.0)));

	oFogColor = vec4(fogParam[1].rgb,
		ComputeFog(blockPos-fogParam[2].xyz, fogParam[0].xyz));
}
