#version 300 es
/// 文件：lighting_v2_tesselator_array_medium_v2.vs
/// 用途：Medium LDR Array 顶点入口。VS 预打包天空+洞穴+背光到 v_indirectIrradiance，雾关闭。
/// Catalog：Tess_Solid_No_Alpha_Test_Array_NoLocal_Medium_v2
/// 宏：BM_TERRAIN_MEDIUM_LDR、BM_TERRAIN_FOG_DISABLED
/// Include：lighting_v2_tesselator_array_v2.glslinc

#define BM_TERRAIN_MEDIUM_LDR 1
#define BM_TERRAIN_FOG_DISABLED 1
#include "lighting_v2_tesselator_array_v2.glslinc"
