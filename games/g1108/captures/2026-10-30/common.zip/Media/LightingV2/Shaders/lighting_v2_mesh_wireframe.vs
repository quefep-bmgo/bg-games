#version 300 es
/// 文件：lighting_v2_mesh_wireframe.vs
/// 用途：静态网格线框顶点：只做 WVP。像素走 edge.ps 纯色。
/// Catalog：StaticMeshForActorWireframe
/// 特征：LinearSceneAware / Unlit。

in vec3 inPosition;

uniform mat4 matWVP;

void main(void)
{
    gl_Position = matWVP * vec4(inPosition, 1.0);
}
