#version 300 es
/// 文件：lighting_v2_tesselator_purecolor.vs
/// 用途：纯色方块顶点。只还原格点并输出顶点色，不算光照。
/// Catalog：Tess_Solid_PureColor
/// 特征：Unlit / LinearSceneAware
/// 顶点 ABI：inPosition.xyz=/15；inColor.rgb/255；.w 低 3bit=sectionIndex

in vec4 inPosition;                  // .xyz=/15 格点
in vec4 inColor;                     // rgb=8bit 顶点色；.w 低 3bit=sectionIndex

uniform mat4 matWVP;
uniform vec4 cellOrigin;             // 2×2×2 section 合批的 cell 原点

out vec4 lightColor;                 // rgb=归一化顶点色，a=1

void main(void)
{
	vec3 blockPos = inPosition.xyz / 15.0;
	int sectionIndex = int(floor(inColor.w + 0.5)) & 7;
	vec3 sectionOffset = vec3(float(sectionIndex & 1),
		float((sectionIndex >> 1) & 1), float((sectionIndex >> 2) & 1)) * 16.0;
	blockPos += cellOrigin.xyz + sectionOffset;
	gl_Position = matWVP * vec4(blockPos, 1.0);
	lightColor = vec4(inColor.rgb / 255.0, 1.0);
}
