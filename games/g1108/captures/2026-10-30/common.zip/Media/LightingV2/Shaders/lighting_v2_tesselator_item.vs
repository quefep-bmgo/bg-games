#version 300 es
/// 文件：lighting_v2_tesselator_item.vs
/// 用途：UI/兼容物品顶点。无可靠法线，走 VertexLit：CPU 一次解析方向无关辐照，写入 extraColor。
/// Catalog：mcItem
/// 特征：VertexLit + ObjectUniform + Shadow None。不读世界 Probe，不采样 CSM。
/// 顶点 ABI：inPosition.xyz=(packed/127-1)*2；.w 高位=面索引（只供 legacyFaceBrightness）；inTexCoord=/32768

in vec4 inPosition;
in vec2 inTexCoord;
in vec4 inColor; // rgb=顶点 tint

uniform mat4 matWVP;
uniform mat4 matWorld;

uniform vec4 fogParam; // xyz=fogStart/fogEnd/density
uniform vec3 cameraPos;
uniform vec4 extraColor; // rgb=VertexLit 方向无关辐照（ObjectUniform）
uniform highp vec4 sceneColorOutputParams; // x>0.5=线性 HDR 场景色

out vec4 lightColor; // rgb=已点亮色，w=雾可见度
out vec2 texCoord;

// 线性雾可见度：1=无雾。param.x/y/z = fogStart/fogEnd/density。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

vec3 GammaToLinear(vec3 color)
{
	return pow(max(color, vec3(0.0)), vec3(2.2));
}

void main(void)
{
	vec3 blockPos = (inPosition.xyz / 127.0 - 1.0) * 2.0;
	vec4 vWorldPos = matWorld * vec4(blockPos, 1.0);
			
	texCoord = inTexCoord / 32768.0;
	
	gl_Position = matWVP * vec4(blockPos, 1.0);
	
	// lighting
	// 顶点光：无可靠法线，不能 Lambert。legacyFaceBrightness 只是 UI/物品美术面明暗，不参与世界 Probe。
	float faceNormalIndex = floor(inPosition.w / 16.0);
	float frontOrBack = step(3.5, faceNormalIndex) * step(faceNormalIndex, 5.5);
	float legacyFaceBrightness = mix(1.0, 0.7, frontOrBack);
	vec3 legacyColor = inColor.rgb * extraColor.rgb * legacyFaceBrightness;
	lightColor.xyz = sceneColorOutputParams.x > 0.5
		? GammaToLinear(legacyColor) : legacyColor;
	lightColor.w = ComputeFog(vWorldPos.xyz - cameraPos, fogParam.xyz);
}
