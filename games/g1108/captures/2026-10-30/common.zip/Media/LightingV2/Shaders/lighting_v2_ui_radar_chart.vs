#version 300 es
/// 文件：lighting_v2_ui_radar_chart.vs
/// 用途：雷达图顶点：WVP 变换，把 inTexCoord 当作局部 [0,1] 坐标传给像素。
/// Catalog：UIRadarChart
/// 特征：NotSceneColor。

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec4 inColor;
layout(location = 2) in vec2 inTexCoord;

uniform mat4 matWVP;

out mediump vec4 color;
out mediump vec2 localPos;

void main(void)
{
    gl_Position = matWVP * vec4(inPosition, 1.0);
    color = inColor;
    // 像素 shader 用局部 UV 算六边形，不用采样贴图。
    localPos = inTexCoord;
}
