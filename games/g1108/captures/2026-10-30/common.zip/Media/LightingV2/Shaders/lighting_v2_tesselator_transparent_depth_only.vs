#version 300 es
/// 文件：lighting_v2_tesselator_transparent_depth_only.vs
/// 用途：透明预深度。只还原格点并输出裁剪坐标，不算光照、不传 varying。
/// Catalog：Tess_Transparent_DepthOnly
/// 特征：Unlit / DepthOnly
/// 顶点 ABI：inPosition.xyz=/15；inColor.w 低 3bit=sectionIndex

precision highp float;

in vec4 inPosition;                  // .xyz=/15 格点
in vec4 inColor;                     // .w 低 3bit=sectionIndex

uniform mat4 matWVP;
uniform vec4 cellOrigin;             // 2×2×2 section 合批的 cell 原点

void main(void)
{
	vec3 blockPos = inPosition.xyz / 15.0;
	// 只解 section 偏移，忽略材质变体/greedy：深度预通不需要。
	int packedTerrainMeta = int(floor(inColor.w + 0.5));
	int sectionIndex = packedTerrainMeta & 7;
	vec3 sectionOffset = vec3(float(sectionIndex & 1),
		float((sectionIndex >> 1) & 1),
		float((sectionIndex >> 2) & 1)) * 16.0;
	blockPos = cellOrigin.xyz + sectionOffset + blockPos;
	gl_Position = matWVP * vec4(blockPos, 1.0);
}
