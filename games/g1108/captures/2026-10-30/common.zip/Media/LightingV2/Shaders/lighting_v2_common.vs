#version 300 es
/// 文件：lighting_v2_common.vs
/// 用途：无光照通用顶点入口。只做 WVP 变换并透传顶点色/UV。
/// Catalog：UI、Font、mcFont、Effect、EffectSky、BackgroundForEditor 等
/// 特征：Unlit；多数 NotSceneColor，Effect/EffectSky/mcFont 为 LinearSceneAware

in vec3 inPosition;
in vec4 inColor;          // 顶点色，由 PS 决定是否当光照
in vec2 inTexCoord;

uniform mat4 matWVP;

out vec4 color;
out vec2 texCoord;

void main(void)
{
	gl_Position = matWVP * vec4(inPosition, 1.0);

	color = inColor;
	texCoord = inTexCoord;
}