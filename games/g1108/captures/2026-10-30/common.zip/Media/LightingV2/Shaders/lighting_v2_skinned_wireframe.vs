#version 300 es
/// 文件：lighting_v2_skinned_wireframe.vs
/// 用途：蒙皮网格线框顶点：3 骨蒙皮后 WVP。像素走 edge.ps 纯色。
/// Catalog：SkinedMeshForActorWireframe
/// 特征：LinearSceneAware / Unlit。

#define MAX_BONE_NUM 73

in vec3 inPosition;
in vec4 inBlendIndices;
in vec3 inBlendWeights;

uniform mat4 matWVP;
uniform vec4 boneMatRows[3*MAX_BONE_NUM];

// 3×4 变换位置（含平移）。线框不需要法线。
vec3 MulBone4(vec4 vInputPos, int nMatrix, float fBlendWeight)
{
    vec3 vResult;
    vResult.x = dot(vInputPos, boneMatRows[(3*nMatrix)+0].xyzw);
    vResult.y = dot(vInputPos, boneMatRows[(3*nMatrix)+1].xyzw);
    vResult.z = dot(vInputPos, boneMatRows[(3*nMatrix)+2].xyzw);
    return vResult * fBlendWeight;
}

void main(void)
{
    ivec3 boneIndices;
    boneIndices.x = int(inBlendIndices.x);
    boneIndices.y = int(inBlendIndices.y);
    boneIndices.z = int(inBlendIndices.z);

    vec3 vPos = MulBone4(vec4(inPosition, 1.0), boneIndices.x, inBlendWeights.x)
        + MulBone4(vec4(inPosition, 1.0), boneIndices.y, inBlendWeights.y)
        + MulBone4(vec4(inPosition, 1.0), boneIndices.z, inBlendWeights.z);

    gl_Position = matWVP * vec4(vPos, 1.0);
}
