#version 300 es

precision highp float;

in vec3 inPosition;
in vec2 inTexCoord;

uniform mat4 matWorld;
uniform mat4 matWVP;
uniform vec4 fogParam;
uniform vec3 cameraPos;
uniform mediump vec3 terrainSkyRadiance;
uniform mediump vec4 objectDynamicLightIrradiance;

out mediump vec4 lightColor;
out mediump vec2 texCoord;

float computeFogVisibility(vec3 worldPosition)
{
	if (fogParam.z <= 0.0)
		return 1.0;
	float distanceFromFogStart = max(length(worldPosition - cameraPos)
		- fogParam.x, 0.0);
	float fogRange = max(fogParam.y - fogParam.x, 0.001);
	float density = clamp(distanceFromFogStart / fogRange, 0.0, 1.0)
		* fogParam.z;
	return 1.0 - clamp(density, 0.0, 1.0);
}

void main(void)
{
	vec4 worldPosition = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * vec4(inPosition, 1.0);
	texCoord = inTexCoord;
	lightColor.rgb = clamp(terrainSkyRadiance
		+ objectDynamicLightIrradiance.rgb, 0.0, 1.0);
	lightColor.a = computeFogVisibility(worldPosition.xyz);
}
