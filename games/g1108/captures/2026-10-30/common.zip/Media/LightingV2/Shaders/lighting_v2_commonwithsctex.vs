#version 300 es
/// 文件：lighting_v2_commonwithsctex.vs
/// 用途：在 common.vs 基础上额外输出裁剪空间位置，供屏幕空间扭曲采样。
/// Catalog：DistortionEffect
/// 特征：Unlit / NotSceneColor
/// 顶点 ABI：与 lighting_v2_common.vs 相同，另出 clipPos。

in vec3 inPosition;
in vec4 inColor;
in vec2 inTexCoord;

uniform mat4 matWVP;

out vec4 color;
out vec2 texCoord;

out vec4 clipPos;         // 裁剪空间，PS 用来还原屏幕 UV

void main(void)
{
	clipPos = matWVP * vec4(inPosition.xyz, 1.0);
	gl_Position = clipPos;
	color = inColor;
	texCoord = inTexCoord;
}