#version 300 es
/// 文件：lighting_v2_localScale.vs
/// 用途：特效天空局部缩放顶点入口。在 common.vs 上多传一套 per-vertex scale。
/// Catalog：EffectSkyLocalScale
/// 特征：Unlit / NotSceneColor
/// 顶点 ABI：inTexCoord1 = 局部缩放，不参与光照。

in vec3 inPosition;
in vec4 inColor;
in vec2 inTexCoord;
in vec2 inTexCoord1;      // 局部缩放

uniform mat4 matWVP;

out vec4 color;
out vec2 texCoord;
out vec2 scale;           // 透传 inTexCoord1

void main(void)
{
	gl_Position = matWVP * vec4(inPosition, 1.0);

	color = inColor;
	texCoord = inTexCoord;
	scale = inTexCoord1;
}