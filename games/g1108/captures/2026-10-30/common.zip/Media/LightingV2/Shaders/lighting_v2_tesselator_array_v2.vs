#version 300 es
/// 文件：lighting_v2_tesselator_array_v2.vs
/// 用途：Terrain Array 标准顶点入口。
/// Catalog：Tess_Solid_No_Alpha_Test_Array_v2 等
/// Include：lighting_v2_tesselator_array_v2.glslinc（完整实现）

#include "lighting_v2_tesselator_array_v2.glslinc"
