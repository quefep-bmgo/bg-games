#version 300 es
/// 文件：lighting_v2_skinned_xray.vs
/// 用途：蒙皮网格 Xray 顶点：3 骨蒙皮后 WVP。加减 inNormal/inTexCoord 保住 attribute。
/// Catalog：SkinedMeshForActorXray
/// 特征：LinearSceneAware / Unlit。像素走 lighting_v2_xray.ps。

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec3 inNormal;
in vec2 inTexCoord;
in vec4 inBlendIndices;
in vec3 inBlendWeights;

uniform mat4 matWVP;
uniform vec4 boneMatRows[3*MAX_BONE_NUM];

// 3×3 变换；本 VS 最终用加减抵消法线，但仍要编译进同一顶点格式。
vec3 MulBone3( vec3 vInputPos, int nMatrix, float fBlendWeight )
{
    vec3 vResult;
    vResult.x = dot( vInputPos, boneMatRows[3*nMatrix+0].xyz );
    vResult.y = dot( vInputPos, boneMatRows[3*nMatrix+1].xyz );
    vResult.z = dot( vInputPos, boneMatRows[3*nMatrix+2].xyz );
    return vResult * fBlendWeight;
}

// 3×4 变换位置（含平移）。
vec3 MulBone4( vec4 vInputPos, int nMatrix, float fBlendWeight )
{
    vec3 vResult;
    vResult.x = dot( vInputPos, boneMatRows[(3*nMatrix)+0].xyzw );
    vResult.y = dot( vInputPos, boneMatRows[(3*nMatrix)+1].xyzw );
    vResult.z = dot( vInputPos, boneMatRows[(3*nMatrix)+2].xyzw );
    return vResult * fBlendWeight;
}

void main(void)
{
	vec3 vPos;
	
	ivec3 BoneIndices;
	BoneIndices.x = int(inBlendIndices.x);
	BoneIndices.y = int(inBlendIndices.y);
	BoneIndices.z = int(inBlendIndices.z);
	
  	vPos  = MulBone4(inPosition, BoneIndices.x, inBlendWeights.x);
  	vPos += MulBone4(inPosition, BoneIndices.y, inBlendWeights.y);
  	vPos += MulBone4(inPosition, BoneIndices.z, inBlendWeights.z);
	
	// blend vertex
	// 蒙皮位置；随后 +N+UV-N-UV 保住 attribute，净位移为 0。
	gl_Position = matWVP * vec4(vPos, 1.0) 
	+ vec4( inNormal, 0.0) + vec4( inTexCoord, 0.0, 0.0) 
	- vec4( inNormal, 0.0) - vec4( inTexCoord, 0.0, 0.0);
}