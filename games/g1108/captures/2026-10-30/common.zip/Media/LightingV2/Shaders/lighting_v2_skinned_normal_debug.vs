#version 300 es
/// 文件：lighting_v2_skinned_normal_debug.vs
/// 用途：蒙皮网格法线调试顶点：3 骨蒙皮后再把世界法线编码成颜色。
/// Catalog：SkinedMeshForActorNormalDebug
/// 特征：LinearSceneAware / Unlit。骨骼 ABI 与主角色 VS 相同（3 行矩阵 × 73 骨）。

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec3 inNormal;
in vec4 inBlendIndices;
in vec3 inBlendWeights;

uniform mat4 matWorld;
uniform mat4 matWVP;
uniform vec4 boneMatRows[3*MAX_BONE_NUM];

out mediump vec3 normalColor;

// 3×3 变换法线（不含平移）。
vec3 MulBone3(vec3 vInputPos, int nMatrix, float fBlendWeight)
{
    vec3 vResult;
    vResult.x = dot(vInputPos, boneMatRows[3*nMatrix+0].xyz);
    vResult.y = dot(vInputPos, boneMatRows[3*nMatrix+1].xyz);
    vResult.z = dot(vInputPos, boneMatRows[3*nMatrix+2].xyz);
    return vResult * fBlendWeight;
}

// 3×4 变换位置（含平移）。
vec3 MulBone4(vec4 vInputPos, int nMatrix, float fBlendWeight)
{
    vec3 vResult;
    vResult.x = dot(vInputPos, boneMatRows[(3*nMatrix)+0].xyzw);
    vResult.y = dot(vInputPos, boneMatRows[(3*nMatrix)+1].xyzw);
    vResult.z = dot(vInputPos, boneMatRows[(3*nMatrix)+2].xyzw);
    return vResult * fBlendWeight;
}

void main(void)
{
    ivec3 boneIndices;
    boneIndices.x = int(inBlendIndices.x);
    boneIndices.y = int(inBlendIndices.y);
    boneIndices.z = int(inBlendIndices.z);

    // 前三骨加权；与主角色 VS 同一 73 骨 ABI。
    vec3 vPos = MulBone4(inPosition, boneIndices.x, inBlendWeights.x)
        + MulBone4(inPosition, boneIndices.y, inBlendWeights.y)
        + MulBone4(inPosition, boneIndices.z, inBlendWeights.z);
    vec3 vNormal = MulBone3(inNormal, boneIndices.x, inBlendWeights.x)
        + MulBone3(inNormal, boneIndices.y, inBlendWeights.y)
        + MulBone3(inNormal, boneIndices.z, inBlendWeights.z);

    gl_Position = matWVP * vec4(vPos, 1.0);
    vec3 worldNormal = normalize(mat3(matWorld) * vNormal);
    // 蒙皮后的世界法线编成 [0,1] 色。
    normalColor = worldNormal * 0.5 + 0.5;
}
