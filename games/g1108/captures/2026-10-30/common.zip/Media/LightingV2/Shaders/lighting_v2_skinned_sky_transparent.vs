#version 300 es
/// 文件：lighting_v2_skinned_sky_transparent.vs
/// 用途：蒙皮 Actor 透明天空特效顶点。与 skinned_sky.vs 相同，另把 alphaColor.a 写入 color.a。
/// Catalog：SkinedMeshForActorSkyTransparent
/// 特征：Unlit / LinearSceneAware

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec3 inNormal;
in vec2 inTexCoord;
in vec4 inBlendIndices;
in vec3 inBlendWeights;

uniform mat4 matWVP;
uniform mat4 matWorld;
uniform vec4 fogParam[3];             // [0]=start/end/density，[1]=雾色，[2]=相机
uniform vec4 boneMatRows[3*MAX_BONE_NUM];
uniform vec3 viewPos;
uniform vec4 alphaColor;              // .a=整网格透明度

out vec4 oFogColor;                   // rgb=雾色，a=雾可见度
out vec4 color;                       // .a 来自 alphaColor
out vec2 texCoord;
out vec3 normal;
out vec3 viewDir;

invariant gl_Position;

// 3 行骨骼矩阵变换方向（不含平移）。
vec3 MulBone3( vec3 vInputPos, int nMatrix, float fBlendWeight )
{
	vec3 vResult;
	vResult.x = dot( vInputPos, boneMatRows[3*nMatrix+0].xyz );
	vResult.y = dot( vInputPos, boneMatRows[3*nMatrix+1].xyz );
	vResult.z = dot( vInputPos, boneMatRows[3*nMatrix+2].xyz );
	return vResult * fBlendWeight;
}

// 3 行骨骼矩阵变换位置（含平移）。
vec3 MulBone4( vec4 vInputPos, int nMatrix, float fBlendWeight )
{
	vec3 vResult;
	vResult.x = dot( vInputPos, boneMatRows[(3*nMatrix)+0].xyzw );
	vResult.y = dot( vInputPos, boneMatRows[(3*nMatrix)+1].xyzw );
	vResult.z = dot( vInputPos, boneMatRows[(3*nMatrix)+2].xyzw );
	return vResult * fBlendWeight;
}

// 线性距离雾可见度：1=无雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	vec3 vPos;
	vec3 vNorm;
	vec4 vWorldPos;
	ivec3 BoneIndices;

	BoneIndices.x = int(inBlendIndices.x);
	BoneIndices.y = int(inBlendIndices.y);
	BoneIndices.z = int(inBlendIndices.z);

	vPos = MulBone4(inPosition, BoneIndices.x, inBlendWeights.x)
		+ MulBone4(inPosition, BoneIndices.y, inBlendWeights.y)
		+ MulBone4(inPosition, BoneIndices.z, inBlendWeights.z);

	vNorm = MulBone3(inNormal, BoneIndices.x, inBlendWeights.x)
		+ MulBone3(inNormal, BoneIndices.y, inBlendWeights.y)
		+ MulBone3(inNormal, BoneIndices.z, inBlendWeights.z);

	vWorldPos = matWorld * vec4(vPos, 1.0);

	gl_Position = matWVP * vec4(vPos, 1.0);
	texCoord = inTexCoord;

	vNorm = normalize(mat3(matWorld)*vNorm);

	normal = vNorm;
	viewDir = viewPos - vWorldPos.xyz;

	color = vec4(1.0, 1.0, 1.0, 1.0);
	color.a = alphaColor.a;

	oFogColor = vec4(fogParam[1].rgb, ComputeFog(vWorldPos.xyz - fogParam[2].xyz, fogParam[0].xyz));
}
