#version 300 es
/// 文件：lighting_v2_terrain_outline_fat_line.vs
/// 用途：地形描边粗线。把线段挤成屏幕空间四边形，并按透视压线宽。
/// Catalog：Tess_TerrainOutlineFatLine
/// 特征：Unlit / LinearSceneAware
/// 顶点 ABI：
///   inPosition=当前端世界坐标；inNormal 复用为另一端世界坐标
///   inTexCoord1.x=横向偏移符号，.y=半宽，.z=AA 像素，.w=是否终点

in vec3 inPosition;                  // 当前端世界坐标
in vec3 inNormal;                    // 复用：线段另一端世界坐标
in vec4 inColor;
in vec4 inTexCoord1;                 // .x=侧向符号，.y=半宽，.z=AA，.w>0.5=终点

uniform mat4 matWVP;
uniform vec2 viewportSize;           // 像素尺寸，用于 NDC↔屏幕

out mediump vec4 color;
out highp vec2 startScreen;          // 线段屏幕起点
out highp vec2 endScreen;            // 线段屏幕终点
out mediump float lineHalfWidth;     // 透视缩放后的半宽
out mediump float lineAaSize;        // 透视缩放后的 AA 带宽

void main(void)
{
    vec4 currClip = matWVP * vec4(inPosition, 1.0);
    vec4 otherClip = matWVP * vec4(inNormal, 1.0);

    float currW = currClip.w;
    float otherW = otherClip.w;
    // 相机后方或 w≈0 时裁到屏外，避免除零和反向投影。
    if (abs(currW) < 0.0001 || abs(otherW) < 0.0001 || currW < 0.0 || otherW < 0.0)
    {
        gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
        color = vec4(0.0);
        startScreen = vec2(0.0);
        endScreen = vec2(0.0);
        lineHalfWidth = 1.0;
        lineAaSize = 1.0;
        return;
    }

    vec2 currNdc = currClip.xy / currW;
    vec2 otherNdc = otherClip.xy / otherW;
    vec2 dir = otherNdc - currNdc;
    float dirLen = length(dir);
    // 退化成点：仍输出当前位置，避免零长度方向除零。
    if (dirLen < 0.00001)
    {
        gl_Position = currClip;
        color = inColor;
        startScreen = (currNdc * 0.5 + 0.5) * viewportSize;
        endScreen = startScreen;
        lineHalfWidth = 1.0;
        lineAaSize = 1.0;
        return;
    }

    dir = dir / dirLen;
    vec2 normal = vec2(-dir.y, dir.x);
    vec2 pixelToNdc = vec2(2.0 / viewportSize.x, 2.0 / viewportSize.y);
    float referenceDistance = 24.0;
    float minWidthScale = 0.35;
    float segmentW = (currW + otherW) * 0.5;
    // 近处按透视压线宽，远处不低于 minWidthScale，避免远景线消失。
    float widthScale = clamp(referenceDistance / max(segmentW, referenceDistance), minWidthScale, 1.0);
    float scaledHalfWidth = max(inTexCoord1.y * widthScale, 0.75);
    float scaledAaSize = max(inTexCoord1.z * widthScale, 0.5);
    vec2 offset = normal * inTexCoord1.x * scaledHalfWidth * pixelToNdc;

    currClip.xy += offset * currClip.w;
    gl_Position = currClip;

    color = inColor;
    vec2 currScreen = (currNdc * 0.5 + 0.5) * viewportSize;
    vec2 otherScreen = (otherNdc * 0.5 + 0.5) * viewportSize;
    // 两端顶点都写出同一条屏幕线段，PS 才能按像素算到线的距离。
    bool isEndPoint = inTexCoord1.w > 0.5;
    startScreen = isEndPoint ? otherScreen : currScreen;
    endScreen = isEndPoint ? currScreen : otherScreen;
    lineHalfWidth = scaledHalfWidth;
    lineAaSize = scaledAaSize;
}
