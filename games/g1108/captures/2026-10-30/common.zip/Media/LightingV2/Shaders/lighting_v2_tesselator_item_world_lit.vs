#version 300 es
/// 文件：lighting_v2_tesselator_item_world_lit.vs
/// 用途：世界物品顶点。有面法线，按灯算 Lambert；天空/洞穴/放置方块光 + 对象 Top-K 局部光 + 太阳直射。
/// Catalog：mcItemWorldLit
/// 特征：Lambert + ObjectUniform + Analytic。无 CSM（CSM 只调太阳直射，本 Program 用 sunGate 近似资格）。
/// 顶点 ABI：同 mcItem（packed/127-1）*2；inPosition.w 高位=15 槽面法线索引。

in highp vec4 inPosition;
in vec2 inTexCoord;
in vec4 inColor; // rgb=顶点 tint（作者空间；HDR 时再解码）

uniform mat4 matWVP;
uniform mat4 matWorld;
uniform vec4 fogParam; // xyz=fogStart/fogEnd/density
uniform vec3 cameraPos;
uniform highp vec3 mainLightDir; // 太阳方向（指向光源）
uniform highp vec3 terrainDirectionalRadiance; // 太阳直射辐照
uniform highp vec3 terrainSkyRadiance; // 天空环境辐照
uniform highp vec4 terrainLightingParams; // x=skyResponseCurve，y=sunDiffuseWrap
uniform highp vec4 sceneColorOutputParams; // x>0.5=线性 HDR，z=全局昼间强度
// World Item reuses the existing object color uniform: a=raw sky, rgb=resolved local irradiance.
// 世界物品复用 extraColor：a=天空亮度 skyBrightness，rgb=已解析局部光（放置方块光）。
uniform highp vec4 extraColor;
const int BM_MAX_OBJECT_DYNAMIC_LIGHTS = 4;
uniform highp vec4 objectDynamicLightDirectionWeight[BM_MAX_OBJECT_DYNAMIC_LIGHTS]; // xyz=灯方向，w=1 用 Lambert / 0 方向无关
uniform highp vec4 objectDynamicLightIrradiance[BM_MAX_OBJECT_DYNAMIC_LIGHTS]; // rgb=对象 Top-K 局部光辐照
uniform highp float actorLightStrength; // 世界 Item / VertexLit 接收倍率

out vec4 lightColor; // rgb=tint×辐照，w=雾可见度
out vec2 texCoord;

const float kInvSqrt2 = 0.70710678118;
const vec3 kFaceNormals[15] = vec3[15](
	vec3( 1.0,       0.0,       0.0),
	vec3(-1.0,       0.0,       0.0),
	vec3( 0.0,       1.0,       0.0),
	vec3( 0.0,      -1.0,       0.0),
	vec3( 0.0,       0.0,       1.0),
	vec3( 0.0,       0.0,      -1.0),
	vec3( kInvSqrt2, 0.0,       kInvSqrt2),
	vec3( kInvSqrt2, 0.0,      -kInvSqrt2),
	vec3(-kInvSqrt2, 0.0,       kInvSqrt2),
	vec3(-kInvSqrt2, 0.0,      -kInvSqrt2),
	vec3( kInvSqrt2, kInvSqrt2, 0.0),
	vec3(-kInvSqrt2, kInvSqrt2, 0.0),
	vec3( 0.0,       kInvSqrt2, kInvSqrt2),
	vec3( 0.0,       kInvSqrt2,-kInvSqrt2),
	vec3( 0.0,       1.0,       0.0)
);

// 线性雾可见度：1=无雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist / (param.y - param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

vec3 GammaToLinear(vec3 color)
{
	return pow(max(color, vec3(0.0)), vec3(2.2));
}

// 对象 Top-K 局部光。w=0 时方向无关（无可靠法线灯），避免伪造法线。
highp vec3 ComputeObjectDynamicLight(highp vec3 worldNormal)
{
	highp vec3 result = vec3(0.0);
	for (int i = 0; i < BM_MAX_OBJECT_DYNAMIC_LIGHTS; ++i)
	{
		highp float diffuse = mix(1.0,
			max(dot(worldNormal, objectDynamicLightDirectionWeight[i].xyz), 0.0),
			objectDynamicLightDirectionWeight[i].w);
		result += objectDynamicLightIrradiance[i].rgb * diffuse;
	}
	return result;
}

void main(void)
{
	vec3 itemPos = (inPosition.xyz / 127.0 - 1.0) * 2.0;
	vec4 worldPos = matWorld * vec4(itemPos, 1.0);
	gl_Position = matWVP * vec4(itemPos, 1.0);
	texCoord = inTexCoord / 32768.0;

	int faceNormalIndex = int(clamp(floor(inPosition.w / 16.0), 0.0, 14.0));
	vec3 worldNormal = normalize(mat3(matWorld) * kFaceNormals[faceNormalIndex]);
	float rawSky = clamp(extraColor.a, 0.0, 1.0); // 天空亮度 skyBrightness
	float skyCurve = clamp(terrainLightingParams.x, 0.0, 10.0);
	// 天空响应：与 Terrain 同一曲线，把离散天空亮度压成连续权重。
	float skyResponse = rawSky / ((1.0 - rawSky) * skyCurve + 1.0);
	vec3 skyCave = terrainSkyRadiance
		* skyResponse;
	vec3 local = extraColor.rgb + ComputeObjectDynamicLight(worldNormal);
	float wrap = clamp(terrainLightingParams.y, 0.0, 1.0);
	float NdotL = dot(mainLightDir, worldNormal);
	float wrappedDiffuse = NdotL < 0.0 ? 0.0
		: max((NdotL + wrap) / (1.0 + wrap), 0.0);
	float sunGate = smoothstep(0.5 / 15.0, 3.5 / 15.0, rawSky);
	vec3 direct = terrainDirectionalRadiance * wrappedDiffuse * sunGate;

	vec3 lightmapLighting = (skyCave
		+ local) * actorLightStrength;
	vec3 totalRadiance = lightmapLighting + direct * actorLightStrength;
	vec3 outputRadiance = sceneColorOutputParams.x > 0.5
		? max(totalRadiance, vec3(0.0))
		: clamp(totalRadiance, 0.0, 1.0);
	vec3 inputColor = sceneColorOutputParams.x > 0.5
		? GammaToLinear(inColor.rgb) : inColor.rgb;
	lightColor.xyz = inputColor * outputRadiance;
	lightColor.w = ComputeFog(worldPos.xyz - cameraPos, fogParam.xyz);
}
