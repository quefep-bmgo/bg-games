#version 300 es
/// 文件：lighting_v2_csm_shadow_depth.vs
/// 用途：Terrain 方块 CSM caster。只把世界坐标变到光源裁剪空间，不算光照。
/// Catalog：CSM_Shadow_Block
/// 特征：Unlit / DepthOnly
/// 顶点 ABI：4B shadow VBO，inPosition=(PX,PY,PZ,MergeIndex)
/// CSM Shadow Depth Vertex Shader (Terrain Blocks)
/// 仅负责将方块世界坐标变换到光源裁剪空间，不计算任何光照。
/// matWVP 在阴影 Pass 期间被设置为 lightViewProj 矩阵。
/// 使用 4B shadow VBO：inPosition = (PX, PY, PZ, MergeIndex)

in vec4 inPosition;     // .xyz = 方块本地坐标(0-240, /15 还原), .w = slotIndex(0..7) = (sx&1)|((sy&1)<<1)|((sz&1)<<2)

uniform mat4 matWVP;       // Shadow Pass 期间 = lightViewProj
// 合批下同 cell（2×2×2 sections = 32×32×32 blocks）共享单个 cell 原点，
// 各 section 的 sectionPos 由 slotIndex 位解码 secOff = (slot.bit0,bit1,bit2)*16 还原。
uniform vec4 cellOrigin;

void main(void)
{
    // 还原方块本地坐标（与 g1048_solid_block.vs 一致）
    vec3 blockPos = inPosition.xyz / 15.0;

    // 从 slotIndex 解码 section 在 cell 内的偏移（0..7 → (0/1, 0/1, 0/1) * 16）
    int slot = int(inPosition.w);
    vec3 secOff = vec3(float(slot & 1), float((slot >> 1) & 1), float((slot >> 2) & 1)) * 16.0;
    blockPos = cellOrigin.xyz + secOff + blockPos;

    gl_Position = matWVP * vec4(blockPos, 1.0);
}
