#version 300 es
/// 文件：lighting_v2_tesselator_sun.vs
/// 用途：太阳广告牌顶点。可选把深度推到远平面，避免挡住天空盒。
/// Catalog：Tess_Sun
/// 特征：Unlit。forceFarDepth=1 时 z=w。

in vec3 inPosition;
in vec2 inTexCoord;

uniform mat4 matWorld;
uniform mat4 matWVP;
uniform mediump float forceFarDepth; // 1=推到远平面，0=保留真实深度

out vec2 texCoord;

void main(void)
{
	vec4 worldPos = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * worldPos;
	gl_Position.z = mix(gl_Position.z, gl_Position.w, forceFarDepth);
	
	texCoord = inTexCoord;
}



