#version 300 es
/// 文件：lighting_v2_mesh_edge.vs
/// 用途：静态网格描边：沿屏幕空间法线外扩固定像素，避免透视下粗细不均。
/// Catalog：StaticMeshForActorEdge
/// 特征：LinearSceneAware / Unlit。像素着色走 lighting_v2_edge.ps。

in vec3 inPosition;
in vec3 inNormal;

uniform mat4 matWVP;
uniform float edgeWidth;
uniform vec2 viewportSize;

const float EDGE_PIXEL_WIDTH = 2.0;
const float EDGE_DIR_EPSILON = 0.00001;

void main(void)
{
    // 沿 NDC 法线方向外扩 EDGE_PIXEL_WIDTH*edgeWidth 个像素，再乘 w 回到 clip。
    vec4 baseClip = matWVP * vec4(inPosition, 1.0);
    vec4 normalClip = matWVP * vec4(inPosition + normalize(inNormal), 1.0);
    vec2 baseNdc = baseClip.xy / max(abs(baseClip.w), EDGE_DIR_EPSILON);
    vec2 normalNdc = normalClip.xy / max(abs(normalClip.w), EDGE_DIR_EPSILON);
    vec2 screenDir = normalNdc - baseNdc;
    float dirLen = length(screenDir);
    vec2 pixelToNdc = vec2(2.0 / max(viewportSize.x, 1.0), 2.0 / max(viewportSize.y, 1.0));
    if (dirLen > EDGE_DIR_EPSILON)
    {
        baseClip.xy += screenDir / dirLen * EDGE_PIXEL_WIDTH * edgeWidth * pixelToNdc * baseClip.w;
    }
    gl_Position = baseClip;
}
