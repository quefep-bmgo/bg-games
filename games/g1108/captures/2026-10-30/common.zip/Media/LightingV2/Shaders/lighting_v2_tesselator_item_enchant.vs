#version 300 es
/// 文件：lighting_v2_tesselator_item_enchant.vs
/// 用途：物品附魔顶点。VertexLit 与 mcItem 相同，额外输出两套滚动 UV。
/// Catalog：mcItemEnchant
/// 特征：VertexLit + ObjectUniform + Shadow None。
/// 顶点 ABI：同 mcItem；（packed/127-1）*2；inPosition.w 高位只供 legacyFaceBrightness。

in vec4 inPosition;
in vec2 inTexCoord;
in vec4 inColor; // rgb=顶点 tint

uniform mat4 matWVP;
uniform mat4 matWorld;
uniform mat4 matTexture1; // 附魔层 1 滚动矩阵
uniform mat4 matTexture2; // 附魔层 2 滚动矩阵

uniform vec4 fogParam; // xyz=fogStart/fogEnd/density
uniform vec3 cameraPos;
uniform vec4 extraColor; // rgb=VertexLit 方向无关辐照

out vec4 lightColor; // rgb=已点亮色（作者空间），w=雾可见度
out vec2 texCoord1;
out vec2 texCoord2;

// 线性雾可见度：1=无雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	vec3 blockPos = (inPosition.xyz / 127.0 - 1.0) * 2.0;
	vec4 vWorldPos = matWorld * vec4(blockPos, 1.0);
	gl_Position = matWVP * vec4(blockPos, 1.0);

	vec4 vTexture, vEnchantTex;
	vTexture.xy = inTexCoord / 32768.0;
	vTexture.z = 1.0;
	vTexture.w = 1.0;
	vEnchantTex = matTexture1 * vTexture;
	texCoord1 = vEnchantTex.xy;
	vEnchantTex = matTexture2 * vTexture;
	texCoord2 = vEnchantTex.xy;

	// 与 mcItem 相同：无可靠法线，只用 VertexLit × 美术面明暗。
	float faceNormalIndex = floor(inPosition.w / 16.0);
	float frontOrBack = step(3.5, faceNormalIndex) * step(faceNormalIndex, 5.5);
	float legacyFaceBrightness = mix(1.0, 0.7, frontOrBack);
	lightColor.xyz = inColor.rgb * extraColor.rgb * legacyFaceBrightness;
	lightColor.w = ComputeFog(vWorldPos.xyz - cameraPos, fogParam.xyz);
}
