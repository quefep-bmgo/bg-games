#version 300 es
/// 文件：lighting_v2_mesh_normal_debug.vs
/// 用途：静态网格法线调试顶点：世界法线 ×0.5+0.5 编码成颜色。
/// Catalog：StaticMeshForActorNormalDebug
/// 特征：LinearSceneAware / Unlit。

in vec3 inPosition;
in vec3 inNormal;

uniform mat4 matWorld;
uniform mat4 matWVP;

out mediump vec3 normalColor;

void main(void)
{
    gl_Position = matWVP * vec4(inPosition, 1.0);
    // 只用 mat3 去平移，避免法线被位移污染。
    vec3 worldNormal = normalize(mat3(matWorld) * inNormal);
    // [-1,1] 法线编成 [0,1] 色，便于直接看朝向。
    normalColor = worldNormal * 0.5 + 0.5;
}
