#version 300 es
/// 文件：lighting_v2_tesselator_skin_writez.vs
/// 用途：蒙皮角色 CSM caster 深度顶点。单骨、mcSkined 格式。
/// Catalog：CSM_Shadow_Skin
/// 特征：Unlit / DepthOnly。CSM 只调太阳直射；本文件是 caster 写深度，不计算光照。
/// 顶点 ABI：同 skin；（packed/127-1）*8；inColor.a=骨骼索引。

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec2 inTexCoord;
in vec4 inColor;    // a=骨骼索引

uniform mat4 matWVP;
uniform mat4 matWorld;
uniform vec4 fogParam;
uniform vec3 cameraPos;
uniform vec4 extraColor;
uniform vec4 boneMatRows[3*MAX_BONE_NUM]; // 每骨 3 行 vec4

out vec4 lightColor; // 深度 pass 占位，保持与 shadow FS 接口一致
out vec2 texCoord;
out vec3 v_worldPos; // 世界坐标，供 CSM 深度/偏差

// 位置：乘完整 3×4，caster 必须与主 pass 同一蒙皮。
vec3 MulBone4(vec4 vInputPos, int nMatrix)
{
    vec3 vResult;
    vResult.x = dot(vInputPos, boneMatRows[(3*nMatrix)+0].xyzw);
    vResult.y = dot(vInputPos, boneMatRows[(3*nMatrix)+1].xyzw);
    vResult.z = dot(vInputPos, boneMatRows[(3*nMatrix)+2].xyzw);
    return vResult;
}

void main(void)
{
    vec3 blockPos = (inPosition.xyz / 127.0 - 1.0) * 8.0;
    texCoord = inTexCoord / 32768.0;
    int BoneIndices = int(inColor.a);
    vec3 vPos = MulBone4(vec4(blockPos, 1.0), BoneIndices);
    gl_Position = matWVP * vec4(vPos, 1.0);
    lightColor = vec4(1.0);
    v_worldPos = (matWorld * vec4(vPos, 1.0)).xyz;
}
