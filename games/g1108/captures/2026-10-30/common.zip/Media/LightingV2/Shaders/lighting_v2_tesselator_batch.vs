#version 300 es
/// 文件：lighting_v2_tesselator_batch.vs
/// 用途：皮肤/合批网格顶点。世界坐标已解包，只做 WVP、UV 透传和线性距离雾。
/// Catalog：mcBatch
/// 特征：VertexLit_VertexPacked；PS 走 lighting_v2_tesselator_skin.ps
/// 顶点 ABI：inPosition 已是世界坐标；inColor.xyz 直接当顶点色

in vec3 inPosition;                  // 已是世界坐标，不再 /15
in vec2 inTexCoord;
in vec4 inColor;                     // rgb=顶点色

uniform mat4 matWVP;
uniform vec4 fogParam;               // 线性距离雾：x=起点，y=终点，z=密度
uniform vec3 cameraPos;

out vec4 lightColor;                 // rgb=顶点色，w=雾可见度
out vec2 texCoord;

// 线性距离雾可见度；合批网格仍用旧 fogParam.xyz 三段式。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	gl_Position = matWVP * vec4(inPosition, 1.0);

	texCoord = inTexCoord;
	lightColor.xyz = inColor.xyz;
	lightColor.w = ComputeFog(inPosition - cameraPos, fogParam.xyz);
}


