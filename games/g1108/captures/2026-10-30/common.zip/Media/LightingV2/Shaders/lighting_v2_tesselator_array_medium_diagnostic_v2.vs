#version 300 es
/// 文件：lighting_v2_tesselator_array_medium_diagnostic_v2.vs
/// 用途：Medium LDR Array 诊断顶点入口。空 section 可把顶点裁到屏外。
/// Catalog：Tess_Solid_No_Alpha_Test_Array_NoLocal_Medium_Diagnostic_v2
/// 宏：BM_TERRAIN_MEDIUM_LDR + BM_TERRAIN_FOG_DISABLED + BM_TERRAIN_DIAGNOSTIC_VS
/// Include：lighting_v2_tesselator_array_v2.glslinc

#define BM_TERRAIN_MEDIUM_LDR 1
#define BM_TERRAIN_FOG_DISABLED 1
#define BM_TERRAIN_DIAGNOSTIC_VS 1
#include "lighting_v2_tesselator_array_v2.glslinc"
