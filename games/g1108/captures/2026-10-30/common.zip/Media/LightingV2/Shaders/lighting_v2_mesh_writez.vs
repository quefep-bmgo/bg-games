#version 300 es
/// 文件：lighting_v2_mesh_writez.vs
/// 用途：静态 Actor 深度预写 / CSM caster 共用顶点入口。只做 WVP，不算光照。
/// Catalog：CSM_Shadow_StaticActor、CSM_Shadow_StaticActorAlphaMask
/// 特征：Unlit / DepthOnly
/// 顶点 ABI：与 mesh_high 相同，保留 inNormal/inTexCoord 以免优化器拆掉绑定。

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec2 inTexCoord;

uniform mat4 matWVP;                  // 主场景 WriteZ=相机 VP；CSM Pass=lightViewProj

out vec3 tempValue;                   // 极小引用，防止属性被裁掉
out mediump vec2 texCoord;            // AlphaMask caster 需要 UV

void main(void)
{
	// 保留属性引用防止优化器裁掉顶点元素绑定
	tempValue = inNormal * 0.000001;
	tempValue.xy += inTexCoord * 0.000001;
	texCoord = inTexCoord;

	gl_Position = matWVP * vec4(inPosition, 1.0);
}
