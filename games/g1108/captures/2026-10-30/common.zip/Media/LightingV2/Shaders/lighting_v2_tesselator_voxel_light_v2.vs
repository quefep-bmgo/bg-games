#version 300 es
/// 文件：lighting_v2_tesselator_voxel_light_v2.vs
/// 用途：非 Array 顶点路径。相对 v2.vs，动态灯额外乘体素遮挡图集可见度。
/// Catalog：Tess_Solid_VoxelLight_v2 / Tess_Solid_Anim_VoxelLight_v2 / Tess_UV_Anim_VoxelLight_v2 等
/// 特征：VoxelAtlas；voxelTessMode 复用 anim/uv/uv_hr 的 UV 动画
/// 顶点 ABI：同 lighting_v2_tesselator_v2.vs
/// voxelTessMode：1=uvOffset，2=uvRotation，3=uvTime，4=uvTime 且 Y 不 /15

layout(std140) uniform BMWorldLightingBlockV1
{
	highp vec3 mainLightDir;                    // 主光方向
	highp vec3 terrainDirectionalRadiance;      // 太阳直射辐照
	highp vec3 terrainSkyRadiance;         // 天空环境辐照
	highp vec4 terrainLightingParams;           // x=天空曲线，y=wrap
	highp vec4 terrainCartoonParams;            // 卡通色度增益
	highp vec4 localLightParams;                // x=放置方块光
	highp vec4 dynamicTerrainLightPosRadius[4]; // xyz=动态灯世界坐标，w=半径
	highp vec4 dynamicTerrainLightColorStrength[4]; // rgb=颜色，w=强度
	highp vec4 dynamicTerrainLightProfileParams[4]; // x=源半径，y=距离指数，z=响应指数，w>0.5 开体素遮挡
};

#define terrainCartoonSunDirectStrength terrainCartoonParams.x          // 卡通太阳直射色度增益
#define terrainCartoonSkyIndirectStrength terrainCartoonParams.y        // 卡通天空间接色度增益
#define terrainCartoonBrightHighlightAttenuation terrainCartoonParams.z // 高亮近白面直射衰减
#define dynamicTerrainLight0PosRadius dynamicTerrainLightPosRadius[0]
#define dynamicTerrainLight0ColorStrength dynamicTerrainLightColorStrength[0]
#define dynamicTerrainLight0ProfileParams dynamicTerrainLightProfileParams[0]
#define placedBlockLightStrength localLightParams.x                     // 静态放置方块光缩放

in vec4 inPosition;                  // .xyz=/15 格点（mode 4 时 Y 已是世界单位）；.w 自发光+faceNormal 索引
in vec2 inTexCoord;                  // 图集 UV，/32768
in vec4 inTexCoord1;                 // .x=skyLevel*16+aoLevel；.yzw=RGB8 静态辐照
in vec4 inColor;                     // rgb=染色；.w=sectionIndex(3)+材质变体(4)

uniform mat4 matWVP;
uniform vec4 cellOrigin;             // 2×2×2 section 合批的 cell 原点
uniform vec4 fogParam;               // x=起雾距离，z=密度，w=高度雾
uniform highp vec4 sceneColorOutputParams; // .x>0.5 = 线性 HDR 场景色
uniform vec3 cameraPos;
uniform vec2 uvOffset;               // mode 1/2
uniform vec4 uvRotation;             // mode 2：2x2
uniform vec4 uvTime;                 // mode 3/4：xy*zw 滚动
uniform int voxelTessMode;           // 1=平移 2=旋转 3=滚动 4=滚动+HR Y

const int BM_MAX_DYNAMIC_TERRAIN_LIGHTS = 4;
const float BM_VOXEL_VOLUME_DIM = 33.0;   // 体素体积边长
const float BM_VOXEL_ATLAS_SIZE = 198.0;  // 6×33 摊平后的图集边
const float BM_VOXEL_ATLAS_TILES = 6.0;   // Z 切成 6 列 tile
uniform highp vec4 dynamicTerrainVoxelLightOrigins[BM_MAX_DYNAMIC_TERRAIN_LIGHTS]; // xyz=体积原点，w=有效
uniform highp sampler2D texSampler_dynamicTerrainVoxelLight; // 体素遮挡图集，RGBA=4 slot

out vec4 lightColor;                 // rgb=染色，w=雾可见度
out vec4 lightmapUV;                 // x=skyBrightness，yzw=局部光（含体素遮挡后的动态灯）
out vec2 texCoord_texture;
out float lightStrength;             // 材质自发光 0~1
out float ambientOcclusion;          // 线性 AO
#ifdef BM_SHADOW_MODE_CSM
out vec3 v_worldPos;                 // CSM 只调太阳直射
#endif
flat out vec4 v_faceNormal;          // xyz=量化面法线，w=surfaceClass

// 15 个量化面法线：6 轴对齐 + 8 对角 + 兜底上向。
const float kInvSqrt2 = 0.70710678118;
const vec3 kFaceNormals[15] = vec3[15](
	vec3( 1.0,       0.0,       0.0),
	vec3(-1.0,       0.0,       0.0),
	vec3( 0.0,       1.0,       0.0),
	vec3( 0.0,      -1.0,       0.0),
	vec3( 0.0,       0.0,       1.0),
	vec3( 0.0,       0.0,      -1.0),
	vec3( kInvSqrt2, 0.0,       kInvSqrt2),
	vec3( kInvSqrt2, 0.0,      -kInvSqrt2),
	vec3(-kInvSqrt2, 0.0,       kInvSqrt2),
	vec3(-kInvSqrt2, 0.0,      -kInvSqrt2),
	vec3( kInvSqrt2, kInvSqrt2, 0.0),
	vec3(-kInvSqrt2, kInvSqrt2, 0.0),
	vec3( 0.0,       kInvSqrt2, kInvSqrt2),
	vec3( 0.0,       kInvSqrt2,-kInvSqrt2),
	vec3( 0.0,       1.0,       0.0)
);

// 距离雾 + 高度雾，返回可见度（1=无雾）。
float ComputeFog(vec3 worldPos, vec3 camToWorldPos, vec4 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float d = fdist * param.z;
	float distFog = 1.0 - exp(-d * d);
	float heightFog = 0.0;
	if (param.w > 0.0)
		heightFog = clamp(1.0 - worldPos.y * param.w, 0.0, 0.5);
	return 1.0 - clamp(distFog + heightFog * (1.0 - distFog), 0.0, 1.0);
}
// 体素遮挡图集：33³ 体积摊到 6×6 tile 的 198² RGBA，每 slot 占一个通道。
// 面落在格线上时，沿面法线采外侧空气格，避免采到面内侧体素。
// 体积外或 origin 无效时可见度=1（不挡）。
highp float SampleVoxelVisibility(highp vec3 worldPos, highp vec3 faceNormal, int slot)
{
	highp vec4 originValid = dynamicTerrainVoxelLightOrigins[slot];
	if (originValid.w < 0.5)
		return 1.0;

	highp vec3 sampleCell = floor(worldPos + faceNormal * 0.01);
	highp vec3 local = sampleCell - originValid.xyz;
	if (any(lessThan(local, vec3(0.0))) || any(greaterThanEqual(local, vec3(BM_VOXEL_VOLUME_DIM))))
		return 1.0;

	int localZ = int(local.z);
	int tileX = localZ % 6;
	int tileY = localZ / 6;
	highp vec2 texel = vec2(float(tileX) * BM_VOXEL_VOLUME_DIM + local.x,
		float(tileY) * BM_VOXEL_VOLUME_DIM + local.y);
	highp vec4 packed = texture(texSampler_dynamicTerrainVoxelLight, (texel + vec2(0.5)) / BM_VOXEL_ATLAS_SIZE);
	return slot == 0 ? packed.r : (slot == 1 ? packed.g : (slot == 2 ? packed.b : packed.a));
}

// 解析衰减 * 体素可见度。profile.w>0.5 才采样图集。
highp vec3 ApplyDynamicTerrainLight(highp vec3 dynLight, highp vec3 worldPos, highp vec3 faceNormal,
	highp vec4 posRadius, highp vec4 colorStrength, highp vec4 profileParams, int slot)
{
	highp float radius = posRadius.w;
	highp float strength = colorStrength.w;
	if (radius <= 0.001 || strength <= 0.001)
		return dynLight;

	highp vec3 lightDelta = posRadius.xyz - worldPos;
	highp float lightDistance = length(lightDelta);
	highp float sourceRadius = clamp(profileParams.x, 0.0, max(radius - 0.001, 0.0));
	highp float dist01 = clamp(max(lightDistance - sourceRadius, 0.0)
		/ max(radius - sourceRadius, 0.001), 0.0, 1.0);
	highp float distanceExponent = clamp(profileParams.y, 0.5, 8.0);
	highp float responseExponent = clamp(profileParams.z, 0.5, 8.0);
	highp float distancePower;
	if (abs(distanceExponent - 2.0) < 0.001) distancePower = dist01 * dist01;
	else if (abs(distanceExponent - 1.0) < 0.001) distancePower = dist01;
	else distancePower = pow(dist01, distanceExponent);
	highp float base = max(0.0, 1.0 - distancePower);
	highp float atten;
	if (abs(responseExponent - 1.0) < 0.001) atten = base;
	else if (abs(responseExponent - 2.0) < 0.001) atten = base * base;
	else atten = pow(base, responseExponent);
	highp float visibility = profileParams.w > 0.5
		? SampleVoxelVisibility(worldPos, faceNormal, slot) : 1.0;
	return dynLight + colorStrength.rgb * (atten * visibility * strength);
}

highp vec3 ComputeDynamicTerrainLights(highp vec3 worldPos, highp vec3 faceNormal)
{
	highp vec3 dynLight = ApplyDynamicTerrainLight(vec3(0.0), worldPos, faceNormal,
		dynamicTerrainLight0PosRadius, dynamicTerrainLight0ColorStrength,
		dynamicTerrainLight0ProfileParams, 0);
	for (int i = 1; i < BM_MAX_DYNAMIC_TERRAIN_LIGHTS; ++i)
		dynLight = ApplyDynamicTerrainLight(dynLight, worldPos, faceNormal,
			dynamicTerrainLightPosRadius[i], dynamicTerrainLightColorStrength[i],
			dynamicTerrainLightProfileParams[i], i);
	return dynLight;
}

void main(void)
{
	vec3 blockPos = inPosition.xyz / 15.0;
	// mode 4 = UV_HR：Y 已是世界单位，避免高柱竖向量化台阶。
	if (voxelTessMode == 4)
		blockPos.y = inPosition.y;
	// inColor.w：section(3) | 材质变体(4)。非 Array 不读 greedy 位。
	int packedTerrainMeta = int(floor(inColor.w + 0.5));
	int sectionIndex = packedTerrainMeta & 7;
	int terrainMaterialVariant = (packedTerrainMeta >> 3) & 15;
	// 变体→surfaceClass：1/4/5→1，2/6→2（微量 sheen），其余 0。写入 v_faceNormal.w。
	float terrainSurfaceClass = (terrainMaterialVariant == 1
		|| terrainMaterialVariant == 4 || terrainMaterialVariant == 5) ? 1.0
		: ((terrainMaterialVariant == 2 || terrainMaterialVariant == 6) ? 2.0 : 0.0);
	vec3 sectionOffset = vec3(float(sectionIndex & 1),
		float((sectionIndex >> 1) & 1), float((sectionIndex >> 2) & 1)) * 16.0;
	blockPos += cellOrigin.xyz + sectionOffset;
	gl_Position = matWVP * vec4(blockPos, 1.0);

	texCoord_texture = inTexCoord / 32768.0;
	// 一套 VS 复用 anim/uv/uv_hr：只改 UV，不改光照打包。
	if (voxelTessMode == 1)
		texCoord_texture += uvOffset;
	else if (voxelTessMode == 2)
	{
		texCoord_texture -= uvOffset;
		texCoord_texture = texCoord_texture * mat2(uvRotation.x, uvRotation.y, uvRotation.z, uvRotation.w);
		texCoord_texture += uvOffset;
	}
	else if (voxelTessMode == 3 || voxelTessMode == 4)
		texCoord_texture += vec2(uvTime.xy * uvTime.zw);

	float packedSkyAo = floor(inTexCoord1.x + 0.5);
	float skyLevel = floor(packedSkyAo / 16.0);
	float aoLevel = mod(packedSkyAo, 16.0);
	// 量化 AO 保持线性，避免窄投影边塌成黑线。
	ambientOcclusion = clamp(1.0 - aoLevel / 15.0, 0.0, 1.0);
	float rawW = inPosition.w;
	lightStrength = mod(rawW, 16.0) / 15.0;
	float faceNormalIdx = floor(rawW / 16.0);
	v_faceNormal = vec4((faceNormalIdx < 14.5)
		? kFaceNormals[int(faceNormalIdx)] : vec3(0.0, 1.0, 0.0),
		terrainSurfaceClass);
	vec3 dynamicFaceNormal = (faceNormalIdx < 14.5) ? v_faceNormal.xyz : vec3(0.0);
	// 静态放置方块光乘 AO；动态灯走体素遮挡图集，不乘 AO。
	lightmapUV = vec4(skyLevel / 15.0,
		inTexCoord1.yzw / 255.0 * 1.5 * placedBlockLightStrength * ambientOcclusion);
	lightmapUV.yzw += ComputeDynamicTerrainLights(blockPos, dynamicFaceNormal);
	lightColor.w = ComputeFog(blockPos, blockPos - cameraPos, fogParam);

	vec3 legacyTint = inColor.rgb / 255.0;
	// sceneColorOutputParams.x>0.5 = 线性 HDR 场景色
	lightColor.xyz = sceneColorOutputParams.x > 0.5
		? pow(max(legacyTint, vec3(0.0)), vec3(2.2)) : legacyTint;
#ifdef BM_SHADOW_MODE_CSM
	v_worldPos = blockPos;
#endif
}
