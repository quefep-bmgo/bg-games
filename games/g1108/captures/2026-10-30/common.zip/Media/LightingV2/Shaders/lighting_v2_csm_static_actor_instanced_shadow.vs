#version 300 es
/// Static Actor instanced CSM depth entry. The pass only transforms vertices.

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec2 inTexCoord;

uniform mat4 instanceWVP[48];

out vec3 tempValue;
out mediump vec2 texCoord;

void main(void)
{
	// Keep these attributes active so the static Actor mesh vertex layout remains valid.
	tempValue = inNormal * 0.000001;
	tempValue.xy += inTexCoord * 0.000001;
	texCoord = inTexCoord;

	gl_Position = instanceWVP[gl_InstanceID] * vec4(inPosition, 1.0);
}
