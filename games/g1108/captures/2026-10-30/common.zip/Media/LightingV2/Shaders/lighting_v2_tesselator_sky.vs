#version 300 es
/// 文件：lighting_v2_tesselator_sky.vs
/// 用途：旧 2D/穹顶天空顶点。推到远平面，并算指数平方雾 + 可选地平线压暗。
/// Catalog：Tess_Sky
/// 特征：Unlit。z=w 保证天空永远在最后。

in vec3 inPosition;

uniform mat4 matWorld;
uniform mat4 matWVP;
uniform vec4 fogParam[3]; // [0]=fogStart/End/expDensity/地平线权重，[1]=雾色，[2].xyz=相机

out vec4 oFogColor; // rgb=雾色，a=雾可见度

// 天空雾：指数平方距离雾；param.w>0 时再按仰角压低地平线，避免远地平发白。
float ComputeSkyFog(vec3 worldPos, vec3 cameraPos, vec4 param)
{
	vec3 camToWorld = worldPos - cameraPos;
	float fdist = max(length(camToWorld) - param.x, 0.0);
	float d = fdist * param.z;
	float fogFactor = exp(-d * d);
	if (param.w > 0.0)
	{
		float elevationY = clamp(normalize(camToWorld).y, 0.0, 1.0);
		float horizonReduction = (1.0 - elevationY) * (1.0 - elevationY) * param.w * 0.4;
		fogFactor = max(0.0, fogFactor - horizonReduction);
	}
	return fogFactor;
}

void main(void)
{
	vec4 worldPos = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * worldPos;
	gl_Position.z = gl_Position.w;
	float fogFactor = ComputeSkyFog(worldPos.xyz, fogParam[2].xyz, fogParam[0]);
	oFogColor = vec4(fogParam[1].rgb, fogFactor);
}

