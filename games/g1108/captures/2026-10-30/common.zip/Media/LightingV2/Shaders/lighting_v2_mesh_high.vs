#version 300 es
/// 文件：lighting_v2_mesh_high.vs
/// 用途：静态 Actor Lambert 顶点。对象 Probe + Top-K 局部光，CSM 只调太阳直射。
/// Catalog：StaticMeshForActorHigh、StaticMeshForActorTextureAlphaMask、
///          StaticMeshForActorTransparent、StaticMeshForActorTextureAlphaBlend、
///          StaticMeshForActorTextureAlphaMaskTransparent
/// 特征：Lambert / ObjectUniform / CSM / Analytic / LinearSceneAware
/// 顶点 ABI：世界法线可靠；lightingProbe 由 CPU 双点平均后上传，不是顶点 packed。

in vec3 inPosition;
in vec3 inNormal;
in vec2 inTexCoord;

uniform mat4 matWorld;
uniform mat4 matWVP;

uniform vec4 fogParam;                // xyz=start/end/density
uniform vec3 cameraPos;
uniform vec3 mainLightDir;
uniform vec3 terrainDirectionalRadiance; // 同帧太阳直射，已含天气
uniform vec3 terrainSkyRadiance;
uniform vec4 terrainLightingParams;   // x=天空响应曲线，y=wrap
uniform float sunIndirectFillStrength; // 与地形共用的太阳间接补偿；普通 UI 为 0
uniform highp vec4 sceneColorOutputParams; // .x>0.5=线性 HDR，.z=全局昼间强度
// x=raw sky brightness, yzw=static local irradiance.
// x=天空亮度，yzw=静态局部光（放置方块光，已解码）
uniform vec4 lightingProbe;
const int BM_MAX_OBJECT_DYNAMIC_LIGHTS = 4;
uniform highp vec4 objectDynamicLightDirectionWeight[BM_MAX_OBJECT_DYNAMIC_LIGHTS]; // xyz=方向，w=是否按法线
uniform highp vec4 objectDynamicLightIrradiance[BM_MAX_OBJECT_DYNAMIC_LIGHTS];

uniform float actorLightStrength;     // 对象接收倍率

out vec4 lightColor;                  // rgb=未阴影总辐照，w=雾可见度
out vec2 texCoord;
out mediump vec3 v_mainDirectional;   // 可被 CSM 遮挡的太阳余量
out mediump vec3 v_unshadowableBase;  // 天空+静态/动态局部光+太阳间接补偿
out highp vec3 v_worldPos;
flat out mediump float v_shadowBiasScale;

// 线性距离雾可见度：density<=0 直接返回 1。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	if (param.z <= 0.0)
		return 1.0;
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

// 对象 Top-K 局部光。w=0 时方向无关（无可靠法线兜底），否则 Lambert。
highp vec3 ComputeObjectDynamicLight(highp vec3 worldNormal)
{
	highp vec3 result = vec3(0.0);
	for (int i = 0; i < BM_MAX_OBJECT_DYNAMIC_LIGHTS; ++i)
	{
		if (max(max(objectDynamicLightIrradiance[i].r,
			objectDynamicLightIrradiance[i].g),
			objectDynamicLightIrradiance[i].b) <= 0.0)
			continue;
		highp float diffuse = mix(1.0,
			max(dot(worldNormal, objectDynamicLightDirectionWeight[i].xyz), 0.0),
			objectDynamicLightDirectionWeight[i].w);
		result += objectDynamicLightIrradiance[i].rgb * diffuse;
	}
	return result;
}

void main(void)
{
	vec4 vWorldPos = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * vec4(inPosition, 1.0);
		
	texCoord = inTexCoord;
	
	vec3 vNorm = normalize(mat3(matWorld) * inNormal);
	
	float rawSky = clamp(lightingProbe.x, 0.0, 1.0);
	float skyCurve = clamp(terrainLightingParams.x, 0.0, 10.0);
	// 天空响应：与 Terrain 同曲线，低天空亮度被压暗。
	float skyResponse = rawSky / ((1.0 - rawSky) * skyCurve + 1.0);
	vec3 skyIndirect = terrainSkyRadiance
		* skyResponse;
	float wrap = clamp(terrainLightingParams.y, 0.0, 1.0);
	float geometricNdotL = dot(mainLightDir, vNorm);
	float wrappedDiffuse = geometricNdotL < 0.0 ? 0.0
		: max((geometricNdotL + wrap) / (1.0 + wrap), 0.0);
	float sunGate = smoothstep(0.5 / 15.0, 3.5 / 15.0, rawSky);
	float sunActive = step(0.0001, max(max(terrainDirectionalRadiance.r,
		terrainDirectionalRadiance.g), terrainDirectionalRadiance.b));

	float sunFill = clamp(sunIndirectFillStrength, 0.0, 1.0) * skyResponse;
	vec3 sunRadiance = terrainDirectionalRadiance
		* sunGate * sunActive * actorLightStrength;
	// PS 仍遮挡太阳余量：f + r*s*(1-f) = r*s + (1-r*s)*f。
	v_mainDirectional = sunRadiance * wrappedDiffuse * (1.0 - sunFill);
	vec3 localTerm = lightingProbe.yzw + ComputeObjectDynamicLight(vNorm);
	v_unshadowableBase = (skyIndirect + localTerm) * actorLightStrength
		+ sunRadiance * sunFill;
	vec3 totalRadiance = v_unshadowableBase + v_mainDirectional;
	lightColor.rgb = sceneColorOutputParams.x > 0.5
		? max(totalRadiance, vec3(0.0))
		: clamp(totalRadiance, 0.0, 1.0);
	lightColor.w = ComputeFog(vWorldPos.xyz - cameraPos, fogParam.xyz);
	v_worldPos = vWorldPos.xyz;
	mediump vec3 shadowNormalInput = vNorm;
	mediump vec3 shadowNormal = normalize(shadowNormalInput);
	mediump float shadowNdotL = dot(shadowNormal, mainLightDir);
	// 掠射角加大深度 bias，减轻自阴影 acne。
	v_shadowBiasScale = 1.0 + 4.0
		* (1.0 - clamp(shadowNdotL, 0.0, 1.0));
}
