#version 300 es
/// 文件：lighting_v2_tesselator_snow.vs
/// 用途：积雪合批顶点。相对 Tess_Fx，顶点光只保留 20%，让雪更跟顶点色走。
/// Catalog：Tess_Snow
/// 特征：VertexLit / LinearSceneAware。lightingDomain>0.5 时不乘顶点光、不做雾。

in highp vec3 inPosition;
in vec4 inColor;
in vec2 inTexCoord;
in vec4 inTexCoord1;

uniform highp mat4 matWVP;
uniform vec4 fogParam;

uniform vec3 cameraPos;
uniform highp vec4 sceneColorOutputParams;
// 0 = world V2 VertexLit color, 1 = view-space unlit domain.
// 0=世界 V2 VertexLit；1=观察空间无光域。
uniform float lightingDomain;

out vec4 lightColor;
out vec2 texCoord_texture;

// 距离雾：低于起点为 1，超过终点按 density 压到 0。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fogRange = param.y - param.x;
	if (fogRange <= 0.0 || param.z <= 0.0)
		return 1.0;
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist / fogRange, 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	gl_Position = matWVP * vec4(inPosition, 1.0);

	texCoord_texture = inTexCoord;
	
	// sceneColorOutputParams.x>0.5 = 线性 HDR 场景色，顶点色要 pow(2.2)。
	vec3 inputColor = sceneColorOutputParams.x > 0.5
		? pow(max(inColor.rgb, vec3(0.0)), vec3(2.2))
		: inColor.rgb;

	// 观察空间无光域：只用顶点色，不做雾。
	if (lightingDomain > 0.5)
	{
		lightColor.xyz = inputColor;
		lightColor.w = 1.0;
		return;
	}

	vec3 vertexLighting = sceneColorOutputParams.x > 0.5
		? pow(max(inTexCoord1.rgb, vec3(0.0)), vec3(2.2))
		: inTexCoord1.rgb;
	// 雪要保自身高反照，顶点光只留 20%。
	lightColor.xyz = mix(vertexLighting * inputColor, inputColor, 0.8);
	lightColor.w = ComputeFog(inPosition - cameraPos, fogParam.xyz);
}
