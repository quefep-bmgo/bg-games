#version 300 es
/// 文件：lighting_v2_tesselator_special_alpha.vs
/// 用途：特殊透明顶点。只还原格点、UV 和顶点色，不算光照。
/// Catalog：Tess_Transparent_Special_Alpha
/// 特征：Unlit / LinearSceneAware
/// 顶点 ABI：inPosition.xyz=/15；inTexCoord/32768；inColor.rgb/255；.w 低 3bit=sectionIndex

in vec4 inPosition;                  // .xyz=/15 格点
in vec2 inTexCoord;                  // 图集 UV，/32768
in vec4 inColor;                     // rgb=8bit 顶点色；.w 低 3bit=sectionIndex

uniform mat4 matWVP;
uniform vec4 cellOrigin;             // 2×2×2 section 合批的 cell 原点

out vec2 texCoord_texture;
out vec3 color;                      // 归一化顶点色

void main(void)
{
	vec3 blockPos;
	blockPos = inPosition.xyz / 15.0;
	
	// output position.
	int sectionIndex = int(floor(inColor.w + 0.5)) & 7;
	vec3 sectionOffset = vec3(float(sectionIndex & 1),
		float((sectionIndex >> 1) & 1), float((sectionIndex >> 2) & 1)) * 16.0;
	blockPos = cellOrigin.xyz + sectionOffset + blockPos;
	gl_Position = matWVP * vec4(blockPos, 1.0);
	texCoord_texture = inTexCoord / 32768.0;
    color = inColor.rgb / 255.0;
}

