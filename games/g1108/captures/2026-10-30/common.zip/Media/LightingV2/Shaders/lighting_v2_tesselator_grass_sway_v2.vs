#version 300 es
/// 文件：lighting_v2_tesselator_grass_sway_v2.vs
/// 用途：在 v2.vs 基础上加草摆动。inPosition.w 低 4bit 改作 swayWeight，自发光强制 0。
/// Catalog：Tess_Solid_GrassSway_v2 / Tess_Solid_GrassSway_Minimal_v2
/// 顶点 ABI：同 v2.vs，但 .w 低 4bit=摆动权重（底=0/顶=1），不再是自发光
/// 雾：仍用旧 fogParam.xyz 线性距离雾。

layout(std140) uniform BMWorldLightingBlockV1
{
	highp vec3 mainLightDir;                    // 主光方向
	highp vec3 terrainDirectionalRadiance;      // 太阳直射辐照
	highp vec3 terrainSkyRadiance;         // 天空环境辐照
	highp vec4 terrainLightingParams;           // x=天空曲线，y=wrap
	highp vec4 terrainCartoonParams;            // 卡通色度增益
	highp vec4 localLightParams;                // x=放置方块光
	highp vec4 dynamicTerrainLightPosRadius[4]; // xyz=动态灯世界坐标，w=半径
	highp vec4 dynamicTerrainLightColorStrength[4]; // rgb=颜色，w=强度
	highp vec4 dynamicTerrainLightProfileParams[4]; // x=源半径，y=距离指数，z=响应指数
};

#define terrainCartoonSunDirectStrength terrainCartoonParams.x          // 卡通太阳直射色度增益
#define terrainCartoonSkyIndirectStrength terrainCartoonParams.y        // 卡通天空间接色度增益
#define terrainCartoonBrightHighlightAttenuation terrainCartoonParams.z // 高亮近白面直射衰减
#define dynamicTerrainLight0PosRadius dynamicTerrainLightPosRadius[0]
#define dynamicTerrainLight0ColorStrength dynamicTerrainLightColorStrength[0]
#define dynamicTerrainLight0ProfileParams dynamicTerrainLightProfileParams[0]
#define placedBlockLightStrength localLightParams.x                     // 静态放置方块光缩放

in vec4 inPosition;                  // .xyz=/15 格点；.w 低 4bit=swayWeight
in vec2 inTexCoord;                  // 图集 UV，/32768
in vec4 inTexCoord1;                 // .x=skyLevel*16+aoLevel；.yzw=RGB8 静态辐照
in vec4 inColor;                     // rgb=染色；.w=sectionIndex(3)+材质变体(4)

uniform mat4 matWVP;
uniform vec4 cellOrigin;             // 2×2×2 section 合批的 cell 原点
uniform vec4 fogParam;               // 线性距离雾：x=起点，y=终点，z=密度
uniform highp vec4 sceneColorOutputParams; // .x>0.5 = 线性 HDR 场景色
uniform vec3 cameraPos;

// Grass sway uniforms
// 草摆动：时间/风向/强度。只改顶点位置，不改光照 ABI。
uniform float grassTime;
uniform vec2  grassWindDir;
uniform float grassWindStrength;
#ifdef BM_LOCAL_LIGHT_ANALYTIC
#ifdef BM_MATERIAL_TIER_MINIMAL
const int BM_MAX_DYNAMIC_TERRAIN_LIGHTS = 1;
#else
const int BM_MAX_DYNAMIC_TERRAIN_LIGHTS = 4;
#endif
#endif

out vec4 lightColor;                 // rgb=染色，w=雾可见度
out vec4 lightmapUV;                 // x=skyBrightness，yzw=局部光
out vec2 texCoord_texture;
out float lightStrength;             // 草路径强制 0：.w 已改作 swayWeight
out float ambientOcclusion;          // 线性 AO
#ifdef BM_SHADOW_MODE_CSM
out vec3 v_worldPos;                 // CSM 只调太阳直射
#endif
flat out vec4 v_faceNormal;          // xyz=草统一上向受光法线，w=surfaceClass

// 线性距离雾可见度；这组动画 VS 仍用旧 fogParam.xyz 三段式，不用高度雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

// Smooth wave functions from engine Grass shader
// 引擎 Grass 的平滑三角波：比 sin 便宜，避免草尖出现折线。
float SmoothCurve(float x)
{
	return x * x * (3.0 - 2.0 * x);
}

float TriangleWave(float x)
{
	return abs(fract(x + 0.5) * 2.0 - 1.0);
}

float SmoothTriangleWave(float x)
{
	return SmoothCurve(TriangleWave(x));
}

#ifdef BM_LOCAL_LIGHT_ANALYTIC
// 顶点动态灯：只按距离衰减，保持与体素地形局部光一致。
highp vec3 ApplyDynamicTerrainLight(highp vec3 dynLight, highp vec3 worldPos, highp vec3 faceNormal,
	highp vec4 posRadius, highp vec4 colorStrength, highp vec4 profileParams)
{
	highp float radius = posRadius.w;
	highp float strength = colorStrength.w;
	if (radius <= 0.001 || strength <= 0.001)
		return dynLight;

	highp vec3 lightDelta = posRadius.xyz - worldPos;
	highp float lightDistance = length(lightDelta);
	highp float sourceRadius = clamp(profileParams.x, 0.0, max(radius - 0.001, 0.0));
	highp float dist01 = clamp(max(lightDistance - sourceRadius, 0.0)
		/ max(radius - sourceRadius, 0.001), 0.0, 1.0);
	highp float distanceExponent = clamp(profileParams.y, 0.5, 8.0);
	highp float responseExponent = clamp(profileParams.z, 0.5, 8.0);
	highp float distancePower;
	if (abs(distanceExponent - 2.0) < 0.001) distancePower = dist01 * dist01;
	else if (abs(distanceExponent - 1.0) < 0.001) distancePower = dist01;
	else distancePower = pow(dist01, distanceExponent);
	highp float base = max(0.0, 1.0 - distancePower);
	highp float atten;
	if (abs(responseExponent - 1.0) < 0.001) atten = base;
	else if (abs(responseExponent - 2.0) < 0.001) atten = base * base;
	else atten = pow(base, responseExponent);
	return dynLight + colorStrength.rgb * (atten * strength);
}

highp vec3 ComputeDynamicTerrainLights(highp vec3 worldPos, highp vec3 faceNormal)
{
	highp vec3 dynLight = vec3(0.0);
	dynLight = ApplyDynamicTerrainLight(dynLight, worldPos, faceNormal, dynamicTerrainLight0PosRadius,
		dynamicTerrainLight0ColorStrength, dynamicTerrainLight0ProfileParams);
	for (int i = 1; i < BM_MAX_DYNAMIC_TERRAIN_LIGHTS; ++i)
	{
		dynLight = ApplyDynamicTerrainLight(dynLight, worldPos, faceNormal, dynamicTerrainLightPosRadius[i],
			dynamicTerrainLightColorStrength[i], dynamicTerrainLightProfileParams[i]);
	}
	return dynLight;
}
#endif

void main(void)
{
	vec3 blockPos;
	blockPos = inPosition.xyz / 15.0;

	// output position.
	// inColor.w：section(3) | 材质变体(4)。非 Array 不读 greedy 位。
	int packedTerrainMeta = int(floor(inColor.w + 0.5));
	int sectionIndex = packedTerrainMeta & 7;
	int terrainMaterialVariant = (packedTerrainMeta >> 3) & 15;
	// 变体→surfaceClass：1/4/5→1，2/6→2（微量 sheen），其余 0。写入 v_faceNormal.w。
	float terrainSurfaceClass = (terrainMaterialVariant == 1
		|| terrainMaterialVariant == 4 || terrainMaterialVariant == 5) ? 1.0
		: ((terrainMaterialVariant == 2 || terrainMaterialVariant == 6) ? 2.0 : 0.0);
	vec3 sectionOffset = vec3(float(sectionIndex & 1),
		float((sectionIndex >> 1) & 1), float((sectionIndex >> 2) & 1)) * 16.0;
	blockPos = cellOrigin.xyz + sectionOffset + blockPos;

	// Sway weight from the w component (0 = bottom/fixed, 1 = top/full sway)
	// .w 低 4bit 是摆动权重：根部固定，梢部满摆。不能再当自发光。
	float rawW = inPosition.w;
	float swayWeight = mod(rawW, 16.0) / 15.0;
	// 交叉草面没有稳定的几何受光方向；统一上向避免同簇面片一明一暗。
	v_faceNormal = vec4(0.0, 1.0, 0.0, terrainSurfaceClass);
	vec3 dynamicFaceNormal = vec3(0.0);

	// Compute wind sway displacement
	// Use world xz coordinates and time to create a spatially varying wave
	// 用世界 xz + 时间做空间相位，避免整片草同步摆。
	float phaseX = blockPos.x * 0.15 + grassTime * 1.8;
	float phaseZ = blockPos.z * 0.15 + grassTime * 1.4;
	float waveX = SmoothTriangleWave(phaseX) * 2.0 - 1.0;
	float waveZ = SmoothTriangleWave(phaseZ) * 2.0 - 1.0;

	// Combine directional wind with local variation
	// 风向 × 局部波，再乘强度。
	float windDisplacement = (grassWindDir.x * waveX + grassWindDir.y * waveZ) * grassWindStrength;

	// Apply sway only to top vertices (swayWeight > 0)
	blockPos.x += grassWindDir.x * windDisplacement * swayWeight;
	blockPos.z += grassWindDir.y * windDisplacement * swayWeight;
	// Slight downward pull when swaying (arc motion)
	// 摆动时略下压，模拟弧线而不是平移。
	blockPos.y -= abs(windDisplacement) * swayWeight * 0.08;

	gl_Position = matWVP * vec4(blockPos, 1.0);

	texCoord_texture = inTexCoord / 32768.0;
	float packedSkyAo = floor(inTexCoord1.x + 0.5);
	float skyLevel = floor(packedSkyAo / 16.0);
	float aoLevel = mod(packedSkyAo, 16.0);
	// 量化 AO 保持线性，避免窄投影边塌成黑线。
	ambientOcclusion = clamp(1.0 - aoLevel / 15.0, 0.0, 1.0);
	// skyBrightness + 静态放置方块光（已乘 AO）；动态灯按摆动后位置算。
	lightmapUV = vec4(skyLevel / 15.0,
		inTexCoord1.yzw / 255.0 * 1.5 * placedBlockLightStrength * ambientOcclusion);
#ifdef BM_LOCAL_LIGHT_ANALYTIC
	lightmapUV.yzw += ComputeDynamicTerrainLights(blockPos, dynamicFaceNormal);
#endif

	// lightStrength is repurposed as swayWeight, set to 0 for fragment shader lighting
	// .w 已改作 swayWeight，PS 自发光通道清零，避免草尖当灯。
	lightStrength = 0.0;

	vec3 legacyTint = inColor.rgb / 255.0;
	// sceneColorOutputParams.x>0.5 = 线性 HDR 场景色
	lightColor.xyz = sceneColorOutputParams.x > 0.5
		? pow(max(legacyTint, vec3(0.0)), vec3(2.2)) : legacyTint;
	lightColor.w = ComputeFog(blockPos - cameraPos, fogParam.xyz);

#ifdef BM_SHADOW_MODE_CSM
	v_worldPos = blockPos;
#endif
}
