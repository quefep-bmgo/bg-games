#version 300 es
/// 文件：lighting_v2_tesselator_v2.vs
/// 用途：Terrain 非 Array 标准顶点着色器。解码 packed 顶点 ABI，输出 sky/AO/静态辐照/雾/面法线。
/// Catalog：Tess_Solid_v2 / Tess_Solid_No_Alpha_Test_v2 / Tess_Transparent_v2 等
/// 特征：Lambert_VertexPacked；CSM 时输出 v_worldPos；Analytic 时叠加动态灯
/// 顶点 ABI：
///   inPosition.xyz=/15 还原格点；.w 低 4bit 自发光，高位 faceNormal 索引
///   inColor.w：sectionIndex(3) + 材质变体(4)；surfaceClass 由变体推导写入 v_faceNormal.w
///   inTexCoord / 32768
///   inTexCoord1.x：skyLevel*16 + aoLevel；.yzw=RGB8 静态辐照（VS 内再 /255 * 1.5 * placedBlockLight * AO）
/// 注意：本文件内联 V1 UBO，未 include bm_terrain_world_lighting_v1.glslinc，字段必须与之 ABI 一致。

layout(std140) uniform BMWorldLightingBlockV1
{
	highp vec3 mainLightDir;                    // 主光方向
	highp vec3 terrainDirectionalRadiance;      // 太阳直射辐照
	highp vec3 terrainSkyRadiance;         // 天空环境辐照
	highp vec4 terrainLightingParams;           // x=天空曲线，y=wrap
	highp vec4 terrainCartoonParams;            // 卡通色度增益
	highp vec4 localLightParams;                // x=放置方块光
	highp vec4 dynamicTerrainLightPosRadius[4]; // xyz=动态灯世界坐标，w=半径
	highp vec4 dynamicTerrainLightColorStrength[4]; // rgb=颜色，w=强度
	highp vec4 dynamicTerrainLightProfileParams[4]; // x=源半径，y=距离指数，z=响应指数
};

#define terrainCartoonSunDirectStrength terrainCartoonParams.x          // 卡通太阳直射色度增益
#define terrainCartoonSkyIndirectStrength terrainCartoonParams.y        // 卡通天空间接色度增益
#define terrainCartoonBrightHighlightAttenuation terrainCartoonParams.z // 高亮近白面直射衰减
#define dynamicTerrainLight0PosRadius dynamicTerrainLightPosRadius[0]
#define dynamicTerrainLight0ColorStrength dynamicTerrainLightColorStrength[0]
#define dynamicTerrainLight0ProfileParams dynamicTerrainLightProfileParams[0]
#define placedBlockLightStrength localLightParams.x                     // 静态放置方块光缩放

in vec4 inPosition;                  // .xyz=/15 格点；.w 低 4bit 自发光，高位 faceNormal 索引
in vec2 inTexCoord;                  // 图集 UV，/32768
in vec4 inTexCoord1;                 // .x=skyLevel*16+aoLevel；.yzw=RGB8 静态辐照
in vec4 inColor;                     // rgb=染色；.w=sectionIndex(3)+材质变体(4)

uniform mat4 matWVP;
uniform vec4 cellOrigin;             // 2×2×2 section 合批的 cell 原点
uniform vec4 fogParam;               // x=起雾距离，z=密度，w=高度雾
uniform highp vec4 sceneColorOutputParams; // .x>0.5 = 线性 HDR 场景色

uniform vec3 cameraPos;
#ifdef BM_LOCAL_LIGHT_ANALYTIC
#ifdef BM_MATERIAL_TIER_MINIMAL
const int BM_MAX_DYNAMIC_TERRAIN_LIGHTS = 1;
#else
const int BM_MAX_DYNAMIC_TERRAIN_LIGHTS = 4;
#endif
#endif

out vec4 lightColor;                 // rgb=染色，w=雾可见度
out vec4 lightmapUV;                 // x=skyBrightness，yzw=局部光
out vec2 texCoord_texture;
out float lightStrength;             // 材质自发光 0~1，不是邻格点光
out float ambientOcclusion;          // 线性 AO
#ifdef BM_SHADOW_MODE_CSM
out vec3 v_worldPos;                 // CSM 只调太阳直射，PS 采样用
#endif
flat out vec4 v_faceNormal;          // xyz=量化面法线，w=surfaceClass

// 15 个量化面法线：6 轴对齐 + 8 对角 + 兜底上向。
const float kInvSqrt2 = 0.70710678118;
const vec3 kFaceNormals[15] = vec3[15](
	vec3( 1.0,       0.0,       0.0),
	vec3(-1.0,       0.0,       0.0),
	vec3( 0.0,       1.0,       0.0),
	vec3( 0.0,      -1.0,       0.0),
	vec3( 0.0,       0.0,       1.0),
	vec3( 0.0,       0.0,      -1.0),
	vec3( kInvSqrt2, 0.0,       kInvSqrt2),
	vec3( kInvSqrt2, 0.0,      -kInvSqrt2),
	vec3(-kInvSqrt2, 0.0,       kInvSqrt2),
	vec3(-kInvSqrt2, 0.0,      -kInvSqrt2),
	vec3( kInvSqrt2, kInvSqrt2, 0.0),
	vec3(-kInvSqrt2, kInvSqrt2, 0.0),
	vec3( 0.0,       kInvSqrt2, kInvSqrt2),
	vec3( 0.0,       kInvSqrt2,-kInvSqrt2),
	vec3( 0.0,       1.0,       0.0)
);

// 距离雾 + 高度雾，返回可见度（1=无雾）。
float ComputeFog(vec3 worldPos, vec3 camToWorldPos, vec4 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float d = fdist * param.z;
	float distFog = 1.0 - exp(-d * d);
	float heightFog = 0.0;
	if (param.w > 0.0)
		heightFog = clamp(1.0 - worldPos.y * param.w, 0.0, 0.5);
	return 1.0 - clamp(distFog + heightFog * (1.0 - distFog), 0.0, 1.0);
}
#ifdef BM_LOCAL_LIGHT_ANALYTIC
// 顶点动态灯：只按距离衰减，保持与体素地形局部光一致。
highp vec3 ApplyDynamicTerrainLight(highp vec3 dynLight, highp vec3 worldPos, highp vec3 faceNormal,
	highp vec4 posRadius, highp vec4 colorStrength, highp vec4 profileParams)
{
	highp float radius = posRadius.w;
	highp float strength = colorStrength.w;
	if (radius <= 0.001 || strength <= 0.001)
		return dynLight;

	highp vec3 lightDelta = posRadius.xyz - worldPos;
	highp float lightDistance = length(lightDelta);
	highp float sourceRadius = clamp(profileParams.x, 0.0, max(radius - 0.001, 0.0));
	highp float dist01 = clamp(max(lightDistance - sourceRadius, 0.0)
		/ max(radius - sourceRadius, 0.001), 0.0, 1.0);
	highp float distanceExponent = clamp(profileParams.y, 0.5, 8.0);
	highp float responseExponent = clamp(profileParams.z, 0.5, 8.0);
	highp float distancePower;
	if (abs(distanceExponent - 2.0) < 0.001) distancePower = dist01 * dist01;
	else if (abs(distanceExponent - 1.0) < 0.001) distancePower = dist01;
	else distancePower = pow(dist01, distanceExponent);
	highp float base = max(0.0, 1.0 - distancePower);
	highp float atten;
	if (abs(responseExponent - 1.0) < 0.001) atten = base;
	else if (abs(responseExponent - 2.0) < 0.001) atten = base * base;
	else atten = pow(base, responseExponent);
	return dynLight + colorStrength.rgb * (atten * strength);
}

highp vec3 ComputeDynamicTerrainLights(highp vec3 worldPos, highp vec3 faceNormal)
{
	highp vec3 dynLight = vec3(0.0);
	dynLight = ApplyDynamicTerrainLight(dynLight, worldPos, faceNormal, dynamicTerrainLight0PosRadius,
		dynamicTerrainLight0ColorStrength, dynamicTerrainLight0ProfileParams);
	for (int i = 1; i < BM_MAX_DYNAMIC_TERRAIN_LIGHTS; ++i)
	{
		dynLight = ApplyDynamicTerrainLight(dynLight, worldPos, faceNormal, dynamicTerrainLightPosRadius[i],
			dynamicTerrainLightColorStrength[i], dynamicTerrainLightProfileParams[i]);
	}
	return dynLight;
}
#endif

void main(void)
{
	vec3 blockPos;
	blockPos = inPosition.xyz / 15.0;

	// inColor.w：section(3) | 材质变体(4)。非 Array 不读 greedy 位。
	int packedTerrainMeta = int(floor(inColor.w + 0.5));
	int sectionIndex = packedTerrainMeta & 7;
	int terrainMaterialVariant = (packedTerrainMeta >> 3) & 15;
	// 变体→surfaceClass：1/4/5→1，2/6→2（微量 sheen），其余 0。写入 v_faceNormal.w。
	float terrainSurfaceClass = (terrainMaterialVariant == 1
		|| terrainMaterialVariant == 4 || terrainMaterialVariant == 5) ? 1.0
		: ((terrainMaterialVariant == 2 || terrainMaterialVariant == 6) ? 2.0 : 0.0);
	vec3 sectionOffset = vec3(float(sectionIndex & 1),
		float((sectionIndex >> 1) & 1), float((sectionIndex >> 2) & 1)) * 16.0;
	blockPos = cellOrigin.xyz + sectionOffset + blockPos;
	gl_Position = matWVP * vec4(blockPos, 1.0);

	texCoord_texture = inTexCoord / 32768.0;
	float packedSkyAo = floor(inTexCoord1.x + 0.5);
	float skyLevel = floor(packedSkyAo / 16.0);
	float aoLevel = mod(packedSkyAo, 16.0);
	// Keep quantized AO linear so narrow projected edges do not collapse into black lines.
	// 量化 AO 保持线性，避免窄投影边塌成黑线。
	ambientOcclusion = clamp(1.0 - aoLevel / 15.0, 0.0, 1.0);
	float rawW = inPosition.w;
	lightStrength = mod(rawW, 16.0) / 15.0;
	float faceNormalIdx = floor(rawW / 16.0);
	v_faceNormal = vec4((faceNormalIdx < 14.5)
		? kFaceNormals[int(faceNormalIdx)] : vec3(0.0, 1.0, 0.0),
		terrainSurfaceClass);
	// 越界索引当无可靠法线：动态灯不再乘 Lambert，避免灭灯。
	vec3 dynamicFaceNormal = (faceNormalIdx < 14.5) ? v_faceNormal.xyz : vec3(0.0);
	// skyBrightness + 静态放置方块光（已乘 AO）；动态灯另加，不乘 AO。
	lightmapUV = vec4(skyLevel / 15.0,
		inTexCoord1.yzw / 255.0 * 1.5 * placedBlockLightStrength * ambientOcclusion);
#ifdef BM_LOCAL_LIGHT_ANALYTIC
	lightmapUV.yzw += ComputeDynamicTerrainLights(blockPos, dynamicFaceNormal);
#endif
	lightColor.w = ComputeFog(blockPos, blockPos - cameraPos, fogParam);

	vec3 legacyTint = inColor.rgb / 255.0;
	// sceneColorOutputParams.x>0.5 = 线性 HDR 场景色，染色先 gamma→线性。
	lightColor.xyz = sceneColorOutputParams.x > 0.5
		? pow(max(legacyTint, vec3(0.0)), vec3(2.2)) : legacyTint;
#ifdef BM_SHADOW_MODE_CSM
	v_worldPos = blockPos;
#endif
}
