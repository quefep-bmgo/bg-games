#version 300 es
/// 文件：lighting_v2_csm_alpha_mask_shadow.fs
/// 用途：Alpha 裁切 Actor 的 CSM caster。只按贴图 Alpha discard，不写颜色、不算光照。
/// Catalog：CSM_Shadow_ActorAlphaMask、CSM_Shadow_StaticActorAlphaMask
/// 特征：Unlit / DepthOnly
/// 阈值：a<0.1 打洞，避免树叶/头发在阴影图里变成实心块。

precision mediump float;

uniform sampler2D texSampler;         // 与主材质同一张 albedo，只读 Alpha

in mediump vec2 texCoord;

void main(void)
{
	if (texture(texSampler, texCoord).a < 0.1)
		discard;
}
