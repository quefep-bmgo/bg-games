#version 300 es
/// 文件：lighting_v2_csm_shadow_depth.fs
/// 用途：Terrain 方块 CSM 深度片元。空实现，深度由固定管线写入；不算光照。
/// Catalog：CSM_Shadow_Block
/// 特征：Unlit / DepthOnly
/// CSM Shadow Depth Fragment Shader (Terrain Blocks)
/// Depth-only pass：直接使用硬件深度 attachment，不再写 R32F 颜色 RT。

precision highp float;

void main(void)
{
    // 空实现：深度由固定功能管线写入 depth texture。
}
