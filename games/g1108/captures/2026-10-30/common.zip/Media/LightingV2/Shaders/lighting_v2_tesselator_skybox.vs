#version 300 es
/// 文件：lighting_v2_tesselator_skybox.vs
/// 用途：天空盒顶点。本地立方体方向原样作 Cubemap UV，再旋转到世界并推到远平面。
/// Catalog：Tess_Skybox
/// 特征：Unlit。z=w 保证天空盒永远在最后。

in vec3 inPosition;

uniform mat4 matRotate; // 天球旋转（随世界时间）
uniform mat4 matWorld;
uniform mat4 matWVP;

out vec3 TexCoords; // 未旋转的本地方向，供 Cubemap / 渐变 / 太阳圆盘

// 本文件未调用：天空盒用 z=w，不用距离雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	TexCoords = inPosition;
	vec4 rotatePos = matRotate * vec4(inPosition, 1.0);
	vec4 worldPos = matWorld * rotatePos;
	gl_Position = matWVP * worldPos;
	gl_Position.z = gl_Position.w;
}


