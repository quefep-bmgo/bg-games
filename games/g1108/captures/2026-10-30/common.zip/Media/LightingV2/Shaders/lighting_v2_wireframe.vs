#version 300 es
/// 文件：lighting_v2_wireframe.vs
/// 用途：编辑器辅助线框顶点：world × viewProj，转发顶点色。
/// Catalog：HelperForEditor
/// 特征：LinearSceneAware。

in vec3 inPosition;
in vec4 inColor;

uniform mat4 worldMat;
uniform mat4 viewProjMat;

out vec4 color;

void main(void)
{
	gl_Position = worldMat * vec4(inPosition, 1.0);
	gl_Position = viewProjMat * gl_Position;

	color = inColor;
}