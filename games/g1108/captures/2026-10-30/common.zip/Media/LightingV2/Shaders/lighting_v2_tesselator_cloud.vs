#version 300 es
/// 文件：lighting_v2_tesselator_cloud.vs
/// 用途：云层顶点。顶点色在 HDR 时解码；雾用线性距离雾（与天空指数平方雾不同）。
/// Catalog：Tess_Cloud
/// 特征：Unlit + LinearSceneAware。inTexCoord 未使用。

in vec3 inPosition;
in vec4 inColor; // 云层顶点色
in vec2 inTexCoord;

uniform mat4 matWorld;
uniform mat4 matWVP;
uniform vec4 fogParam[3]; // [0]=fogStart/End/density，[1]=雾色，[2].xyz=相机
uniform highp vec4 sceneColorOutputParams; // x>0.5=线性 HDR 场景色

out vec4 color;
out vec4 oFogColor; // rgb=雾色，a=雾可见度

// 线性雾可见度：1=无雾。云层不用天空的指数平方雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

vec3 GammaToLinear(vec3 inputColor)
{
	return pow(max(inputColor, vec3(0.0)), vec3(2.2));
}

void main(void)
{
	vec4 worldPos = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * worldPos;
	
	color = vec4(sceneColorOutputParams.x > 0.5
		? GammaToLinear(inColor.rgb) : inColor.rgb, inColor.a);
		
	oFogColor = vec4(fogParam[1].rgb,
		ComputeFog(worldPos.xyz-fogParam[2].xyz, fogParam[0].xyz));
}


