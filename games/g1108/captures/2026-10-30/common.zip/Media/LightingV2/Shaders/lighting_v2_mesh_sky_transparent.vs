#version 300 es
/// 文件：lighting_v2_mesh_sky_transparent.vs
/// 用途：静态 Actor 透明天空特效顶点。与 mesh_sky.vs 相同，另把 alphaColor.a 写入 color.a。
/// Catalog：StaticMeshForActorSkyTransparent
/// 特征：Unlit / LinearSceneAware

in vec3 inPosition;
in vec3 inNormal;
in vec2 inTexCoord;

uniform mat4 matWorld;
uniform mat4 matWVP;
uniform vec4 fogParam[3];             // [0]=start/end/density，[1]=雾色，[2]=相机
uniform vec3 viewPos;
uniform vec4 alphaColor;              // .a=整网格透明度

out vec4 oFogColor;                   // rgb=雾色，a=雾可见度
out vec4 color;                       // .a 来自 alphaColor
out vec2 texCoord;
out vec3 normal;
out vec3 viewDir;

invariant gl_Position;

// 线性距离雾可见度：1=无雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	vec4 vWorldPos = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * vec4(inPosition, 1.0);

	texCoord = inTexCoord;
	normal = normalize(mat3(matWorld) * inNormal);
	viewDir = viewPos - vWorldPos.xyz;

	color = vec4(1.0, 1.0, 1.0, 1.0);
	color.a = alphaColor.a;

	oFogColor = vec4(fogParam[1].rgb, ComputeFog(vWorldPos.xyz - fogParam[2].xyz, fogParam[0].xyz));
}
