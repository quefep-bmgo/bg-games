#version 300 es

precision highp float;

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec2 inTexCoord;
in vec4 inBlendIndices;
in vec3 inBlendWeights;

uniform mat4 matWVP;
uniform mat4 matWorld;
uniform vec4 fogParam;
uniform vec3 cameraPos;
uniform mediump vec3 terrainSkyRadiance;
uniform mediump vec4 objectDynamicLightIrradiance;
uniform vec4 boneMatRows[3 * MAX_BONE_NUM];

out mediump vec4 lightColor;
out mediump vec2 texCoord;

vec3 transformBonePosition(vec4 position, int matrixIndex, float weight)
{
	vec3 result;
	result.x = dot(position, boneMatRows[3 * matrixIndex + 0]);
	result.y = dot(position, boneMatRows[3 * matrixIndex + 1]);
	result.z = dot(position, boneMatRows[3 * matrixIndex + 2]);
	return result * weight;
}

float computeFogVisibility(vec3 worldPosition)
{
	if (fogParam.z <= 0.0)
		return 1.0;
	float distanceFromFogStart = max(length(worldPosition - cameraPos)
		- fogParam.x, 0.0);
	float fogRange = max(fogParam.y - fogParam.x, 0.001);
	float density = clamp(distanceFromFogStart / fogRange, 0.0, 1.0)
		* fogParam.z;
	return 1.0 - clamp(density, 0.0, 1.0);
}

void main(void)
{
	ivec3 boneIndices = ivec3(inBlendIndices.xyz);
	vec3 skinnedPosition =
		transformBonePosition(inPosition, boneIndices.x, inBlendWeights.x)
		+ transformBonePosition(inPosition, boneIndices.y, inBlendWeights.y)
		+ transformBonePosition(inPosition, boneIndices.z, inBlendWeights.z);
	vec4 worldPosition = matWorld * vec4(skinnedPosition, 1.0);

	gl_Position = matWVP * vec4(skinnedPosition, 1.0);
	texCoord = inTexCoord;
	lightColor.rgb = clamp(terrainSkyRadiance
		+ objectDynamicLightIrradiance.rgb, 0.0, 1.0);
	lightColor.a = computeFogVisibility(worldPosition.xyz);
}
