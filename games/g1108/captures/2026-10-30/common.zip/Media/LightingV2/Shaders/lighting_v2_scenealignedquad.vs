#version 300 es
/// 文件：lighting_v2_scenealignedquad.vs
/// 用途：全屏/场景对齐四边形。顶点已是裁剪空间，供后处理与显示 Pass 复用。
/// Catalog：PPOutputTransform、PPHdrBloomExtract/Blur、PPFXAA、GaussianBlur、Lut 等
/// 特征：Unlit / NotSceneColor（DisplayOnly 后处理）

in vec3 inPosition;       // 已是裁剪空间
in vec2 inTexCoord;

out vec2 texCoord;

void main(void)
{
	gl_Position = vec4(inPosition, 1.0);
	texCoord = inTexCoord;
}