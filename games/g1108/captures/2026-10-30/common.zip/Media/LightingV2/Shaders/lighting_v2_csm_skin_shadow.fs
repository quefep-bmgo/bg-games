#version 300 es
/// 文件：lighting_v2_csm_skin_shadow.fs
/// 用途：蒙皮/静态 Actor 与 Skin caster 的 CSM 深度片元。空实现，不算光照。
/// Catalog：CSM_Shadow_Skin、CSM_Shadow_Actor、CSM_Shadow_StaticActor
/// 特征：Unlit / DepthOnly
/// CSM Skin Shadow Depth Fragment Shader (Skinned Characters)
/// Depth-only pass：直接使用硬件深度 attachment，不再写 R32F 颜色 RT。

precision highp float;

void main(void)
{
    // 空实现：深度由固定功能管线写入 depth texture。
}
