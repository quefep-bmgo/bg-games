#version 300 es
/// 文件：lighting_v2_mesh_xray.vs
/// 用途：静态网格 Xray 顶点。加减 inNormal/inTexCoord 是为了保住 attribute，复用主网格顶点格式。
/// Catalog：StaticMeshForActorXray
/// 特征：LinearSceneAware / Unlit。像素走 lighting_v2_xray.ps。

in vec3 inPosition;
in vec3 inNormal;
in vec2 inTexCoord;

uniform mat4 matWVP;

void main(void)
{
	// +N+UV 再 -N-UV，净效果为 0，只为阻止编译器剔除这些 attribute。
	gl_Position = matWVP * vec4(inPosition, 1.0)
		+ vec4( inNormal, 0.0) + vec4( inTexCoord, 0.0, 0.0) 
		- vec4( inNormal, 0.0) - vec4( inTexCoord, 0.0, 0.0);;
}