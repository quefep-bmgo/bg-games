#version 300 es
/// 文件：lighting_v2_tesselator_glow.vs
/// 用途：辉光/自发光顶点。透传顶点色并推到远平面。
/// Catalog：Tess_Glow
/// 特征：Unlit。z=w。颜色域转换在 PS。

in vec3 inPosition;
in vec4 inColor; // 辉光顶点色

uniform mat4 matWorld;
uniform mat4 matWVP;

out vec4 color;

void main(void)
{
	vec4 worldPos = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * worldPos;
	gl_Position.z = gl_Position.w;
	
	color = inColor;
}



