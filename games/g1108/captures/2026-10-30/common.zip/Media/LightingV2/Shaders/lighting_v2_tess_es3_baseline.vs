#version 300 es

in vec4 inPosition;
in vec2 inTexCoord;
in vec4 inColor;

uniform mat4 matWVP;
uniform vec4 cellOrigin;
uniform vec4 fogParam;
uniform vec3 cameraPos;
uniform vec3 uAmbientColor;
uniform int uTessMode;
uniform vec2 uvOffset;
uniform vec4 uvRotation;
uniform vec4 uvTime;
#ifdef BM_LOCAL_LIGHT_ANALYTIC
uniform vec4 uDynamicLight0PosRadius;
uniform vec4 uDynamicLight0ColorStrength;
uniform vec4 uDynamicLight0ProfileParams;
#endif

out vec2 texCoord_texture;
out vec3 lighting;
out float fogVisibility;

float computeFog(vec3 worldPos)
{
	float distanceFog = max(length(worldPos - cameraPos) - fogParam.x, 0.0);
	float density = distanceFog * fogParam.z;
	return 1.0 - clamp(1.0 - exp(-density * density), 0.0, 1.0);
}

#ifdef BM_LOCAL_LIGHT_ANALYTIC
vec3 computeDynamicLight(vec3 worldPos)
{
	float radius = uDynamicLight0PosRadius.w;
	float strength = uDynamicLight0ColorStrength.w;
	if (radius <= 0.001 || strength <= 0.001)
		return vec3(0.0);
	float distanceToLight = length(uDynamicLight0PosRadius.xyz - worldPos);
	float sourceRadius = clamp(uDynamicLight0ProfileParams.x, 0.0, radius);
	float distance01 = clamp((distanceToLight - sourceRadius)
		/ max(radius - sourceRadius, 0.001), 0.0, 1.0);
	float distanceExponent = clamp(uDynamicLight0ProfileParams.y, 0.5, 8.0);
	float responseExponent = clamp(uDynamicLight0ProfileParams.z, 0.5, 8.0);
	float attenuation = pow(max(1.0 - pow(distance01, distanceExponent), 0.0),
		responseExponent);
	return uDynamicLight0ColorStrength.rgb * (attenuation * strength);
}
#endif

void main()
{
	int sectionIndex = int(floor(inColor.w + 0.5)) & 7;
	vec3 sectionOffset = vec3(float(sectionIndex & 1),
		float((sectionIndex >> 1) & 1), float((sectionIndex >> 2) & 1)) * 16.0;
	vec3 blockPos = inPosition.xyz / 15.0;
	// 高范围顶点的 Y 已是世界单位，不能再次缩放。
	if (uTessMode == 4)
		blockPos.y = inPosition.y;
	vec3 worldPos = cellOrigin.xyz + sectionOffset + blockPos;
	gl_Position = matWVP * vec4(worldPos, 1.0);
	texCoord_texture = inTexCoord / 32768.0;
	if (uTessMode == 1)
		texCoord_texture += uvOffset;
	else if (uTessMode == 2)
	{
		texCoord_texture = (texCoord_texture - uvOffset)
			* mat2(uvRotation.x, uvRotation.y, uvRotation.z, uvRotation.w)
			+ uvOffset;
	}
	else if (uTessMode == 3 || uTessMode == 4)
		texCoord_texture += uvTime.xy * uvTime.zw;
	lighting = uAmbientColor;
#ifdef BM_LOCAL_LIGHT_ANALYTIC
	lighting += computeDynamicLight(worldPos);
#endif
	// 顶点 RGB 是材质染色，与精简后的光照能力相互独立。
	lighting *= inColor.rgb / 255.0;
	fogVisibility = computeFog(worldPos);
}
