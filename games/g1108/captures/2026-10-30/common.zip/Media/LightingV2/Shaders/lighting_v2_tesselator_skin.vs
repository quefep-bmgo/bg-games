#version 300 es
/// 文件：lighting_v2_tesselator_skin.vs
/// 用途：蒙皮角色顶点。单骨蒙皮；光照已由 CPU 写成 VertexLit 顶点色，这里只做骨骼、雾和 tint。
/// Catalog：mcSkined_Solid、mcSkined_Transparent
/// 特征：VertexLit + VertexPacked + Shadow None。无可靠法线，不采样 CSM。
/// 顶点 ABI：inPosition.xyz=(packed/127-1)*8；inColor.rgb=VertexLit（0~255），.a=骨骼索引；inTexCoord=/32768

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec2 inTexCoord;
in vec4 inColor;    // rgb=VertexLit 色（0~255），a=骨骼索引

uniform mat4 matWVP;
uniform mat4 matWorld;
uniform vec4 fogParam; // xyz=fogStart/fogEnd/density
uniform vec3 cameraPos;
uniform vec4 extraColor; // rgb=额外 tint，不参与世界 Probe

uniform vec4 boneMatRows[3*MAX_BONE_NUM]; // 每骨 3 行 vec4，组成 3×4 骨骼矩阵

out vec4 lightColor; // rgb=已 tint 的 VertexLit，w=雾可见度
out vec2 texCoord;
out vec3 v_worldPos;

// 方向/法线：只乘 3×3，不含平移。
vec3 MulBone3(vec3 vInputPos, int nMatrix)
{
    vec3 vResult;
    vResult.x = dot( vInputPos, boneMatRows[3*nMatrix+0].xyz );
    vResult.y = dot( vInputPos, boneMatRows[3*nMatrix+1].xyz );
    vResult.z = dot( vInputPos, boneMatRows[3*nMatrix+2].xyz );
    return vResult;
}

// 位置：乘完整 3×4，含骨骼平移。
vec3 MulBone4(vec4 vInputPos, int nMatrix)
{
    vec3 vResult;
    vResult.x = dot( vInputPos, boneMatRows[(3*nMatrix)+0].xyzw );
    vResult.y = dot( vInputPos, boneMatRows[(3*nMatrix)+1].xyzw );
    vResult.z = dot( vInputPos, boneMatRows[(3*nMatrix)+2].xyzw );
    return vResult;
}

// 线性雾可见度：1=无雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	vec3 blockPos = (inPosition.xyz / 127.0 - 1.0) * 8.0;
	texCoord = inTexCoord / 32768.0;
	vec3 color = inColor.rgb / 255.0;
	color *= extraColor.rgb;
	int BoneIndices = int(inColor.a);
		
	vec3 vPos = MulBone4(vec4(blockPos, 1.0), BoneIndices);
	vec4 vWorldPos = matWorld * vec4(vPos, 1.0);
	gl_Position = matWVP * vec4(vPos, 1.0);

	lightColor.xyz = color;	

	lightColor.w = ComputeFog(vWorldPos.xyz - cameraPos, fogParam.xyz);
	v_worldPos = vWorldPos.xyz;
}
