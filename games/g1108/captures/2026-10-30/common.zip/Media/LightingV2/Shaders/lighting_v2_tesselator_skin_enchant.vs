#version 300 es
/// 文件：lighting_v2_tesselator_skin_enchant.vs
/// 用途：蒙皮附魔顶点。单骨蒙皮 + VertexPacked 顶点光；图集 UV 先还原到 0~1，再乘两套滚动矩阵。
/// Catalog：mcSkined_Enchant
/// 特征：VertexLit + VertexPacked + Shadow None。
/// 顶点 ABI：同 skin；（packed/127-1）*8；inColor.rgb=VertexLit（0~255），.a=骨骼索引。

#define MAX_BONE_NUM 73

in vec4 inPosition; // xyz = pos   w null
in vec2 inTexCoord;
in vec4 inColor;    // rgb=VertexLit 色（0~255），a=骨骼索引

uniform mat4 matWVP;
uniform mat4 matWorld;
uniform vec4 fogParam; // xyz=fogStart/fogEnd/density
uniform vec3 cameraPos;
uniform vec4 extraColor; // rgb=额外 tint
uniform mat4 matTexture1; // 附魔层 1 滚动矩阵
uniform mat4 matTexture2; // 附魔层 2 滚动矩阵
uniform vec4 texAtlas; // xy=图集偏移，zw=图集尺寸；把图集 UV 还原成局部 0~1

uniform vec4 boneMatRows[3*MAX_BONE_NUM]; // 每骨 3 行 vec4

out vec4 lightColor; // rgb=已 tint 的 VertexLit，w=雾可见度
out vec2 texCoord1;
out vec2 texCoord2;

// 方向/法线：只乘 3×3。本文件未调用，保留以匹配蒙皮 ABI。
vec3 MulBone3(vec3 vInputPos, int nMatrix)
{
    vec3 vResult;
    vResult.x = dot( vInputPos, boneMatRows[3*nMatrix+0].xyz );
    vResult.y = dot( vInputPos, boneMatRows[3*nMatrix+1].xyz );
    vResult.z = dot( vInputPos, boneMatRows[3*nMatrix+2].xyz );
    return vResult;
}

// 位置：乘完整 3×4。
vec3 MulBone4(vec4 vInputPos, int nMatrix)
{
    vec3 vResult;
    vResult.x = dot( vInputPos, boneMatRows[(3*nMatrix)+0].xyzw );
    vResult.y = dot( vInputPos, boneMatRows[(3*nMatrix)+1].xyzw );
    vResult.z = dot( vInputPos, boneMatRows[(3*nMatrix)+2].xyzw );
    return vResult;
}

// 线性雾可见度：1=无雾。
float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

void main(void)
{
	vec3 blockPos = (inPosition.xyz / 127.0 - 1.0) * 8.0;
	vec2 texCoord = inTexCoord / 32768.0;
	vec3 color = inColor.rgb / 255.0;
	color *= extraColor.rgb;
	int BoneIndices = int(inColor.a);
	
	vec4 vTexture;
	vec4 vEnchantTex;
	vTexture.x = (texCoord.x - texAtlas.x) / texAtlas.z;
	vTexture.y = (texCoord.y - texAtlas.y) / texAtlas.w;
	vTexture.z = 1.0;
	vTexture.w = 1.0;
	vEnchantTex = matTexture1 * vTexture;
	texCoord1 = vEnchantTex.xy;
	vEnchantTex = matTexture2 * vTexture;
	texCoord2 = vEnchantTex.xy;
		
	vec3 vPos = MulBone4(vec4(blockPos, 1.0), BoneIndices);
	vec4 vWorldPos = matWorld * vec4(vPos, 1.0);
	gl_Position = matWVP * vec4(vPos, 1.0);
		
	lightColor.xyz = color;	
	lightColor.w = ComputeFog(vWorldPos.xyz - cameraPos, fogParam.xyz);
}
