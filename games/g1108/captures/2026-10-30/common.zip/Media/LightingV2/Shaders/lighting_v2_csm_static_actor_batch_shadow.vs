#version 300 es
/// Static Actor CSM batches keep local positions and select a per-node WVP.
/// TAM_Mask is intentionally treated as solid shadow geometry in this pass.

layout(location = 0) in vec4 inPosition;

uniform mat4 actorPartWVP[48];

void main(void)
{
	int matrixSlot = int(inPosition.w + 0.5);
	gl_Position = actorPartWVP[matrixSlot] * vec4(inPosition.xyz, 1.0);
}
