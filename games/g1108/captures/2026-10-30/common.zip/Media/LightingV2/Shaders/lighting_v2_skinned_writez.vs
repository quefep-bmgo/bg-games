#version 300 es
/// 文件：lighting_v2_skinned_writez.vs
/// 用途：蒙皮 Actor 深度预写 / CSM caster。只做 3 骨蒙皮 + WVP，不算光照。
/// Catalog：SkinedMeshForActor_WriteZ、CSM_Shadow_Actor、CSM_Shadow_ActorAlphaMask
/// 特征：Unlit / DepthOnly
/// 顶点 ABI：与 skinned_high.vs 相同的骨骼打包；法线/UV 只为保住顶点格式。

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec3 inNormal;
in vec2 inTexCoord;
in vec4 inBlendIndices;               // 最多 3 根骨骼索引
in vec3 inBlendWeights;

uniform mat4 matWVP;                  // WriteZ=相机 VP；CSM Pass=lightViewProj
uniform vec4 boneMatRows[3*MAX_BONE_NUM]; // 每骨 3 行，省第四行

out vec3 tempValue;                   // 极小引用，防止属性被裁掉
out mediump vec2 texCoord;            // AlphaMask caster 需要 UV

// 用 3 行骨骼矩阵变换位置（含平移）。
vec3 MulBone4( vec4 vInputPos, int nMatrix, float fBlendWeight )
{
    vec3 vResult;
    vResult.x = dot( vInputPos, boneMatRows[(3*nMatrix)+0].xyzw );
    vResult.y = dot( vInputPos, boneMatRows[(3*nMatrix)+1].xyzw );
    vResult.z = dot( vInputPos, boneMatRows[(3*nMatrix)+2].xyzw );
    return vResult * fBlendWeight;
}

void main(void)
{
	vec3 vPos;
	
	 ivec3 BoneIndices;
	 BoneIndices.x = int(inBlendIndices.x);
	 BoneIndices.y = int(inBlendIndices.y);
	 BoneIndices.z = int(inBlendIndices.z);
	
  	vPos = MulBone4(inPosition, BoneIndices.x, inBlendWeights.x);
  	vPos += MulBone4(inPosition, BoneIndices.y, inBlendWeights.y);
  	vPos += MulBone4(inPosition, BoneIndices.z, inBlendWeights.z);

	// blend vertex position
	vec4 posV4 = vec4(vPos, 1.0);
	
	tempValue = inNormal * 0.000001;
	tempValue.xy += inTexCoord * 0.000001;
	texCoord = inTexCoord;
	gl_Position = matWVP * posV4;
}
