#version 300 es
/// 文件：lighting_v2_tesselator_water.vs
/// 用途：水体积 Water lighting model。4-bit 单采样 Probe + 解析局部光，无 CSM、无 wrap。
/// Catalog：Tess_Water
/// 特征：Water / VertexPacked / None / Analytic / LinearSceneAware
/// 顶点 ABI：inPosition.xyz=/2048+sectionPos；.w 打包 4×4bit Probe
///   解包 Probe：x=天空亮度，yzw=静态局部光（不是 Terrain RGB8）

#ifdef GL_FRAGMENT_PRECISION_HIGH
	precision highp float;
#else
	precision mediump float;
#endif

in highp vec4 inPosition;             // .w=packed 4-bit Probe

uniform mat4 matWVP;
uniform vec4 sectionPos;


uniform vec4 fogParam[3];             // [0]=距离，[1]=雾色，[2]=相机

out vec4 oFogColor;                   // rgb=雾色，a=雾可见度
out vec3 waterLighting;               // 体积水辐照，给 PS 乘底色

uniform highp vec3 mainLightDir;
uniform highp vec3 terrainDirectionalRadiance;
uniform highp vec3 terrainSkyRadiance;
uniform highp vec4 terrainLightingParams; // x=天空响应曲线
uniform highp float placedBlockLightStrength; // 放置方块光倍率

const int BM_MAX_DYNAMIC_TERRAIN_LIGHTS = 4;
uniform highp vec4 dynamicTerrainLight0PosRadius;
uniform highp vec4 dynamicTerrainLight0ColorStrength;
uniform highp vec4 dynamicTerrainLight0ProfileParams;
uniform highp vec4 dynamicTerrainLightPosRadius[BM_MAX_DYNAMIC_TERRAIN_LIGHTS];
uniform highp vec4 dynamicTerrainLightColorStrength[BM_MAX_DYNAMIC_TERRAIN_LIGHTS];
uniform highp vec4 dynamicTerrainLightProfileParams[BM_MAX_DYNAMIC_TERRAIN_LIGHTS];

float ComputeFog(vec3 camToWorldPos, vec3 param)
{
	float fdist = max(length(camToWorldPos) - param.x, 0.0);
	float density = clamp(clamp(fdist/(param.y-param.x), 0.0, 1.0) * param.z, 0.0, 1.0);
	return 1.0 - density;
}

// 体积水：半球固定 0.5，太阳用 0.5×太阳直射门控，不做环绕漫反射。
vec3 EvaluateWaterVolumeLighting(vec4 probe, vec3 extraLocal)
{
	float skyBrightness = clamp(probe.x, 0.0, 1.0);
	float curve = clamp(terrainLightingParams.x, 0.0, 10.0);
	float skyResponse = skyBrightness / ((1.0 - skyBrightness) * curve + 1.0);
	vec3 skyAmbient = terrainSkyRadiance
		* skyResponse;
	vec3 staticLocal = probe.yzw * 1.5 * placedBlockLightStrength;
	float sunGate = smoothstep(0.5 / 15.0, 3.5 / 15.0, skyBrightness);
	vec3 sun = terrainDirectionalRadiance * (0.5 * sunGate);
	vec3 lightmapLighting = skyAmbient + (staticLocal + extraLocal);
	return lightmapLighting + sun;
}

// 解析局部光：只按距离衰减，保持与地形局部光一致。
highp vec3 ApplyDynamicTerrainLight(highp vec3 dynLight, highp vec3 worldPos,
	highp vec3 faceNormal, highp vec4 posRadius, highp vec4 colorStrength,
	highp vec4 profileParams)
{
	highp float radius = posRadius.w;
	highp float strength = colorStrength.w;
	if (radius <= 0.001 || strength <= 0.001)
		return dynLight;

	highp vec3 lightDelta = posRadius.xyz - worldPos;
	highp float lightDistance = length(lightDelta);
	highp float sourceRadius = clamp(profileParams.x, 0.0, max(radius - 0.001, 0.0));
	highp float dist01 = clamp(max(lightDistance - sourceRadius, 0.0)
		/ max(radius - sourceRadius, 0.001), 0.0, 1.0);
	highp float distanceExponent = clamp(profileParams.y, 0.5, 8.0);
	highp float responseExponent = clamp(profileParams.z, 0.5, 8.0);
	highp float distancePower;
	if (abs(distanceExponent - 2.0) < 0.001) distancePower = dist01 * dist01;
	else if (abs(distanceExponent - 1.0) < 0.001) distancePower = dist01;
	else distancePower = pow(dist01, distanceExponent);
	highp float base = max(0.0, 1.0 - distancePower);
	highp float atten;
	if (abs(responseExponent - 1.0) < 0.001) atten = base;
	else if (abs(responseExponent - 2.0) < 0.001) atten = base * base;
	else atten = pow(base, responseExponent);
	return dynLight + colorStrength.rgb * (atten * strength);
}

// 最多 4 盏手持/动态 Terrain 灯，线性域相加。
highp vec3 ComputeDynamicTerrainLights(highp vec3 worldPos, highp vec3 faceNormal)
{
	highp vec3 dynLight = ApplyDynamicTerrainLight(vec3(0.0), worldPos, faceNormal,
		dynamicTerrainLight0PosRadius, dynamicTerrainLight0ColorStrength,
		dynamicTerrainLight0ProfileParams);
	for (int i = 1; i < BM_MAX_DYNAMIC_TERRAIN_LIGHTS; ++i)
		dynLight = ApplyDynamicTerrainLight(dynLight, worldPos, faceNormal,
			dynamicTerrainLightPosRadius[i], dynamicTerrainLightColorStrength[i],
			dynamicTerrainLightProfileParams[i]);
	return dynLight;
}

void main()
{
	vec3 blockPos = inPosition.xyz / 2048.0 + sectionPos.xyz;
	gl_Position = matWVP * vec4(blockPos, 1.0);
	highp float packedProbe = floor(inPosition.w + 0.5);
	highp vec4 probe;
	probe.x = mod(packedProbe, 16.0) / 15.0;                 // 天空亮度
	probe.y = mod(floor(packedProbe / 16.0), 16.0) / 15.0;    // 静态局部光 R
	probe.z = mod(floor(packedProbe / 256.0), 16.0) / 15.0;
	probe.w = mod(floor(packedProbe / 4096.0), 16.0) / 15.0;
	waterLighting = EvaluateWaterVolumeLighting(probe,
		ComputeDynamicTerrainLights(blockPos, vec3(0.0)));

	oFogColor = vec4(fogParam[1].rgb, ComputeFog(blockPos-fogParam[2].xyz, fogParam[0].xyz));

}
