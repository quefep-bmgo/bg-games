#version 300 es
/// 文件：lighting_v2_actor_face.vs
/// 用途：角色脸部贴图合成的全屏/裁剪空间顶点入口。不做蒙皮、不算光照。
/// Catalog：ActorFaceTexture
/// 特征：Unlit / None / None / None / Full / NotSceneColor
/// 顶点 ABI：inPosition 已是裁剪空间，直接写出；inTexCoord 透传给分层采样。

in vec3 inPosition;
in vec2 inTexCoord;

out vec2 texCoord;

void main(void)
{
	gl_Position = vec4(inPosition, 1.0);
	texCoord = inTexCoord;
}