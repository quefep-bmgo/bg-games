#version 300 es
/// 文件：lighting_v2_tesselator_star.vs
/// 用途：星星顶点。推到远平面；顶点色在 HDR 时先解码，与 PS 贴图同域相乘。
/// Catalog：Tess_Star
/// 特征：Unlit + LinearSceneAware。z=w。

in vec3 inPosition;
in vec4 inColor; // 星星顶点色/闪烁
in vec2 inTexCoord;

uniform mat4 matWorld;
uniform mat4 matWVP;
uniform highp vec4 sceneColorOutputParams; // x>0.5=线性 HDR 场景色

out vec4 color;
out vec2 texCoord;

vec3 GammaToLinear(vec3 inputColor)
{
	return pow(max(inputColor, vec3(0.0)), vec3(2.2));
}

void main(void)
{
	vec4 worldPos = matWorld * vec4(inPosition, 1.0);
	gl_Position = matWVP * worldPos;
	gl_Position.z = gl_Position.w;
	
	color = vec4(sceneColorOutputParams.x > 0.5
		? GammaToLinear(inColor.rgb) : inColor.rgb, inColor.a);
	texCoord = inTexCoord;
}



