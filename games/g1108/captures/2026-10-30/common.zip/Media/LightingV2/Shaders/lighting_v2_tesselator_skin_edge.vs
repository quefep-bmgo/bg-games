#version 300 es
/// 文件：lighting_v2_tesselator_skin_edge.vs
/// 用途：蒙皮描边顶点。先单骨蒙皮，再沿蒙皮后径向在屏幕上外扩，不计算光照。
/// Catalog：mcSkined_Edge
/// 特征：Unlit。PS 为 lighting_v2_edge.ps。
/// 顶点 ABI：同 skin；（packed/127-1）*8；inColor.a=骨骼索引。

#define MAX_BONE_NUM 73

in vec4 inPosition;
in vec4 inColor; // a=骨骼索引

uniform mat4 matWVP;
uniform vec4 boneMatRows[3*MAX_BONE_NUM]; // 每骨 3 行 vec4
uniform float edgeWidth; // 描边宽度倍率
uniform vec2 viewportSize; // 视口像素尺寸

const float EDGE_PIXEL_WIDTH = 2.0;
const float EDGE_DIR_EPSILON = 0.00001;

// 位置：乘完整 3×4。
vec3 MulBone4(vec4 vInputPos, int nMatrix)
{
    vec3 vResult;
    vResult.x = dot(vInputPos, boneMatRows[(3*nMatrix)+0].xyzw);
    vResult.y = dot(vInputPos, boneMatRows[(3*nMatrix)+1].xyzw);
    vResult.z = dot(vInputPos, boneMatRows[(3*nMatrix)+2].xyzw);
    return vResult;
}

// 方向：只乘 3×3，外扩方向必须跟骨骼一起转。
vec3 MulBone3(vec3 vInputNormal, int nMatrix)
{
    vec3 vResult;
    vResult.x = dot(vInputNormal, boneMatRows[(3*nMatrix)+0].xyz);
    vResult.y = dot(vInputNormal, boneMatRows[(3*nMatrix)+1].xyz);
    vResult.z = dot(vInputNormal, boneMatRows[(3*nMatrix)+2].xyz);
    return vResult;
}

void main(void)
{
    vec3 blockPos = (inPosition.xyz / 127.0 - 1.0) * 8.0;
    vec3 localDir = blockPos;
    if (length(localDir) <= EDGE_DIR_EPSILON)
    {
        localDir = vec3(0.0, 1.0, 0.0);
    }

    int boneIndex = int(inColor.a);
    vec3 vPos = MulBone4(vec4(blockPos, 1.0), boneIndex);
    vec3 vNormal = MulBone3(normalize(localDir), boneIndex);

    vec4 baseClip = matWVP * vec4(vPos, 1.0);
    vec4 normalClip = matWVP * vec4(vPos + normalize(vNormal), 1.0);
    vec2 baseNdc = baseClip.xy / max(abs(baseClip.w), EDGE_DIR_EPSILON);
    vec2 normalNdc = normalClip.xy / max(abs(normalClip.w), EDGE_DIR_EPSILON);
    vec2 screenDir = normalNdc - baseNdc;
    float dirLen = length(screenDir);
    vec2 pixelToNdc = vec2(2.0 / max(viewportSize.x, 1.0), 2.0 / max(viewportSize.y, 1.0));
    if (dirLen > EDGE_DIR_EPSILON)
    {
        // 沿屏幕径向外扩，再乘 clip.w，保持像素宽度不随透视变化。
        baseClip.xy += screenDir / dirLen * EDGE_PIXEL_WIDTH * edgeWidth * pixelToNdc * baseClip.w;
    }
    gl_Position = baseClip;
}
