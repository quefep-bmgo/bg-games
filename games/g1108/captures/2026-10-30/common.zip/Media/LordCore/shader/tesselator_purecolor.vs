#version 300 es

in vec4 inPosition;
in vec4 inColor;

uniform mat4 matWVP;
uniform vec4 sectionPos[8];

out mediump vec4 lightColor;

void main(void)
{
    vec3 blockPos = inPosition.xyz / 15.0;
    blockPos += sectionPos[int(inColor.w)].xyz;
    gl_Position = matWVP * vec4(blockPos, 1.0);
    lightColor = vec4(inColor.rgb / 255.0, 1.0);
}
