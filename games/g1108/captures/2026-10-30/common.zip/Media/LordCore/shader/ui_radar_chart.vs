#version 300 es

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec4 inColor;
layout(location = 2) in vec2 inTexCoord;

uniform mat4 matWVP;

out mediump vec4 color;
out mediump vec2 localPos;

void main(void)
{
    gl_Position = matWVP * vec4(inPosition, 1.0);
    color = inColor;
    localPos = inTexCoord;
}
