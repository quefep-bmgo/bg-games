---@class UIMainLayout : IGUILayout
local UIMain = class("UIMain", IGUILayout)
---@type CPlatformVipPkSender
local PlatformVipPkSender = T(Global, "PidPacketSender")

function UIMain:onLoad()
    self.used = 0
    self.max = 0
    self.ivDarkMask = self:getChildWindow("ThrowPotMain-Dark-Mask", GUIType.StaticImage)
    self.btnSubscription = self:getChildWindow("ThrowPotMain-Subscription", GUIType.Button)
    self.btnChest = self:getChildWindow("ThrowPotMain-Chest", GUIType.Button)
    self.stChestCount = self:getChildWindow("ThrowPotMain-ChestCount", GUIType.StaticText)
    self.btnChest:SetVisible(false)
    self:initEvent()
end

function UIMain:initEvent()
    self.btnSubscription:registerEvent(GUIEvent.ButtonClick, function()
        UIHelper.showGameGUILayout("GUISubscriptionVip")
    end)
    if Game:isEnableIndie() then
        self.btnSubscription:SetVisible(false)
    end

    self.btnChest:registerEvent(GUIEvent.ButtonClick, function()
        if self.used < self.max then
            PlatformVipPkSender:useChest()
        end
    end)

    self:registerDataCallBack("ShowDarkMask", function(data)
        local duration = data:getNumberParam("duration")
        self.ivDarkMask:SetVisible(true)
        LuaTimer:cancel(self.darkMaskTaskKey)
        self.darkMaskTaskKey = LuaTimer:schedule(function()
            self.ivDarkMask:SetVisible(false)
        end, duration)
    end, DataBuilderProcessor)
end

function UIMain:updateChestCount(used, max)
    self.used = used
    self.max = max
    self.stChestCount:SetText(math.max(max - used, 0) .. "/" .. max)
    self.btnChest:SetVisible(max > 0)
end

return UIMain