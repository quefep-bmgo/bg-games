
local limitConfig = util.readCsv(path, 3)

local result = {}    
for _, config in pairs(limitConfig) do
    local LimitConfig = {}
    LimitConfig.Index = tonumber(config.Index)
    LimitConfig.Season = tonumber(config.Season)
    LimitConfig.Week = tonumber(config.Week)
    LimitConfig.EXPLimit = tonumber(config.EXPLimit)
    LimitConfig.TaskGroup = tonumber(config.TaskGroup)
    table.insert(result, LimitConfig)
end

return result