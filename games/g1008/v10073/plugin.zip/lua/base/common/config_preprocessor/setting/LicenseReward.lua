local rewardConfig = util.readCsv(path, 3)

local result = {}
for _, config in pairs(rewardConfig) do
    local Reward = {}
    Reward.Index = tonumber(config.Index)
    Reward.Season = tonumber(config.Season)
    Reward.Lv = tonumber(config.Lv)
    Reward.NeedEXP = tonumber(config.NeedEXP)
    Reward.FreeReward = config.FreeReward
    Reward.FreeNum = tonumber(config.FreeNum)
    Reward.PayReward = config.PayReward
    Reward.PayNum = tonumber(config.PayNum)
    Reward.StageReward = tonumber(config.StageReward)
    Reward.BuyLevel = tonumber(config.BuyLevel)
    Reward.FreeShowType = tonumber(config.FreeShowType or "1")
    Reward.PayShowType = tonumber(config.PayShowType or "1")
    Reward.FreeActor = tostring(config.FreeActor)
    Reward.PayActor = tostring(config.PayActor)
    Reward.FreeActorSkillName = tostring(config.FreeActorSkillName or "idle")
    Reward.PayActorSkillName = tostring(config.PayActorSkillName or "idle")
    Reward.FreeSpecialReward = tonumber(config.FreeSpecialReward or "0")
    Reward.PaySpecialReward = tonumber(config.PaySpecialReward or "0")
    if Reward.FreeReward ~= "#" then
        Reward.FreeReward = tonumber(Reward.FreeReward)
    end
    if Reward.PayReward ~= "#" then
        Reward.PayReward = tonumber(Reward.PayReward)
    end
    table.insert(result, Reward)
end

table.sort(result, function(a, b)
    return a.Lv < b.Lv
end)

return result