local config = util.readCsv(path, 2)

local OldToNew = {}
local NewToOld = {}
local DressToNew = {}
local DressToOld = {}

for _, item in pairs(config) do
    local newIds = OldToNew[item.ItemId] or {}
    table.insert(newIds, tonumber(item.NewItemId))
    OldToNew[item.ItemId] = newIds
    NewToOld[item.NewItemId] = tonumber(item.ItemId)
    DressToNew[item.ItemId .. "#" .. item.DressItemId] = tonumber(item.NewItemId)
    local oldIds = DressToOld[item.DressItemId] or {}
    table.insert(oldIds, tonumber(item.ItemId))
    DressToOld[item.DressItemId] = oldIds
end

return {
    OldToNew = OldToNew,
    NewToOld = NewToOld,
    DressToNew = DressToNew,
    DressToOld = DressToOld
}
