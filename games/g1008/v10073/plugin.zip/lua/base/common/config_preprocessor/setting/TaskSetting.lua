local task_list = util.readCsv(path, 2)

local TaskConfig = {}
TaskConfig.TaskList = {}
TaskConfig.TaskGroupList = {}
TaskConfig.TaskGroupWeight = {}

for _, task in pairs(task_list) do
    local item = {
        Id = tonumber(task.id),
        Desc = task.desc or "",
        GroupId = tonumber(task.groupId),
        NextTaskId = tonumber(task.nextTaskId),
        TaskTypeId = tonumber(task.type),
        RefreshCycle = tonumber(task.refreshCycle),
        GoalNum = tonumber(task.num),
        Remarks = util.splitString(task.remarks, "#"),
        GameTypes = util.splitString(task.gameType, "#"),
        Reward = tonumber(task.reward),
        Weight = tonumber(task.weight),
        RewardIds = util.splitString(task.RewardIds or "", "#"),
    }
    TaskConfig.TaskList[item.Id] = item
    TaskConfig.TaskGroupList[tostring(item.GroupId)] = TaskConfig.TaskGroupList[tostring(item.GroupId)] or {}
    table.insert(TaskConfig.TaskGroupList[tostring(item.GroupId)], item)

    if item.GroupId ~= nil then
        if not TaskConfig.TaskGroupWeight[item.GroupId] then
            TaskConfig.TaskGroupWeight[item.GroupId] = item.Weight
        else
            TaskConfig.TaskGroupWeight[item.GroupId] = TaskConfig.TaskGroupWeight[item.GroupId] + item.Weight
        end
    end
end

return TaskConfig