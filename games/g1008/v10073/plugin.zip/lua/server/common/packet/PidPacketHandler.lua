local handler = {}
local observable = EventObservable.new()

observable:registerDataCallBack("pid", function(userId, packetInJson)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local packet = json.decode(packetInJson)
    local hand_func = handler[packet.pid]
    if hand_func then
        hand_func(player, packet)
    end
end)

function handler:PlaceBlockSkill(packet)
    local skill = SkillConfig:getSkill(self:getHeldItemId())
    if skill and skill.isPlaceBlock then
        self.PlaceBlockPos = VectorUtil.newVector3i(packet.x, packet.y, packet.z)
    end
end

function handler:GameAnalytics(packet)
    GameAnalytics:newDesign(self.userId, packet.event, json.decode(packet.pushData) or {})
end