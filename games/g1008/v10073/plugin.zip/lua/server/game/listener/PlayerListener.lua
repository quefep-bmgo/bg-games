PlayerListener = {}
---@type PlayerActionServer
local playerActionServer = require "game.domain_services.PlayerActionServer"

function PlayerListener:init()
    BaseListener.registerCallBack(PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(PlayerRespawnEvent, self.onPlayerRespawn)
    BaseListener.registerCallBack(PlayerAttackedEvent, self.onPlayerHurtForSettlement)
    BaseListener.registerCallBack(PlayerDieEvent, self.onPlayerDied)
    BaseListener.registerCallBack(PlayerDieTipEvent, self.onPlayerDiedTip)
    BaseListener.registerCallBack(PlayerMoveEvent, self.onPlayerMove)

    PlayerUseCommonItemEvent.registerCallBack(self.onPlayerUseCommonItem)
    PlayerDropItemEvent.registerCallBack(self.onPlayerDropItem)
    PlayerExchangeItemEvent.registerCallBack(self.onPlayerExchangeItem)
    PlayerPickupItemEndEvent.registerCallBack(self.onPlayerPickupItemEnd)
    PotionCustomEvent.registerCallBack(self.onPotionCustom)
    ItemSkillNeedCustomSpeedEvent.registerCallBack(self.onItemSkillNeedCustomSpeed)
    KnockBackExtraStrengthEvent.registerCallBack(self.onKnockBackExtraStrength)
    PlayerBackHallEvent.registerCallBack(self.onPlayerBackHall)
    PlayerAttackCreatureEvent.registerCallBack(self.onPlayerAttackCreature)
    UseFishHookHitEntityEvent.registerCallBack(self.onUseFishHookHitEntity)

    PlayerRequestPlayAgainEvent:registerCallBack(self.onPlayerRequestPlayAgain)
    PlayerBuyGoodEvent:registerCallBack(self.onPlayerBuyGood)
    PlayerBackBedWarHallEvent:registerCallBack(self.onPlayerBackHall)

    PlayerLicenseReceiveRewardEvent:registerCallBack(self.onPlayerReceiveReward)
    PlayerLicenseBuyLevelEvent:registerCallBack(self.onPlayerBuyLevel)
    PlayerBuyLicenseEvent:registerCallBack(self.onPlayerBuyLicense)
    PlayerExchangeRewardEvent:registerCallBack(self.onPlayerExchangeReward)
    PlayerReceiveTaskReward:registerCallBack(self.onPlayerReceiveTaskReward)
    PlayerClickMainControlEvent:registerCallBack(self.onPlayerClickMainControl)

    PlayerUseActionEvent:registerCallBack(self.onPlayerUseAction)
    PlayerIntoFollowModeEvent:registerCallBack(self.onPlayerIntoFollowMode)

    PayDiamondsSuccess:registerCallBack(self.onPayDiamondsSuccess)
end

function PlayerListener:onPlayerRequestPlayAgain(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    EngineUtil.sendEnterOtherGame(player.rakssid, GameType, player.userId, player.cur_map_id)
end

function PlayerListener.onPlayerExchangeItem(rakssid, type, itemId, itemMeta, itemNum, bullets, vec3)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    if type == 1 then
        return ItemHelper:canDropItem(player, itemId)
    elseif type == 2 then
        local item = Item.getItemById(itemId)
        if item and item:getClassName() == "ItemSword" then
            player:removeWoodSword()
        end
        return true
    end
end

function PlayerListener.onPlayerLogin(clientPeer)
    if GameMatch.hasStartGame then
        return GameOverCode.GameStarted
    end
    local player = GamePlayer.new(clientPeer)
    player:init()
    GamePacketSender:sendMapId(player.rakssid, GameConfig.mapId)
    HostApi.sendGameStatus(player.rakssid, 1)
    return GameOverCode.Success, player
end

function PlayerListener.onPlayerLogout(player)
    GameMatch:onPlayerQuit(player)
    if not GameMatch.allowPvp then
        GameInfoManager:clearInfo("PlayerInfo", player.userId)
    end
    GameResourceManager:onPlayerLogout(player)
end

function PlayerListener.onPlayerReady(player)
    HostApi.sendPlaySound(player.rakssid, 10000)
    DbUtil:getPlayerData(player)
    player:checkParty()

    if GameConfig.openLotterySwitch == 1 then
        GamePacketSender:sendBedWarOpenLottery(player.rakssid)
    end

    if GameMatch.allowPvp then
        HostApi.setAllowUseItemStatus(player.rakssid, 1)
    else
        HostApi.setAllowUseItemStatus(player.rakssid, 0)
    end
    GameInfoManager.Instance():onPlayerReady(player)
    player.lifeStatus = true
    GamePacketSender:sendMoveLimitCheck(player.rakssid)
    GamePacketSender:sendQuicklyBuildBlock(player.rakssid)
    GameLottery:addPlayerLotteryInfo(player.userId)
    CommonPacketSender:sendBedWarPlayerReady(player.rakssid)
    return 43200
end

function PlayerListener.onPlayerHurtForSettlement(hurtPlayer, hurtFrom, damageType, hurtValue)
    local needHurt = PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    if needHurt then
        local fromer = PlayerManager:getPlayerByPlayerMP(hurtFrom)
        if fromer then
            SettlementManager:onPlayerHurt(hurtPlayer:getPlatformUserId(), hurtFrom:getPlatformUserId(), tonumber(hurtValue.value))
        else
            SettlementManager:onPlayerHurt(hurtPlayer:getPlatformUserId(), nil, tonumber(hurtValue.value))
        end
        local hurter = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
        if hurter and hurter.mount then
            hurter.mount:onHurt(hurtValue.value)
            needHurt = false
        end
    end
    return needHurt
end

function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---@type GamePlayer
    local hurter = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
    if hurter == nil then
        return false
    end
    if hurter.isInvincible then
        ---无敌时间
        return false
    end
    if hurter.hurtLock then
        ---受伤保护时间
        return false
    end
    hurter.hurtLock = LuaTimer:schedule(function()
        hurter.hurtLock = nil
    end, 250)
    ---@type GamePlayer
    local fromer = PlayerManager:getPlayerByPlayerMP(hurtFrom)
    if fromer ~= nil then
        if damageType == "explosion.player" and fromer.onWithered then
            hurtValue.value = 0
            hurter:subHealth(GameConfig.tntExplosionDamageFactor)
        end
        hurter.damageType = "player"
    end
    if (fromer and AIManager:isAI(fromer.rakssid)) and not AIManager:isAI(hurter.rakssid or 0) then
        hurtValue.value = hurtValue.value * GameConfig.aiDamageCoefficient
    end

    if AIManager:isAI(hurter.rakssid) then
        local ai = AIManager:getAIByRakssid(hurter.rakssid)
        if ai then
            ai:onHurt()
        end
    end
    -- HostApi.log("onPlayerHurt " .. damageType)

    if (GameMatch.allowPvp == false) then
        if damageType == "outOfWorld" then
            hurter:teleWaitPos()
        end
        return false
    end

    if damageType == "fall" then
        local blockId = EngineWorld:getBlockId(VectorUtil.getNegY(hurtPlayer:getPosition()))
        if blockId == 0 or blockId == 165 then
            return false
        end
        if InventoryUtil:getPlayerHasEquipItem(hurter, Define.ItemId.NinjaShoes) then
            return false
        end
        if hurter.ignoreOnceFall then
            return false
        end
        hurter.damageType = "fall"
    end

    if damageType == "explosion.player" or damageType == "explosion" then
        hurtValue.value = hurter:subApple(hurtValue.value)
        hurter.damageType = "explosion"
        return true
    end

    if damageType == "outOfWorld" then
        if hurter.isLife == false and hurter.realLife == false then
            hurter:teleWatchPos()
            return false
        end
        hurter.damageType = damageType
        hurtValue.value = hurter:subApple(hurtValue.value)
        hurter.damageType = "outOfWorld"
        return true
    end

    if damageType == "arrow" then
        hurter.damageType = "arrow"
    end

    if damageType == "onFire" then
        hurter.damageType = "onFire"
    end

    if hurtFrom == nil then
        hurtValue.value = hurter:subApple(hurtValue.value)
        return true
    end

    if fromer ~= nil then
        if hurter.team and fromer.team and hurter.team.id == fromer.team.id then
            return false
        end
        RuneManager:onAttack(fromer, hurtValue, damageType, hurter)
    end

    RuneManager:onHurted(hurter, hurtValue)
    if hurtValue.value < 1 then
        hurtValue.value = 1
    end
    hurtValue.value = hurter:subApple(hurtValue.value)
    BuffManager:onPlayerByInterrupt(hurter.userId)
    return true
end

function PlayerListener.onPlayerDiedTip(diePlayer, killPlayer)
    return false
end

function PlayerListener.onPlayerDied(diePlayer, _, killPlayer)
    ---@type GamePlayer
    local dier = PlayerManager:getPlayerByPlayerMP(diePlayer)
    if not dier then
        return true
    end

    if not GameMatch:isGameStart() then
        dier:setInventory()
        dier:clearInv()
        RespawnHelper.addRespawnCountdown(dier, 0)
        return true
    end
    dier.lastDieTime = os.time()

    ---@type GamePlayer
    local killer = PlayerManager:getPlayerByPlayerMP(killPlayer)
    if killer then
        killer:onKill(dier)
    end

    dier:clearEffects()
    dier:clearArmorInfo()
    dier:setInventory()
    dier:setEnderInventory()
    LuaTimer:schedule(function()
        dier:teleWatchPos()
    end, 0)
    dier:resetApple()
    dier.curApple = 0
    dier.maxApple = 0
    dier:updateApple()
    dier.deathNum = dier.deathNum + 1
    dier:resetHollowBlock()

    if dier.deathNum == 1 and AIManager:isAI(dier.rakssid) == false then
        if killer == nil then
            ReportUtil.reportDeathPeriod(dier, dier.damageType, 0)
        else
            ReportUtil.reportDeathPeriod(dier, dier.damageType, killer:getHeldItemId())
        end
    end

    if killer == nil then
        ReportUtil.reportDeathReason(dier, dier.initLevel, dier.damageType, 0)
    else
        local useItemId = killer:getHeldItemId()
        ReportUtil.reportDeathReason(dier, dier.initLevel, dier.damageType, useItemId)
        if not killer.itemKillRecord[tostring(useItemId)] then
            killer.itemKillRecord[tostring(useItemId)] = 0
        end
        killer.itemKillRecord[tostring(useItemId)] = killer.itemKillRecord[tostring(useItemId)] + 1
    end
    if dier.damageType == "outOfWorld" then
        playerActionServer.outOfWold(dier, killer)
    end
    GameMatch:onPlayerDie(dier)
    dier.multiKill = 0
    dier.lifeStatus = false
    local ai = AIManager:getAIByRakssid(dier.rakssid)
    if ai ~= nil then
        ai:refreshInv()
        ai.isLife = false
    end

    if dier.damageType == "outOfWorld" then
        if dier.lastUseEnderDragon and (os.time() - dier.lastUseEnderDragon) <= 8 then
            AnalyticsReportUtil.reportEnderDragonOutOfWorld(dier)
        elseif dier.lastUseWithered and (os.time() - dier.lastUseWithered) <= 8 then
            AnalyticsReportUtil.reportWitheredOutOfWorld(dier)
        end
    end
    if dier.backPearTimer ~= 0 and dier.backPearTimer ~= nil then
        LuaTimer:cancel(dier.backPearTimer)
        dier.backPearTimer = 0
        AnalyticsReportUtil.reportBackPearlResult(dier, true)
    end
    return true
end

function PlayerListener.onPlayerRespawn(player)
    if GameMatch:isGameStart() == false then
        AddMaxHPPrivilege:onPlayerRespawn(player)
        player:fillInvetory(player.inventory)
        player:teleWaitPos()
        return 43200
    end

    RuneManager:onRespawn(player)
    player:onSpawnInGame()
    return 43200
end

function PlayerListener.onPlayerUseCommonItem(rakssId, itemId)

    local player = PlayerManager:getPlayerByRakssid(rakssId)
    if player == nil then
        return
    end

    if itemId >= 467 and itemId <= 471 then
        local pos = player:getPosition()
        if BridgeConfig:buildBridge(itemId, player:getYaw(), VectorUtil.toBlockVector3(pos.x, pos.y - 1, pos.z)) then
            SettlementManager:addBuildScore(player.userId, Define.BuildType.Egg)
        end
    end
end

function PlayerListener.onPlayerDropItem(rakssid, itemId, itemMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end
    BuffManager:onPlayerByInterrupt(player.userId)
    return ItemHelper:canDropItem(player, itemId)
end
----------------------------------------------------------------------------
-----------------------------  临时  ----------------------------------------
local iceTime = 3
local range = 1
function PlayerListener.changeBlockToIce(old_blockId, position, userId)
    if EngineWorld:getBlockId(position) ~= BlockID.PACKED_ICE then
        EngineWorld:setBlock(position, BlockID.PACKED_ICE)
    end
    LuaTimer:schedule(function()
        if EngineWorld:getBlockId(position) == BlockID.PACKED_ICE then
            local player = PlayerManager:getPlayerByUserId(userId)
            if not player then
                EngineWorld:setBlock(position, old_blockId)
                return
            end
            local newPos = player:getPosition()
            if math.abs(newPos.x - position.x) < range + 1 and
                    math.floor(newPos.y - 0.5) == position.y and
                    math.abs(newPos.z - position.z) < range + 1 then
                PlayerListener.changeBlockToIce(old_blockId, position, userId)
                return
            end
            EngineWorld:setBlock(position, old_blockId)
        end
    end, iceTime * 1000)
end

function PlayerListener.canBeIce(blockId)
    return blockId ~= BlockID.AIR
            and blockId ~= BlockID.PACKED_ICE
            and blockId ~= BlockID.OBSIDIAN
            and blockId ~= BlockID.WATER_MOVING
            and blockId ~= BlockID.WATER_STILL
            and blockId ~= BlockID.FIRE
            and blockId ~= BlockID.WOOL_CARPET
end
---@param player GamePlayer
function PlayerListener.checkSkatingShoes(player, pos)
    if player.equip_iec then
        local cur_block_pos = VectorUtil.toBlockVector3(pos.x, pos.y, pos.z)
        local cur_block_id = EngineWorld:getBlockId(cur_block_pos)
        if cur_block_id == BlockID.FIRE then
            EngineWorld:setBlock(cur_block_pos, BlockID.AIR)
        end
        for i = pos.x - range, pos.x + range do
            for j = pos.z - range, pos.z + range do
                local position = VectorUtil.toBlockVector3(i, pos.y - 1, j)
                local floor_block_id = EngineWorld:getBlockId(position)
                if PlayerListener.canBeIce(floor_block_id) and EngineWorld:isBlockChange(position) then
                    PlayerListener.changeBlockToIce(floor_block_id, position, player.userId)
                end
            end
        end
    end
end
-----------------------------  临时  ----------------------------------------
----------------------------------------------------------------------------
function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    if x == 0 and y == 0 and z == 0 then
        return true
    end
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return true
    end

    if y <= GameConfig.useHollowBlockHeight and GameMatch.allowPvp and not player.useHollowBlock then
        player:canUseHollowBlock()
    end

    if y >= GameConfig.startGlideHeight and GameMatch.allowPvp and player.useHollowBlock and not player:isGlide() then
        player:setGlide(true)
        player.ignoreOnceFall = true
        player:startSinging(GameConfig.glideDuration * 1000, false, Define.SingingIcon.HollowBlock)
        LuaTimer:cancel(player.cancelGlideKey or 0)
        player.cancelGlideKey = LuaTimer:schedule(function(userId)
            local c_player = PlayerManager:getPlayerByUserId(userId)
            if c_player then
                c_player:setGlide(false)
                c_player:resetHollowBlock()
            end
        end, GameConfig.glideDuration * 1000, nil, tostring(player.userId))
    end

    if y <= GameConfig.deathLineY then
        if (GameMatch.allowPvp == false) then
            player:teleWaitPos()
        else
            player.damageType = "outOfWorld"
            player:subHealth(99999)
        end

    end
    TeamConfig:onPlayerMove(player, x, y, z)
    GameResourceManager:onPlayerMove(player, x, y, z)
    if player.realLife and movePlayer.onGround == true then
        player:resetHollowBlock()
        player.ignoreOnceFall = false
        local curPos = VectorUtil.newVector3(math.floor(x), math.floor(y), math.floor(z))
        if not player.lastGroundPos or VectorUtil.hashVector3(curPos) ~= VectorUtil.hashVector3(player.lastGroundPos) then
            player.lastGroundPos = curPos
        end
    end
    PlayerListener.checkSkatingShoes(player, VectorUtil.newVector3(x, y, z))
    return true
end

function PlayerListener.onPlayerPickupItemEnd(rakssid, itemId, itemNum, _, entityId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    GameResourceManager:onPickUpItem(player, entityId, itemId, itemNum)
    ItemHelper:tryChangePickUpItem(player, itemId)
end

function PlayerListener.onPotionCustom(entityId, itemId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return true
    end
    local effect = ItemPotionEffect:getPotionEffect(itemId)
    if not effect then
        return true
    end
    player:addEffect(effect.Type, effect.Duration, effect.Level)
    return false
end

function PlayerListener.onItemSkillNeedCustomSpeed(rakssid, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end

    if ItemID.FLARE_BOMB == itemId then
        return false
    end

    return true
end

function PlayerListener.onKnockBackExtraStrength(hurterEntityId, attackerEntityId, knockBackValue)
    local hurter = PlayerManager:getPlayerByEntityId(hurterEntityId)
    local attacker = PlayerManager:getPlayerByEntityId(attackerEntityId)

    if hurter and attacker then
        knockBackValue.value = knockBackValue.value + tonumber(attacker.info:getValue("runeAddKnockBackValue"))
    end
    return true
end

function PlayerListener.onPlayerBackHall(id)
    local player = PlayerManager:getPlayerByRakssid(id)
    if player == nil then
        player = PlayerManager:getPlayerByUserId(id)
        if player == nil then
            return
        end
    end
    BackHallManager:addPlayer(player)
end

function PlayerListener.onPlayerReceiveReward(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local Lv = DataBuilder.new():fromData(data):getNumberParam("Lv")
    local rewardId = DataBuilder.new():fromData(data):getNumberParam("rewardId")
    local rewardType = DataBuilder.new():fromData(data):getParam("rewardType")
    local getAll = DataBuilder.new():fromData(data):getBoolParam("getAll")
    local season = DataBuilder.new():fromData(data):getNumberParam("season")
    GameLicense:onPlayerGetReward(userId, Lv, getAll, season, rewardId, rewardType)
end

function PlayerListener.onPlayerBuyLevel(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local season = DataBuilder.new():fromData(data):getNumberParam("season")
    local level = DataBuilder.new():fromData(data):getNumberParam("level")
    local free = DataBuilder.new():fromData(data):getNumberParam("free")
    GameLicense:onPlayerBuyLevel(player, season, level, free)
end

function PlayerListener.onPlayerBuyLicense(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local season = DataBuilder.new():fromData(data):getNumberParam("season")
    local buyType = DataBuilder.new():fromData(data):getNumberParam("buyType")
    GameLicense:onPlayerBuy(player, season, buyType)
end

function PlayerListener.onPlayerExchangeReward(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local season = DataBuilder.new():fromData(data):getNumberParam("season")
    local itemId = DataBuilder.new():fromData(data):getNumberParam("itemId")
    local rewardNum = DataBuilder.new():fromData(data):getNumberParam("rewardNum")
    GameLicense:onPlayerExchange(userId, itemId, season, rewardNum)
end

function PlayerListener.onPlayerUseAction(userId, actionId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    CommonPacketSender:sendUseActionToAll(player:getEntityId(), actionId)
end

function PlayerListener.onPlayerReceiveTaskReward(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local taskId = DataBuilder.new():fromData(data):getNumberParam("taskId")
    GameLicense:onPlayerReceiveSeasonTaskReward(player, taskId)
end

function PlayerListener.onPlayerClickMainControl(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    BuffManager:onPlayerByInterrupt(userId)
end

function PlayerListener.onPlayerIntoFollowMode(player, follower)
    GamePacketSender:sendMapId(player.rakssid, GameConfig.mapId)
    if GameMatch:isGameStart() then
        GameResourceManager:synTeamResource(player)
    end
end

function PlayerListener.onPlayerAttackCreature(rakssid, entityId, attackType, position, damage, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    local monster = MonsterManager:getMonster(entityId)
    if monster == nil then
        return false
    end
    return monster:onAttacked(player, damage)
end

function PlayerListener.onPayDiamondsSuccess(userId, uniqueId, diamonds)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return false
    end
    ReportUtil.reportUseCube(player, uniqueId, diamonds)
end

function PlayerListener.onUseFishHookHitEntity(anglerId, targetId)
    local angler = PlayerManager:getPlayerByEntityId(anglerId)
    local target = PlayerManager:getPlayerByEntityId(targetId)
    if not target or not angler then
        return true
    end
    local anglerInfo = GameInfoManager:getPlayerInfo(angler.userId)
    local targetInfo = GameInfoManager:getPlayerInfo(target.userId)
    if not anglerInfo or not targetInfo then
        return true
    end

    if anglerInfo:getValue("teamId") == targetInfo:getValue("teamId") then
        return false
    end
    return true
end

return PlayerListener
--endregion
