local rewards = util.readCsv(path, 3)

local result = {}
for _, reward in pairs(rewards) do
    result[reward.Id] = {
        Id = tonumber(reward.Id),
        Title = reward.Title,
        Name = reward.Name,
        Image = reward.Image,
        Desc = reward.Desc,
        Type = tonumber(reward.Type),
        Count = tonumber(reward.Count),
        CountText = reward.CountText,
        RewardId = tonumber(reward.RewardId),
        RewardType = reward.RewardType
    }
end

return result