---@class PetLvConfig
local PetLvConfig = T(Global, "PetLvConfig")
local Config = {}
local ImbueLvSetting = {}
local PetImbueConfig = {}

local TextColor = {
    [1] = "▢FFFFFFFF",      --普通
    [2] = "▢FF80FFFF",      --中级
    [3] = "▢FFFDCB02",      --高级
    default = "▢FFFFFFFF"
}

local QualityStr = {
    [1] = "gui.pet.skill.quality.normal",      --普通
    [2] = "gui.pet.skill.quality.middle",      --中级
    [3] = "gui.pet.skill.quality.high",      --高级
    default = "gui.pet.skill.quality.normal"
}

if not Plugins.IsLoaded("imbue") then
    return
end

local function getItemName(itemId)
    local goods = StoreConfig:getGoodsByItemId(itemId)
    if goods and goods.showDetail and goods.Count == 1 then
        return Lang:getString(goods.showDetail.name)
    end
    return Lang:getItemName(itemId)
end

local DescFunc = {
    [Define.ImbueType.ExtraSwordImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate, params[2])
    end,
    [Define.ImbueType.ExtraArrowImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate, params[2])
    end,
    [Define.ImbueType.PropEDImbue] = function(desc, params)
        local itemName = getItemName(tonumber(params[1]))
        return string.format(Lang:getString(desc), itemName, params[2])
    end,
    [Define.ImbueType.ProductionImbue] = function(desc, params)
        local itemName = getItemName(tonumber(params[3]))
        if tonumber(params[3]) == BlockID.CLOTH then
            itemName = Lang:getString("CustomShopTabs_Lang_2")
        end
        return string.format(Lang:getString(desc), params[1], params[2], itemName)
    end,
    [Define.ImbueType.PickUpRewardImbue] = function(desc, params)
        local itemName = getItemName(tonumber(params[1]))
        local rate = math.modf(tonumber(params[2]) / 100)
        return string.format(Lang:getString(desc), itemName, rate, params[3], params[4])
    end,
    [Define.ImbueType.ReturnFireBallImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate, params[2])
    end,
    [Define.ImbueType.InitItemImbue] = function(desc, params)
        local items = StringUtil.split(params[1], "#")
        local num = StringUtil.split(params[2], "#")
        local str = {}
        for i, id in pairs(items) do
            local itemName = getItemName(tonumber(id))
            table.insert(str, itemName .. "(" .. num[i] .. ")")
        end
        return string.format(Lang:getString(desc), table.concat(str, "、"))
    end,
    [Define.ImbueType.DoubleJumpImbue] = function(desc, params)
        local height = tonumber(params[1]) * 100
        local rate = math.ceil((height - 42) / 42 * 100)
        return string.format(Lang:getString(desc), rate)
    end,
    [Define.ImbueType.OnDieCountDownImbue] = function(desc, params)
        local value = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), value)
    end,
    [Define.ImbueType.KnockBackImbue] = function(desc, params)
        local rate = math.modf(tonumber(params[1]) / 100)
        return string.format(Lang:getString(desc), rate)
    end,
    [Define.ImbueType.RevengeImbue] = function(desc, params)
        return string.format(Lang:getString(desc), tonumber(params[1]) / 100)
    end,
    [Define.ImbueType.AngryImbue] = function(desc, params)
        local BuffConfig = T(Global, "BuffConfig")
        local buffCfg = BuffConfig:getBuffById(tonumber(params[1]))
        return string.format(Lang:getString(desc), tonumber(params[2]) / 100, tonumber(buffCfg.param[1]), tonumber(buffCfg.param[2]))
    end,
    [Define.ImbueType.AddArmorPercentage] = function(desc, params)
        return string.format(Lang:getString(desc), tonumber(params[1]) / 100)
    end,
    [Define.ImbueType.ColdLegs] = function(desc, params)
        local BuffConfig = T(Global, "BuffConfig")
        local buffCfg = BuffConfig:getBuffById(tonumber(params[1]))
        return string.format(Lang:getString(desc), tonumber(buffCfg.param[4]) / 20, tonumber(buffCfg.param[3]))
    end,
    [Define.ImbueType.SelfExplosionImbue] = function(desc, params)
        return string.format(Lang:getString(desc), tostring(params[3]), tostring(params[2]))
    end,
    [Define.ImbueType.ClayBombImbue] = function(desc, params)
        local BuffConfig = T(Global, "BuffConfig")
        local buffCfg = BuffConfig:getBuffById(tonumber(params[1]))
        return string.format(Lang:getString(desc), tonumber(buffCfg.param[2]))
    end,
    [Define.ImbueType.RingOfFireImbue] = function(desc, params)
        local BuffConfig = T(Global, "BuffConfig")
        local buffCfg = BuffConfig:getBuffById(tonumber(params[3]))
        return string.format(Lang:getString(desc), tostring(params[1]) / 100, tostring(params[2]), tonumber(buffCfg.param[1]))
    end,
}

function PetLvConfig:init()
    self:initPetImbueLvConfig()
    self:initPetImbueConfig()
    self:initPetLvConfig()
end

function PetLvConfig:initPetLvConfig()
    local config = FileUtil.getConfigFromCsv("setting/PetLv.csv")
    for _, vConfig in pairs(config) do
        local data = {
            petId = tonumber(vConfig.petId),
            imbueGroupId = tonumber(vConfig.imbueGroupId),
            maxLv = tonumber(vConfig.maxLv),
            uiScale = tonumber(vConfig.uiScale)
        }
        Config[tostring(data.petId)] = data
    end
end

function PetLvConfig:initPetImbueLvConfig()
    local ImbueConfig = FileUtil.getConfigFromCsv("setting/ImbueClassSetting.csv", 3)
    for _, config in pairs(ImbueConfig or {}) do
        if tonumber(config.Type) == 2 and config.Group ~= 0 then
            ---@class PetLvItemConfig
            local data = {}
            data.type = tonumber(config.Type) or 0
            data.level = tonumber(config.Level) or 0
            data.group = tonumber(config.Group) or 0
            data.imbueId = tonumber(config.Id)
            data.moneyType = Define.Money.PET_CANDY
            data.price = tonumber(config.Price)
            data.imbueType = tonumber(config.ImbueType)
            data.values = {}
            for i = 1, 4 do
                if tonumber(config["Value"..i]) ~= 0 then
                    table.insert(data.values,config["Value"..i])
                end
            end
            local list = ImbueLvSetting[data.group]
            if not list then
                ImbueLvSetting[data.group] = {}
            end
            ImbueLvSetting[data.group][tostring(data.level)] = data
        end
    end
end

function PetLvConfig:initPetImbueConfig()
    local config = FileUtil.getConfigFromCsv("setting/PetImbueConfig.csv", 2)
    for _, vConfig in pairs(config) do
        local data = {
            imbueGroupId = tonumber(vConfig.id),
            imbueType = tonumber(vConfig.imbueType),
            noEquipSame = vConfig.noEquipSame == "1" or false,
        }
        if isClient then
            data.icon = vConfig.icon
            data.desc = vConfig.desc
            data.quality = tonumber(vConfig.quality)
        end
        local imbueLevelCfg = ImbueLvSetting[data.imbueGroupId]
        if imbueLevelCfg then
            data.lvCfg = imbueLevelCfg
        end
        PetImbueConfig[data.imbueGroupId] = data
    end
end

function PetLvConfig:getPetImbueConfigByGroupId(imbueGroupId)
    if not imbueGroupId then
        return
    end
    local config = PetImbueConfig[imbueGroupId]
    if not config then
        LogUtil.logWarning("not pet imbue config imbueGroupId: ", imbueGroupId)
    end
    return PetImbueConfig[imbueGroupId]
end

function PetLvConfig:getPetImbueConfigs()
    return PetImbueConfig
end

---@return PetLvItemConfig
function PetLvConfig:getConfigByLv(petId, lv, imbueGroupId)
    local config = Config[tostring(petId)] or {}
    imbueGroupId = imbueGroupId or config.imbueGroupId
    local imbueConfig = self:getPetImbueConfigByGroupId(imbueGroupId)
    if imbueConfig and imbueConfig.lvCfg then
        return TableUtil.copyTable(imbueConfig.lvCfg[tostring(lv)])
    end
    return {}
end

function PetLvConfig:isMaxLv(petId, lv)
    local config = Config[tostring(petId)] or {}
    return lv >= config.maxLv
end

function PetLvConfig:getDesc(petId, lv, imbueGroupId)
    local config = PetLvConfig:getConfigByLv(petId, lv, imbueGroupId)
    if not config.imbueType then
        return ""
    end
    imbueGroupId = imbueGroupId or config.group
    local imbueConfig = self:getPetImbueConfigByGroupId(imbueGroupId)
    if not imbueConfig then
        return ""
    end
    local params = config.values
    return self:getDescString(imbueConfig, params)
end

function PetLvConfig:getDescByImbueGroupId(imbueGroupId, lv)
    local imbueConfig = self:getPetImbueConfigByGroupId(imbueGroupId)
    if not imbueConfig then
        return ""
    end
    local params = imbueConfig.lvCfg[tostring(lv)].values
    return self:getDescString(imbueConfig, params)
end

function PetLvConfig:getDescString(imbueConfig, params)
    local color = TextColor[imbueConfig.quality] or TextColor.default
    local qualityStr = Lang:getString(QualityStr[imbueConfig.quality] or QualityStr.default)
    local desc = nil
    if DescFunc[imbueConfig.imbueType] then
        desc = DescFunc[imbueConfig.imbueType](imbueConfig.desc, params)
    else
        if #params == 1 then
            desc = string.format(Lang:getString(imbueConfig.desc), params[1])
        elseif #params == 2 then
            desc = string.format(Lang:getString(imbueConfig.desc), params[1], params[2])
        elseif #params == 3 then
            desc = string.format(Lang:getString(imbueConfig.desc), params[1], params[2], params[3])
        elseif #params == 4 then
            desc = string.format(Lang:getString(imbueConfig.desc), params[1], params[2], params[3], params[4])
        end
    end
    return string.format("%s(%s)%s", color,qualityStr, desc), color, qualityStr, desc
end

function PetLvConfig:getIcon(petId, imbueGroupId)
    local config = Config[tostring(petId)] or {}
    imbueGroupId = imbueGroupId or config.imbueGroupId
    local imbueConfig = self:getPetImbueConfigByGroupId(imbueGroupId)
    if imbueConfig then
        return imbueConfig.icon or ""
    end
    return ""
end

function PetLvConfig:getMaxLv(petId)
    local config = Config[tostring(petId)] or {}
    return config.maxLv or 0
end

function PetLvConfig:getUIScale(petId)
    local config = Config[tostring(petId)] or {}
    return config.uiScale or 1
end

function PetLvConfig:getCanEquipSame(petId, imbueGroupId)
    local config = Config[tostring(petId)] or {}
    imbueGroupId = imbueGroupId or config.imbueGroupId
    local imbueConfig = self:getPetImbueConfigByGroupId(imbueGroupId)
    if imbueConfig then
        return not (config.noEquipSame or false)
    end
    return false
end

function PetLvConfig:getPetDefaultImbueGroupId(petId)
    local config = Config[tostring(petId)] or {}
    return config.imbueGroupId or 0
end

PetLvConfig:init()

return PetLvConfig