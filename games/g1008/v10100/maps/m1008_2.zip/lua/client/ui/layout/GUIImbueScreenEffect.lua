---@class UIImbueScreenEffectLayout : IGUILayout
local UIImbueScreenEffectLayout = class("UIImbueScreenEffectLayout", IGUILayout)
---@type ImbueEffectConfig
local ImbueEffectConfig = T(Global, "ImbueEffectConfig")

---@private
function UIImbueScreenEffectLayout:isDelayLoad()
	return true
end

---@private
function UIImbueScreenEffectLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIImbueScreenEffectLayout:initCreateEvent()
	self:registerEvent(Events.ShowImbueScreenEffect, function(imbueType, time)
		if not self:isShow() then
			self:show(imbueType, time)
		else
			self:setScreenEffect(imbueType, time)
		end
	end)
	self:registerEvent(Events.HideImbueScreenEffect, function()
		self:hide()
	end)
end

---@private
function UIImbueScreenEffectLayout:onLoad()
	self.siEffect = self:getChildWindow("ImbueScreenEffect-Effect", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function UIImbueScreenEffectLayout:initView()

end

---@param imbueType number
---@param time number 毫秒
function UIImbueScreenEffectLayout:setScreenEffect(imbueType, time)
	local effectData = ImbueEffectConfig:getEffectDataByImbueType(imbueType)
	if effectData then
		if effectData.screenEffect then
			self.siEffect:SetEffectName(effectData.screenEffect)
			self.siEffect:PlayEffect()
		else
			self.siEffect:SetEffectName("")
		end
		self.root:SetTouchable(effectData.banOperate)
	else
		self:hide()
	end
end

function UIImbueScreenEffectLayout:onShow(imbueType, time)
	self:setScreenEffect(imbueType, time)
end

function UIImbueScreenEffectLayout:onHide()
	self.root:SetTouchable(false)
end

---@private
function UIImbueScreenEffectLayout:initEvent()

end

return UIImbueScreenEffectLayout
