---@class UITalentDetailLayout : IGUILayout
local UITalentDetailLayout = class("UITalentDetailLayout", IGUILayout)
---@type ImbueClassSetting
local ImbueClassSetting = T(Global, "ImbueClassSetting")
---@type CTalentController
local CTalentController = T(Global, "CTalentController")
---@type TalentConfig
local TalentConfig = T(Global, "TalentConfig")
---@type BuffConfig
local BuffConfig = T(Global, "BuffConfig")

local DescFunc = {
    [Define.ImbueType.InitItemImbue] = function(desc, params)
        local num = params[2]
        return Lang:format(desc, num)
    end,
    [Define.ImbueType.OnKillIronImbue] = function(desc, params)
        local num = params[1]
        return Lang:format(desc, num)
    end,
    [Define.ImbueType.RespawnItemImbue] = function(desc, params)
        local itemId = params[1]
        local num = params[2]
        local itemName = Lang:getItemName(tonumber(itemId))
        return Lang:format(desc, num, itemName)
    end,
    [Define.ImbueType.BuyItemImbue] = function(desc, params)
        local num = params[2]
        return Lang:format(desc, num)
    end,
    [Define.ImbueType.SwordFireImbue] = function(desc, params)
        local buffId = tonumber(params[3])
        local buffCfg = BuffConfig:getBuffById(buffId)
        local timeStr = string.format("%.0f", buffCfg.duration / 20)
        return Lang:format(desc, UITalentDetailLayout:fixShowVal(params[1]), timeStr, buffCfg.param[1], buffCfg.param[2])
    end,
    [Define.ImbueType.ExtremeSpeedImbue] = function(desc, params)
        local buffId = tonumber(params[1])
        local buffCfg = BuffConfig:getBuffById(buffId)
        local timeStr = string.format("%.0f", buffCfg.duration / 20)
        return Lang:format(desc, buffCfg.param[1], timeStr)
    end,
    [Define.ImbueType.StormImbue] = function(desc, params)
        local buffId = tonumber(params[3])
        local buffCfg = BuffConfig:getBuffById(buffId)
        local timeStr = string.format("%.0f", buffCfg.duration / 20)
        return Lang:format(desc, params[1], params[2],tonumber(buffCfg.param[1]), timeStr, params[4])
    end,
    [Define.ImbueType.ColdIceImbue] = function(desc, params)
        local buffId = tonumber(params[2])
        local buffCfg = BuffConfig:getBuffById(buffId)
        local timeStr = string.format("%.0f", buffCfg.duration / 20)
        return Lang:format(desc, UITalentDetailLayout:fixShowVal(params[1]), math.abs(tonumber(buffCfg.param[1])), timeStr)
    end,
    [Define.ImbueType.ThornImbue] = function(desc, params)
        local buffId = tonumber(params[1])
        local buffCfg = BuffConfig:getBuffById(buffId)
        local replyHpBuffCfg = BuffConfig:getBuffById(Define.BuffId.SubReplyHp)
        local timeStr = string.format("%.0f", replyHpBuffCfg.duration / 20)
        return Lang:format(desc, buffCfg.param[1], timeStr)
    end,
    [Define.ImbueType.MaxHpWithTimeImbue] = function(desc, params)
        return Lang:format(desc, params[2], params[1], params[3])
    end,
    [Define.ImbueType.ThunderclapImbue] = function(desc, params)
        return Lang:format(desc, UITalentDetailLayout:fixShowVal(params[1]), params[2])
    end,
    [Define.ImbueType.FrozenImbue] = function(desc, params)
        local buffId = tonumber(params[2])
        local buffCfg = BuffConfig:getBuffById(buffId)
        local timeStr = string.format("%.0f", buffCfg.duration / 20)
        return Lang:format(desc, UITalentDetailLayout:fixShowVal(params[1]), timeStr)
    end,
    [Define.ImbueType.ArmorImbue] = function(desc, params)
        return Lang:format(desc, params[1])
    end,
    [Define.ImbueType.InitRandomPropsImbue] = function(desc, params)
        return Lang:format(desc, params[2], params[3])
    end,
    [Define.ImbueType.ThrowableSpeedImbue] = function(desc, params)
        return Lang:format(desc, UITalentDetailLayout:fixShowVal(params[2]))
    end,
    [Define.ImbueType.IntervalAddItemImbue] = function(desc, params)
        return Lang:format(desc, params[3], params[2])
    end,
    [Define.ImbueType.ReduceSkillItemCdImbue] = function(desc, params)
        return Lang:format(desc, UITalentDetailLayout:fixShowVal(params[2]))
    end,
    [Define.ImbueType.AddFlareBombDamageImbue] = function(desc, params)
        local buffId = tonumber(params[1])
        local buffCfg = BuffConfig:getBuffById(buffId)
        return Lang:format(desc, tonumber(buffCfg.param[1]) * 100, tonumber(buffCfg.param[2]) * 100)
    end
}

---@private
function UITalentDetailLayout:isDelayLoad()
    return true
end

---@private
function UITalentDetailLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UITalentDetailLayout:initCreateEvent()
    self:registerEvent(Events.StartGameEvent, function()
        self:hide()
    end)
end

---@private
function UITalentDetailLayout:onLoad()
    self.siBg = self:getChildWindow("TalentDetail- Bg", GUIType.StaticImage)
    self.stName = self:getChildWindow("TalentDetail-Name", GUIType.StaticText)
    self.stLevel = self:getChildWindow("TalentDetail-Level", GUIType.StaticText)
    self.siPropDescBg = self:getChildWindow("TalentDetail-PropDescBg", GUIType.StaticImage)
    self.ltPropDescList = self:getChildWindow("TalentDetail-PropDesc", GUIType.List)
    self.stUnlockCondition = self:getChildWindow("TalentDetail-UnlockCondition", GUIType.StaticText)
    self.llUpgradeContent = self:getChildWindow("TalentDetail-UpgradeContent", GUIType.Layout)
    self.llCloseArea = self:getChildWindow("TalentDetail-CloseArea", GUIType.Layout)
    self.siCurPropBg = self:getChildWindow("TalentDetail-CurPropBg", GUIType.StaticImage)
    self.stCurPropTips = self:getChildWindow("TalentDetail-CurPropTips", GUIType.StaticText)
    self.ltCurPropList = self:getChildWindow("TalentDetail-CurPropList", GUIType.List)
    self.siNextPropBg = self:getChildWindow("TalentDetail-NextPropBg", GUIType.StaticImage)
    self.stNextPropTips = self:getChildWindow("TalentDetail-NextPropTips", GUIType.StaticText)
    self.ltNextPropList = self:getChildWindow("TalentDetail-NextPropList", GUIType.List)
    self.stMax = self:getChildWindow("TalentDetail-Max", GUIType.StaticText)
    self.btnOkBtn = self:getChildWindow("TalentDetail-OkBtn", GUIType.Button)
    self.llBtnContent = self:getChildWindow("TalentDetail-BtnContent", GUIType.Layout)
    self.siCurrencyIcon = self:getChildWindow("TalentDetail-CurrencyIcon", GUIType.StaticImage)
    self.stCurrencyPrice = self:getChildWindow("TalentDetail-CurrencyPrice", GUIType.StaticText)
    self.siIcon = self:getChildWindow("TalentDetail-Icon", GUIType.StaticImage)
    self.siUpgradeEffect = self:getChildWindow("TalentDetail-UpgradeEffect", GUIType.StaticImage)
    self.awRewardActor = self:getChildWindow("TalentDetail-RewardActor", GUIType.ActorWindow)
    self:initView()
    self:initEvent()
end

---@private
function UITalentDetailLayout:initView()
    self.stCurPropTips:SetText(Lang:getString("gui.talent.cur.level.effect"))
    self.stNextPropTips:SetText(Lang:getString("gui.talent.next.level.effect"))
    self.stMax:SetText(Lang:getString("gui.talent.level.max"))

    self.siUpgradeEffect:SetVisible(false)
    self.siUpgradeEffect:SetEffectName("g1008_genius_up.effect")
    self.siUpgradeEffect:SetEffectScale(VectorUtil.newVector2(7.5, 7.5))

    self.stPropDesc = self:createDescText(self.ltPropDescList, {112/255, 137/255, 72/255, 1})
    self.stCurProp = self:createDescText(self.ltCurPropList, {112/255, 137/255, 72/255, 1})
    self.stNextProp = self:createDescText(self.ltNextPropList, {112/255, 137/255, 72/255, 1})

    self.rootSize = self.root:GetPixelSize()
end

---@private
function UITalentDetailLayout:initEvent()
    self.btnOkBtn:registerEvent(GUIEvent.ButtonClick, function()
        if self.buyItemConfig then
            PayHelper.checkMoney(self.buyItemConfig.currency, self.buyItemConfig.price, function(canBuy)
                if canBuy then
                    if self.state == 1 then
                        --解锁
                        SoundUtil.playSound(421)
                        self:hide()
                    else
                        SoundUtil.playSound(422)
                    end
                    PlayerManager:getClientPlayer():sendPacket({
                        pid = "C2STalentUpgrade",
                        talentId = self.buyItemConfig.talentId
                    })
                    if self.unEnoughMoneyFlag then
                        ClientReportEvent.recharge_upgrade_talent(self.talentId)
                    end
                    self.unEnoughMoneyFlag = false
                else
                    self.unEnoughMoneyFlag = true
                end
            end)
        end
    end)

    self:registerEvent(Events.TalentUpgradeSuccess, function(talentData, isUnlock)
        if isUnlock then
            return
        end
        self:refreshData()
        self.siUpgradeEffect:SetVisible(true)
        self.siUpgradeEffect:UnprepareEffect()
        self.siUpgradeEffect:PlayEffect()
    end)

    self.llCloseArea:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)
end

function UITalentDetailLayout:createDescText(parent, textColor)
    local talentDescRoot = UIHelper.newGameGUIWindow("GUITalentDescRoot", parent, textColor)
    parent:AddItem(talentDescRoot.root)
    return talentDescRoot
end

function UITalentDetailLayout:fixPos(targetRoot)
    self.bgWidth = self.siBg:GetWidth()[2]
    self.bgHeight = self.siBg:GetHeight()[2]
    local targetUIPixelSize = targetRoot:GetPixelSize()
    local targetRect = targetRoot:GetUnclippedOuterRect()
    local targetCenterX = targetRect[1] + (targetRect[3] - targetRect[1]) / 2
    local targetCenterY = targetRect[2] + (targetRect[4] - targetRect[2]) / 2
    local rightDis = self.rootSize.x - targetRect[3]
    local topDis = targetRect[2]
    local bottomDis = self.rootSize.y - targetRect[4]
    local x, y
    if rightDis > self.bgWidth then
        if topDis > self.bgHeight then
            --右上显示
            x = targetCenterX + targetUIPixelSize.x * 0.5
            y = targetCenterY - self.bgHeight + targetUIPixelSize.y * 0.5
            if topDis < self.bgHeight then
                y = y + (self.bgHeight - topDis)
            end
        else
            --右下显示
            x = targetCenterX + targetUIPixelSize.x * 0.5
            y = targetCenterY - targetUIPixelSize.y * 0.5
            if bottomDis < self.bgHeight then
                y = y - (self.bgHeight - bottomDis)
            end
        end
    elseif rightDis < self.bgWidth then
        if topDis > self.bgHeight then
            --左上显示
            x = targetCenterX - self.bgWidth + targetUIPixelSize.x * 0.5
            y = targetCenterY - self.bgHeight
            if topDis < self.bgHeight then
                y = y + (self.bgHeight - topDis)
            end
        else
            --左下显示
            x = targetCenterX - self.bgWidth - targetUIPixelSize.x * 0.5
            y = targetCenterY - targetUIPixelSize.y * 0.5
            if bottomDis < self.bgHeight then
                y = y - (self.bgHeight - bottomDis)
            end
        end
    end
    self.siBg:SetXPosition({ 0, x })
    self.siBg:SetYPosition({ 0, y })
end

function UITalentDetailLayout:isEnoughMoney(type, price)
    local money = PlayerWallet.getMoneyByCoinId(type)
    if type == CurrencyId.GCube or type == CurrencyId.Diamonds then
        money = money + PlayerWallet.getMoneyByCoinId(CurrencyId.GameCashCoupon)
    end
    return money >= price
end

function UITalentDetailLayout:getUnlockStr(talentConfig)
    local str = Lang:getString("gui.unlock.condition.tips")
    str = str .. "\n"
    local unlockCond = talentConfig.unlockCond
    for _, v in pairs(unlockCond) do
        local talentCfg = TalentConfig:getTalentCfg(v.talentId, v.level)
        if talentCfg then
            str = str .. Lang:getString(talentCfg.name) .. "  Lv." .. v.level .. "\n"
        end
    end
    return str
end

function UITalentDetailLayout:setMaxLevelContent()
    self.stMax:SetVisible(true)
    self.siBg:SetHeight({ 0, 405 })
    self.siPropDescBg:SetVisible(true)
end

function UITalentDetailLayout:setUpgradeContent()
    self.btnOkBtn:SetText(Lang:getString("gui.talent.upgrade"))
    self.siBg:SetHeight({ 0, 616 })
    self.llBtnContent:SetYPosition({0, -45})
    self.llBtnContent:SetVisible(true)
    self.llUpgradeContent:SetVisible(true)
    self.stCurProp:SetText(self:getPropDesc(self.curTalentConfig.desc, self.curTalentConfig.effectId))
    local nextLevelConfig = TalentConfig:getTalentNextLevel(self.talentId, self.curTalentConfig.level)
    if nextLevelConfig then
        self.buyItemConfig = nextLevelConfig
        self.stNextProp:SetText(self:getPropDesc(self.curTalentConfig.desc, nextLevelConfig.effectId))
        self.stCurrencyPrice:SetText(nextLevelConfig.price)
        if self:isEnoughMoney(nextLevelConfig.currency, nextLevelConfig.price) then
            self.btnOkBtn:SetPushedImage("set:talent.json image:btn_0_unlock02")
            self.btnOkBtn:SetNormalImage("set:talent.json image:btn_0_unlock02")
        else
            self.btnOkBtn:SetPushedImage("set:talent.json image:btn_0_unlock01")
            self.btnOkBtn:SetNormalImage("set:talent.json image:btn_0_unlock01")
        end
    end
end

function UITalentDetailLayout:setUnlockContent()
    self.siPropDescBg:SetVisible(true)
    self.siBg:SetHeight({ 0, 495 })
    self.btnOkBtn:SetText(Lang:getString("gui.talent.unlock"))
    self.llBtnContent:SetVisible(true)
    self.llBtnContent:SetYPosition({0, -55})
    self.stCurrencyPrice:SetText(self.curTalentConfig.price)
    self.buyItemConfig = self.curTalentConfig
    if self:isEnoughMoney(self.curTalentConfig.currency, self.curTalentConfig.price) then
        self.btnOkBtn:SetPushedImage("set:talent.json image:btn_0_unlock02")
        self.btnOkBtn:SetNormalImage("set:talent.json image:btn_0_unlock02")
    else
        self.btnOkBtn:SetPushedImage("set:talent.json image:btn_0_unlock01")
        self.btnOkBtn:SetNormalImage("set:talent.json image:btn_0_unlock01")
    end
end

function UITalentDetailLayout:setLockContent()
    self.siPropDescBg:SetVisible(true)
    self.siBg:SetHeight({ 0, 495 })
    self.stUnlockCondition:SetVisible(true)
    self.stUnlockCondition:SetText(self:getUnlockStr(self.curTalentConfig))
end

function UITalentDetailLayout:resetUI()
    self.stUnlockCondition:SetVisible(false)
    self.llBtnContent:SetVisible(false)
    self.stMax:SetVisible(false)
    self.llUpgradeContent:SetVisible(false)
    self.siPropDescBg:SetVisible(false)
    self.buyItemConfig = nil
    self.state = 0
end

function UITalentDetailLayout:refreshData()
    self:resetUI()
    local isUnlockTalent = CTalentController:isUnlockTalent(self.talentId)
    local isGiftTalent = TalentConfig:isGiftTalent(self.talentId)
    if not isUnlockTalent then
        --没有解锁默认显示1级天赋
        self.curTalentConfig = CTalentController:getTalentConfigByLevel(self.talentId, 1)
    else
        --获取当前当等级的天赋配置
        self.curTalentConfig = CTalentController:getCurTalentConfig(self.talentId)
    end
    if self.curTalentConfig then
        self.siCurrencyIcon:SetImage(PayHelper.getMoneyIcon(Define.Money.TALENT_ESSENCE))
        self.siIcon:SetImage(self.curTalentConfig.detailIcon)
        self.stLevel:SetVisible(not isGiftTalent)
        if isGiftTalent then
            local rewardId = self.curTalentConfig.unlockRewardId
            local rewardCfg = RewardConfig.findRewardById(rewardId)
            if rewardCfg then
                self.awRewardActor:SetVisible(true)
                --RewardItemShowDetailConfig:showActorSkill(self.awRewardActor, rewardCfg.ShowDetail)
                self:showActor(rewardCfg.ShowDetail)
            else
                self.awRewardActor:SetVisible(false)
            end
            if isUnlockTalent then
                --礼物天赋已解锁
                self.stPropDesc:SetText(Lang:getString("gui.talent.desc03.199903"))
            else
                self.stPropDesc:SetText(Lang:getString(self.curTalentConfig.desc))
            end
        else
            self.awRewardActor:SetVisible(false)
            self.stPropDesc:SetText(self:getPropDesc(self.curTalentConfig.desc, self.curTalentConfig.effectId))
        end
        self.stName:SetText(Lang:getString(self.curTalentConfig.name))
        self.stLevel:SetText("Lv." .. self.curTalentConfig.level)
        if isUnlockTalent then
            --已解锁
            if not CTalentController:canUpgrade(self.talentId) then
                --满级
                self:setMaxLevelContent()
            else
                --升级
                self:setUpgradeContent()
                self.state = 2
            end
        else
            --未解锁
            if CTalentController:isNextConditionsMet(self.talentId) then
                --满足解锁条件
                self:setUnlockContent()
                self.state = 1
            else
                --不满足解锁条件
                self:setLockContent()
            end
        end
    end
end

function UITalentDetailLayout:showActorSkillPool(skillNamePool)
    if self.animTimer then
        LuaTimer:cancel(self.animTimer)
        self.animTimer = nil
    end
    local skillName = skillNamePool[math.random(1, #skillNamePool)]
    local actorObj = self.awRewardActor:GetActor()
    if not actorObj then
        error(" find error actor: UITalentDetailLayout:showActorSkillPool "..tostring(skillName))
        return
    end
    if not actorObj:getHasInited() then
        self.animTimer = LuaTimer:schedule(function()
            self:showActorSkillPool(skillNamePool)
        end, 50)
        return
    end
    local skillTime = self.awRewardActor:GetActor():GetSkillTimeLength(skillName, self.awRewardActor:GetActorName())
    if skillTime == 0 then
        self.animTimer = LuaTimer:schedule(function()
            self:showActorSkillPool(skillNamePool)
        end, 50)
        return
    end
    self.awRewardActor:PlaySkill("")
    self.awRewardActor:PlaySkill(skillName)
    self.animTimer = LuaTimer:schedule(function()
        self:showActorSkillPool(skillNamePool)
    end, skillTime)
end

function UITalentDetailLayout:showActor(detailConfig)
    if self.bodyTimer then
        LuaTimer:cancel(self.bodyTimer)
        self.bodyTimer = nil
    end
    self.awRewardActor:SetActor1(detailConfig.actor, "", detailConfig.actorRotate)
    self.awRewardActor:SetRotateX(detailConfig.actorXRotate)
    self.awRewardActor:SetActorScale(0.8)

    for index, actorBody in pairs(detailConfig.actorBody) do
        if detailConfig.actorBodyId[index] then
            self.awRewardActor:UseBodyPart(actorBody, "")
        end
    end

    self.bodyTimer = LuaTimer:schedule(function()
        for index, actorBody in pairs(detailConfig.actorBody) do
            if detailConfig.actorBodyId[index] then
                self.awRewardActor:UseBodyPart(actorBody, detailConfig.actorBodyId[index] or "")
            end
        end
    end, detailConfig.actorBodyDelay)
    if self.animTimer then
        LuaTimer:cancel(self.animTimer)
        self.animTimer = nil
    end
    if detailConfig.actorShowSkill ~= "#" then
        local actorObj = self.awRewardActor:GetActor()
        if not actorObj then
            error("find error actor: showActorSkillPool:showActorSkill "..tostring(detailConfig.actorShowSkill))
            return
        end
        if not actorObj:getHasInited() then
            self.animTimer = LuaTimer:schedule(function()
                self:showActor(detailConfig)
            end, 50)
            return
        end
        local showSkillTime = self.awRewardActor:GetActor():GetSkillTimeLength(detailConfig.actorShowSkill, self.awRewardActor:GetActorName())
        if showSkillTime == 0 then
            self.animTimer = LuaTimer:schedule(function()
                self:showActor(detailConfig)
            end, 50)
            return
        end
        self.awRewardActor:PlaySkill("")
        self.awRewardActor:PlaySkill(detailConfig.actorShowSkill)
        self.animTimer = LuaTimer:schedule(function()
            self:showActorSkillPool(detailConfig.actorIdleSkillPool)
        end, showSkillTime)
    else
        self:showActorSkillPool(detailConfig.actorIdleSkillPool)
    end
end

function UITalentDetailLayout:onTick()
    local newCount = PlayerWallet.getMoneyByCoinId(Define.Money.TALENT_ESSENCE)
    if self.oldCurrencyCount ~= newCount then
        self.oldCurrencyCount = newCount
        if self.unEnoughMoneyFlag then
            self:refreshData()
        end
    end
end

function UITalentDetailLayout:onShow(targetRoot, talentId)
    self.unEnoughMoneyFlag = false
    self.talentId = talentId
    self:refreshData()
    self:fixPos(targetRoot)
end

function UITalentDetailLayout:onHide()
    if self.animTimer then
        LuaTimer:cancel(self.animTimer)
        self.animTimer = nil
    end
    if self.bodyTimer then
        LuaTimer:cancel(self.bodyTimer)
        self.bodyTimer = nil
    end
    self.siUpgradeEffect:SetVisible(false)
end

function UITalentDetailLayout:getPropDesc(desc, effectId)
    local imbueCfg = ImbueClassSetting:getImbueById(effectId)
    if not imbueCfg then
        return ""
    end
    local func = DescFunc[imbueCfg.imbueType]
    local str
    if not func then
        str = Lang:format(desc, self:fixShowVal(imbueCfg.values[1]),
                self:fixShowVal(imbueCfg.values[2]),
                self:fixShowVal(imbueCfg.values[3]),
                self:fixShowVal(imbueCfg.values[4]))
    else
        str = func(desc, imbueCfg.values)
    end
    return str or ""
end

function UITalentDetailLayout:fixShowVal(value)
    if not value or value == 0 then
        return ""
    else
        return value * 0.01
    end
end

return UITalentDetailLayout
