---@type GameTeam
local GameTeam = require "game.data.GameTeam"
---@type RecentPlayUtil
local RecentPlayUtil = T(Global, "RecentPlayUtil")
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")
---@type SRankUtil
local SRankUtil = T(Global, "SRankUtil")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type SGameLicense
local SGameLicense = T(Global, "SGameLicense")
---@type SGamePass
local SGamePass = T(Global, "SGamePass")
---@type TaskUtil
local TaskUtil = T(Global, "TaskUtil")
---@type GameStateReport
local GameStateReport = T(Global, "GameStateReport")
---@type GainsConfig
local GainsConfig = T(Global, "GainsConfig")
---@type GameMsgServer
local GameMsgServer = T(Global, "GameMsgServer")
---@type BackHallManager
local BackHallManager = T(Global, "BackHallManager")
---@type ReconnectUtil
local ReconnectUtil = T(Global, "ReconnectUtil")
---@class GameMatch
GameMatch = {}
GameMatch.Status = {
    WaitingPlayer = 1,
    GameRunning = 2,
    GameOver = 3,
}
---@type GameTeam[]
GameMatch.Teams = {}
GameMatch.curStatus = GameMatch.Status.WaitingPlayer
GameMatch.startServerTime = os.time()
GameMatch.startGameTime = os.time()
GameMatch.startGamePlayer = 0

local checkDisconnectInterval = 30
local maxDisconnectTime = 15

function GameMatch:init()
    isGameStart = false
    isGameEnd = false
    ---init teams
    local teams = TeamConfig:getTeams()
    for _, config in pairs(teams) do
        local team = GameTeam.new(config, TeamColor:getTeamColor(config.id))
        GameMatch.Teams[config.id] = team
    end
    WaitingPlayerTask:start()
    TreasureChallenge:setSeasonRefreshTimer()
    GameMatch.startServerTime = os.time()
    GameStateReport:reportGameInit()
end

---创建出未成功登陆的AI玩家暂时先代替玩家
function GameMatch:createUnLoginPlayerAI()
    local infoList = GameInfoManager:getAllPlayerInfo()
    for userId, info in pairs(infoList) do
        userId = tonumber(userId)
        if not PlayerManager:getPlayerByUserId2(userId) and PlayerManager:getPlayerCount2() < PlayerManager:getRoomMaxPlayer() then
            local attr = GameServer:getRoomManager():getUserAttrInfo(userId)
            if attr then
                local teamId = info:getValue("teamId", true)
                AITeamManager:newAi(0, teamId, userId, attr.name)
            end
        end
    end
end

function GameMatch:startMatch()
    ServerHelper.putBoolPrefs("DisableRemovePlayer", true)
    isGameStart = true
    self.curStatus = GameMatch.Status.GameRunning
    self.startGameTime = os.time()
    self.startGamePlayer = SettlementManager:getPlayerCount()
    self.startAIPlayer = 0
    TaskUtil:initTeamPlayWithRecord()
    for _, player in pairs(PlayerManager:getPlayers()) do
        if PlayerManager:isAIPlayer(player) then
            self.startAIPlayer = self.startAIPlayer + 1
        end
    end

    self:createUnLoginPlayerAI()
    ---调整队伍
    GameInfoManager.Instance():adjustTeam()
    ---不让玩家进入
    HostApi.sendStartGame(PlayerManager:getPlayerCount())
    GainsConfig:onGameStart()
    GameStore:updateTabStatus()
    local players = PlayerManager:getPlayers2()
    for _, player in pairs(players) do
        player:setShowName(player:buildShowName())
        ---回满血
        player:setHealth(player:getMaxHealth())
        player:sendPacket({
            pid = "SyncStartGameTime",
            startGameTime = self.startGameTime
        })
        if player:checkReady() then
            player:onSpawnInGame(Define.INIT_PLAYER_ITEM_TYPE.GAME_START)
            CommonPacketSender:sendGameStart(player)
            GamePacketSender:sendGameConfig(player)
            if PersonalTitleHelper then
                PersonalTitleHelper:showCurrTitle(player)
            end
        end
        CreditScoreUtil:onMatchStart(player, self.startGameTime)
        Plugins.CallTargetPluginFunc("imbue", "onPlayerReady", player)
        --ServerReportEvent.match_room(player)
    end

    RewardManager:startGame()
    RecentPlayUtil:recordGamePlayer()

    if GameMatch:getLifeTeams() <= 1 then
        GameMsgServer:sendSystemTipToAll(IMessages:msgGameOverByLittle())
        self:endMatch()
    else
        GameMsgServer:sendSystemTipToAll(IMessages:msgGameStart())
        GameTimeTask:start()
    end

    PropBlockConfig:createBedProtect()

    if PlayerManager:getPlayerCount() ~= 16 or GameConfig.startPlayers ~= 16 or SettlementManager:getPlayerCount() ~= 16 then
        print("PlayerManager:getPlayerCount()", PlayerManager:getPlayerCount())
        print("GameConfig.startPlayers", GameConfig.startPlayers)
        print("SettlementManager:getPlayerCount()", SettlementManager:getPlayerCount())
    end
   
end

function GameMatch:endMatch()
    isGameEnd = true
    if GameConfig and GameConfig.gameTime then
        HostApi.log("endMatch " .. GameConfig.gameTime)
    end
    self.curStatus = GameMatch.Status.GameOver
    GameTimeTask:pureStop()

    local finalWin = true
    local winner = 0

    if GameMatch:getLifeTeams() > 1 then
        finalWin = false
    end

    local winTeam

    for _, team in pairs(self.Teams) do
        if finalWin and team:isDeath() == false then
            winTeam = team
            winner = team.id
        end
    end
    SettlementManager:updateFinalSettlement(winner)

    if finalWin and winTeam ~= nil then
        local players = PlayerManager:getPlayers()
        for _, player in pairs(players) do
            GameMsgServer:sendSystemTipToPlayer(player.userId, IMessages:msgWinnerInfo(winTeam:getDisplayName(player:getLanguage())))
            if player.teamId == winner then
                SurveyManager:onGameEnd(player)
            end
        end
    else
        GameMsgServer:sendSystemTipToAll(IMessages:msgNoWinner(1))
    end
    AIManager:onGameOver()
    HostApi.sendPlaySound(0, 10003)
    GameOverTask:start()
    ServerReportEvent.server_game_end()
end

function GameMatch:cleanPlayer()
    self:doReport()
    ---@type GamePlayer[]
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        BackHallManager:addPlayer(player)
    end
end

function GameMatch:doReport()
    ---@type GamePlayer[]
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        player:onQuit()
    end
    SRankUtil:tryReport()
    GameServer:closeServer()
end

function GameMatch:getLifeTeams()
    local lifeTeam = 0
    for _, team in pairs(self.Teams) do
        if team:isDeath() == false then
            lifeTeam = lifeTeam + 1
        end
    end
    return lifeTeam
end

function GameMatch:getRealLifeTeams()
    local lifeTeam = 0
    for _, team in pairs(self.Teams) do
        if team.realLife then
            lifeTeam = lifeTeam + 1
        end
    end
    return lifeTeam
end

function GameMatch:ifGameOver()
    if not isGameStart or isGameEnd then
        return
    end
    local lifeTeam = self:getLifeTeams()
    if lifeTeam <= 1 then
        self:endMatch()
    end
end

local function getRespawnTime(player)
    local setting = RespawnConfig:getKeepItemSetting(1)
    local time = setting.Time
    if not Privilege.checkHavePrivilege(player, Define.PrivilegeType.Respawn) then
        local subSpawnTimeRate = math.max((1 - player.info:getValue("subSpawnTimeRate", true)), 0)
        time = (time - player.info:getValue("runeSubSpawnTime", true)) * subSpawnTimeRate
        time = math.max(time, GameConfig.minRespawnTime or 2)
    end
    return time
end

---@param player GamePlayer
function GameMatch:onPlayerDie(player)
    player.isKeepItem = false
    player.canRebirthWithoutBed = false
    if not player.team or not player.isLife then
        return
    end
    Plugins.CallTargetPluginFunc("imbue", "onPlayerDie", player)
    if player.team.isHaveBed then
        if not player.isKeepItem then
            RespawnPrivilege:onShowBuyKeepItem(player)
        else
            local time = getRespawnTime(player)
            HostApi.sendKeepItemAndReviveCountDown(player.rakssid, time, 1)
            RespawnHelper.addRespawnCountdown(player, time)
        end
        return
    end
    player.realLife = false
    if player.team:getRealLifePlayerCount() == 0 and not player.canRebirthWithoutBed then
        ---没有队友存活，直接死亡，同时杀死弹出弹窗等待复活中的对友
        for _, teammate in pairs(player.team.playerList) do
            teammate:onDie()
        end
    else
        ---有队友存活，弹出购买复活弹窗
        local ai = AIManager:getAIByRakssid(player.rakssid)
        if ai ~= nil then
            ---AI不选择复活
            ai.luaPlayer:onDie()
        else
            if player.isDisconnect then
                ---掉线直接选择死亡
                player:onDie()
            else
                if player.canRebirthWithoutBed then
                    local time = getRespawnTime(player)
                    HostApi.sendKeepItemAndReviveCountDown(player.rakssid, time, 1)
                    RespawnHelper.addRespawnCountdown(player, time)
                else
                    RespawnPrivilege:onShowBuyRespawn(player)
                end
            end
        end
    end
    GameMatch:ifGameOver()
end

---@param player GamePlayer
function GameMatch:onPlayerQuit(player)
    RecentPlayUtil:updateRecentPlayRecord(player)
    QualifyingHelper:onPlayerLogout(player)
    TreasureChallenge:onPlayerLogout(player)
    SGameLicense:onPlayerLogout(player)
    SGamePass:onPlayerLogout(player)
    player:onLogout()
    player:onQuit()
    local ai = AIManager:getAIByRakssid(player.rakssid)
    if ai then
        ai:onLogout()
    end
end

function GameMatch:checkInArea()
    if not GameConfig.MovementArea then
        return
    end
    local players = PlayerManager:getPlayers2()
    ---@param player GamePlayer
    for _, player in pairs(players) do
        if not player:isDead() and not GameConfig.MovementArea:inArea(player:getPosition()) then
            ---提示
            GameMsgServer:sendSystemTipToPlayer(player.userId, Messages:msgOutOfArea())
            player:subHealth(GameConfig.outOfAreaHurt)
        end
    end
end

function GameMatch:checkDisconnectPlayer(ticks)
    if not isGameStart or isGameEnd then
        return
    end
    if ticks % checkDisconnectInterval == 0 then
        local droppedPlayers = ReconnectUtil:getDroppedPlayers()
        for _, player in pairs(droppedPlayers) do
            if player.disconnectTime ~= 0 and os.time() - player.disconnectTime > maxDisconnectTime then
                if player.isLife and player.team and not player.team:isDeath() and not player.team.isHaveBed then
                    local onlineSurvivalCount = player.team:getOnlineSurvivalPlayerCount()
                    if onlineSurvivalCount == 0 then
                        player:subHealth(9999)
                    end
                end
            end
        end
    end
end

return GameMatch

--endregion
