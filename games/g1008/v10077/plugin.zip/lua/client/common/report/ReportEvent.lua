
---@param event number event [event name]
---@param event_map table event_map [eg {key1 = value1,key2 = value2, ...}]
local function newDesign(event, event_map)
    if isTest then
        local Message = ""
        Message = Message .. " event : " .. tostring(event)
        for key, value in pairs(event_map) do
            Message = Message .. "  ||  key: " .. key .. "   value : " .. tostring(value)
        end
        UIHelper.showToast(Message, 5000)
    end
    GameAnalytics:newDesign(event, event_map)
end

---@class ClientReportEvent
local ReportEvent = {}

---@param buttonId number
function ReportEvent.click_activity_page_button(buttonId)
    newDesign("click_activity_page_button", { buttonId = buttonId })
end

---@param buttonId number
function ReportEvent.click_main_button(buttonId)
    newDesign("click_main_button", { buttonId = buttonId })
end

---@param buttonId number
function ReportEvent.click_Mode_button(buttonId)
    newDesign("click_Mode_button", { buttonId = buttonId })
end

---@param buttonId number
function ReportEvent.click_chat_button(buttonId)
    newDesign("click_chat_button", { buttonId = buttonId })
end

---@param type number
function ReportEvent.send_chat_text(type)
    newDesign("send_chat_text", { type = type })
end

---@param type number
function ReportEvent.send_chat_emoji(type)
    newDesign("send_chat_emoji", { type = type })
end

ClientReportEvent = ReportEvent
