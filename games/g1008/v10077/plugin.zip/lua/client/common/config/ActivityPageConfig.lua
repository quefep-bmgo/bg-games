---@type ActivityPageData[]
local ConfigList = {}

local function isInTimeRange(starTime, endTime)
    local nowNum = os.time(os.date("*t"))
    if nowNum >= starTime and nowNum < endTime then
        return true
    end
    return false
end

local function init()
    local settings = FileUtil.getConfigFromCsv("common/ActivityPageConfig.csv", 3, true)
    for _, item in pairs(settings) do
        ---@class ActivityPageData
        local data = {}
        data.startTime, data.endTime = 0, -1
        if item.startDate ~= "#" then
            local _, _, year, month, day, hour, min, sec = string.find(item.startDate, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
            data.startTime = DateUtil.date2BeiJingTime({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
        end
        if item.endDate ~= "#" then
            local _, _, year, month, day, hour, min, sec = string.find(item.endDate, "(%d+)-(%d+)-(%d+)-(%d+)-(%d+)-(%d+)")
            data.endTime = DateUtil.date2BeiJingTime({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
        end
        data.id = tonumber(item.id)
        data.sort = tonumber(item.sort)
        data.uiJson = item.uiJson .. ".json"
        data.imageset = item.imageset
        data.textOffset = StringUtil.split(item.textOffset, "#")
        data.closeOffset = StringUtil.split(item.closeOffset, "#")
        if isInTimeRange(data.startTime, data.endTime) then
            table.insert(ConfigList, data)
        end
    end
    table.sort(ConfigList, function(a, b)
        return a.sort < b.sort
    end)
end

init()
return ConfigList

