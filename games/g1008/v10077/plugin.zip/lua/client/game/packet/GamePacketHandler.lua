---@class GamePacketHandler : EventObservable
local handler = class("GamePacketHandler", EventObservable)

Trigger = {}
Trigger.isFirstOpen = true

function handler:init()
    self:registerDataCallBack("OpenLottery", self.onOpenLottery)
    self:registerDataCallBack("MoveLimitCheck", self.onMoveLimitCheck)

    self:registerDataCallBack("LotteryResult", function(data)
        self.onLotteryResult(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("LotteryRefreshResult", function(data)
        self.onLotteryRefreshResult(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("playSound", function(data)
        local type = data:getNumberParam("type")
        SoundUtil.playSound(type)
    end, DataBuilderProcessor)

    self:registerDataCallBack("playSound3d", function(data)
        local type = data:getNumberParam("type")
        local x = data:getNumberParam("x")
        local y = data:getNumberParam("y")
        local z = data:getNumberParam("z")
        SoundUtil.playSound3D(type, x, y, z)
    end, DataBuilderProcessor)

    self:registerDataCallBack("ResourceUpgrade", function(pointId)
        self.onResourceUpgrade(pointId)
    end)

    self:registerDataCallBack("PlayerMotionData", function(data)
        self.onPlayerMotionData(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("IsEquipNinjaShoes", function(data)
        self.isEquipNinjaShoes(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("PlayerIntoTeamResource", function(data)
        self.onPlayerIntoTeamResource(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("NotPlayerTeamResource", function(data)
        self.onNotPlayerIntoTeamResource(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("ShowSurvey", function()
        self.onShowSurvey()
    end)
end

function handler.onLotteryResult(data)
    local rewardId = data:getNumberParam("rewardId")
    local price = data:getNumberParam("price")
    local seq = data:getNumberParam("seq")
    GUILottery:onGetReward(rewardId, price, seq)
end

function handler.onLotteryRefreshResult(data)
    local result = data:getParam("reward")
    local refreshPrice = data:getNumberParam("refreshPrice")
    local lotteryPrice = data:getNumberParam("lotteryPrice")
    GUILottery:onGetRefreshResult(result, refreshPrice, lotteryPrice)
end

function handler.onOpenLottery()
    if Trigger.isFirstOpen then
        GamePacketSender:sendBedWarLotteryRefresh()
        Trigger.isFirstOpen = false
    end
    GUIBedWarToolBar:onLotteryBtn()
end

function handler.onMoveLimitCheck(data)
    local builder = DataBuilder.new():fromData(data)
    ClientHelper.putIntPrefs("RunLimitCheck", builder:getNumberParam("runLimitCheck"))
    ClientHelper.putIntPrefs("SprintLimitCheck", builder:getNumberParam("sprintLimitCheck"))
end

function handler.onResourceUpgrade(pointId)
    if ResourcePointConfig == nil then
        LuaTimer:schedule(function()
            handler.onResourceUpgrade(pointId)
        end, 100)
        return
    end
    ResourcePointConfig:UpgradeResource(pointId)
end

function handler.onPlayerMotionData(data)
    local player = Game:getPlayer()
    local motion = data:getVector3Param("Motion")
    player.motion = motion
    player.fallDistance = 0
end

function handler.isEquipNinjaShoes(data)
    local isEquip = data:getBoolParam("isEquip")
    local player = PlayerManager:getClientPlayer()
    if player and player.Player then
        if isEquip then
            local height = data:getNumberParam("height")
            player.Player:setFloatProperty("JumpHeight", height)
            player.doubleJumpCount = 2
        else
            player.Player:setFloatProperty("JumpHeight", 0.42)
            player.doubleJumpCount = 1
        end
    end
end

function handler.onPlayerIntoTeamResource(data)
    local userId = data:getParam("userId")
    local pointId = data:getNumberParam("pointId")
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    ResourcePointConfig:onPlayerIntoTeamResource(player:getEntityId(), pointId)
end

function handler.onNotPlayerIntoTeamResource(data)
    local pointId = data:getNumberParam("pointId")
    ResourcePointConfig:onNotPlayerIntoResource(pointId)
end

function handler.onShowSurvey()
    if GUIBedWarSurvey then
        GUIBedWarSurvey:show(true)
    end
end

handler:init()