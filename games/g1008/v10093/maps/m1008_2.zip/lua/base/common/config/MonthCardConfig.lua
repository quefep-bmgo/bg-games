---@class MonthCardConfig
local MonthCardConfig = T(Global, "MonthCardConfig")

---@type MonthCardConfigData[]
local settings = {}

function MonthCardConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/MonthCard.csv", 3)
    for _, item in pairs(config) do
        ---@class MonthCardConfigData
        local data = {
            id = tonumber(item.Id),
            price = tonumber(item.Price),
            time = tonumber(item.Time),
            rewardItemId = tonumber(item.RewardItemId),
            rewardItemNum = tonumber(item.RewardItemNum),
            percent = item.Percent,
        }
        settings[data.id] = data
    end
end

function MonthCardConfig:getAllCfg()
    return settings
end

---@return MonthCardConfigData
function MonthCardConfig:getCfgById(id)
    return settings[tonumber(id)]
end

MonthCardConfig:init()