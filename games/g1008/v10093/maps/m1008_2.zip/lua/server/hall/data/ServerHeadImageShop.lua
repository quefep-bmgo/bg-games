---@class ServerHeadImageShop
local HeadImageShop = T(Global, "HeadImageShop")
---@type HeadImageShopConfig
local HeadImageShopConfig = T(Global, "HeadImageShopConfig")
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

local function checkPlayerAndHeadImage(userId, goodsId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local goods = HeadImageShopConfig:getShopConfigById(goodsId)
    if not goods then
        return
    end
    return player, goods
end

function HeadImageShop:init()
    EventObservable:registerDataCallBack("BuyHeadImage", function(userId, goodsId)
        local player, goods = checkPlayerAndHeadImage(userId, goodsId)
        if not player then
            return
        end
        self:onBuyHeadImage(player, goods)
    end)

    EventObservable:registerDataCallBack("EquipHeadImage", function(userId, goodsId)
        local player, goods = checkPlayerAndHeadImage(userId, goodsId)
        if not player then
            return
        end
        self:onEquipHeadImage(player, goods)
    end)
end

HeadImageShop:init()

function HeadImageShop:onSyncPlayerAllGoods(player)
    local allCfg = HeadImageShopConfig:getShopAllConfigs()
    for i, cfg in pairs(allCfg) do
        if cfg.Id ~= 0 and cfg.IsFree == 1 then
            if not TableUtil.tableContain(player.headImageData, cfg.RewardId) then
                table.insert(player.headImageData, tonumber(cfg.RewardId))
            end
        end
    end
    if TableUtil.getTableSize(player.headImageData) > 0 then
        GamePacketSender:sendHeadImageDataData(player.rakssid, TableUtil.copyTable(player.headImageData))
    end
end

function HeadImageShop:hasHeadImage(player, rewardId)
    for i, reward in ipairs(player.headImageData) do
        if reward == tonumber(rewardId) then
            return true
        end
    end
    return false
end

function HeadImageShop:onBuyHeadImageSuccess(player, rewardId)
    if TableUtil.tableContain(player.headImageData, rewardId) then
        ---已拥有
        return
    end
    table.insert(player.headImageData, tonumber(rewardId))
    GamePacketSender:sendBuyHeadImageSuccess(player.rakssid, rewardId)
end

function HeadImageShop:onRemoveImageImage(player, rewardId)
    if not TableUtil.tableContain(player.headImageData, rewardId) then
        ---未拥有
        return
    end
    for index, _rewardId in pairs(player.headImageData or {}) do
        if _rewardId == tonumber(rewardId) then
            table.remove(player.headImageData, index)
            break
        end
    end
    PlayerCustomInfoUtil:reportCustomInfo(player.userId, "int", Define.PlayerCustomInfo.CurHeadImage, 0, "2")
    self:onEquipHeadImageSuccess(player, 0)
    GamePacketSender:sendRemoveHeadImage(player.rakssid, rewardId)
end

function HeadImageShop:onBuyHeadImage(player, goods)
    if goods.Price <= 0 then
        return
    end
    local reward = RewardConfig:getRewardById(tonumber(goods.RewardId))
    if not reward then
        return
    end

    if TableUtil.tableContain(player.headImageData, reward.RewardId) then
        ---已拥有
        return
    end

    if not MoneyUtil:checkHasMoney(player, goods.CoinId, goods.Price) then
        return
    end

    PayHelper.payDiamondsSync(player.userId, goods.Id, goods.Price, function()
        self:onBuyHeadImageSuccess(player, reward.RewardId)
        return true
    end)
end

function HeadImageShop:onEquipHeadImage(player, goods)
    if goods.Default then
        PlayerCustomInfoUtil:reportCustomInfo(player.userId, "int", Define.PlayerCustomInfo.CurHeadImage, 0, "2")
        self:onEquipHeadImageSuccess(player, 0)
        return
    end
    local reward = RewardConfig:getRewardById(tonumber(goods.RewardId))
    if not reward then
        return
    end
    if not TableUtil.tableContain(player.headImageData, reward.RewardId) then
        return
    end
    local CurHeadImage = reward.RewardId
    PlayerCustomInfoUtil:reportCustomInfo(player.userId, "int", Define.PlayerCustomInfo.CurHeadImage, CurHeadImage, "2")
    self:onEquipHeadImageSuccess(player, CurHeadImage)
end

function HeadImageShop:onEquipHeadImageSuccess(player, imageId)
    GamePacketSender:sendEquipHeadImageSuccess(player.rakssid, imageId)
end
