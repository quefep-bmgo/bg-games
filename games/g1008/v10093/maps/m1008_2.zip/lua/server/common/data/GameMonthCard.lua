---@class GameMonthCard
GameMonthCard = {}
---@type MonthCardConfig
local MonthCardConfig = T(Global, "MonthCardConfig")
---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")

function GameMonthCard:init()
    EventObservable:registerDataCallBack("BuyMonthCard", function(userId, cardId)
        local player = PlayerManager:getPlayerByUserId(userId)
        if not player then
            return
        end
        self:onBuyMonthCard(player, cardId)
    end)
end

function GameMonthCard:setDBData(player, data)
    if data and data.monthCard then
        player.monthCard = data.monthCard
    else
        player.monthCard = {}
    end
    self:receiveItem(player, true)
    self:syncPlayerMonthCardData(player)
end

---@param player ServerPlayer
function GameMonthCard:onBuyMonthCard(player, cardId)
    local cardCfg = MonthCardConfig:getCfgById(cardId)
    if not cardCfg then
        return
    end
    local id = cardCfg.id
    local price = cardCfg.price
    local time = cardCfg.time * 3600 * 24
    local remainingDay = 10
    PayHelper.payMoneySync(player, id, CurrencyId.GCube, price, function()
        for i, card in pairs(player.monthCard) do
            if card.id == id then
                if card.endTime < os.time() then
                    card.receiveDayStart = 0    -- 重新续费前，把领取日期设为0，续费后立刻给奖励
                    card.endTime = os.time() + time - (3600 * 24)  -- 重新续费算第一次购买，因为立刻领取了奖励，这里要减少一天
                else
                    -- 月卡剩下10天才能购买
                    local remainingTime = os.time() - card.endTime
                    if remainingTime > 3600 * 24 * remainingDay then
                        return
                    end
                    card.endTime = card.endTime + time
                end
                self:receiveItem(player)
                self:syncPlayerMonthCardData(player)
                ReportEvent.buy_month_card(player.userId, id)
                return
            end
        end
        local data = {
            id = id,
            endTime = os.time() + time - (3600 * 24),  -- 第一次购买，因为立刻领取了奖励，这里要减少一天
            receiveDayStart = 0
        }
        table.insert(player.monthCard, data)
        self:receiveItem(player)
        self:syncPlayerMonthCardData(player)
        ReportEvent.buy_month_card(player.userId, id)
    end)
end

local function getDayStartTime(time)
    local date = os.date("*t", time)
    local dayStartTime = os.time({ year = date.year, month = date.month, day = date.day, hour = 0, min = 0, sec = 0 })
    return dayStartTime
end

local function getDeltaDay(startTime, endTime)
    local deltaDay = (getDayStartTime(endTime) - getDayStartTime(startTime)) / (3600 * 24)
    return math.floor(deltaDay)
end

---@param player ServerPlayer
function GameMonthCard:receiveItem(player, delay)
    local rewardIds = {}
    for _, card in pairs(player.monthCard) do
        local nowDayStart = getDayStartTime(os.time())
        local cardCfg = MonthCardConfig:getCfgById(card.id)
        if cardCfg then
            if not card.receiveDayStart or card.receiveDayStart == 0 then
                card.receiveDayStart = nowDayStart
                local itemId = cardCfg.rewardItemId
                local num = cardCfg.rewardItemNum
                local reward = TableUtil.copyTable(RewardConfig:getRewardById(itemId))
                if reward then
                    reward.Count = num
                    GameReward:onPlayerGetReward(player, reward)
                    rewardIds[tostring(itemId)] = num
                end
            elseif card.receiveDayStart < nowDayStart then
                local calcDay = nowDayStart
                local endTime = card.endTime
                local endTimeDayStart = getDayStartTime(endTime)
                if endTimeDayStart < nowDayStart then
                    calcDay = endTimeDayStart
                end
                local deltaDay = getDeltaDay(card.receiveDayStart, calcDay)
                if deltaDay > 0 then
                    card.receiveDayStart = nowDayStart
                    local itemId = cardCfg.rewardItemId
                    local num = cardCfg.rewardItemNum * deltaDay
                    local reward = RewardConfig:getRewardById(itemId)
                    if reward then
                        reward.Count = num
                        GameReward:onPlayerGetReward(player, reward)
                        rewardIds[tostring(itemId)] = num
                    end
                end
            end
        end
    end

    if next(rewardIds) then
        local data = {
            rewardIds = rewardIds,
            delay = delay
        }
        CommonPacketSender:sendMonthCardReceive(player.rakssid, data)
    end
end

---@param player ServerPlayer
function GameMonthCard:syncPlayerMonthCardData(player)
    CommonPacketSender:sendMonthCardData(player.rakssid, player.monthCard)
end

---@param player ServerPlayer
function GameMonthCard:resetPlayerMonthCardData(player)
    player.monthCard = {}
    self:syncPlayerMonthCardData(player)
end

---@param player ServerPlayer
function GameMonthCard:GMBuyCardAhead(player)
    player.monthCard = {}
    for id = 1, 2 do
        local data = {
            id = id,
            endTime = os.time() + (3600 * 24 * 10),
            receiveDayStart = getDayStartTime(os.time() - (3600 * 24 * 10))
        }
        table.insert(player.monthCard, data)
    end
    self:syncPlayerMonthCardData(player)
end

GameMonthCard:init()