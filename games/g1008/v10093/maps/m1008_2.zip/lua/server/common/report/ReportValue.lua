---@class ServerReportValue
local ValueUtil = {}


---player_login
---player_logout
---player_game_start: map_id
---player_game_end :map_id , is_complete , game_time ,average_fps
---server_game_end : map_id , game_time

---@type GameModeUtil
local GameModeUtil = T(Global, "GameModeUtil")
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")

---@return number
function ValueUtil.match_id()
    return GameServer:getServerConfig().gameId
end

---@return number
function ValueUtil.game_mode()
    return GameModeUtil:getGameMode()
end

---@return number
function ValueUtil.start_ai_count()
    return GameMatch and GameMatch.startAIPlayer or 0
end

---@return number
function ValueUtil.ai_count()
    return GameMatch and GameMatch.startAIPlayer or 0
end

---@return number
function ValueUtil.ai_game()
    return IsAIGame or false
end

---@return number
function ValueUtil.robot_type()
    if RoomGameConfig.robotType then
        return GameServer:getServerConfig().robotType or 0
    end
    return 0
end

---@return number
function ValueUtil.map_id()
    if GameType == "g1046" then
        return 0
    end
    return GameConfig.mapId
end

---@param player GamePlayer
---@return number
function ValueUtil.team_id(player)
    return player.teamId
end

---@param player ServerPlayer
---@return number
function ValueUtil.game_result_type(player)
    return player.gameResultType or Define.GameResult.QUIT
end

---@param player ServerPlayer
---@return number
function ValueUtil.enemy_count(player)
    local enemy_count = 0
    ---@param _player ServerPlayer
    for _, _player in pairs(PlayerManager:getPlayers()) do
        if _player ~= player then
            if _player.teamId ~= player.teamId then
                enemy_count = enemy_count + 1
            end
        end
    end
    return enemy_count
end

---@param player ServerPlayer
---@return number
function ValueUtil.teammate_count(player)
    local teammate_count = 0
    ---@param _player ServerPlayer
    for _, _player in pairs(PlayerManager:getPlayers()) do
        if _player ~= player then
            if _player.teamId == player.teamId then
                teammate_count = teammate_count + 1
            end
        end
    end
    return teammate_count
end
---@param player ServerPlayer
---@return number
function ValueUtil.my_team_average_honor(player)
    if player.my_team_average_honor ~= nil then
        return player.my_team_average_honor
    end
    local teammate_count = 1
    local team_honor = (QualifyingHelper:getPlayerQualifyingScore(player) or 0)
    ---@param _player ServerPlayer
    for _, _player in pairs(PlayerManager:getPlayers()) do
        if _player ~= player then
            if _player.teamId == player.teamId then
                teammate_count = teammate_count + 1
                team_honor = team_honor + (QualifyingHelper:getPlayerQualifyingScore(_player) or 0)
            end
        end
    end
    player.my_team_average_honor = team_honor / teammate_count
    return player.my_team_average_honor
end

---@return string
function ValueUtil.all_team_average_honor(player)
    if GameMatch.all_team_average_honor ~= nil then
        return GameMatch.all_team_average_honor
    end
    local allTeamHonor = {}
    local teamHonorMap = {}
    ---@param _player ServerPlayer
    for _, _player in pairs(PlayerManager:getPlayers()) do
        local teamId = _player.teamId or 0
        if teamHonorMap[teamId] == nil then
            teamHonorMap[teamId] = { players = 0, honor = 0 }
        end
        teamHonorMap[teamId].players = teamHonorMap[teamId].players + 1
        teamHonorMap[teamId].honor = teamHonorMap[teamId].honor + (QualifyingHelper:getPlayerQualifyingScore(_player) or 0)
    end
    for id, teamInfo in pairs(teamHonorMap) do
        local averageHonor = teamInfo.honor / teamInfo.players
        local formatData = { team_id = id, average_honor = averageHonor }
        table.insert(allTeamHonor, formatData)
    end
    GameMatch.all_team_average_honor = json.encode(allTeamHonor)
    return GameMatch.all_team_average_honor
end

---@return number
function ValueUtil.server_running_second()
    if GameType ~= "g1046" then
        return os.time() - GameMatch.startServerTime
    end
    return 0
end

---@return number
function ValueUtil.game_running_second()
    if GameType ~= "g1046" then
        return os.time() - GameMatch.startGameTime
    end
    return 0
end
function ValueUtil.player_running_second(player)
    return os.time() - player.ready_time
end
---@return number
function ValueUtil.player_waiting_second(player)
    if GameType ~= "g1046" then
        return math.max(GameMatch.startGameTime - player.ready_time, 0)
    end
    return 0
end
function ValueUtil.player_running_minute(player)
    return math.floor((os.time() - player.ready_time) / 60)
end
function ValueUtil.minute_average_fps(player)
    return player.minute_average_fps or 0
end
function ValueUtil.minute_min_fps(player)
    return player.minute_min_fps or 0
end
function ValueUtil.minute_max_fps(player)
    return player.minute_max_fps or 0
end
function ValueUtil.total_average_fps(player)
    return player.total_average_fps or 0
end
function ValueUtil.minute_jank(player)
    return player.minute_jank or 0
end
function ValueUtil.minute_average_ping(player)
    return player.minute_average_ping or 0
end
function ValueUtil.minute_min_ping(player)
    return player.minute_min_ping or 0
end
function ValueUtil.minute_max_ping(player)
    return player.minute_max_ping or 0
end
function ValueUtil.total_average_ping(player)
    return player.total_average_ping or 0
end
function ValueUtil.consecutive_login_days(player)
    return player.consecutiveLoginDays
end
function ValueUtil.player_lv(player)
    return player.level
end
function ValueUtil.segment_score(player)
    return QualifyingHelper:getPlayerQualifyingScore(player) or 0
end
function ValueUtil.play_times_g1008(player)
    return player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].play or 0
end
function ValueUtil.win_rate_g1008_d(player)
    local play = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].play or 0
    local win = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].win or 0
    local rate = play > 0 and math.ceil(win / play * 100) or 0
    return rate
end
function ValueUtil.play_times_g1062(player)
    return player.newBattleRecord["g1062"] and player.newBattleRecord["g1062"].play or 0
end
function ValueUtil.win_rate_g1062_d(player)
    local play = player.newBattleRecord["g1062"] and player.newBattleRecord["g1062"].play or 0
    local win = player.newBattleRecord["g1062"] and player.newBattleRecord["g1062"].win or 0
    local rate = play > 0 and math.ceil(win / play * 100) or 0
    return rate
end
function ValueUtil.play_times_g1061(player)
    return player.newBattleRecord["g1061"] and player.newBattleRecord["g1061"].play or 0
end
function ValueUtil.win_rate_g1061_d(player)
    local play = player.newBattleRecord["g1061"] and player.newBattleRecord["g1061"].play or 0
    local win = player.newBattleRecord["g1061"] and player.newBattleRecord["g1061"].win or 0
    local rate = play > 0 and math.ceil(win / play * 100) or 0
    return rate
end
function ValueUtil.ai_game_times(player)
    return player.aiGameRecord.play or 0
end
function ValueUtil.ai_game_win_rate_d(player)
    local play = player.aiGameRecord.play or 0
    local win = player.aiGameRecord.win or 0
    local rate = play > 0 and math.ceil(win / play * 100) or 0
    return rate
end
function ValueUtil.ai_in_last_1(player)
    return #player.lastFiveRecord > 0 and player.lastFiveRecord[1] or false
end
function ValueUtil.ai_in_last_3(player)
    local hasAi = false
    for i, v in pairs(player.lastFiveRecord) do
        if v == true then
            hasAi = true
            break
        end
        if i == 3 then
            break
        end
    end
    return hasAi
end
function ValueUtil.ai_in_last_5(player)
    local hasAi = false
    for i, v in pairs(player.lastFiveRecord) do
        if v == true then
            hasAi = true
            break
        end
        if i == 5 then
            break
        end
    end
    return hasAi
end
function ValueUtil.kill_avg_times_g1008_d(player)
    local play = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].play or 0
    local kill = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].kill or 0
    local avg = play > 0 and math.ceil(kill / play * 100) or 0
    return avg
end
function ValueUtil.die_avg_times_g1008_d(player)
    local play = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].play or 0
    local die = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].die or 0
    local avg = play > 0 and math.ceil(die / play * 100) or 0
    return avg
end
function ValueUtil.kill_avg_times_ai_d(player)
    local play = player.aiGameRecord.play or 0
    local kill = player.aiGameRecord.kill or 0
    local avg = play > 0 and math.ceil(kill / play * 100) or 0
    return avg
end
function ValueUtil.die_avg_times_ai_d(player)
    local play = player.aiGameRecord.play or 0
    local die = player.aiGameRecord.die or 0
    local avg = play > 0 and math.ceil(die / play * 100) or 0
    return avg
end
function ValueUtil.avg_play_time_g1008_d(player)
    local play = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].play or 0
    local time = player.newBattleRecord["g1008"] and player.newBattleRecord["g1008"].time or 0
    local avg = play > 0 and math.ceil(time / play * 100) or 0
    return avg
end
function ValueUtil.avg_play_time_ai_d(player)
    local play = player.aiGameRecord.play or 0
    local time = player.aiGameRecord.time or 0
    local avg = play > 0 and math.ceil(time / play * 100) or 0
    return avg
end
function ValueUtil.is_new(player)
    return player.play_days <= 1
end
function ValueUtil.weekly_segment_score(player)
    return json.encode(player.weeklySegment)
end

function ValueUtil.qualifying_segment(player)
    local data = QualifyingHelper:getPlayerQualifyingData(player)
    if data then
        return data.segment
    end
    return 0
end
function ValueUtil.qualifying_grade(player)
    local data = QualifyingHelper:getPlayerQualifyingData(player)
    if data then
        return data.grade
    end
    return 0
end
function ValueUtil.qualifying_star_number(player)
    local data = QualifyingHelper:getPlayerQualifyingData(player)
    if data then
        return data.starNumber
    end
    return 0
end
--- 是否为定位赛
function ValueUtil.qualifying_is_in_pos_match(player)
    return QualifyingHelper:isInPosMatch(player)
end
--- 本局新增的挑战分
function ValueUtil.qualifying_add_qualifying_score(player)
    return QualifyingHelper:addQualifyingScore(player)
end
--- 本局新增的勇者分
function ValueUtil.qualifying_add_brave_point(player)
    return QualifyingHelper:addBravePoint(player)
end
--- 是否为组队
function ValueUtil.qualifying_is_in_team(player)
    return (player.team == nil and false or true)
end
--- 是否消耗勇者分
function ValueUtil.qualifying_is_consume_brave_score(player)
    return QualifyingHelper:isConsumeBraveScore(player)
end
--- 当前的隐藏分
function ValueUtil.qualifying_hidden_score(player)
    return QualifyingHelper:getPlayerMatchHiddenScore(player)
end
--- 当前的综合分
function ValueUtil.qualifying_score(player)
    return QualifyingHelper:getPlayerQualifyingScore(player)
end
--- 当前勇者分
function ValueUtil.qualifying_brave_points(player)
    return QualifyingHelper:getBravePoints(player)
end
--- 段位变化，当前段位
function ValueUtil.qualifying_segment_grade_star(player)
    local data = QualifyingHelper:getPlayerQualifyingData(player)
    if data then
        return data.segment .. "_" .. data.grade .. "_" .. data.starNumber
    end
    return "0_0_0"
end

--- 连败次数
---@param player SBasePlayer
---@return number
function ValueUtil.g1008_loser_streak(player)
    local info = UserInfoCache:GetCache(player.userId)
    if info then
        return info.loserStreak
    end
    return 0
end

---@param player SBasePlayer
function ValueUtil.total_recharge_cube(player)
    return player:getTotalRecharge()
end

---@param player SBasePlayer
function ValueUtil.have_cube_order(player)
    return player.have_cube_order or false
end

function ValueUtil.cube_count(player)
    return player:getDiamond()
end

function ValueUtil.server_time()
    local nowTime = os.time()
    return nowTime - DateUtil.getDayLastTime(nowTime - DateUtil.getDaySeconds(), true)
end

function ValueUtil.is_reconnect(player)
    return player.isReconnect or false
end

function ValueUtil.is_in_team(player)
    if player.is_in_team ~= nil then
        return player.is_in_team
    end
    player.is_in_team = 0
    if player.dynamicAttr.teamId ~= "" then
        for _, _player in pairs(PlayerManager:getPlayers()) do
            if _player ~= player then
                if _player.dynamicAttr.teamId == player.dynamicAttr.teamId then
                    player.is_in_team = 1
                    break
                end
            end
        end
    end
    return player.is_in_team
end

function ValueUtil.match_time(player)
    return ValueUtil.player_waiting_second(player)
end

function ValueUtil.room_id(player)
    return ValueUtil.match_id()
end

return ValueUtil