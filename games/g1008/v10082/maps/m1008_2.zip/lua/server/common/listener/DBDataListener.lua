---
--- Created by longxiang.
--- DateTime: 2018/11/9  16:15

local DBDataListener = {}

function DBDataListener:init()
    ---@param player GamePlayer
    DBManager:setPlayerDBSaveFunction(function(player, immediate)
        DbUtil:savePlayerData(player, immediate)
    end)
end

DBDataListener:init()
