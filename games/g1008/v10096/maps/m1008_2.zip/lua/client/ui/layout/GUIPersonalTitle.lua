---@class UIPersonalTitleLayout : IGUILayout
local UIPersonalTitleLayout = class("UIPersonalTitleLayout", IGUILayout)
---@type PersonalTitleConfig
local PersonalTitleConfig = T(Global, "PersonalTitleConfig")
---@type TaskOverrideConfig
local TaskOverrideConfig = T(Global, "TaskOverrideConfig")

local currTitle = nil

---@private
function UIPersonalTitleLayout:ctor(parent)
	self.super.ctor(self, "PersonalTitle.json", parent)
end

---@private
function UIPersonalTitleLayout:onLoad()
	self.llBack = self:getChildWindow("PersonalTitle-Back", GUIType.Layout)
	self.siBg = self:getChildWindow("PersonalTitle-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("PersonalTitle-Content", GUIType.Layout)
	self.llInfo = self:getChildWindow("PersonalTitle-Info", GUIType.Layout)
	self.siInfoIcon = self:getChildWindow("PersonalTitle-Info-Icon", GUIType.StaticImage)
	self.siCur = self:getChildWindow("PersonalTitle-Cur", GUIType.StaticImage)
	self.stName = self:getChildWindow("PersonalTitle-Name", GUIType.StaticText)
	self.btnUse = self:getChildWindow("PersonalTitle-Use", GUIType.Button)
	self.stDesc = self:getChildWindow("PersonalTitle-Desc", GUIType.StaticText)
	self.btnClose = self:getChildWindow("PersonalTitle-Close", GUIType.Button)
	self.stTitle = self:getChildWindow("PersonalTitle-Title", GUIType.StaticText)
	self.stGetTimeTxt = self:getChildWindow("PersonalTitle-GetTimeTxt", GUIType.StaticText)
	self.stGetTime = self:getChildWindow("PersonalTitle-GetTime", GUIType.StaticText)
	self.stTaskProgressNum = self:getChildWindow("PersonalTitle-TaskProgressNum", GUIType.StaticText)
	self.siTaskProgressBg = self:getChildWindow("PersonalTitle-TaskProgressBg", GUIType.StaticImage)
	self.siTaskProgressImg = self:getChildWindow("PersonalTitle-TaskProgressImg", GUIType.StaticImage)


	self:initView()
	self:initEvent()
end

---@private
function UIPersonalTitleLayout:onCreate()

end

---@private
function UIPersonalTitleLayout:initView()
	self.lvFrameList = IGUIGridView.new("PersonalTitle-Frame-List", self.llContent)
	self.lvFrameList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.lvFrameList.root:SetHorizontalAlignment(HorizontalAlignment.Left)
	self.lvFrameList.root:SetVerticalAlignment(VerticalAlignment.Top)
	self.lvFrameList:setConfig(0, 0, 2)
	self.lvFrameList.root:SetClipChild(true)
	self.llContent:SetClipChild(true)

	---@type BedWarHeadItemAdapter
	self.frameAdapter = UIHelper.newGameAdapter("BedWarPersonalTitleItemAdapter")
	self.frameAdapter:setItemSize(263, 127)
	self.lvFrameList:setAdapter(self.frameAdapter)

	---@type GUIBedWarPersonalTitleShowItem
	self.showItem = UIHelper.newGameGUIWindow("GUIBedWarPersonalTitleShowItem")
	self.siCur:AddChildWindow(self.showItem.root)

	self.stTitle:SetText(Lang:getString("gui.personal_title.title"))
	self.stGetTimeTxt:SetText(Lang:getString("gui.personal_title.getTime"))
end

---@private
function UIPersonalTitleLayout:initEvent()
	self.btnUse:registerEvent(GUIEvent.ButtonClick, function()
		self:onBtnClick()
	end)

	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		GUIPersonalTitleLayout:hide()
	end)

	self.llBack:registerEvent(GUIEvent.Click, function()
		GUIPersonalTitleLayout:hide()
	end)

	self:registerEvent(Events.PersonalTitleItemSelectEvent, function(id)
		currTitle = id
		self:updateTitleInfo()
	end)

	self:registerEvent(Events.PersonalTitleUpdateUseTitleEvent, function(titleId)
		if currTitle ~= titleId then
			local ownTime = CPersonalTitleHelper:hasTitle(currTitle)
			if ownTime then
				self.btnUse:SetText(Lang:getString("gui.personal_title.use"))
				self.btnUse:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy01")
				self.btnUse:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy01")
			else
				self.btnUse:SetText(Lang:getString("gui.personal_title.goto"))
				self.btnUse:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy02")
				self.btnUse:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy02")
			end
		else
			self.btnUse:SetText(Lang:getString("gui.personal_title.unload"))
			self.btnUse:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy02")
			self.btnUse:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy02")
		end
	end)

	self:registerEvent(Events.PersonalTitleUpdateTaskEvent, function(titleId)

	end)

	self:registerEvent(Events.PersonalTitleReceiveTitleEvent, function(titleId)
		if titleId == currTitle then
			self:updateTitleInfo()
		end
		self:updateListUI()
	end)
end

---@param self UIPersonalTitleLayout
local function showOwnerTitle(self, ownTime)

	if currTitle == CPersonalTitleHelper:getCurrTitle() then
		self.btnUse:SetText(Lang:getString("gui.personal_title.unload"))
		self.btnUse:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy02")
		self.btnUse:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy02")
	else
		self.btnUse:SetText(Lang:getString("gui.personal_title.use"))
		self.btnUse:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy01")
		self.btnUse:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy01")
	end

	self.stGetTimeTxt:SetVisible(true)
	self.stTaskProgressNum:SetVisible(false)

	local date = os.date("*t", ownTime)
	local showDate = string.format("%04d/%02d/%02d", date.year, date.month, date.day)
	self.stGetTime:SetText(showDate)
end


---@param self UIPersonalTitleLayout
---@param config PersonalTitleItemConfig
local function showUnOwnerTitle(self, config)
	self.btnUse:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy02")
	self.btnUse:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy02")
	self.btnUse:SetText(Lang:getString("gui.personal_title.goto"))
	self.btnUse:SetVisible(true)

	self.stGetTimeTxt:SetVisible(false)

	if config.from and config.from[1] == "Task" then
		--- 任务
		self.stTaskProgressNum:SetVisible(true)
		local taskInfo = CPersonalTitleHelper:getTaskInfo(config.from[2])
		local taskConfig = TaskOverrideConfig:getCfgById(tonumber(config.from[2]))

		self.stTaskProgressNum:SetText(string.format("%d/%d", taskInfo.count, taskConfig.count ))
		local pro = math.min(taskInfo.count * 1.0 / taskConfig.count, 1.0)
		self.siTaskProgressImg:SetArea({ 0, 0 }, { 0, 0 }, { pro, 0 }, { 0, 16 })

		if taskInfo.status == Define.TaskStatus.FINISHED then
			self.btnUse:SetNormalImage("set:bed_war_3_button.json image:btn_9_buy01")
			self.btnUse:SetPushedImage("set:bed_war_3_button.json image:btn_9_buy01")
			self.btnUse:SetText(Lang:getString("gui.personal_title.receive"))
		else
			if not TaskOverrideConfig:hasGoTo(tonumber(config.from[2])) then
				self.btnUse:SetVisible(false)
			end
		end

		--self.btnUse:SetVisible(taskInfo.status == Define.TaskStatus.FINISHED)

	else
		--- 其他
		self.stTaskProgressNum:SetVisible(false)
	end
end

function UIPersonalTitleLayout:updateTitleInfo()
	self.showItem:onDataChanged(currTitle)

	local config = PersonalTitleConfig:getConfigById(currTitle)
	self.stName:SetText(Lang:getString(config.name))
	self.stDesc:SetText(Lang:getString(config.desc))

	local ownTime = CPersonalTitleHelper:hasTitle(currTitle)
	if ownTime then
		showOwnerTitle(self, ownTime)
	else
		showUnOwnerTitle(self, config)
	end
end

function UIPersonalTitleLayout:getCurSelectId()
	return currTitle
end

function UIPersonalTitleLayout:updateListUI()
	self.frameAdapter:setData(PersonalTitleConfig:getAllConfig())
end

local function getInitCurrTitle()
	currTitle = CPersonalTitleHelper:getCurrTitle()
	PersonalTitleConfig:sortTitleList()
	if not currTitle then
		currTitle = PersonalTitleConfig:getAllConfig()[1].id
	end
end

function UIPersonalTitleLayout:onBtnClick()
	local ownTime = CPersonalTitleHelper:hasTitle(currTitle)
	local useTitle = CPersonalTitleHelper:getCurrTitle()
	if useTitle == currTitle then
		CPersonalTitleHelper:unloadTitle(currTitle)
	elseif ownTime then
		CPersonalTitleHelper:useTitle(currTitle)
	else
		local config = PersonalTitleConfig:getConfigById(currTitle)
		if config.from and config.from[1] == "Task" then
			local taskInfo = CPersonalTitleHelper:getTaskInfo(config.from[2])
			if taskInfo.status == Define.TaskStatus.FINISHED then
				CPersonalTitleHelper:receiveTask(config.from[2])
			else
				TaskOverrideConfig:gotoTask(tonumber(config.from[2]), function()
					GUIPersonalTitleLayout:hide()
				end)
			end
		elseif config.from and config.from[1] == "Activity" then

		else
			--- 其他

		end

	end
end

function UIPersonalTitleLayout:onShow()
	--if not self.firstInit then
		getInitCurrTitle()
		self:updateListUI()
		Events.PersonalTitleItemSelectEvent:invoke(currTitle)
	--	self.firstInit = true
	--else
	--	self:updateListUI()
	--end
end

return UIPersonalTitleLayout
