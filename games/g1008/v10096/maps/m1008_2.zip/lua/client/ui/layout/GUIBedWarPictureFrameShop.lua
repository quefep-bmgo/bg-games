---@class UIBedWarPictureFrameShopLayout : IGUILayout
local UIBedWarPictureFrameShopLayout = class("UIBedWarPictureFrameShopLayout", IGUILayout)
---@type HeadFrameShopConfig
local HeadFrameShopConfig = T(Global, "HeadFrameShopConfig")
---@type ClientHeadFrameShop
local HeadFrameShop = T(Global, "HeadFrameShop")
---@type HeadImageShopConfig
local HeadImageShopConfig = T(Global, "HeadImageShopConfig")
---@type ClientHeadImageShop
local HeadImageShop = T(Global, "HeadImageShop")
---@type BackgroundShopConfig
local BackgroundShopConfig = T(Global, "BackgroundShopConfig")
---@type ClientBackgroundShop
local BackgroundShop = T(Global, "BackgroundShop")
---@type ActionShowShopConfig
local ActionShowShopConfig = T(Global, "ActionShowShopConfig")
---@type ClientActionShowShop
local ActionShowShop = T(Global, "ActionShowShop")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
local TabType = {
	HeadFrame = 1,
	HeadImage = 2,
	Background = 3,
	ActionShow = 4
}
local TabSort = {1, 2, 3, 4}
local HeadTabText = {
[TabType.HeadFrame] = "gui.head.frame.txt",
[TabType.HeadImage] = "gui.head.txt",
[TabType.Background] = "gui.background.txt",
[TabType.ActionShow] = "gui.action.show.txt",
}
local CurUiType = {
	Icon = 1,
	Actor = 2
}
local ItemUiType = {
	[TabType.HeadFrame] = CurUiType.Icon,
	[TabType.HeadImage] = CurUiType.Icon,
	[TabType.Background] = CurUiType.Actor,
	[TabType.ActionShow] = CurUiType.Actor,
}

---@private
function UIBedWarPictureFrameShopLayout:ctor(parent)
	self.super.ctor(self, "BedWarPictureFrameShop.json", parent)
end

---@private
function UIBedWarPictureFrameShopLayout:onLoad()
	self.llBack = self:getChildWindow("BedWarHallPictureFrameShop-Back", GUIType.Layout)
	self.siBg = self:getChildWindow("BedWarHallPictureFrameShop-Bg", GUIType.StaticImage)
	self.llContent = self:getChildWindow("BedWarHallPictureFrameShop-Content", GUIType.Layout)
	self.llInfo = self:getChildWindow("BedWarHallPictureFrameShop-Info", GUIType.Layout)
	self.siInfoIcon = self:getChildWindow("BedWarHallPictureFrameShop-Info-Icon", GUIType.StaticImage)
	self.siCur = self:getChildWindow("BedWarHallPictureFrameShop-Cur", GUIType.StaticImage)
	self.stName = self:getChildWindow("BedWarHallPictureFrameShop-Name", GUIType.StaticText)
	self.btnUse = self:getChildWindow("BedWarHallPictureFrameShop-Use", GUIType.Button)
	self.stWay = self:getChildWindow("BedWarHallPictureFrameShop-Way", GUIType.StaticText)
	self.btnClose = self:getChildWindow("BedWarHallPictureFrameShop-Close", GUIType.Button)
	self.siPrice = self:getChildWindow("BedWarHallPictureFrameShop-Price", GUIType.StaticImage)
	self.siMoneyIcon = self:getChildWindow("BedWarHallPictureFrameShop-Money-Icon", GUIType.StaticImage)
	self.stPriceText = self:getChildWindow("BedWarHallPictureFrameShop-Price-Text", GUIType.StaticText)
	self.siCanNotBuyBg = self:getChildWindow("BedWarHallPictureFrameShop-Can-Not-Buy", GUIType.StaticImage)
	self.stCanNotBuy = self:getChildWindow("BedWarHallPictureFrameShop-Can-Not-Buy-Text", GUIType.StaticText)
	self.ltTabList = self:getChildWindow("BedWarHallPictureFrameShop-TabList", GUIType.List)
	self.stTitle = self:getChildWindow("BedWarHallPictureFrameShop-Title", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function UIBedWarPictureFrameShopLayout:isDelayLoad()
	return true
end

---@private
function UIBedWarPictureFrameShopLayout:onCreate()
	local configs = HeadFrameShopConfig:getShopConfigs()
	self.curSelectItem = configs[1]
	for _, type in pairs(TabSort) do
		UIUtils.dynamicAddRedDot(Define.RedDotKey.PictureFrameShop .. type,
				Define.RedDotKey.PictureFrameShop, 0)
	end
end

local function setFrameAdaptData(self)
	local configs = HeadFrameShopConfig:getShopConfigs()
	local dataList = {}
	for i, v in ipairs(configs) do
		local reward = RewardConfig.findRewardById(v.RewardId)
		if reward and reward.RewardId and not v.Default then
			local isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
			v.isOwn = isOwn and 1 or 0
		else
			v.isOwn = 1
		end
		table.insert(dataList, v)
	end
	table.sort(dataList, function(a, b)
		if a.isOwn == b.isOwn then
			return a.Rank < b.Rank
		end
		return a.isOwn > b.isOwn
	end)
	for i = 1, 4 do
		table.insert(dataList, {})
	end
	self.frameAdapter:setData(dataList)
end

local function setImageAdaptData(self)
	local configs = HeadImageShopConfig:getShopConfigs()
	local dataList = {}
	for i, v in ipairs(configs) do
		local isOwn = HeadImageShop:checkHeadImageStatus(v.RewardId)
		v.isOwn = isOwn and 1 or 0
		if v.Id == 0 then
			v.isOwn = 1
		end
		table.insert(dataList, v)
	end

	table.sort(dataList, function(a, b)
		if a.isOwn == b.isOwn then
			return a.Rank < b.Rank
		end
		return a.isOwn > b.isOwn
	end)

	for i = 1, 4 do
		table.insert(dataList, {})
	end
	self.imageAdapter:setData(dataList)
end

local function setBackgroundAdaptData(self)
	local configs = BackgroundShopConfig:getShopConfigs()
	local dataList = {}
	for i, v in ipairs(configs) do
		local reward = RewardConfig.findRewardById(v.RewardId)
		if reward and reward.RewardId and not v.Default then
			local isOwn = BackgroundShop:checkBackgroundStatus(reward.RewardId)
			v.isOwn = isOwn and 1 or 0
		else
			v.isOwn = 1
		end
		table.insert(dataList, v)
	end
	table.sort(dataList, function(a, b)
		if a.isOwn == b.isOwn then
			return a.Rank < b.Rank
		end
		return a.isOwn > b.isOwn
	end)
	self.backgroundAdapter:setData(dataList)
end

local function setActionShowAdaptData(self)
	local configs = ActionShowShopConfig:getShopConfigs()
	local dataList = {}
	for i, v in ipairs(configs) do
		local isOwn = CustomShop:isGoodsHas(v.RewardId)
		if isOwn or v.NotOwned then
			table.insert(dataList, v)
		end
	end
	table.sort(dataList, function(a, b)
		return a.Rank < b.Rank
	end)
	self.actionShowAdapter:setData(dataList)
end

---@private
function UIBedWarPictureFrameShopLayout:initView()
	self.ltTabList:SetProperty("BetweenDistance", 7)
	---@type GUIWindow[]
	self.headTabList = {}
	self.curSelectId = {}
	for _, type in pairs(TabSort) do
		local tab = GUIManager:createGUIWindow(GUIType.CheckBox, "BedWarHallPictureFrameShop-Tab" .. type)
		tab:SetTextColor(Define.TabTextColor.Normal)
		tab:SetNormalImage("set:bed_war_3_common_part.json image:chb_9_normal")
		tab:SetPushedImage("set:bed_war_3_common_part.json image:chb_9_selected")
		tab:SetProperty("Font", "HT14")
		tab:SetHeight({ 0, 56 })
		tab:SetWidth({ 1, 0 })
		tab:SetText(Lang:getString(HeadTabText[type]))
		tab:registerEvent(GUIEvent.CheckStateChanged, function()
			if not tab:GetChecked() then
				return
			end
			self:setHeadTabSelect(type)
		end)
		UIUtils.addRedDot(tab, Define.RedDotKey.PictureFrameShop .. type, Define.RedDotKey.PictureFrameShop,
				{ offset = VectorUtil.newVector2(-5, 3)})
		self.ltTabList:AddItem(tab)
		self.headTabList[type] = tab
		self.curSelectId[type] = self.curSelectId[type] or 0
	end

	self.stTitle:SetText(Lang:getString("gui_picture_frame_shop_title"))
	self.stCanNotBuy:SetText(Lang:getString("gui_picture_frame_can_not_buy"))
	self.llContent:SetClipChild(true)

	self.lvFrameList = IGUIGridView.new("BedWarHallPictureFrameShop-Frame-List", self.llContent)
	self.lvFrameList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, -15 }, { 1, -15 })
	self.lvFrameList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvFrameList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvFrameList:setConfig(10, 10, 4)
	self.lvFrameList.root:SetClipChild(true)

	self.lvImageList = IGUIGridView.new("BedWarHallPictureFrameShop-Image-List", self.llContent)
	self.lvImageList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, -15 }, { 1, -15 })
	self.lvImageList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvImageList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvImageList:setConfig(10, 10, 4)
	self.lvImageList.root:SetClipChild(true)

	self.lvBackgroundList = IGUIGridView.new("BedWarHallPictureFrameShop-Background-List", self.llContent)
	self.lvBackgroundList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, -15 }, { 1, -15 })
	self.lvBackgroundList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvBackgroundList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvBackgroundList:setConfig(12, 10, 3)
	self.lvImageList.root:SetClipChild(false)

	self.lvActionShowList = IGUIGridView.new("BedWarHallPictureFrameShop-ActionShow-List", self.llContent)
	self.lvActionShowList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, -15 }, { 1, -15 })
	self.lvActionShowList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.lvActionShowList.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.lvActionShowList:setConfig(12, 6, 3)
	self.lvActionShowList.root:SetClipChild(true)

	---@type BedWarHeadItemAdapter
	self.frameAdapter = UIHelper.newGameAdapter("BedWarHeadItemAdapter")
	local itemWidth = 100 -- (self.lvFrameList.root:GetPixelSize().x - 90) /  4
	self.frameAdapter:setItemSize(itemWidth, itemWidth)
	self.lvFrameList:setAdapter(self.frameAdapter)
	setFrameAdaptData(self)

	---@type BedWarHeadImageItemAdapter
	self.imageAdapter = UIHelper.newGameAdapter("BedWarHeadImageItemAdapter")
	itemWidth = 100
	self.imageAdapter:setItemSize(itemWidth, itemWidth)
	self.lvImageList:setAdapter(self.imageAdapter)
	setImageAdaptData(self)

	---@type BedWarBackgroundItemAdapter
	self.backgroundAdapter = UIHelper.newGameAdapter("BedWarBackgroundItemAdapter")
	self.backgroundAdapter:setItemSize(147, 191)
	self.lvBackgroundList:setAdapter(self.backgroundAdapter)
	setBackgroundAdaptData(self)

	---@type BedWarActionShowItemAdapter
	self.actionShowAdapter = UIHelper.newGameAdapter("BedWarActionShowItemAdapter")
	self.actionShowAdapter:setItemSize(142, 186)
	self.lvActionShowList:setAdapter(self.actionShowAdapter)
	setActionShowAdaptData(self)

	---@type GUIBedWarHeadFrameItem
	self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHeadFrameItem")
	self.winHead.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.winHead.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.winHead.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.siCur:AddChildWindow(self.winHead.root)
	self.winHead:setCanNotBeSelect()

	---@type GUIBedWarHeadImageItem
	self.winHeadImage = UIHelper.newGameGUIWindow("GUIBedWarHeadImageItem")
	self.winHeadImage.root:SetArea({ 0, 0 }, { 0, 0 }, { 1.2, 0 }, { 1.2, 0 })
	self.winHeadImage.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.winHeadImage.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.siCur:AddChildWindow(self.winHeadImage.root)
	self.winHeadImage:setCanNotBeSelect()

	-----@type GUIBedWarBackgroundItemWindow
	self.winActor = UIHelper.newGameGUIWindow("GUIBedWarBackgroundItem")
	self.winActor.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.winActor.root:SetHorizontalAlignment(HorizontalAlignment.Center)
	self.winActor.root:SetVerticalAlignment(VerticalAlignment.Center)
	self.siCur:AddChildWindow(self.winActor.root)
	self.winActor:setCanNotBeSelect()
	self.winActor:setShowActor()


	self:setHeadTabSelect(1)
end

function UIBedWarPictureFrameShopLayout:setHeadTabSelect(type)
	UIUtils.updateRedDotCount(Define.RedDotKey.PictureFrameShop .. type, 0)
	if self.curSelectTabIndex == type then
		return
	end
	if self.curSelectTabIndex then
		local oldTab = self.headTabList[self.curSelectTabIndex]
		oldTab:SetTextColor(Define.TabTextColor.Normal)
	end
	self.curSelectTabIndex = type
	local newTab = self.headTabList[self.curSelectTabIndex]
	newTab:SetTextColor(Define.TabTextColor.Select)
	for id, tab in pairs(self.headTabList) do
		tab:SetTouchable(id ~= type)
		tab:SetChecked(id == type)
	end
	self.lvFrameList.root:SetVisible(type == TabType.HeadFrame)
	self.lvImageList.root:SetVisible(type == TabType.HeadImage)
	self.lvBackgroundList.root:SetVisible(type == TabType.Background)
	self.lvActionShowList.root:SetVisible(type == TabType.ActionShow)
	self.winHead.root:SetVisible(type == TabType.HeadFrame)
	self.winHeadImage.root:SetVisible(type == TabType.HeadImage)
	self.winActor.root:SetVisible(type == TabType.Background or type == TabType.ActionShow)
	self:setCurUiType(ItemUiType[type])

	self:onSelectItemChange(self.curSelectId[type])
end

---@private
function UIBedWarPictureFrameShopLayout:initEvent()
	self.btnUse:registerEvent(GUIEvent.ButtonClick, function()
		self:onBtnClick()
	end)

	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		GUIBedWarPictureFrameShopLayout:hide()
	end)

	self.llBack:registerEvent(GUIEvent.Click, function()
		GUIBedWarPictureFrameShopLayout:hide()
	end)

	self:registerEvent(Events.HeadFrameItemSelectEvent, function(id)
		self:onSelectItemChange(id)
		self.curSelectId[TabType.HeadFrame] = id
	end)

	self:registerEvent(Events.HeadImageItemSelectEvent, function(id)
		self:onSelectItemChange(id)
		self.curSelectId[TabType.HeadImage] = id
	end)

	self:registerEvent(Events.BackgroundItemSelectEvent, function(id)
		self:onSelectItemChange(id)
		self.curSelectId[TabType.Background] = id
	end)

	self:registerEvent(Events.ActionShowItemSelectEvent, function(id)
		self:onSelectItemChange(id)
		self.curSelectId[TabType.ActionShow] = id
	end)

	self:registerEvent(Events.HeadFrameItemStatusEvent, function()
		setFrameAdaptData(self)
	end)

	self:registerEvent(Events.HeadImageItemStatusEvent, function()
		setImageAdaptData(self)
	end)

	self:registerEvent(Events.BackgroundItemStatusEvent, function()
		setBackgroundAdaptData(self)
	end)

	self:registerEvent(Events.ActionShowItemStatusEvent, function()
		UIUtils.updateRedDotCount(Define.RedDotKey.PictureFrameShop .. TabType.ActionShow, 1)
		setActionShowAdaptData(self)
	end)
end

---@param id number
function UIBedWarPictureFrameShopLayout:onSelectItemChange(id)
	local config = nil
	local win = nil
	if self.curSelectTabIndex == TabType.HeadFrame then
		---@type HeadFrameShopItem
		config = HeadFrameShopConfig:getShopConfigById(id)
		win = self.winHead
	elseif self.curSelectTabIndex == TabType.HeadImage then
		---@type HeadImageShopItem
		config = HeadImageShopConfig:getShopConfigById(id)
		win = self.winHeadImage
	elseif self.curSelectTabIndex == TabType.Background then
		---@type BackgroundShopConfig
		config = BackgroundShopConfig:getShopConfigById(id)
		win = self.winActor
	elseif self.curSelectTabIndex == TabType.ActionShow then
		---@type ActionShowShopConfig
		config = ActionShowShopConfig:getShopConfigById(id)
		win = self.winActor
	end
	if not config or not win then
		return
	end
	self.curSelectItem = config
	if self.curSelectTabIndex == TabType.Background or self.curSelectTabIndex == TabType.ActionShow then
		win:setShowInfo(config)
	else
		win:onDataChanged(config)
	end
	if self.curSelectTabIndex == TabType.ActionShow then
		local detailId = ActionShowShop:getActionShowDetail(config.RewardId)
		local detailConfig = RewardItemShowDetailConfig:getConfigById(detailId)
		self.stName:SetText(Lang:getString(detailConfig.name))
	else
		local reward = RewardConfig.findRewardById(config.RewardId)
		self.stName:SetText(Lang:getString(reward and reward.ShowDetail and reward.ShowDetail.name or "gui_head_frame_default_name"))
		self.stWay:SetText(Lang:getString(reward and reward.ShowDetail and reward.ShowDetail.desc or "gui_head_frame_default_desc"))
	end
	self:setBtnStatus(config)
end

function UIBedWarPictureFrameShopLayout:updateListUI()
	if self:isShow() and self.curSelectItem then
		self:setBtnStatus(self.curSelectItem)
	end
end

---@param config HeadFrameShopItem
function UIBedWarPictureFrameShopLayout:setBtnStatus(config)
	self.siPrice:SetVisible(false)
	self.siCanNotBuyBg:SetVisible(false)
	local curItem = nil
	if self.curSelectTabIndex == TabType.HeadFrame then
		curItem = HeadFrameShop.curHeadFrame
	elseif self.curSelectTabIndex == TabType.HeadImage then
		curItem = HeadImageShop.curHeadImage
	elseif self.curSelectTabIndex == TabType.Background then
		curItem = BackgroundShop.curBackground
	elseif self.curSelectTabIndex == TabType.ActionShow then
		curItem = ActionShowShop.curActionShow
	end
	if config.Default then
		local isEquip = curItem and curItem == 0
		self.btnUse:SetVisible(not isEquip)
		if not isEquip then
			self.btnUse:SetText(Lang:getString("gui_equip"))
		end
		return
	end
	self.btnUse:SetVisible(config.CanBuy)
	self.btnUse:SetText(config.CanBuy and Lang:getString("gui_buy_text") or "")
	local reward = RewardConfig.findRewardById(config.RewardId)
	if self.curSelectTabIndex == TabType.ActionShow then
		reward = CustomShopConfig:getGoodsConfig(config.RewardId)
	end
	if not reward then
		self.btnUse:SetVisible(false)
		return
	end
	local isOwn = false
	if self.curSelectTabIndex == TabType.HeadFrame then
		isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
	elseif self.curSelectTabIndex == TabType.HeadImage then
		isOwn = HeadImageShop:checkHeadImageStatus(reward.RewardId)
	elseif self.curSelectTabIndex == TabType.Background then
		isOwn = BackgroundShop:checkBackgroundStatus(reward.RewardId)
	elseif self.curSelectTabIndex == TabType.ActionShow then
		isOwn = ActionShowShop:checkActionShowStatus(reward.Id)
	end
	local rewardId = self.curSelectTabIndex == TabType.ActionShow and reward.Id or reward.RewardId
	self.siCanNotBuyBg:SetVisible(not config.CanBuy and not isOwn)
	self.stCanNotBuy:SetText(Lang:getString(config.GetWayDesc or "gui_picture_frame_can_not_buy"))
	self.siPrice:SetVisible(config.CanBuy and not isOwn)
	if isOwn then
		self.btnUse:SetVisible(rewardId ~= curItem)
		self.btnUse:SetText(Lang:getString(rewardId ~= curItem and "gui_equip" or ""))
	else
		self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(config.CoinId))
		self.stPriceText:SetText(config.Price)
	end
end

function UIBedWarPictureFrameShopLayout:onBtnClick()
	if self.curSelectTabIndex == TabType.HeadFrame then
		if self.curSelectItem.Default then
			local isEquip = HeadFrameShop.curHeadFrame == 0
			if not isEquip then
				HeadFrameShop:onEquipGoods(self.curSelectItem)
			end
			return
		end
		local reward = RewardConfig.findRewardById(self.curSelectItem.RewardId)
		local isOwn = HeadFrameShop:checkHeadFrameStatus(reward.RewardId)
		if isOwn then
			if reward.RewardId ~= HeadFrameShop.curHeadFrame then
				HeadFrameShop:onEquipGoods(self.curSelectItem)
			end
		else
			if self.curSelectItem.CanBuy then
				HeadFrameShop:onBuyGoods(self.curSelectItem)
			end
		end
	elseif self.curSelectTabIndex == TabType.HeadImage then
		if self.curSelectItem.Default then
			local isEquip = HeadImageShop.curHeadImage == 0
			if not isEquip then
				HeadImageShop:onEquipGoods(self.curSelectItem)
			end
			return
		end
		local reward = RewardConfig.findRewardById(self.curSelectItem.RewardId)
		local isOwn = HeadImageShop:checkHeadImageStatus(reward.RewardId)
		if isOwn then
			if reward.RewardId ~= HeadImageShop.curHeadImage then
				HeadImageShop:onEquipGoods(self.curSelectItem)
			end
		else
			if self.curSelectItem.CanBuy then
				HeadImageShop:onBuyGoods(self.curSelectItem)
			end
		end
	elseif self.curSelectTabIndex == TabType.Background then
		if self.curSelectItem.Default then
			local isEquip = BackgroundShop.curBackground == 0
			if not isEquip then
				BackgroundShop:onEquipGoods(self.curSelectItem)
			end
			return
		end
		local reward = RewardConfig.findRewardById(self.curSelectItem.RewardId)
		local isOwn = BackgroundShop:checkBackgroundStatus(reward.RewardId)
		if isOwn then
			if reward.RewardId ~= BackgroundShop.curBackground then
				BackgroundShop:onEquipGoods(self.curSelectItem)
			end
		else
			if self.curSelectItem.CanBuy then
				BackgroundShop:onBuyGoods(self.curSelectItem)
			end
		end
	elseif self.curSelectTabIndex == TabType.ActionShow then
		if self.curSelectItem.Default then
			local isEquip = ActionShowShop.curActionShow == 0
			if not isEquip then
				ActionShowShop:onEquipGoods(self.curSelectItem)
			end
			return
		end
		local reward = CustomShopConfig:getGoodsConfig(self.curSelectItem.RewardId)
		local isOwn = ActionShowShop:checkActionShowStatus(reward.Id)
		if isOwn then
			if reward.Id ~= ActionShowShop.curActionShow then
				ActionShowShop:onEquipGoods(self.curSelectItem)
			end
		end
	end
end

function UIBedWarPictureFrameShopLayout:getCurSelectId(type)
	return self.curSelectId[type] or 0
end

function UIBedWarPictureFrameShopLayout:onShow()
	if not self.firstInit then
		Events.HeadFrameItemSelectEvent:invoke(self.curSelectItem.Id)
		self.firstInit = true
	else
		self:updateListUI()
	end
	if self.curSelectTabIndex then
		UIUtils.updateRedDotCount(Define.RedDotKey.PictureFrameShop .. self.curSelectTabIndex, 0)
	end
end

function UIBedWarPictureFrameShopLayout:setCurUiType(type)
	if self.curUiType == type then
		return
	end
	self.curUiType = type
	self.siCur:SetWidth(type == CurUiType.Icon and {0, 90} or {0, 170})
	self.siCur:SetHeight(type == CurUiType.Icon and {0, 90} or {0, 222})
	self.stName:SetYPosition(type == CurUiType.Icon and {1, 28} or {1, 20})
	self.stWay:SetVisible(type == CurUiType.Icon)
end

return UIBedWarPictureFrameShopLayout
