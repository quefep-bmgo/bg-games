---@class GUIMonthCardWindow : IGUIWindow
local GUIMonthCardWindow = class("GUIMonthCardWindow", IGUIWindow)

---@type MonthCardConfig
local MonthCardConfig = T(Global, "MonthCardConfig")

-- todo: dead code
local cardId1 = 1
local cardId2 = 2

---@private
function GUIMonthCardWindow:ctor(...)
	self.super.ctor(self, "MonthCard.json", ...)
end

---@private
function GUIMonthCardWindow:onLoad()
	self.siSkin = self:getChildWindowByName("MonthCard-Skin", GUIType.StaticImage)
	self.stSkinTitle = self:getChildWindowByName("MonthCard-Skin-Title", GUIType.StaticText)
	self.siSkinIcon = self:getChildWindowByName("MonthCard-Skin-Icon", GUIType.StaticImage)
	self.siSkinDiscountBg = self:getChildWindowByName("MonthCard-Skin-Discount-Bg", GUIType.StaticImage)
	self.stSkinDiscountTxt = self:getChildWindowByName("MonthCard-Skin-Discount-Txt", GUIType.StaticText)
	self.btnSkinHint = self:getChildWindowByName("MonthCard-Skin-Hint", GUIType.Button)
	self.stSkinAvailableAccept = self:getChildWindowByName("MonthCard-Skin-Available-Accept", GUIType.StaticText)
	self.siSkinAvailableImage = self:getChildWindowByName("MonthCard-Skin-Available-Image", GUIType.StaticImage)
	self.stSkinAvailableNum = self:getChildWindowByName("MonthCard-Skin-Available-Num", GUIType.StaticText)
	self.stSkinTotalAccept = self:getChildWindowByName("MonthCard-Skin-Total-Accept", GUIType.StaticText)
	self.siSkinTotalImage = self:getChildWindowByName("MonthCard-Skin-Total-Image", GUIType.StaticImage)
	self.stSkinTotalNum = self:getChildWindowByName("MonthCard-Skin-Total-Num", GUIType.StaticText)
	self.btnSkinBuy = self:getChildWindowByName("MonthCard-Skin-Buy", GUIType.Button)
	self.siSkinPriceIcon = self:getChildWindowByName("MonthCard-Skin-Price-Icon", GUIType.StaticImage)
	self.stSkinPriceTxt = self:getChildWindowByName("MonthCard-Skin-Price-Txt", GUIType.StaticText)
	self.stSkinPriceOriginTxt = self:getChildWindowByName("MonthCard-Skin-Price-Origin-Txt", GUIType.StaticText)
	self.siSkinPriceOriginLine = self:getChildWindowByName("MonthCard-Skin-Price-Origin-Line", GUIType.StaticImage)
	self.stSkinReBuy = self:getChildWindowByName("MonthCard-Skin-ReBuy", GUIType.StaticText)
	self.siSkinRemainingTime = self:getChildWindowByName("MonthCard-Skin-Remaining-Time", GUIType.StaticImage)
	self.siSkinTimeIcon = self:getChildWindowByName("MonthCard-Skin-Time-Icon", GUIType.StaticImage)
	self.stSkinTimeTxt = self:getChildWindowByName("MonthCard-Skin-Time-Txt", GUIType.StaticText)
	self.siKey = self:getChildWindowByName("MonthCard-Key", GUIType.StaticImage)
	self.stKeyTitle = self:getChildWindowByName("MonthCard-Key-Title", GUIType.StaticText)
	self.siKeyIcon = self:getChildWindowByName("MonthCard-Key-Icon", GUIType.StaticImage)
	self.siKeyDiscountBg = self:getChildWindowByName("MonthCard-Key-Discount-Bg", GUIType.StaticImage)
	self.stKeyDiscountTxt = self:getChildWindowByName("MonthCard-Key-Discount-Txt", GUIType.StaticText)
	self.btnKeyHint = self:getChildWindowByName("MonthCard-Key-Hint", GUIType.Button)
	self.stKeyAvailableAccept = self:getChildWindowByName("MonthCard-Key-Available-Accept", GUIType.StaticText)
	self.siKeyAvailableImage = self:getChildWindowByName("MonthCard-Key-Available-Image", GUIType.StaticImage)
	self.stKeyAvailableNum = self:getChildWindowByName("MonthCard-Key-Available-Num", GUIType.StaticText)
	self.stKeyTotalAccept = self:getChildWindowByName("MonthCard-Key-Total-Accept", GUIType.StaticText)
	self.siKeyTotalImage = self:getChildWindowByName("MonthCard-Key-Total-Image", GUIType.StaticImage)
	self.stKeyTotalNum = self:getChildWindowByName("MonthCard-Key-Total-Num", GUIType.StaticText)
	self.btnKeyBuy = self:getChildWindowByName("MonthCard-Key-Buy", GUIType.Button)
	self.siKeyPriceIcon = self:getChildWindowByName("MonthCard-Key-Price-Icon", GUIType.StaticImage)
	self.stKeyPriceTxt = self:getChildWindowByName("MonthCard-Key-Price-Txt", GUIType.StaticText)
	self.stKeyPriceOriginTxt = self:getChildWindowByName("MonthCard-Key-Price-Origin-Txt", GUIType.StaticText)
	self.siKeyPriceOriginLine = self:getChildWindowByName("MonthCard-Key-Price-Origin-Line", GUIType.StaticImage)
	self.stKeyReBuy = self:getChildWindowByName("MonthCard-Key-ReBuy", GUIType.StaticText)
	self.siKeyRemainingTime = self:getChildWindowByName("MonthCard-Key-Remaining-Time", GUIType.StaticImage)
	self.siKeyTimeIcon = self:getChildWindowByName("MonthCard-Key-Time-Icon", GUIType.StaticImage)
	self.stKeyTimeTxt = self:getChildWindowByName("MonthCard-Key-Time-Txt", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIMonthCardWindow:initView()
	self.siSkinRemainingTime:SetVisible(false)
	self.siKeyRemainingTime:SetVisible(false)
	self.stSkinReBuy:SetVisible(false)
	self.stKeyReBuy:SetVisible(false)
	self.stSkinReBuy:SetText(Lang:getString("gui.month.card.skin.reBuy"))
	self.stKeyReBuy:SetText(Lang:getString("gui.month.card.key.reBuy"))

	self.time1 = 0
	self.time2 = 0
end

---@private
function GUIMonthCardWindow:initEvent()
	self.btnSkinHint:registerEvent(GUIEvent.ButtonClick, function()
		local cardCfg = MonthCardConfig:getCfgById(cardId1)
		if not cardCfg then
			return
		end
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("gui.month.card.skin.help.title")
					.setContentText(Lang:format("gui.month.card.skin.help.content", cardCfg.rewardItemNum))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)

	self.btnSkinBuy:registerEvent(GUIEvent.ButtonClick, function()
		local cardCfg = MonthCardConfig:getCfgById(cardId1)
		if not cardCfg then
			return
		end
		local day = cardCfg.time
		local price = cardCfg.firstPrice
		local contentTxt = Lang:getString("gui.store.purchase.tip")
		local monthCardData = ClientMonthCard:getMonthCardData()
		for i, data in pairs(monthCardData) do
			if data.endTime then
				local second = data.endTime - os.time()
				if data.id == cardId1 then
					price = cardCfg.renewPrice
					if second > 0 then
						contentTxt = Lang:format("gui.month.card.skin.purchase.content", price, day)
					end
				end
			end
		end
		CustomDialog.builder()
					.setTitleText("gui.month.card.skin.purchase.title")
					.setContentText(contentTxt)
					.setRightIcon(PayHelper.getMoneyIcon(CurrencyId.GCube))
					.setRightText(tostring(price))
					.setRightClickListener(function()
			LuaTimer:schedule(function()
				PayHelper.checkMoney(CurrencyId.GCube, price, function(success, tips)
					if success then
						CommonPacketSender:sendBuyMonthCard(cardId1)
					end
				end)
			end, 50)
		end).show()
	end)

	self.btnKeyHint:registerEvent(GUIEvent.ButtonClick, function()
		local cardCfg = MonthCardConfig:getCfgById(cardId2)
		if not cardCfg then
			return
		end
		CustomDialog.builder()
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setTitleText("gui.month.card.key.help.title")
					.setContentText(Lang:format("gui.month.card.key.help.content", cardCfg.rewardItemNum))
					.setHideLeftButton()
					.setHideRightButton()
					.show()
	end)

	self.btnKeyBuy:registerEvent(GUIEvent.ButtonClick, function()
		local cardCfg = MonthCardConfig:getCfgById(cardId2)
		if not cardCfg then
			return
		end
		local day = cardCfg.time
		local price = cardCfg.firstPrice
		local contentTxt = Lang:getString("gui.store.purchase.tip")
		local monthCardData = ClientMonthCard:getMonthCardData()
		for i, data in pairs(monthCardData) do
			if data.endTime then
				local second = data.endTime - os.time()
				if data.id == cardId2 then
					price = cardCfg.renewPrice
					if second > 0 then
						contentTxt = Lang:format("gui.month.card.key.purchase.content", price, day)
					end
				end
			end
		end

		CustomDialog.builder()
					.setTitleText("gui.month.card.key.purchase.title")
					.setContentText(contentTxt)
					.setRightIcon(PayHelper.getMoneyIcon(CurrencyId.GCube))
					.setRightText(tostring(price))
					.setRightClickListener(function()
			LuaTimer:schedule(function()
				PayHelper.checkMoney(CurrencyId.GCube, price, function(success, tips)
					if success then
						CommonPacketSender:sendBuyMonthCard(cardId2)
					end
				end)
			end, 50)
		end).show()
	end)

	Events.UpdateMonthCardDataEvent:registerCallBack(function()
		self:showPage()
	end)
end

local function setUILayout(self, skinCfg, keyCfg, monthCardData)
	self.stSkinTitle:SetText(Lang:getString("gui.month.card.skin.title"))
	self.stSkinAvailableAccept:SetText(Lang:getString("gui.month.card.skin.available.accept.txt"))
	self.stSkinTotalAccept:SetText(Lang:getString("gui.month.card.skin.total.accept.txt"))
	self.stKeyTitle:SetText(Lang:getString("gui.month.card.key.title"))
	self.stKeyAvailableAccept:SetText(Lang:getString("gui.month.card.key.available.accept.txt"))
	self.stKeyTotalAccept:SetText(Lang:getString("gui.month.card.key.total.accept.txt"))

	--self.stSkinPriceTxt:SetText(skinCfg.price)
	self.stSkinPriceOriginTxt:SetText(skinCfg.price)
	self.stSkinAvailableNum:SetText(skinCfg.rewardItemNum)
	self.stSkinTotalNum:SetText(skinCfg.rewardItemNum * 30)
	self.stSkinDiscountTxt:SetText(skinCfg.percent)
	--self.stKeyPriceTxt:SetText(keyCfg.price)
	self.stKeyPriceOriginTxt:SetText(keyCfg.price)
	self.stKeyAvailableNum:SetText(keyCfg.rewardItemNum)
	self.stKeyTotalNum:SetText(keyCfg.rewardItemNum * 30)
	self.stKeyDiscountTxt:SetText(keyCfg.percent)

	local xOffset = -40
	local font = GUIFontManager.Instance():GetFont("HT16")
	local txt1 = Lang:format("gui.month.card.skin.available.accept.txt", skinCfg.rewardItemNum)
	self.stSkinAvailableAccept:SetWidth({0, font:GetTextExtent(txt1, 1)})
	self.stSkinAvailableAccept:SetXPosition({0, xOffset})

	local txt2 = Lang:format("gui.month.card.skin.total.accept.txt", skinCfg.rewardItemNum * 30)
	self.stSkinTotalAccept:SetWidth({0, font:GetTextExtent(txt2, 1)})
	self.stSkinTotalAccept:SetXPosition({0, xOffset})

	local txt3 = Lang:format("gui.month.card.key.available.accept.txt", keyCfg.rewardItemNum)
	self.stKeyAvailableAccept:SetWidth({0, font:GetTextExtent(txt3, 1)})
	self.stKeyAvailableAccept:SetXPosition({0, xOffset})

	local txt4 = Lang:format("gui.month.card.key.total.accept.txt", keyCfg.rewardItemNum * 30)
	self.stKeyTotalAccept:SetWidth({0, font:GetTextExtent(txt4, 1)})
	self.stKeyTotalAccept:SetXPosition({0, xOffset})

	self.stSkinReBuy:SetVisible(false)
	self.stKeyReBuy:SetVisible(false)
	self.siSkinPriceIcon:SetVisible(true)
	self.siKeyPriceIcon:SetVisible(true)
	self.siSkinPriceIcon:SetDrawColor({ 1, 1, 1, 1 })
	self.siKeyPriceIcon:SetDrawColor({ 1, 1, 1, 1 })
	self.btnSkinBuy:SetEnabled(true)
	self.btnKeyBuy:SetEnabled(true)

	local remainingDay = 10		--剩余10天才能购买
	local keyPrice = keyCfg.firstPrice
	local skinPrice = skinCfg.firstPrice
	for _, data in pairs(monthCardData) do
		if data.endTime then
			local second = data.endTime - os.time()
			if data.id == cardId1 then
				skinPrice = skinCfg.renewPrice
				if second > 0 then
					--self.stSkinReBuy:SetVisible(true)
					--self.siSkinPriceIcon:SetVisible(false)
					self.siSkinPriceIcon:SetDrawColor({ 0.5, 0.5, 0.5, 1 })
					if second > 3600 * 24 * remainingDay then
						self.btnSkinBuy:SetEnabled(false)
					end
				end
			end
			if data.id == cardId2 then
				keyPrice = keyCfg.renewPrice
				if second > 0 then
					--self.stKeyReBuy:SetVisible(true)
					--self.siKeyPriceIcon:SetVisible(false)
					self.siKeyPriceIcon:SetDrawColor({ 0.5, 0.5, 0.5, 1 })
					if second > 3600 * 24 * remainingDay then
						self.btnKeyBuy:SetEnabled(false)
					end
				end
			end
		end
	end

	self.stSkinPriceTxt:SetText(skinPrice)
	self.stKeyPriceTxt:SetText(keyPrice)
end

function GUIMonthCardWindow:showPage()
	local skinCfg = MonthCardConfig:getCfgById(cardId1)
	local keyCfg = MonthCardConfig:getCfgById(cardId2)
	self.siSkinRemainingTime:SetVisible(false)
	self.siKeyRemainingTime:SetVisible(false)
	if not skinCfg or not keyCfg then
		return
	end
	local monthCardData = ClientMonthCard:getMonthCardData()
	setUILayout(self, skinCfg, keyCfg, monthCardData)
	for i, data in pairs(monthCardData) do
		if data.endTime then
			local second = data.endTime - os.time()
			if data.id == cardId1 and second > 0 then
				self.time1 = second
				local day = math.floor(second / (3600 * 24))
				local hour = math.floor((second % (3600 * 24)) / 3600)
				self.stSkinTimeTxt:SetText(day .. "d " .. hour .. "h")
				self.siSkinRemainingTime:SetVisible(true)
			end
			if data.id == cardId2 and second > 0 then
				self.time2 = second
				local day = math.floor(second / (3600 * 24))
				local hour = math.floor((second % (3600 * 24)) / 3600)
				self.stKeyTimeTxt:SetText(day .. "d " .. hour .. "h")
				self.siKeyRemainingTime:SetVisible(true)
			end
		end
	end

	if not self.timer then
		self.timer = LuaTimer:scheduleTimer(function()
			if self.time1 <= 0 and self.time2 <= 0 then
				LuaTimer:cancel(self.timer)
				self.timer = nil
			end
			self.time1 = self.time1 - 1
			local day = math.floor(self.time1 / (3600 * 24))
			local hour = math.floor((self.time1 % (3600 * 24)) / 3600)
			self.stSkinTimeTxt:SetText(day .. "d " .. hour .. "h")
			if self.time1 <= 0 then
				self.siSkinRemainingTime:SetVisible(false)
			end
			self.time2 = self.time2 - 1
			local day2 = math.floor(self.time2 / (3600 * 24))
			local hour2 = math.floor((self.time2 % (3600 * 24)) / 3600)
			self.stKeyTimeTxt:SetText(day2 .. "d " .. hour2 .. "h")
			if self.time2 <= 0 then
				self.siKeyRemainingTime:SetVisible(false)
			end
		end, 1000)
	end
end

return GUIMonthCardWindow
