---@class GUIBedWarHallChatItemContentEmojiWindow : IGUIWindow
local GUIBedWarHallChatItemContentEmojiWindow = class("GUIBedWarHallChatItemContentEmojiWindow", IGUIWindow)
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")

---@private
function GUIBedWarHallChatItemContentEmojiWindow:ctor(...)
    self.super.ctor(self, "BedWarHallChatEmoji.json", ...)
end

---@private
function GUIBedWarHallChatItemContentEmojiWindow:onLoad()
    self.icon = self:getChildWindowByName("BedWarHallChatEmoji-Icon", GUIType.StaticImage)
    self.effect = self:getChildWindowByName("BedWarHallChatEmoji-Effect", GUIType.Layout)
end

---@param data ChatMsgData
function GUIBedWarHallChatItemContentEmojiWindow:onDataChanged(data)
    if self.timer then
        LuaTimer:cancel(self.timer)
        self.timer = nil
    end
    if data.sendId == Game:getPlatformUserId() then
        self.root:SetXPosition({ 0, -18 })
    end
    --LogUtil.logError("dddddddd", StringUtil.v2s(data.data))
    local config = EmojiConfig:getCfgById(data.data.content.emojiId)
    --LogUtil.logError("cccccccccc", StringUtil.v2s(config))
    self.icon:SetImage(config.icon)
    -- not include .effect
    if config.effect and string.len(config.effect) > 7 then
        self.icon:SetVisible(false)
        self.effect:SetVisible(true)
        local time = self.effect:SetEffectName(config.effect)
        --LogUtil.logError("ttttttttttt", time)
        if time > 0 then
            self.timer = LuaTimer:schedule(function()
                self.icon:SetVisible(true)
                self.effect:SetVisible(false)
            end, time)
        end
    else
        self.icon:SetVisible(true)
        self.effect:SetVisible(false)
    end
end

return GUIBedWarHallChatItemContentEmojiWindow
