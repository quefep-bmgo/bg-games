---@class UIBedWarHallLvUpLayout : IGUILayout
local UIBedWarHallLvUpLayout = class("UIBedWarHallLvUpLayout", IGUILayout)

local function setNumberToLayout(number, parent, numberStr)
    number = math.floor(number)
    local Spacing = -6
    parent:CleanupChildren()
    local numberHeight = parent:GetPixelSize().y
    local parentWidth = parent:GetPixelSize().x
    local numberWidth = numberHeight / 167 * 110
    local numberList = {}
    while number ~= 0 do
        table.insert(numberList, number % 10)
        number = math.floor(number / 10)
    end
    local PosX = ((numberWidth + Spacing) * (#numberList - 1)) / -2
    for i = #numberList, 1, -1 do
        ---@type GUINumberItem
        local item = UIHelper.newGameGUIWindow("GUINumberItem", numberList[i], numberStr)
        item:setArea({ PosX / parentWidth, 0 }, { 0, 0 }, { numberWidth / parentWidth, 0 }, { 1, 0 })
        item.root:SetHorizontalAlignment(HorizontalAlignment.Center)
        parent:AddChildWindow(item.root)
        PosX = PosX + numberWidth + Spacing
    end
end

---@private
function UIBedWarHallLvUpLayout:ctor(parent)
    self.super.ctor(self, "BedWarHallLvUp.json", parent)
end

---@private
function UIBedWarHallLvUpLayout:onLoad()
    self.curLv = 1
    self.curExp = 0
    self.maxExp = 0
    self.isMax = false
    self.lvUpRewards = {}
    self.llClose = self:getChildWindow("BedWarHallLvUp-Close", GUIType.Layout)
    self.siBg = self:getChildWindow("BedWarHallLvUp-Bg", GUIType.StaticImage)
    self.stTitle = self:getChildWindow("BedWarHallLvUp-Title", GUIType.StaticText)
    self.btnCloseBtn = self:getChildWindow("BedWarHallLvUp-Close-Btn", GUIType.Button)
    self.siFlag = self:getChildWindow("BedWarHallLvUp-Flag", GUIType.StaticImage)
    self.siLvBg = self:getChildWindow("BedWarHallLvUp-Lv-Bg", GUIType.StaticImage)
    self.siLvBgIcon = self:getChildWindow("BedWarHallLvUp-Lv-Bg-Icon", GUIType.StaticImage)
    self.stExpText = self:getChildWindow("BedWarHallLvUp-Exp-Text", GUIType.StaticText)
    self.stMaxText = self:getChildWindow("BedWarHallLvUp-Max-Text", GUIType.StaticText)
    self.siBarBg = self:getChildWindow("BedWarHallLvUp-Bar-Bg", GUIType.StaticImage)
    self.pbExpBar = self:getChildWindow("BedWarHallLvUp-Exp-Bar", GUIType.ProgressBar)
    self.llLv = self:getChildWindow("BedWarHallLvUp-Lv", GUIType.Layout)
    self.llContent = self:getChildWindow("BedWarHallLvUp-Content", GUIType.Layout)

    self.siBgEffectTop = self:getChildWindow("BedWarHallLvUp-Bg-Effect-Top", GUIType.StaticImage)
    self.siBgEffectBottom = self:getChildWindow("BedWarHallLvUp-Bg-Effect-Bottom", GUIType.StaticImage)
    self.siEffect = self:getChildWindow("BedWarHallLvUp-Effect", GUIType.StaticImage)
    self.siEffectLight = self:getChildWindow("BedWarHallLvUp-Effect-Light", GUIType.StaticImage)

    self.siLeftIcon = self:getChildWindow("BedWarHallLvUp-Left-Icon", GUIType.StaticImage)
    self.siRightIcon = self:getChildWindow("BedWarHallLvUp-Right-Icon", GUIType.StaticImage)

    self.gvList = IGUIGridView.new("BedWarHallLvUp-List-Grid", self.llContent)
    self.gvList:setConfig(0, 9, 1)
    ---@type LvUpItemAdapter
    self.lvItemAdapt = UIHelper.newGameAdapter("LvUpItemAdapter")
    local width = self.gvList:getWidth()
    local height = width / 507 * 100
    self.lvItemAdapt:setItemSize(width, height)
    self.gvList:setAdapter(self.lvItemAdapt)

    self:initView()
    self:initEvent()
end

---@private
function UIBedWarHallLvUpLayout:initView()
    self.stTitle:SetText(Lang:getString("gui_lv_up_title"))
    self.stMaxText:SetText("MAX")
    self.stMaxText:SetVisible(false)
    self.siBgEffectTop:SetVisible(false)
    self.siBgEffectBottom:SetVisible(false)
    self.siEffect:SetVisible(false)
    self.siEffectLight:SetVisible(false)
end

---@private
function UIBedWarHallLvUpLayout:initEvent()
    self.llClose:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)

    self.btnCloseBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)

    self:registerDataCallBack("LevelInfo", function(data)
        self:onHallInfoUpdate(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("LvUpInfo", function(data)
        self:onLvUpInfoUpdate(data)
    end, JsonBuilderProcessor)
end

function UIBedWarHallLvUpLayout:initList()
    local config = ExpConfig:getLvRewardSettings()
    self.lvItemAdapt:setData(config)
    self.init = true
end

function UIBedWarHallLvUpLayout:onHallInfoUpdate(data)
    self.curLv = data:getNumberParam("level")
    self.curExp = data:getNumberParam("curExp")
    self.maxExp = data:getNumberParam("maxExp")
    self.isMax = data:getBoolParam("isMax")
    if not self.isPlayingAni and self:isShow() then
        self:updateCurLv()
    end
    if self.needPlayAni then
        GUIManager:addShowQueue(GUIBedWarHallLvUpLayout)
    end
end

function UIBedWarHallLvUpLayout:onLvUpInfoUpdate(data)
    if not self.init then
        self:initList()
    end
    self.lvUpRewards = data.lvUpRewards
    Events.UpdateLvUpRewardEvent:invoke(self.curLv or 1)
    if data.oldLv then
        if not self:isShow() or not self.curLv then
            self.needPlayAni = {
                oldLv = data.oldLv,
                oldExp = data.oldExp
            }
            if self.curLv > 0 then
                GUIManager:addShowQueue(GUIBedWarHallLvUpLayout)
            end
        else
            self:playAni(data.oldLv, data.oldExp)
        end
    end
    self:checkCanOpen()
end

function UIBedWarHallLvUpLayout:onShow()
    if self.needPlayAni then
        self:playAni(self.needPlayAni.oldLv, self.needPlayAni.oldExp)
        self.needPlayAni = nil
        return
    end
    if self.isPlayingAni then
        return
    end
    self:updateCurLv()
    if not self.init then
        self:initList()
        return
    end
    self:setScrollOffset()
    Events.UpdateLvUpRewardEvent:invoke(self.curLv)
end

function UIBedWarHallLvUpLayout:getStatus(lv)
    local status = Define.RewardStatus.CantReceived
    if lv <= self.curLv then
        status = Define.RewardStatus.Received
    end
    if TableUtil.include(self.lvUpRewards, lv) then
        status = Define.RewardStatus.WaitReceived
    end
    return status
end

function UIBedWarHallLvUpLayout:updateCurLv()
    self:setLv(self.curLv)
    self.stExpText:SetVisible(not self.isMax)
    self.siBarBg:SetVisible(not self.isMax)
    self.stMaxText:SetVisible(self.isMax)
    if not self.isMax then
        if self.maxExp > 0 then
            self:setExpBar(self.curExp, self.maxExp)
        else
            self.stExpText:SetText(0)
            self.pbExpBar:SetProgress(0)
        end
    end
end

function UIBedWarHallLvUpLayout:setLv(lv)
    local size = lv > 10 and 1 or 1.2
    self.llLv:SetHeight({0, 90 * size})
    setNumberToLayout(lv, self.llLv, "set:bed_war_3_yellow_num.json image:img_0_myself_number")
end

function UIBedWarHallLvUpLayout:playAni(oldLv, oldExp)
    if GUIGMControlPanel then
        GUIGMControlPanel:hide()
    end
    self.isPlayingAni = true
    self:setLv(oldLv)
    local maxExp = ExpConfig:getMaxExp(oldLv)
    self:setExpBar(oldExp, maxExp)
    local index = ExpConfig:getIndex(self.curLv)
    self:setScrollOffset(index)
    LuaTimer:schedule(function()
        self:setScrollOffset(index)
    end, 400)
    self:aniReady()
    --背景渐变显示
    local bgAlpha = 0
    self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
        if bgAlpha < 1 then
            bgAlpha = math.min(1, bgAlpha + 0.1)
            self.root:SetAlpha(bgAlpha)
            self.siLeftIcon:SetAlpha(bgAlpha * 0.1)
            self.siRightIcon:SetAlpha(bgAlpha * 0.1)
        end
    end, function()
        self.siBgEffectTop:SetVisible(true)
        self.siBgEffectTop:PlayEffect()
        self.siBgEffectBottom:SetVisible(true)
        self.siBgEffectBottom:PlayEffect()
        self.siEffectLight:SetVisible(true)
        self.siEffectLight:PlayEffect()
    end, 40, 10))

    self:addTimer(LuaTimer:schedule(function()
        --等级背景旋转及放大
        local rotate = 0
        self:addTimer(LuaTimer:scheduleTimer(function()
            local size = self.siLvBgIcon:GetHeight()[1]
            if size < 1 then
                rotate = rotate + 288
                self.siLvBgIcon:SetArea({ 0, 0 }, { 0, 0 }, { size + 0.1, 0 }, { size + 0.1, 0 })
                self.siLvBgIcon:SetRotate(rotate % 360)
            end
        end, 40, 10))
    end, 400))

    --等级数字缩放
    self:addTimer(LuaTimer:schedule(function()
        local scale = 5
        local alpha = 0.4
        self.llLv:SetVisible(true)
        self:addTimer(LuaTimer:scheduleTimer(function()
            alpha = math.min(1, alpha + 0.15)
            if scale > 0.8 then
                scale = math.max(0.8, scale - 0.7)
            else
                scale = 1
            end
            self.llLv:SetArea({ 0, -3 }, { 0, 0 }, { 0, 154 * scale }, { 0, 80 * scale })
            self.llLv:SetAlpha(alpha)
        end, 40, 7))
    end, 680))

    --显示当前等级
    self:addTimer(LuaTimer:schedule(function()
        local _oldExp = oldExp
        local expDiff = maxExp - oldExp + self.curExp
        local once = math.min(expDiff / 5)
        self.siEffect:SetVisible(true)
        self.stTitle:SetVisible(true)
        self.stExpText:SetVisible(true)
        self.siBarBg:SetVisible(true)
        self:setLv(self.curLv)
        --进度条动画
        --self:addTimer(LuaTimer:scheduleTimer(function()
        --    _oldExp = _oldExp + once
        --    self:setExpBar(_oldExp, maxExp)
        --    if _oldExp >= maxExp then
        --        _oldExp = maxExp - _oldExp
        --        maxExp = self.maxExp
        --    end
        --    if maxExp == self.maxExp and (self.isMax or _oldExp >= self.curExp) then
        --        self:updateCurLv()
        --    end
        --end, 40, 6))
        self:setExpBar(self.curExp, self.maxExp)
        self:updateCurLv()
    end, 1040))

    self:addTimer(LuaTimer:schedule(function()
        --奖励列表入场
        local rewardAlpha = 0
        self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
            local xPos = self.llContent:GetXPosition()[1]
            if xPos > 0 then
                xPos = math.max(0, xPos - 0.08)
                self.llContent:SetXPosition({ xPos, 160 })
            end
        end, function()
            Events.ShowLvUpRewardEffectEvent:invoke(self.curLv, true)
        end, 7, 50))
        --奖励列表渐变
        self:addTimer(LuaTimer:scheduleTimer(function()
            if rewardAlpha < 1 then
                rewardAlpha = rewardAlpha + 0.06
                Events.SetLvUpRewardAlphaEvent:invoke(math.min(1, rewardAlpha))
            end
        end, 40, 17))
    end, 1080))

    --动画结束
    self:addTimer(LuaTimer:schedule(function()
        Events.ShowLvUpRewardEffectEvent:invoke(0, false)
        self.isPlayingAni = false
        self.btnCloseBtn:SetVisible(true)
    end, 2000))
end

function UIBedWarHallLvUpLayout:aniReady()
    self:cancelAllTimer()
    self.root:SetAlpha(0)
    self.siLeftIcon:SetAlpha(0)
    self.siRightIcon:SetAlpha(0)
    self.stTitle:SetVisible(false)
    self.btnCloseBtn:SetVisible(false)
    self.siBgEffectTop:SetVisible(false)
    self.siBgEffectBottom:SetVisible(false)
    self.siEffect:SetVisible(false)
    self.siEffectLight:SetVisible(false)
    self.stExpText:SetVisible(false)
    self.stMaxText:SetVisible(false)
    self.siBarBg:SetVisible(false)
    self.llLv:SetVisible(false)
    self.siLvBgIcon:SetArea({ 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 })
    self.llLv:SetArea({ 0, -3 }, { 0, 0 }, { 0, 770 }, { 0, 400 })
    self.llContent:SetXPosition({ 0.56, 160 })
    Events.ShowLvUpRewardEffectEvent:invoke(0, false)
    Events.SetLvUpRewardAlphaEvent:invoke(0)
end

function UIBedWarHallLvUpLayout:setExpBar(cur, max)
    local expTxt = string.format("%d▢FF51F1EB/%d", math.floor(math.min(cur, max)), max)
    self.stExpText:SetText(expTxt)
    self.pbExpBar:SetProgress(math.min(cur / max, 1))
end

function UIBedWarHallLvUpLayout:resetUI()
    self.root:SetAlpha(1)
    self.siLeftIcon:SetAlpha(0.1)
    self.siRightIcon:SetAlpha(0.1)
    self.stTitle:SetVisible(true)
    self.btnCloseBtn:SetVisible(true)
    self.siBgEffectTop:SetVisible(false)
    self.siBgEffectBottom:SetVisible(false)
    self.siEffect:SetVisible(false)
    self.siEffectLight:SetVisible(false)
    self.stExpText:SetVisible(not self.isMax)
    self.stMaxText:SetVisible(self.isMax)
    self.siBarBg:SetVisible(true)
    self.llLv:SetVisible(true)
    self.siLvBgIcon:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.llLv:SetArea({ 0, -3 }, { 0, 0 }, { 0, 154 }, { 0, 80 })
    self.llContent:SetXPosition({ 0, 160 })
    self:updateCurLv()
    Events.ShowLvUpRewardEffectEvent:invoke(0, false)
    Events.SetLvUpRewardAlphaEvent:invoke(1)
end

function UIBedWarHallLvUpLayout:onHide()
    self:cancelAllTimer()
    self:resetUI()
end

function UIBedWarHallLvUpLayout:isShowAnim()
    return false
end

function UIBedWarHallLvUpLayout:checkCanOpen()
    if TableUtil.isEmpty(self.lvUpRewards) and self.isMax then
        GUIBedWarToolBar:removeButton(Define.ClickPopUpLayout.Right, "BedWarToolBar-Lv-Up")
    end
end

function UIBedWarHallLvUpLayout:setScrollOffset(index)
    local _index = index or -1
    if _index == -1 then
        if not TableUtil.isEmpty(self.lvUpRewards) then
            _index = ExpConfig:getIndex(self.lvUpRewards[1])
        else
            _index = ExpConfig:getIndex(self.curLv + 1)
        end
    end
    local maxLevel = ExpConfig:getMaxLevel()
    local offsetIndex = (maxLevel - 1) > 0 and (maxLevel - 1) or (_index + 1)
    local offset = math.min(0, self.gvList:getHeight() - (self.lvItemAdapt:getItemHeight()[2] + 9) * (math.min(_index + 1, offsetIndex)))

    --  setScrollOffset 有一个bug, 当offset特别大的时候，不能一下设置到offset所指的位置
    --  这里用定时器，是取巧方法。
    LuaTimer:scheduleTicker(function()
        self.lvItemAdapt:setScrollOffset(offset)
    end, 1, 5)
end

function UIBedWarHallLvUpLayout:cancelAllTimer()
    UITimerMgr:cancelUITimerKey(self.__name)
end

return UIBedWarHallLvUpLayout
