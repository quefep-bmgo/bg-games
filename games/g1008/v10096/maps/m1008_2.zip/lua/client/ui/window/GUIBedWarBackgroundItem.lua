---@class GUIBedWarBackgroundItemWindow : IGUIWindow
local GUIBedWarBackgroundItemWindow = class("GUIBedWarBackgroundItemWindow", IGUIWindow)
---@type BackgroundConfig
local BackgroundConfig = T(Global, "BackgroundConfig")
---@type ClientBackgroundShop
local BackgroundShop = T(Global, "BackgroundShop")
---@type ClientActionShowShop
local ActionShowShop = T(Global, "ActionShowShop")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@private
function GUIBedWarBackgroundItemWindow:ctor(...)
	self.super.ctor(self, "BedWarBackgroundItem.json", ...)
end

---@private
function GUIBedWarBackgroundItemWindow:onLoad()
	self.siBg = self:getChildWindowByName("BedWarBackgroundItem-Bg", GUIType.StaticImage)
	self.awActor = self:getChildWindowByName("BedWarBackgroundItem-Actor", GUIType.ActorWindow)
	self.llTouch = self:getChildWindowByName("BedWarBackgroundItem-Touch", GUIType.Layout)
	self.siIcon = self:getChildWindowByName("BedWarBackgroundItem-Icon", GUIType.StaticImage)
	self.siEffect = self:getChildWindowByName("BedWarBackgroundItem-Effect", GUIType.StaticImage)
	self.siSelect = self:getChildWindowByName("BedWarBackgroundItem-Select", GUIType.StaticImage)
	self.siFrame = self:getChildWindowByName("BedWarBackgroundItem-Frame", GUIType.StaticImage)
	self.siLock = self:getChildWindowByName("BedWarBackgroundItem-Lock", GUIType.StaticImage)
	self.siUse = self:getChildWindowByName("BedWarBackgroundItem-Use", GUIType.StaticImage)
	self.llActorBg = self:getChildWindowByName("BedWarBackgroundItem-Actor-Bg", GUIType.Layout)
	self.siFrameBg = self:getChildWindowByName("BedWarBackgroundItem-Frame-Bg", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarBackgroundItemWindow:initView()
	self.llActorBg:SetVisible(false)
end

---@private
function GUIBedWarBackgroundItemWindow:initEvent()
	self.llTouch:registerEvent(GUIEvent.Click, function()
		if not self.cantBeSelect then
			Events.BackgroundItemSelectEvent:invoke(self.data.Id)
		end
	end)

	self:registerEvent(Events.BackgroundItemSelectEvent, function(id)
		if not self.cantBeSelect then
			self.siSelect:SetVisible(id == self.data.Id)
		end
	end)

	self:registerEvent(Events.BackgroundChangeEvent, function(userId)
		if self.userId or self.userId == userId then
			local userInfo = UserInfoCache:GetCache(self.userId)
			if not userInfo then
				return
			end
			self:updatePlayerShowInfo(userInfo)
			return
		end
		if userId ~= Game:getPlatformUserId() then
			return
		end
		if self.cantBeSelect or not self.data then
			return
		end
		local reward = RewardConfig.findRewardById(self.data.RewardId)
		if reward and reward.RewardId then
			self.siUse:SetVisible(reward.RewardId == BackgroundShop.curBackground)
		else
			self.siUse:SetVisible(BackgroundShop.curBackground == 0)
		end
	end)

	self:registerEvent(Events.ActionShowChangeEvent, function(userId)
		if not self.userId or self.userId ~= userId then
			return
		end
		local userInfo = UserInfoCache:GetCache(self.userId)
		if not userInfo then
			return
		end
		self:updatePlayerShowInfo(userInfo)
	end)

	self:registerEvent(Events.BackgroundItemStatusEvent, function(id)
		if not self.data or self.cantBeSelect then
			return
		end
		local reward = RewardConfig.findRewardById(self.data.RewardId) or {}
		local isOwn = BackgroundShop:checkBackgroundStatus(reward.RewardId or 0)
		self.siLock:SetVisible(self.data.Default or not isOwn)

		if not self.siLock:IsVisible() and self.data.Default then
			self.siUse:SetVisible(id == 0)
			return
		end
	end)
end

---@param data BackgroundShopItem
function GUIBedWarBackgroundItemWindow:onDataChanged(data)
	self.data = data
	self:setBackground(data.RewardId)

	if not self.cantBeSelect and GUIBedWarPictureFrameShopLayout then
		self.siSelect:SetVisible(self.data.Id == GUIBedWarPictureFrameShopLayout:getCurSelectId(3))
	end

	if not self.cantBeSelect then
		if data.Default then
			self.siLock:SetVisible(false)
			self.siUse:SetVisible(BackgroundShop.curBackground == 0)
		else
			local reward = RewardConfig.findRewardById(data.RewardId)
			local isOwn = BackgroundShop:checkBackgroundStatus(reward.RewardId)
			self.siLock:SetVisible(not isOwn)
			self.siUse:SetVisible(reward.RewardId == BackgroundShop.curBackground)
		end
	end
end

---@param data BackgroundShopItem | ActionShowShopItem
function GUIBedWarBackgroundItemWindow:setShowInfo(data)
	local backgroundSetting = BackgroundConfig.getConfigById(data.RewardId)
	local backgroundId = data.RewardId
	if not backgroundSetting then
		backgroundId =  BackgroundShop.curBackground
	end
	self:setBackground(backgroundId)
	local detailId = data.RewardDetail or ActionShowShop:getActionShowDetail()
	self:setActionShow(Game:getPlatformUserId(), detailId)
end

function GUIBedWarBackgroundItemWindow:setCanNotBeSelect()
	self.cantBeSelect = true
	self.siUse:SetVisible(false)
	self.siLock:SetVisible(false)
	self.siSelect:SetVisible(false)
end

---@param data UserInfo
function GUIBedWarBackgroundItemWindow:updatePlayerShowInfo(data)
	if data == nil then
		LogUtil.logScriptException("data = nil", debug.traceback())
		return
	end
	self.siFrameBg:SetVisible(false)
	self.userId = data.userId
	local backgroundId = data[Define.PlayerCustomInfo.Background] or 0
	local actionShowId = data[Define.PlayerCustomInfo.ActionShow] or 0

	self:setBackground(backgroundId)
	local detailId = ActionShowShop:getActionShowDetail(actionShowId)
	self:setActionShow(self.userId, detailId)
end

function GUIBedWarBackgroundItemWindow:setShowActor()
	self.llActorBg:SetVisible(true)
end

function GUIBedWarBackgroundItemWindow:setTouchDown(position)
	self.awActor:TouchDown(position)
end

function GUIBedWarBackgroundItemWindow:setTouchMove(position)
	self.awActor:TouchMove(position)
end

function GUIBedWarBackgroundItemWindow:setBackground(backgroundId)
	local backgroundSetting = BackgroundConfig.getConfigById(backgroundId) or {}
	self.siBg:SetImage(backgroundSetting.BackImg or "")
	self.siIcon:SetImage(backgroundSetting.BackIcon or "")
	self.siEffect:PlayEffect1("")
	self.siEffect:PlayEffect1(backgroundSetting.Effect ~= "#" and backgroundSetting.Effect or "")
end

function GUIBedWarBackgroundItemWindow:setActionShow(userId, detailId)
	local detailConfig = RewardItemShowDetailConfig:getConfigById(detailId)
	if detailConfig then
		self.detailConfig = detailConfig
		RewardItemShowDetailConfig:showActorSkill(self.llActorBg, detailConfig)
		self:addTimer(LuaTimer:schedule(function()
			self.awActor:SetActorByUserId(userId, 0, false, function()
				RewardItemShowDetailConfig:showActorSkill(self.llActorBg, detailConfig)
				local info = GameInfoManager:getPlayerInfo(userId)
				if info and info:getBoolValue("IsHideFace") then
					self.awActor:UseBodyPart("custom_face", "")
					self.awActor:UseBodyPart("custom_glasses", "")
				end
			end)
		end, 100))
	else
		self.detailConfig = nil
		self.awActor:SetActorByUserId(userId, 0, false, function()
			local info = GameInfoManager:getPlayerInfo(userId)
			if info and info:getBoolValue("IsHideFace") then
				self.awActor:UseBodyPart("custom_face", "")
				self.awActor:UseBodyPart("custom_glasses", "")
			end
		end)
		RewardItemShowDetailConfig:onWindowHide(self.llActorBg)
	end
end

return GUIBedWarBackgroundItemWindow
