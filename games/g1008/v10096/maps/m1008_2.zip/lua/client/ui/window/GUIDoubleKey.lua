---@class GUIDoubleKeyWindow : IGUIWindow
local GUIDoubleKeyWindow = class("GUIDoubleKeyWindow", IGUIWindow)
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@private
function GUIDoubleKeyWindow:ctor(...)
	self.super.ctor(self, "DoubleKey.json", ...)
end

---@private
function GUIDoubleKeyWindow:onLoad()
	self.siBg = self:getChildWindowByName("DoubleKey-Bg", GUIType.StaticImage)
	self.siIcon = self:getChildWindowByName("DoubleKey-Icon", GUIType.StaticImage)
	self.siNameBg = self:getChildWindowByName("DoubleKey-Name-Bg", GUIType.StaticImage)
	self.stName = self:getChildWindowByName("DoubleKey-Name", GUIType.StaticText)
	self.stDesc = self:getChildWindowByName("DoubleKey-Desc", GUIType.StaticText)
	self.btnBuy = self:getChildWindowByName("DoubleKey-Buy", GUIType.Button)
	self.siMoneyIcon = self:getChildWindowByName("DoubleKey-Money-Icon", GUIType.StaticImage)
	self.stPrice = self:getChildWindowByName("DoubleKey-Price", GUIType.StaticText)
	self.llHas = self:getChildWindowByName("DoubleKey-Has", GUIType.Layout)
	self.stHasText = self:getChildWindowByName("DoubleKey-Has-Text", GUIType.StaticText)

	self:initView()
	self:initEvent()
end

---@private
function GUIDoubleKeyWindow:initView()
	self.stHasText:SetText(Lang:getString("gui_doubele_key_has"))
end

---@private
function GUIDoubleKeyWindow:initEvent()
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		GUINewStore.purchasePanel:show(self.data)
	end)

	self:registerDataCallBack("PrivilegeData", function(data)
		self:checkOwn()
	end, JsonBuilderProcessor)
end

---@param data GoodsInfo[]
function GUIDoubleKeyWindow:onDataChanged(data)
	if not data then
		return
	end
	self.data = data[1]
	local detail = self.data.config.showDetail
	self.stName:SetText(Lang:getString(detail.name))
	self.stDesc:SetText(Lang:getString(detail.desc))
	self.siIcon:SetImage(detail.image)
	self.stPrice:SetText(self.data.config.Price)
	local currency = StoreConfig:getCurrencyConfig(self.data.config.CurrencyId)
	self.siMoneyIcon:SetImage(PayHelper.getMoneyIcon(currency.RealId))
	self:checkOwn()
end

function GUIDoubleKeyWindow:checkOwn()
	if not self.data then
		return
	end
	local isOwn = Privilege.checkHavePrivilege(self.data.config.ItemId)
	self.btnBuy:SetVisible(not isOwn)
	self.llHas:SetVisible(isOwn)
end

return GUIDoubleKeyWindow
