---@class UIMiniGameMainLayout : IGUILayout
local UIMiniGameMainLayout = class("UIMiniGameMainLayout", IGUILayout)

---@type CMiniGameMgr
local CMiniGameMgr = T(Global, "CMiniGameMgr")

---@private
function UIMiniGameMainLayout:ctor()
    self.super.ctor(self, "MiniGameMain.json", GUIManager:getMainControl())
end

---@private
function UIMiniGameMainLayout:isDelayLoad()
    return true
end

---@private
function UIMiniGameMainLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIMiniGameMainLayout:initCreateEvent()
    Events.StartWaitMiniGameMatchTimerEvent:registerCallBack(function(countdown)
        self:show()
        self:setCountdown(countdown)
    end)
    Events.ShowMiniGameMatchDialogContentEvent:registerCallBack(function(contents)
        self:show()
        self.contents = {}
        LuaTimer:cancel(self.dialogTimer)
        self:setDialogContents(contents)
    end)
end

---@private
function UIMiniGameMainLayout:onLoad()
    self.siCountdown = self:getChildWindow("MiniGameMain-Countdown", GUIType.StaticImage)
    self.stCountdownText = self:getChildWindow("MiniGameMain-CountdownText", GUIType.StaticText)
    self.siDialog = self:getChildWindow("MiniGameMain-Dialog", GUIType.StaticImage)
    self.stDialogText = self:getChildWindow("MiniGameMain-DialogText", GUIType.StaticText)
    self.siBackHall = self:getChildWindow("MiniGameMain-BackHall", GUIType.StaticImage)
    self.llWoodenMan = self:getChildWindow("MiniGameMain-WoodenMan123", GUIType.Layout)
    self.llWoodenManRedLight = self:getChildWindow("MiniGameMain-WoodenMan123-Red-Light", GUIType.Layout)
    self.llWoodenManGreenLight = self:getChildWindow("MiniGameMain-WoodenMan123-Green-Light", GUIType.Layout)
    self.stWoodenManCountdownText = self:getChildWindow("MiniGameMain-WoodenMan123-CountDown-Text", GUIType.StaticText)
    self.stWoodenManWarning = self:getChildWindow("MiniGameMain-WoodenMan123-Warning", GUIType.StaticImage)
    self.siReadyGo = self:getChildWindow("MiniGameMain-ReadyGo", GUIType.StaticImage)
    self.stCurPayerRange = self:getChildWindow("MiniGameMain-CurPayer-Range", GUIType.StaticText)
    self.stCurPayerText = self:getChildWindow("MiniGameMain-CurPlayer-Text", GUIType.StaticText)
    self.llCurPayer = self:getChildWindow("MiniGameMain-CurPlayer-Layout", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function UIMiniGameMainLayout:initView()
    self.siDialog:SetVisible(false)
    self.siCountdown:SetVisible(false)
    self.siBackHall:SetVisible(false)
    self.siReadyGo:SetVisible(false)
end

---@private
function UIMiniGameMainLayout:initEvent()
    self.siBackHall:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("mini.game.lose.tip"))
                    .setRightText("gui.backHall")
                    .setRightClickListener(function()
            PlayerManager:getClientPlayer():sendPacket({
                pid = "LeaveMiniGameMatch"
            })
        end)        .setLeftText("gui.watch")
                    .show()
    end)
    Events.ShowMiniGameReadyGoEvent:registerCallBack(function(visible)
        self:showReadyGo(visible)
    end)

    Events.MiniGameAreaDataEvent:registerCallBack(function(minCount, maxCount)
        self.stCurPayerRange:SetText("( " .. minCount .. " - " .. maxCount .. " )")
    end)
    Events.MiniGameAreaPlayerCountEvent:registerCallBack(function(curCount)
        self:updateCurCount(curCount)
    end)
end

function UIMiniGameMainLayout:onTick()
    self.siBackHall:SetVisible(PlayerManager:getClientPlayer().Player:isActorInvisible())
end

---@private
function UIMiniGameMainLayout:updateCurCount(curCount)
    self.llCurPayer:SetVisible(CMiniGameMgr.curGameMatch == nil and curCount > 0)
    self.stCurPayerText:SetText(curCount)
    if curCount == 0 then
        self:hide()
    end
end

---@private
function UIMiniGameMainLayout:setCountdown(countdown)
    LuaTimer:cancel(self.countdownTimer)
    if countdown <= 0 then
        self.siCountdown:SetVisible(false)
        return
    end
    self.siCountdown:SetVisible(true)
    self.stCountdownText:SetText(tostring(countdown))
    self.countdownTimer = LuaTimer:scheduleTimerWithEnd(function()
        countdown = countdown - 0.1
        if countdown < 0 then
            countdown = 0
        end
        self.stCountdownText:SetText(tostring(math.floor(countdown)))
    end, function()
        self.siCountdown:SetVisible(false)
    end, 100, math.floor(countdown * 10))
end

---@private
---@param contents string[]
function UIMiniGameMainLayout:setDialogContents(contents)
    self.contents = contents
    ---@type string
    local _, content = next(self.contents)
    if not content then
        self.siDialog:SetVisible(false)
        return
    end
    table.remove(self.contents, 1)
    content = Lang:getString(content)
    local times = math.min(#content, 80)
    local charSub = #content / times
    local curIndex = 0
    self.siDialog:SetVisible(true)
    self.stDialogText:SetText("")
    self.dialogTimer = LuaTimer:scheduleTimerWithEnd(function()
        curIndex = curIndex + charSub
        local text = content:sub(1, math.floor(curIndex + 1))
        self.stDialogText:SetText(text)
    end, function()
        self.dialogTimer = LuaTimer:schedule(function()
            self.siDialog:SetVisible(false)
            self:setDialogContents(self.contents)
        end, 1500)
    end, 30, times)
end

function UIMiniGameMainLayout:showReadyGo(visible)
    self.siReadyGo:SetVisible(visible)
    if visible then
        self.siReadyGo:PlayEffect1("")
        self.siReadyGo:SetEffectName("g1046_mini_game_01_ready.effect")
    end
end

return UIMiniGameMainLayout
