---
--- Created by Jimmy.
--- DateTime: 2018/9/13 0028 11:37
---
---@type SConnectorCenter
local SConnectorCenter = T(Global, "ConnectorCenter")

BaseListener = {}
BaseListener.callbacks = {}

local function IsWatch(userId)
    local manager = GameServer:getRoomManager()
    if not manager:isUserAttrExisted(userId) then
        return false
    end
    local attr = manager:getUserAttrInfo(userId)
    if attr.followEnterType == 2 then
        return true
    end
    return false
end

local function setFollowModeAndTeleport(player, follower)
    LuaTimer:schedule(function()
        player:setAllowFlying(true)
        player:setFlying(true)
    end, 10)
    PacketSender:sendIntoFollowMode(player.rakssid, tostring(follower.userId))
    PacketSender:sendLuaCommonData(player.rakssid, "JoinGameStatus", tostring(PlayerManager:getJoinGameStatus()))
end

local function intoFollowMode(player, targetUserId)
    local _player = PlayerManager:getPlayerByUserId(targetUserId)
    if _player then
        player:addNightVisionPotionEffect(43200)
        player:teleportPos(_player:getPosition())
        Events.PlayerIntoFollowModeEvent:invoke(player, _player)
        setFollowModeAndTeleport(player, _player)
    end
end

function BaseListener.registerCallBack(event, func)
    BaseListener.callbacks[event] = func
end

function BaseListener:init()
    CEvents.GameInitEvent:registerCallBack(self.onGameInit)
    CEvents.PlayerLoginEvent:registerCallBack(self.onPlayerLogin)
    CEvents.PlayerLogoutEvent:registerCallBack(self.onPlayerLogout)
    CEvents.PlayerReadyEvent:registerCallBack(self.onPlayerReady)
    CEvents.PlayerAttackedEvent:registerCallBack(self.onPlayerHurt)
    CEvents.PlayerFirstSpawnEvent:registerCallBack(self.onPlayerFirstSpawn)
    CEvents.PlayerRespawnEvent:registerCallBack(self.onPlayerRespawn)
    CEvents.PlayerDieEvent:registerCallBack(self.onPlayerDied)
    CEvents.PlayerDieTipEvent:registerCallBack(self.onPlayerDiedTip)
    CEvents.PlayerMoveEvent:registerCallBack(self.onPlayerMove)
    CEvents.PlayerAfterRespawnEvent:registerCallBack(self.onPlayerAfterRespawn)
    CEvents.ClientCommonDataEvent:registerCallBack(self.onClientCommonData)
    CEvents.SpawnEntityEvent:registerCallBack(self.onSpawnEntity)
    CEvents.RemoveEntityEvent:registerCallBack(self.onRemoveEntity)
    CEvents.PlayerReconnectSuccessEvent:registerCallBack(self.onPlayerReconnectSuccess)
    CEvents.SavePlayerDBDataEvent:registerCallBack(self.onSavePlayerDBData)
    CEvents.PlayerDynamicAttrEvent:registerCallBack(self.onPlayerDynamicAttr)
    CEvents.GameStatusChangeEvent:registerCallBack(self.onGameStatusChange)
    CEvents.ReceiveRoomCommonMsgEvent:registerCallBack(self.onReceiveRoomCommonMsg)
    Events.GetDataFromDBEvent:registerCallBack(self.onGetDataFromDB)
end

---@param GamePath string
---@param ver string
---@param serverWorld ServerWorld
---@param config RoomGameConfig
function BaseListener.onGameInit(GamePath, ver, serverWorld, config)
    GameType = config.gameType
    HostApi.log(VarDump(ServerWorld))
    BaseMain:setIsChina(config.isChina)
    local mapPath = string.gsub(tostring(GamePath), "config.yml", "")
    --[[
        2021/3/31
        目前不支持服务器和客户端使用不同的配置文件，但是服务器和客户端允许有同名
        但不同逻辑的XXXXConfig.lua文件，也就是说服务器和客户端允许有不同的预处理逻
        辑。所以服务器和客户端可能需要使用不一样的离线预处理后的二进制配置文件。
        所以暂时禁用服务器使用二进制配置文件，地图的二进制配置文件是客户端专用的。
        目前只关注客户端的游戏启动速度，所以客户端能使用二进制配置文件就可以了
    ]]
    ConfigLoader.setBinaryEnabled(false)
    ConfigLoader.setMapPath(mapPath)
    FileUtil:setMapPath(mapPath)
    FileUtil:setRootPath("./")
    EngineWorld:setWorld(serverWorld)
    PacketSender:init()
    AppProps:init()
    WebService:init(ver, config)
    CommonTask:start()
    PlayerManager:setMaxPlayer(config.maxPlayers)
    PlayerManager:setRoomMaxPlayer(config.maxPlayers)
    PlayerManager:setWatchMode(config.watchMode)
    require "engine_server.helper.GMHelper"
    Global:loadSetting()
    Plugins.LoadAllPlugins()
    local callback = BaseListener.callbacks[CEvents.GameInitEvent]
    if callback ~= nil then
        callback(FileUtil.getConfigFromYml("config"))
    end

    WebService:GetExpRule()
    PlayerIdentityCache:init()
    GameAnalyticsRequest.asyncInit(3)
    SumRechargeConfig:init()
    MaxRecordHelper:init()
    require "engine_base.config.CommonActivityChestConfig"
    require "engine_base.config.CommonActivityConfig"
    require "engine_base.config.CommonActivityRewardConfig"
    require "engine_base.config.MustLotteryPriceConfig"
    require "engine_base.config.LuckyLotteryPrice"
    require "engine_base.config.LuckyValueConfig"
    require "engine_base.config.BlindBoxConfig"
    require "engine_base.config.BlindBoxRewardConfig"

    if Platform.isWindow() then
        HU.Init("engine_base.hotupdate.hotupdatelist", {
            FileUtil:getScriptPath() .. "/lua/base",
            FileUtil:getScriptPath() .. "/lua/server",
            "./Media/Scripts/Engine/lua"
        })
    end
end

---@param clientPeer ClientPeer
---@param clientInfo string
---@param enableIndie number
---@param gameTimeToday number
function BaseListener.onPlayerLogin(clientPeer, clientInfo, enableIndie, gameTimeToday)
    ---玩家进入游戏前发送服务器配置
    local builder = DataBuilder.new()
    builder:addParam("isChina", BaseMain:isChina())
    builder:addParam("regionId", GameServer:getServerConfig().regionId)
    builder:addParam("gameId", GameServer:getServerConfig().gameId)
    PacketSender:sendLuaCommonData(clientPeer:getRakssid(), "ServerInfo", builder:getData())

    if IsWatch(clientPeer:getPlatformUserId()) then
        ---好友跟随进入观战模式
        local player = BasePlayer.new(clientPeer)
        PlayerManager:addWatcher(player)
        PacketSender:sendPlayerDBReady(player.rakssid)
        player:subHealth(player:getHealth() + 1)
        player:sendLoginResult(true, player.dynamicAttr.team, "",
                PlayerManager:getPlayerCount(), PlayerManager:getMaxPlayer())
        return false
    end
    ---@type SBasePlayer
    local player = PlayerManager:getPlayerByUserId(clientPeer:getPlatformUserId())
    if player then
        ---顶号登录，直接使用现有玩家，不重置玩家数据
        local entityPlayerMP = clientPeer:getEntityPlayer()
        local oldPosition = player.entityPlayerMP:getPosition()
        local oldYaw = player.entityPlayerMP:getYaw()
        entityPlayerMP:clonePlayer(player.entityPlayerMP, true)
        player:initStaticAttr(player.entityPlayerMP:getTeamId())
        player.clientPeer = clientPeer
        player.entityPlayerMP = entityPlayerMP
        player.rakssid = clientPeer:getRakssid()
        player.isKickOut = false
        LuaTimer:schedule(function()
            player:teleportPosWithYaw(oldPosition, oldYaw)
        end, 100)
        if player:checkReady() then
            ---顶号登录需要保存一次数据，否则会拉取到旧数据
            DBManager:callSavePlayerData(player)
        end
        return DBManager:onPlayerLogin(player)
    end
    ---------------正常登录流程---------------
    if PlayerManager:isPlayerFull() then
        HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGamePlayerIsEnough(), GameOverCode.PlayerIsEnough)
        return true
    end
    GameAnalyticsCache:addClientInfo(clientPeer:getPlatformUserId(), clientInfo)
    local code, status, c_callback
    local callback = BaseListener.callbacks[CEvents.PlayerLoginEvent]
    if callback == nil then
        code = GameOverCode.Success
        player = BasePlayer.new(clientPeer)
        player:initStaticAttr(player.dynamicAttr.team)
    else
        code, player, status, c_callback = callback(clientPeer)
        if code == GameOverCode.GameStarted then
            HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGameHasStarting(), GameOverCode.GameStarted)
            return true
        end
        if code ~= GameOverCode.Success then
            HostApi.sendGameover(clientPeer:getRakssid(), IMessages:msgGameOver(), GameOverCode.GameOver)
            return true
        end
        if player == nil then
            code = GameOverCode.Success
            player = BasePlayer.new(clientPeer)
            player:initStaticAttr(player.dynamicAttr.team)
        end
    end
    PlayerManager:addPlayer(player)
    if BaseMain:isChina() and Platform.isLinux() then
        player.gameTimeToday = gameTimeToday or 0
    else
        player.gameTimeToday = -1
    end
    player.enableIndie = enableIndie or false
    if PlayerManager:isPlayerFull() then
        HostApi.sendStartGame(PlayerManager:getPlayerCount())
    end
    if status ~= nil and status >= 1 and status <= 2 then
        HostApi.sendGameStatus(clientPeer:getRakssid(), status)
    end
    if c_callback ~= nil then
        c_callback()
    end
    return DBManager:onPlayerLogin(player)
end

function BaseListener.onPlayerLogout(rakssid)
    local watcher = PlayerManager:getWatcherByRakssid(rakssid)
    if watcher then
        SConnectorCenter:onUserOut(watcher.userId)
        PlayerManager:subWatcher(watcher)
        return true
    end

    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return false
    end
    SConnectorCenter:onUserOut(player.userId)
    GameGroupManager:removeUser(player.userId)
    SumRechargeHelper:onPlayerLogout(player.userId)
    CommonActivity:onPlayerLogout(player)
    GameAnalyticsCache:forceSendEvents(player.userId)
    PlayerManager:subPlayer(player)
    local clear = function()
        Plugins.CallPluginFunc("onPlayerLogout", player)
        ---玩家正常退出游戏后，保存一次数据
        if not player.isKickOut then
            DBManager:callSavePlayerData(player)
        end
        player:onPlayerLogout()
        if DBManager:isAutoCache() then
            DBManager:removeCache(player.userId)
        end
        RewardManager:removeRewardCache(player.userId)
        GameAnalyticsCache:removeCache(player.userId)
        MaxRecordHelper:onPlayerLogout(player.userId)
        SumRechargeHelper:removeCache(player)
    end
    local callback = BaseListener.callbacks[CEvents.PlayerLogoutEvent]
    if callback == nil then
        clear()
        return true
    end
    callback(player)
    clear()
    return true
end

function BaseListener.onPlayerReady(rakssid)
    local player = PlayerManager:getWatcherByRakssid(rakssid)
    if player then
        SConnectorCenter:onUserIn(player.userId)
        PacketSender:sendDataReport(rakssid, "follow_watch", GameType)
        intoFollowMode(player, player.dynamicAttr.targetUserId)
        return
    end
    player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        HostApi.sendGameover(rakssid, IMessages:msgGameOver(), GameOverCode.ReadyNoPlayer)
        return
    end
    SConnectorCenter:onUserIn(player.userId)
    local callback = BaseListener.callbacks[CEvents.PlayerReadyEvent]
    if callback == nil then
        return
    end
    player.isReady = true
    Plugins.CallPluginFunc("onPlayerReady", player)
    local time = callback(player)
    DBManager:onPlayerReady(player)
    SumRechargeHelper:onPlayerReady(player)
    ExchangeHelper:onPlayerReady(player)
    if time ~= nil and time > 0 then
        player:addNightVisionPotionEffect(time)
    end
    if player.dynamicAttr.followEnterType == 1 then
        PacketSender:sendDataReport(rakssid, "follow_game", GameType)
    end
    CommonActivity:onPlayerReady(player)
end

function BaseListener.onPlayerFirstSpawn(clientPeer)
    local player = PlayerManager:getPlayerByRakssid(clientPeer:getRakssid())
    if player == nil then
        return
    end
    PlayerIdentityCache:onPlayerSpawn(player)
    local callback = BaseListener.callbacks[CEvents.PlayerFirstSpawnEvent]
    if callback == nil then
        return
    end
    callback(player)
end

function BaseListener.onPlayerAfterRespawn(clientPeer)
    local player = PlayerManager:getPlayerByRakssid(clientPeer:getRakssid())
    if player == nil then
        return
    end
    local callback = BaseListener.callbacks[CEvents.PlayerAfterRespawnEvent]
    if callback == nil then
        return
    end
    callback(player)
end

function BaseListener.onPlayerRespawn(clientPeer)
    local player = PlayerManager:getPlayerByRakssid(clientPeer:getRakssid())
    if player == nil then
        return
    end
    PlayerIdentityCache:onPlayerSpawn(player)
    local callback = BaseListener.callbacks[CEvents.PlayerRespawnEvent]
    if callback == nil then
        return
    end
    player:respawn(clientPeer)
    local time = callback(player)
    if time ~= nil and time > 0 then
        player:addNightVisionPotionEffect(time)
    end
end

function BaseListener.onGetDataFromDB(userId, subKey, data)
    local callback = BaseListener.callbacks[Events.GetDataFromDBEvent]
    if callback == nil then
        return
    end
    local player = PlayerManager:getPlayerByUserId(userId)
    if player ~= nil then
        if DBManager:isAutoCache() then
            DBManager:addCache(userId, subKey, data)
        end
        callback(player, subKey, data)
    end
end

function BaseListener.onClientCommonData(userId, key, data)
    CommonDataEvents:dispatchEvent(userId, key, data)
end

function BaseListener.onSpawnEntity(entity, type)
    if not EngineWorld:getWorld() then
        return
    end
    local lEntity = EntityCache:createEntityCache(entity, type)
    local callback = BaseListener.callbacks[CEvents.SpawnEntityEvent]
    if callback then
        callback(lEntity)
    end
end

function BaseListener.onRemoveEntity(entityId)
    EntityCache:removeEntityCache(entityId)
end

function BaseListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---攻击者如果是 观战者拦截攻击
    if hurtFrom and PlayerManager:getWatcherByUserId(hurtFrom:getPlatformUserId()) then
        return false
    end

    local callback = BaseListener.callbacks[CEvents.PlayerAttackedEvent]
    if callback ~= nil then
        return callback(hurtPlayer, hurtFrom, damageType, hurtValue)
    end
    return true
end

function BaseListener.onPlayerDied(diePlayer, iskillByPlayer, killPlayer)
    ---死亡者如果是 观战者必须死
    if diePlayer and PlayerManager:getWatcherByUserId(diePlayer:getPlatformUserId()) then
        return true
    end

    local callback = BaseListener.callbacks[CEvents.PlayerDieEvent]
    if callback ~= nil then
        return callback(diePlayer, iskillByPlayer, killPlayer)
    end
    return true
end

function BaseListener.onPlayerDiedTip(diePlayer, killPlayer)
    ---死亡者如果是 观战者 不提示
    if diePlayer and PlayerManager:getWatcherByUserId(diePlayer:getPlatformUserId()) then
        return false
    end

    local callback = BaseListener.callbacks[CEvents.PlayerDieTipEvent]
    if callback ~= nil then
        return callback(diePlayer, killPlayer)
    end
    return true
end

function BaseListener.onPlayerMove(pPlayer, ...)
    ---移动者如果是 观战者 默认允许移动
    if pPlayer and PlayerManager:getWatcherByUserId(pPlayer:getPlatformUserId()) then
        return true
    end
    local callback = BaseListener.callbacks[CEvents.PlayerMoveEvent]
    if callback ~= nil then
        return callback(pPlayer, ...)
    end
    return true
end

function BaseListener.onPlayerReconnectSuccess(clientPeer)

end

function BaseListener.onSavePlayerDBData(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player ~= nil then
        ---玩家被踢退出游戏，保存一次数据
        player.isKickOut = true
        DBManager:callSavePlayerData(player)
    end
end

function BaseListener.onPlayerDynamicAttr(attr)
    local userId = attr.userId
    if not Platform.isWindow() then
        if Server.Instance():getEnableRoom() then
            LuaTimer:schedule(function(requestId)
                local player = PlayerManager:getPlayerByUserId(userId)
                local watcher = PlayerManager:getWatcherByUserId(userId)
                if not player and not watcher then
                    GameServer:getRoomManager():sendUserOut(userId, requestId)
                end
            end, 90000, nil, attr.requestId)
        end
    end
    if attr.followEnterType == 2 then
        return
    end
    local callback = BaseListener.callbacks[CEvents.PlayerDynamicAttrEvent]
    if callback then
        callback(attr)
    end
end

function BaseListener.onGameStatusChange(status)
    PlayerManager:onGameStatusChange(status)
end

function BaseListener.onReceiveRoomCommonMsg(content)
    local ok, result = pcall(json.decode, content)
    if not ok then
        return
    end
end

return BaseListener