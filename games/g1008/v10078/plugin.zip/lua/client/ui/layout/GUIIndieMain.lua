---@class UIIndieMainLayout : IGUILayout
local UIIndieMainLayout = class("UIIndieMainV3Layout", IGUILayout)
---@type FriendManager
local FriendManager = T(Global, "FriendManager")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type TeamService
local TeamService = T(Global, "TeamService")

function UIIndieMainLayout:ctor(parent)
    self.super.ctor(self, "IndieMain.json", parent)
end

function UIIndieMainLayout:onLoad()
    self.btnSetting = self:getChildWindow("IndieMain-Setting", GUIType.Button)
    self.btnSkin = self:getChildWindow("IndieMain-Skin", GUIType.Button)
    self.btnMail = self:getChildWindow("IndieMain-Mail", GUIType.Button)
    self.stCubeNum = self:getChildWindow("IndieMain-Cube-Num", GUIType.StaticText)
    self.btnCubeAdd = self:getChildWindow("IndieMain-Cube-Add", GUIType.Button)
    self.stKeyNum = self:getChildWindow("IndieMain-Key-Num", GUIType.StaticText)
    self.btnKeyAdd = self:getChildWindow("IndieMain-Key-Add", GUIType.Button)
    self.btnRecharge = self:getChildWindow("IndieMain-Recharge", GUIType.Button)
    self.stRechargeText = self:getChildWindow("IndieMain-Recharge-Text", GUIType.StaticText)
    self.stPlayerName = self:getChildWindow("IndieMain-Player-Name", GUIType.StaticText)
    self.stLevel = self:getChildWindow("IndieMain-Level", GUIType.StaticText)
    self.llPlayerHead = self:getChildWindow("IndieMain-Player-Head", GUIType.Layout)
    self.pbExp = self:getChildWindow("IndieMain-Exp", GUIType.ProgressBar)
    self.stExpNum = self:getChildWindow("IndieMain-Exp-Num", GUIType.StaticText)
    self.btnSymbols = self:getChildWindow("IndieMain-Symbols", GUIType.Button)
    self.stSymbolsText = self:getChildWindow("IndieMain-Symbols-Text", GUIType.StaticText)
    self.btnChallenge = self:getChildWindow("IndieMain-Challenge", GUIType.Button)
    self.stChallengeText = self:getChildWindow("IndieMain-Challenge-Text", GUIType.StaticText)
    self.btnChest = self:getChildWindow("IndieMain-Chest", GUIType.Button)
    self.stChestText = self:getChildWindow("IndieMain-Chest-Text", GUIType.StaticText)
    self.btnRank = self:getChildWindow("IndieMain-Rank", GUIType.Button)
    self.stRankText = self:getChildWindow("IndieMain-Rank-Text", GUIType.StaticText)
    self.btnShop = self:getChildWindow("IndieMain-Shop", GUIType.Button)
    self.stShopText = self:getChildWindow("IndieMain-Shop-Text", GUIType.StaticText)
    self.btnCustom = self:getChildWindow("IndieMain-Custom", GUIType.Button)
    self.stCustomText = self:getChildWindow("IndieMain-Custom-Text", GUIType.StaticText)
    self.btnHorn = self:getChildWindow("IndieMain-Horn", GUIType.Button)
    self.stHornText = self:getChildWindow("IndieMain-Horn-Text", GUIType.StaticText)
    self.awPlayer = self:getChildWindow("IndieMain-Player", GUIType.ActorWindow)
    self.llMessageLayout = self:getChildWindow("IndieMain-Message-Layout", GUIType.Layout)
    self.llFriendListLayout = self:getChildWindow("IndieMain-Friend-List-Layout", GUIType.Layout)
    self.btnClassicMode = self:getChildWindow("IndieMain-Classic-Mode", GUIType.Button)
    self.stClassicName = self:getChildWindow("IndieMain-Classic-Name", GUIType.StaticText)
    self.btnDoubleMode = self:getChildWindow("IndieMain-Double-Mode", GUIType.Button)
    self.stDoubleName = self:getChildWindow("IndieMain-Double-Name", GUIType.StaticText)
    self.btnSoloMode = self:getChildWindow("IndieMain-Solo-Mode", GUIType.Button)
    self.stSoloName = self:getChildWindow("IndieMain-Solo-Name", GUIType.StaticText)
    self.btnFriendList = self:getChildWindow("IndieMain-Friend-List", GUIType.Button)

    ---@type GUIBedWarHead
    self.headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
    self.headItem:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.llPlayerHead:AddChildWindow(self.headItem.root)

    self.gvFriendList = GUIManager:createGUIWindow(GUIType.GridView, "IndieMain-Friend-List-GridView")
    self.gvFriendList:InitConfig(14, 0, 4)
    self.gvFriendList:SetVerticalAlignment(VerticalAlignment.Bottom)
    self.gvFriendList:SetArea({ 0, 5 }, { 0, -5 }, { 1, -10 }, { 1, -10 })
    self.llFriendListLayout:AddChildWindow(self.gvFriendList)
    self.gvFriendList:SetClipChild(false)
    self.llFriendListLayout:SetClipChild(true)

    ---@type GUIRollMessageWindow
    local messageItem = UIHelper.newGameGUIWindow("GUIRollMessage")
    self.llMessageLayout:AddChildWindow(messageItem.root)

    if Game:getPlayer():getSex() == 2 then
        self.awPlayer:SetActor1("girl.actor", "idle", 0)
    else
        self.awPlayer:SetActor1("boy.actor", "idle", 0)
    end

    self:initView()
    self:initEvent()

    self:onUpdatePlayerModel()
end

function UIIndieMainLayout:initView()
    self.stRechargeText:SetText(Lang:getString("gui.sumrecharge.txt"))
    self.stSymbolsText:SetText(Lang:getString("gui.game.rule.txt"))
    self.stChallengeText:SetText(Lang:getString("gui_bed_war_hall_challenge_title"))
    self.stChestText:SetText(Lang:getString("gui.box.chest.txt"))
    self.stRankText:SetText(Lang:getString("gui_rank_default_title_name"))
    self.stShopText:SetText(Lang:getString("gui_str_app_shop_shop"))
    self.stCustomText:SetText(Lang:getString("bed.war.custom.shop"))
    self.stHornText:SetText(Lang:getString("gui_bed_war_license_title"))
    self.stClassicName:SetText(Lang:getString("gui.mode.classic"))
    self.stDoubleName:SetText(Lang:getString("gui.mode.double"))
    self.stSoloName:SetText(Lang:getString("gui.mode.solo"))

    UIUtils.addRedDot(self.btnHorn, Define.RedDotKey.License, nil, { offset = VectorUtil.newVector2(0, 10) })
    UIUtils.addRedDot(self.btnChallenge, Define.RedDotKey.Challenge)
    UIUtils.addRedDot(self.btnClassicMode, Define.RedDotKey.ClassicMode, nil, { customImage = "set:bed_war_indie_main_new.json image:red_point_big" })
    UIUtils.updateRedDotCount(Define.RedDotKey.License, 1)
    UIUtils.addRedDot(self.btnFriendList, Define.RedDotKey.FriendApply, nil, { offset = VectorUtil.newVector2(4, -3) })
end

function UIIndieMainLayout:initEvent()
    self.btnSetting:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        GUIBedWarIndieSettingLayout:show()
    end)
    self.btnSkin:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_DRESS)
    end)
    self.btnMail:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_EMAIL)
    end)
    self.btnCubeAdd:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ClientHelper.onRecharge(1)
    end)
    self.btnKeyAdd:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        GUIStore:show(StoreId.CubeStore, 8)
    end)
    self.btnRecharge:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        ReportUtil.reportClickFirstRecharge(GUISumRechargeLayout.currentId)
        GUISumRechargeLayout:show()
    end)
    self.btnSymbols:registerEvent(GUIEvent.ButtonClick, function()
        GUIManager:showWindowByName("BedWarRune.json")
    end)
    self.btnChallenge:registerEvent(GUIEvent.ButtonClick, function()
        GUITreasureChallenge:onDataChange(TreasureChallenge.rewardData)
        GUITreasureChallenge:show(true)
    end)
    self.btnChest:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.clickUI()
        GUIBoxLottery:show()
    end)
    self.btnRank:registerEvent(GUIEvent.ButtonClick, function()
        GUIManager:showWindowByName("BedWarSeasonRank.json")
    end)
    self.btnShop:registerEvent(GUIEvent.ButtonClick, function()
        GUIStore:show(StoreId.CubeStore)
    end)
    self.btnCustom:registerEvent(GUIEvent.ButtonClick, function()
        GUICustomShop:show(true)
    end)
    self.btnHorn:registerEvent(GUIEvent.ButtonClick, function()
        GUILicense:show()
        CommonPacketSender:sendPlayerOpenLicense()
    end)
    self.btnFriendList:registerEvent(GUIEvent.ButtonClick, function()
        GUIFriends:show()
    end)

    self.btnClassicMode:registerEvent(GUIEvent.ButtonClick, function()
        self:onPlayerLockModel()
        TeamService:sendCreateTeam("g1008")
        UIUtils.updateRedDotCount(Define.RedDotKey.ClassicMode, 0)
    end)
    self.btnDoubleMode:registerEvent(GUIEvent.ButtonClick, function()
        if GUIBedWarHallToolBar:getPlayerLevel() >= 3 then
            self:onPlayerLockModel()
            TeamService:sendCreateTeam("g1062")
        else
            GUICustomDialog:showLevelLimit(3)
        end
    end)
    self.btnSoloMode:registerEvent(GUIEvent.ButtonClick, function()
        if GUIBedWarHallToolBar:getPlayerLevel() >= 3 then
            self:onPlayerLockModel()
            GamePacketSender:sendBedWarStartGame("g1061")
            Game:resetGame("g1061")
        else
            GUICustomDialog:showLevelLimit(3)
        end
    end)

    self.llMessageLayout:registerEvent(GUIEvent.Click, function()
        GUIBedWarHallChatLayout:show()
    end)

    self:registerEvent(CEvents.GameActionTriggerEvent, function(_type, params)
        if _type == CDefine.GameActionType.GAME_ACTION_REFRESH_DRESS then
            self:onUpdatePlayerModel()
        end
    end)

    self:registerEvent(Events.FinishLoadFriendDataEvent, function()
        self:onUpdateFriendList()
    end)

    self:registerDataCallBack("ShowSumRecharge", function(data)
        local id = data:getParam("Id")
        local config = SumRechargeConfig:getSumRecharge(id)
        if config then
            self.btnRecharge:SetVisible(true)
        else
            self.btnRecharge:SetVisible(false)
        end
    end, DataBuilderProcessor)

    self:registerDataCallBack("HallInfo", function(data)
        self:onHallInfoUpdate(data)
    end, DataBuilderProcessor)

    self:registerDataCallBack("IndieDailyLogin", function()
        UIUtils.updateRedDotCount(Define.RedDotKey.Challenge, 1)
        UIUtils.updateRedDotCount(Define.RedDotKey.ClassicMode, 1)
    end)
end

function UIIndieMainLayout:onTick()
    local showAd = ClientHelper.getBoolPrefs("ShowVideoAd") and (not isBeta)

    local count = PlayerWallet.getMoneyByCoinId(Define.Money.DIAMOND)
    self.stCubeNum:SetText(tostring(count))
end

function UIIndieMainLayout:onHallInfoUpdate(data)
    local level = data:getNumberParam("level")
    local curExp = data:getNumberParam("curExp")
    local maxExp = data:getNumberParam("maxExp")
    local key = data:getNumberParam("key")
    local isMax = data:getBoolParam("isMax")
    self.stLevel:SetText("LV." .. tostring(level))
    if not isMax then
        maxExp = maxExp > 0 and maxExp or 0
        local expTxt = string.format("%d/%d", curExp, maxExp)
        self.stExpNum:SetText(expTxt)
        self.pbExp:SetProgress(curExp / maxExp)
    else
        self.stExpNum:SetText("MAX")
        self.pbExpProgress:SetProgress(1)
    end
    self.stKeyNum:SetText(tostring(key))

    local user = UserManager.Instance():findUser(PlayerManager:getClientPlayer().userId)
    self.stPlayerName:SetText(user.userName)
    self.headItem:setUserInfo(UserInfoCache:GetCache(Game:getPlatformUserId()))
end

function UIIndieMainLayout:onUpdateFriendList()
    self.gvFriendList:RemoveAllItems()
    local itemHeight = math.floor(self.gvFriendList:GetPixelSize().y)
    local friendList = FriendManager.GetFriends()
    for i = 1, 4 do
        local userId = friendList[i]
        if userId and UserInfoCache:GetCache(userId) then
            ---@type GUIBedWarHead
            local headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
            headItem:setArea({ 0, 0 }, { 0, 0 }, { 0, itemHeight }, { 0, itemHeight })
            headItem:setUserInfo(UserInfoCache:GetCache(userId))
            self.gvFriendList:AddItem(headItem.root)
        end
    end
end

function UIIndieMainLayout:onUpdatePlayerModel()
    self.awPlayer:SetActorByUserId(Game:getPlatformUserId(), 0, true)
end

function UIIndieMainLayout:onPlayerLockModel()
    self.btnClassicMode:SetEnabled(false)
    self.btnDoubleMode:SetEnabled(false)
    self.btnSoloMode:SetEnabled(false)
    LuaTimer:cancel(self.lockKey or 0)
    self.lockKey = LuaTimer:schedule(function()
        self.btnClassicMode:SetEnabled(true)
        self.btnDoubleMode:SetEnabled(true)
        self.btnSoloMode:SetEnabled(true)
    end, 5000)
end

function UIIndieMainLayout:isMainControl()
    return true
end

return UIIndieMainLayout
