---@class UIBedWarIndieSettingLayout : IGUILayout
local UIBedWarIndieSettingLayout = class("UIBedWarIndieSettingLayout", IGUILayout)

local DefaultTabs = {
	Define.SettingTabType.Screen,
	Define.SettingTabType.Buttons,
	Define.SettingTabType.Sound,
	Define.SettingTabType.Account,
	Define.SettingTabType.System
}

SystemSettingRecord = {}
function onSaveSetting()
	if GUIBedWarIndieSettingLayout then
		ClientHelper.putStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_SystemSettings", json.encode(GUIBedWarIndieSettingLayout:getSystemSettingRecord()))
	end
end

---@private
function UIBedWarIndieSettingLayout:ctor(parent)
	self.super.ctor(self, "BedWarIndieSetting.json", parent)
end

---@private
function UIBedWarIndieSettingLayout:onLoad()
	self.defaultSetting = FileUtil.getConfigFromYml("setting/DefaultSettings")
	self.tabSetting = self.defaultSetting.SettingButton or DefaultTabs
	self.tabs = {}
	self.layouts = {}

	self.llContent = self:getChildWindow("BedWarIndieSetting-Content", GUIType.Layout)
	self.llTabs = self:getChildWindow("BedWarIndieSetting-Tabs", GUIType.Layout)
	self.lhTabList = self:getChildWindow("BedWarIndieSetting-Tab-List", GUIType.ListHorizontal)
	local llReturn = require("ui.window.GUIBedWarUIReturnControl").new("gui_setting_title", function()
		SoundUtil.clickUI()
		GUIBedWarIndieSettingLayout:hide()
	end)

	self.root:AddChildWindow(llReturn.root)
	self:initView()
	self:initEvent()
	self:setTabSelect(Define.SettingTabType.Screen)
end

---@private
function UIBedWarIndieSettingLayout:initView()
	self:initLayouts()
	self:initTabs()
end

---@private
function UIBedWarIndieSettingLayout:initLayouts()
	for index, tabType in pairs(self.tabSetting) do
		tabType = tonumber(tabType)
		local content
		if tabType == Define.SettingTabType.Screen then
			content = UIHelper.newGameGUIWindow("GUISettingBasic")
		elseif tabType == Define.SettingTabType.Sound then
			content = UIHelper.newGameGUIWindow("GUIIndieSettingSound")
		elseif tabType == Define.SettingTabType.Buttons then
			content = UIHelper.newGameGUIWindow("GUIIndieSettingOperation")
		end
		if content then
			self.llContent:AddChildWindow(content.root)
			content.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
			content.root:SetVisible(false)
			self.layouts[tabType] = content
		end
	end
end

---@private
function UIBedWarIndieSettingLayout:initTabs()
	for index, tabType in ipairs(self.tabSetting) do
		tabType = tonumber(tabType)
		local btn = GUIManager:createGUIWindow(GUIType.Button, " -Tab-" .. tabType)
		local line = GUIManager:createGUIWindow(GUIType.StaticImage, "BedWarIndieSetting-Tab-Line" .. tabType)
		self.lhTabList:AddChildWindow(btn)
		btn:AddChildWindow(line)
		btn:SetHorizontalAlignment(HorizontalAlignment.Center)
		line:SetHorizontalAlignment(HorizontalAlignment.Center)
		line:SetVerticalAlignment(VerticalAlignment.Bottom)
		btn:SetArea({ 0, 0 }, { 0.131757 * (index - 1), 0 }, { 1, -4 }, { 0.103041, 0 })
		line:SetArea({ 0, 0 }, { 0, -10 }, { 0.527675, 0 }, { 0, 2 })
		line:SetBackgroundColor({ 179 / 255, 176 / 255, 241 / 255, 1 })
		btn:SetText(Lang:getString(Define.SettingTabText[tabType]))
		btn:SetNormalImage("")
		btn:SetPushedImage("")
		btn:SetTextColor(Define.TabTextColor.Normal)
		line:SetVisible(true)
		btn:registerEvent(GUIEvent.ButtonClick, function()
			SoundUtil.clickUI()
			self:setTabSelect(tabType)
		end)
		self.tabs[tabType] = {
			btn = btn,
			line = line
		}

		if tabType == Define.SettingTabType.Back or tabType == Define.SettingTabType.Exit then
			btn:SetVerticalAlignment(VerticalAlignment.Bottom)
			local _index = #self.tabSetting - index + 1
			btn:SetArea({ 0, 0 }, { -0.131757 * (_index - 1), 0 }, { 1, -4 }, { 0.103041, 0 })
		end
	end
end

---@private
function UIBedWarIndieSettingLayout:initEvent()
	self:registerDataCallBack("PlayerReady", function()
		self:initCacheSetting()
	end)
end

---@private
---@param type number
function UIBedWarIndieSettingLayout:setTabSelect(type)
	if self.selectTab and self.selectTab ~= 0 then
		local oldTab = self.tabs[self.selectTab]
		if self.layouts[self.selectTab] then
			self.layouts[self.selectTab].root:SetVisible(false)
		else
			ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_CLOSE_SINGLE_SETTING)
		end
		oldTab.btn:SetNormalImage("")
		oldTab.btn:SetPushedImage("")
		oldTab.btn:SetTextColor(Define.TabTextColor.Normal)
		oldTab.line:SetVisible(true)
	end

	local newTab = self.tabs[type]
	if self.layouts[type] then
		self.layouts[type].root:SetVisible(true)
	elseif type == Define.SettingTabType.Account then
		ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ACCOUNT)
	elseif type == Define.SettingTabType.System then
		ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_VERSION)
	elseif type == Define.SettingTabType.Exit then
		CustomDialog.builder()
					.setContentText(Lang:getString("gui.message.exit.game"))
					.setLeftText("gui.cancel")
					.setRightText("gui.sure")
					.setLeftClickListener(function()

		end)
					.setRightClickListener(function()
			Game:exitGame()
		end)        .show()
	elseif type == Define.SettingTabType.Back then
		CustomDialog.builder().setTitleText("gui_dialog_tip_title_tip")
					.setRightText(Lang:getString("gui_dialog_tip_btn_sure"))
					.setContentText(Lang:getString("gui_bed_war_mane_back_hall_tip"))
					.setRightClickListener(function()
			GamePacketSender:sendBackHall()
		end)
					.setLeftText(Lang:getString("gui_dialog_tip_btn_cancel"))
					.show()
	end
	newTab.btn:SetNormalImage("set:bed_war_3_button.json image:btn_0_current01")
	newTab.btn:SetPushedImage("set:bed_war_3_button.json image:btn_0_current01")
	newTab.btn:SetTextColor(Define.TabTextColor.Select)
	newTab.line:SetVisible(false)
	self.selectTab = type
end

function UIBedWarIndieSettingLayout:initCacheSetting()
	SystemSettingRecord = {}
	local SettingJson = ClientHelper.getStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_SystemSettings", "")
	if string.sub(SettingJson, 1, 1) == "{" then
		SystemSettingRecord = json.decode(SettingJson)
	end
	self:initSystemSetting(SystemSettingRecord)
	if ClientNewReportUtil then
		ClientNewReportUtil:onReportCurrentControlModel(SystemSettingRecord.defaultOperation)
	end
end

function UIBedWarIndieSettingLayout:initSystemSetting(setting)
	local oldSetting = TableUtil.copyTable(setting)
	---帧数默认选择{ 1, 2 ,3}
	local defaultFPS = setting.defaultFPS or self.defaultSetting.defaultFPS
	self.layouts[Define.SettingTabType.Screen].fpsGroup:selectIndex(defaultFPS)

	---亮度进度条 [0-1]
	local defaultLuminance = setting.defaultLuminance or self.defaultSetting.defaultLuminance
	self.layouts[Define.SettingTabType.Screen]:refreshLuminance(defaultLuminance)

	---按钮大小进度条 [0-1]
	local defaultButtonSize = setting.defaultButtonSize or self.defaultSetting.defaultButtonSize
	self.layouts[Define.SettingTabType.Buttons]:refreshSize(defaultButtonSize)
	---灵敏度进度条 [0-1]
	local defaultSensitivity = setting.defaultSensitivity or self.defaultSetting.defaultSensitivity
	self.layouts[Define.SettingTabType.Screen]:refreshSensitive(defaultSensitivity)

	---视野距离进度条 [0-1]
	local defaultHorizon = setting.defaultHorizon or self.defaultSetting.defaultHorizon
	self.layouts[Define.SettingTabType.Screen]:refreshHorizon(defaultHorizon)

	---操作遥感选择{ 1, 2, 3, 4 } 1是旧按键 2是旧摇杆, 3是灵活摇杆, 4是跳跃前进按键
	local defaultOperation = setting.defaultOperation or self.defaultSetting.defaultOperation
	self.layouts[Define.SettingTabType.Buttons].opGroup:selectIndex(defaultOperation)
	---背景音乐开关{ 0, 1} 2是关 1是开
	local defaultBackGroundSwitch = setting.defaultBackGroundSwitch or self.defaultSetting.defaultBackGroundSwitch
	self.layouts[Define.SettingTabType.Sound].bgGroup:selectIndex(defaultBackGroundSwitch)
	---背景音乐大小进度条 [0-1]
	local defaultBackGroundVolume = setting.defaultBackGroundVolume or self.defaultSetting.defaultBackGroundVolume
	self.layouts[Define.SettingTabType.Sound]:refreshBackGround(defaultBackGroundVolume)
	---音效开关{ 0, 1} 2是关 1是开
	local defaultEffectSwitch = setting.defaultEffectSwitch or self.defaultSetting.defaultEffectSwitch
	self.layouts[Define.SettingTabType.Sound].soundGroup:selectIndex(defaultEffectSwitch)
	---音效大小进度条 [0-1]
	local defaultEffectVolume = setting.defaultEffectVolume or self.defaultSetting.defaultEffectVolume
	self.layouts[Define.SettingTabType.Sound]:refreshEffect(defaultEffectVolume)
	SystemSettingRecord = oldSetting
end

function UIBedWarIndieSettingLayout:getSystemSettingRecord()
	local setting = {}
	for key, value in pairs(SystemSettingRecord) do
		setting[key] = math.floor(value * 10) / 10
	end
	return setting
end

function UIBedWarIndieSettingLayout:onHide()
	ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_CLOSE_SINGLE_SETTING)
end

function UIBedWarIndieSettingLayout:onShow()
	if not self.first then
		local appPos = {
			minX = self.llContent:GetXPosition()[1],
			minY = self.llContent:GetYPosition()[1],
			maxX = (self.llContent:GetXPosition()[1] + self.llContent:GetWidth()[1]),
			maxY = (self.llContent:GetYPosition()[1] + self.llContent:GetHeight()[1])
		}
		ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_SETTING_VIEW_SIZE, json.encode(appPos))
		self.first = true
	end
	if self.selectTab == Define.SettingTabType.Account then
		ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ACCOUNT)
	elseif self.selectTab == Define.SettingTabType.System then
		ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_VERSION)
	end
end

return UIBedWarIndieSettingLayout
