local handler = T(Global, "PacketHandlers")

local observable = EventObservable.new()
observable:registerDataCallBack("pid", function(data)
    local success, res = pcall(json.decode, data)
    if not success then
        LogUtil.logError("[EventObservable:registerDataCallBack:pid]", res)
        return
    end
    local func = handler[res.pid]
    if not func then
        return
    end
    func(PlayerManager:getClientPlayer(), res)
end)

function handler:AddEventToDialog(package)
    GUIGMMain:addEventToDialog(package.event_map)
end

return handler