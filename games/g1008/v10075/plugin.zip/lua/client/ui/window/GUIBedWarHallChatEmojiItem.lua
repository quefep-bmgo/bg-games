---@class GUIBedWarHallChatEmojiItemWindow : IGUIWindow
local GUIBedWarHallChatEmojiItemWindow = class("GUIBedWarHallChatEmojiItemWindow", IGUIWindow)

---@private
function GUIBedWarHallChatEmojiItemWindow:ctor(...)
	self.super.ctor(self, "BedWarHallChatEmojiItem.json", ...)
end

---@private
function GUIBedWarHallChatEmojiItemWindow:onLoad()
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarHallChatEmojiItemWindow:initView()
	self.root = self:getChildWindowByName("BedWarHallChatEmojiItem", GUIType.StaticImage)
end

---@private
function GUIBedWarHallChatEmojiItemWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		---发表情
		GUIBedWarHallChatLayout:sendGameEmojiMsg(self.data.icon)
	end)
end

---@param data ChatEmojiData
function GUIBedWarHallChatEmojiItemWindow:onDataChanged(data)
	self.data = data
	self.root:SetImage(data.icon)
end

return GUIBedWarHallChatEmojiItemWindow
