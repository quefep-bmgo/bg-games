---@class UICreateTeamApplyListLayout : IGUILayout
local UICreateTeamApplyListLayout = class("UICreateTeamApplyListLayout", IGUILayout)
---@type TeamService
local TeamService = T(Global, "TeamService")
---@type FriendManager
local FriendManager = T(Global, "FriendManager")
---@type GUICreateTeamApplyItemWindow
local GUICreateTeamApplyItemWindow = require "ui.window.GUICreateTeamApplyItem"
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function UICreateTeamApplyListLayout:ctor(parent)
    self.super.ctor(self, "CreateTeamApplyList.json", parent)
end

---@private
function UICreateTeamApplyListLayout:onLoad()
    self.llRoot = self:getChildWindow("CreateTeamApplyList", GUIType.Layout)
    self.btnTeamApply = self:getChildWindow("CreateTeamApplyList-Team-Apply", GUIType.Button)
    self.btnTeamInvite = self:getChildWindow("CreateTeamApplyList-Team-Invite", GUIType.Button)
    self.btnFriendApply = self:getChildWindow("CreateTeamApplyList-Friend-Apply", GUIType.Button)
    self.llApplyContent = self:getChildWindow("CreateTeamApplyList-Apply-Content", GUIType.Layout)
    self.stApplyName = self:getChildWindow("CreateTeamApplyList-Apply-Name", GUIType.StaticText)
    self.stNoApplyText = self:getChildWindow("CreateTeamApplyList-No-Apply-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UICreateTeamApplyListLayout:initView()
    self.stNoApplyText:SetText(Lang:getString("gui.no.new.msg"))
    self.lvApplyList = IGUIListView.new("CreateTeamApplyList-Apply-List", self.llApplyContent)
    self.lvApplyList:setArea({ 0, 22 }, { 0, 56 }, { 1, -44 }, { 1, -76 })
    self.lvApplyList:setItemSpace(16)

    UIUtils.addRedDot(self.btnTeamApply, Define.RedDotKey.TeamApply, nil, { offset = VectorUtil.newVector2(4, -3) })
    UIUtils.addRedDot(self.btnFriendApply, Define.RedDotKey.FriendApply, nil, { offset = VectorUtil.newVector2(4, -3) })
    UIUtils.addRedDot(self.btnTeamInvite, Define.RedDotKey.TeamInvite, nil, { offset = VectorUtil.newVector2(4, -3) })
end

---@private
function UICreateTeamApplyListLayout:initEvent()
    self.llRoot:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)
    self.btnTeamApply:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnFriendApply:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnTeamInvite:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self:registerEvent(Events.JoinTeamEvent, function()
        self:hide()
    end)
end

---@private
function UICreateTeamApplyListLayout:isShowAnim()
    return false
end

function UICreateTeamApplyListLayout:showApplyList(type)
    if type == Define.ApplyType.TeamApply then
        self.btnTeamApply:SetVisible(true)
        self.btnTeamInvite:SetVisible(false)
        self.btnFriendApply:SetVisible(false)
        self.stApplyName:SetText(Lang:getString("gui.team.apply.list"))
        self.llApplyContent:SetYPosition(self.btnTeamApply:GetYPosition())
        self:updateTeamApplyList()
    elseif type == Define.ApplyType.FriendApply then
        self.btnTeamApply:SetVisible(false)
        self.btnTeamInvite:SetVisible(false)
        self.btnFriendApply:SetVisible(true)
        self.stApplyName:SetText(Lang:getString("gui.friend.apply.list"))
        self.llApplyContent:SetYPosition(self.btnFriendApply:GetYPosition())
        self:updateFriendApplyList()
    else
        self.btnTeamApply:SetVisible(false)
        self.btnTeamInvite:SetVisible(true)
        self.btnFriendApply:SetVisible(false)
        self.stApplyName:SetText(Lang:getString("gui.team.invite.list"))
        self.llApplyContent:SetYPosition(self.btnTeamApply:GetYPosition())
        self:updateTeamInviteList()
    end
    self:updateListHeight()
    self:show()
end

---@private
function UICreateTeamApplyListLayout:updateTeamApplyList()
    self.lvApplyList:clearItems()
    local infoList = TeamService:getApplyList()
    for _, userInfo in pairs(infoList) do
        local item = GUICreateTeamApplyItemWindow.new()
        item:onDataChanged(userInfo)
        item:setOKCallback(function()
            TeamService:agreeApply(userInfo.userId)
            self:removeApplyItem(item)
        end)
        item:setRejectionCallback(function()
            TeamService:rejectionApply(userInfo.userId)
            self:removeApplyItem(item)
        end)
        self.lvApplyList:addItem(item)
    end
end

---@private
function UICreateTeamApplyListLayout:updateFriendApplyList()
    self.lvApplyList:clearItems()
    for _, userInfo in pairs(FriendManager.GetUndoFriendRequest()) do
        local item = GUICreateTeamApplyItemWindow.new()
        item:onDataChanged(userInfo)
        item:setOKCallback(function()
            FriendManager.FriendOperation(Define.FriendOperationType.Agree, userInfo.userId)
            self:removeApplyItem(item)
        end)
        item:setRejectionCallback(function()
            FriendManager.FriendOperation(Define.FriendOperationType.Refuse, userInfo.userId)
            self:removeApplyItem(item)
        end)
        self.lvApplyList:addItem(item)
    end
end

---处理好友发出来的组队邀请
---@private
function UICreateTeamApplyListLayout:updateTeamInviteList()
    self.lvApplyList:clearItems()
    local inviteList = TeamService:getInviteList()
    for _, inviteData in pairs(inviteList) do
        local item = GUICreateTeamApplyItemWindow.new()
        item:onDataChanged(inviteData.info)
        item:setOKCallback(function()
            if TeamService:sendJoinTeam(inviteData.teamId, inviteData.token, inviteData.regionId) then
                TeamService:changeTeamInviteOperate(inviteData, Define.TeamInviteOperate.Agree)
                self:removeApplyItem(item)
            end
        end)
        item:setRejectionCallback(function()
            TeamService:sendRejectionInvite(inviteData.userId, inviteData.teamId, inviteData.regionId)
            TeamService:changeTeamInviteOperate(inviteData, Define.TeamInviteOperate.Rejection)
            self:removeApplyItem(item)
        end)
        self.lvApplyList:addItem(item)
    end
end

---@param item GUICreateTeamApplyItemWindow
function UICreateTeamApplyListLayout:removeApplyItem(item)
    LuaTimer:schedule(function()
        self.lvApplyList:removeItem(item)
        self:updateListHeight()
    end, 100)
end

---@private
function UICreateTeamApplyListLayout:updateListHeight()
    local maxHeight = self.root:GetPixelSize().y - self.llApplyContent:GetYPosition()[2] - 96
    local maxCount = math.floor(math.min((maxHeight - 57) / 130)) + 0.5
    local contentHeight = math.min(math.max(self.lvApplyList:getItemCount(), 1), maxCount) * 130 + 60
    self.llApplyContent:SetHeight({ 0, contentHeight })
    self.stNoApplyText:SetVisible(self.lvApplyList:getItemCount() == 0)
    self.lvApplyList.root:SetScrollOffset(10)
end

return UICreateTeamApplyListLayout
