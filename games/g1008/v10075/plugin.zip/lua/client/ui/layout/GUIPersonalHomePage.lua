---@class BedWarUserInfo : UserInfo
---@field pageLike number 主页被点赞数
---@field battleLikeCount number 对战被点赞数
---@field maxRank number 历史最高段位
---@field totalGameTimes number 游戏总场次
---@field totalRankTimes number 排位总场次
---@field totalFunTimes number 娱乐总场次
---@field runeLevel number 符文等级
---@field dressNum number 个性装饰数量
---@field playDays number 游戏天数
---@field fansNum number 粉丝数量
---@field followNum number 关注他人的数量
---@field currentPet number 当前装备的宠物
---@field valuableDress string 价值最高的三个个性装扮
---@field dailyVisitorCount number 今日访客数
---@field historyVisitorCount string 历史访客数
---@field visitorInfos table 访客信息
---@field followStatus number 关注关系状态: 0.无关系 1.关注 2.粉丝 3.互相关注
---@field curOldHonorId number 当前的旧段位
---@field maxOldHonorId number 最高的旧段位
---@field friendCount number 好友数量
---@field dressCount number 装扮数量

---@class UIPersonalHomePageLayout : IGUILayout
local UIPersonalHomePageLayout = class("UIPersonalHomePageLayout", IGUILayout)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

local pageRecord = {
    selfPage = {
        userId = 0,
        page = 1,
        isOpen = false
    },
    otherPlayerPage = {
        userId = 0,
        page = 1,
        isOpen = false
    }
}

function UIPersonalHomePageLayout:ctor(parent)
    self.super.ctor(self, "PersonalHomePage.json", parent)
end

function UIPersonalHomePageLayout:onLoad()
    self.llBg = self:getChildWindow("PersonalHomePage-Bg", GUIType.Layout)
    self.llInfo = self:getChildWindow("PersonalHomePage-Info", GUIType.Layout)
    self.llTabs = self:getChildWindow("PersonalHomePage-Tabs", GUIType.Layout)
    self.cbHome = self:getChildWindow("PersonalHomePage-Home", GUIType.CheckBox)
    self.cbBattleResults = self:getChildWindow("PersonalHomePage-Battle-Results", GUIType.CheckBox)
    self.cbSkin = self:getChildWindow("PersonalHomePage-Skin", GUIType.CheckBox)
    self.cbPersonality = self:getChildWindow("PersonalHomePage-Personality", GUIType.CheckBox)
    self:initView()
    self:initEvent()
    self.curUserIds = {}
end

function UIPersonalHomePageLayout:initView()
    local llReturn = require("ui.window.GUIBedWarUIReturnControl").new("gui.bed_war.back.btn.txt", function()
        Events.ClosePersonalHomePageEvent:invoke()
    end)
    self.root:AddChildWindow(llReturn.root)

    self.cbHome:SetText(Lang:getString("gui.personal.home"))
    self.cbBattleResults:SetText(Lang:getString("gui.personal.battle.results"))
    self.cbSkin:SetText(Lang:getString("gui.personal.skin"))
    self.cbPersonality:SetText(Lang:getString("gui.personal.personality"))

    self.llTabs:SetVisible(false)
end

function UIPersonalHomePageLayout:initEvent()
    self:registerEvent(Events.ClosePersonalHomePageEvent, function()
        self:closePersonalHomePage()
    end)

    self.tapGroup = RadioBoxGroup.new(SoundConfig.switchSetting)

    self.tapGroup:addCheckBox(self.cbHome, function(checked)
        if checked then
            self.cbHome:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
            if self.playerInfo == nil then
                self.playerInfo = require("ui.window.GUIPersonalHomePlayerInfo").new()
                self.llInfo:AddChildWindow(self.playerInfo.root)
            end
            self:onChangePage(1)
            self.playerInfo.root:SetVisible(true)
        else
            self.playerInfo.root:SetVisible(false)
            self.cbHome:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
        end
    end)

    self.tapGroup:addCheckBox(self.cbBattleResults, function(checked)
        if checked then
            self:onChangePage(2)
            self.cbBattleResults:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
        else
            self.cbBattleResults:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
        end
    end)

    self.tapGroup:addCheckBox(self.cbSkin, function(checked)
        if checked then
            self:onChangePage(3)
            self.cbSkin:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
        else
            self.cbSkin:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
        end
    end)

    self.tapGroup:addCheckBox(self.cbPersonality, function(checked)
        if checked then
            self:onChangePage(4)
            self.cbPersonality:SetTextColor({ 39 / 255, 45 / 255, 92 / 255, 1 })
        else
            self.cbPersonality:SetTextColor({ 200 / 255, 221 / 255, 242 / 255, 1 })
        end
    end)
end

function UIPersonalHomePageLayout:openPersonalHomePageByUserId(userId)
    local info = {
        userId = userId,
        curPage = 1,
        isOpen = true
    }

    if userId == Game:getPlatformUserId() then
        pageRecord.selfPage = info
    else
        pageRecord.otherPlayerPage = info
        WebService:UploadVisitorInfo(Game:getPlatformUserId(), userId)
    end

    self:updatePersonalPageInfo(info)
    self:show()
end

---@param closeAll boolean
function UIPersonalHomePageLayout:closePersonalHomePage(closeAll)
    closeAll = closeAll or false
    if pageRecord.otherPlayerPage and pageRecord.otherPlayerPage.isOpen == true then
        pageRecord.otherPlayerPage = {
            userId = 0,
            page = 1,
            isOpen = false
        }
        if pageRecord.selfPage.isOpen and not closeAll then
            self:updatePersonalPageInfo(pageRecord.selfPage)
        else
            self:hide()
        end
    else
        pageRecord.selfPage.isOpen = false
        self:hide()
    end
end

function UIPersonalHomePageLayout:onChangePage(pageId)
    if pageRecord.otherPlayerPage and pageRecord.otherPlayerPage.isOpen == true then
        pageRecord.otherPlayerPage.page = pageId
    else
        pageRecord.selfPage.page = pageId
    end
end

function UIPersonalHomePageLayout:updatePersonalPageInfo(pageInfo)
    local flashPage = function(code, data)
        self.playerInfo:setShowPlayerUserId(pageInfo.userId)
    end
    PlayerCustomInfoUtil:getPlayerAllCustomInfo(pageInfo.userId, flashPage)
    self.tapGroup:selectIndex(pageInfo.curPage)
end

function UIPersonalHomePageLayout:onShow()
    if pageRecord.otherPlayerPage.userId == 0 then
        self:openPersonalHomePageByUserId(Game:getPlatformUserId())
    end
end

return UIPersonalHomePageLayout
