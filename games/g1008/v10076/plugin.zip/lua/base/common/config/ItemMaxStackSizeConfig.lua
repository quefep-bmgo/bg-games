---@class ItemMaxStackSizeConfig
local ItemMaxStackSizeConfig = T(Global, "ItemMaxStackSizeConfig")
---@type ItemMaxStackSizeData[]
local Settings = {}

function ItemMaxStackSizeConfig:init()
	local config = FileUtil.getConfigFromCsv("setting/ItemMaxStackSize.csv")
	for _, item in pairs(config) do
		---@class ItemMaxStackSizeData
		local data = {
			id = item.id,
			itemId = item.itemId,
			maxStackSize = item.maxStackSize,
		}
		local Item = Item.getItemById(data.itemId)
		if Item then
			Item:setMaxStackSize(data.maxStackSize)
		end
		Settings[data.id] = data
	end
end

function ItemMaxStackSizeConfig:getAllCfg()
	return Settings
end

---@return ItemMaxStackSizeData
function ItemMaxStackSizeConfig:getCfgById(id)
	return Settings[id]
end

ItemMaxStackSizeConfig:init()
