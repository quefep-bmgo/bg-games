---@class GUIInTeamPlayerItemWindow : IGUIWindow
local GUIInTeamPlayerItemWindow = class("GUIInTeamPlayerItemWindow", IGUIWindow)
---@type TeamService
local TeamService = T(Global, "TeamService")
---@type FriendManager
local FriendManager = T(Global, "FriendManager")

function GUIInTeamPlayerItemWindow:ctor(...)
    self.super.ctor(self, "InTeamPlayerItem.json", ...)
end

function GUIInTeamPlayerItemWindow:onLoad()
    self.siNoPlayer = self:getChildWindowByName("InTeamPlayerItem-No-Player", GUIType.StaticImage)
    self.llContent = self:getChildWindowByName("InTeamPlayerItem-Content", GUIType.Layout)
    self.btnAddFriend = self:getChildWindowByName("InTeamPlayerItem-Add-Friend", GUIType.Button)
    self.llHeader = self:getChildWindowByName("InTeamPlayerItem-Header", GUIType.Layout)
    self.siCaptainTag = self:getChildWindowByName("InTeamPlayerItem-Captain-Tag", GUIType.StaticImage)
    self.btnRemove = self:getChildWindowByName("InTeamPlayerItem-Remove", GUIType.Button)
    self.stName = self:getChildWindowByName("InTeamPlayerItem-Name", GUIType.StaticText)
    self.siHonorIcon = self:getChildWindowByName("InTeamPlayerItem-Honor-Icon", GUIType.StaticImage)
    self.stHonorText = self:getChildWindowByName("InTeamPlayerItem-Honor-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

function GUIInTeamPlayerItemWindow:initView()
    ---暂时隐藏段位信息
    self.siHonorIcon:SetVisible(false)
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
end

function GUIInTeamPlayerItemWindow:initEvent()
    self.btnAddFriend:registerEvent(GUIEvent.ButtonClick, function()
        self.btnAddFriend:SetVisible(false)
        FriendManager.FriendOperation(Define.FriendOperationType.Request, self.data.userId)
    end)
    self.btnRemove:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.kick.out.team.tip"))
                    .setRightClickListener(function()
            TeamService:kickOutTeammate(self.data.userId)
        end)        .show()
    end)
end

---@param data UserInfo
function GUIInTeamPlayerItemWindow:onDataChanged(data)
    if not data or not TeamService:isInTeam(data.userId) then
        self.siNoPlayer:SetVisible(true)
        self.llContent:SetVisible(false)
        self.data = nil
        return
    end
    self.data = data
    self.llContent:SetVisible(true)
    self.siNoPlayer:SetVisible(false)
    self.stName:SetText(data.name)
    self.winHead:setUserInfo(data)
    self.siCaptainTag:SetVisible(TeamService.ownerId == data.userId)
    self.btnRemove:SetVisible(data.userId ~= Game:getPlatformUserId() and TeamService:isOwner())
    self.btnAddFriend:SetVisible(data.userId ~= Game:getPlatformUserId() and not data.friend)
end

return GUIInTeamPlayerItemWindow
