local function hideEngineWindow(name)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetXPosition({ 0, 6000 })
    window:SetVisible(false)
end

local function setTouchable(window, visible)
    window:SetTouchable(visible)
    local count = window:GetChildCount()
    if count == 0 then
        return
    end
    for index = 1, count do
        setTouchable(window:GetChildByIndex(index - 1), visible)
    end
end

---@class UIGameMain : IGUILayout
local UIGameMain = class("UIGameMain", IGUILayout)

function UIGameMain:onLoad()
    self.btnLottery = self:getChildWindow("BedWarGameMain-Menu-Lottery", GUIType.Button)
    self.btnBlockShop = self:getChildWindow("BedWarGameMain-Menu-BlockShop", GUIType.Button)
    self.btnCustomShop = self:getChildWindow("BedWarGameMain-Menu-Custom-Shop", GUIType.Button)
    self.btnRecharge = self:getChildWindow("BedWarGameMain-Menu-Recharge", GUIType.Button)
    self.cbShortMessage = self:getChildWindow("BedWarGameMain-MenuList-ShortMessage", GUIType.CheckBox)
    self.cbMenuList = self:getChildWindow("BedWarGameMain-MenuList-Switch", GUIType.CheckBox)
    self.siRedPoint = self:getChildWindow("BedWarGameMain-MenuList-RedPoint", GUIType.StaticImage)
    self.ivBlockShopPoint = self:getChildWindow("BedWarGameMain-Menu-BlockShop-RedPoint", GUIType.StaticImage)
    self.siChallengeRedPoint = self:getChildWindow("BedWarGameMain-Menu-Challenge-RedPoint", GUIType.StaticImage)
    self.ivLicenseRedPoint = self:getChildWindow("BedWarGameMain-Menu-License-Red-Point", GUIType.StaticImage)
    self.siShortMessageMask = self:getChildWindow("BedWarGameMain-MenuList-ShortMessage-mask", GUIType.StaticImage)
    self.btnLicense = self:getChildWindow("BedWarGameMain-Menu-License", GUIType.Button)
    self.btnStore = self:getChildWindow("BedWarGameMain-Store-Btn", GUIType.Button)
    self.btnUpgradeStore = self:getChildWindow("BedWarGameMain-UpgradeStore-Btn", GUIType.Button)

    self.ivScreenEffect = self:getChildWindow("BedWarGameMain-Screen-Effect", GUIType.StaticImage)
    self.ivScreenEffect:SetVisible(false)

    self.lyPersonView = self:getChildWindow("BedWarGameMain-PersonView", GUIType.Layout)
    self.siPersonView = self:getChildWindow("BedWarGameMain-PersonView-Image", GUIType.StaticImage)
    self.lyPersonView:SetVisible(true)

    self.btnFrontBuild = self:getChildWindow("BedWarGameMain-FrontBuild", GUIType.Button)

    self:setEngineUIStyle()
    self:register()
end

function UIGameMain:setEngineUIStyle()
    ClientHelper.putFloatPrefs("PoleControlMaxDistance", 65)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaNormal", 1)
    ClientHelper.putFloatPrefs("MainControlKeyAlphaPress", 1)
    local ivPoleArrow = GUIManager:getWindowByName("Main-PoleControl-Arrow", GUIType.StaticImage)
    ivPoleArrow:SetImage("set:pole.json image:pole_arrow")
    local wMoveState = GUIManager:getWindowByName("Main-MoveState")
    wMoveState:SetArea(wMoveState:GetXPosition(), wMoveState:GetYPosition(), { 0, 70 }, { 0, 70 })
    local wJumControls = GUIManager:getWindowByName("Main-Jump-Controls")
    wJumControls:SetArea(wJumControls:GetXPosition(), wJumControls:GetYPosition(), { 0, 138 }, { 0, 377 })
    local btnSkillRelease = GUIManager:getWindowByName("Main-Skill-Release-btn", GUIType.Button)
    btnSkillRelease:SetNormalImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetPushedImage("set:bedwarsmall.json image:free_skill")
    btnSkillRelease:SetArea(btnSkillRelease:GetXPosition(), btnSkillRelease:GetYPosition(), { 0, 120 }, { 0, 120 })
    self.btnSkill = btnSkillRelease
    local ivSneak = GUIManager:getWindowByName("Main-MoveState-Sneak", GUIType.StaticImage)
    ivSneak:SetImage("set:move_state.json image:sneak_circle")
    local btnFly = GUIManager:getWindowByName("Main-Fly", GUIType.Button)
    btnFly:SetNormalImage("set:bedwarsmall.json image:fly")
    btnFly:SetPushedImage("set:bedwarsmall.json image:fly")
    btnFly:SetArea(btnFly:GetXPosition(), btnFly:GetYPosition(), { 0, 70 }, { 0, 70 })
    hideEngineWindow("Main-Player-Exp")
    hideEngineWindow("Main-Chat-Message")
    hideEngineWindow("Main-Gun-Operate-ReloadBtn")

    local bgWatch = GUIManager:getWindowByName("Main-Watch-Battle-Bg", GUIType.StaticImage)
    bgWatch:SetProperty("StretchOffset", "60 10 0 0")
    bgWatch:SetImage("set:bedwar_toolbar.json image:bg_onWatch")
    GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetHeight({ 0, 49 })
    GUIManager:getWindowByName("Main-Watch-Battle-Tip"):SetWidth({ 0, 250 })
    GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetArea({ 0, 50 }, { 0, 0 }, { 1, -50 }, { 1, 0 })
    GUIManager:getWindowByName("Main-Watch-Battle-Text"):SetHorizontalAlignment(HorizontalAlignment.Left)
end

function UIGameMain:register()
    ------------
    self.btnRecharge:registerEvent(GUIEvent.ButtonClick, function()
        ReportUtil.reportClickFirstRecharge(GUISumRechargeLayout.currentId)
        GUISumRechargeLayout:show()
    end)
    self.btnStore:registerEvent(GUIEvent.ButtonClick, function()
        if isGameStart then
            GUIStore:show(StoreId.GoodsStore, nil, true)
        else
            CustomDialog.builder().setContentText(Lang:getString("gui.message.not.start"))
                        .setLeftText("gui_dialog_tip_btn_cancel")
                        .setRightText("gui_dialog_tip_btn_sure")
                        .show()
        end
    end)
    self.btnUpgradeStore:registerEvent(GUIEvent.ButtonClick, function()
        if isGameStart then
            GUIUpgradeStore:show(true)
        else
            CustomDialog.builder().setContentText(Lang:getString("gui.message.not.start"))
                        .setLeftText("gui_dialog_tip_btn_cancel")
                        .setRightText("gui_dialog_tip_btn_sure")
                        .show()
        end
    end)

    self.btnLicense:registerEvent(GUIEvent.ButtonClick, function()
        GameAnalytics:design(1, { "G_License" })
        GUILicense:show()
        CommonPacketSender:sendPlayerOpenLicense()
    end)

    self:registerDataCallBack("ShowSumRecharge", function(data)
        local id = data:getParam("Id")
        local config = SumRechargeConfig:getSumRecharge(id)
        if config then
            self.btnRecharge:SetVisible(true)
        else
            self.btnRecharge:SetVisible(false)
        end
    end, DataBuilderProcessor)

    self.cbShortMessage:registerEvent(GUIEvent.CheckStateChanged, function()
        if self.cbShortMessage:GetChecked() then
            GUICommandList:show(true)
        else
            GUICommandList:hide()
        end
    end)

    self.btnLottery:registerEvent(GUIEvent.ButtonClick, function()
        self:onLotteryBtn()
        GameAnalytics:design(1, { "ui_luckybox" })
    end)

    if self.btnBlockShop then
        self.btnBlockShop:registerEvent(GUIEvent.ButtonClick, function()
            GameAnalytics:design(1, { "G_blockshop" })
            GUIBlockShop:show()
        end)
    end

    self.btnCustomShop:registerEvent(GUIEvent.ButtonClick, function()
        GUICustomShop:show(true)
        GameAnalytics:design(1, { "ui_customshop" })
    end)

    self.cbMenuList:registerEvent(GUIEvent.CheckStateChanged, function()
        self:showMenuList(self.cbMenuList:GetChecked())
    end)

    local challenge = self:getChildWindow("BedWarGameMain-Menu-Challenge", GUIEvent.Button)
    if challenge then
        challenge:registerEvent(GUIEvent.ButtonClick, function()
            GameAnalytics:design(1, { "G_Treasure" })
            GUITreasureChallenge:onDataChange(TreasureChallenge.rewardData)
            GUITreasureChallenge:show(true)
        end)
    end

    self.lyPersonView:registerEvent(GUIEvent.Click, function()
        local cruCamera = SystemSettingRecord.defaultCamera
        ClientNewReportUtil:onPlayerChangePersonView("newBtn")
        if cruCamera == 1 then
            GUIBedWarSetting:changeCamera(2)
            SystemSettingRecord.defaultCamera = 2
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective3_normal")
        elseif cruCamera == 2 then
            GUIBedWarSetting:changeCamera(1)
            SystemSettingRecord.defaultCamera = 1
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
        elseif cruCamera == 3 then
            GUIBedWarSetting:changeCamera(1)
            SystemSettingRecord.defaultCamera = 1
            self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
        end
    end)

    self.btnFrontBuild:registerEvent(GUIEvent.ButtonClick, function()
        PlaceBlockHelper:onClickFrontBuildButton()
    end)

    GUIManager:getWindowByName("Main-Jump"):registerEvent(GUIEvent.Click, function()
        ClientNewReportUtil:onPlayerJump("Right")
    end)

    GUIManager:getWindowByName("MainControl-jump"):registerEvent(GUIEvent.Click, function()
        ClientNewReportUtil:onPlayerJump("Left")
    end)
end

function UIGameMain:upScreenEffect(time)
    self.ivScreenEffect:SetVisible(true)
    self.ivScreenEffect:SetEffectName("g1008_radar_ui.effect")
    LuaTimer:cancel(self.screen_key or 0)
    self.screen_key = LuaTimer:scheduleWithEnd(function()
    end, function()
        self.ivScreenEffect:SetVisible(false)
    end, time * 1000)
end

local function checkOnMount()
    local entityPlayer = PlayerManager:getClientPlayer().Player
    if entityPlayer then
        if entityPlayer:isOnFloatingMount() or entityPlayer:isOnFlyingMount() then
            return true
        end
    end
    return false
end

function UIGameMain:onTick(frameTime)
    GUIPlayerInventory:onTick(frameTime)
    local lua_player = PlayerManager:getClientPlayer()
    local holdId = lua_player.Player:getHeldItemId()
    local skill = SkillConfig:getSkill(holdId)
    self.btnSkill:SetVisible(skill and not skill.isPlaceBlock and not skill.isLongTouch)

    local onMount = checkOnMount()
    GUIBedWarToolBar.btnChangeCamera:SetEnabled(not onMount)
    self.lyPersonView:SetVisible(not onMount)
    self:checkFrontBuildButton(onMount)
end

function UIGameMain:checkFrontBuildButton(onMount)
    local heldItemId = Game:getPlayer():getHeldItemId()
    local item = Item.getItemById(heldItemId)
    self.btnFrontBuild:SetVisible(false)
    if not item or onMount then
        return
    end
    if not isGameStart then
        return
    end

    ---过滤有技能的方块
    local skill = SkillConfig:getSkill(heldItemId)
    if skill then
        return
    end
    ---过滤保护墙和防御�
    if heldItemId == 2418 or heldItemId == 2417 then
        return
    end
    local class = item:getClassName()
    if class == "ItemBlockImp" or class == "ItemCloth" or class == "ItemMultiTextureTile" then
        self.btnFrontBuild:SetVisible(true)
    end
end

function UIGameMain:showMenuList(check)
    local layout = self:getChildWindow("BedWarGameMain-MenuList", GUIType.Layout)
    self.siRedPoint:SetVisible(false)
    LuaTimer:cancel(self.listKey or 0)
    if check then
        self.listKey = LuaTimer:scheduleTimer(function()
            local curWidth = math.floor(layout:GetPixelSize().x)
            if curWidth == 0 then
                LuaTimer:cancel(self.listKey or 0)
                setTouchable(layout, false)
            else
                if curWidth - 3 > 0 then
                    layout:SetWidth({ 0, curWidth - 20 })
                else
                    layout:SetWidth({ 0, 0 })
                end
            end
        end, 10)
    else
        setTouchable(layout, true)
        self.listKey = LuaTimer:scheduleTimer(function()
            local curWidth = math.floor(layout:GetPixelSize().x)
            if curWidth == 354 then
                LuaTimer:cancel(self.listKey or 0)
            else
                if curWidth + 3 < 354 then
                    layout:SetWidth({ 0, curWidth + 20 })
                else
                    layout:SetWidth({ 0, 354 })
                end
            end
        end, 10)
    end
end

function UIGameMain:onLotteryBtn()
    GUILottery:show()
    SoundUtil.playSound(SoundConfig.openLottery)
end

function UIGameMain:onCommandCD()
    self.cbShortMessage:SetTouchable(false)
    self.siShortMessageMask:SetVisible(true)
    self.siShortMessageMask:setCooldownAnim(true, 1000)

    LuaTimer:schedule(function()
        self.cbShortMessage:SetTouchable(true)
        self.siShortMessageMask:SetVisible(false)
    end, 1000)
end

function UIGameMain:hideList()
    ---开始游戏，玩家传送到自己的岛X秒之后，如果玩家没有把图标列表收起来，则自动收起来，并且收缩按钮有一个红点提示，点击按钮之后红点消失·
    if not self.listKey then
        self.listKey = LuaTimer:schedule(function()
            if not self.cbMenuList:GetChecked() then
                self.cbMenuList:SetChecked(true)
            end
            self.siRedPoint:SetVisible(true)
        end, GameConfig.mainTabRedPoint * 1000)
    end
end

function UIGameMain:cameraChange()
    local cruCamera = Blockman.Instance():getCurrPersonView()
    if cruCamera == 1 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective3_normal")
    elseif cruCamera == 2 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective2_normal")
    elseif cruCamera == 0 then
        self.siPersonView:SetImage("set:view_state.json image:btn_0_perspective1_normal")
    end
end

return UIGameMain
