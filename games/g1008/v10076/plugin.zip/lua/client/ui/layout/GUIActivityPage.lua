---@class UIActivityPageLayout : IGUILayout
local UIActivityPageLayout = class("UIActivityPageLayout", IGUILayout)
---@type ActivityPageData[]
local configs = require "common.config.ActivityPageConfig"

if #configs == 0 then
    return false
end
local function isInTimeRange(starTime, endTime)
    local nowNum = os.time(os.date("*t"))
    if nowNum >= starTime and nowNum < endTime then
        return true
    end
    return false
end

local function haveImage(imageName)
    local imageInfo = StringUtil.split(imageName, " ")
    if #imageInfo ~= 2 then
        return false
    end
    local fileName = imageInfo[1]:gsub("set:", "")
    local imageset = GUIImagesetManager.Instance():findImageSetByName(fileName)
    if not imageset then
        GUIImagesetManager.Instance():CreateFromFile(fileName)
        imageset = GUIImagesetManager.Instance():findImageSetByName(fileName)
    end
    if not imageset then
        return false
    end
    local name = imageInfo[2]:gsub("image:", "")
    local image = imageset:GetImage(name)
    if not image then
        GUIImagesetManager.Instance():CreateFromFile(fileName)
        image = imageset:GetImage(name)
    end
    if not image then
        return false
    end
    return true
end

function UIActivityPageLayout:ctor()
    self.super.ctor(self, "ActivityPage.json")
end

function UIActivityPageLayout:onLoad()
    self.siBG = self:getChildWindow("ActivityPage-BG", GUIType.StaticImage)
    self.stText = self:getChildWindow("ActivityPage-Text", GUIType.StaticImage)
    self.btnClose = self:getChildWindow("ActivityPage-Close", GUIType.Button)
    self:initView()
end

function UIActivityPageLayout:initView()
    self.siBG:registerEvent(GUIEvent.Click, function()
        GUIManager:showWindowByName(self.cur_page.uiJson)
        self:nextPage()
    end)

    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:nextPage()
    end)
end

function UIActivityPageLayout:nextPage()
    if #configs == 0 then
        self:hide()
        return
    end
    self.cur_page = configs[1]
    table.remove(configs, 1)
    if not isInTimeRange(self.cur_page.startTime, self.cur_page.endTime) then
        self:nextPage()
        return
    end

    UIHelper:setImageAdjustSize(self.siBG, "set:" .. self.cur_page.imageset .. ".json image:bg", 9999, 9999)
    if haveImage("set:" .. self.cur_page.imageset .. ".json image:" .. Lang:getLang()) then
        UIHelper:setImageAdjustSize(self.stText, "set:" .. self.cur_page.imageset .. ".json image:" .. Lang:getLang(), 9999, 9999)
    else
        UIHelper:setImageAdjustSize(self.stText, "set:" .. self.cur_page.imageset .. ".json image:en_US", 9999, 9999)
    end
    self.btnClose:SetArea({ 0, self.siBG:GetPixelSize().x / 2 + 10 }, { 0, self.siBG:GetPixelSize().y / -2 + 30 }, { 0, 30 }, { 0, 30 })
end

function UIActivityPageLayout:onShow()
    self:nextPage()
end

return UIActivityPageLayout
