---@class GUITalentDescRootWindow : IGUIWindow
local GUITalentDescRootWindow = class("GUITalentDescRootWindow", IGUIWindow)

---@private
function GUITalentDescRootWindow:ctor(parent, textColor)
	self.super.ctor(self, "TalentDescRoot.json")
	self.parent = parent
	self.textColor = textColor
end

---@private
function GUITalentDescRootWindow:onLoad()
	self.stTalentDesc = self:getChildWindowByName("TalentDescRoot-TalentDesc", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUITalentDescRootWindow:initView()
end


---@private
function GUITalentDescRootWindow:initEvent()

end

function GUITalentDescRootWindow:SetText(text)
	self.stTalentDesc:SetTextColor(self.textColor)
	self.stTalentDesc:SetText(text)
	self.root:SetHeight({0, self.stTalentDesc:GetTextHeight() + 5})
	self.parent:LayoutChild()
	self.parent:SetScrollOffset(0)
end

---@param data table
function GUITalentDescRootWindow:onDataChanged(data)

end

return GUITalentDescRootWindow
