---@class GUITeamInvitePlayerItemWindow : IGUIWindow
local GUITeamInvitePlayerItemWindow = class("GUITeamInvitePlayerItemWindow", IGUIWindow)
---@type TeamService
local TeamService = T(Global, "TeamService")
---邀请记录
---@type table
local InviteStatusRecord = T(Global, "InviteStatusRecord")
---@type table
local CountdownRecord = {}

function GUITeamInvitePlayerItemWindow:ctor(...)
    self.super.ctor(self, "TeamInvitePlayerItem.json", ...)
end

function GUITeamInvitePlayerItemWindow:onLoad()
    self.llHeader = self:getChildWindowByName("TeamInvitePlayerItem-Header", GUIType.Layout)
    self.stName = self:getChildWindowByName("TeamInvitePlayerItem-Name", GUIType.StaticText)
    self.siSex = self:getChildWindowByName("TeamInvitePlayerItem-Sex", GUIType.StaticImage)
    self.stHonor = self:getChildWindowByName("TeamInvitePlayerItem-Honor", GUIType.StaticText)
    self.stStatus = self:getChildWindowByName("TeamInvitePlayerItem-Status", GUIType.StaticText)
    self.stRejected = self:getChildWindowByName("TeamInvitePlayerItem-Rejected", GUIType.StaticText)
    self.btnInvite = self:getChildWindowByName("TeamInvitePlayerItem-Invite", GUIType.Button)
    self:initView()
    self:initEvent()
end

function GUITeamInvitePlayerItemWindow:initView()
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
end

function GUITeamInvitePlayerItemWindow:initEvent()
    self.btnInvite:registerEvent(GUIEvent.ButtonClick, function()
        InviteStatusRecord[self.data.userId] = Define.InviteStatus.Rejected
        self:updateInviteButtonUI()
        TeamService:sendTeamInvite(self.data.userId)
        GUISelectTeamInviteListLayout:updateInviteList()
    end)
end

function GUITeamInvitePlayerItemWindow:updateInviteButtonUI()
    if TeamService.isMatching then
        self.btnInvite:SetVisible(false)
        self.stRejected:SetVisible(false)
        return
    end
    if self.data.status ~= Define.UserStatus.Online
            or not TeamService:canSendInvite()
            or TeamService:isInTeam(self.data.userId) then
        self.btnInvite:SetVisible(false)
        self.stRejected:SetVisible(false)
        return
    end
    local inviteStatus = InviteStatusRecord[self.data.userId] or Define.InviteStatus.Invite
    if inviteStatus == Define.InviteStatus.Invite then
        self.btnInvite:SetVisible(true)
        self.btnInvite:SetEnabled(true)
        self.stRejected:SetVisible(false)
        self.btnInvite:SetText(Lang:getString("gui.create.team.invite"))
        self.btnInvite:SetProperty("TextBorderColor", "0.00784314 0.541176 0.572549 1")
    elseif inviteStatus == Define.InviteStatus.Invited then
        self.btnInvite:SetVisible(true)
        self.btnInvite:SetEnabled(false)
        self.stRejected:SetVisible(false)
        self.btnInvite:SetText(Lang:getString("gui.create.team.invited"))
        self.btnInvite:SetProperty("TextBorderColor", "0.3333 0.3333 0.3333 1")
    elseif inviteStatus == Define.InviteStatus.Rejected then
        self.stRejected:SetVisible(true)
        self.btnInvite:SetVisible(false)
    end
end

function GUITeamInvitePlayerItemWindow:onTick()
    if TeamService.isMatching then
        self.btnInvite:SetVisible(false)
        self.stRejected:SetVisible(false)
        return
    end
    local inviteStatus = InviteStatusRecord[self.data.userId]
    if inviteStatus ~= Define.InviteStatus.Rejected then
        return
    end
    self.btnInvite:SetVisible(false)
    self.stRejected:SetVisible(true)
    local time = CountdownRecord[self.data.userId]
    if not time then
        time = os.time()
        CountdownRecord[self.data.userId] = time
    end
    local lastTime = 30 - (os.time() - time)
    self.stRejected:SetText(Lang:format("gui.create.team.rejected", lastTime))
    if lastTime <= 0 then
        InviteStatusRecord[self.data.userId] = Define.InviteStatus.Invite
        CountdownRecord[self.data.userId] = nil
        self:updateInviteButtonUI()
    end
end

---@param data BedWarUserInfo
function GUITeamInvitePlayerItemWindow:onDataChanged(data)
    if isLocalWin then
        data.status = Define.UserStatus.Online
    end
    self.data = data
    self.winHead:setUserInfo(data)
    self.stName:SetText(data.name)
    --self.siSex:SetImage(Define.SexIcon[data.sex] or Define.SexIcon[Define.SexType.Boy])
    self.siSex:SetImage("")
    QualifyingTool.setQualifyingSegmentInListUI(nil, self.stHonor, data.qualifyingData)
    if TeamService:isInTeam(data.userId) then
        self.stStatus:SetText(Lang:getString(Define.UserStatusLang[Define.UserStatus.InTeam]))
        self.stStatus:SetTextColor(Define.UserStatusColor[Define.UserStatus.InTeam])
    else
        if data[Define.PlayerCustomInfo.IsBackPlayer] and data[Define.PlayerCustomInfo.IsBackPlayer] == "true" then
            self.stStatus:SetText(Lang:getString(Define.UserStatusLang[Define.UserStatus.IsBackPlayer] or "gui.user.status.offline"))
            self.stStatus:SetTextColor(Define.UserStatusColor[Define.UserStatus.IsBackPlayer] or Color.WHITE)
        else
            self.stStatus:SetText(Lang:getString(Define.UserStatusLang[data.status] or "gui.user.status.offline"))
            self.stStatus:SetTextColor(Define.UserStatusColor[data.status] or Color.WHITE)
        end
    end
    self:updateInviteButtonUI()
end

return GUITeamInvitePlayerItemWindow
