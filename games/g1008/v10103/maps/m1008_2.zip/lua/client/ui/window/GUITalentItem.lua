---@class GUITalentItemWindow : IGUIWindow
local GUITalentItemWindow = class("GUITalentItemWindow", IGUIWindow)
---@type TalentConfig
local TalentConfig = T(Global, "TalentConfig")
---@type CTalentController
local CTalentController = T(Global, "CTalentController")

local ItemTypeConfig = {
	[1] = {
		lockImage = "set:talent.json image:img_0_general01",
		canUnlockImage = "set:talent.json image:img_0_general02",
		unlockImage = "set:talent.json image:img_0_general03",
		size = 1.13,
		iconSize = 0.63,
		levelTextPos = {x = -0.2, y = -0.151},
		unlockEffect = "g1008_genius_unlock_small.effect",
		upgradeEffect = "g1008_genius_up.effect",
		unlockEffectScale = 3.5,
		newEffectName = "g1008_talent_ui_redpoint_02.effect",
		newEffectScale = 0.98,
		newEffectPos = {x = 0, y = -0.49}
	},
	[2] = {
		lockImage = "set:talent.json image:img_0_advanced01",
		canUnlockImage = "set:talent.json image:img_0_advanced02",
		unlockImage = "set:talent.json image:img_0_advanced03",
		size = 1.77,
		iconSize = 0.65,
		levelTextPos = {x = -0.22, y = -0.151},
		unlockEffect = "g1008_genius_unlock_big.effect",
		upgradeEffect = "g1008_genius_up.effect",
		unlockEffectScale = 2.8,
		newEffectName = "g1008_talent_ui_redpoint_01.effect",
		newEffectScale = 0.98,
		newEffectPos = {x = 0, y = -0.49}
	},
	[3] = {
		lockImage = "set:talent.json image:img_0_advanced01",
		canUnlockImage = "set:talent.json image:img_0_advanced02",
		unlockImage = "set:talent.json image:img_0_advanced03",
		size = 1.77,
		iconSize = 0.65,
		levelTextPos = {x = -0.22, y = -0.151},
		unlockEffect = "g1008_genius_unlock_big.effect",
		upgradeEffect = "g1008_genius_up.effect",
		unlockEffectScale = 2.8,
		newEffectName = "g1008_talent_ui_redpoint_01.effect",
		newEffectScale = 0.98,
		newEffectPos = {x = 0, y = -0.49}
	}
}

---@private
function GUITalentItemWindow:ctor(...)
	self.super.ctor(self, "TalentItem.json", ...)
end

---@private
function GUITalentItemWindow:onLoad()
	self.siBg = self:getChildWindowByName("TalentItem-Bg", GUIType.StaticImage)
	self.stLevel = self:getChildWindowByName("TalentItem-Level", GUIType.StaticText)
	self.siIcon = self:getChildWindowByName("TalentItem-Icon", GUIType.StaticImage)
	self.siUIEffect = self:getChildWindowByName("TalentItem-UIEffect", GUIType.StaticImage)
	self.siRedDot = self:getChildWindowByName("TalentItem-RedDot", GUIType.StaticImage)
	self.siHadGet = self:getChildWindowByName("TalentItem-HadGet", GUIType.StaticImage)
	self.lyNewEffect = self:getChildWindowByName("TalentItem-NewEffect", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function GUITalentItemWindow:initView()

end

---@private
function GUITalentItemWindow:initEvent()
	self:registerEvent(Events.TalentUpgradeSuccess, function(talentData, isUnlock)
		if not self.curTalentLevelData then
			return
		end
		if self.curTalentLevelData.talentId == talentData.talentId then
			self.curTalentLevelData.level = talentData.level
			if isUnlock then
				--解锁
				self:refreshState()
				self:unlockShow(talentData)
			else
				--升级
				self:refreshState()
			end
		elseif self.curTalentLevelData.level == 0 then
			self:refreshState()
		end
	end)

	self:registerEvent(Events.TalentResetSuccess, function()
		if not self.talentCfg then
			return
		end
		self.curTalentLevelData = CTalentController:getCurTalentLevelData(self.talentCfg.talentId)
		self:refreshState()
	end)

	self:registerEvent(Events.TalentShowDetail, function(talentId)
		if not self.talentCfg then
			return
		end
		if self.talentCfg.talentId == talentId then
			self:showDetail()
		end
	end)

	self:registerEvent(Events.TalentItemRefresh, function()
		if not self.talentCfg then
			return
		end
		self.curTalentLevelData = CTalentController:getCurTalentLevelData(self.talentCfg.talentId)
		self:refreshState()
	end)

	self:registerEvent(Events.TalentRefreshRedDot, function()
		self:refreshRedDotShow()
	end)

	self.root:registerEvent(GUIEvent.Click, function()
		if CTalentController:isShowRedDot(self.talentCfg.talentId) then
			CTalentController:hideRedDot(self.talentCfg.talentId)
			self.lyNewEffect:SetVisible(false)
		end
		self:showDetail()
	end)
end

function GUITalentItemWindow:showDetail()
	if self.talentCfg then
		UITalentDetail:show(self.root, self.talentCfg.talentId)
	end
end

function GUITalentItemWindow:unlockShow(talentData)
	local isGiftTalent = TalentConfig:isGiftTalent(self.talentCfg.talentId)
	Events.TalentShowMask:invoke(true)
	self:addTimer(	LuaTimer:scheduleTimer(function()
		if not isGiftTalent then
			self:showDetail()
		else
			--如果有配置奖励,弹出通用获得弹窗
			local unlockRewardId = TalentConfig:getUnlockReward(talentData.talentId, talentData.level)
			if unlockRewardId then
				local rewardCfg = RewardConfig:getRewardById(unlockRewardId)
				if rewardCfg then
					GUIChallengeRewardReceive:init(rewardCfg.ShowDetail)
				end
			end
		end
	end, 500, 1))
	self:showUnlockEffect(1000, function()
		Events.TalentShowMask:invoke(false)
	end)
end

function GUITalentItemWindow:refreshState()
	local typeCfg = ItemTypeConfig[self.talentCfg.type]
	local conditionMet = CTalentController:isNextConditionsMet(self.talentCfg.talentId)
	if CTalentController:canUpgrade(self.talentCfg.talentId) then
		if conditionMet then
			if self.curTalentLevelData.level == 0 then
				self.siBg:SetImage(typeCfg.canUnlockImage)
			else
				self.siBg:SetImage(typeCfg.unlockImage)
			end
		else
			self.siBg:SetImage(typeCfg.lockImage)
		end
	else
		if self.curTalentLevelData.level > 0 then
			self.siBg:SetImage(typeCfg.unlockImage)
		else
			self.siBg:SetImage(typeCfg.lockImage)
		end
	end
	if self.curTalentLevelData.level > 0 then
		self.siIcon:SetImage(self.unlockIcon)
	else
		self.siIcon:SetImage(self.lockIcon)
	end
	self.stLevel:SetText(self.curTalentLevelData.level)
	self.stLevel:SetVisible(self.curTalentLevelData.level > 1)
end

function GUITalentItemWindow:initItemType()
	local typeCfg = ItemTypeConfig[self.talentCfg.type]
	if typeCfg then
		self.siBg:SetWidth({typeCfg.size, 0})
		self.siBg:SetHeight({typeCfg.size, 0})
		self.siIcon:SetWidth({typeCfg.iconSize, 0})
		self.siIcon:SetHeight({typeCfg.iconSize, 0})
		self.stLevel:SetXPosition({typeCfg.levelTextPos.x, 0})
		self.stLevel:SetYPosition({typeCfg.levelTextPos.y, 0})
		self.siUIEffect:SetArea({0, 0}, {-0.5, 0}, {1, 0}, {1, 0})
		self.siUIEffect:SetEffectScale(VectorUtil.newVector2(typeCfg.unlockEffectScale, typeCfg.unlockEffectScale))
	end
end

function GUITalentItemWindow:refreshRedDotShow()
	if CTalentController:isShowRedDot(self.talentCfg.talentId) then
		local typeCfg = ItemTypeConfig[self.talentCfg.type]
		self.lyNewEffect:SetEffectName(typeCfg.newEffectName)
		self.lyNewEffect:SetVisible(true)
		self.lyNewEffect:SetEffectScale(VectorUtil.newVector2(typeCfg.newEffectScale,typeCfg.newEffectScale))
		self.lyNewEffect:SetYPosition({typeCfg.newEffectPos.y, 0})
		self.lyNewEffect:SetXPosition({typeCfg.newEffectPos.x, 0})
	else
		self.lyNewEffect:SetVisible(false)
	end
end

function GUITalentItemWindow:showUnlockEffect(time, cb)
	local typeCfg = ItemTypeConfig[self.talentCfg.type]
	if typeCfg then
		self.siUIEffect:SetVisible(true)
		self.siUIEffect:SetEffectName(typeCfg.unlockEffect)
 		self.siUIEffect:PlayEffect()
	end
	self:addTimer(LuaTimer:scheduleTimer(function()
		if cb then
			cb()
		end
		self.siUIEffect:SetVisible(false)
	end, time, 1))
end

---@param data table
function GUITalentItemWindow:onDataChanged(layoutCfg)
	self.layoutCfg = layoutCfg
	self.talentCfg = TalentConfig:getTalentByLayoutId(self.layoutCfg.id)
	if not self.talentCfg then
		return
	end
	self.curTalentLevelData = CTalentController:getCurTalentLevelData(self.talentCfg.talentId)
	self.unlockIcon = self.talentCfg.icon
	local imageNameSplit = StringUtil.split(self.unlockIcon, "_")
	self.lockIcon = "set:talent_icon_lock.json image:g1008_icon_talent_lock_"..imageNameSplit[#imageNameSplit]
	self:initItemType()
	self:refreshState()
	self:refreshRedDotShow()
end

function GUITalentItemWindow:getTalentId()
	return self.cfg.id
end

return GUITalentItemWindow
