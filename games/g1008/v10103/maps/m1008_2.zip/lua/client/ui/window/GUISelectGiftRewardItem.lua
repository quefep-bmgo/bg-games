---@class GUISelectGiftRewardItemWindow : IGUIWindow
local GUISelectGiftRewardItemWindow = class("GUISelectGiftRewardItemWindow", IGUIWindow)

---@private
function GUISelectGiftRewardItemWindow:ctor(...)
	self.super.ctor(self, "SelectGiftRewardItem.json", ...)
end

---@private
function GUISelectGiftRewardItemWindow:onLoad()
	self.siBg = self:getChildWindowByName("SelectGiftRewardItem", GUIType.StaticImage)
	self.siIcon = self:getChildWindowByName("SelectGiftRewardItem-Icon", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("SelectGiftRewardItem-Num", GUIType.StaticText)
	self.siSelect = self:getChildWindowByName("SelectGiftRewardItem-Select", GUIType.StaticImage)
	self.siMask = self:getChildWindowByName("SelectGiftRewardItem-Mask", GUIType.StaticImage)
	self:initView()
	self:initEvent()
end

---@private
function GUISelectGiftRewardItemWindow:initView()
	self.siSelect:SetVisible(false)
	self.siMask:SetVisible(false)
end

---@private
function GUISelectGiftRewardItemWindow:initEvent()
	self.siIcon:registerEvent(GUIEvent.Click, function()
		if not self.data then
			return
		end
		Events.SelectGiftSelectItem:invoke(self.data.Id)
	end)

	self:registerEvent(Events.SelectGiftSelectItem, function(id)
		if not self.id then
			return
		end
		self.siSelect:SetVisible(tostring(self.id) == tostring(id))
	end)
end

function GUISelectGiftRewardItemWindow:onDataChanged(id)
	local data = RewardConfig:getRewardById(id)
	if not data then
		return
	end
	self.id = id
	self.data = data
	self.siIcon:SetImage(data.ShowDetail.image)
	self.stNum:SetVisible(data.Count > 1)
	self.stNum:SetText("X" .. data.CountText)
	self.siMask:SetVisible(ClientStore:checkHave({ type = "RewardSetting", realId = id }))
end

return GUISelectGiftRewardItemWindow
