---@class GUITalentContentWindow : IGUIWindow
local GUITalentContentWindow = class("GUITalentContentWindow", IGUIWindow)

local Quaternion = require "engine_base.math.quaternion"
local Vector2 = require "engine_base.math.vector2"
---@type TalentLayoutConfig
local TalentLayoutConfig = T(Global, "TalentLayoutConfig")
---@type CTalentController
local CTalentController = T(Global, "CTalentController")
---@type TalentConfig
local TalentConfig = T(Global, "TalentConfig")

local cellWidth = TalentLayoutConfig:getCellWidth()
local itemWidth = TalentLayoutConfig:getItemWidth()
local cellHeight = TalentLayoutConfig:getCellHeight()
local cellOffset = (cellWidth - itemWidth) * 0.5

---@private
function GUITalentContentWindow:ctor(...)
	self.super.ctor(self, "TalentContent.json", ...)
end

---@private
function GUITalentContentWindow:onLoad()
	self.llLineRoot = self:getChildWindowByName("TalentContent-LineRoot", GUIType.Layout)
	self.llItemRoot = self:getChildWindowByName("TalentContent-ItemRoot", GUIType.Layout)
	self:initView()
	self:initEvent()
end

---@private
function GUITalentContentWindow:initView()
	self.nodeMap = {}
	self.lineMap = {}
	self:initItem()
end

---@private
function GUITalentContentWindow:initEvent()

end

---@param data table
function GUITalentContentWindow:onDataChanged(data)
end

function GUITalentContentWindow:rotateAxis(v3, degree)
	v3 = v3:normalize()
	degree = degree * 0.5
	local s = math.sin(math.rad(degree))
	local w = math.cos(math.rad(degree))
	local x = s * v3.x
	local y = s * v3.y
	local z = s * v3.z
	return Quaternion.new(w, x, y, z)
end

function GUITalentContentWindow:createLine(parentId, curId, parent, target)
	local name = parentId.."_"..curId
	if self.lineMap[name] then
		return
	end
	local line = GUIManager:createGUIWindow(GUIType.StaticImage, name)
	self.llLineRoot:AddChildWindow(line)
	line:SetTouchable(false)
	line:SetImage("set:talent.json image:img_0_line01")
	self.lineMap[name] = line
	local offsetPos = Vector2.new(target:GetXPosition()[2] - parent:GetXPosition()[2], target:GetYPosition()[2] - parent:GetYPosition()[2])
	local lineLen = offsetPos:len()
	local posX = offsetPos.x * 0.5 + parent:GetXPosition()[2] + itemWidth * 0.5
	local posY = offsetPos.y * 0.5 + parent:GetYPosition()[2] - (lineLen - itemWidth) * 0.5
	local angle = math.acos(offsetPos:dot(Vector2.new(0, -1)) / lineLen) * 180 / math.pi
	if offsetPos.x < 0 then
		angle = -angle
	end
	line:SetArea({0, posX}, {0, posY}, {0, 4}, {0, lineLen})
	line:SetRotate(angle)
end

function GUITalentContentWindow:createNode(root, cfg)
	if not root or not cfg then
		return
	end
	if cfg.nextIds then
		for _, id in pairs(cfg.nextIds) do
			if not self.nodeMap[id] then
				local node = UIHelper.newGameGUIWindow("GUITalentItem")
				node.root:SetWidth({0, itemWidth})
				node.root:SetHeight({0, itemWidth})
				local layoutCfg = TalentLayoutConfig:getTalentLayoutById(id)
				node:onDataChanged(layoutCfg)
				self.nodeMap[layoutCfg.id] = node
				self.llItemRoot:AddChildWindow(node.root)
				node.root:SetXPosition({0, cellWidth * (layoutCfg.posIndex[1] - 1) + cellOffset})
				node.root:SetYPosition({0, cellHeight * (layoutCfg.posIndex[2] - 1) + cellOffset})
				self:createLine(cfg.id, layoutCfg.id, root.root, node.root)
				self:createNode(node, layoutCfg)
			else
				--已存在的item 只要连线就行了
				local node = self.nodeMap[id]
				self:createLine(cfg.id, id, root.root, node.root)
			end
		end
	end
end

function GUITalentContentWindow:initItem()
	for i, v in pairs(TalentLayoutConfig:getTalentLayoutCfg()) do
		if not self.nodeMap[v.id] then
			local node = UIHelper.newGameGUIWindow("GUITalentItem")
			node.root:SetWidth({0, itemWidth})
			node.root:SetHeight({0, itemWidth})
			node:onDataChanged(v)
			self.llItemRoot:AddChildWindow(node.root)
			node.root:SetXPosition({0, cellWidth * (v.posIndex[1] - 1) + cellOffset})
			node.root:SetYPosition({0, cellHeight * (v.posIndex[2] - 1) + cellOffset})
			self.nodeMap[v.id] = node
			self:createNode(node, v)
		end
	end
	self:refreshLine()
end

function GUITalentContentWindow:refreshLine()
	for name, lineImg in pairs(self.lineMap) do
		local layoutIdArr = StringUtil.split(name, "_", false, true)
		local startTalentId = TalentConfig:getTalentIdByLayoutId(layoutIdArr[1])
		local endTalentId = TalentConfig:getTalentIdByLayoutId(layoutIdArr[2])
		--if TalentConfig:isGiftTalent(endTalentId) then
		--	if CTalentController:isUnlockTalent(startTalentId) then
		--		if CTalentController:isUnlockTalent(endTalentId) then
		--			lineImg:SetVisible(false)
		--		else
		--			lineImg:SetImage("set:talent.json image:img_0_line02")
		--			lineImg:SetVisible(true)
		--		end
		--	else
		--		lineImg:SetImage("set:talent.json image:img_0_line01")
		--		lineImg:SetVisible(true)
		--	end
		--else
			if CTalentController:isUnlockTalent(startTalentId) and CTalentController:isUnlockTalent(endTalentId) then
				lineImg:SetImage("set:talent.json image:img_0_line02")
			else
				lineImg:SetImage("set:talent.json image:img_0_line01")
			end
		--end
	end
end



return GUITalentContentWindow
