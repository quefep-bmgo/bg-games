---@class GUIPicturePuzzleActivityPanelWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIPicturePuzzleActivityPanelWindow = class("GUIPicturePuzzleActivityPanelWindow", GUICommonActivityPanel)

---@type PicturePuzzleActivityConfig
local PicturePuzzleActivityConfig = T(Global, "PicturePuzzleActivityConfig")

---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@private
function GUIPicturePuzzleActivityPanelWindow:ctor(...)
    self.json_name = "PicturePuzzleActivityPanel.json"
    self.super.ctor(self, "PicturePuzzleActivityPanel.json", ...)
end

---@private
function GUIPicturePuzzleActivityPanelWindow:onChildLoad()
    ---@type CPicturePuzzleActivityMgr
    self.mgr = self.mgr
    self.siBg = self:getChildWindowByName("PicturePuzzleActivityPanel-Bg", GUIType.StaticImage)
    self.llImage = self:getChildWindowByName("PicturePuzzleActivityPanel-Image", GUIType.Layout)
    self.siImageBg = self:getChildWindowByName("PicturePuzzleActivityPanel-ImageBg", GUIType.Layout)
    self.llDebrisPanel = self:getChildWindowByName("PicturePuzzleActivityPanel-DebrisPanel", GUIType.Layout)
    self.siTimeIcon = self:getChildWindowByName("PicturePuzzleActivityPanel-TimeIcon", GUIType.StaticImage)
    self.stTime = self:getChildWindowByName("PicturePuzzleActivityPanel-Time", GUIType.StaticText)
    self.siDescriptionBg = self:getChildWindowByName("PicturePuzzleActivityPanel-DescriptionBg", GUIType.StaticImage)
    self.stDescriptionTitle = self:getChildWindowByName("PicturePuzzleActivityPanel-DescriptionTitle", GUIType.StaticText)
    self.stDescriptionContext = self:getChildWindowByName("PicturePuzzleActivityPanel-DescriptionContext", GUIType.StaticText)
    self.siTitle = self:getChildWindowByName("PicturePuzzleActivityPanel-Title", GUIType.StaticImage)
    self.btnGoButton = self:getChildWindowByName("PicturePuzzleActivityPanel-GoButton", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function GUIPicturePuzzleActivityPanelWindow:initView()
    self.siBg:SetImage(self.mgr.config.backGroundImage)
    self.gvDebris = IGUIGridView.new("DebrisPanel-Debris" .. self.activity.activityId, self.llDebrisPanel, nil)
    self.gvDebris:setConfig(0, 0, 3)
    ---@type PicturePuzzleActivityDebrisAdapter
    self.debrisAdapter = UIHelper.requireAdapter("PicturePuzzleActivityDebrisAdapter", false, "ui_activity").new()
    self.debrisAdapter:setActivityMgr(self.mgr)
    self.gvDebris:setAdapter(self.debrisAdapter)
    local debrisGroup = PicturePuzzleActivityConfig:getDebrisGroupByActivityId(self.mgr.mainConfig.activityId)
    self.debrisAdapter:setData(debrisGroup)
end

---@private
function GUIPicturePuzzleActivityPanelWindow:initEvent()
    self.mgr:registerCacheChange(function()
        self:onCacheChanged(self.mgr:getPlayerCache())
    end)
    for i = 1, self.gvDebris:getItemCount() do
        ---@type GUIDebrisItemWindow
        item = self.gvDebris:getItemByIndex(i)
        item:addClickEvent(self)
    end
    self.btnGoButton:registerEvent(GUIEvent.ButtonClick, function()
        --self.mgr:goMiniGame()
        GUIGameActivityLayout:hide(true)
        ---@type TeamService
        local TeamService = T(Global, "TeamService")
        TeamService:sendCreateTeam("g1008", Define.GameMode.Qualifying)
    end)
end

---@private
function GUIPicturePuzzleActivityPanelWindow:onShow()
    GUIGameActivityLayout:hideTitle()
    self:refreshLangUI()
end

---@private
function GUIPicturePuzzleActivityPanelWindow:refreshLangUI()
    self.siTitle:SetImage(UIUtils.GetLangImage("set:ActivityLayout_21.json image:text"))
    self.stDescriptionTitle:SetText(Lang:getString("score.activity.help.title.2"))
    self.stDescriptionContext:SetText(Lang:getString(self.mgr.mainConfig.descLang))
    self.btnGoButton:SetText(Lang:getString("activity.goButton"))
    self.debrisAdapter:refreshLangUI()
end

---某个碎片被点击
function GUIPicturePuzzleActivityPanelWindow:DebrisByClick(debrisId, isActivate)
    if isActivate then
        self.mgr:tryActivateDebris(debrisId)
    end
end

---持久化数据改变
function GUIPicturePuzzleActivityPanelWindow:onCacheChanged(cache)
    self.debrisAdapter:onCacheChanged(cache)
    local receivable = false
    local receivableTimes = cache.receivableTimes or 0
    if receivableTimes > 0 then
        self.btnGoButton:SetVisible(true)
        if #self.mgr:getDebrisList() > 0 then
            receivable = true
            local debrisList = cache.debrisList or {}
            for _, debris in pairs(debrisList) do
                if not debris.activated then
                    receivable = false
                    break
                end
            end
            if receivable then
                self.mgr:tryGetReward("#")
            end
        end
    else
        self.btnGoButton:SetVisible(false)
    end
end

return GUIPicturePuzzleActivityPanelWindow
