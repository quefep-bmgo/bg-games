---@class GUIGameScoreActivityPanel9Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameScoreActivityPanel9Window = class("GUIGameScoreActivityPanel9Window", GUICommonActivityPanel)
---@type ScoreActivityConfig
local ScoreActivityConfig = T(Global, "ScoreActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

local ShowType = {
    Icon = 1,
    Actor = 2
}

---@private
function GUIGameScoreActivityPanel9Window:ctor(...)
    self.json_name = "GameScoreActivityPanel9.json"
    self.super.ctor(self, "GameScoreActivityPanel9.json", ...)
end

---@private
function GUIGameScoreActivityPanel9Window:onChildLoad()
    ---@type CScoreActivityMgr
    self.mgr = self.mgr
    self.iconMovePos = 0
    self.iconMoveGap = 2
    self.siQuestion = self:getChildWindowByName("GameScoreActivityPanel9-Question", GUIType.StaticImage)
    self.llTaskPanelClip = self:getChildWindowByName("GameScoreActivityPanel9-TaskPanel-Clip", GUIType.Layout)
    self.siTaskPanel = self:getChildWindowByName("GameScoreActivityPanel9-TaskPanel", GUIType.StaticImage)
    self.llTaskPanelTouch = self:getChildWindowByName("GameScoreActivityPanel9-TaskPanel-Touch", GUIType.Layout)
    self.stDailyTaskText = self:getChildWindowByName("GameScoreActivityPanel9-DailyTaskText", GUIType.StaticText)
    self.stTaskTimeText = self:getChildWindowByName("GameScoreActivityPanel9-Task-Time-Text", GUIType.StaticText)
    self.llTaskContent = self:getChildWindowByName("GameScoreActivityPanel9-TaskContent", GUIType.Layout)
    self.llRewardPanel = self:getChildWindowByName("GameScoreActivityPanel9-RewardPanel", GUIType.Layout)
    self.stRewardPool = self:getChildWindowByName("GameScoreActivityPanel9-RewardPool", GUIType.StaticText)
    self.btnExchange = self:getChildWindowByName("GameScoreActivityPanel9-Exchange", GUIType.Button)
    self.siImage = self:getChildWindowByName("GameScoreActivityPanel9-Image", GUIType.StaticImage)
    self.siImageBack = self:getChildWindowByName("GameScoreActivityPanel9-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindowByName("GameScoreActivityPanel9-Image-Top", GUIType.StaticImage)
    self.stScoreText = self:getChildWindowByName("GameScoreActivityPanel9-ScoreText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

function GUIGameScoreActivityPanel9Window:onShow()
    self.btnExchange:SetEnabled(false)
    self.siImage:SetVisible(false)
    self.awActor:SetVisible(false)
    self.super.showRewardDetail(self)
    self:refreshUI()
end

---@private
function GUIGameScoreActivityPanel9Window:initView()
    self.isTaskPanelOpen = false
    self.siTaskPanel:SetImage("")
    self.siImage:SetVisible(false)
    self.stDailyTaskText:SetText(Lang:getString("gui.daily.task"))
    self.btnExchange:SetText(Lang:getString("gui.exchange"))
    self.stRewardPool:SetText(Lang:getString("gui.reward.poll"))
    local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
    self.lvRewards = IGUIGridView.new("GameScoreActivityPanel9-Rewards" .. self.activity.activityId, self.llRewardPanel)
    self.lvRewards:setArea({ 0, 24 }, { 0, 76 }, { 1, -46 }, { 1, -104 })
    self.lvRewards:setConfig(10, 10, 3)
    ---@type ScoreActivityReward9Adapter
    self.rewardAdapter = UIHelper.requireAdapter("ScoreActivityReward9Adapter", false, "ui_activity").new()
    self.rewardAdapter:setActivityMgr(self.mgr)
    self.lvRewards:setAdapter(self.rewardAdapter)
    self.rewards = rewards
    self.rewardAdapter:setData(self.rewards)
    local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId) or {}
    if #tasks == 0 then
        return
    end
    table.sort(tasks, function(t1, t2)
        return t1.Id < t2.Id
    end)
    for i = #tasks, 1, -1 do
        local task = tasks[i]
        task.Image = Define.DailyTaskIcon[task.TaskTypeId]
    end
    local count = math.min(#tasks, 6)
    self.llTaskPanelClip:SetHeight({ 0, count * 76 - 2 })
    self.siTaskPanel:SetHeight({ 0, count * 76 + 40 })
    self.lvTaskList = IGUIListView.new("GameScoreActivityPanel9-TaskList" .. self.activity.activityId, self.llTaskContent)
    self.lvTaskList:setItemSpace(6)
    for _, task in pairs(tasks) do
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = UIHelper.requireGUIWindow("GUIGameScoreActivityTaskItem", false, "ui_activity").new(self)
        item:setUIStyle(
                "set:game_activity_score_9.json image:img_0_icon_sugar", VectorUtil.newVector2(50, 46),
                "set:game_activity_score_9.json image:img_0_iconbd", VectorUtil.newVector2(62, 70),
                { 0.0392, 0.0901, 0.2117, 0.7 })
        item.root:SetHeight({ 0, 70 })
        item:onDataChanged(task)
        self.lvTaskList:addItem(item)
    end
end

---@private
function GUIGameScoreActivityPanel9Window:initEvent()
    self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
        if not self.curShowReward then
            return
        end
        if self.mgr:getScore() < self.curShowReward.score then
            CustomDialog.builder()
                        .setContentText(Lang:getString("gui.lack.of.score." .. self:getActivityById()))
                        .setHideLeftButton()
                        .show()
            return
        end
        local function tryGetReward()
            CustomDialog.builder()
                        .setContentText(Lang:getString("exchange.activity.buy.tip"))
                        .setRightClickListener(function()
                self.mgr:tryGetReward(self.curShowReward.id)
            end)        .show()
        end
        if self.curShowReward.price > 0 then
            PayHelper.checkMoney(self.curShowReward.priceType, self.curShowReward.price, function(success)
                if success then
                    tryGetReward()
                end
            end)
        else
            tryGetReward()
        end
    end)

    self.llTaskPanelTouch:registerEvent(GUIEvent.Click, function(events)
        if self.isTaskPanelOpen then
            self:changeTaskPanel()
            Game:handleTouchClick(events.position.x, events.position.y)
        end
    end)

    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("score.activity.help.title.2")
                    .setContentText(Lang:getString("score.activity.help.content.2"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self.mgr:registerCacheChange(function()
        if self:isShow() then
            self:refreshUI()
        else
            self:updateRedPoint()
        end
    end)
    self:registerEvent(Events.ShowScoreActivityRewardDetailEvent, function(activityId, data)
        if self:getActivityById() ~= activityId then
            return
        end
        self:showCurRewardDetail(data)
    end)
    self:registerEvent(Events.ScoreActivityTaskUpdateEvent, function(activityId, taskId, progress, status)
        if self:getActivityById() ~= activityId then
            return
        end
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = self.lvTaskList:getItem("taskId", taskId)
        if item then
            item:setTaskInfo(progress, status)
        end
    end)
end

---@private
function GUIGameScoreActivityPanel9Window:refreshUI()
    if self.curShowReward then
        self:showCurRewardDetail(self.curShowReward)
    else
        if self.rewardAdapter then
            self.rewardAdapter:notifyDataChange()
        end
    end
    self:updateRedPoint()
    self.stScoreText:SetText(self.mgr:getScore())
end

---@private
function GUIGameScoreActivityPanel9Window:updateRedPoint()
    --local count = 0
    --for _, reward in pairs(self.rewards) do
    --    if not self.mgr:isRewardReceived(reward.id) and self.mgr:getScore() >= reward.score then
    --        count = count + 1
    --    end
    --end
    --UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityPanel9Window:showCurRewardDetail(data)
    self.curShowReward = data
    self.btnExchange:SetVisible(true)
    self.btnExchange:SetEnabled(self.mgr:getRewardLimit(self.curShowReward) > 0)
    self.mgr.curShowRewardId = self.curShowReward.id
    if self.rewardAdapter then
        self.rewardAdapter:notifyDataChange()
    end
    local rewardDetail = RewardItemShowDetailConfig:getConfigById(data.reward.showDetailId)
    if not rewardDetail then
        self:setIcon(data.reward)
        self.tvName:SetText(Lang:getString(data.reward.name))
        self.siImage:SetVisible(true)
        self.awActor:SetVisible(false)
        return
    end
    self.tvName:SetText(Lang:getString(rewardDetail.name))
    self.tvRewardDesc:SetText(Lang:getString(rewardDetail.desc))
    self.siImage:SetVisible(rewardDetail.showType == ShowType.Icon)
    self.awActor:SetVisible(rewardDetail.showType == ShowType.Actor)
    if rewardDetail.showType == ShowType.Icon then
        self:setIcon(rewardDetail)
    elseif rewardDetail.showType == ShowType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, rewardDetail, self.llSlideBlock)
    end
end

---@private
---@param rewardDetail RewardItemShowDetailItem
function GUIGameScoreActivityPanel9Window:setIcon(rewardDetail)
    self.siImage:SetYPosition({ -0.05, self.iconMovePos })
    self.siImage:SetImage("")
    if rewardDetail.scale and rewardDetail.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180, rewardDetail.scale)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180, rewardDetail.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180)
    end
    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ -0.05, self.iconMovePos })
    end, 100)
    self:addTimer(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel9Window:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel9Window:onTick()
    if not self.isTaskPanelOpen then
        return
    end
    local lastTime = DateUtil.getDayLeftSeconds()
    self.stTaskTimeText:SetText(DateUtil.getFormatTime(lastTime))
end

function GUIGameScoreActivityPanel9Window:changeTaskPanel()
    if self.locked then
        return
    end
    self.locked = true
    self.isTaskPanelOpen = not self.isTaskPanelOpen
    self.llTaskPanelTouch:SetVisible(self.isTaskPanelOpen)
    local count = math.min(self.lvTaskList:getChildCount(), 6)
    local startW, endW, startH, endH
    if self.isTaskPanelOpen then
        startW = 85
        endW = 352
        startH = count * 76 - 2
        endH = count * 76 + 40
        self.llTaskPanelClip:SetXPosition({ 0, -554 })
        self.llTaskPanelClip:SetYPosition({ 0, 100 })
        self.siTaskPanel:SetXPosition({ 0, 0 })
        self.siTaskPanel:SetYPosition({ 0, 0 })
        self:updateTaskUI()
    else
        startW = 352
        endW = 85
        startH = count * 76 + 40
        endH = count * 76 - 2
    end
    local offsetW = (endW - startW) / 8
    local offsetH = (endH - startH) / 8
    self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
        startW = startW + offsetW
        startH = startH + offsetH
        self.llTaskPanelClip:SetWidth({ 0, startW })
        self.llTaskPanelClip:SetHeight({ 0, startH })
    end, function()
        self.locked = false
        if not self.isTaskPanelOpen then
            self.siTaskPanel:SetImage("")
            self.llTaskPanelClip:SetXPosition({ 0, -562 })
            self.llTaskPanelClip:SetYPosition({ 0, 108 })
            self.siTaskPanel:SetXPosition({ 0, 8 })
            self.siTaskPanel:SetYPosition({ 0, -8 })
            self.llSlideBlock:SetTouchable(true)
            self.lvTaskList.root:SetScrollOffset(0)
            self:updateTaskUI()
        else
            self.llSlideBlock:SetTouchable(false)
            self.siTaskPanel:SetImage("set:game_activity_score_9.json image:img_9_taskbd")
        end
    end, 1, 8))
end

function GUIGameScoreActivityPanel9Window:updateTaskUI()
    ---@param item GUIGameScoreActivityTaskItemWindow
    for _, item in pairs(self.lvTaskList.items) do
        item:updateUI()
    end
end

return GUIGameScoreActivityPanel9Window
