---@class UISurvivalToolBarLayout : IGUILayout
local UISurvivalToolBarLayout = class("UISurvivalToolBarLayout", IGUILayout)

---@private
function UISurvivalToolBarLayout:ctor(parent)
    self.super.ctor(self, "SurvivalToolBar.json", parent)
end

---@private
function UISurvivalToolBarLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UISurvivalToolBarLayout:initCreateEvent()

end

---@private
function UISurvivalToolBarLayout:onLoad()
    GUIManager:getToolBar():SetArea({ 0, 0 }, { 1, 0 }, { 1, 0 }, { 0, 54 })
    self.root:SetLevel(49)
    self.cbSetting = self:getChildWindow("SurvivalToolBar-Menu-Setting", GUIType.CheckBox)
    self.cbChat = self:getChildWindow("SurvivalToolBar-Chat", GUIType.CheckBox)
    self.btnChangeCamera = self:getChildWindow("SurvivalToolBar-Camera-Change", GUIType.Button)
    self.cbAction = self:getChildWindow("SurvivalToolBar-Action", GUIType.CheckBox)
    self.btnVideo = self:getChildWindow("SurvivalToolBar-Video", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UISurvivalToolBarLayout:initView()
    local VersionCode = tonumber(GameAnalyticsCache:getClientInfo().version_code) or 0
    self.btnVideo:SetVisible(isLocalWin or VersionCode >= 4391)
end

---@private
function UISurvivalToolBarLayout:initEvent()
    self.cbSetting:registerEvent(GUIEvent.CheckStateChanged, function()
        if self.cbSetting:GetChecked() then
            self.cbChat:SetChecked(false)
            self.cbAction:SetChecked(false)
            GUIBedWarSetting:show(true)
        else
            GUIBedWarSetting:hide(true)
        end
    end)

    self.cbChat:registerEvent(GUIEvent.CheckStateChanged, function()
        if self.cbChat:GetChecked() then
            self.cbSetting:SetChecked(false)
            self.cbAction:SetChecked(false)
            if BaseMain:getGameType() == "g1046" then
                GUIBedWarHallChatLayout:show(Define.ChatTabType.SameServer)
            else
                GUIChatInput:show()
            end
        else
            if BaseMain:getGameType() == "g1046" then
                GUIBedWarHallChatLayout:hide()
            else
                GUIChatInput:hide()
            end
        end
    end)

    self.btnChangeCamera:registerEvent(GUIEvent.ButtonClick, function()
        local cruCamera = SystemSettingRecord.defaultCamera
        if cruCamera == 1 then
            GUIBedWarSetting:changeCamera(2)
            SystemSettingRecord.defaultCamera = 2
        elseif cruCamera == 2 then
            GUIBedWarSetting:changeCamera(3)
            SystemSettingRecord.defaultCamera = 3
        elseif cruCamera == 3 then
            GUIBedWarSetting:changeCamera(1)
            SystemSettingRecord.defaultCamera = 1
        end
    end)

    self.cbAction:registerEvent(GUIEvent.CheckStateChanged, function()
        if self.cbAction:GetChecked() then
            self.cbSetting:SetChecked(false)
            self.cbChat:SetChecked(false)
            GUIAction:show()
        else
            GUIAction:hide()
        end
    end)

    self.btnVideo:registerEvent(GUIEvent.ButtonClick, function()
        print("_-----------------------------------------------")
        Plugins.CallTargetPluginFunc("video", "openVideo")
    end)
end

function UISurvivalToolBarLayout:cameraChange()
    local cruCamera = Blockman.Instance():getCurrPersonView()
    if self.cruCamera == cruCamera then
        return
    end
    self.cruCamera = cruCamera
    if cruCamera == 1 then
        self.btnChangeCamera:SetPushedImage("set:bedwar_toolbar.json image:change_camera_2")
        self.btnChangeCamera:SetNormalImage("set:bedwar_toolbar.json image:change_camera_2")
    elseif cruCamera == 2 then
        self.btnChangeCamera:SetPushedImage("set:bedwar_toolbar.json image:change_camera_3")
        self.btnChangeCamera:SetNormalImage("set:bedwar_toolbar.json image:change_camera_3")
    elseif cruCamera == 0 then
        self.btnChangeCamera:SetPushedImage("set:bedwar_toolbar.json image:change_camera_1")
        self.btnChangeCamera:SetNormalImage("set:bedwar_toolbar.json image:change_camera_1")
    end
end

function UISurvivalToolBarLayout:lockCamera(index)
    self.btnChangeCamera:SetEnabled(false)
    GUIBedWarSetting:changeCamera(index)
end

function UISurvivalToolBarLayout:unlockCamera()
    self.btnChangeCamera:SetEnabled(true)
end

function UISurvivalToolBarLayout:onTick(frameTime)
    self.cbSetting:SetChecked(GUIBedWarSetting:isShow())
    self:cameraChange()
end

return UISurvivalToolBarLayout
