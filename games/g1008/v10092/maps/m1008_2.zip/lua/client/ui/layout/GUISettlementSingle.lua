---@class UISettlementSingleLayout : IGUILayout
local UISettlementSingleLayout = class("UISettlementSingleLayout", IGUILayout)
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type AdUtil
local AdUtil = T(Global, "AdUtil")
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")

---@private
function UISettlementSingleLayout:ctor(parent)
    self.super.ctor(self, "SettlementSingle.json", parent)
end

---@private
function UISettlementSingleLayout:isDelayLoad()
    return true
end

---@private
function UISettlementSingleLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UISettlementSingleLayout:initCreateEvent()
    self:registerDataCallBack("SingleSettlement", function(data)
        isGameEnd = true
        SoundUtil.playSound(SoundConfig.nextSettlement)
        RootGuiLayout.Instance():showMainControl()
        self:show()
        self:updateInfo(data)
    end, DataBuilderProcessor)
end

---@private
function UISettlementSingleLayout:onLoad()
    self.siBg = self:getChildWindow("SettlementSingle-Bg", GUIType.StaticImage)
    self.siTitle1Bg = self:getChildWindow("SettlementSingle-Title1-Bg", GUIType.StaticImage)
    self.stTitleText = self:getChildWindow("SettlementSingle-Title-Text", GUIType.StaticText)
    self.llContent = self:getChildWindow("SettlementSingle-Content", GUIType.Layout)
    self.llRankNumLayout = self:getChildWindow("SettlementSingle-RankNum-Layout", GUIType.Layout)
    self.llSegment = self:getChildWindow("SettlementSingle-Segment", GUIType.Layout)
    self.stSegmentHint = self:getChildWindow("SettlementSingle-Segment-Hint", GUIType.StaticText)
    self.stKeyText = self:getChildWindow("SettlementSingle-Key-Text", GUIType.StaticText)
    self.stKDAText = self:getChildWindow("SettlementSingle-KDA-Text", GUIType.StaticText)
    self.stKillText = self:getChildWindow("SettlementSingle-Kill-Text", GUIType.StaticText)
    self.stDieText = self:getChildWindow("SettlementSingle-Die-Text", GUIType.StaticText)
    self.stAssistText = self:getChildWindow("SettlementSingle-Assist-Text", GUIType.StaticText)
    self.siSmallRankBg = self:getChildWindow("SettlementSingle-SmallRank-Bg", GUIType.StaticImage)
    self.llSmallRankNumLayout = self:getChildWindow("SettlementSingle-SmallRankNum-Layout", GUIType.Layout)
    self.stSmallRankText = self:getChildWindow("SettlementSingle-SmallRank-Text", GUIType.StaticText)
    self.btnKeyDoubleAd = self:getChildWindow("SettlementSingle-Key-Double-Ad", GUIType.Button)
    self.siBorder = self:getChildWindow("SettlementSingle-Border", GUIType.StaticImage)
    self.stName = self:getChildWindow("SettlementSingle-Name", GUIType.StaticText)
    self.stLevel = self:getChildWindow("SettlementSingle-Level", GUIType.StaticText)
    self.pbExpBar = self:getChildWindow("SettlementSingle-ExpBar", GUIType.ProgressBar)
    self.stExpText = self:getChildWindow("SettlementSingle-Exp-Text", GUIType.StaticText)
    self.stRewardExp = self:getChildWindow("SettlementSingle-RewardExp", GUIType.StaticText)
    self.llBravePoint = self:getChildWindow("SettlementSingle-BravePoint", GUIType.Layout)
    self.llShareHide = self:getChildWindow("SettlementSingle-Share-Hide", GUIType.Layout)
    self.llButtonsEnd = self:getChildWindow("SettlementSingle-Buttons-End", GUIType.Layout)
    self.btnNext = self:getChildWindow("SettlementSingle-Next", GUIType.Button)
    self.stNextText = self:getChildWindow("SettlementSingle-Next-Text", GUIType.StaticText)
    self.llButtons = self:getChildWindow("SettlementSingle-Buttons", GUIType.Layout)
    self.btnWatch = self:getChildWindow("SettlementSingle-Watch", GUIType.Button)
    self.stWatchText = self:getChildWindow("SettlementSingle-Watch-Text", GUIType.StaticText)
    self.btnBack = self:getChildWindow("SettlementSingle-Back", GUIType.Button)
    self.stBackText = self:getChildWindow("SettlementSingle-Back-Text", GUIType.StaticText)
    self.siBackTip = self:getChildWindow("SettlementSingle-Back-Tip", GUIType.StaticImage)
    self.stBackTipText = self:getChildWindow("SettlementSingle-Back-Tip-Text", GUIType.StaticText)
    self.btnPlayAgain = self:getChildWindow("SettlementSingle-PlayAgain", GUIType.Button)
    self.stPlayAgainText = self:getChildWindow("SettlementSingle-PlayAgain-Text", GUIType.StaticText)
    self.btnExit = self:getChildWindow("SettlementSingle-Exit", GUIType.Button)
    self.stExitText = self:getChildWindow("SettlementSingle-Exit-Text", GUIType.StaticText)
    self.btnShare = self:getChildWindow("SettlementSingle-Share", GUIType.Button)
    self.siAFKIcon = self:getChildWindow("SettlementSingle-AFKIcon", GUIType.StaticImage)
    self.siReport = self:getChildWindow("SettlementSingle-Report", GUIType.StaticImage)

    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.siBorder:GetPixelSize().x)
    self.siBorder:AddChildWindow(self.winHead.root)
    self.winHead:setCanOpenPersonalHome(false)

    self:initView()
    self:initEvent()
end

---@private
function UISettlementSingleLayout:initView()
    self.btnShare:SetVisible(not Game:isChina() and not Game:isEnableIndie())
    self.stSegmentHint:SetVisible(false)

    self.stBackText:SetText(Lang:getString("gui.backHall"))
    self.stWatchText:SetText(Lang:getString("gui.watch"))
    self.stPlayAgainText:SetText(Lang:getString("gui.playAgain"))
    self.stExitText:SetText(Lang:getString("wordart_exit_game"))
    self.stSmallRankText:SetText(Lang:getString("gui.rank"))
    self.stNextText:SetText(Lang:getString("gui.next"))
end

---@private
function UISettlementSingleLayout:initEvent()
    self.btnBack:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.playSound(SoundConfig.backHallSettlement)
        CommonPacketSender:sendBackHall()
    end)

    self.btnPlayAgain:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.playSound(SoundConfig.againSettlement)
        Game:playAgain()
        self.btnPlayAgain:SetEnabled(false)
    end)

    self.btnNext:registerEvent(GUIEvent.ButtonClick, function()
        SoundUtil.playSound(SoundConfig.nextSettlement)
        if TeamConfig:getTeamCount() > 4 then
            GUIResult8P:show(self.siBackTip:IsVisible())
        else
            GUIResult:show(self.siBackTip:IsVisible())
        end
    end)

    self.btnWatch:registerEvent(GUIEvent.ButtonClick, function()
        GUIManager:getWindowByName("BedWarGameMain-MenuList-ShortMessage"):SetVisible(false)
        GUIBedWarToolBar.btnBackHall:SetVisible(true)
        GUIBedWarToolBar.btnPlayAgain:SetVisible(true)
        GUIMain.btnStore:SetVisible(false)
        GUIMain.btnUpgradeStore:SetVisible(false)
        self:hide(true)
    end)

    self.btnExit:registerEvent(GUIEvent.ButtonClick, function()
        GUIBedWarSetting:onClickExit()
    end)

    self.btnKeyDoubleAd:registerEvent(GUIEvent.ButtonClick, function()
        if WatchADSwitch:getSwitchBoolByType(5) then
            WatchAdTip.init()
                      .setContentVisible(false)
                      .SetYPosition({ 0, -20 })
                      .setTitle("gui_bed_war_free_gift_tip_title")
                      .setTipText("gui_bed_war_settlement_single_double_key")
                      .banJumpToShop()
                      .show(Define.AdType.DoubleKey)
        else
            AdUtil:showAd(Define.AdType.DoubleKey)
        end
        SoundUtil.playSound(SoundType.Click)
    end)

    self.btnShare:registerEvent(GUIEvent.ButtonClick, function()
        if isTest then
            self:hide(true)
        else
            self:onShare(true)
        end
    end)

    self.siReport:registerEvent(GUIEvent.Click, function()
        if ReportPlayerContentLayout:setDefaultPlayer() then
            CustomDialog.builder()
                        .setTitleText("gui.report.player.title")
                        .setPanelSize(nil, 520)
                        .setContentView(ReportPlayerContentLayout)
                        .setRightClickListener(function()
                ReportPlayerContentLayout:doReport()
            end)        .show()
            ReportPlayerContentLayout:removeReportId(nil)
        end
    end)

    self:registerEvent(Events.SyncQualifyingDataEvent, function()
        self:initQualifyingView()
    end)

    self:registerDataCallBack("KeyAdSettlementSingle", function(data)
        self:onWatchAd(data)
    end)
end

---@private
function UISettlementSingleLayout:onShare(open)
    if open then
        self.isShare = true
        self.llShareHide:SetVisible(false)
        self.btnKeyDoubleAd:SetVisible(false)
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_SCREEN_CAPTURE)
    else
        self.isShare = false
        self.llShareHide:SetVisible(true)
        self.btnKeyDoubleAd:SetVisible(true)
    end
end

function UISettlementSingleLayout:show(playSound)
    if playSound then
        SoundUtil.playSound(SoundConfig.openSettlement)
    end
    self.super.show(self)
end

function UISettlementSingleLayout:hide(force)
    if not force then
        return
    end
    self.super.hide(self)
end

---@private
function UISettlementSingleLayout:onShow()
    if GUICommunitySharing and not ClientHelper.getBoolForKey("g1008_CommunitySharing") then
        ClientHelper.putBoolForKey("g1008_CommunitySharing", true)
        GUICommunitySharing:show()
    end
    self:onTick()
    if self.btnKeyDoubleAd:IsVisible() then
        AdUtil:checkAdStatus(Define.AdType.DoubleKey)
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ADS_PLACEMENT, Define.AdType.DoubleKey)
    end
    self:initQualifyingView()
end

---@private
function UISettlementSingleLayout:onWatchAd(data)
    local builder = DataBuilder.new():fromData(data)
    local key = builder:getNumberParam("key")
    self.stKeyText:SetText(string.format("+%d", key))
    self.stKeyText:SetTextColor(Color.GREEN)
    self.isDoubleKey = true
    self.btnKeyDoubleAd:SetVisible(false)
end

---@private
function UISettlementSingleLayout:updateInfo(data)
    local info = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
    if not info then
        return
    end
    local totalWidth = math.min(self.siBg:GetPixelSize().x)
    local totalHeight = math.min(self.siBg:GetPixelSize().y)
    if totalWidth / totalHeight > 1280 / 404 then
        totalWidth = totalHeight / 404 * 1280
    else
        totalHeight = totalWidth / 1280 * 404
    end
    self.llContent:SetArea({ 0, 0 }, { 0, 0 }, { 0, totalWidth }, { 0, totalHeight })

    local rank = tonumber(info:getValue("rank"))
    local rewardExp = data:getNumberParam("rewardExp") or 0
    local extraExp = data:getNumberParam("extraExp") or 0
    local cupExp = data:getNumberParam("cupExp") or 0
    local maxExp = data:getNumberParam("maxExp") or 0
    local level = data:getNumberParam("level") or 1
    local key = data:getNumberParam("key") or 0
    local extraKey = data:getNumberParam("extraKey") or 0
    local isEnd = data:getBoolParam("isEnd") or false
    local isNegative = data:getBoolParam("isNegative") or false
    local isEscape = data:getBoolParam("isEscape") or false
    local isLvUp = data:getBoolParam("isLvUp") or false

    self.winHead:setUserInfo(UserInfoCache:GetCache(Game:getPlatformUserId()) or {})
    self.stName:SetText(info:getValue("userName"))
    self.stKillText:SetText(info:getValue("kill"))
    self.stDieText:SetText(info:getValue("die"))
    self.stAssistText:SetText(info:getValue("assist"))
    self.stKDAText:SetText(info:getKDA())
    if extraExp >= 0 then
        self.stRewardExp:SetText(string.format("+%d(+%d)", rewardExp, extraExp))
    else
        self.stRewardExp:SetText(string.format("+%d(%d)", rewardExp, extraExp))
    end
    if extraKey >= 0 then
        self.stKeyText:SetText(string.format("+%d(+%d)", key, extraKey))
    else
        self.stKeyText:SetText(string.format("+%d(%d)", key, extraKey))
    end
    self.stKeyText:SetTextColor({ 199 / 255, 213 / 255, 226 / 255, 1 })
    ---等级相关处理
    self.stLevel:SetText("Lv" .. level)
    if cupExp < maxExp then
        self.pbExpBar:SetProgress(cupExp / maxExp)
        self.stExpText:SetText(tostring(cupExp) .. "/" .. maxExp)
    else
        self.pbExpBar:SetProgress(1)
        self.stExpText:SetText("MAX")
    end

    if isEscape then
        self.siAFKIcon:SetImage("set:bed_war_credit_score.json image:img_0_escape")
        self.siAFKIcon:SetVisible(true)
    elseif isNegative then
        self.siAFKIcon:SetImage("set:bed_war_credit_score.json image:img_0_inaction")
        self.siAFKIcon:SetVisible(true)
    end

    if isLvUp then
        self.siBackTip:SetVisible(true)
        local line = math.floor(self.stBackTipText:GetTextWidth() / 300) + 1
        self.siBackTip:SetHeight({ 0, math.max(self.stBackTipText:GetFont():GetFontHeight() * line + 20, 60) })
        self.stBackTipText:SetText(Lang:getString("gui_to_get_reward"), true)
        GUIResult.siBackTip:SetVisible(true)
        GUIResult8P.siBackTip:SetVisible(true)
    else
        self.siBackTip:SetVisible(false)
    end

    ---isEnd
    if isEnd then
        self.llButtons:SetVisible(false)
        self.llButtonsEnd:SetVisible(true)
        if TeamConfig:getTeamCount() > 4 then
            GUIResult8P:onUpdateUI()
        else
            GUIResult:onUpdateUI()
        end
    else
        ---检查是否还有队友
        local teamId = info:getValue("teamId")
        local teamInfo = GameInfoManager:getTeamInfo(teamId)
        if teamInfo and tonumber(teamInfo:getValue("liveCount")) > 0 then
            ---还有队友
        else

        end
    end
    self:setRankNum(rank)
    self:setWin()
end

---@private
function UISettlementSingleLayout:setWin()
    local info = GameInfoManager:getPlayerInfo(Game:getPlatformUserId())
    local isWin = false
    if info then
        isWin = info:getBoolValue("isWin")
    end
    if isWin then
        ---胜利
        self.siTitle1Bg:SetImage("set:result.json image:title_victory")
        self.stTitleText:SetText(Lang:getString("gui.victory"))
    else
        self.siTitle1Bg:SetImage("set:result.json image:title_failed")
        self.stTitleText:SetText(Lang:getString("gui.failed"))
    end
end

function UISettlementSingleLayout:onTick()
    if self.isShare then
        return
    end
    self.btnKeyDoubleAd:SetVisible(not self.isDoubleKey)
end

---@private
function UISettlementSingleLayout:setRankNum(rank)
    if rank >= 10 then
        self.llRankNumLayout:SetHeight({ 0.45, 0 })
        self.llSmallRankNumLayout:SetHeight({ 0.54, 0 })
    else
        self.llRankNumLayout:SetHeight({ 0.5, 0 })
        self.llSmallRankNumLayout:SetHeight({ 0.6, 0 })
    end
    UIUtils.setNumberToLayout(rank, self.llRankNumLayout)
    UIUtils.setNumberToLayout(rank, self.llSmallRankNumLayout)
end

---@private
function UISettlementSingleLayout:initQualifyingView()
    if not CQualifyingController:isInQualifying() then
        self.siSmallRankBg:SetVisible(false)
        self.llRankNumLayout:SetVisible(true)
        return
    end
    self.siSmallRankBg:SetVisible(true)
    self.llRankNumLayout:SetVisible(false)
    if self.wBravePoints == nil then
        ---@type GUIBedWarQualifyingBravePointsWindow
        self.wBravePoints = UIHelper.newGameGUIWindow("GUIBedWarQualifyingBravePoints")
        self.wBravePoints:setInGameSettlement()
        self.llBravePoint:AddChildWindow(self.wBravePoints.root)
    end
    if self.wHonorRank == nil then
        ---@type GUIBedWarQualifyingSegmentWindow
        self.wHonorRank = UIHelper.newGameGUIWindow("GUIBedWarQualifyingSegment", self.llSegment, 220)
    end
    self:updateQualifyingUI()
end

---@private
function UISettlementSingleLayout:updateQualifyingUI()
    WebService:GetQualifyingSegmentConfig(function(_)
        local qualifyingData = CQualifyingController:getQualifyingData()
        if not qualifyingData then
            return
        end
        if self.wBravePoints ~= nil then
            self.wBravePoints:onDataChanged(qualifyingData)
        end
        if self.wHonorRank ~= nil then
            self.wHonorRank:onDataChanged(qualifyingData, true)
        end
        self.stSegmentHint:SetVisible(CQualifyingController:isInPosMatch())
        self.stSegmentHint:SetText(Lang:format("gui.qualifying.in.pos.match", CQualifyingController:getPosMatchCount()))
    end)
end

return UISettlementSingleLayout
