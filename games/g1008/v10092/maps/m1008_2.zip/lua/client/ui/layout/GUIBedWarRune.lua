---@class UIBedWarRuneLayout : IGUILayout
local UIBedWarRuneLayout = class("UIBedWarRuneLayout", IGUILayout)
---@type CRuneController
local CRuneController = T(Global, "CRuneController")
---@type RuneConfig
local RuneConfig = T(Global, "RuneConfig")

---@private
function UIBedWarRuneLayout:ctor(parent)
    self.super.ctor(self, "BedWarRune.json", parent)
end

---@private
function UIBedWarRuneLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarRuneLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIBedWarRuneLayout:initCreateEvent()

end

---@private
function UIBedWarRuneLayout:onLoad()
    self.rgTab = RadioBoxGroup.new()
    self.rgTypeTab = RadioBoxGroup.new()
    self.siBackground = self:getChildWindow("BedWarRune-Background", GUIType.StaticImage)
    self.siShadow = self:getChildWindow("BedWarRune-Shadow", GUIType.StaticImage)
    self.llTabLayout = self:getChildWindow("BedWarRune-TabLayout", GUIType.Layout)
    self.cbTabRuneButton = self:getChildWindow("BedWarRune-TabRuneButton", GUIType.CheckBox)
    self.siTabRuneLine = self:getChildWindow("BedWarRune-TabRuneLine", GUIType.StaticImage)
    self.cbTabBagButton = self:getChildWindow("BedWarRune-TabBagButton", GUIType.CheckBox)
    self.siTabBagLine = self:getChildWindow("BedWarRune-TabBagLine", GUIType.StaticImage)
    self.btnGetRune = self:getChildWindow("BedWarRune-GetRune", GUIType.Button)
    self.stGetRuneTitle = self:getChildWindow("BedWarRune-GetRuneTitle", GUIType.StaticText)
    self.llRune = self:getChildWindow("BedWarRune-Rune", GUIType.Layout)
    self.siRuneBackground = self:getChildWindow("BedWarRune-RuneBackground", GUIType.StaticImage)
    self.siProSumLayout = self:getChildWindow("BedWarRune-ProSumLayout", GUIType.StaticImage)
    self.siTotalRuneLevelBackground = self:getChildWindow("BedWarRune-TotalRuneLevelBackground", GUIType.StaticImage)
    self.stTotalRuneLevel = self:getChildWindow("BedWarRune-TotalRuneLevel", GUIType.StaticText)
    self.stTotalRuneLevelTitle = self:getChildWindow("BedWarRune-TotalRuneLevelTitle", GUIType.StaticText)
    self.llProPerLayout = self:getChildWindow("BedWarRune-ProPerLayout", GUIType.Layout)
    self.btnOneKeyUninstall = self:getChildWindow("BedWarRune-OneKeyUninstall", GUIType.Button)
    self.btnOneKeyInstall = self:getChildWindow("BedWarRune-OneKeyInstall", GUIType.Button)
    self.siRuneListLayout = self:getChildWindow("BedWarRune-RuneListLayout", GUIType.StaticImage)
    self.llCurRuneLayout = self:getChildWindow("BedWarRune-CurRuneLayout", GUIType.Layout)
    self.siCurRuneImg = self:getChildWindow("BedWarRune-CurRuneImg", GUIType.StaticImage)
    self.stCurRuneName = self:getChildWindow("BedWarRune-CurRuneName", GUIType.StaticText)
    self.stCurRuneDes = self:getChildWindow("BedWarRune-CurRuneDes", GUIType.StaticText)
    self.stCurRunePro = self:getChildWindow("BedWarRune-CurRunePro", GUIType.StaticText)
    self.btnUninstallButton = self:getChildWindow("BedWarRune-UninstallButton", GUIType.Button)
    self.stRuneListTitle = self:getChildWindow("BedWarRune-RuneListTitle", GUIType.StaticText)
    self.ltRuneList = self:getChildWindow("BedWarRune-RuneList", GUIType.List)
    self.btnRuneListBack = self:getChildWindow("BedWarRune-RuneListBack", GUIType.Button)
    self.llBag = self:getChildWindow("BedWarRune-Bag", GUIType.Layout)
    self.llTypeTab = self:getChildWindow("BedWarRune-TypeTab", GUIType.Layout)
    self.llWithoutRune = self:getChildWindow("BedWarRune-WithoutRune", GUIType.Layout)
    self.siNoticeIcon = self:getChildWindow("BedWarRune-NoticeIcon", GUIType.StaticImage)
    self.siNoticeIcon2 = self:getChildWindow("BedWarRune-NoticeIcon2", GUIType.StaticImage)
    self.stNoticeTxt = self:getChildWindow("BedWarRune-NoticeTxt", GUIType.StaticText)
    self.llWithoutRuneLst = self:getChildWindow("BedWarRune-WithoutRuneLst", GUIType.Layout)
    self.siNoticeIconLst = self:getChildWindow("BedWarRune-NoticeIconLst", GUIType.StaticImage)
    self.siNoticeIconLst2 = self:getChildWindow("BedWarRune-NoticeIconLst2", GUIType.StaticImage)
    self.stNoticeTxtLst = self:getChildWindow("BedWarRune-NoticeTxtLst", GUIType.StaticText)
    self.btnNoticeButtonLst = self:getChildWindow("BedWarRune-NoticeButtonLst", GUIType.Button)
    self.lvProList = IGUIListView.new("ProListView", self.llProPerLayout)
    self.troughPos = { { 64, 290 }, { 165, 247 }, { 247, 165 }, { 290, 64 }, { 91, 173 }, { 173, 91 }, { 64, 64 } }
    self.runeAdapterPattern = { bagList = 1, runeList = 2 }
    ---@type GUIBedWarRuneTroughItemWindow[]
    self.trough = {}
    local troughId = 0
    for type = 1, 4 do
        local notTrans = (type == 1 or type == 4) and 1 or 2
        for order = 1, 7 do
            local XPos = self.troughPos[order][notTrans] * (type % 2 == 1 and -1 or 1)
            local YPos = self.troughPos[order][3 - notTrans] * (type < 3 and -1 or 1)
            troughId = troughId + 1
            self.trough[troughId] = UIHelper.newGameGUIWindow("GUIBedWarRuneTroughItem", troughId, XPos, YPos, self.siRuneBackground)
        end
    end
    ---@type GUICheckBox[]
    self.cbType = {}
    ---@type GUIStaticText[]
    self.stTypeTxt = {}
    ---@type GUIStaticImage[]
    self.siTypeLine = {}
    for type = 1, 5 do
        self.cbType[type] = self:getChildWindow("BedWarRune-Type" .. type, GUIType.CheckBox)
        self.stTypeTxt[type] = self:getChildWindow("BedWarRune-TypeTxt" .. type, GUIType.StaticText)
    end
    for i = 1, 4 do
        self.siTypeLine[i] = self:getChildWindow("BedWarRune-TypeLine" .. i, GUIType.StaticImage)
    end
    self.llBagLayout = self:getChildWindow("BedWarRune-BagLayout", GUIType.Layout)
    self.btnBulkSale = self:getChildWindow("BedWarRune-BulkSale", GUIType.Button)
    ---@type GUICurrency
    self.llKeyMoney = UIHelper.newGameGUIWindow("GUICurrency", "GameActivityCurrency.json")
    self:getChildWindow("BedWarRune-Key", GUIType.Layout):AddChildWindow(self.llKeyMoney.root)
    self:initView()
    self:initEvent()
    self:updateTroughUI()
    self:updateProListUI(1)
end

---@private
function UIBedWarRuneLayout:initView()
    ---@type GUIBedWarUIReturnControlWindow
    local llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui.game.rule.txt", function()
        SoundUtil.clickUI()
        self:hide()
    end)
    self.root:AddChildWindow(llReturn.root)
    self.llKeyMoney:onDataChanged({ ItemId = 0, RealId = Define.Money.KEY, Icon = "set:bed_war_3_icon.json image:img_0_key" })
    self.cbTabRuneButton:SetText(Lang:getString("gui.game.rule.txt"))
    self.cbTabBagButton:SetText(Lang:getString("gui_bedwar_bag_txt"))
    self.stGetRuneTitle:SetText(Lang:getString("gui_bedwar_obtain_rune_title"))
    self.stTotalRuneLevel:SetText(CRuneController:getRuneSumLevel())
    self.stTotalRuneLevelTitle:SetText(Lang:getString("gui_bed_war_pro_lv_sum_txt"))
    self.btnOneKeyInstall:SetText(Lang:getString("gui.bed_war.one.key.assemble.txt"))
    self.btnOneKeyUninstall:SetText(Lang:getString("gui.bed_war.one.key.unload.txt"))
    self.btnUninstallButton:SetText(Lang:getString("bed.war.custom.shop.unload"))
    self.stRuneListTitle:SetText(Lang:getString("gui_bedwar_interchangeable_rune"))
    self.btnBulkSale:SetText(Lang:getString("gui_bed_war_batch_reclaim_txt"))
    self.stNoticeTxt:SetText(Lang:getString("gui.bed_war.rune.notice.txt"))
    self.stNoticeTxtLst:SetText(Lang:getString("gui.bed_war.rune.notice.txt"))
    self.btnNoticeButtonLst:SetText(Lang:getString("gui_bedwar_obtain_rune_title"))
    for type = 1, 5 do
        self.stTypeTxt[type]:SetText(Lang:getString("gui_bed_war_re_tab_title" .. type))
        self.cbType[type]:SetChecked(false)
    end
    self:setTypeTxtColor(1)
    self.cbType[1]:SetChecked(true)
    self.cbTabRuneButton:SetNormalImage("")
    self.cbTabBagButton:SetNormalImage("")
    self.cbTabRuneButton:SetChecked(true)
    self.cbTabBagButton:SetChecked(false)
    ---@type RuneItemAdapter
    self.bagListAdapter = UIHelper.newGameAdapter("RuneItemAdapter", self.runeAdapterPattern.bagList)
    self.bagListAdapter:setItemSize(322, 104)
    self.gvBagGridView = IGUIGridView.new("BagGridView", self.llBagLayout)
    self.gvBagGridView:setAdapter(self.bagListAdapter)
    self.gvBagGridView:setConfig(10, 10, 3)
    ---@type RuneItemAdapter
    self.runeListAdapter = UIHelper.newGameAdapter("RuneItemAdapter", self.runeAdapterPattern.runeList)
    self.lvRuneList = IGUIListView.new("", self.siRuneListLayout, self.ltRuneList, Orientation.Vertical)
    self.runeListAdapter:setItemSize(self.lvRuneList:getWidth(), 111)
    self.lvRuneList:setAdapter(self.runeListAdapter)
    self.lvRuneList:setItemSpace(6)
    self.lvProList:setItemSpace(4)
end

---@private
function UIBedWarRuneLayout:initEvent()
    self.rgTab:addCheckBox(self.cbTabRuneButton, function(checked)
        if not checked then
            return
        end
        self.llRune:SetVisible(true)
        self.llBag:SetVisible(false)
        self.cbTabRuneButton:SetTextColor({ 34 / 255, 41 / 255, 92 / 255, 1 })
        self.cbTabBagButton:SetTextColor({ 100 / 255, 113 / 255, 147 / 255, 1 })
    end)
    self.rgTab:addCheckBox(self.cbTabBagButton, function(checked)
        if not checked then
            return
        end
        self:updateBagListUI(self.rgTypeTab:getCurIndex())
        self.llRune:SetVisible(false)
        self.llBag:SetVisible(true)
        self.cbTabRuneButton:SetTextColor({ 100 / 255, 113 / 255, 147 / 255, 1 })
        self.cbTabBagButton:SetTextColor({ 34 / 255, 41 / 255, 92 / 255, 1 })
    end)
    self.btnGetRune:registerEvent(GUIEvent.ButtonClick, function()
        GUIBoxLottery:show()
    end)
    self.btnNoticeButtonLst:registerEvent(GUIEvent.ButtonClick, function()
        GUIBoxLottery:show()
    end)
    for troughId = 1, 28 do
        self.trough[troughId].root:registerEvent(GUIEvent.Click, function()
            local curTroughId = CRuneController:getCurTrough()
            if curTroughId == troughId then
                return
            end
            if curTroughId ~= 0 then
                self.trough[curTroughId]:setSelected(false)
            end
            CRuneController:setCurTrough(troughId)
            local curType = math.ceil(troughId / 7)
            if CRuneController:checkTroughLock() then
                CustomDialog.builder()
                            .setTitleText(Lang:getString("gui_bedwar_unlock_rune_title_tip"))
                            .setContentView(UnlockTroughContent)
                            .setRightClickListener(function()
                    CRuneController:runeTroughUnlock(curType)
                end)        .show()
                self:notShowRuneListLayout(0)
                return
            end
            local runeId = CRuneController:getRuneByTrough(troughId)
            local config = RuneConfig:getRuneById(runeId)
            if config then
                self.siCurRuneImg:SetImage(config.Image)
                self.stCurRuneName:SetText(Lang:getString(config.Name))
                self.stCurRuneDes:SetText(Lang:getString(config.DesWithoutPro))
                self.stCurRunePro:SetXPosition({ 0, math.min(self.stCurRuneDes:GetTextWidth(), 200) + 20 })
                self.stCurRunePro:SetText(Lang:format(config.DesPro, config.Pro))
                self:isShowCurRune(true)
            else
                self:isShowCurRune(false)
            end
            self.trough[troughId]:setSelected(true)
            self:updateRuneListUI(curType)
            self.siRuneListLayout:SetVisible(true)
        end)
    end
    self.btnOneKeyUninstall:registerEvent(GUIEvent.ButtonClick, function()
        CRuneController:oneKeyUninstall()
    end)
    self.btnOneKeyInstall:registerEvent(GUIEvent.ButtonClick, function()
        CRuneController:oneKeyInstall()
    end)
    self.btnUninstallButton:registerEvent(GUIEvent.ButtonClick, function()
        CRuneController:installRune()
    end)
    self.btnRuneListBack:registerEvent(GUIEvent.ButtonClick, function()
        self:notShowRuneListLayout(CRuneController:getCurTrough())
    end)
    for type = 1, 5 do
        self.rgTypeTab:addCheckBox(self.cbType[type], function(checked)
            if not checked then
                return
            end
            self:updateBagListUI(type)
            self:setTypeTxtColor(type)
        end)
    end
    self.btnBulkSale:registerEvent(GUIEvent.ButtonClick, function()
        local curIndex = self.rgTypeTab:getCurIndex()
        local result = CRuneController:getReclaimNum(curIndex)
        local totalNum = result.num[1] + result.num[2] + result.num[3]
        if totalNum == 0 then
            CustomDialog.builder()
                        .setTitleText(Lang:getString("gui_bedwar_reclaim_all_title_tip"))
                        .setContentText(Lang:format("gui_bedwar_reclaim_all_fail_tip"))
                        .setRightClickListener(function()

            end)        .show()
            return
        end
        CustomDialog.builder()
                    .setTitleText(Lang:getString("gui_bedwar_reclaim_all_title_tip"))
                    .setContentText(Lang:format("gui_bedwar_reclaim_all_msg_tip", result.yaoshi, 0, 0, 0))
                    .setRightClickListener(function()
            if totalNum > 0 then
                CRuneController:bulkReclaim(curIndex)
            end
        end)        .show()
    end)
    self:registerEvent(Events.ChangeRuneEvent, function()
        self:updateBagListUI(self.rgTypeTab:getCurIndex())
        self:updateRuneListUI(math.ceil(CRuneController:getCurTrough() / 7))
    end)
    self:registerEvent(Events.ChangeEquipRuneEvent, function(troughId)
        self:updateTroughUI(troughId)
        self:notShowRuneListLayout(CRuneController:getCurTrough())
    end)
    self:registerEvent(Events.ChangeProListEvent, function(pattern, rune_list)
        self:updateProListUI(pattern, rune_list)
    end)
    self.siBackground:registerEvent(GUIEvent.Click, function()
        self:notShowRuneListLayout(CRuneController:getCurTrough())
    end)
end

---@private
function UIBedWarRuneLayout:onTick()
    self.llKeyMoney:onTick()
end

---@private
function UIBedWarRuneLayout:updateBagListUI(type)
    local rune_list = CRuneController:getRuneByType(type, true)
    self.bagListAdapter:setData(rune_list)
    if #rune_list == 0 then
        self.llWithoutRune:SetVisible(true)
    else
        self.llWithoutRune:SetVisible(false)
    end
end

---@private
function UIBedWarRuneLayout:updateRuneListUI(type)
    if type == 0 then
        return
    end
    local rune_list = CRuneController:getRuneByType(type + 1, false)
    self.runeListAdapter:setData(rune_list)
    self.llWithoutRuneLst:SetVisible(#rune_list == 0)
    self.ltRuneList:SetVisible(#rune_list ~= 0)
end

---@private
function UIBedWarRuneLayout:updateTroughUI(troughId)
    local curTrough = troughId and CRuneController:getTroughByIndex(troughId) or CRuneController:getAllTrough()
    if not curTrough then
        return
    end

    for _, trough in ipairs(curTrough) do
        if not trough.lock then
            local config = RuneConfig:getRuneById(trough.id)
            self.trough[trough.t_id]:onDataChanged(config)
        end
    end
end

---@private
function UIBedWarRuneLayout:updateProListUI(pattern, rune_list)
    self.stTotalRuneLevel:SetText(CRuneController:getRuneSumLevel())
    if pattern == 0 then
        self.lvProList:clearItems()
        return
    end
    if pattern == 1 then
        rune_list = rune_list or CRuneController:getAllTrough()
        for _, rune in pairs(rune_list) do
            self:updatePerPro(0, rune.id)
        end
        return
    end
    self:updatePerPro(rune_list.oldRuneId, rune_list.curRuneId)
end

---@private
function UIBedWarRuneLayout:updatePerPro(oldRuneId, curRuneId)
    if oldRuneId ~= 0 then
        local config = RuneConfig:getRuneById(oldRuneId)
        local configUsed = { SubType = config.SubType, Pro = -config.Pro, MaxPro = config.MaxPro, DesWithoutPro = config.DesWithoutPro, DesPro = config.DesPro }
        ---@type GUIBedWarRuneProItemWindow
        local item = self.lvProList:getItem("type", configUsed.SubType)
        if item then
            local backCall = item:onDataChanged(configUsed)
            if backCall == 0 then
                self.lvProList:removeItem(item)
            end
        end
    end

    if curRuneId ~= 0 then
        local config = RuneConfig:getRuneById(curRuneId)
        local configUsed = { SubType = config.SubType, Pro = config.Pro, MaxPro = config.MaxPro, DesWithoutPro = config.DesWithoutPro, DesPro = config.DesPro }
        ---@type GUIBedWarRuneProItemWindow
        local item = self.lvProList:getItem("type", configUsed.SubType)
        if item then
            item:onDataChanged(configUsed)
        else
            item = UIHelper.newGameGUIWindow("GUIBedWarRuneProItem")
            item:onDataChanged(configUsed)
            self.lvProList:addItem(item)
        end
    end
end

---@private
function UIBedWarRuneLayout:notShowRuneListLayout(troughId)
    if troughId ~= 0 then
        self.trough[troughId]:setSelected(false)
    end
    CRuneController:setCurTrough()
    self.siRuneListLayout:SetVisible(false)
end

---@private
function UIBedWarRuneLayout:setTypeTxtColor(index)
    for type = 1, 5 do
        self.stTypeTxt[type]:SetTextColor({ 165 / 255, 190 / 255, 225 / 255, 1 })
    end
    self.stTypeTxt[index]:SetTextColor({ 34 / 255, 41 / 255, 92 / 255, 1 })
end

---@private
function UIBedWarRuneLayout:isShowCurRune(isShow)
    self.stRuneListTitle:SetYPosition({ 0, isShow and 164 or 24 })
    self.ltRuneList:SetHeight({ 0, isShow and 480 or 620 })
    self.siNoticeIconLst:SetYPosition({ 0, isShow and 69 or -1 })
    self.stNoticeTxtLst:SetYPosition({ 0, isShow and 207 or 137 })
    self.llCurRuneLayout:SetVisible(isShow)
end

return UIBedWarRuneLayout
