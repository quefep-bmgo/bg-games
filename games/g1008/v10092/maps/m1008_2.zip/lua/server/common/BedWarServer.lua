require "EventDefine"
require "common.config.Define"
require "common.config.GameConfig"
require "common.config.TeamDefine"
require "common.connector.MessageInterceptor"
require "common.connector.TeamInterceptor"
require "common.connector.TeamService"
require "common.connector.QualifyingService"
require "common.connector.GameService"
require "common.web.BedWarWeb"
require "common.pay.PayHelper"
require "common.data.GMBedWarCommon"
require "common.data.GameReward"
require "common.data.GameChestLottery"
require "common.data.ServerTreasureChallenge"
require "common.data.GameTask"
require "common.data.GameTaskController"
require "common.data.GameLicense"
require "common.util.DbUtil"
require "common.util.MoneyUtil"
require "common.util.LotteryUtil"
require "common.util.GameModeUtil"
require "common.util.RankUtil"
require "common.util.ReconnectUtil"
require "common.util.CreditScoreUtil"
require "common.util.ReportPlayerUtil"
require "common.util.PlayerCustomInfoUtil"
require "common.util.QualifyingTool"
require "common.qualifying.QualifyingHelper"
require "common.rune.RuneHelper"
require "common.manager.PlayerManager"
require "common.manager.GameInfoManager"
require "common.manager.ScoreActivityTaskMgr"
require "common.manager.TurntableActivityTaskMgr"
require "common.manager.PuzzleActivityTaskMgr"
require "common.manager.PropPacketManager"
require "common.manager.BackHallManager"
require "common.packet.PidPacketHandler"
require "common.packet.CommonPacketSender"
require "common.packet.CommonPacketHandler"
require "common.listener.DBDataListener"
require "common.listener.CommonListener"

function onServerCommonInit()
    require "common.config.MapConfig"
    require "common.config.LicenseCompensateConfig"
    if GameType ~= "g1063" then
        ---@param mainActivity SMainActivity
        Plugins.CallTargetPluginFunc("activity", "init", function(mainActivity)
            SPluginMainActivity = mainActivity
        end)
    end
    ---每分钟记录一次在线时长任务
    LuaTimer:scheduleTimer(function()
        ---@type ServerPlayer[]
        local players = PlayerManager:getPlayers()
        for _, player in pairs(players) do
            if player.taskController then
                player.taskController:packingProgressData(Define.TaskType.GrowUp.OnlineTime, nil, 1)
            end
        end
    end, 60000)
    Plugins.CallTargetPluginFunc("item_skill", "enable")
end