---@class GUISettingCollimator : IGUIWindow
local GUISettingCollimator = class("GUISettingCollimator", IGUIWindow)

function GUISettingCollimator:ctor()
    self.super.ctor(self, "BedWarSettingCollimator.json")
end
function GUISettingCollimator:onLoad()
    self.clickBox = self:getChildWindowByName("BedWarSettingCollimator-ClickScene-Box", GUIType.CheckBox)
    ---@type GUICheckBox
    self.collimatorBox = self:getChildWindowByName("BedWarSettingCollimator-Collimator-Box", GUIType.CheckBox)

    self.clickLayout = self:getChildWindowByName("BedWarSettingCollimator-ClickScene-Show", GUIType.StaticImage)
    self.siCollimator = self:getChildWindowByName("BedWarSettingCollimator-Collimator-Show", GUIType.StaticImage)

    self:getChildWindowByName("BedWarSettingCollimator-Title", GUIType.StaticText):SetText(Lang:getString("gui.setting.collimator.title"))
    self:getChildWindowByName("BedWarSettingCollimator-ClickScene-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.collimator.clickScene"))
    self:getChildWindowByName("BedWarSettingCollimator-Collimator-Text", GUIType.StaticText):SetText(Lang:getString("gui.setting.collimator.collimator"))

    self.selectGroup = RadioBoxGroup.new(521)
    --self.soundGroup = RadioBoxGroup.new(SoundConfig.switchSetting)

    self:register()
end

function GUISettingCollimator:register()
    self.selectGroup:addCheckBox(self.clickBox, function(checked)
        if not checked then
            return
        end
        Blockman.Instance().m_gameSettings:setCollimatorMode(false)
        local player = PlayerManager:getClientPlayer()
        player:sendPacket({
            pid = "UpdateCollimatorMode",
            mode = false,
        })
    end)

    self.selectGroup:addCheckBox(self.collimatorBox, function(checked)
        if not checked then
            return
        end
        Blockman.Instance().m_gameSettings:setCollimatorMode(true)
        local player = PlayerManager:getClientPlayer()
        player:sendPacket({
            pid = "UpdateCollimatorMode",
            mode = true,
        })
    end)

    self.clickLayout:registerEvent(GUIEvent.Click, function()
        self.clickBox:SetChecked(true)
    end)

    self.siCollimator:registerEvent(GUIEvent.Click, function()
        self.collimatorBox:SetChecked(true)
    end)
end

function GUISettingCollimator:onDataChanged()
    if Blockman.Instance().m_gameSettings:isCollimatorMode() then
        self.collimatorBox:SetChecked(true)
    else
        self.clickBox:SetChecked(true)
    end
end

return GUISettingCollimator