---@class GUILottery3RewardItem : IGUIWindow
local GUILottery3RewardItem = class("GUILottery3RewardItem", IGUIWindow)

local qualify = {
    [1] = "set:bed_war_lottery3.json image:img_9_quality_green",
    [2] = "set:bed_war_lottery3.json image:img_9_quality_blue",
    [3] = "set:bed_war_lottery3.json image:img_9_quality_purple",
    [4] = "set:bed_war_lottery3.json image:img_9_quality_yellow",
}

function GUILottery3RewardItem:onLoad()
    self.siQualityBg = self:getChildWindowByName("BedWarLottery3RewardItem-QualityBg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("BedWarLottery3RewardItem-Icon", GUIType.StaticImage)
    self.llMask = self:getChildWindowByName("BedWarLottery3RewardItem-Mask", GUIType.Layout)
    self.stNum = self:getChildWindowByName("BedWarLottery3RewardItem-Num", GUIType.StaticText)
end

function GUILottery3RewardItem:onDataChanged(data)
    self.siIcon:SetImage(data.Image)
    self.siQualityBg:SetImage(qualify[data.qualify])
    if data.CountText == "1" then
        self.stNum:SetText("")
    else
        self.stNum:SetText(data.CountText)
    end

    if data.isGet == false then
        self.llMask:SetVisible(false)
    else
         self:addTimer(LuaTimer:schedule(function()
             self.llMask:SetVisible(true)
         end, 300)) 
    end
end

return GUILottery3RewardItem
