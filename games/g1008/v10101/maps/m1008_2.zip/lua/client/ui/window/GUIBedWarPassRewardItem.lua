---@class GUIBedWarPassRewardItemWindow : IGUIWindow
local GUIBedWarPassRewardItemWindow = class("GUIBedWarPassRewardItemWindow", IGUIWindow)

---@private
function GUIBedWarPassRewardItemWindow:ctor(...)
	self.super.ctor(self, "BedWarPassRewardItem.json", ...)
end

---@private
function GUIBedWarPassRewardItemWindow:onLoad()
	self.siIconBg = self:getChildWindowByName("BedWarPassRewardItem-Icon-bg", GUIType.StaticImage)
	self.btnIconButton = self:getChildWindowByName("BedWarPassRewardItem-Icon-Button", GUIType.Button)
	self.siIcon = self:getChildWindowByName("BedWarPassRewardItem-Icon", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("BedWarPassRewardItem-Num", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIBedWarPassRewardItemWindow:initView()
	self.stNum:SetText()
	self.siIconBg:SetImage("set:bedwar_new_license.json image:img_0_special")
end

---@private
function GUIBedWarPassRewardItemWindow:initEvent()
	self.btnIconButton:registerEvent(GUIEvent.ButtonClick, function()

	end)
end

---@param data table
function GUIBedWarPassRewardItemWindow:onDataChanged(data)
	local payReward = RewardConfig.findRewardById(data.rewardId)
	self.siIcon:SetImage(payReward.ShowDetail.image)
	self.stNum:SetVisible(data.count > 1)
	self.stNum:SetText(data.count)
end

return GUIBedWarPassRewardItemWindow
