---@class GUIInTeamPlayerItemWindow : IGUIWindow
local GUIInTeamPlayerItemWindow = class("GUIInTeamPlayerItemWindow", IGUIWindow)
---@type TeamService
local TeamService = T(Global, "TeamService")
---@type FriendManager
local FriendManager = T(Global, "FriendManager")

function GUIInTeamPlayerItemWindow:ctor(scale, ...)
    self.super.ctor(self, "InTeamPlayerItem.json", ...)
    self.root:SetWidth({ 0, 132 * scale })
    self.root:SetHeight({ 0, 252 * scale })
    self:initView()
end

function GUIInTeamPlayerItemWindow:onLoad()
    self.siNoPlayer = self:getChildWindowByName("InTeamPlayerItem-No-Player", GUIType.StaticImage)
    self.llContent = self:getChildWindowByName("InTeamPlayerItem-Content", GUIType.Layout)
    self.btnAddFriend = self:getChildWindowByName("InTeamPlayerItem-Add-Friend", GUIType.Button)
    self.llHeader = self:getChildWindowByName("InTeamPlayerItem-Header", GUIType.Layout)
    self.siCaptainTag = self:getChildWindowByName("InTeamPlayerItem-Captain-Tag", GUIType.StaticImage)
    self.btnRemove = self:getChildWindowByName("InTeamPlayerItem-Remove", GUIType.Button)
    self.stName = self:getChildWindowByName("InTeamPlayerItem-Name", GUIType.StaticText)
    self.siHonorIcon = self:getChildWindowByName("InTeamPlayerItem-Honor-Icon", GUIType.StaticImage)
    self.stHonorText = self:getChildWindowByName("InTeamPlayerItem-Honor-Text", GUIType.StaticText)
    self:initEvent()
end

function GUIInTeamPlayerItemWindow:initView()
    ---@type GUIBedWarHead
    self.winHead = UIHelper.newGameGUIWindow("GUIBedWarHead", self.llHeader:GetPixelSize().x)
    self.llHeader:AddChildWindow(self.winHead.root)
    self.winHead.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.winHead.root:SetVerticalAlignment(VerticalAlignment.Center)
    self.winHead.root:SetWidth({1,0})
    self.winHead.root:SetHeight({1,0})
end

function GUIInTeamPlayerItemWindow:initEvent()
    self.btnAddFriend:registerEvent(GUIEvent.ButtonClick, function()
        self.btnAddFriend:SetVisible(false)
        FriendManager.FriendOperation(Define.FriendOperationType.Request, self.data.userId)
    end)
    self.btnRemove:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.kick.out.team.tip"))
                    .setRightClickListener(function()
            if self.data then
                TeamService:kickOutTeammate(self.data.userId)
            end
        end)        .show()
    end)
end

---@param data BedWarUserInfo
function GUIInTeamPlayerItemWindow:onDataChanged(data)
    if not data or not TeamService:isInTeam(data.userId) then
        self.siNoPlayer:SetVisible(true)
        self.llContent:SetVisible(false)
        self.data = nil
        return
    end
    self.data = data
    self.llContent:SetVisible(true)
    self.siNoPlayer:SetVisible(false)
    self.stName:SetText(data.name)
    self.winHead:setUserInfo(data)
    self.siCaptainTag:SetVisible(TeamService.ownerId == data.userId)
    self.btnRemove:SetVisible(data.userId ~= Game:getPlatformUserId() and TeamService:isOwner())
    self.btnAddFriend:SetVisible(FriendManager.CanAddFriend(data.userId))
    QualifyingTool.setQualifyingSegmentInListUI(self.siHonorIcon, self.stHonorText, data.qualifyingData)
    local xPos = self.siHonorIcon:GetXPosition()[2]
    self.siHonorIcon:SetXPosition({ 0, math.max(xPos, -50) })
end

return GUIInTeamPlayerItemWindow
