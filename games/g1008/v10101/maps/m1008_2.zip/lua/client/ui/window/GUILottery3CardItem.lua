---@class GUILottery3CardItem : IGUIWindow
local GUILottery3CardItem = class("GUILottery3CardItem", IGUIWindow)

---@type GameLotteryModel
local GameLotteryModel = require("game.model.GameLotteryModel")

function GUILottery3CardItem:onLoad()
    self.siBg = self:getChildWindowByName("BedWarLottery3CardItem-Bg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("BedWarLottery3CardItem-Icon", GUIType.StaticImage)
    self.stNum = self:getChildWindowByName("BedWarLottery3CardItem-Num", GUIType.StaticText)
    self.stFree = self:getChildWindowByName("BedWarLottery3CardItem-Free", GUIType.StaticText)
    self.stFree:SetText(Lang:getString("gui_bed_war_lottery_free"))

    self.llCost = self:getChildWindowByName("BedWarLottery3CardItem-LotteryCost", GUIType.Layout)
    self.siCostIcon = self:getChildWindowByName("BedWarLottery3CardItem-CostIcon", GUIType.StaticImage)
    self.stCostNum = self:getChildWindowByName("BedWarLottery3CardItem-CostNum", GUIType.StaticText)

    self.siBg:registerEvent(GUIEvent.Click, function()
        GameLotteryModel:onBuyLottery(self.index)
    end)


    self.modelEvents = {}
    self.modelEvents[#self.modelEvents + 1] = GameLotteryModel:registerEvent("onGetReward", function(seq, rewardId)
        if seq == self.index then
            self.stFree:SetVisible(false)
            self.llCost:SetVisible(false)

            self.siIcon:SetVisible(true)
            local data = LotteryConfig.findRewardById(rewardId)
            self.siIcon:SetImage(data.Image)
            self.siIcon:SetWidth({ 0, 0 })
            self.rewardId = rewardId

            self:startRotateAnim(0.5)
        end
    end)

    self.modelEvents[#self.modelEvents + 1] = GameLotteryModel:registerEvent("nowPriceChange", function(seq, rewardId)
        local data = LotteryConfig.findRewardById(self.rewardId)
        if data and data.isGet then
            return
        end

        local nowPrice = GameLotteryModel:getNowPrice()
        if nowPrice == 0 then
            self.stFree:SetVisible(true)
            self.llCost:SetVisible(false)
        else
            self.stFree:SetVisible(false)
            self.llCost:SetVisible(true)
            self.stCostNum:SetText(nowPrice)
        end
    end)
end
local tick = {
    {delay = 3.0 / 20, image = "0002", width = 0},
    {delay = 2.0 / 20, image = "0003", width = 0},
    {delay = 3.0 / 20, image = "0004", width = 0},
    {delay = 2.0 / 20, image = "0005", width = 80 * 0.06, x = -6},
    {delay = 3.0 / 20, image = "0006", width = 80 * 0.65},
    {delay = 3.0 / 20, image = "0007", width = 80 * 0.92},
    {delay = 2.0 / 20, image = "0008", width = 80 * 1},
}

function GUILottery3CardItem:startRotateAnim(time, index)
    index = index or 1
    local info = tick[index]
    if not info then
        self.siIcon:SetWidth({ 0, 80})
        local data = LotteryConfig.findRewardById(self.rewardId)
        self.siBg:SetVisible(true)
        self:updateInfo(data)
        return
    end
    self.rotateAnimKey = LuaTimer:schedule(function()
        self.rotateAnimKey = nil
        self.siBg:SetImage("set:bed_war_lottery3.json image:"..info.image)
        self.siIcon:SetWidth({ 0, info.width })
        self.siIcon:SetXPosition({0, info.x or -1})
        self:startRotateAnim(time, index + 1)
    end, info.delay * time * 1000)
end

function GUILottery3CardItem:updateInfo(data)
    if data and data.isGet then
        self.siBg:SetImage("set:bed_war_lottery3.json image:0008")
        self.siIcon:SetVisible(true)
        self.stNum:SetVisible(true)

        self.llCost:SetVisible(false)
        self.stFree:SetVisible(false)

        self.siIcon:SetImage(data.Image)
        self.stNum:SetText(tostring(data.CountText))

    else
        self.siBg:SetImage("set:bed_war_lottery3.json image:0001")
        self.siIcon:SetVisible(false)
        self.stNum:SetVisible(false)

        local nowPrice = GameLotteryModel:getNowPrice()
        if nowPrice == 0 then
            self.stFree:SetVisible(true)
            self.llCost:SetVisible(false)
        else
            self.stFree:SetVisible(false)
            self.llCost:SetVisible(true)
            self.stCostNum:SetText(nowPrice)
        end
    end
end

function GUILottery3CardItem:onDataChanged(info)
    self.index = info.index
    self.rewardId = info.rewardId
    local data = LotteryConfig.findRewardById(info.rewardId)
    self:updateInfo(data)
end

function GUILottery3CardItem:onDestroy()
    self.super.onDestroy(self)
    if self.rotateAnimKey then
        LuaTimer:cancel(self.rotateAnimKey)
        self.rotateAnimKey = nil
    end

    for i, func in ipairs(self.modelEvents) do
        func()
    end
    self.modelEvents = {}
end

return GUILottery3CardItem
