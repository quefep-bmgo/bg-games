---@class GUISettingMaterialCellWindow : IGUIWindow
local GUISettingMaterialCellWindow = class("GUISettingMaterialCellWindow", IGUIWindow)

---@private
function GUISettingMaterialCellWindow:ctor(...)
	self.super.ctor(self, "SettingMaterialCell.json", ...)
end


local UseStatus = {
	NoUse = { 44 / 255, 135 / 255, 53 / 255, 1 },
	Using = { 31 / 255, 94 / 255, 37 / 255, 1}
}

---@private
function GUISettingMaterialCellWindow:onLoad()
	self.siImage = self:getChildWindowByName("SettingMaterialCell-Image", GUIType.UrlImage)
	self.stName = self:getChildWindowByName("SettingMaterialCell-Name", GUIType.StaticText)
	self.siUse = self:getChildWindowByName("SettingMaterialCell-Use", GUIType.StaticImage)
	self.stUseTxt = self:getChildWindowByName("SettingMaterialCell-Use-Txt", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUISettingMaterialCellWindow:initView()
	self.stName:SetText()
	self.stUseTxt:SetText(Lang:getString("gui_blockcity_pack_use"))
	self.siImage:setUrl("")
	self.siUse:SetBackgroundColor(UseStatus.NoUse)
end

---@private
function GUISettingMaterialCellWindow:initEvent()
	--self.siUse:registerEvent(GUIEvent.Click, function()
	--	if self.fun and self.canUse then
	--		self.fun(self.data)
	--	end
	--end)
	self.root:registerEvent(GUIEvent.Click, function()
		if self.fun and self.canUse then
			self.fun(self.data)
		end
	end)
end

---@param data table
function GUISettingMaterialCellWindow:onDataChanged(data)
	--LogUtil.pv(data)
	--local price = data.price
	self.data = data
	self.fun = nil
	if data then
		self.fun = data.fun
		self.canUse = data.purchaseStatus ~= 2
		local name = data.name
		local coverImage = data.coverImage
		--local materialBagId = data.materialBagId
		local purchaseStatus = data.purchaseStatus
		self.siImage:setChildMaterial(0)
		if coverImage then
			self.siImage:setUrl(coverImage)
		end
		if name then
			self.stName:SetText(Lang:getString(name))
		end
		if purchaseStatus == 2 then
			self.siUse:SetBackgroundColor(UseStatus.Using)
			self.stUseTxt:SetText(Lang:getString("gui_shop_has_use"))
		else
			self.siUse:SetBackgroundColor(UseStatus.NoUse)
			self.stUseTxt:SetText(Lang:getString("gui_blockcity_pack_use"))
		end
	end
end

return GUISettingMaterialCellWindow
