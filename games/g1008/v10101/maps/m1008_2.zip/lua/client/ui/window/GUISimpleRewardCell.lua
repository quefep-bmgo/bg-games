---@class GUISimpleRewardCellWindow : IGUIWindow
local GUISimpleRewardCellWindow = class("GUISimpleRewardCellWindow", IGUIWindow)

---@private
function GUISimpleRewardCellWindow:onLoad()
	self.siIcon = self:getChildWindowByName("SimpleRewardCell-icon", GUIType.StaticImage)
	self.stNum = self:getChildWindowByName("SimpleRewardCell-num", GUIType.StaticText)
end

---@param data table
function GUISimpleRewardCellWindow:onDataChanged(data)
	if data then
		self.siIcon:SetImage(data.icon)
		self.stNum:SetText(data.num)
	end
end

return GUISimpleRewardCellWindow
