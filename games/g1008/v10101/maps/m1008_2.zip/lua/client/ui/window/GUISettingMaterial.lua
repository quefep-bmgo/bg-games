---@class GUISettingMaterialWindow : IGUIWindow
local GUISettingMaterialWindow = class("GUISettingMaterialWindow", IGUIWindow)

local defaultMaterial = {
	materialBagId = 0,
	name = "gui.default.material.pack",
	coverImage = "http://static.sandboxol.com/sandbox/icon/props/fenbaodefault230316.png"
}

local getFileNameList = function(path)
	local fileNameList = {}
	if os.execute("cd "..path) then
		for entry in lfs.dir(path) do
			if entry~='.' and entry~='..' then
				local arr = StringUtil.split(entry, ".")
				if #arr == 2 and arr[2] == "zip" then
					table.insert(fileNameList, tonumber(arr[1]))
				end
			end
		end
	end
	return fileNameList;
end

---@private
function GUISettingMaterialWindow:ctor(...)
	self.super.ctor(self, "SettingMaterial.json", ...)
end

---@private
function GUISettingMaterialWindow:onLoad()
	self.llControl = self:getChildWindowByName("SettingMaterial-control", GUIType.Layout)
	self.ltyHelp = self:getChildWindowByName("SettingMaterial-help", GUIType.Layout)
	self.txtHelp = self:getChildWindowByName("SettingMaterial-helpText", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUISettingMaterialWindow:initView()
	self.txtHelp:SetText(Lang:getString("gui.material.help"))

	self.gvGiftList = IGUIGridView.new("SettingMaterial-List", self.llControl)
	self.gvGiftList:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
	self.gvGiftList:setConfig(9, 12, 3)
	---@type SettingMaterialAdapter
	self.giftAdapter = UIHelper.newGameAdapter("SettingMaterialAdapter")
	self.giftAdapter:setItemSize(274, 248)
	self.gvGiftList:setAdapter(self.giftAdapter)

end

---@private
function GUISettingMaterialWindow:initEvent()
	self.ltyHelp:registerEvent(GUIEvent.Click, function()
		CustomDialog.builder().setTitleText(Lang:getString("gui.material.help.title"))
					.setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
					.setHideLeftButton()
					.setHideRightButton()
					.setContentText(Lang:getString("gui.material.help.details"))
					.show()
	end)
end

function GUISettingMaterialWindow:changeBlockTextures(materialBagId)
	if not materialBagId then
		return
	end
	local path = FileUtil:getTexturePackPath()
	local fun = function(_, code)
		if code == 1 then
			Blockman.Instance():changeBlockTextures(path)
			GUIBedWarSetting:hide()
		end
		self.onUseMaterial = false
	end
	if materialBagId == 0 then
		path = ""
		WebService:CancelUseMaterialBag(fun)
	else
		path = FileUtil:getTexturePackPath() .. materialBagId .. ".zip"
		WebService:UseMaterialBag(materialBagId, fun)
	end
end

function GUISettingMaterialWindow:updateSettingMaterialList(data)
	if data then
		defaultMaterial.purchaseStatus = 2
		table.insert(data,1,defaultMaterial)
		for i, v in pairs(data) do
			v.fun = function(info)
				if not info or self.onUseMaterial then
					return
				end
				self.onUseMaterial = true
				self:changeBlockTextures(info.materialBagId)
			end
			if v.materialBagId ~= 0 and v.purchaseStatus == 2 then
				data[1].purchaseStatus = 1
			end
		end
		self.giftAdapter:setData(data)
	end
end

function GUISettingMaterialWindow:onDataChanged()
	local path = FileUtil:getTexturePackPath()
	local ids = getFileNameList(path)
	WebService:GetMaterialBagListByIds(ids, function(data, code)
		--print('--GetMaterialBagListByIds--',code)
		--LogUtil.pv(data)
		self:updateSettingMaterialList(data or {})
	end)
end

return GUISettingMaterialWindow
