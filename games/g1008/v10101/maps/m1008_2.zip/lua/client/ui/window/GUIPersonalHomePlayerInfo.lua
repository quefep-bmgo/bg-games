---@type FriendManager
local FriendManager = T(Global, "FriendManager")

---@class GUIPersonalHomePlayerInfoWindow : IGUIWindow
local GUIPersonalHomePlayerInfoWindow = class("GUIPersonalHomePlayerInfoWindow", IGUIWindow)
---@type CreditScoreConfig
local CreditScoreConfig = T(Global, "CreditScoreConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

local recordList = {
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_play_times",
        count = 0,
        desc = "gui.personal.record.game",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_friend",
        count = 0,
        desc = "gui.personal.record.friend",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_heat",
        count = 0,
        desc = "gui.personal.record.hot",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_fan",
        count = 0,
        desc = "gui.personal.record.follow",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_reputation",
        count = 0,
        desc = "gui.personal.record.credit",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_play_daytime",
        count = 0,
        desc = "gui.personal.record.playDay",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_rune",
        count = 0,
        desc = "gui.personal.record.rune",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_dan",
        count = 0,
        desc = "gui.personal.record.rank",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_individuation",
        count = 0,
        desc = "gui.personal.record.dress",
    },
    {
        icon = "set:bed_war_3_personal_homepage.json image:icon_entertainment",
        count = 0,
        desc = "gui.personal.record.fun",
    },
}

function GUIPersonalHomePlayerInfoWindow:ctor(...)
    self.super.ctor(self, "PersonalHomePlayerInfo.json", ...)
end

function GUIPersonalHomePlayerInfoWindow:onLoad()
    self.llPlayerInfo = self:getChildWindowByName("PersonalHomePlayerInfo-Player-Info", GUIType.Layout)
    self.llHead = self:getChildWindowByName("PersonalHomePlayerInfo-Head", GUIType.Layout)
    self.stLv = self:getChildWindowByName("PersonalHomePlayerInfo-Lv", GUIType.StaticText)
    self.pbExp = self:getChildWindowByName("PersonalHomePlayerInfo-Lv-Exp", GUIType.ProgressBar)
    self.stExp = self:getChildWindowByName("PersonalHomePlayerInfo-Lv-Exp-Text", GUIType.StaticText)
    self.stName = self:getChildWindowByName("PersonalHomePlayerInfo-Name", GUIType.StaticText)
    self.siCountryIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Country-Icon", GUIType.StaticImage)
    self.stCountry = self:getChildWindowByName("PersonalHomePlayerInfo-Country", GUIType.StaticText)
    self.siSex = self:getChildWindowByName("PersonalHomePlayerInfo-Sex", GUIType.StaticImage)
    self.siVip = self:getChildWindowByName("PersonalHomePlayerInfo-Vip", GUIType.StaticImage)
    self.siHot = self:getChildWindowByName("PersonalHomePlayerInfo-Hot", GUIType.StaticImage)
    self.stHotCount = self:getChildWindowByName("PersonalHomePlayerInfo-Hot-Count", GUIType.StaticText)
    self.siLike = self:getChildWindowByName("PersonalHomePlayerInfo-Like", GUIType.StaticImage)
    self.stLikeCount = self:getChildWindowByName("PersonalHomePlayerInfo-Like-Count", GUIType.StaticText)
    self.llIconList = self:getChildWindowByName("PersonalHomePlayerInfo-Icon-List", GUIType.Layout)
    self.llActors = self:getChildWindowByName("PersonalHomePlayerInfo-Actors", GUIType.Layout)
    self.siActorDecor = self:getChildWindowByName("PersonalHomePlayerInfo-Actor-Decor", GUIType.StaticImage)
    self.llPlayer = self:getChildWindowByName("PersonalHomePlayerInfo-Player", GUIType.Layout)
    self.awPet1 = self:getChildWindowByName("PersonalHomePlayerInfo-Pet-1", GUIType.ActorWindow)
    self.awPet2 = self:getChildWindowByName("PersonalHomePlayerInfo-Pet-2", GUIType.ActorWindow)
    self.llVisitors = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors", GUIType.Layout)
    self.siVisitorsIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors-Icon", GUIType.StaticText)
    self.stVisitorsText = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors-Text", GUIType.StaticText)
    self.llVisitorsList = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors-List", GUIType.Layout)
    self.llStatisticsData = self:getChildWindowByName("PersonalHomePlayerInfo-StatisticsData", GUIType.Layout)
    self.llRecordList = self:getChildWindowByName("PersonalHomePlayerInfo-Record-List", GUIType.Layout)

    self.btnAddFriend = self:getChildWindowByName("PersonalHomePlayerInfo-Add-Friend", GUIType.Button)
    self.btnFollow = self:getChildWindowByName("PersonalHomePlayerInfo-Follow", GUIType.Button)
    self.llDressShow = self:getChildWindowByName("PersonalHomePlayerInfo-Dress-Show", GUIType.Layout)
    self.siRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Rank-Icon", GUIType.StaticImage)
    self.stRankText = self:getChildWindowByName("PersonalHomePlayerInfo-Rank-Text", GUIType.StaticText)
    self.stRankName = self:getChildWindowByName("PersonalHomePlayerInfo-Rank-Name", GUIType.StaticText)
    self.siMaxRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Max-Rank-Icon", GUIType.StaticImage)
    self.stMaxRankText = self:getChildWindowByName("PersonalHomePlayerInfo-Max-Rank-Text", GUIType.StaticText)
    self.stMaxRankName = self:getChildWindowByName("PersonalHomePlayerInfo-Max-Rank-Name", GUIType.StaticText)
    self.btnTitleSet = self:getChildWindowByName("PersonalHomePlayerInfo-Title-Set", GUIType.Button)
    self.stNoTitle = self:getChildWindowByName("PersonalHomePlayerInfo-Title-No", GUIType.StaticText)
    self.llTitle = self:getChildWindowByName("PersonalHomePlayerInfo-Title", GUIType.Layout)
    self.llTitleLyt = self:getChildWindowByName("PersonalHomePlayerInfo-Title-Lyt", GUIType.Layout)
    self.siTitleRedDot = self:getChildWindowByName("PersonalHomePlayerInfo-Title-RedDot", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

function GUIPersonalHomePlayerInfoWindow:initView()
    self.siHot:SetVisible(false)

    local text = Lang:getString("gui.personal.visitors")
    self.stVisitorsText:SetText(text)
    local textWidth = self.stVisitorsText:GetFont():GetTextExtent(text, 1)
    self.stVisitorsText:SetWidth({0, textWidth})


    self.btnAddFriend:SetText(Lang:getString("gui.personal.btn.addFriend"))
    self.btnFollow:SetText(Lang:getString("gui.personal.btn.follow"))
    self.stRankText:SetText(Lang:getString("gui.personal.icon.rank"))
    self.stMaxRankText:SetText(Lang:getString("gui.personal.icon.maxRank"))
    self.stNoTitle:SetText(Lang:getString("gui.personal_title.noTitle"))

    ---@type GUIBedWarHead
    self.headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
    self.headItem:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.llHead:AddChildWindow(self.headItem.root)

    --self.lvDressList = IGUIGridView.new("VisitorsListContent-Dress-Show-List", self.llDressShow)
    --self.lvDressList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    --self.lvDressList:setConfig(10, 12, 3)
    ---@type DressShowAdapter
    --self.dressAdapter = UIHelper.newGameAdapter("DressShowAdapter")
    --self.dressAdapter:setItemSize(66, 66)
    --self.lvDressList:setAdapter(self.dressAdapter)

    self.lvGameRecordList = IGUIGridView.new("RecordListContent-Game-Record-List-" .. self.windowId, self.llRecordList)
    self.lvGameRecordList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.lvGameRecordList:setConfig(10, 5, 2)
    ---@type PlayerGameRecordAdapter
    self.recordAdapter = UIHelper.newGameAdapter("PlayerGameRecordAdapter")
    self.recordAdapter:setItemSize(172, 33)
    self.lvGameRecordList:setAdapter(self.recordAdapter)

    ---@type GUIBedWarPersonalTitleShowItem
    self.showTitleItem = UIHelper.newGameGUIWindow("GUIBedWarPersonalTitleShowItem")
    self.llTitleLyt:AddChildWindow(self.showTitleItem.root)

    self.siTitleRedDot:SetVisible(false)

    -----@type GUIBedWarBackgroundItemWindow
    self.winActor = UIHelper.newGameGUIWindow("GUIBedWarBackgroundItem")
    self.winActor.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.winActor.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.winActor.root:SetVerticalAlignment(VerticalAlignment.Center)
    self.llPlayer:AddChildWindow(self.winActor.root)
    self.winActor:setCanNotBeSelect()
    self.winActor:setShowActor()
end

function GUIPersonalHomePlayerInfoWindow:initEvent()
    self.btnAddFriend:registerEvent(GUIEvent.ButtonClick, function()
        if Game:getPlatformUserId() ~= self.curUserId then
            if FriendManager.IsFriend(self.curUserId) then
                ---打开聊天
                GUIPersonalHomePageLayout:closePersonalHomePage(true)
                GUIBedWarHallChatLayout:hide()
                GUIBedWarHallChatLayout:show(Define.ChatTabType.Friend, self.curUserId)
            else
                ---加好友
                local msg = Lang:getString("gui_friend_request_default_msg")
                GUICustomInputContentLayout:setTipText(Lang:getString("gui_add_friend_msg_text"))
                GUICustomInputContentLayout:setDefaultContentText(msg)
                GUICustomInputContentLayout:setContentChangeListener(function(content)
                    msg = content
                end)
                CustomDialog.builder()
                            .setTitleText("gui_add_friend_msg_title")
                            .setContentView(GUICustomInputContentLayout)
                            .setRightClickListener(function()
                    FriendManager.FriendOperation(Define.FriendOperationType.Request, self.curUserId, msg)
                    UIHelper.showToast(Lang:getString("gui.send.success"))
                end)        .show()
            end
        end
    end)

    self.btnFollow:registerEvent(GUIEvent.ButtonClick, function()
        if Game:getPlatformUserId() ~= self.curUserId then
            local curUserInfo = UserInfoCache:GetCache(self.curUserId)
            if curUserInfo and curUserInfo.followStatus ~= nil then
                if curUserInfo.followStatus == Define.FollowStatus.None or curUserInfo.followStatus == Define.FollowStatus.Fan then
                    WebService:FollowOtherPlayer(self.curUserId, function(code, data)
                        self:showPersonalInfo()
                        Events.PlayerFollowEvent:invoke(self.curUserId, Define.FollowOperationType.Follow)
                    end)
                else
                    CustomDialog.builder()
                                .setTitleText("gui_dialog_tip_title_tip")
                                .setContentText(Lang:getString("gui.personal.popularity.cancel"))
                                .setRightText("gui_dialog_tip_btn_sure")
                                .setLeftText("gui_dialog_tip_btn_cancel")
                                .setRightClickListener(function()
                        WebService:CancelFollowOtherPlayer(self.curUserId, function(code, data)
                            self:showPersonalInfo()
                            Events.PlayerFollowEvent:invoke(self.curUserId, Define.FollowOperationType.CancelFollow)
                        end)
                    end)
                                .show()
                end
            end
        end
    end)

    self.siHot:registerEvent(GUIEvent.Click, function()
        PopUpWindows.builder()
                    .setTitleText("gui.personal.popularity.title")
                    .setContentView(PopularityValueContentLayout)
                    .show()
        PopularityValueContentLayout:setData(UserInfoCache:GetCache(self.curUserId))
    end)

    self.stHotCount:registerEvent(GUIEvent.Click, function()
        PopUpWindows.builder()
                    .setTitleText("gui.personal.popularity.title")
                    .setContentView(PopularityValueContentLayout)
                    .show()
        PopularityValueContentLayout:setData(UserInfoCache:GetCache(self.curUserId))
    end)

    self.llVisitors:registerEvent(GUIEvent.Click, function()
        PopUpWindows.builder()
                    .setTitleText("gui.personal.visitors.title")
                    .setContentView(VisitorsListContentLayout)
                    .show()
        VisitorsListContentLayout:setData(UserInfoCache:GetCache(self.curUserId))
    end)

    self.siLike:registerEvent(GUIEvent.Click, function()
        if Game:getPlatformUserId() ~= self.curUserId then
            local level = self.level or 1
            if level < 5 then
                UIHelper.showToast(Lang:getString("gui.personal.popularity.level"))
                return
            end
            WebService:GivePlayerPageLike(self.curUserId, function(code)
                ---播一个特效
                if code == 17001 then
                    UIHelper.showToast(Lang:getString("gui.personal.popularity.limit"))
                elseif code == 17002 then
                    UIHelper.showToast(Lang:getString("gui.personal.popularity.once"))
                elseif code == 1 then
                    WebService:GetPlayerPageLikeCount(self.curUserId, function(code, data)
                        self:showPersonalInfo()
                        CommonPacketSender:sendReportPopularRank(self.curUserId)
                    end)
                end
            end)
        end
    end)

    local awSlide = self:getChildWindowByName("PersonalHomePlayerInfo-Slide", GUIType.ActorWindow)
    awSlide:registerEvent(GUIEvent.TouchDown, function(events)
        self.winActor:setTouchDown(events.position)
        self.awPet1:TouchDown(events.position)
        self.awPet2:TouchDown(events.position)
    end)
    awSlide:registerEvent(GUIEvent.TouchMove, function(events)
        self.winActor:setTouchMove(events.position)
        self.awPet1:TouchMove(events.position)
        self.awPet2:TouchMove(events.position)
    end)

    self.llHead:registerEvent(GUIEvent.Click, function()
        if self.curUserId == Game:getPlatformUserId() and GameType == "g1046" then
            GUIBedWarPictureFrameShopLayout:show()
        end
    end)

    self:registerDataCallBack("LevelInfo", function(data)
        self:onMeLevelInfoUpdate(data)
    end, DataBuilderProcessor)
    
    self.llTitle:registerEvent(GUIEvent.Click, function()
        if self.curUserId == Game:getPlatformUserId() and GameType == "g1046" then
            GUIPersonalTitleLayout:show()
        end
    end)

    self:registerEvent(Events.PersonalTitleUpdateUseTitleEvent, function(titleId)
        if self.curUserId == Game:getPlatformUserId() then
            if titleId then
                self.showTitleItem:onDataChanged(titleId)
                self.stNoTitle:SetVisible(false)
            else
                self.showTitleItem:onDataChanged(nil)
                self.stNoTitle:SetVisible(true)
            end
        end
    end)

    self:registerEvent(Events.PersonalTitleUpdateTaskEvent, function()
        if self.curUserId == Game:getPlatformUserId() then
            self.siTitleRedDot:SetVisible(CPersonalTitleHelper:hasRedDot())
        end
    end)
end

---@param userId number
function GUIPersonalHomePlayerInfoWindow:setShowPlayerUserId(userId)
    if not userId then
        return
    end
    self.curUserId = userId
    local userInfo = UserInfoCache:GetCache(userId)
    if not userInfo then
        return
    end
    PlayerManager:getClientPlayer():sendPacket({ pid = "searchPlayerLevelInfo" })

    -- 引擎关于 ArmorHeadNoFaceMap 有bug, 原来的逻辑是最后才根据配置设置 GUICustomShop:useBodyPart("custom_face", "")
    -- 后来被改成了根据穿戴的装备去覆盖预览的装备
    -- 某些 actorWindow需要, 某些actorWindow不需要
    if not next(ArmorHeadNoFaceMap) then
        ArmorHeadNoFaceMap = TableUtil.copyTable(PlayerManager:getClientPlayer().ArmorHeadNoFaceMap)
    end
    if not userInfo.pageLike then
        WebService:GetPlayerPageLikeCount(userId, function(code, data)
            self:showPersonalInfo()
        end)
    end

    if not userInfo.fansNum then
        WebService:GetFollowPlayerCount(userId, function(code, data)
            self:showPersonalInfo()
        end)
    end

    if self.curUserId ~= Game:getPlatformUserId() then
        self.btnAddFriend:SetVisible(true)
        if userInfo.friend then
            self.btnAddFriend:SetText(Lang:getString("gui.personal.btn.chat"))
        else
            self.btnAddFriend:SetText(Lang:getString("gui.personal.btn.addFriend"))
        end

        self.pbExp:SetVisible(false)
        self.btnFollow:SetVisible(true)
        if userInfo.followStatus then
            if userInfo.followStatus == Define.FollowStatus.Follow or userInfo.followStatus == Define.FollowStatus.EachFollow then
                self.btnFollow:SetText(Lang:getString("gui.personal.btn.followed"))
            else
                self.btnFollow:SetText(Lang:getString("gui.personal.btn.follow"))
            end
        else
            self:updateFollowStatus()
        end
        self.llVisitors:SetVisible(false)
    else
        self.pbExp:SetVisible(true)
        self.btnAddFriend:SetVisible(false)
        self.btnFollow:SetVisible(false)

        if not userInfo.visitorInfos then
            local getVisitorList = function(code, data)
                local visitorIds = {}
                for _, visitor in pairs(data.visitorInfos) do
                    table.insert(visitorIds, visitor.visitorId)
                end
                UserInfoCache:GetCacheByUserIds(visitorIds, function()
                    self.llVisitors:SetVisible(true)
                    ---展示拜访者头像
                    local itemNum = 0
                    for _, visitor in pairs(data.visitorInfos) do
                        local visitorInfo = UserInfoCache:GetCache(visitor.visitorId)
                        if visitorInfo then
                            ---@type GUIBedWarHead
                            local headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
                            headItem:setArea({ 0, (50) * (itemNum) }, { 0, 0 }, { 0, 40 }, { 0, 40 })
                            headItem:setUserInfo(visitorInfo)
                            headItem:setCanOpenPersonalHome(false)
                            self.llVisitorsList:AddChildWindow(headItem.root)
                            itemNum = itemNum + 1
                            if itemNum >= 3 then
                                break
                            end
                        end
                    end
                end)
            end
            WebService:getVisitorListInfo(userId, getVisitorList)
        else
            self.llVisitors:SetVisible(true)
        end
    end
    self:showPersonalInfo()
    self.winActor:updatePlayerShowInfo(userInfo)
end

function GUIPersonalHomePlayerInfoWindow:showPersonalInfo()
    local userInfo = UserInfoCache:GetCache(self.curUserId)
    self.siTitleRedDot:SetVisible(false)
    if self.curUserId == Game:getPlatformUserId() then
        self:onLevelInfoUpdate()
        self.siTitleRedDot:SetVisible(CPersonalTitleHelper:hasRedDot())
    end
    if userInfo.sex then
        --self.siSex:SetImage(Define.SexIcon[userInfo.sex])
        self.siSex:SetImage("")
    end
    if userInfo.qualifyingData then
        self.siRankIcon:SetImage(QualifyingTool.getQualifyingSegmentSmallIcon(userInfo.qualifyingData.segment))
        self.stRankName:SetText(QualifyingTool.getQualifyingSegmentBaseName(userInfo.qualifyingData.segment))
    else
        self.siRankIcon:SetImage(QualifyingTool.getQualifyingSegmentSmallIcon(1))
        self.stRankName:SetText(QualifyingTool.getQualifyingSegmentBaseName(1))
    end
    if userInfo.maxSegment or userInfo.qualifyingData then
        local maxSegment = userInfo.maxSegment or 1
        local curSegment = userInfo.qualifyingData and userInfo.qualifyingData.segment or 1
        self.siMaxRankIcon:SetImage(QualifyingTool.getQualifyingSegmentIcon(math.max(maxSegment, curSegment)))
        self.stMaxRankName:SetText(QualifyingTool.getQualifyingSegmentBaseName(math.max(maxSegment, curSegment)))
    else
        self.siMaxRankIcon:SetImage(QualifyingTool.getQualifyingSegmentIcon(1))
        self.stMaxRankName:SetText(QualifyingTool.getQualifyingSegmentBaseName(1))
    end

    self.awPet1:SetVisible(false)
    self.awPet2:SetVisible(false)
    if userInfo.pet ~= 0 then
        local curPetsStr = userInfo.currentPets
        local curPets = StringUtil.split(curPetsStr, ",", false, true)
        for index, id in pairs(curPets) do
            local goods = CustomShopConfig:getGoodsConfig(id)
            if goods then
                local pet = CustomShopPet.Settings[tostring(goods.SettingId)]
                if pet then
                    local win = index == 1 and self.awPet1 or self.awPet2
                    win:SetActor1(pet.ActorName, "idle", 0)
                    win:SetWidth({ pet.scale, 0 })
                    win:SetVisible(true)
                end
            end
        end
    end

    --if userInfo.valuableDress then
    --    local dress = StringUtil.split(userInfo.valuableDress, "#")
    --    self.dressAdapter:setData(dress)
    --else
    --    self.dressAdapter:clearItems()
    --end
    if not userInfo.vip or userInfo.vip == 0 then
        self.siVip:SetVisible(false)
    else
        self.siVip:SetVisible(true)
        self.siVip:SetImage(Define.VipIcon[userInfo.vip])
    end

    if userInfo.followStatus == Define.FollowStatus.Follow or userInfo.followStatus == Define.FollowStatus.EachFollow then
        self.btnFollow:SetText(Lang:getString("gui.personal.btn.followed"))
    else
        self.btnFollow:SetText(Lang:getString("gui.personal.btn.follow"))
    end

    self.headItem:setUserInfo(userInfo)
    self.headItem:setCanOpenPersonalHome(false)
    self.stLv:SetText("Lv." .. (userInfo.playerLevel or 1))
    self.stName:SetText(userInfo.name)
    local country = userInfo.country and CGame.Instance():getShellInterface():getCountryDetail(userInfo.country) or Lang:getString("gui_unknown_country")
    self.stCountry:SetText(country)
    self.stLikeCount:SetText(userInfo.pageLike or 0)
    --self.stHotCount:SetText((userInfo.pageLike or 0) + (userInfo.fansNum or 0) + 100)

    recordList[1].count = userInfo.totalGameTimes or 0
    recordList[2].count = userInfo.friendCount or 0
    recordList[3].count = (userInfo.pageLike or 0) + (userInfo.fansNum or 0) + 100 -- userInfo.battleLikeCount or 0
    recordList[4].count = userInfo.fansNum or 0

    local creditConfig = CreditScoreConfig:getCfgByCreditScore(userInfo.creditScore or 100)
    recordList[5].count = creditConfig.level or 0
    recordList[6].count = (tonumber(userInfo.playDays) or 1)
    recordList[7].count = userInfo.runeLevel or 0
    recordList[8].count = userInfo.totalRankTimes or 0
    recordList[9].count = userInfo.dressCount or 0
    local totalFunTimes = math.max(0, (userInfo.totalGameTimes or 0) - (userInfo.totalRankTimes or 0))
    recordList[10].count = totalFunTimes

    if userInfo.currTitle and userInfo.currTitle ~= -1 then
        self.showTitleItem:onDataChanged(userInfo.currTitle)
        self.stNoTitle:SetVisible(false)
    else
        self.showTitleItem:onDataChanged(nil)
        self.stNoTitle:SetVisible(true)
    end

    self.recordAdapter:setData(recordList)
end

function GUIPersonalHomePlayerInfoWindow:updateFollowStatus()
    WebService:EnquiryFollowRelations(Game:getPlatformUserId(), { self.curUserId }, function(code, data)
        WebService:GetFollowPlayerCount(self.curUserId, function(code, data)
            self:showPersonalInfo()
        end)
    end)
end

function GUIPersonalHomePlayerInfoWindow:onMeLevelInfoUpdate(data)
    local level = data:getNumberParam("level")
    local curExp = data:getNumberParam("curExp")
    local maxExp = data:getNumberParam("maxExp")
    local isMax = data:getBoolParam("isMax")
    self.level = level
    self.curExp = curExp
    self.maxExp = maxExp
    self.isMaxExp = isMax


    local userInfo = UserInfoCache:GetCache(Game:getPlatformUserId())
    if userInfo then
        userInfo.playerLevel = level
    end

    if self.curUserId == Game:getPlatformUserId() then
        self:onLevelInfoUpdate()
    end
end

function GUIPersonalHomePlayerInfoWindow:onLevelInfoUpdate()
    local curExp = self.curExp or nil
    local maxExp = self.maxExp or nil
    local isMax = self.isMaxExp or nil

    if not curExp then
        self.stExp:SetVisible(false)
        return
    end

    self.stLv:SetText("Lv." .. (self.level or 1))

    if not isMax then
        if maxExp > 0 then
            local expTxt = string.format("%d/%d", curExp, maxExp)
            self.stExp:SetVisible(true)
            self.stExp:SetText(expTxt)
            self.pbExp:SetProgress(curExp / maxExp)
        else
            self.stExp:SetVisible(false)
            self.pbExp:SetProgress(0)
        end
    else
        self.stExp:SetVisible(true)
        self.stExp:SetText("MAX")
        self.pbExp:SetProgress(0)
    end
end

return GUIPersonalHomePlayerInfoWindow
