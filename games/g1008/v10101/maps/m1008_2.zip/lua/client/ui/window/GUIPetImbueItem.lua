---@class GUIPetImbueItemWindow : IGUIWindow
local GUIPetImbueItemWindow = class("GUIPetImbueItemWindow", IGUIWindow)
---@private
function GUIPetImbueItemWindow:ctor(...)
	self.super.ctor(self, "PetImbueItem.json", ...)
end

---@private
function GUIPetImbueItemWindow:onLoad()
	self.cdCache = {}
	self.timesCache = {}
	self.needCheckEnemyDistance = {}
	self.needShowEffect = {}
	self.siIcon = self:getChildWindowByName("PetImbueItem-Icon", GUIType.StaticImage)
	self.siEffect = self:getChildWindowByName("PetImbueItem-Effect", GUIType.StaticImage)
	self.siMask = self:getChildWindowByName("PetImbueItem-Mask", GUIType.StaticImage)
	self.stTimes = self:getChildWindowByName("PetImbueItem-Times", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIPetImbueItemWindow:initView()
	self.siMask:SetVisible(false)
	self.stTimes:SetVisible(false)
	self.siEffect:SetVisible(false)
end

---@private
function GUIPetImbueItemWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		self:showPetImbueInfo()
	end)

	self:registerEvent(Events.UpdateImbueCd, function(imbueId, cd, className, showEffect)
		if not self.imbueId then
			self.cdCache[imbueId] = cd
			self.needShowEffect[imbueId] = showEffect
		end
		if className and self.className == className then
			self:updateCd(cd, showEffect)
			return
		end
		if self.imbueId and self.imbueId == imbueId then
			self:updateCd(cd, showEffect)
		end
	end)

	self:registerEvent(Events.UpdateImbueTimes, function(imbueId, times, className, hideMask)
		if not self.imbueId then
			self.timesCache[imbueId] = {
				times = times,
				hideMask = hideMask
			}
			if className then
				self.timesCache[className] = {
					times = times,
					hideMask = hideMask
				}
			end
		end
		if className and self.className == className then
			self:updateTimes(times, hideMask)
			return
		end
		if self.imbueId and self.imbueId == imbueId then
			self:updateTimes(times, hideMask)
		end
	end)

	self:registerEvent(Events.CheckEnemyDistance, function(imbueId, distance, isCheck)
		if not self.imbueId then
			self.needCheckEnemyDistance[imbueId] = distance
		end
		if self.imbueId and self.imbueId == imbueId then
			self:setCheckEnemyDistance(distance, isCheck)
		end
	end)
end

---@param config PetLvItemConfig
function GUIPetImbueItemWindow:onDataChanged(config)
	if self.imbueId and self.imbueId == config.imbueId then
		return
	end
	self.config = config
	self.imbueId = config.imbueId
	self.className = tostring(config.imbueType)
	self.siIcon:SetImage(config.icon)
	self:setInitDisplayState()
	self:cancelTimer()
	if self.cdCache[self.imbueId] then
		self:updateCd(self.cdCache[self.imbueId], self.needShowEffect[self.imbueId])
		self.cdCache = {}
		self.needShowEffect = {}
	end
	if self.timesCache[self.imbueId] then
		if self.timesCache[self.className] then
			self:updateTimes(self.timesCache[self.className].times, self.timesCache[self.className].hideMask)
		else
			self:updateTimes(self.timesCache[self.imbueId].times, self.timesCache[self.imbueId].hideMask)
		end
		self.timesCache = {}
	end
	if self.needCheckEnemyDistance[self.imbueId] then
		self:setCheckEnemyDistance(self.needCheckEnemyDistance[self.imbueId], true)
		self.needCheckEnemyDistance = {}
	end
end

function GUIPetImbueItemWindow:setInitDisplayState()
	self.stTimes:SetVisible(false)
	if tonumber(self.className) == Define.ImbueType.AngryImbue or tonumber(self.className) == Define.ImbueType.RevengeImbue then
		self.siMask:SetProperty("StretchOffset", "0 0 0 0")
		self.siMask:SetVisible(true)
	else
		self.siMask:SetVisible(false)
	end
end

function GUIPetImbueItemWindow:updateCd(cd, showEffect)
	self:cancelTimer()
	if cd == -1 then
		self.siMask:SetProperty("StretchOffset", "0 0 0 0")
		self.siMask:SetVisible(true)
		self.siEffect:SetVisible(false)
		return
	end
	local times = cd * 1000 / 100
	local gap = 360 / times
	self.curAngle = 0
	self.siMask:SetProperty("StretchOffset", "0 0 0 0")
	self.siMask:SetVisible(true)
	self.siEffect:SetVisible(showEffect)
	self:addTimer(LuaTimer:scheduleTimerWithEnd(function()
		self.curAngle = self.curAngle + gap
		self.siMask:SetProperty("StretchOffset", self.curAngle .. " 0 0 0")
		if self.curAngle >= 360 then
			self.siMask:SetVisible(false)
		end
	end, function()
		self.siMask:SetVisible(false)
	end, 100, times))
end

function GUIPetImbueItemWindow:updateTimes(times, hideMask)
	self.stTimes:SetText(tostring(times))
	self.stTimes:SetVisible(true)
	if times <= 0 then
		self:cancelTimer()
		self.siMask:SetProperty("StretchOffset", "0 0 0 0")
		self.siMask:SetVisible(true)
		self.siEffect:SetVisible(false)
	else
		self.siMask:SetVisible(not hideMask)
	end
end

function GUIPetImbueItemWindow:setCheckEnemyDistance(distance, isCheck)
	self:cancelTimer()
	if not isCheck then
		self.stTimes:SetVisible(false)
		self.siMask:SetProperty("StretchOffset", "0 0 0 0")
		self.siMask:SetVisible(true)
		return
	end
	self.stTimes:SetVisible(true)
	self.siMask:SetVisible(false)
	self:addTimer(LuaTimer:scheduleTimer(function()
		if isGameStart then
			local player = PlayerManager:getClientPlayer()
			local dis = player:getClosestPlayer(distance)
			if dis and dis > 0 then
				self.stTimes:SetText(tostring(dis))
			else
				self.stTimes:SetText("")
			end
		end
	end, 1000, -1))
end

function GUIPetImbueItemWindow:showPetImbueInfo()
	local data = {}
	if not self.config or not self.config.desc then
		return
	end
	data.text = self.config.desc
	if self.config.petName then
		data.text = self.config.petName .. ":" .. (self.config.desc or "")
	end
	Events.ReceiveGameBottomTipMsgEvent:invoke({data = data})
end

return GUIPetImbueItemWindow
