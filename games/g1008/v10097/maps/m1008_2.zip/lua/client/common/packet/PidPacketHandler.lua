---@type CPacketHandlers
local handler = T(Global, "PacketHandlers")
---@type WeakGuideControl
local WeakGuideControl = T(Global, "WeakGuideControl")
---@type HeadFrameShopConfig
local HeadFrameShopConfig = T(Global, "HeadFrameShopConfig")

-----------------common-----------------
function handler:CurSelectMap(packet)
    T(Global, "CurSelectMap", packet.selectMap)
    Events.SyncSelectMapEvent:invoke(packet.selectMap)
end

-----------------game---------------
function handler:AlarmWarning(packet)
    GUIMain:upScreenEffect(tonumber(packet.time))
    GUIBedWarGameTip:showGameTip(Lang:getString("prop.alarm.tip.warning"))
end

function handler:AlarmDisappear(packet)
    GUIBedWarGameTip:showGameTip(Lang:getString("prop.alarm.tip.disappear"))
end

function handler:ShowGameTip(packet)
    GUIBedWarGameTip:showGameTip(Lang:getString(packet.lang))
end

function handler:StartSinging(packet)
    GUIPlayerInfo:startSinging(packet.time or 1)
    GUIPlayerInfo:setSingingIcon(packet.icon or Define.SingingIcon.Teleport)
end

function handler:BreakSinging(packet)
    GUIPlayerInfo:breakSinging()
end

function handler:resetHollowBlock(packet)
    PlayerManager:getClientPlayer():resetHollowBlock()
end

function handler:MountHurt(packet)
    local entityId = EntityCache:getClientId(tonumber(packet.entityId))
    local function setOnHurt(isHurting)
        local entity = EntityCache:getEntity(entityId)
        if not entity then
            return
        end
        entity.entity:setHurting(isHurting)
    end
    setOnHurt(true)
    LuaTimer:schedule(function()
        setOnHurt(false)
    end, 300)
end

function handler:UpdateItemCd(packet)
    GUIPlayerInventory:UpdateItemCd(packet.itemId, packet.totalTime, packet.curTime or packet.totalTime)
end

function handler:CloseSlotCDLoop(packet)
    GUIPlayerInventory:closeSlotCD(packet.slot)
end

function handler:UpdateSlotCDLoop(packet)
    local totalTime = math.tointeger(packet.totalTime)
    local slot = packet.slot
    local curTime = math.tointeger(packet.curTime)
    GUIPlayerInventory:updateSlotCD(slot, totalTime, curTime)
end

function handler:NegativeGameTip(packet)
    CustomDialog.builder()
                .setContentText(Lang:getString("gui.tip.afk.warning"))
                .setLeftText("gui.cancel")
                .setRightText("gui.sure")
                .show()
end

function handler:S2CDialog(packet)
    CustomDialog.builder()
                .setTitleText(Lang:getString(packet.title))
                .setContentText(Lang:getString(packet.content))
                .setRightText(Lang:getString(packet.sureButtonTxt))
                .show()
end

function handler:SyncStartGameTime(packet)
    WeakGuideControl:initGuideData(packet.startGameTime)
end

function handler:onPlaceBlockInBedBuildPos(packet)
    WeakGuideControl.isCheckBedBuild = true
end

function handler:ResetItemSkillCd(packet)
    ---@type gui_mainControl
    local guiMainControl = DynamicCastHelper.dynamicCastGuiMainControl(RootGuiLayout.Instance():getLayout(0))
    if gui_mainControl.resetSkillCd and guiMainControl then
        guiMainControl:resetSkillCd(packet.itemId)
    end
end


function handler:ShowGetDragonEggRewardTips(packet)
    local itemId = packet.itemId
    local itemCount = packet.itemCount
    local item = Item.getItemById(itemId)
    local itemName
    if item then
        local name = item:getUnlocalizedName() .. ".name"
        itemName = Lang:getString(name)
        if itemName == name then
            name = "item." .. string.gsub(item:getUnlocalizedName(), "item.", "") .. ".name"
            itemName = Lang:getString(name)
        end
    end
    MsgSender.sendTopTips(5, Lang:getString("DrongonEggConfig.RewardTips")..itemName.." X"..tostring(itemCount))
end

-----------------hall---------------

function handler:showCreditScoreHeadFrame(packet)
    local config = HeadFrameShopConfig:getShopConfigById(packet.frameId)
    if not config then
        return
    end
    local reward = RewardConfig.findRewardById(config.RewardId)
    if not reward then
        return
    end
    GUIChallengeRewardReceive:init({
        name = reward.ShowDetail.name,
        image = reward.ShowDetail.image
    }, function()

    end, "CreditScore_RewardReceive_title", "CreditScore_RewardReceive_tip")
end

-----------------common---------------
function handler:PropPacketData(packet)
    GUIPropPacket:refreshUI(packet.data)
    local player = PlayerManager:getClientPlayer()
    player.Player.m_handMeshChanged = true
end

function handler:InitPlayerLevel(packet)
    GUIManager:setLockQueueTick(false)
    ClientHelper.putIntPrefs("PlayerLevel", packet.playerLevel)
end

function handler:CheckMoneyTip(packet)
    packet.type = packet.type or 1
    packet.price = packet.price or 0
    PayHelper.checkMoney(packet.type, packet.price, function()

    end)
end

function handler:showOldRankScore(packet)
    UIHelper.showToast("段位=" .. (packet.segment or 0) .. "积分=" .. (packet.integral or 0))
end

function handler:ScoreActivityTaskUpdate(packet)
    Events.ScoreActivityTaskUpdateEvent:invoke(packet.activityId, packet.taskId, packet.progress, packet.status)
end

function handler:BedWarPlayerMotion(packet)
    local player = Game:getPlayer()
    player.motion = packet.motion
    player.fallDistance = 0
end

function handler:PlayerFishingSuccess(packet)
    local data = {
        Count = packet.count,
        ShowDetail = {
            image = packet.icon,
            bg = packet.isRare and "set:game_activity.json image:img_0_grade_yellow" or "set:game_activity.json image:img_0_grade_blue"
        }
    }
    GUIRewardResult:onShowRewardsTip({ data }, false)
end

function handler:GameActivityShowReward(packet)
    if GameType == "g1046" and packet.rewards and #packet.rewards == 1 then
        local reward = RewardConfig:getRewardById(packet.rewards[1].rewardId) or PluginMainActivity:getRewardById(packet.rewards[1].rewardId)
        if reward.type == "RewardSetting" then
            reward = RewardConfig:getRewardById(reward.realId)
        end
        if reward and ((reward.RewardType == Define.RewardType.RUNE or reward.type == "Rune") or
                (reward.RewardType == Define.RewardType.CUSTOM_SHOP or reward.type == "CustomShop") or
                (reward.RewardType == Define.RewardType.CustomGoodsTicket)) then
            GameActivityShowReward.builder()
                                  .setRewardView(packet.rewards)
                                  .setRightButton("common.activity.sure")
                                  .setLeftButton("common.activity.use")
                                  .setLeftClickListener(function()
                if (reward.RewardType == Define.RewardType.RUNE or reward.type == "Rune") then
                    GUIBedWarRuneLayout:show()
                elseif (reward.RewardType == Define.RewardType.CUSTOM_SHOP or reward.type == "CustomShop") then
                    if reward.RewardType == Define.RewardType.CUSTOM_SHOP then
                        GUICustomShop:openCustomShopByGoodsId(reward.RewardId)
                    elseif reward.type == "CustomShop" then
                        GUICustomShop:openCustomShopByGoodsId(reward.realId)
                    end
                elseif (reward.RewardType == Define.RewardType.CustomGoodsTicket) then
                    GUICustomShop:show(true)
                    GUICustomGoodsTicketBagLayout:show()
                end
            end)
                                  .show()
            return
        end
    end
    GameActivityShowReward.builder()
                          .setRewardView(packet.rewards)
                          .setHideLeftButton()
                          .setRightButton("common.activity.sure")
                          .setAlwaysOnTop(true)
                          .show()
end

function handler:CompensatePacketItem(packet)
    CustomDialog.builder()
                .setExtraInfo("set:bedwaritem.json image:heiyaoshi", Lang:getString("CommodityMechant_name_4_47") .. "x" .. packet.count)
                .setContentText(Lang:getString("compensate.obsidian.tip"))
                .setCloseVisible(true)
                .setHideLeftButton()
                .setHideRightButton()
                .show()
end

function handler:SyncLicensePageTime(packet)
    ---@type CGameLicense
    local CGameLicense = T(Global, "CGameLicense")
    CGameLicense:updateLicensePageTime(packet.time)
end

function handler:TurntableActivityTaskUpdate(packet)
    Events.TurntableActivityTaskUpdateEvent:invoke(packet.activityId, packet.taskId, packet.progress, packet.status)
end

function handler:showInvertoryCdProgress(packet)
    local invertory = packet.invertoryId
    local cdTime = packet.hatchTime

end

function handler:SyncData(packet)
    local player = PlayerManager:getClientPlayer()
    player[packet.key] = packet.value
    if packet.key == "storeDataMap" then
        ClientStore:freeTimeGoodsRedDot()
    end
end

function handler:GameActivityAceMinerStartAnimation(packet)
    Events.UpdateAceMinerActivityAnimation:invoke(packet.start)
end

function handler:LuckyExchangeRefresh()
    Events.LuckyExchangeResult:invoke()
end

function handler:syncCustomGameSetting(packet)
    local player = PlayerManager:getClientPlayer()
    player.customGameSetting = packet.data
    Blockman.Instance().m_gameSettings:setCollimatorMode(player.customGameSetting.collimator)
end

function handler:popCollimatorSelectUI()
    local ui = UIHelper.newGameGUILayout("GUICollimatorSelectContent")
    ui:show()
end

return handler