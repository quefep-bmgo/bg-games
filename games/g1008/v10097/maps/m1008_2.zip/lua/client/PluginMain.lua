require "common.BedWarClient"

if Platform.isWindow() then
    require "PCKeyboard"
end

---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
    GameInfoManager.Instance()
    if BaseMain:getGameType() == "g1046" then
        require "hall.BedWarClient"
    elseif BaseMain:getGameType() == "g1063" then
        require "guide.BedWarClient"
    elseif BaseMain:getGameType() == "g1064" then
        require "survival.BedWarClient"
    else
        require "game.BedWarClient"
    end
    registerMoneyIcon(Define.Money.DIAMOND, "set:bed_war_3_icon.json image:img_0_magic_cube")
    registerMoneyIcon(Define.Money.CHIP, "set:dress_shop.json image:chip")
    registerMoneyIcon(Define.Money.KEY, "set:app_shop.json image:bedwar_key")
    registerMoneyIcon(Define.Money.HORN, "set:icon_haojiao.json image:haojiao")
    registerMoneyIcon(Define.Money.TICKET, "set:free_gift.json image:movie_ticket_icon")
    registerMoneyIcon(Define.Money.COMMON_CHIP, "set:bed_war_3_icon.json image:img_0_fragments")
    registerMoneyIcon(Define.Money.GameCashCoupon, "set:bed_war_3_icon.json image:img_currency_coupon_big")
    for _, coinId in pairs(Define.Money) do
        PlayerWallet:setMoneyCount(coinId, 0)
    end
    BedWarClient.onGameInit()
    local deviation = 3 -- 辉光的宽度
    local intensity = 2.6 --- 辉光的强度
    local saturation = 1.0 --  辉光颜色对场景的影响 (0-1.0)
    Blockman.Instance():setBlockBloomOption(deviation, intensity, saturation)
    -- 起床因为一些特殊原因禁掉了场景辉光，方块辉光不受影响
    Blockman.Instance():setBloomEnable(false)
    ClientHelper.putStringPrefs("RechargeGameType", "g1008")
    ClientHelper.putBoolPrefs("IsShowItemDurability", true)
    ClientHelper.putBoolPrefs("DisableRenderClouds", true)
    ClientHelper.putBoolPrefs("DisableFog", true)

    local oldRecharge = ClientHelper.onRecharge
    function ClientHelper.onRecharge(type, reportKey)
        ReportEvent.recharge_open(reportKey or "sum_recharge")
        PlayerManager:getClientPlayer():sendPacket({
            pid = "RechargeReport",
            reportKey = reportKey
        })
        oldRecharge(type)
    end
    if GameType == "g1046" then
        local key = Game:getPlatformUserId() .. "g1008_UI_First_Hide"
        local cache = ClientHelper.getStringForKey(key)
        print("--------------GameInitEvent---------------", cache)
        T(Global, "IndieFirstHideUIRecord", StringUtil.split(cache, "#"))
    end

    ---@type RecorderUtil
    local RecorderUtil = T(Global, "RecorderUtil")
    local whiteList
    if GameType == "g1046" then
        whiteList = {
            "ItemSkillMain"
        }
    else
        whiteList = {
            "Main-ItemBarBg",
            "Main-VisibleBar",
            "Main-MoveState",
            "Main-Gun-Operate",
            "PropPacket",
            "SurvivalPacket",
            "SurvivalMain-Plugins-UnRiding",
            "ItemSkillMain",
            "ModuleBlockMain",
        }
    end
    RecorderUtil:addHideUiWhiteList({ "BedWarCustomDialog" })
    RecorderUtil:addHideUiWhiteList(whiteList)
    RecorderUtil:addAlphaToZeroUiList(whiteList)
end)

BaseListener.registerCallBack(CEvents.ShowSettingMenuEvent, function()
    if GUIBedWarSetting then
        GUIBedWarSetting:show()
    end
    return false
end)

--- 临时接口
local oldGetSkillTimeLength = ActorObject.GetSkillTimeLength

local function newGetSkillTimeLength(actor, skillName, actorName)
    if not actorName or not skillName then
        return oldGetSkillTimeLength(actor, skillName)
    end
    --local name = string.gsub(self.__name, ".actor", "")
    if not Define.ACTOR_SKILL_TIME_MAP then
        return oldGetSkillTimeLength(actor, skillName)
    end
    local key = actorName..":"..skillName
    local timeLength = Define.ACTOR_SKILL_TIME_MAP[key]
    if not timeLength then
        timeLength =  oldGetSkillTimeLength(actor, skillName)
        if timeLength > 0 then
            Define.ACTOR_SKILL_TIME_MAP[key] = timeLength
        end
        return timeLength
    end
    return timeLength
end

ActorObject.GetSkillTimeLength = newGetSkillTimeLength