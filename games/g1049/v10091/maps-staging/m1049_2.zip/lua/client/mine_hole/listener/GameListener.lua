local function hideEngineWindow(name)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetXPosition({ 0, 6000 })
    window:SetVisible(false)
end

GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
end

function GameListener.onGameReady()
    GameConfig:init()
    require "ui.GUISkyBlockItemDetail"
    require "ui.GUISkyBlockMoneyDetail"
    require "ui.GUITipDialog"

    if GUISumRechargeLayout ~= nil then
        GUISumRechargeLayout:setRewardWidth(77)
    end
    ClientHelper.putStringPrefs("RechargeGameType", "g1048")
end

return GameListener
