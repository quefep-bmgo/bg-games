---@class UIRandomShopLayout : IGUILayout
local UIRandomShopLayout = class("UIRandomShopLayout", IGUILayout)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")
---@type RandomShopConfig
local RandomShopConfig = T(Global, "RandomShopConfig")

---@private
function UIRandomShopLayout:ctor(parent)
    self.super.ctor(self, "RandomShop.json", parent)
end

---@private
function UIRandomShopLayout:isDelayLoad()
    return true
end

---@private
function UIRandomShopLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIRandomShopLayout:initCreateEvent()

end

---@private
function UIRandomShopLayout:isShowAnim()
    return false
end

---@private
function UIRandomShopLayout:onLoad()
    self.stTitleText = self:getChildWindow("RandomShop-TitleText", GUIType.StaticText)
    self.siClose = self:getChildWindow("RandomShop-Close", GUIType.StaticImage)
    self.stRefresh = self:getChildWindow("RandomShop-Refresh", GUIType.StaticText)
    self.siRefreshIcon = self:getChildWindow("RandomShop-RefreshIcon", GUIType.StaticImage)
    self.stTimeText = self:getChildWindow("RandomShop-TimeText", GUIType.StaticText)
    self.siImage = self:getChildWindow("RandomShop-Image", GUIType.StaticImage)
    self.awActor = self:getChildWindow("RandomShop-Actor", GUIType.ActorWindow)
    self.stName = self:getChildWindow("RandomShop-Name", GUIType.StaticText)
    self.stDesc = self:getChildWindow("RandomShop-Desc", GUIType.StaticText)
    self.llGoods = self:getChildWindow("RandomShop-Goods", GUIType.Layout)
    self.btnShopBuy = self:getChildWindow("RandomShop-ShopBuy", GUIType.Button)
    self.siPriceIcon = self:getChildWindow("RandomShop-PriceIcon", GUIType.StaticImage)
    self.stPriceText = self:getChildWindow("RandomShop-PriceText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIRandomShopLayout:initView()
    self.randomShop = PlayerManager:getClientPlayer().randomShop
    self.stTitleText:SetText(Lang:getString("gui.task.chain.shop.title"))
    self.stRefresh:SetText(Lang:getString("gui.task.chain.refresh"))
    self.stRefresh:SetWidth({ 0, self.stRefresh:GetTextWidth() })
    self.btnShopBuy:SetText(Lang:getString("gui.task.chain.shop.buy"))
    ---@type GUICurrencyGroupWindow
    self.wCurrencyGroup = UIHelper.newGameGUIWindow("GUICurrencyGroup")
    self.root:AddChildWindow(self.wCurrencyGroup.root)
    self:initShopItemList()
end

---@private
function UIRandomShopLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        self:hide()
        SoundUtil.clickUI()
    end)
    self.btnShopBuy:registerEvent(GUIEvent.ButtonClick, function()
        if self.curShopItem then
            self.randomShop:tryBuyShopItem(self.shopId, self.curShopItem.id, 1)
        end
    end)
    self.stRefresh:registerEvent(GUIEvent.Click, function()
        self.randomShop:tryRefreshShop(self.shopId)
    end)
    self.siRefreshIcon:registerEvent(GUIEvent.Click, function()
        self.randomShop:tryRefreshShop(self.shopId)
    end)
end

---@private
function UIRandomShopLayout:initShopItemList()
    self.gvShopItemList = IGUIGridView.new("RandomShop-ShopItems", self.llGoods)
    self.gvShopItemList:setConfig(11, 11, 4)
    self.gvShopItemList:setArea({ 0, 11 }, { 0, 11 }, { 1, -22 }, { 1, -22 })
    ---@type RandomShopItemAdapter
    self.shopItemAdapter = UIHelper.newGameAdapter("RandomShopItemAdapter")
    self.gvShopItemList:setAdapter(self.shopItemAdapter)
end

---@private
function UIRandomShopLayout:onTick()
    self.wCurrencyGroup:onTick()
    self:updateRefreshTime()
end

function UIRandomShopLayout:updateRefreshTime()
    local curTime = os.time()
    local tag = math.floor(curTime / self.shop.refreshTime)
    local endTime = (tag + 1) * self.shop.refreshTime
    self.stTimeText:SetText(DateUtil.getFormatTime(endTime - curTime))
end

function UIRandomShopLayout:show(shopId)
    self.shopId = tonumber(shopId)
    self.shop = RandomShopConfig:getCfgById(self.shopId)
    if not self.shop then
        return
    end
    RootGuiLayout.Instance():hideAllChildren()
    self.super.show(self, self.shopId)
    self:updateList()
    self.wCurrencyGroup:onDataChanged({ self.shop.refreshPriceType, CurrencyId.Diamonds }, nil, 15)
end

---@private
function UIRandomShopLayout:onHide()
    RootGuiLayout.Instance():showMainControl()
end

---@param data RandomShopItemConfigData
function UIRandomShopLayout:showShopItemDetail(data)
    if data.limit > 0 then
        self.btnShopBuy:SetEnabled(self.randomShop:getShopBuyTimes(self.shopId, data.id) < data.limit)
    else
        self.btnShopBuy:SetEnabled(true)
    end
    if self.curShopItem == data then
        return
    end
    self.curShopItem = data
    RewardConfig:setRewardDetailUI(data.reward, self.siImage, self.stName, self.stDesc, self.awActor)
    self.siPriceIcon:SetHexagonImage("", "")
    self.siPriceIcon:SetRenderAsBlock(false)
    if type(data.priceType) == "number" then
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
    else
        GuiItemStack.showItemIcon(self.siPriceIcon, data.priceType[1], data.priceType[2], "")
    end
    self.stPriceText:SetText(data.price)
    self:updateList()
end

---@private
function UIRandomShopLayout:updateList()
    local cfgs = self.randomShop:getShopItemCfgs(self.shopId)
    if not TableUtil.tableContain(cfgs, self.curShopItem) then
        self.curShopItem = nil
    end
    if self.curShopItem then
        self:showShopItemDetail(self.curShopItem)
    elseif cfgs[1] then
        self:showShopItemDetail(cfgs[1])
    end
    self.shopItemAdapter:setData(cfgs)
end

return UIRandomShopLayout
