---@class UIHalloweenShopLayout : IGUILayout
local UIHalloweenShopLayout = class("UIHalloweenShopLayout", IGUILayout)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")
---@type RandomShopConfig
local RandomShopConfig = T(Global, "RandomShopConfig")

---@private
function UIHalloweenShopLayout:ctor(parent)
    self.super.ctor(self, "HalloweenShop.json", parent)
end

---@private
function UIHalloweenShopLayout:isDelayLoad()
    return true
end

---@private
function UIHalloweenShopLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIHalloweenShopLayout:initCreateEvent()

end

---@private
function UIHalloweenShopLayout:isShowAnim()
    return false
end

---@private
function UIHalloweenShopLayout:onLoad()
    self.siClose = self:getChildWindow("HalloweenShop-Close", GUIType.StaticImage)
    self.stRefresh = self:getChildWindow("HalloweenShop-Refresh", GUIType.StaticText)
    self.siRefreshIcon = self:getChildWindow("HalloweenShop-RefreshIcon", GUIType.StaticImage)
    self.stTimeText = self:getChildWindow("HalloweenShop-TimeText", GUIType.StaticText)
    self.siImage = self:getChildWindow("HalloweenShop-Image", GUIType.StaticImage)
    self.awActor = self:getChildWindow("HalloweenShop-Actor", GUIType.ActorWindow)
    self.stName = self:getChildWindow("HalloweenShop-Name", GUIType.StaticText)
    self.stDesc = self:getChildWindow("HalloweenShop-Desc", GUIType.StaticText)
    self.llGoods = self:getChildWindow("HalloweenShop-Goods", GUIType.Layout)
    self.btnShopBuy = self:getChildWindow("HalloweenShop-ShopBuy", GUIType.Button)
    self.siPriceIcon = self:getChildWindow("HalloweenShop-PriceIcon", GUIType.StaticImage)
    self.stPriceText = self:getChildWindow("HalloweenShop-PriceText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIHalloweenShopLayout:initView()
    self.randomShop = PlayerManager:getClientPlayer().randomShop
    self.stRefresh:SetText(Lang:getString("gui.task.chain.refresh"))
    self.stRefresh:SetWidth({ 0, self.stRefresh:GetTextWidth() })
    self.btnShopBuy:SetText(Lang:getString("gui.task.chain.shop.buy"))
    ---@type GUICurrencyGroupWindow
    self.wCurrencyGroup = UIHelper.newGameGUIWindow("GUICurrencyGroup")
    self.root:AddChildWindow(self.wCurrencyGroup.root)
    self:initShopItemList()
end

---@private
function UIHalloweenShopLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        self:hide()
        SoundUtil.clickUI()
    end)
    self.btnShopBuy:registerEvent(GUIEvent.ButtonClick, function()
        if self.curShopItem then
            self.randomShop:tryBuyShopItem(self.shopId, self.curShopItem.id, 1, "GUIHalloweenShop")
        end
    end)
    self.stRefresh:registerEvent(GUIEvent.Click, function()
        self.randomShop:tryRefreshShop(self.shopId)
    end)

    self.siRefreshIcon:registerEvent(GUIEvent.Click, function()
        self.randomShop:tryRefreshShop(self.shopId)
    end)
end

---@private
function UIHalloweenShopLayout:initShopItemList()
    self.gvShopItemList = IGUIGridView.new("HalloweenShop-ShopItems", self.llGoods)
    self.gvShopItemList:setConfig(11, 11, 4)
    self.gvShopItemList:setArea({ 0, 11 }, { 0, 11 }, { 1, -22 }, { 1, -22 })
    ---@type RandomShopItemAdapter
    self.shopItemAdapter = UIHelper.newGameAdapter("RandomShopItemAdapter", "GUIHalloweenShop")
    self.gvShopItemList:setAdapter(self.shopItemAdapter)
end

---@private
function UIHalloweenShopLayout:onTick()
    self.wCurrencyGroup:onTick()
    self:updateRefreshTime()
end

function UIHalloweenShopLayout:updateRefreshTime()
    local curTime = os.time()
    local tag = math.floor(curTime / self.shop.refreshTime)
    local endTime = (tag + 1) * self.shop.refreshTime
    self.stTimeText:SetText(DateUtil.getFormatTime(endTime - curTime))
end

function UIHalloweenShopLayout:show(shopId)
    self.shopId = tonumber(shopId)
    self.shop = RandomShopConfig:getCfgById(self.shopId)
    if not self.shop then
        return
    end
    RootGuiLayout.Instance():hideAllChildren()
    self.super.show(self, self.shopId)
    self:updateList()
    self.wCurrencyGroup:onDataChanged({ self.shop.refreshPriceType, CurrencyId.Diamonds }, nil, 15)
end

---@private
function UIHalloweenShopLayout:onHide()
    RootGuiLayout.Instance():showMainControl()
end

---@param data RandomShopItemConfigData
function UIHalloweenShopLayout:showShopItemDetail(data)
    if data.limit > 0 then
        self.btnShopBuy:SetEnabled(self.randomShop:getShopBuyTimes(self.shopId, data.id) < data.limit)
    else
        self.btnShopBuy:SetEnabled(true)
    end
    if self.curShopItem == data then
        return
    end
    self.curShopItem = data
    RewardConfig:setRewardDetailUI(data.reward, self.siImage, self.stName, self.stDesc, self.awActor)
    self.siPriceIcon:SetHexagonImage("", "")
    self.siPriceIcon:SetRenderAsBlock(false)
    if type(data.priceType) == "number" then
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
    else
        GuiItemStack.showItemIcon(self.siPriceIcon, data.priceType[1], data.priceType[2], "")
    end
    self.stPriceText:SetText(data.price)
    self:updateList()
end

---@private
function UIHalloweenShopLayout:updateList()
    local cfgs = self.randomShop:getShopItemCfgs(self.shopId)
    if not TableUtil.tableContain(cfgs, self.curShopItem) then
        self.curShopItem = nil
    end
    if self.curShopItem then
        self:showShopItemDetail(self.curShopItem)
    elseif cfgs[1] then
        self:showShopItemDetail(cfgs[1])
    end
    self.shopItemAdapter:setData(cfgs)
end

return UIHalloweenShopLayout
