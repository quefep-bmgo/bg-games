---@class GUIRandomShopItemWindow : IGUIWindow
local GUIRandomShopItemWindow = class("GUIRandomShopItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUIRandomShopItemWindow:ctor(_, guiName)
    self.super.ctor(self, "RandomShopItem.json")
    self.guiName = guiName
    self.guiRandomShop = UIHelper.newGameGUILayout(guiName)
end

---@private
function GUIRandomShopItemWindow:onLoad()
    self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.siSelected = self:getChildWindowByName("RandomShopItem-Selected", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("RandomShopItem-Icon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("RandomShopItem-Limit", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIRandomShopItemWindow:initView()
    self.randomShop = PlayerManager:getClientPlayer().randomShop
end

---@private
function GUIRandomShopItemWindow:initEvent()
    self.llRoot:registerEvent(GUIEvent.Click, function()
        self.guiRandomShop:showShopItemDetail(self.data)
    end)
end

---@private
function GUIRandomShopItemWindow:getBuyTimes()
    return self.randomShop:getShopBuyTimes(self.data.shopId, self.data.id)
end

---@param data RandomShopItemConfigData
function GUIRandomShopItemWindow:onDataChanged(data)
    self.data = data
    local reward = data.reward
    RewardConfig:setRewardQuality(self.llRoot, reward, true)
    RewardConfig:setRewardImage(self.siIcon, reward)
    self.stLimit:SetVisible(data.limit > 0)
    local times = self:getBuyTimes()
    if times >= data.limit then
        self.stLimit:SetText(TextFormat.colorRed .. times .. "/" .. data.limit)
    else
        self.stLimit:SetText(times .. "/" .. data.limit)
    end
    self.siSelected:SetVisible(self.guiRandomShop.curShopItem == self.data)
end

return GUIRandomShopItemWindow
