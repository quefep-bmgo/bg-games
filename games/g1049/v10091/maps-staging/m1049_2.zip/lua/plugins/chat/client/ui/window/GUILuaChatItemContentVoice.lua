---@class GUILuaChatItemContentVoiceWindow : IGUIWindow
local GUILuaChatItemContentVoiceWindow = class("GUILuaChatItemContentVoiceWindow", IGUIWindow)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")

---@private
function GUILuaChatItemContentVoiceWindow:ctor(...)
	self.super.ctor(self, "LuaChatItemContentVoice.json", ...)
end

---@private
function GUILuaChatItemContentVoiceWindow:onLoad()
	self.siArrow = self:getChildWindowByName("LuaChatItemContentVoice-Arrow", GUIType.StaticImage)
	self.siVoice = self:getChildWindowByName("LuaChatItemContentVoice-Voice", GUIType.StaticImage)
	self:initEvent()
end

---@private
function GUILuaChatItemContentVoiceWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		self:playVoice()
	end)
end

---@param data ChatMsgData
function GUILuaChatItemContentVoiceWindow:onDataChanged(data)
	self.data = data
	if data.sendId == Game:getPlatformUserId() then
		self.siArrow:SetXPosition({ 1, 0 })
		self.siArrow:SetProperty("Rotate", 180)
		self.siVoice:SetProperty("Rotate", 180)
	end
end

function GUILuaChatItemContentVoiceWindow:playVoice()
	---播放语音消息
	local msgData = self.data.data
	if not msgData.uri then
		return
	end
	ChatClient:playVoice(msgData.uri)
end

return GUILuaChatItemContentVoiceWindow
