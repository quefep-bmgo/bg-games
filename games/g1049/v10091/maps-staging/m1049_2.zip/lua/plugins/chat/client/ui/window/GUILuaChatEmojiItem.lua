---@class GUILuaChatEmojiItemWindow : IGUIWindow
local GUILuaChatEmojiItemWindow = class("GUILuaChatEmojiItemWindow", IGUIWindow)

---@private
function GUILuaChatEmojiItemWindow:ctor(...)
	self.super.ctor(self, "LuaChatEmojiItem.json", ...)
end

---@private
function GUILuaChatEmojiItemWindow:onLoad()
	self:initView()
	self:initEvent()
end

---@private
function GUILuaChatEmojiItemWindow:initView()
	self.root = self:getChildWindowByName("LuaChatEmojiItem", GUIType.StaticImage)
end

---@private
function GUILuaChatEmojiItemWindow:initEvent()
	self.root:registerEvent(GUIEvent.Click, function()
		---发表情
		local GUILuaChat = UIHelper.newGameGUILayout("GUILuaChat")
		GUILuaChat:sendGameEmojiMsg(self.data.icon)
	end)
end

---@param data EmojiData
function GUILuaChatEmojiItemWindow:onDataChanged(data)
	self.data = data
	self.root:SetImage(data.icon)
end

return GUILuaChatEmojiItemWindow
