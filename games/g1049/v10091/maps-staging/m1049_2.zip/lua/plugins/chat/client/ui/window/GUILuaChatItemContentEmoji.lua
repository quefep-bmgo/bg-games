---@class GUILuaChatItemContentEmojiWindow : IGUIWindow
local GUILuaChatItemContentEmojiWindow = class("GUILuaChatItemContentEmojiWindow", IGUIWindow)

---@private
function GUILuaChatItemContentEmojiWindow:ctor(...)
    self.super.ctor(self, "LuaChatItemContentEmoji.json", ...)
end

---@private
function GUILuaChatItemContentEmojiWindow:onLoad()
    self.siImage = DynamicCast.dynamicCastWindow(GUIType.StaticImage, self.root)
end

---@param data ChatMsgData
function GUILuaChatItemContentEmojiWindow:onDataChanged(data)
    if data.sendId == Game:getPlatformUserId() then
        self.siImage:SetXPosition({ 0, -18 })
    end
    self.siImage:SetImage(data.data.content.emojiData)
end

return GUILuaChatItemContentEmojiWindow
