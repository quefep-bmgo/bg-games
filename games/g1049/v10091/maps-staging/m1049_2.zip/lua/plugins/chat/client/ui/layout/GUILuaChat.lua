---@class UILuaChatLayout : IGUILayout
local UILuaChatLayout = class("UILuaChatLayout", IGUILayout)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")
---@type MessageService
local MessageService = T(Global, "MessageService")
---@type EmojiConfig
local EmojiConfig = T(Global, "EmojiConfig")
---@type number 好友聊天消息单页数量
local PageSize = 5
---@type RadioBoxGroup
local RadioBoxGroup = Plugins.Require("common", "client.ui.RadioBoxGroup")

local ChatTabText = {
    [Define.ChatTabType.Lang] = "",
    [Define.ChatTabType.Common] = "gui_chat_tab_text_common",
    [Define.ChatTabType.SameServer] = "gui_chat_tab_text_same_server",
    [Define.ChatTabType.Friend] = "gui_chat_tab_text_friend",
}

local ChatTabRedDotType = {
    [Define.ChatTabType.Lang] = Define.RedDotKey.ChatMsgTab .. "lang",
    [Define.ChatTabType.Common] = Define.RedDotKey.ChatMsgTab .. "group",
    [Define.ChatTabType.SameServer] = Define.RedDotKey.ChatMsgTab .. "same_server",
    [Define.ChatTabType.Friend] = Define.RedDotKey.ChatMsgTab .. "friend",
}

---@private
function UILuaChatLayout:ctor(parent)
    self.super.ctor(self, "LuaChat.json", parent)
end

---@private
function UILuaChatLayout:isDelayLoad()
    return true
end

---@private
function UILuaChatLayout:onCreate()
    self.curChatId = nil
    self.curChatFriendId = nil
    self.newMsgCount = {}
    self.tabMsgCount = {}
    self.friendIndex = {}
    self.loveData = {}
    ---@type gui_mainControl
    self.mainControl = DynamicCastHelper.dynamicCastGuiMainControl(RootGuiLayout.Instance():getLayout(0))
    for _, key in pairs(ChatTabRedDotType) do
        Plugins.CallTargetPluginFunc("red_dot", "registerDynamicWithKey", key, Define.RedDotKey.ChatNewMsg, 0)
    end
    self:initCreateEvent()
    ---加入聊天室
    local language = Lang:getLang()
    local name = StringUtil.split(language, "_")[1]
    name = ClientHelper.getStringForKey("g1048_ChatLangGroup", name)
    local lang_list = Global.setting.lang_list
    for _, lang in pairs(lang_list) do
        if lang.name == name then
            MessageService:sendJoinInLangGroup(lang.name)
            return
        end
    end
    MessageService:sendJoinInLangGroup(lang_list[1].name)
end

---@private
function UILuaChatLayout:initCreateEvent()
    ---@param data ChatMsgData
    self:registerEvent(Events.ReceiveChatMsgEvent, function(chatId, data)
        if type(chatId) == "number" then
            local userIds = Plugins.CallTargetPluginFunc("friend", "getFriends")
            if not TableUtil.tableContain(userIds, chatId) then
                table.insert(userIds, chatId)
            end
            self:updateFriendListIndex(chatId)
        end
        if self:isShow() then
            if self.curChatId ~= chatId then
                self:addNewMsgCount(chatId)
            else
                self:addChatMsg(data)
            end
        else
            self:addNewMsgCount(chatId)
        end
        if chatId == "same_server" then
            self.mainControl:addChatMessage(ChatClient:chatMsgToString(data, TextFormat.colorWrite), false)
            ---@type CBasePlayer
            local player = PlayerManager:getPlayerByUserId(data.sendId)
            if player then
                player:setChatSayMsg(data)
            end
        end
    end)
end

---@private
function UILuaChatLayout:onLoad()
    self.curChatId = nil
    self.curChatFriendId = nil
    self.newMsgCount = {}
    self.tabMsgCount = {}
    self.friendIndex = {}

    self.lhTabList = self:getChildWindow("LuaChat-Tab-List", GUIType.ListHorizontal)
    self.llClose = self:getChildWindow("LuaChat-Close", GUIType.Layout)
    self.llCenter = self:getChildWindow("LuaChat-Center", GUIType.Layout)
    self.llContent = self:getChildWindow("LuaChat-Content", GUIType.Layout)
    self.btnBackBtn = self:getChildWindow("LuaChat-Back-Btn", GUIType.Button)

    ---语言选择列表
    self.llLangListClose = self:getChildWindow("LuaChat-LangListClose", GUIType.Layout)
    self.siLangListBg = self:getChildWindow("LuaChat-LangListBg", GUIType.StaticImage)
    self.ltLangList = self:getChildWindow("LuaChat-LangList", GUIType.List)

    ---输入框
    self.siBottom = self:getChildWindow("LuaChat-Bottom", GUIType.StaticImage)
    self.etInput = self:getChildWindow("LuaChat-Input", GUIType.Edit)
    self.btnEmojiBtn = self:getChildWindow("LuaChat-Emoji-Btn", GUIType.Button)
    self.siVoiceBtn = self:getChildWindow("LuaChat-Voice-Btn", GUIType.StaticImage)
    self.btnSendBtn = self:getChildWindow("LuaChat-Send-Btn", GUIType.Button)
    self.stSendBtnText = self:getChildWindow("LuaChat-Send-Btn-Text", GUIType.StaticText)

    ---聊天
    self.stPlayerNum = self:getChildWindow("LuaChat-Player-Num", GUIType.StaticText)
    self.llPlayerList = self:getChildWindow("LuaChat-Player-List", GUIType.Layout)
    self.llChatView = self:getChildWindow("LuaChat-Chat-View", GUIType.Layout)
    self.stChatName = self:getChildWindow("LuaChat-Chat-Name", GUIType.StaticText)
    self.stChatTip = self:getChildWindow("LuaChat-Chat-Tip", GUIType.StaticText)
    self.btnChatDelete = self:getChildWindow("LuaChat-Chat-Delete", GUIType.Button)
    self.llChatMsgList = self:getChildWindow("LuaChat-Chat-Msg-List", GUIType.Layout)
    self.stNoSelectFriend = self:getChildWindow("LuaChat-No-Select-Friend", GUIType.StaticText)
    self.btnGoToBottomBtn = self:getChildWindow("LuaChat-GoToBottom-Btn", GUIType.Button)
    self.stGoToBottomBtnText = self:getChildWindow("LuaChat-GoToBottom-Btn-Text", GUIType.StaticText)
    self.llEmoji = self:getChildWindow("LuaChat-Emoji", GUIType.Layout)
    self.llEmojiContentClose = self:getChildWindow("LuaChat-Emoji-Content-Close", GUIType.Layout)
    self.llEmojiOutClose = self:getChildWindow("LuaChat-Emoji-Out-Close", GUIType.Layout)

    ---玩家信息
    self.llPlayerInfo = self:getChildWindow("LuaChat-Player-Info", GUIType.Layout)
    self.stNameText = self:getChildWindow("LuaChat-Name-Text", GUIType.StaticText)
    self.stClanNameText = self:getChildWindow("LuaChat-Clan-Name-Text", GUIType.StaticText)
    self.stClanText = self:getChildWindow("LuaChat-Clan-Text", GUIType.StaticText)
    self.stRoleNameText = self:getChildWindow("LuaChat-Role-Name-Text", GUIType.StaticText)
    self.stRoleText = self:getChildWindow("LuaChat-Role-Text", GUIType.StaticText)
    self.btnAddFriendBtn = self:getChildWindow("LuaChat-Add-Friend-Btn", GUIType.Button)
    self.stAddFriendBtnText = self:getChildWindow("LuaChat-Add-Friend-Btn-Text", GUIType.StaticText)
    self.btnReportBtn = self:getChildWindow("LuaChat-Report-Btn", GUIType.Button)

    ---语音
    self.llVoice = self:getChildWindow("LuaChat-Voice-View", GUIType.Layout)
    self.llVoiceTip = self:getChildWindow("LuaChat-Voice-Tip", GUIType.Layout)
    self.siVoiceTipIcon = self:getChildWindow("LuaChat-Voice-Tip-Icon", GUIType.StaticImage)
    self.stVoiceTipText = self:getChildWindow("LuaChat-Voice-Tip-Text", GUIType.StaticText)

    self.llNoFriendTip = self:getChildWindow("LuaChat-No-Friend-Tip", GUIType.Layout)
    self.stNoFriendTipText = self:getChildWindow("LuaChat-No-Friend-Tip-Text", GUIType.StaticText)

    self.btnFriendRefresh = self:getChildWindow("LuaChat-Friend-Refresh", GUIType.Button)

    self:initView()
    self:initEvent()

end

---@private
function UILuaChatLayout:initView()
    self.stSendBtnText:SetText(Lang:getString("gui_chat_send_btn_text"))
    self.stGoToBottomBtnText:SetText(Lang:getString("gui_chat_go_to_bottom_btn_text"))
    self.stClanNameText:SetText(Lang:getString("gui_chat_clan_text"))
    self.stRoleNameText:SetText(Lang:getString("gui_chat_role_text"))
    self.stAddFriendBtnText:SetText(Lang:getString("gui_chat_add_friend_btn_text"))
    self.stNoSelectFriend:SetText(Lang:getString("gui_chat_no_select_friend_text"))
    self.stChatTip:SetText(Lang:getString("gui_chat_friend_chat_tip_text"))
    self.stNoFriendTipText:SetText(Lang:getString("gui.no.friend.tip"))
    self.btnReportBtn:SetText(Lang:getString("gui_chat_report_btn_text"))
    self.stChatName:SetText("")
    self.etInput:SetMaxLength(200)
    self.llPlayerInfo:SetVisible((false))
    self.btnGoToBottomBtn:SetVisible(false)
    self.ltLangList:SetInterval(8)
    self.btnBackBtn:SetVisible(false)

    self:initTabs()
    self:initContent()
    self:initLangList()
    self:initEmoji()
    self:showVoiceView(false)
    self:showEmojiView(false)
end

---@private
function UILuaChatLayout:initEvent()
    self.btnEmojiBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:showEmojiView(not self.llEmoji:IsVisible())
    end)

    self.siVoiceBtn:registerEvent(GUIEvent.TouchDown, function()
        if self.selectTab ~= Define.ChatTabType.Friend or self.curChatFriendId == 0 then
            return
        end
        ---开始录音
        self.isWaitingSend = true
        self:showVoiceView(true)
        ChatClient:startRecordVoice(self.curChatFriendId)
    end)

    self.siVoiceBtn:registerEvent(GUIEvent.TouchMove, function()
        ---发送提示
        self.stVoiceTipText:SetText(Lang:getString("gui_chat_release_to_send"))
    end)

    self.siVoiceBtn:registerEvent(GUIEvent.TouchUp, function()
        if self.selectTab ~= Define.ChatTabType.Friend or self.curChatFriendId == 0 then
            return
        end
        ---发送语音
        self:showVoiceView(false)
        ChatClient:stopRecordVoice(self.curChatFriendId, false)
    end)

    self.llVoice:registerEvent(GUIEvent.TouchDown, function()
        if not self.isWaitingSend then
            self.leaveCancelArea = true
            return
        end
        self.isWaitingSend = false
        self.leaveCancelArea = false
        ---取消提示
        self.stVoiceTipText:SetText(Lang:getString("gui_chat_release_to_cancel"))
        self.siVoiceTipIcon:SetImage("set:chat.json image:img_0_cancel")
    end)

    self.llVoice:registerEvent(GUIEvent.TouchMove, function()
        self.isWaitingSend = false
        self.leaveCancelArea = false
        ---取消提示
        self.stVoiceTipText:SetText(Lang:getString("gui_chat_release_to_cancel"))
        self.siVoiceTipIcon:SetImage("set:chat.json image:img_0_cancel")
    end)

    self.llVoice:registerEvent(GUIEvent.Release, function()
        if self.leaveCancelArea then
            return
        end
        if self.selectTab ~= Define.ChatTabType.Friend or not self.curChatFriendId or self.curChatFriendId == 0 then
            return
        end
        ---取消发送
        self.leaveCancelArea = false
        self:showVoiceView(false)
        ChatClient:stopRecordVoice(self.curChatFriendId, true)
    end)

    self.btnSendBtn:registerEvent(GUIEvent.ButtonClick, function()
        if self.selectTab == Define.ChatTabType.Friend and self.curChatFriendId == 0 then
            return
        end
        self:sendTextMsg()
    end)

    self.btnGoToBottomBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:gotoBottom()
    end)

    --self.btnBackBtn:registerEvent(GUIEvent.ButtonClick, function()
    --    self:hide()
    --end)

    self.btnAddFriendBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:showPlayerInfo(false)
        if not self.userInfo or not self.userInfo.userId or self.userInfo.userId == 0 then
            return
        end
        Plugins.CallTargetPluginFunc("friend", "tryAddFriend", self.userInfo.userId)
    end)

    self.btnReportBtn:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui_chat_report_player_title")
                    .setContentText(Lang:getString("gui_chat_report_player_text"))
                    .setRightText("gui_dialog_tip_btn_sure")
                    .setLeftText("gui_dialog_tip_btn_cancel")
                    .setRightClickListener(function()
            self:showPlayerInfo(false)
            ---提示举报成功
            UIHelper.showToast(Lang:getString("gui.report.success"))
        end)
                    .show()
    end)

    self.btnChatDelete:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui_chat_clear_friend_chat_title")
                    .setContentText(Lang:getString("gui_chat_clear_friend_chat_text"))
                    .setRightText("gui_dialog_tip_btn_sure")
                    .setLeftText("gui_dialog_tip_btn_cancel")
                    .setRightClickListener(function()
            self.lvChatMsgList:clearItems()
            ChatClient:clearMsgCache(self.curChatId)
        end)
                    .show()
    end)

    self.etInput:registerEvent(GUIEvent.EditTextInput, function(args)
        self:updateInputHeight()
        if self.selectTab == Define.ChatTabType.Friend and self.curChatFriendId == 0 then
            return
        end
        if args.trigger == 0 then
            self:sendTextMsg()
        end
    end)

    self.llClose:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)

    self.llEmojiContentClose:registerEvent(GUIEvent.Click, function()
        self:showEmojiView(false)
    end)

    self.llEmojiOutClose:registerEvent(GUIEvent.Click, function()
        self:showEmojiView(false)
    end)

    self.btnFriendRefresh:registerEvent(GUIEvent.ButtonClick, function()
        Plugins.CallTargetPluginFunc("friend", "loadFriendData")
    end)

    self.llLangListClose:registerEvent(GUIEvent.Click, function()
        self.llLangListClose:SetVisible(not self.llLangListClose:IsVisible())
        self.siSelectLangArrow:SetImage(self.llLangListClose:IsVisible() and
                "set:chat.json image:tgl_0_hide" or "set:chat.json image:tgl_0_show")
    end)

    ---@param userId number
    self:registerEvent(Events.ChatSelectFriendEvent, function(userId)
        if self.curChatFriendId ~= userId then
            self.lastMsgId = nil
            self.curChatFriendId = userId
            self.lvChatMsgList:clearItems()
            self:updateFriendMsgList()
        end
    end)

    ---@param userInfo UserInfo
    self:registerEvent(Events.ChatShowPlayerInfoEvent, function(userInfo)
        self:showPlayerInfo(true, userInfo)
    end)

    self.llPlayerInfo:registerEvent(GUIEvent.Click, function()
        self:showPlayerInfo(false)
    end)

    self:registerDataCallBack("UpdateLoveNum", function(data)
        if not data then
            return
        end
        self.loveData[tostring(data.targetUserId)] = data.loveNum
        if not self.llPlayerInfo:IsVisible() or not data or not self.userInfo or data.targetUserId == self.userInfo.userId then
            return
        end
        self.stRoleText:SetText(data.loveNum)
    end, JsonBuilderProcessor)
end

---@private
function UILuaChatLayout:initTabs()
    ---@type GUIWindow[]
    self.chatTabs = {}
    local types = {}
    for _, type in pairs(Define.ChatTabType) do
        table.insert(types, type)
    end
    TableUtil.tableRemove(types, Define.ChatTabType.Clan)
    TableUtil.tableRemove(types, Define.ChatTabType.Common)
    if Platform.isPC() then
        TableUtil.tableRemove(types, Define.ChatTabType.Friend)
    end
    table.sort(types, function(a, b)
        return a < b
    end)
    for index, type in ipairs(types) do
        local tab = GUIManager:createGUIWindow(GUIType.CheckBox, "LuaChat-Chat-Tab-Btn-" .. type)
        if index ~= #types then
            local line = GUIManager:createGUIWindow(GUIType.StaticImage, "LuaChat-Chat-Tab-Line-" .. type)
            line:SetBackgroundColor({ 220 / 255, 230 / 255, 240 / 255, 1 })
            line:SetHorizontalAlignment(HorizontalAlignment.Right)
            line:SetVerticalAlignment(VerticalAlignment.Center)
            line:SetWidth({ 0, 2 })
            line:SetHeight({ 1, -12 })
            tab:AddChildWindow(line)
        end
        if type == Define.ChatTabType.Lang then
            self.siSelectLangArrow = GUIManager:createGUIWindow(GUIType.StaticImage, "LuaChat-Chat-Tab-Arrow-" .. type)
            self.siSelectLangArrow:SetArea({ 0, 8 }, { 0, 8 }, { 0, 29 }, { 0, 31 })
            self.siSelectLangArrow:SetImage("set:chat.json image:tgl_0_show")
            tab:AddChildWindow(self.siSelectLangArrow)

            self.stLangTabText = GUIManager:createGUIWindow(GUIType.StaticText, "LuaChat-Chat-Tab-Text-" .. type)
            self.stLangTabText:SetArea({ 0, 48 }, { 0, 0 }, { 0, 80 }, { 0, 32 })
            self.stLangTabText:SetTextVertAlign(VerticalAlignment.Center)
            self.stLangTabText:SetText(Lang:getString("gui_chat_tab_text_lang"))
            tab:AddChildWindow(self.stLangTabText)

            self.stLangTabName = GUIManager:createGUIWindow(GUIType.StaticText, "LuaChat-Chat-Tab-Name-" .. type)
            self.stLangTabName:SetArea({ 0, 48 }, { 0, 25 }, { 0, 80 }, { 0, 20 })
            self.stLangTabName:SetTextVertAlign(VerticalAlignment.Center)
            self.stLangTabName:SetProperty("Font", "HT12")
            tab:AddChildWindow(self.stLangTabName)

            self.btnOpenSelectLang = GUIManager:createGUIWindow(GUIType.Button, "LuaChat-Chat-Tab-Click-" .. type)
            self.btnOpenSelectLang:SetWidth({ 1, 0 })
            self.btnOpenSelectLang:SetHeight({ 1, 0 })
            self.btnOpenSelectLang:registerEvent(GUIEvent.ButtonClick, function()
                self.llLangListClose:SetVisible(not self.llLangListClose:IsVisible())
                self.siSelectLangArrow:SetImage(self.llLangListClose:IsVisible() and
                        "set:chat.json image:tgl_0_hide" or "set:chat.json image:tgl_0_show")
            end)
            tab:AddChildWindow(self.btnOpenSelectLang)
        end
        tab:SetText(Lang:getString(ChatTabText[type]))
        tab:SetTextColor(Define.TabTextColor.Normal)
        tab:SetPushedImage("set:chat.json image:btn_0_current02")
        tab:SetHeight({ 1, 0 })
        tab:SetWidth({ 0, 175 })
        tab:registerEvent(GUIEvent.CheckStateChanged, function()
            if not tab:GetChecked() then
                return
            end
            self:setTabSelect(type)
        end)
        self.lhTabList:AddItem(tab)
        self.chatTabs[type] = tab
        Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", tab, ChatTabRedDotType[type], Define.RedDotKey.ChatNewMsg,
                { offset = VectorUtil.newVector2(-5, 3),
                  isShowNumber = true,
                  customImage = "set:common.json image:img_0_red_dot" })
    end
end

---@private
function UILuaChatLayout:initContent()
    ---@type LuaChatFriendAdapter
    self.playerListAdapter = UIHelper.newGameAdapter("LuaChatFriendAdapter")
    self.lvPlayerList = IGUIListView.new("LuaChat-Chat-Player-List-View", self.llPlayerList)
    self.lvPlayerList:setAdapter(self.playerListAdapter)
    self.playerListAdapter:setBottomCall(function()
        if self.selectTab == Define.ChatTabType.Friend then
            Plugins.CallTargetPluginFunc("friend", "loadMoreFriend")
        end
    end)

    self.lvChatMsgList = IGUIGridView.new("LuaChat-Chat-Msg-List-View", self.llChatMsgList)
    self.lvChatMsgList:setConfig(0, 0, 1)
    self.lvChatMsgList.isScrollTop = false
    self.lvChatMsgList.root:EnableVirtualList()
    self.lvChatMsgList.root:registerEvent(GUIEvent.ScrollMoveChange, function()
        local offset = self.lvChatMsgList.root:GetScrollOffset()
        self.lvChatMsgList.isScrollTop = self.lvChatMsgList.isScrollTop or offset > 10
    end)
    self.lvChatMsgList.root:registerEvent(GUIEvent.ScrollMoveEnd, function()
        local offset = self.lvChatMsgList.root:GetScrollOffset()
        local minOffset = self.lvChatMsgList.root:GetMinScrollOffset()
        if offset <= minOffset then
            self.btnGoToBottomBtn:SetVisible(false)
        end
        if self.lvChatMsgList.isScrollTop and not self.isUpdating then
            self.lvChatMsgList.root:SetScrollOffset(0)
            self.isUpdating = true
            self:loadMoreChatMsg()
        end
        self.lvChatMsgList.isScrollTop = false
    end)
end

---@private
function UILuaChatLayout:initLangList()
    self.isFirstJoinLang = true
    local lang_list = Global.setting.lang_list
    local group = RadioBoxGroup.new()
    for index, lang in pairs(lang_list) do
        local tab = GUIManager:createGUIWindow(GUIType.CheckBox, "LuaChat-Lang-Select-Tab-" .. index)
        tab:SetArea({ 0, 0 }, { 0, 0 }, { 1, -4 }, { 0, 40 })
        tab:SetText(Lang:getString(lang.lang))
        tab:SetTextColor({ 128 / 255, 177 / 255, 207 / 255, 1 })
        tab:SetHorizontalAlignment(HorizontalAlignment.Center)
        group:addCheckBox(tab, function(select)
            if select then
                self.llLangListClose:SetVisible(false)
                self.siSelectLangArrow:SetImage("set:chat.json image:tgl_0_show")
                self.stLangTabName:SetText(Lang:getString(lang.lang))
                MessageService:sendJoinInLangGroup(lang.name)
                ClientHelper.putStringForKey("g1048_ChatLangGroup", lang.name)
                tab:SetTextColor(Define.TabTextColor.Select)
                tab:SetBackgroundColor({ 227 / 255, 233 / 255, 240 / 255, 1 })
                if self.isFirstJoinLang then
                    self.isFirstJoinLang = false
                else
                    UIHelper.showToast(Lang:getString("gui.change.chat.lang.success"))
                end
            else
                tab:SetTextColor({ 128 / 255, 177 / 255, 207 / 255, 1 })
                tab:SetBackgroundColor({ 0, 0, 0, 0 })
            end
        end)
        if index ~= #lang_list then
            local line = GUIManager:createGUIWindow(GUIType.Layout, "LuaChat-Lang-Select-Tab-Line-" .. index)
            line:SetArea({ 0, 0 }, { 1, 3 }, { 1, 4 }, { 0, 2 })
            line:SetHorizontalAlignment(HorizontalAlignment.Center)
            line:SetBackgroundColor({ 55 / 255, 66 / 255, 123 / 255, 1 })
            tab:AddChildWindow(line)
        end
        self.ltLangList:AddItem(tab)
    end
    self.siLangListBg:SetHeight({ 0, math.min(#lang_list * 48 + 6, 300) })
    local language = Lang:getLang()
    local name = StringUtil.split(language, "_")[1]
    name = ClientHelper.getStringForKey("g1048_ChatLangGroup", name)
    for index, lang in pairs(lang_list) do
        if lang.name == name then
            group:selectIndex(index)
            return
        end
    end
    group:selectIndex(1)
end

---@private
function UILuaChatLayout:initEmoji()
    self.gvEmojiList = IGUIGridView.new("LuaChat-Emoji-Grid", self.llEmoji)
    self.gvEmojiList:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    ---@type LuaChatEmojiAdapter
    self.emojiAdapter = UIHelper.newGameAdapter("LuaChatEmojiAdapter")
    self.gvEmojiList:setConfig(0, 0, 7)
    local itemWidth = self.gvEmojiList:getWidth() / 7
    self.emojiAdapter:setItemSize(itemWidth, itemWidth)
    self.gvEmojiList:setAdapter(self.emojiAdapter)

    local cfg = EmojiConfig:getAllCfg()
    self.emojiAdapter:setData(cfg)
end

---@private
function UILuaChatLayout:updateFriendList()
    local userIds = Plugins.CallTargetPluginFunc("friend", "getFriends")
    local userInfoList = {}
    local online = 0

    for i = #self.friendIndex, 1, -1 do
        if not TableUtil.tableContain(userIds, self.friendIndex[i]) then
            table.remove(self.friendIndex, i)
        end
    end

    for _, userId in pairs(userIds) do
        if userId ~= Game:getPlatformUserId() and not TableUtil.include(self.friendIndex, userId) then
            local info = UserInfoCache:GetCache(userId)
            if info.status ~= Define.UserStatus.Offline then
                online = online + 1
            end
            table.insert(userInfoList, info)
        end
    end

    for _, userId in ipairs(self.friendIndex) do
        local info = UserInfoCache:GetCache(userId)
        if info.status ~= Define.UserStatus.Offline then
            online = online + 1
        end
        table.insert(userInfoList, 1, info)
    end

    self.llNoFriendTip:SetVisible(#userIds <= 0)
    local friendCount = Plugins.CallTargetPluginFunc("friend", "getTotalFriendCount")
    self.stPlayerNum:SetText(Lang:getString("gui.chat.friend") .. ": " .. online .. " / " .. friendCount)
    self.playerListAdapter:setData(userInfoList, true)
    if not TableUtil.tableContain(userIds, self.curChatFriendId) then
        self.curChatFriendId = 0
        self:updateFriendMsgList()
    end
end

---@private
---@param type number 标签类型
function UILuaChatLayout:setTabSelect(type)
    self.lastMsgId = nil
    self:showEmojiView(false)
    if self.selectTab and self.selectTab ~= 0 then
        local oldTab = self.chatTabs[self.selectTab]
        oldTab:SetProperty("Font", "HT16")
        oldTab:SetProperty("TextRenderOffset", "0 -2")
        oldTab:SetTextColor(Define.TabTextColor.Normal)
        if self.selectTab == Define.ChatTabType.Lang then
            self.stLangTabText:SetTextColor(Define.TabTextColor.Normal)
            self.stLangTabName:SetTextColor(Define.TabTextColor.Normal)
        end
    end
    local newTab = self.chatTabs[type]
    newTab:SetTextColor(Define.TabTextColor.Select)
    newTab:SetProperty("Font", "HT20")
    newTab:SetProperty("TextRenderOffset", "0 -5")
    self.selectTab = type
    if self.selectTab == Define.ChatTabType.Lang then
        self.stLangTabText:SetTextColor(Define.TabTextColor.Select)
        self.stLangTabName:SetTextColor(Define.TabTextColor.Select)
    end
    for tabType, tab in pairs(self.chatTabs) do
        tab:SetTouchable(tabType ~= self.selectTab)
        tab:SetChecked(tabType == self.selectTab)
    end

    self.llNoFriendTip:SetVisible(false)
    self.stNoSelectFriend:SetVisible(false)
    self.llNoFriendTip:SetVisible(false)
    self.lvChatMsgList:clearItems()
    self.btnFriendRefresh:SetVisible(false)
    self.llLangListClose:SetVisible(false)
    if self.siSelectLangArrow then
        self.siSelectLangArrow:SetImage("set:chat.json image:tgl_0_show")
    end
    if self.btnOpenSelectLang then
        self.btnOpenSelectLang:SetVisible(false)
    end
    if type == Define.ChatTabType.Common then
        self:showCommonChatContent()
    elseif type == Define.ChatTabType.Friend then
        self.btnFriendRefresh:SetVisible(true)
        self:showFriendChatContent()
    elseif type == Define.ChatTabType.Clan then
        self:showClanChatContent()
    elseif type == Define.ChatTabType.Lang then
        self:showLangChatContent()
    elseif type == Define.ChatTabType.SameServer then
        self:showSameServerChatContent()
    else
        self:showCommonChatContent()
    end
    self:gotoBottom()
end

---@private
function UILuaChatLayout:showCommonChatContent()
    self.curChatId = "group"
    self.btnChatDelete:SetVisible(false)
    self.stPlayerNum:SetVisible(false)
    self.llPlayerList:SetVisible(false)
    self.stChatName:SetVisible(false)
    self.llChatView:SetWidth({ 1, -30 })
    self.llChatMsgList:SetHeight({ 1, 0 })
    self:setVoiceButtonVisible(false)
    self:loadMoreChatMsg()
end

---@private
function UILuaChatLayout:showLangChatContent()
    self.curChatId = "lang"
    if self.btnOpenSelectLang then
        self.btnOpenSelectLang:SetVisible(true)
    end
    self.btnChatDelete:SetVisible(false)
    self.stPlayerNum:SetVisible(false)
    self.llPlayerList:SetVisible(false)
    self.stChatName:SetVisible(false)
    self.llChatView:SetWidth({ 1, -30 })
    self.llChatMsgList:SetHeight({ 1, 0 })
    self:setVoiceButtonVisible(false)
    self:loadMoreChatMsg()
end

---@private
function UILuaChatLayout:showFriendChatContent()
    self.btnChatDelete:SetVisible(true)
    self.stPlayerNum:SetVisible(true)
    self.llPlayerList:SetVisible(true)
    self.stChatName:SetVisible(true)
    self.stChatTip:SetVisible(true)
    self.llChatView:SetWidth({ 1, -230 })
    self.llChatMsgList:SetHeight({ 1, -102 })
    self:setVoiceButtonVisible(false)
    self:updateFriendList()
    self:updateFriendMsgList()
end

---@private
function UILuaChatLayout:updateFriendMsgList()
    self.curChatId = self.curChatFriendId
    self.stNoSelectFriend:SetVisible(self.curChatFriendId == 0)
    if self.curChatFriendId == 0 then
        self.lvChatMsgList:clearItems()
        self.stChatName:SetVisible(false)
        return
    end
    ---显示对应好友聊天信息
    local info = UserInfoCache:GetCache(self.curChatFriendId)
    local name = info and info.name or ""
    self.stChatName:SetVisible(true)
    self.stChatName:SetText(name)
    self:loadMoreChatMsg()
end

---@private
function UILuaChatLayout:showClanChatContent()

end

function UILuaChatLayout:showSameServerChatContent()
    self.curChatId = "same_server"
    self.btnChatDelete:SetVisible(false)
    self.stPlayerNum:SetVisible(false)
    self.llPlayerList:SetVisible(false)
    self.stChatName:SetVisible(false)
    self.llChatView:SetWidth({ 1, -30 })
    self.llChatMsgList:SetHeight({ 1, 0 })
    self:setVoiceButtonVisible(false)
    self:loadMoreChatMsg()
end

---@private
---@param isShow boolean 是否显示
---@param userInfo UserInfo    显示的玩家信息
function UILuaChatLayout:showPlayerInfo(isShow, userInfo)
    if userInfo and userInfo.userId == Game:getPlatformUserId() then
        return
    end
    self.llPlayerInfo:SetVisible(isShow)
    if not isShow then
        return
    end
    self.userInfo = userInfo
    self.stNameText:SetText(userInfo.name)
    self.stClanText:SetText("")
    self.stClanText:SetText(userInfo.clanName or Lang:getString("gui_no_clan_text"))
    local likeNum = self:getLoveNum(userInfo.userId)
    self.stRoleText:SetText(likeNum)
    local isFriend = Plugins.CallTargetPluginFunc("friend", "isFriend", userInfo.userId)
    self.stAddFriendBtnText:SetText(Lang:getString(isFriend and "gui_chat_already_friend" or "gui_chat_add_friend_btn_text"))
end

---@private
function UILuaChatLayout:loadMoreChatMsg()
    ChatClient:getPrivateMsgCache(self.curChatId, nil, function(msgList)
        local needGotoBottom = self.lastMsgId == nil
        if #msgList > 0 then
            self.lastMsgId = msgList[1].msgId
        end
        for i = #msgList, 1, -1 do
            self:addChatMsg(msgList[i], 1)
        end
        self.lvChatMsgList.root:SetScrollOffset(0)
        self.lvChatMsgList.isScrollTop = false
        self.isUpdating = false
        if needGotoBottom then
            self:gotoBottom()
        end
    end, self.lastMsgId, PageSize)
end

---@private
function UILuaChatLayout:sendTextMsg()
    local msg = self.etInput:GetText()
    local len = string.len(msg)
    if not msg or len < 1 or len > 200 then
        return
    end
    local result = false
    msg = FilterWord.getReplaceContent(msg)
    len = string.len(msg)
    local b = string.byte(msg, len)
    if b >= 128 and len >= 2 and string.byte(msg, len - 1) < 128 then
        msg = msg:sub(1, len - 1)
    end
    msg = string.gsub(msg, "%^FF", "")
    if self.selectTab == Define.ChatTabType.Common then
        result = ChatClient:sendTextMsgToGroup(msg)
    elseif self.selectTab == Define.ChatTabType.Friend and self.curChatFriendId ~= 0 then
        ChatClient:sendTextMsgToTarget(self.curChatFriendId, msg)
        result = true
    elseif self.selectTab == Define.ChatTabType.Lang then
        result = ChatClient:sendTextMsgToLangGroup(msg)
    elseif self.selectTab == Define.ChatTabType.SameServer then
        result = ChatClient:sendTextMsgToSameServer(msg)
    end
    if result then
        self.etInput:SetText("")
        self:updateInputHeight()
    end
end

function UILuaChatLayout:sendGameEmojiMsg(emoji)
    if self.selectTab == Define.ChatTabType.Common then
        ChatClient:sendGameEmojiMsgToGroup(emoji)
    elseif self.selectTab == Define.ChatTabType.Friend and self.curChatFriendId ~= 0 then
        ChatClient:sendGameEmojiMsgToTarget(self.curChatFriendId, emoji)
    elseif self.selectTab == Define.ChatTabType.Lang then
        ChatClient:sendGameEmojiMsgToLangGroup(emoji)
    elseif self.selectTab == Define.ChatTabType.SameServer then
        ChatClient:sendGameEmojiMsgToSameServer(emoji)
    end
    self:showEmojiView(false)
end

---@private
---@param msgData ChatMsgData
function UILuaChatLayout:addChatMsg(msgData, index)
    if msgData.type == Define.ChatMsgType.None then
        return
    end
    if self.lastMsgId == nil then
        self.lastMsgId = msgData.msgId
    end
    ---非当前界面处理
    ---@type GUILuaChatItemWindow
    local item = UIHelper.newGameGUIWindow("GUILuaChatItem", msgData)
    self.lvChatMsgList:addItem(item, nil, index)
    item:onDataChanged(msgData)

    local offset = self.lvChatMsgList.root:GetScrollOffset()
    local minOffset = self.lvChatMsgList.root:GetMinScrollOffset()
    if offset - minOffset > 20 and msgData.sendId ~= Game:getPlatformUserId() then
        if not index then
            self:addNewMsgCount(self.curChatId)
            self.btnGoToBottomBtn:SetVisible(true)
            self.stGoToBottomBtnText:SetText(self:getNewMsgCount(self.curChatId) .. Lang:getString("gui_chat_go_to_bottom_btn_text"))
        end
    else
        if not index then
            self:gotoBottom()
        end
    end
end

---@private
---@param tabType number|nil 页签类型，传空为上一次打开的页签
---@param userId number
function UILuaChatLayout:onShow(tabType, userId)
    tabType = tabType or self.selectTab
    if tabType == Define.ChatTabType.Friend and userId then
        self.curChatFriendId = userId
    end
    self.chatTabs[tabType]:SetChecked(false)
    self.chatTabs[tabType]:SetChecked(true)
    self:showPlayerInfo(false)
    self:initOpenEvent()
end

---@private
function UILuaChatLayout:onHide()
    self:showEmojiView(false)
    self:unregisterOpenEvent()
    local toolBar = UIHelper.newGameGUILayout("GUILuaToolBar")
    toolBar.cbChat:SetChecked(false)
end

---@private
function UILuaChatLayout:gotoBottom()
    LuaTimer:cancel(self.gotoBottomTimer)
    self.gotoBottomTimer = LuaTimer:schedule(function()
        local height = 0
        for _, item in pairs(self.lvChatMsgList.items) do
            height = height + item.root:GetPixelSize().y
        end
        self.lvChatMsgList.root:SetScrollOffset(math.min(self.lvChatMsgList.root:GetPixelSize().y - height, 0))
        self.btnGoToBottomBtn:SetVisible(false)
    end, 1)
    self:clearRedDot()
end

---@private
---@param isShow boolean 是否显示
function UILuaChatLayout:showVoiceView(isShow)
    self.llVoice:SetVisible(isShow)
    self.llVoiceTip:SetVisible(isShow)
    if isShow then
        self:showEmojiView(false)
        self.stVoiceTipText:SetText(Lang:getString("gui_chat_release_to_send"))
        self.siVoiceTipIcon:SetImage("set:chat.json image:img_0_mic")
    end
end

function UILuaChatLayout:getCurSelectFriend()
    return self.curChatFriendId or 0
end

---@private
function UILuaChatLayout:showEmojiView(isShow)
    self.llEmoji:SetVisible(isShow)
    self.llEmojiOutClose:SetVisible(isShow)
    self.llEmojiContentClose:SetVisible(isShow)
    if isShow then
        self.llChatView:SetHeight({ 0, self.llChatView:GetPixelSize().y - self.llEmoji:GetPixelSize().y })
    else
        self.llChatView:SetHeight({ 1, 0 })
    end
    if isShow then
        self:gotoBottom()
    end
end

function UILuaChatLayout:clearRedDot()
    local chatId = self.curChatId
    if type(chatId) == "number" then
        self.newMsgCount[chatId] = nil
        local totalCount = 0
        for _, count in pairs(self.newMsgCount) do
            totalCount = totalCount + count
        end
        chatId = "friend"
        self.tabMsgCount[chatId] = totalCount
        Events.ChatPrivateNewMsgEvent:invoke(self.curChatId, 0)
    else
        self.tabMsgCount[chatId] = 0
    end
    Plugins.CallTargetPluginFunc("red_dot", "resetRedDotState", Define.RedDotKey.ChatMsgTab .. chatId, self.tabMsgCount[chatId] or 0)
end

---@private
function UILuaChatLayout:addNewMsgCount(chatId)
    if type(chatId) == "number" then
        self.newMsgCount[chatId] = (self.newMsgCount[chatId] or 0) + 1
        Events.ChatPrivateNewMsgEvent:invoke(chatId, self.newMsgCount[chatId])
        local totalCount = 0
        for _, count in pairs(self.newMsgCount) do
            totalCount = totalCount + count
        end
        chatId = "friend"
        self.tabMsgCount[chatId] = totalCount
    else
        self.tabMsgCount[chatId] = (self.tabMsgCount[chatId] or 0) + 1
    end
    Plugins.CallTargetPluginFunc("red_dot", "resetRedDotState", Define.RedDotKey.ChatMsgTab .. chatId, self.tabMsgCount[chatId] or 0)
    if not self:isLoad() then
        return
    end
    if self.btnGoToBottomBtn:IsVisible() then
        self.stGoToBottomBtnText:SetText(self:getNewMsgCount(self.curChatId) .. Lang:getString("gui_chat_go_to_bottom_btn_text"))
    end
end

function UILuaChatLayout:getNewMsgCount(chatId)
    if type(chatId) == "string" then
        return self.tabMsgCount[chatId] or 0
    end
    return self.newMsgCount[chatId] or 0
end

---@private
function UILuaChatLayout:setVoiceButtonVisible(visible)
    self.siVoiceBtn:SetVisible(visible)
    self.btnEmojiBtn:SetXPosition({ visible and 0.67 or 0.76, 0 })
    self.etInput:SetWidth({ visible and 0.6 or 0.68, 0 })
end

function UILuaChatLayout:updateInputHeight()
    local height = math.max(self.etInput:GetTextHeight() - self.etInput:GetFont():GetFontHeight(), 0)
    self.etInput:SetHeight({ 0, 57 + height })
    self.siBottom:SetHeight({ 0, 88 + height })
    self.llCenter:SetHeight({ 1, -145 - height })
end

function UILuaChatLayout:updateFriendListIndex(chatId)
    if TableUtil.include(self.friendIndex, chatId) then
        if self.friendIndex[#self.friendIndex] == chatId then
            return
        end
        TableUtil.tableRemove(self.friendIndex, chatId)
    end
    table.insert(self.friendIndex, chatId)
    if self:isShow() and self.selectTab == Define.ChatTabType.Friend then
        self:updateFriendList()
    end
end

---只有界面打开着才监听的事件
---@private
function UILuaChatLayout:initOpenEvent()
    self:registerEvent(Events.FinishLoadFriendDataEvent, function()
        if self.selectTab == Define.ChatTabType.Friend then
            self:updateFriendList()
        end
    end)
end

---@private
function UILuaChatLayout:unregisterOpenEvent()
    self:unregisterEvent(Events.FinishLoadFriendDataEvent)
end

function UILuaChatLayout:getLoveNum(userId)
    if self.loveData[tostring(userId)] then
        return self.loveData[tostring(userId)]
    end
    PlayerManager:getClientPlayer():sendPacket({
        pid = "getLoveNum",
        userId = userId,
    })
    return 0
end

return UILuaChatLayout
