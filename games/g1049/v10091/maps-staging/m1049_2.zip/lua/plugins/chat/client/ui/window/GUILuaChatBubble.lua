---@class GUILuaChatBubbleWindow : IGUIWindow
local GUILuaChatBubbleWindow = class("GUILuaChatBubbleWindow", IGUIWindow)
---@type ChatClient
local ChatClient = T(Global, "ChatClient")

---@private
function GUILuaChatBubbleWindow:ctor(...)
    self.super.ctor(self, "LuaChatBubble.json", ...)
end

---@private
function GUILuaChatBubbleWindow:onLoad()
    self.llBubble = self:getChildWindowByName("LuaChatBubble", GUIType.Layout)
    self.llBubble:SetLevel(100)
    self.stText = self:getChildWindowByName("LuaChatBubble-Text", GUIType.StaticText)
    self.siEmoji = self:getChildWindowByName("LuaChatBubble-Emoji", GUIType.StaticImage)
end

---@param chatMsg ChatMsgData
function GUILuaChatBubbleWindow:onDataChanged(chatMsg)
    if chatMsg.type == Define.ChatMsgType.CustomMsg and chatMsg.data.content.type == Define.CustomChatMsgType.EmojiMsg then
        self.stText:SetVisible(false)
        self.siEmoji:SetVisible(true)
        self.llBubble:SetWidth({ 0, 100 })
        self.llBubble:SetHeight({ 0, 115 })
        self.siEmoji:SetImage(chatMsg.data.content.emojiData)
    else
        local text = ChatClient:chatMsgToString(chatMsg, TextFormat.colorBlack, true)
        local width = math.min(200, math.max(self.stText:GetFont():GetTextExtent(text, 1) + 28, 90))
        self.llBubble:SetWidth({ 0, width })
        self.stText:SetVisible(true)
        self.siEmoji:SetVisible(false)
        self.stText:SetText(text)
        self.llBubble:SetHeight({ 0, math.max(62, self.stText:GetTextHeight() + 30) })
    end
end

return GUILuaChatBubbleWindow
