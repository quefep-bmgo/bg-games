---@class GUILuaChatItemWindow : IGUIWindow
local GUILuaChatItemWindow = class("GUILuaChatItemWindow", IGUIWindow)

local ChatContentWindowName = {
    [Define.ChatMsgType.TextMsg] = "GUILuaChatItemContentText",
    [Define.ChatMsgType.ImageMsg] = "GUILuaChatItemContentImage",
    [Define.ChatMsgType.VoiceMsg] = "GUILuaChatItemContentVoice",
    [Define.ChatMsgType.CustomMsg .. "_" .. Define.CustomChatMsgType.EmojiMsg] = "GUILuaChatItemContentEmoji",
}

---@param msgData ChatMsgData
function GUILuaChatItemWindow:ctor(msgData)
    if msgData.sendId ~= Game:getPlatformUserId() then
        self.super.ctor(self, "LuaChatItemLeft.json")
    else
        self.super.ctor(self, "LuaChatItemRight.json")
    end
end

function GUILuaChatItemWindow:onLoad()
    self.llHeadImg = self:getChildWindowByName("LuaChatItem-HeadImg", GUIType.Layout)
    self.uiHead = self:getChildWindowByName("LuaChatItem-Head", GUIType.UrlImage)
    self.siSex = self:getChildWindowByName("LuaChatItem-Sex", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("LuaChatItem-Name", GUIType.StaticText)
    self.stLv = self:getChildWindowByName("LuaChatItem-Lv", GUIType.StaticText)
    self.llContent = self:getChildWindowByName("LuaChatItem-Content", GUIType.Layout)
    self:initView()
    self:initEvent()
end

function GUILuaChatItemWindow:initView()
    self.stLv:SetVisible(false)
    self.uiHead:setDefaultImage("set:userItem.json image:icon")
end

function GUILuaChatItemWindow:initEvent()
    self.llHeadImg:registerEvent(GUIEvent.Click, function()
        Events.ChatShowPlayerInfoEvent:invoke(self.playerInfo)
    end)
end

---@param data ChatMsgData
function GUILuaChatItemWindow:onDataChanged(data)
    self.data = data
    self.playerInfo = UserInfoCache:GetCache(data.sendId)
    if self.playerInfo then
        if self.playerInfo.picUrl then
            self.uiHead:setUrl(self.playerInfo.picUrl)
        end
        self.stName:SetText(self.playerInfo.name)
        self.stLv:SetText("Lv." .. (self.playerInfo.playerLevel or 1))
        self.siSex:SetImage(Define.SexIcon[self.playerInfo.sex] or Define.SexIcon[Define.SexType.Boy])
    end
    local name = ChatContentWindowName[data.type]
    if data.type == Define.ChatMsgType.CustomMsg then
        name = ChatContentWindowName[data.type .. "_" .. data.data.content.type]
    end
    if not name then
        return
    end
    local wContent = UIHelper.newGameGUIWindow(name)
    if data.sendId == Game:getPlatformUserId() then
        wContent.root:SetHorizontalAlignment(HorizontalAlignment.Right)
    end
    self.llContent:AddChildWindow(wContent.root)
    local height = wContent:onDataChanged(data)
    if not height then
        height = 76
    end
    self.root:SetHeight({ 0, height + 60 })
end

return GUILuaChatItemWindow
