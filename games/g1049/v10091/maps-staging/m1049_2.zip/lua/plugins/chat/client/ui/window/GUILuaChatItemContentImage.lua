---@class GUILuaChatItemContentImageWindow : IGUIWindow
local GUILuaChatItemContentImageWindow = class("GUILuaChatItemContentImageWindow", IGUIWindow)

---@private
function GUILuaChatItemContentImageWindow:ctor(...)
    self.super.ctor(self, "LuaChatItemContentImage.json", ...)
end

---@private
function GUILuaChatItemContentImageWindow:onLoad()
    self.siArrow = self:getChildWindowByName("LuaChatItemContentImage-Arrow", GUIType.StaticImage)
    self.uivImage = self:getChildWindowByName("LuaChatItemContentImage-Image", GUIType.UrlImage)
    self.uivImage:setDefaultImage("set:userItem.json image:icon")
    self:initEvent()
end

---@private
function GUILuaChatItemContentImageWindow:initEvent()

end

---@param data ChatMsgData
function GUILuaChatItemContentImageWindow:onDataChanged(data)
    if data.sendId == Game:getPlatformUserId() then
        self.siArrow:SetXPosition({ 1, 0 })
        self.siArrow:SetProperty("Rotate", 180)
    end
    self.uivImage:setUrl(data.data.uri)
	local height = 120
    self.root:SetHeight({ 0, height })
    return height
end

return GUILuaChatItemContentImageWindow
