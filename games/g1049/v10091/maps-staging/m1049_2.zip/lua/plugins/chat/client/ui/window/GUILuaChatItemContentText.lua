---@class GUILuaChatItemContentTextWindow : IGUIWindow
local GUILuaChatItemContentTextWindow = class("GUILuaChatItemContentTextWindow", IGUIWindow)

---@private
function GUILuaChatItemContentTextWindow:ctor(...)
    self.super.ctor(self, "LuaChatItemContentText.json", ...)
end

---@private
function GUILuaChatItemContentTextWindow:onLoad()
    self.stText = self:getChildWindowByName("LuaChatItemContentText-Text", GUIType.StaticText)
    self.siArrow = self:getChildWindowByName("LuaChatItemContentText-Arrow", GUIType.StaticImage)
end

---@param data ChatMsgData
function GUILuaChatItemContentTextWindow:onDataChanged(data)
    if data.sendId == Game:getPlatformUserId() then
        self.siArrow:SetXPosition({ 1, 0 })
        self.siArrow:SetProperty("Rotate", 180)
    end
    self.stText:SetText(data.data.content)
    ---@type number 消息总宽度
    local width = self.stText:GetTextWidth()
    ---@type number 消息总高度（换行后），最小取46
    local height = math.max(self.stText:GetTextHeight() + 16, 46)
    if width < self.stText:GetPixelSize().x then
        self.root:SetWidth({ 0, width + 35 })
    end
    self.root:SetHeight({ 0, height })
    return height
end

return GUILuaChatItemContentTextWindow
