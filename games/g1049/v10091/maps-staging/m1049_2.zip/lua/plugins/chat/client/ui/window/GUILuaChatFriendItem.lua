---@class GUILuaChatFriendItemWindow : IGUIWindow
local GUILuaChatFriendItemWindow = class("GUILuaChatFriendItemWindow", IGUIWindow)

local function addRedPoint(node, params, name)
    params = params or {}
    local redPoint = GUIManager:createGUIWindow(GUIType.StaticImage, name .. '-RedPoint')
    local img = params.img or "set:common.json image:img_0_red_dot"
    redPoint:SetTouchable(false)
    redPoint:SetProperty("Material", "CullBackLinear")
    redPoint:SetHorizontalAlignment(2)
    node:AddChildWindow(redPoint)
    UIHelper:setImageAdjustSize(redPoint, img, 50, 50)
    local size_rp = redPoint:GetPixelSize()
    redPoint:SetXPosition({ 0, params.x or size_rp.x / 4 })
    redPoint:SetYPosition({ 0, params.y or -size_rp.y / 4 })
    return redPoint
end

---@param time number 时间差
local function GetLogoutTimeText(time)
    if time < 3600 then
        return Lang:format("gui_user_logout_time_text_min", math.max(1, math.floor(time / 60)))
    elseif time < DateUtil.getDaySeconds() then
        return Lang:format("gui_user_logout_time_text_hour", math.floor(time / 3600))
    elseif time < DateUtil.getWeekSeconds() then
        return Lang:format("gui_user_logout_time_text_day", math.floor(time / DateUtil.getDaySeconds()))
    elseif time < 2626560 then
        return Lang:format("gui_user_logout_time_text_week", math.floor(time / DateUtil.getWeekSeconds()))
    else
        return Lang:format("gui_user_logout_time_text_month", math.floor(time / 2626560))
    end
end

function GUILuaChatFriendItemWindow:ctor(...)
    self.super.ctor(self, "LuaChatFriendItem.json", ...)
end

function GUILuaChatFriendItemWindow:onLoad()
    self.siBg = self:getChildWindowByName("LuaChatFriendItem-Bg", GUIType.StaticImage)
    self.llBottomLine = self:getChildWindowByName("LuaChatFriendItem-Bottom-Line", GUIType.Layout)
    self.llHeader = self:getChildWindowByName("LuaChatFriendItem-Header", GUIType.Layout)
    self.uiHead = self:getChildWindowByName("LuaChatFriendItem-Head", GUIType.UrlImage)
    self.stName = self:getChildWindowByName("LuaChatFriendItem-Name", GUIType.StaticText)
    self.siSex = self:getChildWindowByName("LuaChatFriendItem-Sex", GUIType.StaticImage)
    self.stHonor = self:getChildWindowByName("LuaChatFriendItem-Honor", GUIType.StaticText)
    self.stStatus = self:getChildWindowByName("LuaChatFriendItem-Status", GUIType.StaticText)
    self.siGoChat = self:getChildWindowByName("LuaChatFriendItem-Go-Chat", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

function GUILuaChatFriendItemWindow:initView()
    self.redPoint = addRedPoint(self.root, { x = 0, y = 3, img = "set:common.json image:img_0_red_dot"}, self.root:GetName())
    self.txtNum = GUIManager:createGUIWindow(GUIType.StaticText, self.redPoint:GetName() .. "Num-Text")
    self.txtNum:SetHorizontalAlignment(HorizontalAlignment.Center)
    self.txtNum:SetVerticalAlignment(VerticalAlignment.Center)
    self.txtNum:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.txtNum:SetTextVertAlign(VerticalAlignment.Center)
    self.txtNum:SetTextHorzAlign(HorizontalAlignment.Center)
    self.txtNum:SetProperty("Font", "HT10")
    self.redPoint:AddChildWindow(self.txtNum)
    self.redPoint:SetVisible(false)
    self.uiHead:setDefaultImage("set:userItem.json image:icon")
end

function GUILuaChatFriendItemWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if self.data.userId == Game:getPlatformUserId()then
            return
        end
        Events.ChatSelectFriendEvent:invoke(self.data.userId)
    end)

    self:registerEvent(Events.ChatSelectFriendEvent, function(userId)
        if userId ~= self.data.userId then
            self.siBg:SetImage("")
        else
            self.siBg:SetImage("set:chat.json image:img_0_current_friends")
            local GUILuaChat = UIHelper.newGameGUILayout("GUILuaChat")
            GUILuaChat:clearRedDot()
        end
    end)

    self:registerEvent(Events.ChatPrivateNewMsgEvent, function(userId, count)
        if userId == self.data.userId then
            self.redPoint:SetVisible(count > 0)
            self.txtNum:SetText(count)
        end
    end)
end

function GUILuaChatFriendItemWindow:onDataChanged(data)
    self.data = data
    if data.picUrl then
        self.uiHead:setUrl(data.picUrl)
    end
    self.stName:SetText(data.name)
    self.siSex:SetImage(Define.SexIcon[data.sex] or Define.SexIcon[Define.SexType.Boy])
    self.stStatus:SetText(Lang:getString(Define.UserStatusLang[data.status] or "gui.user.status.offline"))
    self.stStatus:SetTextColor(Define.UserStatusColor[data.status] or Color.WHITE)
    ---@type UILuaChatLayout
    local GUILuaChat = UIHelper.newGameGUILayout("GUILuaChat")
    local curFriendChatId = GUILuaChat:getCurSelectFriend()
    self.siBg:SetImage("")
    if curFriendChatId == data.userId then
        self.siBg:SetImage("set:chat.json image:img_0_current_friends")
    end
    self.siGoChat:SetVisible(false)
    local newMsgCount = GUILuaChat:getNewMsgCount(data.userId)
    self.redPoint:SetVisible(newMsgCount > 0)
    self.txtNum:SetText(newMsgCount)
    if data.status == Define.UserStatus.Offline and data.logoutTime and data.logoutTime > 0 then
        local time = os.time() - data.logoutTime / 1000
        self.stStatus:SetText(GetLogoutTimeText(time))
    end
end

return GUILuaChatFriendItemWindow
