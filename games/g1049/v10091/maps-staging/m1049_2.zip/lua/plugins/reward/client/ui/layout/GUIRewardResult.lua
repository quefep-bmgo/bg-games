---@class UIRewardResultLayout : IGUILayout
local UIRewardResultLayout = class("UIRewardResultLayout", IGUILayout)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function UIRewardResultLayout:ctor(parent)
    self.super.ctor(self, "RewardResult.json", parent)
end

---@private
function UIRewardResultLayout:isDelayLoad()
    return true
end

---@private
function UIRewardResultLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIRewardResultLayout:initCreateEvent()
    self.rewards = {}
end

---@private
function UIRewardResultLayout:onLoad()
    self.llTitle = self:getChildWindow("RewardResult-Title", GUIType.Layout)
    self.btnConfirm = self:getChildWindow("RewardResult-Confirm", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIRewardResultLayout:initView()
    ---@type GUIRewardResultItemWindow[]
    self.wItems = {}
    self.btnConfirm:SetText(Lang:getString("gui_dialog_tip_btn_sure"))
end

---@private
function UIRewardResultLayout:initEvent()
    self.btnConfirm:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
end

function UIRewardResultLayout:show(rewards)
    TableUtil.mergeArray(self.rewards, rewards)
    self.super.show(self, rewards)
end

function UIRewardResultLayout:onShow()
    self:tryShowRewardList()
end

function UIRewardResultLayout:findRewardResultItem()
    for _, item in pairs(self.wItems) do
        if not item.root:IsVisible() then
            return item
        end
    end
    if #self.wItems == 10 then
        return nil
    end
    ---@type GUIRewardResultItemWindow
    local item = UIHelper.newGameGUIWindow("GUIRewardResultItem")
    item.root:SetVerticalAlignment(VerticalAlignment.Center)
    self.root:AddChildWindow(item.root)
    table.insert(self.wItems, item)
    return item
end

function UIRewardResultLayout:tryShowRewardList()
    local count = math.min(10, #self.rewards)
    if count == 0 then
        self:hide()
        return
    end
    for _, item in pairs(self.wItems) do
        item:setVisible(false)
    end
    self.btnConfirm:SetVisible(false)
    local space = 18
    local startPos = (self.root:GetPixelSize().x - (count * (97 + space) - space)) / 2
    for i = 1, count do
        local reward = self.rewards[1]
        local rewardId, rewardCount = reward[1], reward[2]
        local cfg = TableUtil.copyTable(RewardConfig:getCfgById(rewardId))
        cfg.count = rewardCount
        table.remove(self.rewards, 1)
        local item = self:findRewardResultItem()
        item:setVisible(true)
        item:setXPosition({ 0, startPos })
        item:onDataChanged(cfg)
        startPos = startPos + 97 + space
        self:addTimer(LuaTimer:scheduleTicker(function()
            item:setVisible(true)
            if i == count then
                self.btnConfirm:SetVisible(true)
            end
            UIAnimation:alpha(item.root, 0, 1.1, 5)
            UIAnimation:scale(item.root, 0.8, 1, 5, function(destroy)
                if destroy then
                    return
                end
                UIAnimation:scale(item.root, 1.1, 1, 3)
            end)
        end, 5 * i, 1))
    end
    for _, item in pairs(self.wItems) do
        item:setVisible(false)
    end
end

function UIRewardResultLayout:onHide()
    if #self.rewards == 0 then
        return
    end
    self:show({})
end

return UIRewardResultLayout
