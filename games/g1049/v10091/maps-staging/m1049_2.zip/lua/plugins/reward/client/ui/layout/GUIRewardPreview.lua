---@class UIRewardPreviewLayout : IGUILayout
local UIRewardPreviewLayout = class("UIRewardPreviewLayout", IGUILayout)

---@private
function UIRewardPreviewLayout:ctor(parent)
    self.super.ctor(self, "RewardPreview.json", parent)
end

---@private
function UIRewardPreviewLayout:isDelayLoad()
    return true
end

---@private
function UIRewardPreviewLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIRewardPreviewLayout:initCreateEvent()

end

---@private
function UIRewardPreviewLayout:onLoad()
    self.btnClose = self:getChildWindow("RewardPreview-Close", GUIType.Button)
    self.stTitle = self:getChildWindow("RewardPreview-Title", GUIType.StaticText)
    self.siBg = self:getChildWindow("RewardPreview-Bg", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIRewardPreviewLayout:initView()
    self.stTitle:SetText(Lang:getString("gui.lucky.chest.reward"))
end

---@private
function UIRewardPreviewLayout:initEvent()
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
end

---@private
function UIRewardPreviewLayout:onShow(rewards)
    self:tryShowRewards(rewards)
end

---@private
function UIRewardPreviewLayout:tryShowRewards(rewards)
    if not self.rewardAdapter then
        self.lvRewardList = IGUIGridView.new("RewardPreview-RewardListItems", self.siBg)
        self.lvRewardList:setArea({ 0, 13 }, { 0, 13 }, { 1, -26 }, { 1, -26 })
        self.lvRewardList:setConfig(15, 15, 6)
        ---@type RewardPreviewItemAdapter
        self.rewardAdapter = UIHelper.newGameAdapter("RewardPreviewItemAdapter")
        self.lvRewardList:setAdapter(self.rewardAdapter)
    end
    self.rewardAdapter:setData(rewards)
end

return UIRewardPreviewLayout
