---@class GUIRewardPreviewItemWindow : IGUIWindow
local GUIRewardPreviewItemWindow = class("GUIRewardPreviewItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUIRewardPreviewItemWindow:ctor(...)
    self.super.ctor(self, "RewardPreviewItem.json", ...)
end

---@private
function GUIRewardPreviewItemWindow:onLoad()
    self.siImage = self:getChildWindowByName("RewardPreviewItem-Image", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("RewardPreviewItem-Count", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIRewardPreviewItemWindow:initView()

end

---@private
function GUIRewardPreviewItemWindow:initEvent()
    self.siImage:registerEvent(GUIEvent.Click, function()
        if not self.rewardId then
            return
        end
        UIHelper.showGameGUILayout("GUIRewardDetail", self.rewardId)
    end)
end

---@param data table
function GUIRewardPreviewItemWindow:onDataChanged(data)
    self.rewardId = data[1]
    RewardConfig:setRewardImage(self.siImage, RewardConfig:getCfgById(data[1]))
    self.stCount:SetText(data[2] or "1")
end

return GUIRewardPreviewItemWindow
