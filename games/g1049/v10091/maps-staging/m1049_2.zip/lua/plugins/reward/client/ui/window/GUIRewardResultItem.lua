---@class GUIRewardResultItemWindow : IGUIWindow
local GUIRewardResultItemWindow = class("GUIRewardResultItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUIRewardResultItemWindow:ctor(...)
    self.super.ctor(self, "RewardResultItem.json", ...)
end

---@private
function GUIRewardResultItemWindow:onLoad()
    self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.siIcon = self:getChildWindowByName("RewardResultItem-Icon", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("RewardResultItem-Count", GUIType.StaticText)
    self.stName = self:getChildWindowByName("RewardResultItem-Name", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIRewardResultItemWindow:initView()

end

---@private
function GUIRewardResultItemWindow:initEvent()

end

---@param data RewardConfigData
function GUIRewardResultItemWindow:onDataChanged(data)
    RewardConfig:setRewardQuality(self.llRoot, data, true)
    RewardConfig:setRewardImage(self.siIcon, data)
    RewardConfig:setRewardName(self.stName, data)
    self.stCount:SetText(data.count)
end

return GUIRewardResultItemWindow
