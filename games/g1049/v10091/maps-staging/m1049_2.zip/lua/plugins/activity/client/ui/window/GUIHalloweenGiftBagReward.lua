---@class GUIHalloweenGiftBagRewardWindow : IGUIWindow
local GUIHalloweenGiftBagRewardWindow = class("GUIHalloweenGiftBagRewardWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUIHalloweenGiftBagRewardWindow:ctor(...)
    self.super.ctor(self, "HalloweenGiftBagReward.json", ...)
end

---@private
function GUIHalloweenGiftBagRewardWindow:onLoad()
    self.siIconBg = self:getChildWindowByName("HalloweenGiftBagReward-Icon-Bg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("HalloweenGiftBagReward-Icon", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("HalloweenGiftBagReward-Effect", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("HalloweenGiftBagReward-Count", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIHalloweenGiftBagRewardWindow:initView()
    self.siEffect:SetEffectName("g1048_jiangliquan_liubianxing.effect")
end

---@private
function GUIHalloweenGiftBagRewardWindow:initEvent()
    self.siIcon:registerEvent(GUIEvent.Click, function()
        if self.rewardId then
            UIHelper.showGameGUILayout("GUIRewardDetail", self.rewardId)
        end
    end)
end

---@param data table
function GUIHalloweenGiftBagRewardWindow:onDataChanged(data)
    self.rewardId = data[1]
    RewardConfig:setRewardImage(self.siIcon, RewardConfig:getCfgById(self.rewardId))
    if data[2] and data[2] > 1 then
        self.stCount:SetVisible(true)
        self.stCount:SetText("x" .. data[2])
    else
        self.stCount:SetVisible(false)
    end
end

return GUIHalloweenGiftBagRewardWindow
