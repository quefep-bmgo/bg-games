---@class UIHalloweenGiftBagLayout : IGUILayout
local UIHalloweenGiftBagLayout = class("UIHalloweenGiftBagLayout", IGUILayout)
---@type GiftBagRewardConfig
local GiftBagRewardConfig = T(Global, "GiftBagRewardConfig")

---@private
function UIHalloweenGiftBagLayout:ctor(parent)
    self.super.ctor(self, "HalloweenGiftBag.json", parent)
end

---@private
function UIHalloweenGiftBagLayout:isDelayLoad()
    return true
end

---@private
function UIHalloweenGiftBagLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIHalloweenGiftBagLayout:initCreateEvent()

end

---@private
function UIHalloweenGiftBagLayout:onLoad()
    self.btnClose = self:getChildWindow("HalloweenGiftBag-Close", GUIType.Button)
    self.llContent = self:getChildWindow("HalloweenGiftBag-Content", GUIType.Layout)
    self.llTitleBg = self:getChildWindow("HalloweenGiftBag-Title-Bg", GUIType.Layout)
    self.stTitle = self:getChildWindow("HalloweenGiftBag-Title", GUIType.StaticText)
    self.llHintBg = self:getChildWindow("HalloweenGiftBag-Hint-Bg", GUIType.Layout)
    self.stHint = self:getChildWindow("HalloweenGiftBag-Hint", GUIType.StaticText)
    self.siMainImage = self:getChildWindow("HalloweenGiftBag-Main-Image", GUIType.StaticImage)
    self.llRewards = self:getChildWindow("HalloweenGiftBag-Rewards", GUIType.Layout)
    self.btnBuy = self:getChildWindow("HalloweenGiftBag-Buy", GUIType.Button)
    self.ivPriceIcon = self:getChildWindow("HalloweenGiftBag-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindow("HalloweenGiftBag-Price", GUIType.StaticText)
    self.btnSmallClose = self:getChildWindow("HalloweenGiftBag-Small-Close", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIHalloweenGiftBagLayout:initView()
    self.stTitle:SetText(Lang:getString("halloween.activity.title"))
    self.stHint:SetText(Lang:getString("halloween.activity.hint"))
end

---@private
function UIHalloweenGiftBagLayout:initEvent()
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
        if not self.cfg then
            return
        end
        CustomDialog.builder()
                    .setContentText(Lang:getString("halloween.activity.buy.tip"))
                    .setRightClickListener(function()
            self.activity:tryBuyGiftBag(self.cfg.id)
        end)        .show()
    end)
    self.btnSmallClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
end

function UIHalloweenGiftBagLayout:show(...)
    if self:isShow() then
        self:tryAddRewards()
        self:updateBuyButtonUI()
    else
        self.super.show(self, ...)
    end
end

---@param activity HalloweenGiftBag
function UIHalloweenGiftBagLayout:onShow(activity)
    self.activity = activity
    self:tryAddRewards()
    self:updateBuyButtonUI()
end

function UIHalloweenGiftBagLayout:updateBuyButtonUI()
    if self.activity:interceptLoginUI() then
        self.btnBuy:SetEnabled(false)
        self.btnBuy:SetText(Lang:getString("shop_btn_have_bought"))
        self.ivPriceIcon:SetVisible(false)
    else
        self.btnBuy:SetEnabled(true)
        self.btnBuy:SetText("")
        self.ivPriceIcon:SetVisible(true)
    end
end

function UIHalloweenGiftBagLayout:tryAddRewards()
    local cfg = self.activity:getCurrentGiftBag()
    if not cfg or self.cfg == cfg then
        return
    end
    self.cfg = cfg
    self.llRewards:CleanupChildren()
    local rewards = GiftBagRewardConfig:getCfgById(cfg.id)
    local count = #rewards
    if count == 0 then
        return
    end
    table.sort(rewards, function(r1, r2)
        return r1[1] > r2[1]
    end)
    local itemW = self.llRewards:GetPixelSize().x / count
    local space = 10
    if itemW > 130 then
        space = itemW - 130
        itemW = 130
    else
        itemW = itemW - space
    end
    local itemH = (itemW / 130) * 113
    local curX = space / 2
    for _, reward in pairs(rewards) do
        ---@type GUIHalloweenGiftBagRewardWindow
        local wReward = UIHelper.newGameGUIWindow("GUIHalloweenGiftBagReward")
        wReward:setArea({ 0, curX }, { 0, 0 }, { 0, itemW }, { 0, itemH })
        wReward:onDataChanged(reward)
        wReward.root:SetVerticalAlignment(VerticalAlignment.Center)
        self.llRewards:AddChildWindow(wReward.root)
        curX = curX + itemW + space
    end
    self.stPrice:SetText(cfg.price)
    self.ivPriceIcon:SetImage(PayHelper.getMoneyIcon(cfg.priceType))
    self.ivPriceIcon:SetXPosition({ 0, -self.stPrice:GetTextWidth() / 2 - 3 })
end

return UIHalloweenGiftBagLayout
