---@class UIPlayerHotbarLayout : IGUILayout
local UIPlayerHotbarLayout = class("UIPlayerHotbarLayout", IGUILayout)
---@type CInventoryPkSender
local InventoryPkSender = T(Global, "PidPacketSender")
---@type ReportUtil
local ReportUtil = T(Global, "ReportUtil")

local function setEngineWindowVisible(name, visible)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetYPosition({ 0, visible and -200 or 6000 })
    window:SetVisible(visible)
end

local function setEngineHotbarVisible(visible)
    setEngineWindowVisible("Main-VisibleBar", visible)
    setEngineWindowVisible("Main-ItemBarBg", visible)
end

---@private
function UIPlayerHotbarLayout:ctor()
    self.super.ctor(self, "PlayerHotbar.json", GUIManager:getMainControl())
end

---@private
function UIPlayerHotbarLayout:isDelayLoad()
    return true
end

---@private
function UIPlayerHotbarLayout:isShowAnim()
    return false
end

---@private
function UIPlayerHotbarLayout:onCreate()
    self:initCreateEvent()
    setEngineHotbarVisible(false)
end

---@private
function UIPlayerHotbarLayout:initCreateEvent()

end

---@private
function UIPlayerHotbarLayout:onLoad()
    self.siOpen = self:getChildWindow("PlayerHotbar-Open", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIPlayerHotbarLayout:initView()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    ---@type GUIItemContainerWindow
    self.wHotbar = UIHelper.newGameGUIWindow("GUIItemContainer", self.root)
    self.wHotbar:initContainer({ 1, -8 }, { 0, 62 }, 62)
    self.wHotbar:setPosition({ 0, 4 }, { 0, 4 })
    self.wHotbar:setItemContainer(inv.hotbar)
    self.curSelectSlot = nil
end

---@private
function UIPlayerHotbarLayout:initEvent()
    self.siOpen:registerEvent(GUIEvent.Click, function()
        self:hide()
        RootGuiLayout.Instance():hideAllChildren()
        UIHelper.showGameGUILayout("GUIPlayerInventoryLua")
        ReportUtil.clickMainButton("inventory")
    end)
    self.wHotbar:setItemClickListener(function(slot, event)
        if event == GUIEvent.Click then
            self:onClickSlot(slot)
        elseif event == GUIEvent.LongTouchStart then
            InventoryPkSender:tryDropInventoryItem(slot.slot)
        end
    end)
    local index = tonumber(ClientHelper.getStringForKey("HotbarIndex", "1"))
    self.wHotbar:onItemSlotClick(self.wHotbar.gvSlots.items[index], GUIEvent.Click)
end

---@private
---@param slot GUIItemSlotLuaWindow
function UIPlayerHotbarLayout:onClickSlot(slot)
    if self.curSelectSlot == slot then
        return
    end
    if self.curSelectSlot then
        self.curSelectSlot:setSelected(false)
    end
    self.curSelectSlot = slot
    self.curSelectSlot:setSelected(true)
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    inv:setHotbarIndex(slot.slot.index)
    InventoryPkSender:tryChangeHotbarIndex(slot.slot.index)
    ClientHelper.putStringForKey("HotbarIndex", tostring(slot.slot.index))
end

function UIPlayerHotbarLayout:trySelectSlot(index)
    local item = self.wHotbar.gvSlots.items[index]
    if not item then
        return
    end
    self.wHotbar:onItemSlotClick(item, GUIEvent.Click)
end

function UIPlayerHotbarLayout:onHide()
    self.wHotbar:hide()
end

function UIPlayerHotbarLayout:onShow()
    self.wHotbar:show()
end

return UIPlayerHotbarLayout
