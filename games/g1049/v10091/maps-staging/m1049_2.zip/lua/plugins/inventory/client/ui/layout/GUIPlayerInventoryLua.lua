---@class UIPlayerInventoryLuaLayout : IGUILayout
local UIPlayerInventoryLuaLayout = class("UIPlayerInventoryLuaLayout", IGUILayout)
---@type ItemContainerUtil
local ItemContainerUtil = T(Global, "ItemContainerUtil")

local TabType = {
    Backpack = 1,
    Workbench = 2,
}

local PanelName = {
    [TabType.Backpack] = "GUIBackpackPanel",
    [TabType.Workbench] = "GUIWorkbenchPanel",
}

---@private
function UIPlayerInventoryLuaLayout:ctor(parent)
    self.super.ctor(self, "PlayerInventoryLua.json", parent)
end

---@private
function UIPlayerInventoryLuaLayout:isDelayLoad()
    return true
end

---@private
function UIPlayerInventoryLuaLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIPlayerInventoryLuaLayout:initCreateEvent()

end

---@private
function UIPlayerInventoryLuaLayout:isShowAnim()
    return false
end

---@private
function UIPlayerInventoryLuaLayout:onLoad()
    self.siClose = self:getChildWindow("PlayerInventoryLua-Close", GUIType.StaticImage)
    self.siHide = self:getChildWindow("PlayerInventoryLua-Hide", GUIType.StaticImage)
    self.llHotbar = self:getChildWindow("PlayerInventoryLua-Hotbar", GUIType.Layout)
    self.llPanel = self:getChildWindow("PlayerInventoryLua-Panel", GUIType.Layout)
    self.rbBackpack = self:getChildWindow("PlayerInventoryLua-Backpack", GUIType.RadioButton)
    self.rbWorkbench = self:getChildWindow("PlayerInventoryLua-Workbench", GUIType.RadioButton)
    ---@type GUIRadioButton[]
    self.tabs = {
        [TabType.Backpack] = self.rbBackpack,
        [TabType.Workbench] = self.rbWorkbench,
    }
    ---@type IGUIWindow[]
    self.panels = {}
    self:initView()
    self:initEvent()
end

---@private
function UIPlayerInventoryLuaLayout:initView()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    ---@type GUIItemContainerWindow
    self.wHotbar = UIHelper.newGameGUIWindow("GUIItemContainer", self.llHotbar)
    self.wHotbar:initContainer({ 1, -8 }, { 0, 62 }, 62)
    self.wHotbar:setPosition({ 0, 4 }, { 0, 4 })
    self.wHotbar:setItemContainer(inv.hotbar)
    self.curSelectSlot = nil
    self.rbBackpack:SetSelected(true)
    self.rbBackpack:SetText(Lang:getString("wordart_role"))
    self.rbWorkbench:SetText(Lang:getString("wordart_compound"))
end

---@private
function UIPlayerInventoryLuaLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self:hide()
    end)
    self.siHide:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self:hide()
    end)
    self.wHotbar:setItemClickListener(function(slot, event)
        if event == GUIEvent.DoubleClick then
            if PlayerManager:getClientPlayer():getPlayerInventory():tryEquipSlot(slot.slot) then
                self:addTimer(LuaTimer:scheduleTicker(function()
                    self:clearSelectSlot()
                end, 2, 1))
            end
        elseif event == GUIEvent.Click then
            self:onClickSlot(slot)
        end
    end)
end

function UIPlayerInventoryLuaLayout:clearSelectSlot()
    if not self.curSelectSlot then
        return
    end
    self.curSelectSlot:setSelected(false)
    self.curSelectSlot = nil
    self:tryShowItemDesc()
end

---@param slot GUIItemSlotLuaWindow
function UIPlayerInventoryLuaLayout:onClickSlot(slot)
    if slot.slot.itemId < 0 then
        return
    end
    if self.curSelectSlot == slot then
        self:clearSelectSlot()
        return
    end
    if not self.curSelectSlot then
        self.curSelectSlot = slot
        self.curSelectSlot:setSelected(true)
    else
        if self.curSelectSlot.slot.itemId == 0 and slot.slot.itemId == 0 then
            self.curSelectSlot:setSelected(false)
            self.curSelectSlot = slot
            self.curSelectSlot:setSelected(true)
        else
            local container1 = self.curSelectSlot.slot.container
            local index1 = self.curSelectSlot.slot.index
            local container2 = slot.slot.container
            local index2 = slot.slot.index
            self.curSelectSlot:setSelected(false)
            self.curSelectSlot = nil
            ItemContainerUtil:trySwapContainerSlot(container1.key, index1, container2.key, index2)
        end
    end
    self:tryShowItemDesc()
end

function UIPlayerInventoryLuaLayout:onShow(tab, ...)
    tab = tab or TabType.Backpack
    self:showPanel(tab, ...)
    self.wHotbar:show()
    if self.tabs[tab] then
        self.tabs[tab]:SetSelected(true)
    end
    for type, win in pairs(self.tabs) do
        win:registerEvent(GUIEvent.RadioStateChanged, function()
            if win:IsSelected() then
                self:showPanel(type)
            end
        end)
    end
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    if inventory:getHandItemSlot().itemId == 0 then
        self.wHotbar:tryClickItemSlot(inventory.hotbarIndex)
    end
end

function UIPlayerInventoryLuaLayout:onHide(...)
    for _, panel in pairs(self.panels) do
        if panel.onHide then
            panel:onHide(true)
        end
    end
    self.wHotbar:hide()
    for _, tab in pairs(self.tabs) do
        tab:removeAllEvents()
    end
    UIHelper.showGameGUILayout("GUIPlayerHotbar")
    RootGuiLayout.Instance():showMainControl()
    if self.curSelectSlot then
        self.curSelectSlot:setSelected(false)
        self.curSelectSlot = nil
    end
end

function UIPlayerInventoryLuaLayout:onTick(frameTime, renderDt)
    if self.curShowPanel then
        self.curShowPanel:onDataChanged(frameTime, renderDt)
    end
end

function UIPlayerInventoryLuaLayout:showPanel(tab, ...)
    if not self.panels[tab] then
        self.panels[tab] = UIHelper.newGameGUIWindow(PanelName[tab])
        self.llPanel:AddChildWindow(self.panels[tab].root)
    end
    if self.curShowPanel == self.panels[tab] then
        if self.curShowPanel.onHide then
            self.curShowPanel:onHide(false)
        end
    end
    for type, panel in pairs(self.panels) do
        if type == tab then
            panel:setVisible(true)
            if panel.onShow then
                panel:onShow(...)
            end
            self.curShowPanel = panel
        else
            panel:setVisible(false)
            if panel.onHide then
                panel:onHide(false)
            end
        end
    end
    if tab == TabType.Backpack then
        self:tryShowItemDesc()
    end
end

function UIPlayerInventoryLuaLayout:tryShowItemDesc()
    ---@type GUIBackpackPanelWindow
    local panel = self.panels[TabType.Backpack]
    if not panel then
        return
    end
    if self.curSelectSlot then
        panel:showItemDesc(self.curSelectSlot.slot)
    else
        panel:showItemDesc(nil)
    end
end

return UIPlayerInventoryLuaLayout
