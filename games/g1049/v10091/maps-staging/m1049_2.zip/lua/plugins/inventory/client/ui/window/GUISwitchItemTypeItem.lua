---@class GUISwitchItemTypeItemWindow : IGUIWindow
local GUISwitchItemTypeItemWindow = class("GUISwitchItemTypeItemWindow", IGUIWindow)

---@private
function GUISwitchItemTypeItemWindow:ctor(...)
    self.super.ctor(self, "SwitchItemTypeItem.json", ...)
end

---@private
function GUISwitchItemTypeItemWindow:onLoad()
    self.stText = self:getChildWindowByName("SwitchItemTypeItem-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUISwitchItemTypeItemWindow:initView()

end

---@private
function GUISwitchItemTypeItemWindow:initEvent()

end

---@param data table
function GUISwitchItemTypeItemWindow:onDataChanged(data)
    self.stText:SetText(Lang:getString(data))
end

function GUISwitchItemTypeItemWindow:setOnClickListener(listener)
	self.stText:registerEvent(GUIEvent.Click, listener)
end

return GUISwitchItemTypeItemWindow
