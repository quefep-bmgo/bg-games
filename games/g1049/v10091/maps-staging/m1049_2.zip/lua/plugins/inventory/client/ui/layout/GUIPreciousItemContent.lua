---@class UIPreciousItemContentLayout : IGUILayout
local UIPreciousItemContentLayout = class("UIUIPreciousItemContentLayout", IGUILayout)

---@private
function UIPreciousItemContentLayout:ctor(name, parent)
	self.super.ctor(self, name, parent)
end

---@private
function UIPreciousItemContentLayout:isDelayLoad()
	return true
end

---@private
function UIPreciousItemContentLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIPreciousItemContentLayout:initCreateEvent()

end

---@private
function UIPreciousItemContentLayout:onLoad()
	self.stTip = self:getChildWindow("PreciousItemContent-Tip", GUIType.StaticText)
	self.siIcon = self:getChildWindow("PreciousItemContent-Icon", GUIType.StaticImage)
	self.stName = self:getChildWindow("PreciousItemContent-Name", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIPreciousItemContentLayout:initView()

end

---@private
function UIPreciousItemContentLayout:initEvent()

end

function UIPreciousItemContentLayout:showTip(tip, itemId, meta)
	self:show()
	self.stTip:SetText(Lang:getString(tip))
	self.siIcon:SetHexagonImage("", "")
	self.siIcon:SetRenderAsBlock(false)
	self.stName:SetText(Lang:getItemName(itemId, meta))
	GuiItemStack.showItemIcon(self.siIcon, itemId, meta, "")
end

---@type UIPreciousItemContentLayout
PreciousItemContent = buildCustomDialogContent(UIPreciousItemContentLayout, "PreciousItemContent.json")

return UIPreciousItemContentLayout
