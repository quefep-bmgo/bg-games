---@class GUIPassVipRewardItemWindow : IGUIWindow
local GUIPassVipRewardItemWindow = class("GUIPassVipRewardItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUIPassVipRewardItemWindow:ctor(...)
	self.super.ctor(self, "PassVipRewardItem.json", ...)
end

---@private
function GUIPassVipRewardItemWindow:onLoad()
	self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
	self.siIcon = self:getChildWindowByName("PassVipRewardItem-Icon", GUIType.StaticImage)
	self.stCount = self:getChildWindowByName("PassVipRewardItem-Count", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function GUIPassVipRewardItemWindow:initView()

end

---@private
function GUIPassVipRewardItemWindow:initEvent()

end

---@param data RewardConfigData
function GUIPassVipRewardItemWindow:onDataChanged(data)
	RewardConfig:setRewardQuality(self.llRoot, data, true)
	RewardConfig:setRewardImage(self.siIcon, data)
	self.stCount:SetText(data.count)
end

return GUIPassVipRewardItemWindow
