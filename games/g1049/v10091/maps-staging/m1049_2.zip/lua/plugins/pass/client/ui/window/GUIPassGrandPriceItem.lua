---@class GUIPassGrandPriceItemWindow : IGUIWindow
local GUIPassGrandPriceItemWindow = class("GUIPassGrandPriceItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUIPassGrandPriceItemWindow:ctor(...)
    self.super.ctor(self, "PassGrandPriceItem.json", ...)
end

---@private
function GUIPassGrandPriceItemWindow:onLoad()
	self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.siIconBg = self:getChildWindowByName("PassGrandPriceItem-IconBg", GUIType.StaticImage)
    self.siIcon = self:getChildWindowByName("PassGrandPriceItem-Icon", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("PassGrandPriceItem-Count", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassGrandPriceItemWindow:setIsPay(isPay)
	if isPay then
		self.llRoot:SetBackImage("set:passes.json image:img_0_rewards08")
	else
		self.llRoot:SetBackImage("set:passes.json image:img_0_rewards02")
	end
end

---@private
function GUIPassGrandPriceItemWindow:initView()

end

---@private
function GUIPassGrandPriceItemWindow:initEvent()

end

---@param data RewardConfigData
function GUIPassGrandPriceItemWindow:onDataChanged(data)
	RewardConfig:setRewardQuality(self.siIconBg, data)
	RewardConfig:setRewardImage(self.siIcon, data)
	self.stCount:SetText(data.count)
end

return GUIPassGrandPriceItemWindow
