---@class UIPassVipBuyLayout : IGUILayout
local UIPassVipBuyLayout = class("UIPassVipBuyLayout", IGUILayout)
---@type PassConfig
local PassConfig = T(Global, "PassConfig")
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function UIPassVipBuyLayout:ctor(parent)
    self.super.ctor(self, "PassVipBuy.json", parent)
end

---@private
function UIPassVipBuyLayout:isDelayLoad()
    return true
end

---@private
function UIPassVipBuyLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIPassVipBuyLayout:initCreateEvent()

end

---@private
function UIPassVipBuyLayout:onLoad()
    self.awActor = self:getChildWindow("PassVipBuy-Actor", GUIType.ActorWindow)
    self.stTip = self:getChildWindow("PassVipBuy-Tip", GUIType.StaticText)
    self.llShow = self:getChildWindow("PassVipBuy-Show", GUIType.Layout)
    self.llActorSlide = self:getChildWindow("PassVipBuy-ActorSlide", GUIType.Layout)
    self.stVip1NameText = self:getChildWindow("PassVipBuy-Vip1NameText", GUIType.StaticText)
    self.stVip1Info = self:getChildWindow("PassVipBuy-Vip1Info", GUIType.StaticText)
    self.btnVip1Buy = self:getChildWindow("PassVipBuy-Vip1Buy", GUIType.Button)
    self.stVip1Price = self:getChildWindow("PassVipBuy-Vip1Price", GUIType.StaticText)
    self.stVip2NameText = self:getChildWindow("PassVipBuy-Vip2NameText", GUIType.StaticText)
    self.stVip2Info = self:getChildWindow("PassVipBuy-Vip2Info", GUIType.StaticText)
    self.btnVip2Buy = self:getChildWindow("PassVipBuy-Vip2Buy", GUIType.Button)
    self.stVip2Price = self:getChildWindow("PassVipBuy-Vip2Price", GUIType.StaticText)
    self.stMarkText = self:getChildWindow("PassVipBuy-MarkText", GUIType.StaticText)
    self.stMark2Text = self:getChildWindow("PassVipBuy-Mark2Text", GUIType.StaticText)
    self.siTop = self:getChildWindow("PassVipBuy-Top", GUIType.StaticImage)
    self.btnBack = self:getChildWindow("PassVipBuy-Back", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIPassVipBuyLayout:initView()
    self.pass = PlayerManager:getClientPlayer().pass
    self.stTip:SetText(Lang:getString("gui.pass.vip.tip"))
    self.stVip1NameText:SetText(Lang:getString("gui.pass.vip.name1"))
    self.stVip1Info:SetText(Lang:getString("gui.pass.vip.info1"))
    self.stVip1Price:SetText(PassConfig.config.vip1Price)
    self.stVip2NameText:SetText(Lang:getString("gui.pass.vip.name2"))
    self.stVip2Info:SetText(Lang:getString("gui.pass.vip.info2"))
    self.stVip2Price:SetText(PassConfig.config.vip2Price)
    self.stMarkText:SetText(Lang:getString("gui.pass.vip.recommend"))
    self.stMark2Text:SetText("+Lv." .. PassConfig.config.vip2UpLv)
    self:setMainActorUI()
    self:setRewardList()
end

---@private
function UIPassVipBuyLayout:initEvent()
    self.btnVip1Buy:registerEvent(GUIEvent.ButtonClick, function()
        self.pass:tryUpgradeVip(1)
    end)
    self.btnVip2Buy:registerEvent(GUIEvent.ButtonClick, function()
        self.pass:tryUpgradeVip(2)
    end)
    self.btnBack:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)

    self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveStart, function()
        self.isStopMove = true
    end)
    self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveEnd, function()
        self.isStopMove = false
    end)
    self.lvRewardList.root:registerEvent(GUIEvent.ScrollCardClick, function()
        self.isStopMove = false
    end)
    self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveChange, function(events)
        local scroll = events.offset
        local size = self.rewardAdapter:getItemWidth()[2] + 20
        if scroll > 7 then
            local last = table.remove(self.rewards, #self.rewards)
            table.insert(self.rewards, 1, last)
            self.rewardAdapter:setData(self.rewards)
            scroll = scroll - size
            self.lvRewardList.root:SetScrollOffset(scroll)
        end
    end)

    self.pass.info:addKeyObserver(Define.PassInfoKey.VIP, function()
        self:hide()
    end)
    self.pass.info:addKeyObserver(Define.PassInfoKey.Season, function()
        self:setRewardList()
    end)
end

function UIPassVipBuyLayout:setMainActorUI()
    local cfg = self.pass:getSeasonCfg()
    if not cfg or not cfg.mainReward then
        return
    end
    self.awActor:SetWidth({ 0, 200 })
    RewardConfig:setRewardDetailUI(cfg.mainReward, nil, nil, nil, self.awActor, self.llActorSlide)
end

---@private
function UIPassVipBuyLayout:setRewardList()
    if not self.rewardAdapter then
        self.lvRewardList = IGUIListView.new("PassVipBuy-RewardListItems", self.llShow, nil, Orientation.Horizontal)
        self.lvRewardList:setItemSpace(20)
        ---@type PassVipRewardAdapter
        self.rewardAdapter = UIHelper.newGameAdapter("PassVipRewardAdapter")
        self.lvRewardList:setAdapter(self.rewardAdapter)
    end
    self.rewards = self.pass:getGrandPriceRewardList(true)
    self.rewardAdapter:setData(self.rewards)
end

function UIPassVipBuyLayout:onTick()
    if next(self.rewards) == nil then
        return
    end
    local scroll = self.lvRewardList.root:GetScrollOffset()
    local size = self.rewardAdapter:getItemWidth()[2] + 20
    while ((-scroll) > size)
    do
        local first = table.remove(self.rewards, 1)
        table.insert(self.rewards, first)
        self.rewardAdapter:setData(self.rewards)
        scroll = scroll + size
        self.lvRewardList.root:SetScrollOffset(scroll)
    end

    if not self.isStopMove then
        self.lvRewardList.root:SetScrollOffset(scroll - 1)
    end
end

return UIPassVipBuyLayout
