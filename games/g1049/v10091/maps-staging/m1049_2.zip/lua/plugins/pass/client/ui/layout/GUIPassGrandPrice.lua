---@class UIPassGrandPriceLayout : IGUILayout
local UIPassGrandPriceLayout = class("UIPassGrandPriceLayout", IGUILayout)

---@private
function UIPassGrandPriceLayout:ctor(parent)
	self.super.ctor(self, "PassGrandPrice.json", parent)
end

---@private
function UIPassGrandPriceLayout:isDelayLoad()
	return true
end

---@private
function UIPassGrandPriceLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIPassGrandPriceLayout:initCreateEvent()

end

---@private
function UIPassGrandPriceLayout:onLoad()
	self.btnClose = self:getChildWindow("PassGrandPrice-Close", GUIType.Button)
	self.stTitle = self:getChildWindow("PassGrandPrice-Title", GUIType.StaticText)
	self.stFreePriceText = self:getChildWindow("PassGrandPrice-FreePriceText", GUIType.StaticText)
	self.llFreePriceList = self:getChildWindow("PassGrandPrice-FreePriceList", GUIType.Layout)
	self.stPayPriceText = self:getChildWindow("PassGrandPrice-PayPriceText", GUIType.StaticText)
	self.llPayPriceList = self:getChildWindow("PassGrandPrice-PayPriceList", GUIType.Layout)
	self.btnBuy = self:getChildWindow("PassGrandPrice-Buy", GUIType.Button)
	self:initView()
	self:initEvent()
end

---@private
function UIPassGrandPriceLayout:initView()
	self.pass = PlayerManager:getClientPlayer().pass
	self.stTitle:SetText(Lang:getString("gui.pass.grand.price.title"))
	self.stFreePriceText:SetText(Lang:getString("gui.pass.reward.normal"))
	self.stPayPriceText:SetText(Lang:getString("gui.pass.reward.vip"))
	self.btnBuy:SetText(Lang:getString("gui.pass.vip.buy"))
	self:setRewardList()
end

---@private
function UIPassGrandPriceLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		UIHelper.showGameGUILayout("GUIPassVipBuy")
		self:hide()
	end)
	self.pass.info:addKeyObserver(Define.PassInfoKey.Season, function()
		self:setRewardList()
	end)
end

function UIPassGrandPriceLayout:onShow()
	self.btnBuy:SetVisible(not self.pass:isVip())
end

function UIPassGrandPriceLayout:setRewardList()
	if not self.freeRewardAdapter then
		self.lvFreeRewardList = IGUIListView.new("PassGrandPrice-FreePriceListItems", self.llFreePriceList, nil, Orientation.Horizontal)
		self.lvFreeRewardList:setItemSpace(1)
		---@type PassGrandPriceAdapter
		self.freeRewardAdapter = UIHelper.newGameAdapter("PassGrandPriceAdapter")
		self.freeRewardAdapter:setIsPay(false)
		self.lvFreeRewardList:setAdapter(self.freeRewardAdapter)
	end
	if not self.payRewardAdapter then
		self.lvPayRewardList = IGUIListView.new("PassGrandPrice-PayPriceListItems", self.llPayPriceList, nil, Orientation.Horizontal)
		self.lvPayRewardList:setItemSpace(1)
		---@type PassGrandPriceAdapter
		self.payRewardAdapter = UIHelper.newGameAdapter("PassGrandPriceAdapter")
		self.freeRewardAdapter:setIsPay(true)
		self.lvPayRewardList:setAdapter(self.payRewardAdapter)
	end
	self.freeRewardAdapter:setData(self.pass:getGrandPriceRewardList(false))
	self.payRewardAdapter:setData(self.pass:getGrandPriceRewardList(true))
end

return UIPassGrandPriceLayout
