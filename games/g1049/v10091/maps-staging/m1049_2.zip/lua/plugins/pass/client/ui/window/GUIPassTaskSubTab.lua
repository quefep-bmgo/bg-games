---@class GUIPassTaskSubTabWindow : IGUIWindow
local GUIPassTaskSubTabWindow = class("GUIPassTaskSubTabWindow", IGUIWindow)

---@private
function GUIPassTaskSubTabWindow:ctor(...)
    self.super.ctor(self, "PassTaskSubTab.json", ...)
end

---@private
function GUIPassTaskSubTabWindow:onLoad()
    self.stText = self:getChildWindowByName("PassTaskSubTab-Text", GUIType.StaticText)
    self.siArrow = self:getChildWindowByName("PassTaskSubTab-Arrow", GUIType.StaticImage)
    self.llTag = self:getChildWindowByName("PassTaskSubTab-Tag", GUIType.Layout)
    self.siLock = self:getChildWindowByName("PassTaskSubTab-Lock", GUIType.StaticImage)
    self.llTime = self:getChildWindowByName("PassTaskSubTab-Time", GUIType.Layout)
    self.stTimeText = self:getChildWindowByName("PassTaskSubTab-TimeText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassTaskSubTabWindow:initView()
    self.pass = PlayerManager:getClientPlayer().pass
    ---@type UIPassLayout
    local GUIPass = UIHelper.newGameGUILayout("GUIPass")
    self.wTaskPage = GUIPass:getTaskPage()
end

---@private
function GUIPassTaskSubTabWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        local time = os.time() - self.pass:getSeasonCfg().startDate
        if self.data.startTime and time < self.data.startTime then
            return
        end
        self.wTaskPage:setSelectTab(self.data.key)
    end)
end

---@param data PassTaskTabData
function GUIPassTaskSubTabWindow:onDataChanged(data)
    self.data = data
    self.stText:SetText(Lang:getString(data.lang))
    local cfg = self.pass:getSeasonCfg()
    local time = os.time() - (cfg and cfg.startDate or 0)
    if data.startTime and time < data.startTime then
        self.llTime:SetVisible(true)
        self.siLock:SetVisible(true)
        self.llTag:SetVisible(false)
        self.siArrow:SetVisible(false)
        local countdown = data.startTime - time
        local day = math.floor(countdown / DateUtil.getDaySeconds())
        local hour = math.floor((countdown - day * DateUtil.getDaySeconds()) / 3600)
        self.stTimeText:SetText(Lang:format("gui.pass.time", day, hour))
        self.stText:SetTextColor({ 83 / 255, 64 / 255, 105 / 255, 1 })
    else
        self.llTime:SetVisible(false)
        self.siLock:SetVisible(false)
        self.llTag:SetVisible(true)
        if self.wTaskPage:getCurTabKey() == data.key then
            self.siArrow:SetVisible(true)
            self.stText:SetTextColor({ 246 / 255, 198 / 255, 74 / 255, 1 })
            self.llTag:SetDrawColor({ 246 / 255, 198 / 255, 74 / 255, 1 })
        else
            self.siArrow:SetVisible(false)
            self.stText:SetTextColor(Color.WHITE)
            self.llTag:SetDrawColor(Color.WHITE)
        end
    end
end

return GUIPassTaskSubTabWindow
