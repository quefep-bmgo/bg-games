---@class UIPassLayout : IGUILayout
local UIPassLayout = class("UIPassLayout", IGUILayout)
---@type ReportUtil
local ReportUtil = T(Global, "ReportUtil")

local PageType = {
    Reward = 1,
    Task = 2,
    Shop = 3,
}

local PageGUIName = {
    [PageType.Reward] = "GUIPassPageReward",
    [PageType.Task] = "GUIPassPageTask",
    [PageType.Shop] = "GUIPassPageReward",
}

---@private
function UIPassLayout:ctor(parent)
    self.super.ctor(self, "Pass.json", parent)
end

---@private
function UIPassLayout:isDelayLoad()
    return true
end

---@private
function UIPassLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIPassLayout:initCreateEvent()

end

---@private
function UIPassLayout:onLoad()
    self.llContent = self:getChildWindow("Pass-Content", GUIType.Layout)
    self.siTitle = self:getChildWindow("Pass-Title", GUIType.StaticImage)
    self.btnBack = self:getChildWindow("Pass-Back", GUIType.Button)
    self.stTitleSeason = self:getChildWindow("Pass-TitleSeason", GUIType.StaticText)
    self.siTitleSeasonT = self:getChildWindow("Pass-TitleSeasonT", GUIType.StaticImage)
    self.llTab = self:getChildWindow("Pass-Tab", GUIType.Layout)
    self.rbTabReward = self:getChildWindow("Pass-TabReward", GUIType.RadioButton)
    self.rbTabTask = self:getChildWindow("Pass-TabTask", GUIType.RadioButton)
    self.rbTabShop = self:getChildWindow("Pass-TabShop", GUIType.RadioButton)
    self:initView()
    self:initEvent()
end

---@private
function UIPassLayout:initView()
    self.pass = PlayerManager:getClientPlayer().pass
    self:setSeasonTitle(self.pass.info:getValue(Define.PassInfoKey.Season))
    self.rbTabReward:SetText(Lang:getString("gui.pass.tab.reward"))
    self.rbTabTask:SetText(Lang:getString("gui.pass.tab.task"))
    self.rbTabShop:SetText(Lang:getString("gui.pass.tab.shop"))
    Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", self.rbTabReward, Define.RedDotKey.PassReward, nil, {
        offset = VectorUtil.newVector2(-5, -5),
        customImage = "set:common.json image:img_0_red_dot"
    })
    Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", self.rbTabTask, Define.RedDotKey.PassTask, nil, {
        offset = VectorUtil.newVector2(-5, -5),
        customImage = "set:common.json image:img_0_red_dot"
    })
    ---@type GUICurrencyGroupWindow
    self.wCurrencyGroup = UIHelper.newGameGUIWindow("GUICurrencyGroup")
    self.wCurrencyGroup:onDataChanged({ CurrencyId.PassScore, CurrencyId.Diamonds })
    self.siTitle:AddChildWindow(self.wCurrencyGroup.root)
    ---@type table<string, IGUIWindow>
    self.wPages = {}
end

---@private
function UIPassLayout:initEvent()
    self.btnBack:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.rbTabReward:registerEvent(GUIEvent.RadioStateChanged, function()
        self:tryShowPage(self.rbTabReward, PageType.Reward)
    end)
    self.rbTabTask:registerEvent(GUIEvent.RadioStateChanged, function()
        self:tryShowPage(self.rbTabTask, PageType.Task)
    end)
    self.rbTabShop:registerEvent(GUIEvent.RadioStateChanged, function()
        self:tryShowPage(self.rbTabShop, PageType.Shop)
    end)
    self.pass.info:addKeyObserver(Define.PassInfoKey.Season, function(_, _, value)
        if value == 0 then
            self:hide()
            CustomDialog.builder()
                        .setContentText(Lang:getString("gui.pass.season.end"))
                        .setHideLeftButton()
                        .show()
        else
            self:setSeasonTitle(value)
            self:addTimer(LuaTimer:scheduleTicker(function()
                self.rbTabReward:SetSelected(false)
                self.rbTabReward:SetSelected(true)
            end, 1, 1))
        end
    end)
end

function UIPassLayout:show(...)
    local pass = PlayerManager:getClientPlayer().pass
    if not pass:getSeasonCfg() then
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui.pass.season.no.start"))
                    .setHideLeftButton()
                    .show()
        return
    end
    RootGuiLayout.Instance():hideAllChildren()
    self.super.show(self, ...)
    self.rbTabReward:SetSelected(false)
    self.rbTabReward:SetSelected(true)
end

function UIPassLayout:onHide()
    RootGuiLayout.Instance():showMainControl()
    for _, page in pairs(self.wPages) do
        if page.onHide then
            page:onHide()
        end
    end
end

function UIPassLayout:onTick()
    self.wCurrencyGroup:onTick()
end

---@private
function UIPassLayout:setSeasonTitle(season)
    self.stTitleSeason:SetText(season)
    self.siTitleSeasonT:SetXPosition({ 0, self.stTitleSeason:GetTextWidth() + 120 })
end

---@private
---@param rbTab GUIRadioButton
function UIPassLayout:tryShowPage(rbTab, type)
    if not rbTab:IsSelected() then
        rbTab:SetTextColor({ 147 / 255, 92 / 255, 115 / 255, 1 })
    else
        rbTab:SetTextColor({ 122 / 255, 85 / 255, 51 / 255, 1 })
        local name = PageGUIName[type]
        if not self.wPages[name] then
            local page = UIHelper.newGameGUIWindow(name)
            self.llContent:AddChildWindow(page.root)
            self.wPages[name] = page
        end
        for key, page in pairs(self.wPages) do
            page:setVisible(key == name)
        end
        if type == PageType.Reward then
            ---@type GUIPassPageRewardWindow
            local page = self.wPages[name]
            page:setShowReward()
        elseif type == PageType.Task then
            ---@type GUIPassPageTaskWindow
            local page = self.wPages[name]
            page:setShowTask()
        elseif type == PageType.Shop then
            ---@type GUIPassPageRewardWindow
            local page = self.wPages[name]
            page:setShowShop()
            ReportUtil.clickPassButton("shop")
        end
    end
end

---@return GUIPassPageRewardWindow
function UIPassLayout:getRewardPage()
    return self.wPages[PageGUIName[PageType.Reward]]
end

---@return GUIPassPageTaskWindow
function UIPassLayout:getTaskPage()
    return self.wPages[PageGUIName[PageType.Task]]
end

return UIPassLayout
