---@class GUIPassTaskTabWindow : IGUIWindow
local GUIPassTaskTabWindow = class("GUIPassTaskTabWindow", IGUIWindow)

---@private
function GUIPassTaskTabWindow:ctor(...)
    self.super.ctor(self, "PassTaskTab.json", ...)
end

---@private
function GUIPassTaskTabWindow:onLoad()
    self.stText = self:getChildWindowByName("PassTaskTab-Text", GUIType.StaticText)
    self.siArrow = self:getChildWindowByName("PassTaskTab-Arrow", GUIType.StaticImage)
    self.llSelected = self:getChildWindowByName("PassTaskTab-Selected", GUIType.Layout)
    self.ltChild = self:getChildWindowByName("PassTaskTab-Child", GUIType.List)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassTaskTabWindow:initView()
    self.pass = PlayerManager:getClientPlayer().pass
    ---@type UIPassLayout
    local GUIPass = UIHelper.newGameGUILayout("GUIPass")
    self.wTaskPage = GUIPass:getTaskPage()
end

---@private
function GUIPassTaskTabWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if not self.lvChild then
            self.wTaskPage:setSelectTab(self.data.key)
        else
            self:trySelectChildTab()
        end
    end)
end

function GUIPassTaskTabWindow:trySelectChildTab()
    local key
    local time = os.time() - self.pass:getSeasonCfg().startDate
    for _, child in pairs(self.data.child) do
        if child.startTime and time < child.startTime then
            break
        end
        key = child.key
    end
    if key then
        self.wTaskPage:setSelectTab(key)
    end
end

---@private
function GUIPassTaskTabWindow:tryCreateChild()
    if not self.data.child or not next(self.data.child) then
        return
    end
    if self.lvChild then
        ---@param item GUIPassTaskSubTabWindow
        for _, item in pairs(self.lvChild.items) do
            item:onDataChanged(item.data)
        end
        return
    end
    self.lvChild = IGUIListView.new("", self.root, self.ltChild, Orientation.Vertical)
    local height = #self.data.child * 69
    self.lvChild:setHeight({ 0, height })
    self.root:SetHeight({ 0, height + 58 })
    for _, child in pairs(self.data.child) do
        ---@type GUIPassTaskSubTabWindow
        local tab = UIHelper.newGameGUIWindow("GUIPassTaskSubTab")
        tab:onDataChanged(child)
        self.lvChild:addItem(tab)
        Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", tab.root, child.key, Define.RedDotKey.PassTask, {
            offset = VectorUtil.newVector2(-40, 0),
            customImage = "set:common.json image:img_0_red_dot"
        })
    end
end

---@param data PassTaskTabData
function GUIPassTaskTabWindow:onDataChanged(data)
    self.data = data
    self.stText:SetText(Lang:getString(data.lang))
    self:tryCreateChild()
    if self.wTaskPage:getCurTabKey() == data.key then
        self.siArrow:SetVisible(true)
        self.llSelected:SetVisible(true)
        self.stText:SetTextColor({ 246 / 255, 198 / 255, 74 / 255, 1 })
    else
        self.siArrow:SetVisible(false)
        self.llSelected:SetVisible(false)
        self.stText:SetTextColor({ 157 / 255, 125 / 255, 175 / 255, 1 })
    end
end

return GUIPassTaskTabWindow
