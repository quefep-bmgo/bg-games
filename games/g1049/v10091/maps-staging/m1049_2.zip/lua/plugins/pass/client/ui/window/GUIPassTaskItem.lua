---@class GUIPassTaskItemWindow : IGUIWindow
local GUIPassTaskItemWindow = class("GUIPassTaskItemWindow", IGUIWindow)
---@type TaskConfig
local TaskConfig = T(Global, "TaskConfig")

---@private
function GUIPassTaskItemWindow:ctor(...)
    self.super.ctor(self, "PassTaskItem.json", ...)
end

---@private
function GUIPassTaskItemWindow:onLoad()
    self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.siTaskIcon = self:getChildWindowByName("PassTaskItem-TaskIcon", GUIType.StaticImage)
    self.siTaskTag = self:getChildWindowByName("PassTaskItem-TaskTag", GUIType.StaticImage)
    self.stExpText = self:getChildWindowByName("PassTaskItem-ExpText", GUIType.StaticText)
    self.stDesc = self:getChildWindowByName("PassTaskItem-Desc", GUIType.StaticText)
    self.pbProgress = self:getChildWindowByName("PassTaskItem-Progress", GUIType.ProgressBar)
    self.stProgressText = self:getChildWindowByName("PassTaskItem-ProgressText", GUIType.StaticText)
    self.btnGet = self:getChildWindowByName("PassTaskItem-Get", GUIType.Button)
    self.stStatusText = self:getChildWindowByName("PassTaskItem-StatusText", GUIType.StaticText)
    self.llStatusLine = self:getChildWindowByName("PassTaskItem-StatusLine", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassTaskItemWindow:initView()
    self.btnGet:SetText(Lang:getString("gui.pass.task.receive"))
end

---@private
function GUIPassTaskItemWindow:initEvent()
    self.btnGet:registerEvent(GUIEvent.ButtonClick, function()
        self.data:tryReceive()
    end)
    self.stStatusText:registerEvent(GUIEvent.Click, function()
        UIHelper.hideGameGUILayout("GUIPass")
    end)
end

---@param data TaskLink
function GUIPassTaskItemWindow:onDataChanged(data)
    self.data = data
    local cfg = data:cfg()
    if not cfg then
        return
    end
    TaskConfig:setTaskIcon(self.siTaskIcon, cfg)
    TaskConfig:setTaskDesc(self.stDesc, cfg)
    self.stExpText:SetText(cfg.rewardCount)
    self.pbProgress:SetProgress(data.value / cfg.value)
    self.stProgressText:SetText(data.value .. "/" .. cfg.value)
    self.btnGet:SetVisible(data.status == Define.TaskStatus.Finished)
    self.stStatusText:SetVisible(data.status ~= Define.TaskStatus.Finished)
    if data.status == Define.TaskStatus.Doing then
        self.stStatusText:SetText(Lang:getString("gui.pass.task.finish"))
        self.stStatusText:SetTextColor({ 177 / 255, 219 / 255, 59 / 255, 1 })
        self.llStatusLine:SetVisible(true)
    elseif data.status == Define.TaskStatus.Received then
        self.stStatusText:SetText(Lang:getString("gui.pass.task.complete"))
        self.stStatusText:SetTextColor({ 95 / 255, 65 / 255, 114 / 255, 1 })
        self.llStatusLine:SetVisible(false)
    end
    self.stStatusText:SetWidth({ 0, self.stStatusText:GetTextWidth() })
    if data.status == Define.TaskStatus.Received then
        self.llRoot:SetBackImage("set:passes.json image:img_0_task03")
    else
        self.llRoot:SetBackImage("set:passes.json image:img_0_task01")
    end
    self.siTaskTag:SetImage(Define.TaskTagIcon[cfg.type] or "")
end

return GUIPassTaskItemWindow
