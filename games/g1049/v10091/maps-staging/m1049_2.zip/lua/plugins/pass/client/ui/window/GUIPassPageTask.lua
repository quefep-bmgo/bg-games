---@class GUIPassPageTaskWindow : IGUIWindow
local GUIPassPageTaskWindow = class("GUIPassPageTaskWindow", IGUIWindow)
---@type PassConfig
local PassConfig = T(Global, "PassConfig")

---@private
function GUIPassPageTaskWindow:ctor(...)
    self.super.ctor(self, "PassPageTask.json", ...)
end

---@private
function GUIPassPageTaskWindow:onLoad()
    self.llTask = self:getChildWindowByName("PassPageTask-Task", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassPageTaskWindow:initView()
    self.pass = PlayerManager:getClientPlayer().pass
    self.info = self.pass.info
end

---@private
function GUIPassPageTaskWindow:initEvent()
    self.info:addKeyObserver(Define.PassInfoKey.Season, function()
        self:trySelectFirstTab()
    end)
end

---@param data table
function GUIPassPageTaskWindow:onDataChanged(data)

end

function GUIPassPageTaskWindow:setShowTask()
    self:tryInitTaskList()
    self:tryInitTaskTab()
    self:addTaskObserver()
end

---@private
function GUIPassPageTaskWindow:tryInitTaskTab()
    if self.lvTaskTab then
        return
    end
    self.lvTaskTab = IGUIListView.new("PassPageTask-TaskTab", self.root)
    self.lvTaskTab:setArea({ 0, 0 }, { 0, 100 }, { 0, 367 }, { 1, -120 })
    for _, task in pairs(PassConfig.config.tasks) do
        ---@type GUIPassTaskTabWindow
        local tab = UIHelper.newGameGUIWindow("GUIPassTaskTab")
        tab:onDataChanged(task)
        self.lvTaskTab:addItem(tab)
        if task.key then
            Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", tab.root, task.key, Define.RedDotKey.PassTask, {
                offset = VectorUtil.newVector2(-40, 0),
                customImage = "set:common.json image:img_0_red_dot"
            })
        end
    end
    self:trySelectFirstTab()
end

---@private
function GUIPassPageTaskWindow:tryInitTaskList()
    if self.lvTaskList then
        self:updateTaskList()
        return
    end
    self.lvTaskList = IGUIListView.new("PassPageTask-TaskList", self.llTask)
    self.lvTaskList:setArea({ 0, 14 }, { 0, 12 }, { 1, -28 }, { 1, -24 })
    self.lvTaskList:setItemSpace(7)
    ---@type PassTaskItemAdapter
    self.taskItemAdapter = UIHelper.newGameAdapter("PassTaskItemAdapter")
    self.lvTaskList:setAdapter(self.taskItemAdapter)
    ---@param task TaskLink
    self.taskObserver = function(_, task)
        self:updateTaskList()
    end
end

---@private
function GUIPassPageTaskWindow:trySelectFirstTab()
    for _, task in pairs(PassConfig.config.tasks) do
        if task.key then
            self:setSelectTab(task.key)
            return
        end
        if task.child then
            for _, child in pairs(task.child) do
                if child.key then
                    self:setSelectTab(child.key)
                    return
                end
            end
        end
    end
end

function GUIPassPageTaskWindow:setSelectTab(key)
    if self.curTabKey == key then
        return
    end
    self:removeTaskObserver()
    self.curTabKey = key
    self:addTaskObserver()
    self:updateTaskList()
    self:notifyTabUIUpdate()
end

function GUIPassPageTaskWindow:getCurTabKey()
    return self.curTabKey
end

---@private
function GUIPassPageTaskWindow:notifyTabUIUpdate()
    ---@param item GUIPassTaskTabWindow
    for _, item in pairs(self.lvTaskTab.items) do
        item:onDataChanged(item.data)
    end
end

---@private
function GUIPassPageTaskWindow:removeTaskObserver()
    local controller = PlayerManager:getClientPlayer().taskController
    local group = controller:getTaskGroup(self.curTabKey)
    if not group then
        return
    end
    group:clearObserver(self.taskObserver)
end

---@private
function GUIPassPageTaskWindow:addTaskObserver()
    local controller = PlayerManager:getClientPlayer().taskController
    local group = controller:getTaskGroup(self.curTabKey)
    if not group then
        return
    end
    group:addObserver(self.taskObserver)
end

---@private
function GUIPassPageTaskWindow:updateTaskList()
    local controller = PlayerManager:getClientPlayer().taskController
    local group = controller:getTaskGroup(self.curTabKey)
    if not group then
        return
    end
    local tasks = {}
    for _, taskLink in pairs(group.tasks) do
        table.insert(tasks, taskLink)
    end
    table.sort(tasks, function(a, b)
        if a.status == b.status then
            return a.index < b.index
        end
        if a.status == Define.TaskStatus.Finished then
            return true
        end
        if b.status == Define.TaskStatus.Finished then
            return false
        end
        return a.status < b.status
    end)
    self.taskItemAdapter:setData(tasks)
end

function GUIPassPageTaskWindow:onHide()
    self:removeTaskObserver()
end

return GUIPassPageTaskWindow
