---@class GUIPassPageRewardWindow : IGUIWindow
local GUIPassPageRewardWindow = class("GUIPassPageRewardWindow", IGUIWindow)
---@type PassRewardConfig
local PassRewardConfig = T(Global, "PassRewardConfig")
---@type PassShopItemConfig
local PassShopItemConfig = T(Global, "PassShopItemConfig")
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")
---@type LuckyChestRewardConfig
local LuckyChestRewardConfig = T(Global, "LuckyChestRewardConfig")
---@type ReportUtil
local ReportUtil = T(Global, "ReportUtil")

local ShowType = {
    Reward = 1,
    Shop = 2,
}

---@private
function GUIPassPageRewardWindow:ctor(...)
    self.super.ctor(self, "PassPageReward.json", ...)
end

---@private
function GUIPassPageRewardWindow:onLoad()
    self.siDesc = self:getChildWindowByName("PassPageReward-Desc", GUIType.StaticImage)
    self.btnLuckyChestDetail = self:getChildWindowByName("PassPageReward-LuckyChestDetail", GUIType.Button)
    self.siImage = self:getChildWindowByName("PassPageReward-Image", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("PassPageReward-Effect", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("PassPageReward-Name", GUIType.StaticText)
    self.stText = self:getChildWindowByName("PassPageReward-Text", GUIType.StaticText)
    self.awActor = self:getChildWindowByName("PassPageReward-Actor", GUIType.ActorWindow)
    self.llActorSlide = self:getChildWindowByName("PassPageReward-ActorSlide", GUIType.Layout)
    self.btnVipBuy = self:getChildWindowByName("PassPageReward-VipBuy", GUIType.Button)
    self.btnShopBuy = self:getChildWindowByName("PassPageReward-ShopBuy", GUIType.Button)
    self.siPriceIcon = self:getChildWindowByName("PassPageReward-PriceIcon", GUIType.StaticImage)
    self.stPriceText = self:getChildWindowByName("PassPageReward-PriceText", GUIType.StaticText)
    self.btnShopBuy10 = self:getChildWindowByName("PassPageReward-ShopBuy10", GUIType.Button)
    self.siPriceIcon10 = self:getChildWindowByName("PassPageReward-PriceIcon10", GUIType.StaticImage)
    self.stPriceText10 = self:getChildWindowByName("PassPageReward-PriceText10", GUIType.StaticText)
    self.pbExpProgress = self:getChildWindowByName("PassPageReward-ExpProgress", GUIType.ProgressBar)
    self.stExpText = self:getChildWindowByName("PassPageReward-ExpText", GUIType.StaticText)
    self.stLevel = self:getChildWindowByName("PassPageReward-Level", GUIType.StaticText)
    self.stLevelTitle = self:getChildWindowByName("PassPageReward-LevelTitle", GUIType.StaticText)
    self.stTimeText = self:getChildWindowByName("PassPageReward-TimeText", GUIType.StaticText)
    self.llList = self:getChildWindowByName("PassPageReward-List", GUIType.Layout)
    self.llListItems = self:getChildWindowByName("PassPageReward-ListItems", GUIType.Layout)
    self.llListLeft = self:getChildWindowByName("PassPageReward-ListLeft", GUIType.Layout)
    self.stListLeftUpText = self:getChildWindowByName("PassPageReward-ListLeftUpText", GUIType.StaticText)
    self.btnListLeftDownIcon = self:getChildWindowByName("PassPageReward-ListLeftDownIcon", GUIType.Button)
    self.siListLeftDownLock = self:getChildWindowByName("PassPageReward-ListLeftDownLock", GUIType.StaticImage)
    self.stListLeftDownText = self:getChildWindowByName("PassPageReward-ListLeftDownText", GUIType.StaticText)
    self.siListRight = self:getChildWindowByName("PassPageReward-ListRight", GUIType.StaticImage)
    self.btnListBack = self:getChildWindowByName("PassPageReward-ListBack", GUIType.Button)
    self.btnGetAll = self:getChildWindowByName("PassPageReward-GetAll", GUIType.Button)
    self.llShop = self:getChildWindowByName("PassPageReward-Shop", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassPageRewardWindow:initView()
    self.pass = PlayerManager:getClientPlayer().pass
    self.info = self.pass.info
    self.stLevelTitle:SetText(Lang:getString("gui.pass.level.title"))
    self.stListLeftUpText:SetText(Lang:getString("gui.pass.reward.normal"))
    self.stListLeftDownText:SetText(Lang:getString("gui.pass.reward.vip"))
    self.btnVipBuy:SetText(Lang:getString("gui.pass.vip.buy"))
    self.btnGetAll:SetText(Lang:getString("gui.pass.get.all"))
    self.btnShopBuy10:SetText(Lang:getString("gui.pass.lottery10"))
    self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(CurrencyId.PassScore))
    self.siPriceIcon10:SetImage(PayHelper.getMoneyIcon(CurrencyId.PassScore))
end

---@private
function GUIPassPageRewardWindow:initEvent()
    self.btnLuckyChestDetail:registerEvent(GUIEvent.ButtonClick, function()
        if self.curShowReward then
            local rewards = LuckyChestRewardConfig:getChestRewardCfg(self.curShowReward.realId)
            UIHelper.showGameGUILayout("GUIRewardPreview", rewards)
        end
        ReportUtil.clickPassButton("shop_preview")
    end)
    self.btnVipBuy:registerEvent(GUIEvent.ButtonClick, function()
        UIHelper.showGameGUILayout("GUIPassVipBuy")
        ReportUtil.clickPassButton("vip_buy")
    end)
    self.btnShopBuy:registerEvent(GUIEvent.ButtonClick, function()
        if self.curSelectShopItem then
            self.pass:tryBuyShopItem(self.curSelectShopItem.id, 1)
            self:updateShopUI(self.curSelectShopItem)
        end
    end)
    self.btnShopBuy10:registerEvent(GUIEvent.ButtonClick, function()
        if self.curSelectShopItem then
            self.pass:tryBuyShopItem(self.curSelectShopItem.id, 10)
            self:updateShopUI(self.curSelectShopItem)
        end
    end)
    self.btnListLeftDownIcon:registerEvent(GUIEvent.ButtonClick, function()
        UIHelper.showGameGUILayout("GUIPassGrandPrice")
        ReportUtil.clickPassButton("vip")
    end)
    self.btnListBack:registerEvent(GUIEvent.ButtonClick, function()
        self:tryGoToCurLevelReward()
    end)
    self.btnGetAll:registerEvent(GUIEvent.ButtonClick, function()
        self.pass:tryGetAllReward()
        self:updateRewardUI()
    end)
    self.info:addKeyObserver(Define.PassInfoKey.Level, function()
        self:updateBaseUI()
        self:updateRewardUI()
        self:updateShopUI(self.curSelectShopItem)
    end)
    self.info:addKeyObserver(Define.PassInfoKey.CurExp, function()
        self:updateBaseUI()
    end)
    self.info:addKeyObserver(Define.PassInfoKey.VIP, function(_, _, vip)
        self.btnVipBuy:SetVisible(vip <= 0)
        self.siListLeftDownLock:SetVisible(vip <= 0)
        LuaTimer:scheduleTicker(function()
            self:updateRewardUI()
        end, 1, 1)
    end)
end

---@private
function GUIPassPageRewardWindow:updateBaseUI()
    local season = self.info:getValue(Define.PassInfoKey.Season)
    local level = self.info:getValue(Define.PassInfoKey.Level)
    local curExp = self.info:getValue(Define.PassInfoKey.CurExp)
    self.stLevel:SetText("Lv." .. level)
    local reward = PassRewardConfig:getRewardCfg(season, level)
    if reward then
        self.pbExpProgress:SetProgress(curExp / reward.needExp)
        self.stExpText:SetText(curExp .. "/" .. reward.needExp)
    else
        self.pbExpProgress:SetProgress(1)
        self.stExpText:SetText(curExp .. "/∞")
    end
end

function GUIPassPageRewardWindow:updateRewardUI()
    if self.rewardAdapter then
        self.rewardAdapter:notifyDataChange()
    end
    self:updateGetAllButton()
    self:updateStageRewardUI()
end

---@private
function GUIPassPageRewardWindow:updateGetAllButton()
    self.btnGetAll:SetVisible(self.showType == ShowType.Reward and self.pass:isCanGetAllReward())
end

---@param data table
function GUIPassPageRewardWindow:onDataChanged(data)

end

function GUIPassPageRewardWindow:setShowReward()
    self.showType = ShowType.Reward
    self.btnShopBuy:SetVisible(false)
    self.btnShopBuy10:SetVisible(false)
    self.llShop:SetVisible(false)
    self.stText:SetVisible(true)
    self.btnVipBuy:SetVisible(not self.pass:isVip())
    self.siListLeftDownLock:SetVisible(not self.pass:isVip())
    self.llList:SetVisible(true)
    self:showMainReward()
    self:updateBaseUI()
    self:resetRewardList()
    self:updateTimeUI()
    self:tryGoToCurLevelReward()
end

---@private
function GUIPassPageRewardWindow:showMainReward()
    local cfg = self.pass:getSeasonCfg()
    if not cfg or not cfg.mainReward then
        return
    end
    ---@type GUIPassRewardItemWindow
    local GUIPassRewardItem = UIHelper.requireGUIWindow("GUIPassRewardItem", false)
    GUIPassRewardItem.clearSelected()
    self:showRewardDetail(cfg.mainReward)
end

function GUIPassPageRewardWindow:setShowShop()
    self.showType = ShowType.Shop
    self.btnShopBuy:SetVisible(true)
    self.llShop:SetVisible(true)
    self.btnVipBuy:SetVisible(false)
    self.llList:SetVisible(false)
    self.btnGetAll:SetVisible(false)
    self:updateTimeUI()
    self:resetShopList()
end

---@private
function GUIPassPageRewardWindow:updateTimeUI()
    local cfg = self.pass:getSeasonCfg()
    if not cfg then
        return
    end
    local countdown = cfg.endDate - os.time()
    local day = math.floor(countdown / DateUtil.getDaySeconds())
    local hour = math.floor((countdown - day * DateUtil.getDaySeconds()) / 3600)
    self.stTimeText:SetText(Lang:format("gui.pass.time", day, hour))
end

---@private
function GUIPassPageRewardWindow:resetRewardList()
    if not self.rewardAdapter then
        self.lvRewardList = IGUIListView.new("PassPageReward-RewardListItems", self.llListItems, nil, Orientation.Horizontal)
        ---@type PassRewardAdapter
        self.rewardAdapter = UIHelper.newGameAdapter("PassRewardAdapter")
        self.lvRewardList:setAdapter(self.rewardAdapter)
        self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveChange, function()
            self:updateStageRewardUI()
        end)
    end
    local season = self.info:getValue(Define.PassInfoKey.Season)
    self.rewards = PassRewardConfig:getSeasonRewardCfgs(season) or {}
    self.rewardAdapter:setData(self.rewards)
    self:updateGetAllButton()
end

---@private
function GUIPassPageRewardWindow:resetShopList()
    if not self.shopItemAdapter then
        self.gvShopList = IGUIGridView.new("PassPageReward-ShopListItems", self.llShop)
        self.gvShopList:setConfig(0, 0, 4)
        ---@type PassShopItemAdapter
        self.shopItemAdapter = UIHelper.newGameAdapter("PassShopItemAdapter")
        local itemWidth = self.llShop:GetPixelSize().x / 4
        self.shopItemAdapter:setItemSize(itemWidth)
        self.gvShopList:setAdapter(self.shopItemAdapter)
    end
    local season = self.info:getValue(Define.PassInfoKey.Season)
    self.shopItems = PassShopItemConfig:getShopCfgs(season) or {}
    local first = self.shopItems[1]
    if first and first.reward then
        self:updateShopUI(first)
    end
    self.shopItemAdapter:setData(self.shopItems)
end

---@param cfg PassShopItemConfigData
function GUIPassPageRewardWindow:updateShopUI(cfg)
    if cfg then
        ---@type GUIPassShopItemWindow
        local GUIPassShopItem = UIHelper.requireGUIWindow("GUIPassShopItem", false)
        GUIPassShopItem.setSelectId(cfg.id)
        self:showRewardDetail(cfg.reward)
    end
    if self.shopItemAdapter then
        self.shopItemAdapter:notifyDataChange()
    end
    if cfg then
        self.stPriceText:SetText(cfg.price)
        self.stPriceText10:SetText(cfg.price * 10)
        local level = self.pass.info:getValue(Define.PassInfoKey.Level)
        local times = self.pass:getShopBuyTimes(cfg.id)
        local limit = cfg.limit > 0 and times >= cfg.limit
        local limit10 = cfg.limit > 0 and times + 10 > cfg.limit
        self.btnShopBuy:SetEnabled(level >= cfg.level and not limit)
        self.btnShopBuy10:SetEnabled(level > cfg.level and not limit10)
        if false then
            self.btnShopBuy10:SetVisible(true)
            self.stName:SetYPosition({ 0, -150 })
            self.stText:SetVisible(false)
            self.btnShopBuy:SetYPosition({ 0, -80 })
            self.btnShopBuy:SetText(Lang:getString("gui.pass.lottery1"))
            self.btnShopBuy:SetNormalImage("set:buttons.json image:btn_0_general03")
            self.btnShopBuy:SetPushedImage("set:buttons.json image:btn_0_general03")
        else
            self.btnShopBuy10:SetVisible(false)
            self.stName:SetYPosition({ 0, -120 })
            self.stText:SetVisible(true)
            self.btnShopBuy:SetYPosition({ 0, 28 })
            self.btnShopBuy:SetText(Lang:getString("gui.pass.shop.buy"))
            self.btnShopBuy:SetNormalImage("set:buttons.json image:btn_0_general02")
            self.btnShopBuy:SetPushedImage("set:buttons.json image:btn_0_general02")
        end
        self.curSelectShopItem = cfg
    end
end

---@param reward RewardConfigData
function GUIPassPageRewardWindow:showRewardDetail(reward)
    self.curShowReward = reward
    if reward then
        self.btnLuckyChestDetail:SetVisible(reward.type == Define.RewardType.LuckyChest)
    else
        self.btnLuckyChestDetail:SetVisible(false)
    end
    self.awActor:SetWidth({ 0.5, 0 })
    RewardConfig:setRewardDetailUI(reward, self.siImage, self.stName, self.stText, self.awActor, self.llActorSlide)
end

---@private
function GUIPassPageRewardWindow:updateStageRewardUI()
    if not self.wGrandPriceItem then
        ---@type GUIPassRewardItemWindow
        self.wGrandPriceItem = UIHelper.newGameGUIWindow("GUIPassRewardItem")
        self.wGrandPriceItem:setArea({ 0, 0 }, { 0, 2 }, { 1, 0 }, { 1, 0 })
        self.wGrandPriceItem:setGrandPriceUI()
        self.siListRight:AddChildWindow(self.wGrandPriceItem.root)
    end
    local curOffset = self.lvRewardList.root:GetScrollOffset()
    if self.curOffset == curOffset then
        return
    end
    self.curOffset = curOffset
    local itemWidth = self.rewardAdapter:getItemWidth()[2]
    local firstShowLv = math.min(math.max(2, math.floor(-curOffset / itemWidth) + 2), #self.rewards)
    for index = firstShowLv, #self.rewards do
        local reward = self.rewards[index]
        if reward and reward.stageReward then
            if self.curStageReward == reward then
                break
            end
            self.curStageReward = reward
            self.wGrandPriceItem:onDataChanged(self.curStageReward)
            break
        end
    end
    self:checkBackButtonVisible()
end

---@private
function GUIPassPageRewardWindow:checkBackButtonVisible()
    local level = self.pass.info:getValue(Define.PassInfoKey.Level)
    local minLv, maxLv = 1, 1
    ---@type GUIPassRewardItemWindow
    local first = self.lvRewardList.items[1]
    if first then
        minLv = first.data.level
    end
    ---@type GUIPassRewardItemWindow
    local last = self.lvRewardList.items[#self.lvRewardList.items]
    if last then
        maxLv = last.data.level
    end
    self.btnListBack:SetVisible(level < minLv - 5 or level > maxLv + 5)
end

---@private
function GUIPassPageRewardWindow:tryGoToCurLevelReward()
    local level = self.pass.info:getValue(Define.PassInfoKey.Level)
    local itemWidth = self.rewardAdapter:getItemWidth()[2]
    local offset = -(level * itemWidth - self.llListItems:GetPixelSize().x * 0.5)
    offset = math.min(offset, 0)
    self.rewardAdapter:setScrollOffset(offset)
    self.btnListBack:SetVisible(false)
end

return GUIPassPageRewardWindow
