---@class GUIPassRewardItemWindow : IGUIWindow
local GUIPassRewardItemWindow = class("GUIPassRewardItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")
---@type ReportUtil
local ReportUtil = T(Global, "ReportUtil")
---@type PassRewardConfigData
local SelectReward, SelectIsPay

function GUIPassRewardItemWindow.clearSelected()
    SelectReward = nil
    SelectIsPay = nil
end

---@private
function GUIPassRewardItemWindow:ctor(...)
    self.super.ctor(self, "PassRewardItem.json", ...)
end

---@private
function GUIPassRewardItemWindow:onLoad()
    self.siFreeRewardBg = self:getChildWindowByName("PassRewardItem-FreeRewardBg", GUIType.StaticImage)
    self.siFreeRewardMask = self:getChildWindowByName("PassRewardItem-FreeRewardMask", GUIType.StaticImage)
    self.siFreeRewardIconBg = self:getChildWindowByName("PassRewardItem-FreeRewardIconBg", GUIType.StaticImage)
    self.siFreeRewardIcon = self:getChildWindowByName("PassRewardItem-FreeRewardIcon", GUIType.StaticImage)
    self.stFreeRewardNum = self:getChildWindowByName("PassRewardItem-FreeRewardNum", GUIType.StaticText)
    self.siFreeRewardGet = self:getChildWindowByName("PassRewardItem-FreeRewardGet", GUIType.StaticImage)
    self.siFreeRewardSelect = self:getChildWindowByName("PassRewardItem-FreeRewardSelect", GUIType.StaticImage)
    self.siPayRewardBg = self:getChildWindowByName("PassRewardItem-PayRewardBg", GUIType.StaticImage)
    self.siPayRewardMask = self:getChildWindowByName("PassRewardItem-PayRewardMask", GUIType.StaticImage)
    self.siPayRewardIconBg = self:getChildWindowByName("PassRewardItem-PayRewardIconBg", GUIType.StaticImage)
    self.siPayRewardIcon = self:getChildWindowByName("PassRewardItem-PayRewardIcon", GUIType.StaticImage)
    self.stPayRewardNum = self:getChildWindowByName("PassRewardItem-PayRewardNum", GUIType.StaticText)
    self.siPayRewardGet = self:getChildWindowByName("PassRewardItem-PayRewardGet", GUIType.StaticImage)
    self.siPayRewardSelect = self:getChildWindowByName("PassRewardItem-PayRewardSelect", GUIType.StaticImage)
    self.siExpLine = self:getChildWindowByName("PassRewardItem-ExpLine", GUIType.StaticImage)
    self.siExpLevel = self:getChildWindowByName("PassRewardItem-ExpLevel", GUIType.StaticImage)
    self.stExpLevelText = self:getChildWindowByName("PassRewardItem-ExpLevelText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassRewardItemWindow:initView()
    self.pass = PlayerManager:getClientPlayer().pass
    self.siFreeRewardSelect:SetVisible(false)
    self.siFreeRewardGet:SetVisible(false)
    self.siPayRewardSelect:SetVisible(false)
    self.siPayRewardGet:SetVisible(false)
end

---@private
function GUIPassRewardItemWindow:initEvent()
    self.siFreeRewardBg:registerEvent(GUIEvent.Click, function()
        self:onClickReward(false)
        ReportUtil.clickPassButton("n_" .. self.data.level)
    end)
    self.siPayRewardBg:registerEvent(GUIEvent.Click, function()
        self:onClickReward(true)
        ReportUtil.clickPassButton("v_" .. self.data.level)
    end)
end

function GUIPassRewardItemWindow:onClickReward(isPay)
    self.pass:tryGetReward(self.data.level, isPay)
    local reward
    if isPay then
        reward = self.data.payReward
    else
        reward = self.data.freeReward
    end
    if not reward then
        return
    end
    SelectReward = self.data
    SelectIsPay = isPay
    self:updateSelectReward(reward)
end

function GUIPassRewardItemWindow:setGrandPriceUI()
    self.siFreeRewardBg:SetImage("set:passes.json image:img_0_rewards08")
    self.siPayRewardBg:SetImage("set:passes.json image:img_0_rewards04")
    self.siFreeRewardMask:SetBackgroundColor({ 0, 0, 0, 0 })
    self.siPayRewardMask:SetBackgroundColor({ 0, 0, 0, 0 })
    self.siFreeRewardBg:SetHeight({ 0, 134 })
    self.siFreeRewardIconBg:SetArea({ 0, 0 }, { -0.02, 0 }, { 0, 95 }, { 0, 95 })
    self.siExpLine:SetYPosition({ 0, 134 })
    self.siPayRewardBg:SetHeight({ 0, 198 })
    self.siPayRewardIconBg:SetArea({ 0, 0 }, { -0.06, 0 }, { 0, 95 }, { 0, 95 })
end

---@param reward RewardConfigData
function GUIPassRewardItemWindow:updateSelectReward(reward)
    ---@type UIPassLayout
    local GUIPass = UIHelper.newGameGUILayout("GUIPass")
    local wPage = GUIPass:getRewardPage()
    if wPage then
        wPage:updateRewardUI()
        wPage:showRewardDetail(reward)
    end
end

---@param data PassRewardConfigData
function GUIPassRewardItemWindow:onDataChanged(data)
    self.data = data
    if data.freeReward then
        self.siFreeRewardIconBg:SetVisible(true)
        RewardConfig:setRewardQuality(self.siFreeRewardIconBg, data.freeReward)
        RewardConfig:setRewardImage(self.siFreeRewardIcon, data.freeReward)
        self.stFreeRewardNum:SetText(data.freeCount)
        self.siFreeRewardGet:SetVisible(self.pass:isRewardGet(data.level, false))
        self.siFreeRewardSelect:SetVisible(SelectReward == data and not SelectIsPay)
    else
        self.siFreeRewardIconBg:SetVisible(false)
    end
    if data.payReward then
        self.siPayRewardIconBg:SetVisible(true)
        RewardConfig:setRewardQuality(self.siPayRewardIconBg, data.payReward)
        RewardConfig:setRewardImage(self.siPayRewardIcon, data.payReward)
        self.stPayRewardNum:SetText(data.payCount)
        self.siPayRewardGet:SetVisible(self.pass:isRewardGet(data.level, true))
        self.siPayRewardSelect:SetVisible(SelectReward == data and SelectIsPay)
    else
        self.siPayRewardIconBg:SetVisible(false)
    end
    self.stExpLevelText:SetText(data.level)
    local level = self.pass.info:getValue(Define.PassInfoKey.Level)
    if data.level > level then
        self.siFreeRewardMask:SetVisible(true)
        self.siPayRewardMask:SetVisible(true)
        self.siExpLine:SetImage("")
        self.siExpLevel:SetImage("set:passes.json image:img_0_grade01")
        self.stExpLevelText:SetTextColor(Color.WHITE)
    else
        self.siFreeRewardMask:SetVisible(false)
        self.siPayRewardMask:SetVisible(not self.pass:isVip())
        self.siExpLine:SetImage("set:passes.json image:img_9_progress04")
        self.siExpLevel:SetImage("set:passes.json image:img_0_grade02")
        self.stExpLevelText:SetTextColor({ 72 / 255, 23 / 255, 4 / 255, 1 })
    end
end

return GUIPassRewardItemWindow
