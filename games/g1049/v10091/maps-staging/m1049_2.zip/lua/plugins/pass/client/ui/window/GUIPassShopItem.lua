---@class GUIPassShopItemWindow : IGUIWindow
local GUIPassShopItemWindow = class("GUIPassShopItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

local SelectId

function GUIPassShopItemWindow.setSelectId(selectId)
    SelectId = selectId
end

---@private
function GUIPassShopItemWindow:ctor(...)
    self.super.ctor(self, "PassShopItem.json", ...)
end

---@private
function GUIPassShopItemWindow:onLoad()
    self.siIcon = self:getChildWindowByName("PassShopItem-Icon", GUIType.StaticImage)
    self.stName = self:getChildWindowByName("PassShopItem-Name", GUIType.StaticText)
    self.siLock = self:getChildWindowByName("PassShopItem-Lock", GUIType.StaticImage)
    self.stLockText = self:getChildWindowByName("PassShopItem-LockText", GUIType.StaticText)
    self.stLimit = self:getChildWindowByName("PassShopItem-Limit", GUIType.StaticText)
    self.siSelect = self:getChildWindowByName("PassShopItem-Select", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIPassShopItemWindow:initView()
    self.pass = PlayerManager:getClientPlayer().pass
end

---@private
function GUIPassShopItemWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        self:onClick()
    end)
end

---@private
function GUIPassShopItemWindow:onClick()
    ---@type UIPassLayout
    local GUIPass = UIHelper.newGameGUILayout("GUIPass")
    local wPage = GUIPass:getRewardPage()
    if wPage then
        wPage:updateShopUI(self.data)
    end
end

---@param data PassShopItemConfigData
function GUIPassShopItemWindow:onDataChanged(data)
    self.data = data
    RewardConfig:setRewardImage(self.siIcon, data.reward)
    RewardConfig:setRewardName(self.stName, data.reward)
    local level = self.pass.info:getValue(Define.PassInfoKey.Level)
    self.siLock:SetVisible(level < data.level)
    self.stName:SetVisible(level >= data.level)
    self.stLockText:SetText("Lv." .. data.level)
    self.stLimit:SetVisible(data.limit > 0)
    local times = self.pass:getShopBuyTimes(data.id)
    if times >= data.limit then
        self.stLimit:SetText(TextFormat.colorRed .. times .. "/" .. data.limit)
    else
        self.stLimit:SetText(times .. "/" .. data.limit)
    end
    self.siSelect:SetVisible(data.id == SelectId)
end

return GUIPassShopItemWindow
