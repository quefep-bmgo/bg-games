GMSetting:addTab("好友测试")
GMSetting:addItem("好友测试", "打开好友", "openFriendWin")

function GMHelper:openFriendWin()
    UIHelper.showGameGUILayout("GUIFriends")
end