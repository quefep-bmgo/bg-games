---@class GUIItemContainerWindow : IGUIWindow
local GUIItemContainerWindow = class("GUIItemContainerWindow", IGUIWindow)
---@type ItemContainerMgr
local ItemContainerMgr = T(Global, "ItemContainerMgr")

---@private
---@param parent CGUIWindow
function GUIItemContainerWindow:ctor(parent, ...)
    self.parent = parent
    self.super.ctor(self, "ItemContainer.json", ...)
end

---@private
function GUIItemContainerWindow:onLoad()
    self:initView()
    self:initEvent()
end

---@private
function GUIItemContainerWindow:initView()
    self.gvRoot = DynamicCast.dynamicCastWindow(GUIType.GridView, self.root)
    local name = self.__name .. "-Slots"
    self.gvSlots = IGUIGridView.new(name, nil, self.gvRoot)
    self.parent:AddChildWindow(self.gvRoot)
end

---@private
function GUIItemContainerWindow:initEvent()
    self.observer = function(_, slot)
        if not self.slotAdapter then
            return
        end
        self.slotAdapter:notifyItemDataChange(slot)
    end
end

function GUIItemContainerWindow:initContainer(width, height, itemSize, horSpace, verSpace)
    if width then
        self.gvRoot:SetWidth(type(width) == "number" and { 0, width } or width)
    end
    if height then
        self.gvRoot:SetHeight(type(height) == "number" and { 0, height } or height)
    end
    if self.slotAdapter then
        self.slotAdapter:setView(nil)
    end
    horSpace = horSpace or 0
    verSpace = verSpace or horSpace
    local row = 0
    local totalWidth = self.gvRoot:GetPixelSize().x
    while totalWidth > 0 do
        totalWidth = totalWidth - itemSize
        if totalWidth >= 0 then
            row = row + 1
        end
        totalWidth = totalWidth - horSpace
    end
    self.gvSlots:setConfig(horSpace, verSpace, row)
    ---@type ItemSlotAdapter
    self.slotAdapter = UIHelper.newGameAdapter("ItemSlotAdapter")
    self.slotAdapter:setItemSize(itemSize)
    self.slotAdapter:setContainer(self)
    self.gvSlots:setAdapter(self.slotAdapter)
end

---@param container ItemContainer | string
function GUIItemContainerWindow:setItemContainer(container)
    if type(container) == "string" then
        container = ItemContainerMgr:getItemContainer(container)
    end
    if not container or container == self.container then
        return
    end
    if self.container then
        self.container:clearObserver(self.observer)
    end
    self.container = container
    self:show()
end

---@param itemClickListener fun(slot : GUIItemSlotLuaWindow, event : string)
function GUIItemContainerWindow:setItemClickListener(itemClickListener)
    self.itemClickListener = itemClickListener
end

---@private
---@param slot GUIItemSlotLuaWindow
function GUIItemContainerWindow:onItemSlotClick(slot, event)
    if not self.itemClickListener then
        return
    end
    self.itemClickListener(slot, event)
end

---@private
---@param data ItemSlot[]
function GUIItemContainerWindow:onDataChanged(data)
    if not self.slotAdapter then
        self:initContainer({ 1, 0 }, { 1, 0 }, 62)
    end
    self.slotAdapter:setData(data)
end

function GUIItemContainerWindow:show()
    self.gvRoot:SetVisible(true)
    if self.container then
        self.container:addObserver(self.observer)
        self:onDataChanged(self.container.slots)
    end
end

function GUIItemContainerWindow:hide()
    self.gvRoot:SetVisible(false)
    if self.container then
        self.container:clearObserver(self.observer)
    end
end

function GUIItemContainerWindow:onDestroy()
    if not self.container then
        return
    end
    self.container:clearObserver(self.observer)
end

function GUIItemContainerWindow:tryClickItemSlot(index)
    ---@type GUIItemSlotLuaWindow
    local item = self.gvSlots:getItemByIndex(index)
    if not item then
        return
    end
    if item.itemClickListener then
        item.itemClickListener(item, GUIEvent.Click)
    end
    self:onItemSlotClick(item, GUIEvent.Click)
end

return GUIItemContainerWindow
