---@class GUIItemSlotLuaWindow : IGUIWindow
local GUIItemSlotLuaWindow = class("GUIItemSlotLuaWindow", IGUIWindow)

---@private
function GUIItemSlotLuaWindow:ctor(...)
    self.super.ctor(self, "ItemSlotLua.json", ...)
end

---@private
function GUIItemSlotLuaWindow:onLoad()
    self.llSelect = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.siIcon = self:getChildWindowByName("ItemSlotLua-Icon", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("ItemSlotLua-Count", GUIType.StaticText)
    self.pbDurable = self:getChildWindowByName("ItemSlotLua-Durable", GUIType.ProgressBar)
    self:initView()
    self:initEvent()
end

---@private
function GUIItemSlotLuaWindow:initView()

end

---@param self GUIItemSlotLuaWindow
local function onItemSlotClick(self, type)
    if self.itemClickListener then
        self.itemClickListener(self, type)
    end
    if not self.container then
        return
    end
    self.container:onItemSlotClick(self, type)
end

---@param self GUIItemSlotLuaWindow
local function tryShowItemName(self)
    local slot = self.slot
    if slot.itemId <= 0 then
        return
    end
    UIHelper.showToast(Lang:getItemName(slot.itemId, slot.meta), 3000)
end

---@private
function GUIItemSlotLuaWindow:initEvent()
    self.root:registerEvent(GUIEvent.TouchDown, function()
        onItemSlotClick(self, GUIEvent.TouchDown)
    end)
    self.root:registerEvent(GUIEvent.TouchUp, function()
        tryShowItemName(self)
        onItemSlotClick(self, GUIEvent.Click)
    end)
    self.root:registerEvent(GUIEvent.DoubleClick, function()
        onItemSlotClick(self, GUIEvent.DoubleClick)
    end)
    self.root:registerEvent(GUIEvent.LongTouchStart, function()
        onItemSlotClick(self, GUIEvent.LongTouchStart)
    end)
    self.root:registerEvent(GUIEvent.LongTouchEnd, function()
        onItemSlotClick(self, GUIEvent.LongTouchEnd)
    end)
    self.root:registerEvent(GUIEvent.Release, function()
        onItemSlotClick(self, GUIEvent.LongTouchEnd)
    end)
end

---@param container GUIItemContainerWindow
function GUIItemSlotLuaWindow:setContainer(container)
    self.container = container
end

---@param itemClickListener fun(slot : GUIItemSlotLuaWindow, event : string)
function GUIItemSlotLuaWindow:setItemClickListener(itemClickListener)
    self.itemClickListener = itemClickListener
end

---@private
function GUIItemSlotLuaWindow:hideOldItemUI()
    self.siIcon:SetImage("")
    self.stCount:SetVisible(false)
    self.pbDurable:SetVisible(false)
    self:setSelected(self.selected)
    if self.llMask then
        self.llMask:SetVisible(false)
    end
end

---@param slot ItemSlot
function GUIItemSlotLuaWindow:onDataChanged(slot)
    self.slot = slot
    self.siIcon:SetHexagonImage("", "")
    self.siIcon:SetRenderAsBlock(false)
    if slot.itemId < 0 then
        self:hideOldItemUI()
        self.llSelect:SetBackImage("set:common.json image:img_0_item02")
        return
    end
    local item = Item.getItemById(slot.itemId)
    if not item then
        self:hideOldItemUI()
        return
    end
    self:setSelected(self.selected)
    GuiItemStack.showItemIcon(self.siIcon, slot.itemId, slot.meta, "")
    self.stCount:SetVisible(slot.count > 1)
    self.stCount:SetText(slot.count)
    local maxDamage = item:getMaxDamage()
    if maxDamage > 0 and slot.meta > 0 then
        self.pbDurable:SetVisible(true)
        self.pbDurable:SetProgress((maxDamage - slot.meta) / maxDamage)
    else
        self.pbDurable:SetVisible(false)
    end
    self:checkCreatableMask()
end

---@private
function GUIItemSlotLuaWindow:checkCreatableMask()
    if self.llMask then
        self.llMask:SetVisible(false)
    end
    if self.slot.creatable == nil then
        return
    end
    if not self.slot.creatable and not self.llMask then
        self.llMask = GUIManager:createGUIWindow(GUIType.Layout, "ItemSlotLua-Mask-" .. self.windowId)
        self.llMask:SetArea({ 0, 2 }, { 0, 2 }, { 1, -4 }, { 1, -4 })
        self.llMask:SetBackgroundColor({ 0, 0, 0, 0.5 })
        self.root:AddChildWindow(self.llMask)
    end
    if self.llMask then
        self.llMask:SetVisible(not self.slot.creatable)
    end
end

function GUIItemSlotLuaWindow:setSelected(selected)
    if self.slot.hideBG or self.slot.itemId < 0 then
        self.llSelect:SetBackImage("")
        return
    end
    self.selected = selected
    if selected then
        self.llSelect:SetBackImage("set:backpack.json image:img_0_current03")
    else
        self.llSelect:SetBackImage("set:common.json image:img_0_item03")
    end
end

return GUIItemSlotLuaWindow
