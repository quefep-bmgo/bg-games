---@class UIFurnaceLayout : IGUILayout
local UIFurnaceLayout = class("UIFurnaceLayout", IGUILayout)
---@type ItemContainerMgr
local ItemContainerMgr = T(Global, "ItemContainerMgr")
---@type ItemContainerUtil
local ItemContainerUtil = T(Global, "ItemContainerUtil")
---@type FurnaceConfig
local FurnaceConfig = T(Global, "FurnaceConfig")
---@type FurnacePkSender
local FurnacePkSender = T(Global, "PidPacketSender")

---@private
function UIFurnaceLayout:ctor(parent)
    self.super.ctor(self, "Furnace.json", parent)
end

---@private
function UIFurnaceLayout:isDelayLoad()
    return true
end

---@private
function UIFurnaceLayout:onCreate()
    self.burnTime = -1
    self.material = ItemContainerMgr:createContainer("material", 0)
    self.fuel = ItemContainerMgr:createContainer("fuel", 0)
    self:initCreateEvent()
end

---@private
function UIFurnaceLayout:initCreateEvent()
end

---@private
function UIFurnaceLayout:isShowAnim()
    return false
end

---@private
function UIFurnaceLayout:onLoad()
    self.stTitleText = self:getChildWindow("Furnace-TitleText", GUIType.StaticText)
    self.siClose = self:getChildWindow("Furnace-Close", GUIType.StaticImage)
    self.stMaterialText = self:getChildWindow("Furnace-MaterialText", GUIType.StaticText)
    self.stFuelText = self:getChildWindow("Furnace-FuelText", GUIType.StaticText)
    self.stOutputText = self:getChildWindow("Furnace-OutputText", GUIType.StaticText)
    self.siBurnFlame = self:getChildWindow("Furnace-BurnFlame", GUIType.StaticImage)
    self.pbBurnProgress = self:getChildWindow("Furnace-BurnProgress", GUIType.ProgressBar)
    self.stSelectMaterialText = self:getChildWindow("Furnace-SelectMaterialText", GUIType.StaticText)
    self.llMaterial = self:getChildWindow("Furnace-Material", GUIType.Layout)
    self.stSelectFuelText = self:getChildWindow("Furnace-SelectFuelText", GUIType.StaticText)
    self.llFuel = self:getChildWindow("Furnace-Fuel", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@param slot GUIItemSlotLuaWindow
---@param event string
function UIFurnaceLayout:onItemSlotClick(slot, event)
    if event == GUIEvent.Click then
        self:onClickSlot(slot)
        return
    end
    if event == GUIEvent.LongTouchStart then
        self.curSelectSlot = slot
        return
    end
    if event == GUIEvent.LongTouchEnd then
        self.curSelectSlot = nil
        return
    end
end

---@private
function UIFurnaceLayout:initView()
    self.stTitleText:SetText(Lang:getString("gui_furnace_title"))
    self.stMaterialText:SetText(Lang:getString("gui_furnace_material"))
    self.stFuelText:SetText(Lang:getString("gui_furnace_fuel"))
    self.stOutputText:SetText(Lang:getString("gui_furnace_output"))
    self.stSelectMaterialText:SetText(Lang:getString("gui_furnace_select_material"))
    self.stSelectFuelText:SetText(Lang:getString("gui_furnace_select_fuel"))
    ---@type GUIItemContainerWindow
    self.wMaterial = UIHelper.newGameGUIWindow("GUIItemContainer", self.llMaterial)
    self.wMaterial:initContainer({ 1, 0 }, { 1, 0 }, 62)
    ---@type GUIItemContainerWindow
    self.wFuel = UIHelper.newGameGUIWindow("GUIItemContainer", self.llFuel)
    self.wFuel:initContainer({ 1, 0 }, { 1, 0 }, 62)
    ---@type GUIItemSlotLuaWindow[]
    self.wSlots = {}
    for i = 1, 3 do
        local siSlot = self:getChildWindow("Furnace-FurnaceSlot" .. i, GUIType.StaticImage)
        ---@type GUIItemSlotLuaWindow
        local item = UIHelper.newGameGUIWindow("GUIItemSlotLua")
        item:setWidth({ 1, 0 })
        item:setHeight({ 1, 0 })
        item:setItemClickListener(function(slot, event)
            self:onItemSlotClick(slot, event)
        end)
        siSlot:AddChildWindow(item.root)
        self.wSlots[i] = item
    end
    self.wMaterial:setItemContainer(self.material)
    self.wFuel:setItemContainer(self.fuel)
end

function UIFurnaceLayout:matchMaterialAndFuel()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    FurnaceConfig:tryMatchMaterialAndFuel(inv, self.material, self.fuel)
    ---@param slot ItemSlot
    self.invObserver = function(_, slot)
        if slot.itemId == 0 or FurnaceConfig:isMaterial(slot.itemId) or FurnaceConfig:isFuel(slot.itemId) then
            FurnaceConfig:tryMatchMaterialAndFuel(inv, self.material, self.fuel)
            self.wMaterial:onDataChanged(self.material.slots)
            self.wFuel:onDataChanged(self.fuel.slots)
        end
    end
    inv.hotbar:addObserver(self.invObserver)
    inv.backpack:addObserver(self.invObserver)
end

---@private
function UIFurnaceLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        SoundUtil.clickUI()
        self:hide()
    end)
    self.wMaterial:setItemClickListener(function(slot, event)
        self:onItemSlotClick(slot, event)
    end)
    self.wFuel:setItemClickListener(function(slot, event)
        self:onItemSlotClick(slot, event)
    end)
end

function UIFurnaceLayout:show(key, params)
    self.furnace = ItemContainerMgr:getItemContainer(key)
    if not self.furnace then
        return
    end
    self:matchMaterialAndFuel()
    self.super.show(self)
    for i = 1, 3 do
        local slot = self.furnace.slots[i]
        slot.hideBG = true
        self.wSlots[i]:onDataChanged(slot)
    end
    self.furnace:addObserver(function(_, slot)
        local item = self.wSlots[slot.index]
        if item then
            item:onDataChanged(slot)
        end
        self:setBurnProgress()
    end)
    if params then
        self.burnTime = params.burnTime
        self.curOutId = params.outItemId
    else
        self.burnTime = -1
    end
    self:setBurnProgress()
    self.burnTask = LuaTimer:scheduleTimer(function()
        if self.burnTime >= 0 then
            self.burnTime = self.burnTime + 0.1
            self:setBurnProgress()
        end
    end, 100)
    self:addTimer(self.burnTask)
end

function UIFurnaceLayout:setBurnProgress()
    local slot1 = self.furnace.slots[1]
    local slot2 = self.furnace.slots[2]
    local material = FurnaceConfig:isMaterial(slot1.itemId)
    local fuel = FurnaceConfig:isFuel(slot2.itemId)
    if not material or not fuel then
        self:stopBurnTask()
        return
    end
    if self.curOutId ~= material.MaterialOutId then
        local slot3 = self.furnace.slots[3]
        if slot3.itemId > 0 and slot3.itemId ~= material.MaterialOutId then
            self:stopBurnTask()
            return
        else
            self.burnTime = 0
        end
    end
    if self.burnTime < 0 then
        self.burnTime = 0
    end
    self.curOutId = material.MaterialOutId
    local endTime = math.max(1, math.floor(material.BurnTime / fuel.BurnSize))
    if self.burnTime >= endTime then
        self.burnTime = self.burnTime - endTime
    end
    self.pbBurnProgress:SetProgress(self.burnTime / endTime)
    self.pbBurnProgress:SetVisible(true)
    self.siBurnFlame:SetGrayMask(false)
end

function UIFurnaceLayout:stopBurnTask()
    self.burnTime = -1
    self.pbBurnProgress:SetProgress(0)
    self.pbBurnProgress:SetVisible(false)
    self.siBurnFlame:SetGrayMask(true)
end

function UIFurnaceLayout:onShow()
    self.wMaterial:show()
    self.wFuel:show()
end

function UIFurnaceLayout:onHide()
    self.wMaterial:hide()
    self.wFuel:hide()
    self.furnace:clearObserver()
    self.curSelectSlot = nil
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    inv.hotbar:clearObserver(self.invObserver)
    inv.backpack:clearObserver(self.invObserver)
    LuaTimer:cancel(self.burnTask)
end

function UIFurnaceLayout:onTick()
    if not self.curSelectSlot then
        return
    end
    if self.curSelectSlot.slot.itemId <= 0 then
        self.curSelectSlot = nil
        return
    end
    self:onClickSlot(self.curSelectSlot)
end

---@param item GUIItemSlotLuaWindow
function UIFurnaceLayout:onClickSlot(item)
    local slot = item.slot
    if slot.itemId == 0 then
        return
    end
    local key1 = slot.container.key
    local key2
    if slot.container == self.furnace then
        key2 = PlayerManager:getClientPlayer():getPlayerInventory().hotbar.key
        ItemContainerUtil:tryTransferContainerSlot(key1, key2, slot.index, 1)
    else
        key2 = self.furnace.key
        FurnacePkSender:tryPushItemInFurnace(key1, key2, slot.index)
    end
end

return UIFurnaceLayout
