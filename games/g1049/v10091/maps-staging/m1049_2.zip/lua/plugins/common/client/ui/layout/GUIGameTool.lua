---@class UIGameToolLayout : IGUILayout
local UIGameToolLayout = class("UIGameToolLayout", IGUILayout)

---@private
function UIGameToolLayout:ctor(parent)
    self.super.ctor(self, "GameTool.json", parent)
end

---@private
function UIGameToolLayout:isDelayLoad()
    return true
end

---@private
function UIGameToolLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIGameToolLayout:initCreateEvent()

end

---@private
function UIGameToolLayout:isShowAnim()
    return false
end

---@private
function UIGameToolLayout:onLoad()
    self.btnClose = self:getChildWindow("GameTool-Close", GUIType.Button)
    self.stCopyPosition = self:getChildWindow("GameTool-CopyPosition", GUIType.StaticText)
    self.stCopyYaw = self:getChildWindow("GameTool-CopyYaw", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIGameToolLayout:initView()
    self.stCopyPosition:SetText("复制坐标(pos)")
    self.stCopyYaw:SetText("复制朝向(yaw)")
end

---@private
function UIGameToolLayout:initEvent()
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.stCopyPosition:registerEvent(GUIEvent.Click, function()
        local pos = PlayerManager:getClientPlayer():getPosition(Blockman.Instance().m_render_dt)
        pos.x = math.floor(pos.x * 100) / 100
        pos.y = math.floor(pos.y * 100) / 100
        pos.z = math.floor(pos.z * 100) / 100
        ClientHelper.onSetClipboard(VectorUtil.hashVector3(pos, ","))
        UIHelper.showToast("复制成功")
    end)
    self.stCopyYaw:registerEvent(GUIEvent.Click, function()
        local yaw = PlayerManager:getClientPlayer():getYaw()
        while yaw < 0 do
            yaw = yaw + 360
        end
        while yaw > 360 do
            yaw = yaw - 360
        end
        ClientHelper.onSetClipboard(tostring(math.floor(yaw)))
        UIHelper.showToast("复制成功")
    end)
end

return UIGameToolLayout
