---@class UILuaToolBarLayout : IGUILayout
local UILuaToolBarLayout = class("UILuaToolBarLayout", IGUILayout)
---@type ReportUtil
local ReportUtil = T(Global, "ReportUtil")

local CameraBtnIcon = {
    ["0"] = "set:new_gui_material.json image:one_perspec_bg",
    ["1"] = "set:new_gui_material.json image:three_perspec_back_bg",
    ["2"] = "set:new_gui_material.json image:three_perspec_face_bg",
}

local ToolBarBtnType = {
    Friend = "Friend",
    Party = "Party",
    Bulletin = "Bulletin",
    Christmas = "Christmas"
}

local ToolBarBtnSetting = {
    Friend = {
        key = "Friend",
        sort = 1,
        normalImage = "set:skyblock_main.json image:party_icon",
        pushedImage = "set:skyblock_main.json image:party_icon",
        hideGameType = { "g1049" },
        openFunc = function()
            UIHelper.showGameGUILayout("GUIFriends")
            ReportUtil.clickMainButton("friend")
        end,
    },
    Party = {
        key = "Party",
        sort = 2,
        normalImage = "set:skyblock_main.json image:party_btn",
        pushedImage = "set:skyblock_main.json image:party_btn",
        hideGameType = { "g1049" },
        effect = "g1048_btn_small.effect",
        openFunc = function()
            GUIParty:show()
            Plugins.CallTargetPluginFunc("red_dot", "resetRedDotState", Define.RedDotKey.Party, 0)
            ReportUtil.clickMainButton("party")
        end,
    },
    Bulletin = {
        key = "Bulletin",
        sort = 3,
        normalImage = "set:skyblock_main.json image:skyblock_bulletin",
        pushedImage = "set:skyblock_main.json image:skyblock_bulletin",
        hideGameType = { "g1049" },
        openFunc = function()
            SoundUtil.clickUI()
            GUIBulletin:showPanel(true)
        end,
    },
    Christmas = {
        key = "Christmas",
        sort = 4,
        normalImage = "set:skyblock_gift.json image:gift_icon",
        pushedImage = "set:skyblock_gift.json image:gift_icon",
        effect = "g1048_btn_small.effect",
        openFunc = function()
            SoundUtil.clickUI()
            UIHelper.showGameGUILayout("GUIChristmas", 1)
        end,
    }
}

---@private
function UILuaToolBarLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UILuaToolBarLayout:initCreateEvent()

end

function UILuaToolBarLayout:ctor(...)
    self.super.ctor(self, "LuaToolBar.json", GUIManager:getMainControl())
end

---@private
function UILuaToolBarLayout:onLoad()
    self.cbSetting = self:getChildWindow("LuaToolBar-Setting", GUIType.CheckBox)
    self.btnCamera = self:getChildWindow("LuaToolBar-Camera", GUIType.Button)
    self.cbAction = self:getChildWindow("LuaToolBar-Action", GUIType.CheckBox)
    self.cbChat = self:getChildWindow("LuaToolBar-Chat", GUIType.CheckBox)
    self.llBtnList = self:getChildWindow("LuaToolBar-Btn-List", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function UILuaToolBarLayout:initView()
    local oldToolBar = GUIManager:getWindowByName("ToolBar")
    if oldToolBar then
        oldToolBar:SetYPosition({ 0, -54 })
    end
    self.llActionLayout = GUIManager:getWindowByName("ToolBar-Action-Layout")
    self.llActionLayout:SetYPosition({ 1, 0 })
    UIHelper.newGameGUILayout("GUILuaChat")
    self:initMoney()
    self:initBtns()
end

---@private
function UILuaToolBarLayout:initMoney()
    local currencyIds = { CurrencyId.TaskChainScore, CurrencyId.Currency, CurrencyId.Diamonds }
    ---@type GUICurrencyGroupWindow
    self.wCurrencyGroup = UIHelper.newGameGUIWindow("GUICurrencyGroup")
    self.wCurrencyGroup:onDataChanged(currencyIds, 185, 15)
    for _, wCurrency in pairs(self.wCurrencyGroup.wCurrencyList) do
        wCurrency:setWidth({ 0, 170 })
        wCurrency:setYPosition({ 0, 10 })
    end
    self.root:AddChildWindow(self.wCurrencyGroup.root)
end

function UILuaToolBarLayout:initBtns()
    local group = {}
    for key, cfg in pairs(ToolBarBtnSetting) do
        if not cfg.hideGameType or not TableUtil.include(cfg.hideGameType, Game.GameType) then
            table.insert(group, cfg)
        end
    end
    table.sort(group, function(a, b)
        return a.sort < b.sort
    end)

    self.toolBarBtns = {}
    local size = #group
    self.llBtnList:SetWidth({ 0, size * 52 + 5 * (size - 1) })
    for index, btnCfg in ipairs(group) do
        local btn = GUIManager:createGUIWindow(GUIType.Button, "LuaToolBar-" .. btnCfg.key)
        if btn then
            self.llBtnList:AddChildWindow(btn)
            btn:SetProperty("Material", "CullBackLinear")
            btn:SetVerticalAlignment(VerticalAlignment.Center)
            btn:SetArea({ 0, (index - 1) * 57 }, { 0, 0 }, { 0, 52 }, { 0, 45 })
            btn:SetNormalImage(btnCfg.normalImage)
            btn:SetPushedImage(btnCfg.pushedImage)
            if btnCfg.effect then
                local image = GUIManager:createGUIWindow(GUIType.StaticImage, "LuaToolBar-" .. btnCfg.key .. "-Effect")
                btn:AddChildWindow(image)
                image:SetHorizontalAlignment(HorizontalAlignment.Center)
                image:SetTouchable(false)
                image:SetEffectName(btnCfg.effect)
                image:SetArea({ 0, 0 }, { -4.7, 0 }, { 1.3, 0 }, { 5.1, 0 })
            end
            btn:registerEvent(GUIEvent.ButtonClick, function()
                if btnCfg.openUi then
                    UIHelper.showGameGUILayout(btnCfg.openUi)
                elseif btnCfg.openFunc then
                    btnCfg.openFunc()
                end
            end)
            self.toolBarBtns[btnCfg.key] = btn
        end
    end

    if self.toolBarBtns[ToolBarBtnType.Friend] then
        Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", self.toolBarBtns[ToolBarBtnType.Friend], Define.RedDotKey.Friend, nil, {
            customImage = "set:common.json image:img_0_red_dot"
        })
    end

    if self.toolBarBtns[ToolBarBtnType.Party] then
        Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", self.toolBarBtns[ToolBarBtnType.Party], Define.RedDotKey.Party, nil, {
            customImage = "set:common.json image:img_0_red_dot"
        })
    end
end

---@private
function UILuaToolBarLayout:initEvent()
    self.cbSetting:registerEvent(GUIEvent.CheckStateChanged, function()
        if self.cbSetting:GetChecked() then
            self.cbAction:SetChecked(false)
            self.cbChat:SetChecked(false)
            GUIManager:showWindowByName("Menu.json")
            ReportUtil.clickMainButton("setting")
        else
            GUIManager:hideWindowByName("Menu.json")
        end
    end)

    self.btnCamera:registerEvent(GUIEvent.ButtonClick, function()
        local curCamera = Blockman.Instance():getCurrPersonView()
        local newCamera = curCamera
        if curCamera == 0 then
            newCamera = 1
        elseif curCamera == 1 then
            newCamera = 2
        elseif curCamera == 2 then
            newCamera = 0
        end
        Blockman.Instance():setPersonView(newCamera)
        self:cameraChange()
    end)

    self.cbAction:registerEvent(GUIEvent.CheckStateChanged, function()
        self.llActionLayout:SetVisible(self.cbAction:GetChecked())
        if self.cbAction:GetChecked() then
            self.cbSetting:SetChecked(false)
            self.cbChat:SetChecked(false)
        end
    end)

    self.cbChat:registerEvent(GUIEvent.CheckStateChanged, function()
        if self.cbChat:GetChecked() then
            self.cbAction:SetChecked(false)
            self.cbSetting:SetChecked(false)
            UIHelper.showGameGUILayout("GUILuaChat", Define.ChatTabType.SameServer)
            ReportUtil.clickMainButton("chat")
        else
            UIHelper.hideGameGUILayout("GUILuaChat")
        end
    end)

    Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", self.cbChat, Define.RedDotKey.ChatNewMsg, nil,
            { customImage = "set:common.json image:img_0_red_dot" })
end

function UILuaToolBarLayout:onTick()
    self.wCurrencyGroup:onTick()
    if not self.llActionLayout:IsVisible() and self.cbAction:GetChecked() then
        self.cbAction:SetChecked(false)
    end
end

function UILuaToolBarLayout:cameraChange()
    local curCamera = Blockman.Instance():getCurrPersonView() or 0
    self.btnCamera:SetPushedImage(CameraBtnIcon[tostring(curCamera)] or "")
    self.btnCamera:SetNormalImage(CameraBtnIcon[tostring(curCamera)] or "")
    PlayerManager:getClientPlayer().Player:setBoolProperty("HideHeadName", curCamera == 1)
end

return UILuaToolBarLayout
