---@class UICustomInputContentLayout : IGUILayout
local UICustomInputContentLayout = class("UICustomInputContentLayout", IGUILayout)

---@private
function UICustomInputContentLayout:isDelayLoad()
    return true
end

---@private
function UICustomInputContentLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UICustomInputContentLayout:initCreateEvent()

end

---@private
function UICustomInputContentLayout:onLoad()
    self.stTip = self:getChildWindow("CustomInputContent-Tip", GUIType.StaticText)
    self.etContentText = self:getChildWindow("CustomInputContent-Content-Text", GUIType.Edit)
    self:initView()
    self:initEvent()
end

---@private
function UICustomInputContentLayout:initView()
    self.stTip:SetText("")
    self.etContentText:SetTextVertAlign(VerticalAlignment.Top)
end

---@private
function UICustomInputContentLayout:initEvent()
    self.etContentText:registerEvent(GUIEvent.EditTextInput, function()
        if self.contentChangeListener then
            local text = self.etContentText:GetText()
            text = FilterWord.getReplaceContent(text)
            self.contentChangeListener(text)
        end
    end)
end

function UICustomInputContentLayout:setInputInfo(tip, defaultContent)
    self:show()
    self.stTip:SetText(tip)
    self.etContentText:SetText(defaultContent)
end

function UICustomInputContentLayout:onHide()
    self.contentChangeListener = nil
    self.etContentText:SetText("")
end

function UICustomInputContentLayout:setContentChangeListener(contentChangeListener)
    self.contentChangeListener = contentChangeListener
end

---@type UICustomInputContentLayout
CustomInputContent = buildCustomDialogContent(UICustomInputContentLayout, "CustomInputContent.json")
