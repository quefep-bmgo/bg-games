---@class GUICurrencyWindow : IGUIWindow
local GUICurrencyWindow = class("GUICurrencyWindow", IGUIWindow)
---@type ReportUtil
local ReportUtil = T(Global, "ReportUtil")

local ButtonName = {
    [CurrencyId.Diamonds] = "gcube",
    [CurrencyId.Currency] = "coins",
    [CurrencyId.PassScore] = "gem",
    [CurrencyId.TaskChainScore] = "medal",
}

---@private
function GUICurrencyWindow:ctor(...)
    self.super.ctor(self, "Currency.json", ...)
end

---@private
function GUICurrencyWindow:onLoad()
    self.siIcon = self:getChildWindowByName("Currency-Icon", GUIType.StaticImage)
    self.siAdd = self:getChildWindowByName("Currency-Add", GUIType.StaticImage)
    self.stText = self:getChildWindowByName("Currency-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUICurrencyWindow:initView()

end

---@private
function GUICurrencyWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        if self.coinId <= CurrencyId.Diamonds then
            ClientHelper.onRecharge(1)

        elseif Define.CurrencyExchangeRadio[self.coinId] ~= nil then
            UIHelper.showGameGUILayout("GUIBuyCurrencyDialog", self.coinId)
        end
        if ButtonName[self.coinId] then
            ReportUtil.clickMainButton(ButtonName[self.coinId])
        end
        SoundUtil.clickUI()
    end)
end

---@param currency number | number[]
function GUICurrencyWindow:onDataChanged(currency)
    if type(currency) == "table" then
        self.coinId = CurrencyId.GameItem
        self.itemId = currency[1] or 0
        self.meta = currency[2] or 0
    else
        self.coinId = currency
        self.itemId = 0
        self.meta = 0
    end
    if self.coinId < CurrencyId.GameItem then
        self.siIcon:SetImage(PayHelper.getMoneyIcon(self.coinId))
    elseif self.itemId > 0 then
        GuiItemStack.showItemIcon(self.siIcon, self.itemId, self.meta, "")
    else
        self.siIcon:SetImage("")
    end
    if isArraignmentApp then
        self.siAdd:SetVisible(false)
    else
        self.siAdd:SetVisible(Define.CurrencyExchangeRadio[self.coinId] ~= nil or self.coinId <= CurrencyId.Diamonds)
    end
end

function GUICurrencyWindow:onTick()
    if self.coinId < CurrencyId.GameItem then
        local money = PlayerWallet.getMoneyByCoinId(self.coinId)
        self.stText:SetText(money)
    elseif self.itemId > 0 then
        local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
        self.stText:SetText(inventory:getItemCount(self.itemId, self.meta))
    else
        self.stText:SetText("0")
    end
end

return GUICurrencyWindow
