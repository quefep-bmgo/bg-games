---@class UILuaMainLayout : IGUILayout
local UILuaMainLayout = class("UILuaMainLayout", IGUILayout)
---@type DataInfoMgr
local DataInfoMgr = T(Global, "DataInfoMgr")
---@type GameUtil
local GameUtil = T(Global, "GameUtil")
---@type ReportValue
local ReportValue = T(Global, "ReportValue")
---@type ReportUtil
local ReportUtil = T(Global, "ReportUtil")
---@type GUILayout[]
local LayoutTable = {}
---@type table<string, GUIButton[]>
local ButtonListTable = {}

local function hideEngineWindow(name)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetXPosition({ 0, 6000 })
    window:SetVisible(false)
end

local BtnLayoutType = {
    Main = "Main",
    Option = "Option"
}

local ItemSpace = {
    [BtnLayoutType.Main] = 33,
    [BtnLayoutType.Option] = 20
}

local ButtonWidth = {
    [BtnLayoutType.Main] = 66,
    [BtnLayoutType.Option] = 47
}

local ButtonHeight = {
    [BtnLayoutType.Main] = 66,
    [BtnLayoutType.Option] = 44
}

---@private
function UILuaMainLayout:onCreate()
    self:initCreateEvent()
    self:checkGoMineField()
end

---@private
function UILuaMainLayout:checkGoMineField()
    local time = tonumber(ClientHelper.getStringForKey("GoMineField", "0"))
    if os.time() - time >= 180 then
        return
    end
    ClientHelper.putStringForKey("GoMineField", "0")
    LuaTimer:schedule(function()
        GameUtil:resetGame(Game:getPlatformUserId(), "mine_field")
    end, 1000)
end

---@private
function UILuaMainLayout:initCreateEvent()

end

---@private
function UILuaMainLayout:ctor(...)
    self.super.ctor(self, "LuaMain.json", GUIManager:getMainControl())
end

---@private
function UILuaMainLayout:onLoad()
    self.optionOpenStatus = false
    self.arrowOpenStatus = false
    self.llEffectLayout = self:getChildWindow("LuaMain-EffectLayout", GUIType.Layout)
    self.uiHead = self:getChildWindow("LuaMain-Head", GUIType.UrlImage)
    self.siExpBarBg = self:getChildWindow("LuaMain-Exp-Bar-Bg", GUIType.StaticImage)
    self.pbExpBar = self:getChildWindow("LuaMain-Exp-Bar", GUIType.ProgressBar)
    self.stExp = self:getChildWindow("LuaMain-Exp", GUIType.StaticText)
    self.siLv = self:getChildWindow("LuaMain-Lv", GUIType.StaticImage)
    self.stLvText = self:getChildWindow("LuaMain-Lv-Text", GUIType.StaticText)
    self.stName = self:getChildWindow("LuaMain-Name", GUIType.StaticText)
    self.siLike = self:getChildWindow("LuaMain-Like", GUIType.StaticImage)
    self.stLikeNum = self:getChildWindow("LuaMain-Like-Num", GUIType.StaticText)
    self.siThumbsUp = self:getChildWindow("LuaMain-Thumbs-Up", GUIType.StaticImage)
    self.btnOptionBtn = self:getChildWindow("LuaMain-Option-Btn", GUIType.Button)
    self.siRedAllImg = self:getChildWindow("LuaMain-Red-All-Img", GUIType.StaticImage)
    LayoutTable[BtnLayoutType.Main] = self:getChildWindow("LuaMain-Btn-List", GUIType.Layout)
    LayoutTable[BtnLayoutType.Option] = self:getChildWindow("LuaMain-Option-Bg", GUIType.Layout)
    self.btnGoHome = self:getChildWindow("LuaMain-Go-Home", GUIType.Button)
    self.btnSetHome = self:getChildWindow("LuaMain-Set-Home", GUIType.Button)
    self.btnExtend = self:getChildWindow("LuaMain-Extend", GUIType.Button)
    self.btnHideGuide = self:getChildWindow("LuaMain-Hide-Guide", GUIType.Button)
    self.stHideGuideText = self:getChildWindow("LuaMain-Hide-Guide-Text", GUIType.StaticText)
    self.siLoveBg = self:getChildWindow("LuaMain-Love-Bg", GUIType.StaticImage)
    self.siLoveIcon = self:getChildWindow("LuaMain-Love-Icon", GUIType.StaticImage)
    self.stLoveNum = self:getChildWindow("LuaMain-Love-Num", GUIType.StaticText)
    self.btnOptionClose = self:getChildWindow("LuaMain-Option-Close", GUIType.Button)

    self.btnArrow = self:getChildWindow("LuaMain-Arrow", GUIType.Button)
    self.llBtnsLayout = self:getChildWindow("LuaMain-Btns", GUIType.Layout)
    self.stSetHomeText = self:getChildWindow("LuaMain-Set-Home-Text", GUIType.StaticText)
    self.stExtendText = self:getChildWindow("LuaMain-Extend-Text", GUIType.StaticText)
    self.stAreaText = self:getChildWindow("LuaMain-Area-Text", GUIType.StaticText)

    self.btnBuildTogether = self:getChildWindow("LuaMain-Build-Together", GUIType.Button)
    self.stBuildTogetherText = self:getChildWindow("LuaMain-Build-Together-Text", GUIType.StaticText)


    self:initView()
    self:initEvent()
end

---@private
function UILuaMainLayout:initView()
    self.btnGoHome:SetText(Lang:getString("gui_skyblock_island_home"))
    self.stSetHomeText:SetText(Lang:getString("gui_skyblock_island_sethome"))
    self.stExtendText:SetText(Lang:getString("gui_skyblock_island_area"))
    self.stHideGuideText:SetText(Lang:getString("gui_skyblock_cancel_guide_arrow"))
    self.stBuildTogetherText:SetText(Lang:getString("Friend_Tab_Name_4"))
    self.llEffectLayout:SetVisible(false)
    self.siRedAllImg:SetVisible(false)
    self.siLike:SetVisible(false)
    self.siThumbsUp:SetVisible(false)
    self.siLoveBg:SetVisible(GameType == "g1048")
    self.btnArrow:SetVisible(GameType == "g1048")
    self.btnBuildTogether:SetVisible(GameType == "g1048")
    Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", self.btnBuildTogether, Define.RedDotKey.Build, nil, {
        offset = VectorUtil.newVector2(-155, -7),
        customImage = "set:common.json image:img_0_red_dot"
    })

    self:initBtns()
    self:initOptionBtns()
    self:setEngineUIStyle()
    self:setNotificationStyle()
end

---@private
function UILuaMainLayout:initBtns()
    self.btnShop = self:addButton(BtnLayoutType.Main, "GUILuaMain-Shop", "gui_sky_block_appshop_title",
            "set:skyblock_main.json image:shop", "set:skyblock_main.json image:shop", function()
                RootGuiLayout.Instance():showSkyBlockAppShopPage()
                ReportUtil.clickMainButton("shop")
            end)

    self.btnMineField = self:addButton(BtnLayoutType.Main, "GUILuaMain-Mine-Field", "gui_skyblock_resource_island",
            "set:skyblock_main.json image:product", "set:skyblock_main.json image:product", function()
                if GameType == "g1048" then
                    GameUtil:resetGame(Game:getPlatformUserId(), "mine_field")
                else
                    ClientHelper.putStringForKey("GoMineField", tostring(os.time()))
                    GameUtil:resetGame(Game:getPlatformUserId(), "g1048")
                end
                ReportUtil.clickMainButton("ore_island")
            end)

    if GameType ~= "g1049" then
        self.btnMineHole = self:addButton(BtnLayoutType.Main, "GUILuaMain-Mine-Hole", "gui_skyblock_diggings",
                "set:skyblock_main.json image:skyblock_diggings", "set:skyblock_main.json image:skyblock_diggings", function()
                    GameUtil:resetGame(Game:getPlatformUserId(), "g1049")
                    ReportUtil.clickMainButton("mining")
                end)
    end

    if GameType == "g1048" then
        self.btnBackHall = self:addButton(BtnLayoutType.Main, "GUILuaMain-BackHall", "gui_skyblock_backHall",
                "set:party.json image:backhall_btn", "set:party.json image:backhall_btn", function()
                    GameUtil:resetGame(Game:getPlatformUserId(), "hall")
                    ReportUtil.clickMainButton("hall")
                end)
    end

    self.btnPass = self:addButton(BtnLayoutType.Main, "GUILuaMain-Pass", "gui_skyblock_pass",
            "set:passes.json image:icon_0_passes", "set:passes.json image:icon_0_passes", function()
                SoundUtil.clickUI()
                UIHelper.showGameGUILayout("GUIPass")
                ReportUtil.clickMainButton("pass")
            end)
    Plugins.CallTargetPluginFunc("red_dot", "redDotBuild", self.btnPass, Define.RedDotKey.Pass, nil, {
        customImage = "set:common.json image:img_0_red_dot"
    })

    self.btnActivity = self:addButton(BtnLayoutType.Main, "GUILuaMain-Activity", "#",
            "set:skyblock_recharge.json image:blue_main_btn", "set:skyblock_recharge.json image:blue_main_btn", function()
                ---@type IActivity
                local _, activity = next(PlayerManager:getClientPlayer().activity.activities)
                if activity then
                    activity:tryShowActivityUI()
                else
                    CustomDialog.builder()
                                .setContentText(Lang:getString("SkyBlock_Npc_hint_4"))
                                .setHideLeftButton()
                                .show()
                end
            end, { name = "170_jiangliquan_jianshen.effect", scale = 2 })
end

---@private
function UILuaMainLayout:initOptionBtns()
    --self.sumRechargeBtn = self:addButton(BtnLayoutType.Option, "GUILuaMain-SumRecharge", "#",
    --        "set:main.json image:btn_0_first_charge", "set:main.json image:btn_0_first_charge", function()
    --            SoundUtil.clickUI()
    --            GUISumRechargeLayout:show()
    --        end)

    --self.christmasBtn = self:addButton(BtnLayoutType.Option, "GUILuaMain-Christmas", "#",
    --        "set:main.json image:btn_0_christmas", "set:main.json image:btn_0_christmas", function()
    --            SoundUtil.clickUI()
    --            UIHelper.showGameGUILayout("GUIChristmas", 1)
    --        end)

    if GameType == "g1048" then
        self.btnRank = self:addButton(BtnLayoutType.Option, "GUILuaMain-Rank", "#",
                "set:skyblock_main.json image:skyblock_rank", "set:skyblock_main.json image:skyblock_rank", function()
                    GUIRank:show()
                    ReportUtil.clickMainButton("rank")
                end)
    end

    if not ButtonListTable[BtnLayoutType.Option] then
        self.btnOptionBtn:SetVisible(false)
    end
end

---@private
function UILuaMainLayout:initEvent()
    self.btnOptionBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:playOptionAnim()
    end)

    self.btnGoHome:registerEvent(GUIEvent.ButtonClick, function()
        GameUtil:resetGame(Game:getPlatformUserId(), "g1048")
        ReportUtil.clickMainButton("go_home")
    end)

    self.btnSetHome:registerEvent(GUIEvent.ButtonClick, function()
        PlayerManager:getClientPlayer():sendPacket({
            pid = "playerSetHome"
        })
        ReportUtil.clickMainButton("set_home")
    end)

    self.btnExtend:registerEvent(GUIEvent.ButtonClick, function()
        PlayerManager:getClientPlayer():sendPacket({
            pid = "playerExtendArea"
        })
        ReportUtil.clickMainButton("island_area")
    end)

    self.siLoveBg:registerEvent(GUIEvent.Click, function()
        GamePacketSender:sendOnToolBarGiveLove()
        ReportUtil.clickMainButton("like")
    end)

    self.btnHideGuide:registerEvent(GUIEvent.ButtonClick, function()
        GamePacketSender:sendCancelGuideArrow()
    end)

    self:registerDataCallBack("ShowSumRecharge", function(data)
        local id = data:getParam("Id")
        local config = SumRechargeConfig:getSumRecharge(id)
        if not config then
            self:removeButton(BtnLayoutType.Option, "GUILuaMain-SumRecharge")
        end
    end, DataBuilderProcessor)

    DataInfoMgr:registerObserver(Game:getPlatformUserId(), function(_, _, value)
        self:updateInHomeStatus(value)
    end, Define.PlayerInfoKey.InHome)

    self:registerDataCallBack("WelcomeTip", function(data)
        local message = string.format(Lang:getString("welcome_visitor_tip"), tostring(data.targetName))
        MsgSender.sendTopTips(5, message)
    end, JsonBuilderProcessor)

    self:registerDataCallBack("showGuideArrowBtn", function(data)
        self:showGuideArrow(data)
    end, JsonBuilderProcessor)

    self.btnOptionClose:registerEvent(GUIEvent.ButtonClick, function()
        self:playOptionAnim()
    end)

    self.btnArrow:registerEvent(GUIEvent.ButtonClick, function()
        self:onClickArrow()
        ReportUtil.clickMainButton("home_list")
    end)

    self.btnBuildTogether:registerEvent(GUIEvent.ButtonClick, function()
        GUIFriend:show()
    end)
end

---@private
function UILuaMainLayout:playOptionAnim()
    self.optionOpenStatus = not self.optionOpenStatus
    LayoutTable[BtnLayoutType.Option]:SetVisible(self.optionOpenStatus)
end

---@private
function UILuaMainLayout:setEngineUIStyle()
    hideEngineWindow("Main-Watch-Battle-Text")
    hideEngineWindow("Main-Player-Exp")
    hideEngineWindow("PlayerInfo-Armor")
    hideEngineWindow("SkyBlockMain")
    hideEngineWindow("SKSumRechargeMain")
    local btnLeftShoot = GUIManager:getWindowByName("Main-Gun-Operate-LeftShootBtn", GUIType.Button)
    btnLeftShoot:SetNormalImage("set:main.json image:btn_0_shoot_left")
    btnLeftShoot:SetPushedImage("set:main.json image:btn_0_shoot_left_click")
    btnLeftShoot:SetVerticalAlignment(VerticalAlignment.Center)
    btnLeftShoot:SetArea({ 0, 15 }, { 0, -50 }, { 0, 80 }, { 0, 80 })
    local btnRightShoot = GUIManager:getWindowByName("Main-Gun-Operate-RightShootBtn", GUIType.Button)
    btnRightShoot:SetNormalImage("set:main.json image:btn_0_shoot_right")
    btnRightShoot:SetPushedImage("set:main.json image:btn_0_shoot_right_click")
    btnRightShoot:SetWidth({ 0, 115 })
    btnRightShoot:SetHeight({ 0, 115 })
    local btnReload = GUIManager:getWindowByName("Main-Gun-Operate-ReloadBtn", GUIType.Button)
    btnReload:SetNormalImage("set:main.json image:btn_0_reroad")
    btnReload:SetPushedImage("set:main.json image:btn_0_reroad_click")
    btnReload:SetVerticalAlignment(VerticalAlignment.Bottom)
    btnReload:SetWidth({ 0, 95 })
    btnReload:SetHeight({ 0, 87 })
    local btnAim = GUIManager:getWindowByName("Main-Gun-Operate-AimBtn", GUIType.Button)
    btnAim:SetNormalImage("set:main.json image:btn_0_sniper2")
    btnAim:SetPushedImage("set:main.json image:btn_0_sniper2_click")
    btnAim:SetWidth({ 0, 78 })
    btnAim:SetHeight({ 0, 78 })
    local btnCancelAim = GUIManager:getWindowByName("Main-Gun-Operate-CancelAimBtn", GUIType.Button)
    btnCancelAim:SetNormalImage("set:main.json image:btn_0_sniper1")
    btnCancelAim:SetPushedImage("set:main.json image:btn_0_sniper1_click")
    btnCancelAim:SetWidth({ 0, 78 })
    btnCancelAim:SetHeight({ 0, 78 })
end

---@param layoutType string
---@param buttonName string
---@param lang string
---@param normalImage string
---@param pushedImage string
---@param callback function
function UILuaMainLayout:addButton(layoutType, buttonName, lang, normalImage, pushedImage, callback, effectInfo)
    local layout = LayoutTable[layoutType]
    if not layout then
        return nil
    end
    if not ButtonListTable[layoutType] then
        ButtonListTable[layoutType] = {}
    end

    local button = GUIManager:createGUIWindow(GUIType.Button, buttonName)
    if lang and lang ~= "#" then
        local textBg = GUIManager:createGUIWindow(GUIType.StaticImage, buttonName .. "-Text-Bg")
        button:AddChildWindow(textBg)
        textBg:SetHorizontalAlignment(HorizontalAlignment.Center)
        textBg:SetVerticalAlignment(VerticalAlignment.Bottom)
        textBg:SetArea({ 0, 0 }, { 0, 8 }, { 0, 89 }, { 0, 26 })
        textBg:SetImage("set:skyblock_main.json image:product_bg")
        textBg:SetTouchable(false)
        textBg:SetProperty("Material", "CullBackLinear")
        textBg:SetProperty("StretchType", "NineGrid")
        textBg:SetProperty("StretchOffset", "8 8 8 8")
        local text = GUIManager:createGUIWindow(GUIType.StaticText, buttonName .. "-Text")
        textBg:AddChildWindow(text)
        text:SetHorizontalAlignment(HorizontalAlignment.Center)
        text:SetTextHorzAlign(HorizontalAlignment.Center)
        text:SetArea({ 0, 0 }, { 0, 2 }, { 1, 0 }, { 1, 0 })
        text:SetProperty("Font", "HT12")
        text:SetText(Lang:getString(lang))
    end
    if effectInfo and effectInfo.name then
        effectInfo.scale = effectInfo.scale or 2
        local effect = GUIManager:createGUIWindow(GUIType.StaticImage, buttonName .. "-Effect")
        effect:SetHorizontalAlignment(HorizontalAlignment.Center)
        effect:SetArea({ 0, 0 }, { -effectInfo.scale + 0.5, 0 }, { effectInfo.scale, 0 }, { effectInfo.scale, 0 })
        effect:SetEffectName(effectInfo.name)
        effect:SetTouchable(false)
        button:AddChildWindow(effect)
    end
    button:SetProperty("Material", "CullBackLinear")
    button:SetNormalImage(normalImage)
    button:SetPushedImage(pushedImage)
    if callback ~= nil then
        button:registerEvent(GUIEvent.ButtonClick, callback)
    end
    LayoutTable[layoutType]:AddChildWindow(button)
    table.insert(ButtonListTable[layoutType], button)
    self:setButtonPos(layoutType, button, #ButtonListTable[layoutType])
    return button
end

---@param layoutType string
---@param buttonName string
function UILuaMainLayout:removeButton(layoutType, buttonName)
    for index, _button in pairs(ButtonListTable[layoutType]) do
        if _button:GetName() == buttonName then
            table.remove(ButtonListTable[layoutType], index)
            GUIManager:destroyGUIWindow(GUIManager:getWindowByName(buttonName))
            break
        end
    end
    self:refreshButton(layoutType)
end

---@param layoutType string
function UILuaMainLayout:refreshButton(layoutType)
    for buttonIndex, button in pairs(ButtonListTable[layoutType]) do
        self:setButtonPos(layoutType, button, buttonIndex)
    end
end

function UILuaMainLayout:setButtonPos(layoutType, button, buttonIndex)
    local itemSpace = ItemSpace[layoutType]
    local buttonWidth = ButtonWidth[layoutType]
    local buttonHeight = ButtonHeight[layoutType]
    local curPos = (buttonIndex - 1) * (itemSpace + buttonWidth)
    if layoutType == BtnLayoutType.Main then
        button:SetHorizontalAlignment(HorizontalAlignment.Right)
        button:SetVerticalAlignment(VerticalAlignment.Center)
        button:SetArea({ 0, -curPos }, { 0, 0 }, { 0, buttonWidth }, { 0, buttonHeight })
    elseif layoutType == BtnLayoutType.Option then
        button:SetHorizontalAlignment(HorizontalAlignment.Left)
        button:SetVerticalAlignment(VerticalAlignment.Center)
        button:SetArea({ 0, curPos + 30 }, { 0, 0 }, { 0, buttonWidth }, { 0, buttonHeight })
    end
    local width = #ButtonListTable[layoutType] * buttonWidth + (#ButtonListTable[layoutType] - 1) * itemSpace
    LayoutTable[layoutType]:SetWidth({ 0, width + 30 })
    if layoutType == BtnLayoutType.Option then
        LayoutTable[layoutType]:SetWidth({ 0, width + 80 })
    end
end

function UILuaMainLayout:updatePlayerInfo(data)
    if not data or not data.userId then
        return
    end
    ReportValue.setValue(Game:getPlatformUserId(), "island_lv", data.lv or 1)
    local isMaster = data.userId == Game:getPlatformUserId()
    if not isMaster then
        self.userId = data.userId
        self:updatePlayerUi()
        self:updateInHomeStatus(false)
        return
    end
    local lv = data.lv
    local exp = data.exp
    local maxExp = data.maxExp
    local area = data.area
    local isInHome = isMaster and GameType == "g1048"
    local isMax = lv > 1500
    self.stLvText:SetText(lv)
    local progress = isMax and 1 or (exp > 0 and exp / maxExp or 0)
    self.pbExpBar:SetProgress(progress)
    self.stExp:SetText(isMax and "Max" or (exp .. "/" .. maxExp))
    self.stAreaText:SetText(area)

    if not self.userId or self.userId ~= data.userId then
        self.userId = data.userId
        self:updatePlayerUi()
        self:updateInHomeStatus(isInHome)
    end
end

function UILuaMainLayout:updatePlayerUi()
    --UserInfoCache:GetCacheByUserIds({ self.userId }, function()
    --    local info = UserInfoCache:GetCache(self.userId)
    --    if info then
    --        self.uiHead:setUrl(info.picUrl or "")
    --        self.stName:SetText(info.name)
    --    end
    --end)
end

function UILuaMainLayout:updateInHomeStatus(inHome)
    --self.btnSetHome:SetVisible(inHome)
    --self.btnExtend:SetVisible(inHome)
    --self.siExpBarBg:SetVisible(inHome)
end

function UILuaMainLayout:checkThumbsUpAni()
    LuaTimer:cancel(self.thumbsUpTimer or 0)
    if not self.siThumbsUp:IsVisible() then
        return
    end
    self.thumbsUpTimer = LuaTimer:scheduleTicker(function()
        UIAnimation:scaleWH(self.siThumbsUp, { 35, 34 }, { 15, 14 }, 25, function()
            UIAnimation:scaleWH(self.siThumbsUp, { 15, 14 }, { 35, 34 }, 20, function()
            end)
        end)
    end, 47, -1)
end

function UILuaMainLayout:showGuideArrow(data)
    local tab = json.decode(data)
    if tab and tab.isShow ~= nil then
        self.btnHideGuide:SetVisible(tab.isShow)
        local arrowPos = VectorUtil.newVector3(tab.posX, tab.posY, tab.posZ)
        if tab.isShow then
            PlayerManager:getClientPlayer().Player:addGuideArrow(arrowPos)
        else
            PlayerManager:getClientPlayer().Player:deleteGuideArrow(arrowPos)
        end
    end
end

function UILuaMainLayout:setNotificationStyle()
    local notificationContent = GUIManager:getWindowByName("Notification-Content", GUIType.Layout)
    if notificationContent then
        --notificationContent:SetArea({ 0, 0 }, { 0, 70 }, { 0, 400 }, { 0, 30 })
        --notificationContent:SetBackgroundColor({ 0, 0, 0, 0 })
        --notificationContent:SetBackImage("set:main.json image:img_9_go")
        --notificationContent:SetProperty("StretchType", "NineGrid")
        --notificationContent:SetProperty("StretchOffset", "30 30 5 5")
        local btnVisit1 = GUIManager:getWindowByName("Notification-Content-Visit-Btn-1", GUIType.Button)
        local btnVisit2 = GUIManager:getWindowByName("Notification-Content-Visit-Btn-2", GUIType.Button)
        btnVisit1:SetXPosition({ 0, -70 })
        btnVisit2:SetXPosition({ 0, -70 })
        --btnVisit1:SetArea({ 1, -70 }, { 0, 0 }, { 0, 57.6 }, { 0, 38.4 })
        --btnVisit1:SetProperty("TextRenderOffset", "0 -4")
        --btnVisit1:SetNormalImage("set:main.json image:btn_0_go")
        --btnVisit1:SetPushedImage("set:main.json image:btn_0_go")
        --btnVisit2:SetArea({ 1, -70 }, { 0, 0 }, { 0, 57.6 }, { 0, 38.4 })
        --btnVisit2:SetProperty("TextRenderOffset", "0 -4")
        --btnVisit2:SetNormalImage("set:main.json image:btn_0_go")
        --btnVisit2:SetPushedImage("set:main.json image:btn_0_go")
        --local text1 = GUIManager:getWindowByName("Notification-Content-Text-1", GUIType.StaticText)
        --local text2 = GUIManager:getWindowByName("Notification-Content-Text-2", GUIType.StaticText)
        --text1:SetArea({ 0, 5 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
        --text2:SetArea({ 0, 5 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    end
end

---@private
function UILuaMainLayout:onClickArrow()
    self.arrowOpenStatus = not self.arrowOpenStatus
    self.btnArrow:SetProperty("Rotate", self.arrowOpenStatus and "0" or "180")
    self.llBtnsLayout:SetVisible(self.arrowOpenStatus)
end

function UILuaMainLayout:setLoveNum(loveNum, isSelf)
    self.stLoveNum:SetText(loveNum)
    self.siLoveIcon:SetImage(isSelf and "set:party.json image:heart" or "set:party.json image:red_pollex")
end

return UILuaMainLayout
