---@class UIBuyCurrencyDialogLayout : IGUILayout
local UIBuyCurrencyDialogLayout = class("UIBuyCurrencyDialogLayout", IGUILayout)
---@type CommonPkSender
local CommonPkSender = T(Global, "PidPacketSender")

local BuyTip = {
    [CurrencyId.Currency] = { "gui_buy_money_tips_left", "gui_buy_money_tips_right" },
    [CurrencyId.PassScore] = { "gui_buy_money_tips_left1", "gui_buy_money_tips_right1" },
    [CurrencyId.TaskChainScore] = { "gui_buy_money_tips_left2", "gui_buy_money_tips_right2" },
}

---@private
function UIBuyCurrencyDialogLayout:ctor(parent)
    self.super.ctor(self, "BuyCurrencyDialog.json", parent)
end

---@private
function UIBuyCurrencyDialogLayout:isDelayLoad()
    return true
end

---@private
function UIBuyCurrencyDialogLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIBuyCurrencyDialogLayout:initCreateEvent()
    self:registerDataCallBack("ShowLackMoney", function(_)
        self:show(CurrencyId.Currency)
    end, JsonBuilderProcessor)
end

---@private
function UIBuyCurrencyDialogLayout:onLoad()
    self.llPanel = self:getChildWindow("BuyCurrencyDialog-Panel", GUIType.Layout)
    self.llTitle = self:getChildWindow("BuyCurrencyDialog-Title", GUIType.Layout)
    self.stTitleText = self:getChildWindow("BuyCurrencyDialog-Title-Text", GUIType.StaticText)
    self.btnClose = self:getChildWindow("BuyCurrencyDialog-Close", GUIType.Button)
    self.btnCancel = self:getChildWindow("BuyCurrencyDialog-Cancel", GUIType.Button)
    self.btnConfirm = self:getChildWindow("BuyCurrencyDialog-Confirm", GUIType.Button)
    self.llMoney = self:getChildWindow("BuyCurrencyDialog-Money", GUIType.Layout)
    self.slSlider = self:getChildWindow("BuyCurrencyDialog-Slider", GUIType.Slider)
    self.btnReduce = self:getChildWindow("BuyCurrencyDialog-Reduce", GUIType.Button)
    self.btnAdd = self:getChildWindow("BuyCurrencyDialog-Add", GUIType.Button)
    self.btnMax = self:getChildWindow("BuyCurrencyDialog-Max", GUIType.Button)
    self.siGCube = self:getChildWindow("BuyCurrencyDialog-GCube", GUIType.StaticImage)
    self.stTip1 = self:getChildWindow("BuyCurrencyDialog-Tip1", GUIType.StaticText)
    self.stTip2 = self:getChildWindow("BuyCurrencyDialog-Tip2", GUIType.StaticText)
    self.stTip3 = self:getChildWindow("BuyCurrencyDialog-Tip3", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIBuyCurrencyDialogLayout:initView()
    self.btnReduce:SetText("-")
    self.btnAdd:SetText("+")
    self.btnMax:SetText("MAX")
    self.stTitleText:SetText(Lang:getString("lack_of_money"))
    self.btnCancel:SetText(Lang:getString("gui_dialog_tip_btn_cancel"))
    self.btnConfirm:SetText(Lang:getString("gui_dialog_tip_btn_sure"))
end

---@private
function UIBuyCurrencyDialogLayout:initEvent()
    self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnCancel:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    self.btnConfirm:registerEvent(GUIEvent.ButtonClick, function()
        PayHelper.checkMoney(CurrencyId.Diamonds, self.radio[1] * self.level, function(success)
            if success then
                CommonPkSender:tryBuyCurrency(self.currency, self.level)
                self:hide()
            end
        end)
    end)
    self.btnReduce:registerEvent(GUIEvent.ButtonClick, function()
        self:setLevel(math.max(1, self.level - 1))
        self:setSlider()
    end)
    self.btnAdd:registerEvent(GUIEvent.ButtonClick, function()
        self:setLevel(math.min(10, self.level + 1))
        self:setSlider()
    end)
    self.btnMax:registerEvent(GUIEvent.ButtonClick, function()
        self:setLevel(10)
        self:setSlider()
    end)
    self.slSlider:registerEvent(GUIEvent.TouchDown, function()
        self:onSliderMove()
    end)
    self.slSlider:registerEvent(GUIEvent.TouchMove, function()
        self:onSliderMove()
    end)
    self.slSlider:registerEvent(GUIEvent.TouchUp, function()
        self:onSliderMove()
        self:setSlider()
    end)
    self.slSlider:registerEvent(GUIEvent.Release, function()
        self:onSliderMove()
        self:setSlider()
    end)
end

function UIBuyCurrencyDialogLayout:show(currency)
    if isArraignmentApp then
        UIHelper.showToast(Lang:getString("lack_of_money"))
        return
    end
    currency = currency or CurrencyId.Currency
    self.radio = Define.CurrencyExchangeRadio[currency]
    if not self.radio then
        return
    end
    self.currency = currency
    self.super.show(self, currency)
    self.stTip1:SetText(Lang:getString(BuyTip[self.currency][1]))
    self:setLevel(1)
    self:setSlider()
end

---@private
function UIBuyCurrencyDialogLayout:onSliderMove()
    local progress = self.slSlider:GetProgress()
    self.level = math.ceil(progress / 0.1)
    self.level = math.max(1, self.level)
    self:setLevel(self.level)
end

---@private
function UIBuyCurrencyDialogLayout:setLevel(level)
    self.level = level
    local diamond = self.radio[1] * self.level
    local currency = self.radio[2] * self.level
    self.stTip2:SetText(Lang:format(BuyTip[self.currency][2], tostring(diamond), tostring(currency)))
    self.stTip3:SetText(Lang:getString("gui_select_buy_money_num") .. TextFormat.colorGreen .. "  " .. diamond .. "/" .. self.radio[1] * 10)
end

---@private
function UIBuyCurrencyDialogLayout:setSlider()
    self.slSlider:SetProgress(self.level / 10)
end

function UIBuyCurrencyDialogLayout:onShow()
    self:setAlwaysOnTop(true)
    self.root:SetLevel(50)
end

return UIBuyCurrencyDialogLayout
