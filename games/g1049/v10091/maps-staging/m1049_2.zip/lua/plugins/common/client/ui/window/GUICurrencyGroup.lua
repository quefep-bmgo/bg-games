---@class GUICurrencyGroupWindow : IGUIWindow
local GUICurrencyGroupWindow = class("GUICurrencyGroupWindow", IGUIWindow)

---@private
function GUICurrencyGroupWindow:ctor(...)
    self.super.ctor(self, "CurrencyGroup.json", ...)
end

---@private
function GUICurrencyGroupWindow:onLoad()
    self:initView()
    self:initEvent()
end

---@private
function GUICurrencyGroupWindow:initView()
    ---@type GUICurrencyWindow[]
    self.wCurrencyList = {}
end

---@private
function GUICurrencyGroupWindow:initEvent()

end

---@param currencies number[] | table<number, number[]>
function GUICurrencyGroupWindow:onDataChanged(currencies, itemWidth, rightSpace)
    if TableUtil.isSameTable(self.currencies, currencies) then
        return
    end
    itemWidth = itemWidth or 220
    rightSpace = rightSpace or 46
    self.root:CleanupChildren()
    self.wCurrencyList = {}
    self.currencies = currencies
    local size = #currencies
    for index, currency in pairs(currencies) do
        ---@type GUICurrencyWindow
        local wCurrency = UIHelper.newGameGUIWindow("GUICurrency")
        wCurrency:setXPosition({ 0, -(size - index) * itemWidth - rightSpace })
        wCurrency:onDataChanged(currency)
        self.root:AddChildWindow(wCurrency.root)
        table.insert(self.wCurrencyList, wCurrency)
    end
end

function GUICurrencyGroupWindow:onTick()
    for _, wCurrency in pairs(self.wCurrencyList) do
        wCurrency:onTick()
    end
end

return GUICurrencyGroupWindow
