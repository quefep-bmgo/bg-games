---@class UIChristmasMainLayout : IGUILayout
local UIChristmasMainLayout = class("UIChristmasMainLayout", IGUILayout)
---@type ChristmasConfig
local ChristmasConfig = T(Global, "ChristmasConfig")

---@private
function UIChristmasMainLayout:ctor()
    self.super.ctor(self, "ChristmasMain.json", GUIManager:getMainControl())
end

---@private
function UIChristmasMainLayout:isDelayLoad()
    return true
end

---@private
function UIChristmasMainLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIChristmasMainLayout:initCreateEvent()
    self:registerEvent(CEvents.PlayerChangeItemInHandEvent, function(userId, itemId, _)
        if userId ~= Game:getPlatformUserId() then
            return
        end
        self:onHandItemChange(itemId)
    end)
end

---@private
function UIChristmasMainLayout:onLoad()
    self.btnOpenGift = self:getChildWindow("ChristmasMain-OpenGift", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIChristmasMainLayout:initView()
    self.btnOpenGift:SetText(Lang:getString("gui_skill_cast"))
end

---@private
function UIChristmasMainLayout:initEvent()
    self.btnOpenGift:registerEvent(GUIEvent.ButtonClick, function()
        UIHelper.showGameGUILayout("GUIChristmas", 2, self.curSelectItemId)
    end)
end

---@private
function UIChristmasMainLayout:onHandItemChange(itemId)
    local cfg = ChristmasConfig:getCfgByItemId(itemId)
	if not cfg then
		self:hide()
		return
	end
	self:show()
    self.curSelectItemId = itemId
end

return UIChristmasMainLayout
