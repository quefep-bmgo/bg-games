---@class GUIChristmasGiftItemWindow : IGUIWindow
local GUIChristmasGiftItemWindow = class("GUIChristmasGiftItemWindow", IGUIWindow)
---@type CChristmasPkSender
local ChristmasPkSender = T(Global, "PidPacketSender")

---@private
function GUIChristmasGiftItemWindow:ctor(...)
    self.super.ctor(self, "ChristmasGiftItem.json", ...)
end

---@private
function GUIChristmasGiftItemWindow:onLoad()
    self.siIcon = self:getChildWindowByName("ChristmasGiftItem-Icon", GUIType.StaticImage)
    self.btnBuyBtn = self:getChildWindowByName("ChristmasGiftItem-Buy-Btn", GUIType.Button)
    self.stPriceNum = self:getChildWindowByName("ChristmasGiftItem-Price-Num", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("ChristmasGiftItem-Price-Icon", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIChristmasGiftItemWindow:initView()

end

---@private
function GUIChristmasGiftItemWindow:initEvent()
    self.btnBuyBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:tryBuyGift()
    end)
end

---@private
function GUIChristmasGiftItemWindow:tryBuyGift()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    if not inv:isCanAddItem(self.data.ItemId, 0, 1) then
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui_inventory_not_enough"))
                    .show()
        return
    end
    PayHelper.checkMoney(self.data.BuyMoneyType, self.data.BuyPrice, function(success)
        if not success then
            return
        end
		ChristmasPkSender:tryBuyChristmasGift(self.data.Id)
		HostApi.notifyGetItem(self.data.ItemId, 0, 1)
    end)
end

---@param data ChristmasGiftConfigData
function GUIChristmasGiftItemWindow:onDataChanged(data)
    self.data = data
    self.stPriceNum:SetText(tostring(self.data.BuyPrice))
    self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(self.data.BuyMoneyType))
    self.siIcon:SetImage(self.data.BigImage)
end

return GUIChristmasGiftItemWindow
