---@class UIChristmasLayout : IGUILayout
local UIChristmasLayout = class("UIChristmasLayout", IGUILayout)
---@type ChristmasConfig
local ChristmasConfig = T(Global, "ChristmasConfig")
---@type ChristmasGiftRewardConfig
local ChristmasGiftRewardConfig = T(Global, "ChristmasGiftRewardConfig")
---@type CChristmasPkSender
local ChristmasPkSender = T(Global, "PidPacketSender")

local PanelType = {
    BuyPanel = 1,
    OpenPanel = 2,
}

---@private
function UIChristmasLayout:ctor(parent)
    self.super.ctor(self, "Christmas.json", parent)
end

---@private
function UIChristmasLayout:isDelayLoad()
    return true
end

---@private
function UIChristmasLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIChristmasLayout:initCreateEvent()

end

---@private
function UIChristmasLayout:onLoad()
    self.btnBtnClose = self:getChildWindow("Christmas-BtnClose", GUIType.Button)
    self.siOpenGiftBg = self:getChildWindow("Christmas-Open-Gift-Bg", GUIType.StaticImage)
    self.siBuyGiftBg = self:getChildWindow("Christmas-Buy-Gift-Bg", GUIType.StaticImage)
    self.rbBuyGiftTab = self:getChildWindow("Christmas-Buy-Gift-Tab", GUIType.RadioButton)
    self.siBuyGiftSmall = self:getChildWindow("Christmas-Buy-Gift-Small", GUIType.StaticImage)
    self.rbOpenGiftTab = self:getChildWindow("Christmas-Open-Gift-Tab", GUIType.RadioButton)
    self.siOpenGiftSmall = self:getChildWindow("Christmas-Open-Gift-Small", GUIType.StaticImage)
    self.llBuyGiftPanel = self:getChildWindow("Christmas-Buy-Gift-Panel", GUIType.Layout)
    self.llBuyGiftList = self:getChildWindow("Christmas-Buy-Gift-List", GUIType.Layout)
    self.llOpenGiftPanel = self:getChildWindow("Christmas-Open-Gift-Panel", GUIType.Layout)
    self.llSelectGiftPanel = self:getChildWindow("Christmas-Select-Gift-Panel", GUIType.Layout)
    self.stMayHaveText = self:getChildWindow("Christmas-May-Have-Text", GUIType.StaticText)
    self.llRewardList = self:getChildWindow("Christmas-Reward-List", GUIType.Layout)
    self.llMyHaveGiftPanel = self:getChildWindow("Christmas-My-Have-Gift-Panel", GUIType.Layout)
    self.siGiftSmallIcon = self:getChildWindow("Christmas-Gift-Small-Icon", GUIType.StaticImage)
    self.btnToLeftBtn = self:getChildWindow("Christmas-To-Left-Btn", GUIType.Button)
    self.btnToRightBtn = self:getChildWindow("Christmas-To-Right-Btn", GUIType.Button)
    self.stGiftName = self:getChildWindow("Christmas-Gift-Name", GUIType.StaticText)
    self.llRewardDetailPanel = self:getChildWindow("Christmas-Reward-Detail-Panel", GUIType.Layout)
    self.stMyHaveNumText = self:getChildWindow("Christmas-My-Have-Num-Text", GUIType.StaticText)
    self.stMyHaveNum = self:getChildWindow("Christmas-My-Have-Num", GUIType.StaticText)
    self.llRewardHideLayout = self:getChildWindow("Christmas-Reward-Hide-Layout", GUIType.Layout)
    self.llLeftOpenPanel = self:getChildWindow("Christmas-Left-Open-Panel", GUIType.Layout)
    self.btnLeftOpenBtn = self:getChildWindow("Christmas-Left-Open-Btn", GUIType.Button)
    self.siLeftPriceIcon = self:getChildWindow("Christmas-Left-Price-Icon", GUIType.StaticImage)
    self.stLeftPriceNum = self:getChildWindow("Christmas-Left-Price-Num", GUIType.StaticText)
    self.llRightOpenPanel = self:getChildWindow("Christmas-Right-Open-Panel", GUIType.Layout)
    self.btnRightOpenBtn = self:getChildWindow("Christmas-Right-Open-Btn", GUIType.Button)
    self.siRightPriceIcon = self:getChildWindow("Christmas-Right-Price-Icon", GUIType.StaticImage)
    self.stRightPriceNum = self:getChildWindow("Christmas-Right-Price-Num", GUIType.StaticText)
    self.siBigIcon = self:getChildWindow("Christmas-Big-Icon", GUIType.StaticImage)
    self.btnProbability = self:getChildWindow("Christmas-Probability", GUIType.Button)
    self.stProbabilityText = self:getChildWindow("Christmas-Probability-Text", GUIType.StaticText)
    self.llRewardResultPanel = self:getChildWindow("Christmas-Reward-Result-Panel", GUIType.Layout)
    self.siResultBigBg = self:getChildWindow("Christmas-Result-Big-Bg", GUIType.StaticImage)
    self.llResultIcon = self:getChildWindow("Christmas-Result-Icon", GUIType.Layout)
    self.btnResultOkBtn = self:getChildWindow("Christmas-Result-Ok-Btn", GUIType.Button)
    self.stRewardText = self:getChildWindow("Christmas-Reward-Text", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIChristmasLayout:initView()
    self.stMayHaveText:SetText(Lang:getString("gui_open-may-have"))
    self.stMyHaveNumText:SetText(Lang:getString("gui_inv_have_gift_num"))
    self.stRewardText:SetText(Lang:getString("gui_sky_block_pri_reward_text"))
    self.rbBuyGiftTab:SetText(Lang:getString("gui_buy_christmas_gift"))
    self.rbOpenGiftTab:SetText(Lang:getString("gui_open_christmas_gift"))
    self.btnProbability:SetVisible(Game:isChina())
    self.stProbabilityText:SetText("概率")
    self.btnResultOkBtn:SetText(Lang:getString("gui_dialog_tip_btn_sure"))
    self.selectGiftIndex = 1
end

---@private
function UIChristmasLayout:initEvent()
    self.btnBtnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
        SoundUtil.clickUI()
    end)
    self.rbBuyGiftTab:registerEvent(GUIEvent.RadioStateChanged, function()
        if self.rbBuyGiftTab:IsSelected() then
            self:onShowPanel(PanelType.BuyPanel)
        end
    end)
    self.rbOpenGiftTab:registerEvent(GUIEvent.RadioStateChanged, function()
        if self.rbOpenGiftTab:IsSelected() then
            self:onShowPanel(PanelType.OpenPanel)
        end
    end)
    self.btnToLeftBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:showRewardList(-1)
    end)
    self.btnToRightBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:showRewardList(1)
    end)
    self.btnLeftOpenBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:tryOpenGift(1)
    end)
    self.btnRightOpenBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:tryOpenGift(2)
    end)
    self.btnProbability:registerEvent(GUIEvent.ButtonClick, function()
        ProbabilityDialog.show("g1048_1")
    end)
    self.btnResultOkBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:hideRewardResult()
    end)
    self.siResultBigBg:registerEvent(GUIEvent.Click, function()
        self:hideRewardResult()
    end)
    self.rbBuyGiftTab:SetSelected(true)
end

---@private
function UIChristmasLayout:hideRewardResult()
    self.llRewardResultPanel:SetVisible(false)
    self.llRewardHideLayout:SetVisible(true)
end

---@private
function UIChristmasLayout:onShowPanel(tabType)
    self:hideRewardResult()
    self.llBuyGiftPanel:SetVisible(tabType == PanelType.BuyPanel)
    self.siBuyGiftBg:SetVisible(tabType == PanelType.BuyPanel)
    self.siBuyGiftSmall:SetVisible(tabType == PanelType.BuyPanel)
    self.llOpenGiftPanel:SetVisible(tabType == PanelType.OpenPanel)
    self.siOpenGiftBg:SetVisible(tabType == PanelType.OpenPanel)
    self.siOpenGiftSmall:SetVisible(tabType == PanelType.OpenPanel)
    if tabType == PanelType.BuyPanel then
        self:onShowBuyPanel()
    else
        self:onShowOpenPanel()
    end
end

function UIChristmasLayout:show(tabType, selectItemId)
    if isArraignmentApp then
        return
    end
    self.super.show(self)
    tabType = tabType or PanelType.BuyPanel
    if tabType == PanelType.BuyPanel then
        self.rbBuyGiftTab:SetSelected(true)
    else
        self.rbOpenGiftTab:SetSelected(true)
        self:updateGiftNumUI()
        if selectItemId then
            local _, index = ChristmasConfig:getCfgByItemId(selectItemId)
            if index then
                self.selectGiftIndex = index
                self:showRewardList(0)
            end
        end
    end
end

---@private
function UIChristmasLayout:onShowBuyPanel()
    if self.gvBuyGiftItems then
        return
    end
    self.gvBuyGiftItems = IGUIGridView.new("SkyBlockChristmas-Buy-Gift-Items", self.llBuyGiftList)
    self.gvBuyGiftItems:setConfig(25, 0, 2)
    local cfgs = ChristmasConfig:getAllCfgs()
    for _, cfg in pairs(cfgs) do
        local item = UIHelper.newGameGUIWindow("GUIChristmasGiftItem")
        item:onDataChanged(cfg)
        item:setHeight({ 1, 0 })
        self.gvBuyGiftItems:addItem(item)
    end
end

---@private
function UIChristmasLayout:onShowOpenPanel()
    if self.gvOpenRewardItems then
        self:updateGiftNumUI()
        return
    end
    self.gvOpenRewardItems = IGUIGridView.new("SkyBlockChristmas-Open-Reward-Items", self.llRewardList)
    self.gvOpenRewardItems:setConfig(5, 5, 5)
    ---@type ChristmasGiftRewardAdapter
    self.openRewardAdapter = UIHelper.newGameAdapter("ChristmasGiftRewardAdapter")
    self.gvOpenRewardItems:setAdapter(self.openRewardAdapter)
    ---@type GUIChristmasGiftRewardItemWindow
    self.wRewardResult = UIHelper.newGameGUIWindow("GUIChristmasGiftRewardItem")
    self.wRewardResult:setSize({ 1, 0 }, { 1, 0 })
    self.llResultIcon:AddChildWindow(self.wRewardResult.root)
    self:showRewardList(0)
end

---@private
function UIChristmasLayout:showRewardList(index)
    local cfgs = ChristmasConfig:getAllCfgs()
    self.selectGiftIndex = self.selectGiftIndex + index
    if self.selectGiftIndex > TableUtil.getTableSize(cfgs) then
        self.selectGiftIndex = 1
    end
    if self.selectGiftIndex < 1 then
        self.selectGiftIndex = TableUtil.getTableSize(cfgs)
    end
    local cfg = cfgs[self.selectGiftIndex]
    if not cfg then
        return
    end
    self.stGiftName:SetText(Lang:getString(cfg.Name))
    self.siBigIcon:SetImage(cfg.BigImage)
    self.siGiftSmallIcon:SetImage(cfg.Image)
    self.llLeftOpenPanel:SetVisible(cfg.OpenMoneyType1 ~= 0)
    self.llRightOpenPanel:SetXPosition({ 0, cfg.OpenMoneyType1 == 0 and 130 or 270 })
    if cfg.OpenMoneyType1 ~= 0 then
        self.siLeftPriceIcon:SetImage(PayHelper.getMoneyIcon(cfg.OpenMoneyType1))
        self.stLeftPriceNum:SetText(cfg.OpenPrice1)
    end
    self.siRightPriceIcon:SetImage(PayHelper.getMoneyIcon(cfg.OpenMoneyType2))
    self.stRightPriceNum:SetText(cfg.OpenPrice2)
    self:updateGiftNumUI()
    self.openRewardAdapter:setData(cfg.Rewards)
end

---@private
function UIChristmasLayout:updateGiftNumUI()
    local cfgs = ChristmasConfig:getAllCfgs()
    local cfg = cfgs[self.selectGiftIndex]
    if not cfg then
        return
    end
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    local itemNum = inv:getItemCount(cfg.ItemId)
    self.stMyHaveNum:SetText("x" .. itemNum)
end

---@private
function UIChristmasLayout:onShow()
    GUISkyBlockMoneyDeatil:show()
    self.root:AddChildWindow(GUISkyBlockMoneyDeatil.root)
end

---@private
function UIChristmasLayout:onTick()
    self:updateGiftNumUI()
end

---@private
function UIChristmasLayout:tryOpenGift(type)
    local cfgs = ChristmasConfig:getAllCfgs()
    local cfg = cfgs[self.selectGiftIndex]
    if not cfg then
        return
    end
    if type == 1 and cfg.OpenMoneyType1 == 0 then
        return
    end
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    if inv:getItemCount(cfg.ItemId) == 0 then
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui_not_have_cur_gift"))
                    .setRightClickListener(function()
            self.rbBuyGiftTab:SetSelected(true)
        end)        .show()
        return
    end
    if not inv:isCanAddItem(cfg.ItemId, 0, 1) then
        CustomDialog.builder()
                    .setContentText(Lang:getString("gui_inventory_not_enough"))
                    .show()
        return
    end
    local openMoneyType = type == 1 and cfg.OpenMoneyType1 or cfg.OpenMoneyType2
    local openPrice = type == 1 and cfg.OpenPrice1 or cfg.OpenPrice2
    PayHelper.checkMoney(openMoneyType, openPrice, function(success)
        if not success then
            return
        end
        ChristmasPkSender:tryOpenChristmasGift(cfg.Id, type)
    end)
end

function UIChristmasLayout:showChristmasGiftReward(id, num)
    local cfg = ChristmasGiftRewardConfig:getCfgById(id)
    if not cfg then
        return
    end
    cfg = TableUtil.copyTable(cfg)
    cfg.Num = num
    self.llRewardResultPanel:SetVisible(true)
    self.llRewardHideLayout:SetVisible(false)
    self.wRewardResult:onDataChanged(cfg)
end

return UIChristmasLayout
