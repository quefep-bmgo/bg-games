---@class GUIChristmasGiftRewardItemWindow : IGUIWindow
local GUIChristmasGiftRewardItemWindow = class("GUIChristmasGiftRewardItemWindow", IGUIWindow)

---@private
function GUIChristmasGiftRewardItemWindow:ctor(...)
    self.super.ctor(self, "ChristmasGiftRewardItem.json", ...)
end

---@private
function GUIChristmasGiftRewardItemWindow:onLoad()
    self.siItemBg = self:getChildWindowByName("ChristmasGiftRewardItem-Item-Bg", GUIType.StaticImage)
    self.siItemIcon = self:getChildWindowByName("ChristmasGiftRewardItem-Item-Icon", GUIType.StaticImage)
    self.stItemNum = self:getChildWindowByName("ChristmasGiftRewardItem-Item-Num", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUIChristmasGiftRewardItemWindow:initView()

end

---@private
function GUIChristmasGiftRewardItemWindow:initEvent()
    self.root:registerEvent(GUIEvent.Click, function()
        GUISkyBlockItemDetail:onSetData(self.data)
        GUISkyBlockItemDetail:show()
    end)
end

---@param data ChristmasGiftRewardConfigData
function GUIChristmasGiftRewardItemWindow:onDataChanged(data)
    self.data = data
    self.siItemIcon:SetImage(data.Icon)
    local textLen = string.len(data.Icon)
    if textLen > 2 then
        GuiItemStack.showItemIcon(self.siItemIcon, data.ItemId, data.Meta, data.Icon)
    else
        GuiItemStack.showItemIcon(self.siItemIcon, data.ItemId, data.Meta, "")
    end
    if type(data.Num) == "number" then
        self.stItemNum:SetVisible(true)
        self.stItemNum:SetText("x" .. data.Num)
    else
        self.stItemNum:SetVisible(false)
    end
end

return GUIChristmasGiftRewardItemWindow
