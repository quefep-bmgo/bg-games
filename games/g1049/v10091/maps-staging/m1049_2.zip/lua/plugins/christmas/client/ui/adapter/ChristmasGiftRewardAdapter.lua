---@class ChristmasGiftRewardAdapter : IDataAdapter
local ChristmasGiftRewardAdapter = class("ChristmasGiftRewardAdapter", IDataAdapter)

function ChristmasGiftRewardAdapter:getWindowClass()
    return UIHelper.requireGUIWindow("GUIChristmasGiftRewardItem", false)
end

function ChristmasGiftRewardAdapter:getJsonName()
    return "ChristmasGiftRewardItem.json"
end

function ChristmasGiftRewardAdapter:getItemWidth()
    return { 0, 70 }
end

function ChristmasGiftRewardAdapter:getItemHeight()
    return { 0, 70 }
end

return ChristmasGiftRewardAdapter