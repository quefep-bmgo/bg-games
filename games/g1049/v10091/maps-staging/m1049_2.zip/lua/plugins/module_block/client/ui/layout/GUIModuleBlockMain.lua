---@class UIModuleBlockMainLayout : IGUILayout
local UIModuleBlockMainLayout = class("UIModuleBlockMainLayout", IGUILayout)
---@type ModuleBlockConfig
local ModuleBlockConfig = T(Global, "ModuleBlockConfig")
---@type PlaceBlockHelper
local PlaceBlockHelper = T(Global, "PlaceBlockHelper")

---@private
function UIModuleBlockMainLayout:ctor()
    self.super.ctor(self, "ModuleBlockMain.json", GUIManager:getMainControl())
end

---@private
function UIModuleBlockMainLayout:isDelayLoad()
    return true
end

---@private
function UIModuleBlockMainLayout:onCreate()
    self.equipModuleIds = {}
    self:initCreateEvent()
end

---@private
function UIModuleBlockMainLayout:initCreateEvent()
    self:registerEvent(CEvents.PlayerChangeItemInHandEvent, function(userId, itemId, _)
        if userId ~= Game:getPlatformUserId() then
            return
        end
        self:onHandItemChange(itemId)
    end)
end

---@private
function UIModuleBlockMainLayout:onLoad()
    self.btnFrontPlace = self:getChildWindow("ModuleBlockMain-FrontPlace", GUIType.Button)
    self.siModuleImage = self:getChildWindow("ModuleBlockMain-ModuleImage", GUIType.StaticImage)
    self.btnChange = self:getChildWindow("ModuleBlockMain-Change", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIModuleBlockMainLayout:initView()
    self.btnChange:SetVisible(false)
    self.siModuleImage:SetImage("set:module_block.json image:img_0_add")
end

---@private
function UIModuleBlockMainLayout:initEvent()
    self.btnFrontPlace:registerEvent(GUIEvent.ButtonClick, function()
        PlaceBlockHelper:onClickFrontBuildButton()
    end)
    self.btnChange:registerEvent(GUIEvent.ButtonClick, function()
        self:changeCurItemModule()
    end)
end

---@private
function UIModuleBlockMainLayout:onHandItemChange(itemId)
    if itemId == 0 then
        self:hide()
        return
    end
    if not Item.isBlockItem(itemId) then
        self:hide()
        return
    end
    self:show()
    self.siModuleImage:SetImage("set:module_block.json image:img_0_add")
    self.btnChange:SetVisible(false)
    local modules = ModuleBlockConfig:getModuleBlocks(itemId)
    if TableUtil.isEmpty(modules) then
        return
    end
    local teamId = PlayerManager:getClientPlayer():getTeamId()
    local moduleId = self.equipModuleIds[itemId] or ModuleBlockConfig:getDefaultModuleId(itemId)
    local module = ModuleBlockConfig:getModuleBlock(itemId, moduleId, teamId)
    if not module then
        return
    end
    self.equipModuleIds[itemId] = moduleId
    self.siModuleImage:SetImage(module.image)
    self.btnChange:SetVisible(true)
end

local function isOnMount()
    local entityPlayer = PlayerManager:getClientPlayer().Player
    if not entityPlayer then
        return false
    end
    return entityPlayer:isOnFloatingMount() or entityPlayer:isOnFlyingMount()
end

function UIModuleBlockMainLayout:changeCurItemModule()
    local itemId = PlayerManager:getClientPlayer():getHeldItemId()
    if itemId == 0 then
        return
    end
    self.btnChange:SetVisible(false)
    local modules = ModuleBlockConfig:getModuleBlocks(itemId)
    if TableUtil.isEmpty(modules) then
        return
    end
    local moduleId = self.equipModuleIds[itemId] or ModuleBlockConfig:getDefaultModuleId(itemId)
    ---@type ModuleBlockData
    local nextModule
    for index, module in pairs(modules) do
        if module.id == moduleId then
            nextModule = modules[index + 1]
        end
    end
    if not nextModule then
        nextModule = modules[1]
    end
    self.equipModuleIds[itemId] = nextModule.id
    self.siModuleImage:SetImage(nextModule.image)
    self.btnChange:SetVisible(true)
    PlayerManager:getClientPlayer():sendPacket({
        pid = "ChangeModuleBlock",
        itemId = itemId,
        moduleId = self.equipModuleIds[itemId],
    })
end

function UIModuleBlockMainLayout:onTick()
    local onMount = isOnMount()
    local showFrontPlace = Events.ShowFrontPlaceBlockEvent:invoke()
    self.btnFrontPlace:SetVisible(not onMount and showFrontPlace)
    local itemId = PlayerManager:getClientPlayer():getHeldItemId()
    if self.equipModuleIds[itemId] then
        self.btnChange:SetVisible(not onMount and showFrontPlace)
    else
        self.btnChange:SetVisible(false)
    end
end

return UIModuleBlockMainLayout
