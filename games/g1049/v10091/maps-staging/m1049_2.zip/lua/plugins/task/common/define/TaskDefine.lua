---@type Define
Define = T(Global, "Define")

Define.TaskStatus = {
    None = 1,       ---未解锁
    Doing = 2,      ---正在做
    Finished = 3,   ---已完成
    Received = 4,   ---已领奖
}

Define.TaskType = {
    DailyLogin = 1,             --每日登陆
    SubmitItem = 2,             --缴纳物品
    OwnItem = 3,                --持有物品
    KillMonster = 4,            --击杀怪物
    InvolvedKillMonster = 5,    --参与击杀怪物
    KillPlayer = 6,             --击杀玩家
    BreakBlock = 7,             --破坏方块
    PlaceBlock = 8,             --放置方块
    UseMoney = 9,               --消耗金币
    SellItem = 10,              --出售物品
    GainMoney = 11,             --获得金币
    CompoundItem = 12,          --合成物品
    JoinParty = 13,             --参与派对
    ThumbsUp = 14,              --家园点赞
    FinishTaskChain = 15,       --完成跑环
    UseItem = 16,               --使用消耗品
    TogetherBuild = 17          --共同建造
}

Define.TaskTagIcon = {
    [Define.TaskType.DailyLogin] = "set:icon.json image:icon_0_corner_scale06",
    [Define.TaskType.SubmitItem] = "set:icon.json image:icon_0_corner_scale01",
    [Define.TaskType.OwnItem] = "set:icon.json image:icon_0_corner_scale01",
    [Define.TaskType.KillMonster] = "set:icon.json image:icon_0_corner_scale02",
    [Define.TaskType.InvolvedKillMonster] = "set:icon.json image:icon_0_corner_scale02",
    [Define.TaskType.KillPlayer] = "set:icon.json image:icon_0_corner_scale02",
    [Define.TaskType.BreakBlock] = "set:icon.json image:icon_0_corner_scale03",
    [Define.TaskType.PlaceBlock] = "set:icon.json image:icon_0_corner_scale03",
    [Define.TaskType.UseMoney] = "set:icon.json image:icon_0_corner_scale05",
    [Define.TaskType.SellItem] = "set:icon.json image:icon_0_corner_scale01",
    [Define.TaskType.GainMoney] = "set:icon.json image:icon_0_corner_scale05",
    [Define.TaskType.CompoundItem] = "set:icon.json image:icon_0_corner_scale04",
    [Define.TaskType.JoinParty] = "set:icon.json image:icon_0_corner_scale06",
    [Define.TaskType.ThumbsUp] = "set:icon.json image:icon_0_corner_scale06",
    [Define.TaskType.FinishTaskChain] = "set:icon.json image:icon_0_corner_scale07",
    [Define.TaskType.UseItem] = "set:icon.json image:icon_0_corner_scale01",
    [Define.TaskType.TogetherBuild] = "set:icon.json image:icon_0_corner_scale06",
}

Define.TaskRefreshCycle = {
    Forever = 0,            ---永久
    Day = 1,                ---每天
    Week = 2,               ---每周
    Pass = 3,               ---通行证
}

Define.TaskGroup = {
    TaskChain = "task_chain"
}