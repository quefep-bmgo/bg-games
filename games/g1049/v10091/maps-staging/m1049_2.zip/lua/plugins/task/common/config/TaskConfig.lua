---@class TaskConfig
local TaskConfig = T(Global, "TaskConfig")
---@type MonsterConfig
local MonsterConfig = T(Global, "MonsterConfig")
---@type TaskSettingData[]
local ConfigList = {}
---@type table<number, TaskPoolData>
local PoolConfig = {}

---@class TaskSetting
---@field refreshCycle table<string, number>

---@class TaskPoolData
---@field weights number
---@field tasks TaskSettingData[]

---@private
function TaskConfig:init()
    ---@type TaskSetting
    self.config = FileUtil.getGameConfigFromJson("task/TaskSetting.json")
    self.config.refreshCycle = self.config.refreshCycle or {}

    local config = FileUtil.getGameConfigFromCsv("task/TaskSetting.csv", 2, true)
    for _, item in pairs(config) do
        ---@class TaskSettingData
        local data = {
            id = tonumber(item.id),
            type = tonumber(item.type),
            value = tonumber(item.value),
            desc = item.desc or "",
            icon = item.icon or "",
            condition = StringUtil.split(item.condition, "#"),
            gameType = StringUtil.split(item.gameType, "#"),
            autoReceive = item.autoReceive == "1",
            rewardId = tonumber(item.rewardId),
            rewardCount = tonumber(item.rewardCount),
            poolId = tonumber(item.poolId),
            weight = tonumber(item.weight),
        }
        ConfigList[data.id] = data
        local pool = PoolConfig[data.poolId] or { weights = 0, tasks = {} }
        pool.weights = pool.weights + data.weight
        table.insert(pool.tasks, data)
        PoolConfig[data.poolId] = pool
    end
end

function TaskConfig:getConfig()
    return self.config
end

function TaskConfig:getRefreshCycle(key)
    return self.config.refreshCycle[key] or Define.TaskRefreshCycle.Forever
end

function TaskConfig:getCfgById(taskId)
    return ConfigList[taskId]
end

function TaskConfig:randomTask(poolId)
    local pool = PoolConfig[poolId]
    if not pool then
        return nil
    end
    local random = math.random(1, pool.weights)
    local weights = 0
    for _, task in pairs(pool.tasks) do
        weights = weights + task.weight
        if weights >= random then
            return task.id
        end
    end
    return nil
end

---@param ivImage GUIStaticImage
---@param cfg TaskSettingData
function TaskConfig:setTaskIcon(ivImage, cfg)
    ivImage:SetHexagonImage("", "")
    ivImage:SetRenderAsBlock(false)
    if not cfg then
        ivImage:SetImage("")
        return
    end
    if cfg.icon ~= "#" then
        ivImage:SetImage(cfg.icon)
        return
    end
    if cfg.type == Define.TaskType.SubmitItem
            or cfg.type == Define.TaskType.OwnItem
            or cfg.type == Define.TaskType.BreakBlock
            or cfg.type == Define.TaskType.PlaceBlock
            or cfg.type == Define.TaskType.SellItem
            or cfg.type == Define.TaskType.CompoundItem
            or cfg.type == Define.TaskType.UseItem
    then
        local itemId, meta = tonumber(cfg.condition[1]) or 0, tonumber(cfg.condition[2]) or -1
        if itemId ~= 0 then
            GuiItemStack.showItemIcon(ivImage, itemId, meta, "")
        else
            ivImage:SetImage("")
        end
    elseif cfg.type == Define.TaskType.UseMoney
            or cfg.type == Define.TaskType.GainMoney
    then
        ivImage:SetImage(PayHelper.getMoneyIcon(CurrencyId.Currency))
    else
        ivImage:SetImage("")
    end
end

---@param stDesc GUIStaticText
---@param cfg TaskSettingData
function TaskConfig:setTaskDesc(stDesc, cfg)
    if not cfg then
        stDesc:SetText("")
        return
    end
    if cfg.desc == "#" then
        stDesc:SetText("")
        return
    end
    local desc = Lang:getString(cfg.desc)
    if cfg.type == Define.TaskType.SubmitItem
            or cfg.type == Define.TaskType.OwnItem
            or cfg.type == Define.TaskType.BreakBlock
            or cfg.type == Define.TaskType.PlaceBlock
            or cfg.type == Define.TaskType.SellItem
            or cfg.type == Define.TaskType.CompoundItem
            or cfg.type == Define.TaskType.UseItem
    then
        local itemId, meta = tonumber(cfg.condition[1]) or 0, tonumber(cfg.condition[2]) or 0
        if itemId > 0 then
            desc = string.format(desc, Lang:getItemName(itemId, meta))
        end
    elseif cfg.type == Define.TaskType.KillMonster
            or cfg.type == Define.TaskType.InvolvedKillMonster
    then
        local type = tonumber(cfg.condition[1])
        local monster = MonsterConfig:getCfgByType(type)
        if monster then
            desc = string.format(desc, Lang:getString(monster.name))
        end
    end
    desc = desc:gsub("{n}", cfg.value)
    stDesc:SetText(desc)
end

TaskConfig:init()

return TaskConfig