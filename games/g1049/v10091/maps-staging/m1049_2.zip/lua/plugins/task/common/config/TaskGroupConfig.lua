---@class TaskGroupConfig
local TaskGroupConfig = T(Global, "TaskGroupConfig")
---@type TaskGroupSettingData[]
local ConfigList = {}
---@type table<string, TaskGroupSettingData[]>
local GroupMap = {}

---@private
function TaskGroupConfig:init()
    local config = FileUtil.getGameConfigFromCsv("task/TaskGroupSetting.csv", 2, true)
    for _, item in pairs(config) do
        ---@class TaskGroupSettingData
        local data = {
            gid = tonumber(item.gid),
            key = item.key,
            nextGid = tonumber(item.nextGid),
            poolId = tonumber(item.poolId),
            isInit = item.isInit == "1",
        }
        ConfigList[data.gid] = data
        local group = GroupMap[item.key] or {}
        table.insert(group, data)
        GroupMap[item.key] = group
    end
    for _, group in pairs(GroupMap) do
        table.sort(group, function(cfg1, cfg2)
            return cfg1.gid < cfg2.gid
        end)
    end
end

function TaskGroupConfig:getCfgsByKey(key)
    return GroupMap[key] or {}
end

function TaskGroupConfig:getCfgById(id)
    return ConfigList[id]
end

TaskGroupConfig:init()

return TaskGroupConfig