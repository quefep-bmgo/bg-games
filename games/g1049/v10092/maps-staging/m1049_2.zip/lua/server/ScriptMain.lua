local CommonMain = require "common.CommonMain"

BaseListener.registerCallBack(CEvents.GameInitEvent, function(config)
    CommonMain:onGameInit()
    if GameType == "g1049" then
        require "mine_hole.Match"
        require "mine_hole.task.GameTimeTask"
        require "mine_hole.listener.GameListener"
        require "mine_hole.listener.DBDataListener"
        require "mine_hole.listener.PlayerListener"
        require "mine_hole.listener.BlockListener"
        require "mine_hole.listener.LogicListener"
        require "mine_hole.listener.CustomListener"
        require "mine_hole.packet.GamePacketSender"
        require "mine_hole.events.GameEvents"
        require "mine_hole.listener.ChestListener"
        HostApi.setLavaDamageSource()
        GameListener.onGameInit(config)
        PlayerListener:init()
        DBDataListener:init()
        BlockListener:init()
        LogicListener:init()
        CustomListener:init()
        ChestListener:init()
        HostApi.setNeedFoodStats(false)
        HostApi.setFoodHeal(false)
        HostApi.setGunFireIsNeedBullet(false)
        HostApi.setBreakBlockSoon(false)
        ServerHelper.putBoolPrefs("SendSystemsChat", false)
        ServerHelper.putBoolPrefs("IsUseCustomArmor", true)
        PlayerManager.IsMessages = false
        HostApi.setSwordBreakBlock(true)
    elseif GameType == "g1050" then
        require "mine_field.Match"
        require "mine_field.task.GameTimeTask"
        require "mine_field.listener.GameListener"
        require "mine_field.listener.DBDataListener"
        require "mine_field.listener.PlayerListener"
        require "mine_field.listener.BlockListener"
        require "mine_field.listener.LogicListener"
        require "mine_field.listener.CustomListener"
        require "mine_field.packet.GamePacketSender"
        require "mine_field.events.GameEvents"
        GameListener.onGameInit(config)
        PlayerListener:init()
        DBDataListener:init()
        BlockListener:init()
        LogicListener:init()
        CustomListener:init()
        HostApi.setNeedFoodStats(false)
        HostApi.setFoodHeal(false)
        HostApi.setGunFireIsNeedBullet(false)
        HostApi.setBreakBlockSoon(false)
        HostApi.setBlockAttr(20, 100)
        ServerHelper.putBoolPrefs("SendSystemsChat", false)
        ServerHelper.putBoolPrefs("IsUseCustomArmor", true)
        ServerHelper.putFloatPrefs("EntityPlayerCollideBoxSize", 3.2)
        PlayerManager.IsMessages = false
    else
        require "main.Match"
        require "main.task.GameTimeTask"
        require "main.listener.GameListener"
        require "main.listener.DBDataListener"
        require "main.listener.PlayerListener"
        require "main.listener.BlockListener"
        require "main.listener.LogicListener"
        require "main.listener.ChestListener"
        require "main.listener.CustomListener"
        require "main.listener.RankListener"
        require "main.packet.GamePacketSender"
        require "main.events.GameEvents"
        require "main.web.SkyBlockWeb"
        require "main.data.GMSkyBlock"
        GameListener.onGameInit(config)
        PlayerListener:init()
        DBDataListener:init()
        BlockListener:init()
        LogicListener:init()
        ChestListener:init()
        CustomListener:init()
        RankListener:init()
        HostApi.setNeedFoodStats(false)
        HostApi.setFoodHeal(false)
        HostApi.setGunFireIsNeedBullet(false)
        HostApi.setBreakBlockSoon(false)
        HostApi.setMaxChangeInChunk(512)
        ServerHelper.putBoolPrefs("SendSystemsChat", false)
        ServerHelper.putBoolPrefs("IsUseCustomArmor", true)
        ServerHelper.putBoolPrefs("NeedSyncSchematicPlaceBlock", true)
        ServerHelper.putBoolPrefs("BlockCustomMeta", true)
        PlayerManager.IsMessages = false
        HostApi.setSwordBreakBlock(true)
        DBManager:disableAutoCache()
    end
    BaseMain:setGameType(GameType)
    DBManager:setGameType("g1048")
end)