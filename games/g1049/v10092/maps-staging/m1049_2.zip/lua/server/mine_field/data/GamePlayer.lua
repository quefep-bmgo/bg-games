---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
require "mine_field.Match"

---@type HomeMgr
local HomeMgr = T(Global, "HomeMgr")
---@type ProductDataInit
local ProductDataInit = T(Global, "ProductDataInit")
---@type ReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type SSkyBlockPlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type SSkyBlockPlayer
GamePlayer = class("GamePlayer", SSkyBlockPlayer)

function GamePlayer:init()
    SSkyBlockPlayer.init(self)
    self:initStaticAttr(0)
    self.manorIndex = 0
    self.yaw = self:getYaw()
    self.isHome = true
    local attr = GameServer:getRoomManager():getUserAttrInfo(self.userId)
    if attr then
        self.manorIndex = attr.manorId
    end
    self.isLife = true
    self.products = {}
    self.on_lineTime = os.time()
    self.off_lineTime = 0
    self.books = {}
    self.backMiningAreaTime = os.time()
    self.backProductTime = os.time()
    self.cur_product_num = 0
    self.privilege = {}
    self.cur_pri_item = {}
    self.isSky = false
    self.stay_time = 0
    self.signIn_id = 1
    self.signIn_dayKey = "0"
    self.canSendCostDiamond = true
    self.signIn_start = "0"
    self.signIn_end = "0"
    self.havePriImgList = {}
    self.notShowSwitchRed = false
    self.notShowRichRed = false
end

function GamePlayer:initShareDataFromDB(data)
    if not data.__first then
        self.hp = data.hp or self.maxHp
        self.foodLevel = data.foodLevel or 20
        self.money = data.money or 0
        self.current_day_money = data.current_day_money or 0
        self.exp = data.exp or 0
        self.level = data.level or 1
        self.area = data.area or "20*20*20"
        self.books = data.books or {}
        self.products = data.products or {}
        self.off_lineTime = data.off_lineTime or 0
        self.backMiningAreaTime = data.backMiningAreaTime or os.time()
        self.backProductTime = data.backProductTime or os.time()
        self.privilege = data.privilege or {}
        self.isSky = data.isSky or false
        self.signIn_id = data.signIn_id or 1
        self.signIn_dayKey = data.signIn_dayKey or "0"
        self.signIn_start = data.signIn_start or "0"
        self.signIn_end = data.signIn_end or "0"
        self.havePriImgList = data.havePriImgList or {}
        self.notShowSwitchRed = data.notShowSwitchRed or false
        self.notShowRichRed = data.notShowRichRed or false
    else
        HostApi.log("initShareDataFromDB the data.__first is true ")
    end
    if not data.__first then
        self:setHealth(data.hp or self.maxHp)
        self:setFoodLevel(data.foodLevel or 20)
    end
    ReportEvent.reportEvent(self.userId, "enter_area")
    PrivilegeConfig:setplayerPrivilege(self)
    PrivilegeConfig:setPrivilegePriImg(self)
    PrivilegeConfig:setInventoryPriImg(self)
    self:syncListInfo()
    self:setCurrency(self.money)
    PrivilegeConfig:checkUnlockThreeNpc(self)
    self:sendSkyBlockShopInfo()
    self:sendSkyBlockPriImg()
    self:sendShowSwitchRed()
    self:sendShowRichRed()
    ProductDataInit:initProductData(self)
    self:checkShowPriSign()
end

function GamePlayer:onMoneyChange()
    self.money = self:getCurrency()
    if self.money then
        HostApi.log("onMoneyChange " .. tostring(self.userId) .. " money: " .. self.money)
    end
end

function GamePlayer:teleHomeWithYaw()
    local home = HomeMgr:findPlayerHome(self)
    if home then
        home:onBackHome(self)
    end
end

function GamePlayer:getListInfo()
    local lv = self.level or 1
    local cur_exp = self.exp or 0
    local max_exp, is_max = IslandLevelConfig:getMaxExp(self.level)
    local area = self.area or "20*20*20"
    local sortType = AppShopConfig:getSortTypeByScore(self.level)
    local island_lv = IslandAreaConfig:getIdByArea(self.area)
    return lv, cur_exp, max_exp, island_lv, area, is_max, sortType
end

function GamePlayer:syncListInfo()
    local lv, cur_exp, max_exp, island_lv, area, is_max, sortType = self:getListInfo()
    self:sendPacket({
        pid = "syncListInfo",
        data = {
            lv = lv,
            exp = cur_exp,
            maxExp = max_exp,
            area = area,
            userId = self.userId
        }
    })
    self:sendSkyBlockShopInfo()
end

function GamePlayer:sendSkyBlockShopInfo()
    local data = {}
    data.priData = self:getpriData()
    data.npcData = self:getnpcData()
    data.priItemData = self:getPriItemData()

    local sortType = AppShopConfig:getSortTypeByScore(self.level)
    PrivilegeConfig:checkSpePri(self)
    HostApi.sendSkyBlockShopInfo(self.rakssid, sortType, self.level, json.encode(data))
end

function GamePlayer:getPriItemData()
    local priItemData = {}
    for k, v in pairs(self.cur_pri_item) do
        local data = {}
        data.id = v.Id
        data.priType = v.PriType
        data.detail = v.Detail
        data.have = v.Forever
        if v.Time >= os.time() then
            data.have = true
        end

        table.insert(priItemData, data)
    end
    return priItemData
end

function GamePlayer:getpriData()
    local priData = {}
    for k, v in pairs(self.privilege) do
        local data = {}
        data = {
            id = v.id,
            itemId = v.itemId,
            forever = v.forever,
            time = v.time,
        }
        table.insert(priData, data)
    end

    for k, v in pairs(priData) do
        v.time = v.time - os.time()
        if v.time < 0 then
            v.time = 0
        end
    end
    return priData
end

function GamePlayer:getnpcData()
    local npcdata = {}
    for k, v in pairs(self.products) do
        local data = {}
        data = {
            id = v.ShopId,
            itemId = v.Id,
            forever = v.Time == -1 and true or false,
            time = v.EndTime
        }
        table.insert(npcdata, data)
    end

    for k, v in pairs(npcdata) do
        v.time = v.time - os.time()
        if v.time < 0 then
            v.time = 0
        end
    end
    return npcdata
end

function GamePlayer:insertProductsInfo(id, shopId)
    if not DbUtil:CanSavePlayerData(self, DbUtil.TAG_SHAREDATA) then
        return
    end
    if self.productData then
        self.productData:unlockProduct(id, shopId)
    end
end

function GamePlayer:checkIsHAvePri(priId)
    for k, pri in pairs(self.cur_pri_item) do
        if priId == pri.PriType then
            if pri.Forever then
                return true
            elseif pri.Time >= os.time() then
                return true
            end
        end
    end

    return false
end

function GamePlayer:checkIsCanBuyPri(priId)
    for k, pri in pairs(self.privilege) do
        if pri.itemId == priId then
            if pri.forever then
                return false
            end
        end
    end
    return true
end

function GamePlayer:onTick()
    self.stay_time = self.stay_time + 1
end

function GamePlayer:addScore(score)
    self.score = self.score + score
end

function GamePlayer:reward()
    RewardManager:getUserGoldReward(self.userId, self.score, function(data)

    end)
end

function GamePlayer:CanSavePlayerShareData()
    return DbUtil:CanSavePlayerData(self, DbUtil.TAG_SHAREDATA)
end

function GamePlayer:checkShowPriSign()
    if not PrivilegeConfig:checkPlayerShowPri(self) then
        return
    end
    self:changeClothes("custom_crown", 10)
end

function GamePlayer:checkIsCanUnlockByOther(priId)
    for k, pri in pairs(self.privilege) do
        if pri.itemId == priId then
            return false
        end
    end
    return true
end

function GamePlayer:sendSkyBlockPriImg()
    GamePacketSender:sendSkyBlockPriImg(self.rakssid, self.havePriImgList)
end

function GamePlayer:checkMoney(priceType, price)
    print("self.userId == " .. tostring(self.userId) .. " priceType == " .. tostring(priceType) .. "price == " .. tostring(price))
    if priceType == Define.Money.DIAMOND or priceType == Define.Money.GOLD_DIAMOND then
        if self:getDiamond() >= price then
            return true
        else
            GamePacketSender:sendShowLackDiamond(self.rakssid)
            return false
        end
    end

    if priceType == Define.Money.MONEY then
        if self:getCurrency() >= price then
            return true
        else
            GamePacketSender:sendShowLackMoney(self.rakssid)
            return false
        end
    end

    GamePacketSender:sendShowLackMoney(self.rakssid)
    return false
end

function GamePlayer:sendShowSwitchRed()
    if not self.notShowSwitchRed then
        local data = {}
        data.RedIsShow = true
        GamePacketSender:sendShowSwitchRed(self.rakssid, data)
    end
end

function GamePlayer:sendShowRichRed()
    if not self.notShowRichRed then
        local data = {}
        data.RedIsShow = true
        GamePacketSender:sendShowRichRed(self.rakssid, data)
    end
end

return GamePlayer

--endregion
