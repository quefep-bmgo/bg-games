---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
require "mine_hole.Match"
---@type SSkyBlockPlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type ProductDataInit
local ProductDataInit = T(Global, "ProductDataInit")
---@type ReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type SSkyBlockPlayer
GamePlayer = class("GamePlayer", SSkyBlockPlayer)

function GamePlayer:init()
    SSkyBlockPlayer.init(self)
    self.isLife = true
    self.books = {}
    self.off_lineTime = 0
    self.products = {}
    self.backMiningAreaTime = os.time()
    self.backProductTime = os.time()
    self.backHomeTime = os.time() - GameConfig.backHomeCD
    self.privilege = {}
    self.cur_pri_item = {}
    self.pvpTime = 0
    self.isInPvp = false
    self.inHandItemId = 0
    self.diedPos = VectorUtil.ZERO
    self:initStaticAttr(0)
    self:teleInitPos()
    self.stay_time = 0
    self.has_ad = false
    self.canSendCostDiamond = true
    self.signIn_id = 1
    self.signIn_dayKey = "0"
    self.needRecivePri = false
    self.isNeedGuideArrow = false
    self.signIn_start = "0"
    self.signIn_end = "0"
    self.havePriImgList = {}
    self.notShowSwitchRed = false
    self.notShowRichRed = false
end

function GamePlayer:initShareDataFromDB(data)
    if not data.__first then
        self.hp = data.hp or self.maxHp
        self.foodLevel = data.foodLevel or 20
        self.money = data.money or 0
        self.current_day_money = data.current_day_money or 0
        self.exp = data.exp or 0
        self.level = data.level or 1
        self.area = data.area or "20*20*20"
        self.books = data.books or {}
        self.off_lineTime = data.off_lineTime or 0
        self.products = data.products or {}
        self.backMiningAreaTime = data.backMiningAreaTime or os.time()
        self.backProductTime = data.backProductTime or os.time()
        self.privilege = data.privilege or {}
        self.isSky = data.isSky or false
        self.signIn_id = data.signIn_id or 1
        self.signIn_dayKey = data.signIn_dayKey or "0"
        self.signIn_start = data.signIn_start or "0"
        self.signIn_end = data.signIn_end or "0"
        self.havePriImgList = data.havePriImgList or {}
        self.notShowSwitchRed = data.notShowSwitchRed or false
        self.notShowRichRed = data.notShowRichRed or false
    else
        HostApi.log("initShareDataFromDB the data.__first is true ")
    end
    if not data.__first then
        self:setHealth(data.hp or self.maxHp)
        self:setFoodLevel(data.foodLevel or 20)
    end
    ReportEvent.reportEvent(self.userId, "enter_area")
    PrivilegeConfig:setplayerPrivilege(self)
    PrivilegeConfig:setPrivilegePriImg(self)
    PrivilegeConfig:setInventoryPriImg(self)
    self:syncListInfo()
    self:setCurrency(self.money)
    PrivilegeConfig:checkUnlockThreeNpc(self)
    self:sendSkyBlockShopInfo()
    self:sendSkyBlockPriImg()
    self:sendShowSwitchRed()
    self:sendShowRichRed()
    ProductDataInit:initProductData(self)
    self:checkShowPriSign()
end

function GamePlayer:onMoneyChange()
    self.money = self:getCurrency()
    if self.money then
        HostApi.log("onMoneyChange " .. tostring(self.userId) .. " money: " .. self.money)
    end
end

function GamePlayer:onTick()
    if self.isInPvp then
        self.pvpTime = self.pvpTime + 1
    end
    self.stay_time = self.stay_time + 1
end

function GamePlayer:teleInitPos()
    self:setRespawnPos(GameConfig.initPos)
    -- HostApi.log("teleInitPos x : "..GameConfig.initPos.x.." y : "..GameConfig.initPos.y.." z : "..GameConfig.initPos.z)
    self:setPositionAndRotation(GameConfig.initPos, GameConfig.yaw, 0)
    if self.entityPlayerMP then
        self.entityPlayerMP:setPositionAndUpdate(GameConfig.initPos.x, GameConfig.initPos.y, GameConfig.initPos.z)
    end
    -- HostApi.changePlayerPerspece(self.rakssid, 1)
end

function GamePlayer:getListInfo()
    local lv = self.level or 1
    local cur_exp = self.exp or 0
    local max_exp, is_max = IslandLevelConfig:getMaxExp(self.level)
    local area = self.area or "20*20*20"
    local sortType = AppShopConfig:getSortTypeByScore(self.level)
    local island_lv = IslandAreaConfig:getIdByArea(self.area)
    return lv, cur_exp, max_exp, island_lv, area, is_max, sortType
end

function GamePlayer:syncListInfo()
    local lv, cur_exp, max_exp, island_lv, area, is_max, sortType = self:getListInfo()
    self:sendPacket({
        pid = "syncListInfo",
        data = {
            lv = lv,
            exp = cur_exp,
            maxExp = max_exp,
            area = area,
            userId = self.userId
        }
    })
    self:sendSkyBlockShopInfo()
end

function GamePlayer:sendSkyBlockShopInfo()
    local data = {}
    data.priData = self:getpriData()
    data.npcData = self:getnpcData()
    data.priItemData = self:getPriItemData()

    local sortType = AppShopConfig:getSortTypeByScore(self.level)
    PrivilegeConfig:checkSpePri(self)
    HostApi.sendSkyBlockShopInfo(self.rakssid, sortType, self.level, json.encode(data))
end

function GamePlayer:getPriItemData()
    local priItemData = {}
    for k, v in pairs(self.cur_pri_item) do
        local data = {}
        data.id = v.Id
        data.priType = v.PriType
        data.detail = v.Detail
        data.have = v.Forever
        if v.Time >= os.time() then
            data.have = true
        end

        table.insert(priItemData, data)
    end
    return priItemData
end

function GamePlayer:getpriData()
    local priData = {}
    for k, v in pairs(self.privilege) do
        local data = {}
        data = {
            id = v.id,
            itemId = v.itemId,
            forever = v.forever,
            time = v.time,
        }
        table.insert(priData, data)
    end

    for k, v in pairs(priData) do
        v.time = v.time - os.time()
        if v.time < 0 then
            v.time = 0
        end
    end
    return priData
end

function GamePlayer:getnpcData()
    local npcdata = {}
    for k, v in pairs(self.products) do
        local data = {}
        data = {
            id = v.ShopId,
            itemId = v.Id,
            forever = v.Time == -1 and true or false,
            time = v.EndTime
        }
        table.insert(npcdata, data)
    end

    for k, v in pairs(npcdata) do
        v.time = v.time - os.time()
        if v.time < 0 then
            v.time = 0
        end
    end
    return npcdata
end

function GamePlayer:insertProductsInfo(id, shopId, num)
    if self.productData then
        self.productData:unlockProduct(id, shopId)
    end
end

function GamePlayer:checkIsHAvePri(priId)
    for k, pri in pairs(self.cur_pri_item) do
        if priId == pri.PriType then
            if pri.Forever then
                return true
            elseif pri.Time >= os.time() then
                return true
            end
        end
    end

    return false
end

function GamePlayer:checkIsCanBuyPri(priId)
    for k, pri in pairs(self.privilege) do
        if pri.itemId == priId then
            if pri.forever then
                return false
            end
        end
    end
    return true
end

function GamePlayer:addScore(score)
    self.score = self.score + score
end

function GamePlayer:reward()
    RewardManager:getUserGoldReward(self.userId, self.score, function(data)

    end)
end

function GamePlayer:CanSavePlayerShareData()
    return DbUtil:CanSavePlayerData(self, DbUtil.TAG_SHAREDATA)
end

function GamePlayer:checkShowPriSign()
    if not PrivilegeConfig:checkPlayerShowPri(self) then
        return
    end
    self:changeClothes("custom_crown", 10)
end

function GamePlayer:changeGuideArrow(isShow)
    if self.isNeedGuideArrow == isShow then
        return
    end
    local pos = GameConfig.ArrowPos
    if pos and pos.x and pos.y and pos.z then
        local data = {}
        data.isShow = isShow
        data.posX = pos.x
        data.posY = pos.y + 1
        data.posZ = pos.z
        self.isNeedGuideArrow = isShow
        GamePacketSender:sendShowGuideArrowBtn(self.rakssid, json.encode(data))
    end
end

function GamePlayer:initHintText()
    for __, v in pairs(GameConfig.hintText) do
        local pos = VectorUtil.newVector3(v.pos[1], v.pos[2], v.pos[3])
        HostApi.addWallText(self.rakssid, 0, 0, tostring(v.text), pos, v.scale, v.yaw, 0, { 1, 1, 1, 1 })
    end
end

function GamePlayer:checkIsCanUnlockByOther(priId)
    for k, pri in pairs(self.privilege) do
        if pri.itemId == priId then
            return false
        end
    end
    return true
end

function GamePlayer:sendSkyBlockPriImg()
    GamePacketSender:sendSkyBlockPriImg(self.rakssid, self.havePriImgList)
end

function GamePlayer:checkMoney(priceType, price)
    print("self.userId == " .. tostring(self.userId) .. " priceType == " .. tostring(priceType) .. "price == " .. tostring(price))
    if priceType == Define.Money.DIAMOND or priceType == Define.Money.GOLD_DIAMOND then
        if self:getDiamond() >= price then
            return true
        else
            GamePacketSender:sendShowLackDiamond(self.rakssid)
            return false
        end
    end

    if priceType == Define.Money.MONEY then
        if self:getCurrency() >= price then
            return true
        else
            GamePacketSender:sendShowLackMoney(self.rakssid)
            return false
        end
    end

    GamePacketSender:sendShowLackMoney(self.rakssid)
    return false
end

function GamePlayer:sendShowSwitchRed()
    if not self.notShowSwitchRed then
        local data = {}
        data.RedIsShow = true
        GamePacketSender:sendShowSwitchRed(self.rakssid, data)
    end
end

function GamePlayer:sendShowRichRed()
    if not self.notShowRichRed then
        local data = {}
        data.RedIsShow = true
        GamePacketSender:sendShowRichRed(self.rakssid, data)
    end
end

return GamePlayer

--endregion


