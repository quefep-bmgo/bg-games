--DbUtil.lua
DbUtil = {}
DbUtil.TAG_SHAREDATA = "ShareData"

DBManager:addMustLoadSubKey(DbUtil.TAG_SHAREDATA)

function DbUtil:getPlayerData(userId)
    DBManager:getPlayerData(userId, DbUtil.TAG_SHAREDATA)
end

function DbUtil:onPlayerGetDataFinish(player, data, subKey)
    if subKey == DbUtil.TAG_SHAREDATA then
        player:initShareDataFromDB(data)
    end
end

function DbUtil:savePlayerData(player, immediate)
    if player == nil then
        return
    end
    DbUtil:SavePlayerShareData(player, immediate)
end

function DbUtil:SavePlayerShareData(player, immediate)
    local subKey = DbUtil.TAG_SHAREDATA
    if not DBManager:isLoadDataFinished(player.userId, subKey) then
        return
    end
    local data = {}
    if player.isLife then
        data.hp = player:getHealth()
        data.maxHp = player:getMaxHealth()
    else
        data.hp = GameConfig.initHP
        data.maxHp = GameConfig.initHP
    end
    data.foodLevel = player.foodLevel
    data.money = player.money
    data.current_day_money = player.current_day_money
    if data.money < 0 then
        data.money = 0
    end
    data.score = player.score
    data.exp = player.exp
    data.level = player.level
    data.area = player.area
    data.products = player.products
    data.books = player.books
    data.off_lineTime = player.off_lineTime
    data.backMiningAreaTime = player.backMiningAreaTime
    data.backProductTime = player.backProductTime
    data.privilege = player.privilege
    data.isSky = player.isSky
    data.signIn_dayKey = player.signIn_dayKey
    data.signIn_id = player.signIn_id
    data.signIn_start = player.signIn_start
    data.signIn_end = player.signIn_end
    data.havePriImgList = player.havePriImgList
    data.notShowSwitchRed = player.notShowSwitchRed
    data.notShowRichRed = player.notShowRichRed
    DBManager:savePlayerData(player.userId, DbUtil.TAG_SHAREDATA, data, immediate)
end

function DbUtil:CanSavePlayerData(player, subKey)
    return DBManager:isLoadDataFinished(player.userId, subKey)
end

return DbUtil