local CommonMain = require "common.CommonMain"

BaseListener.registerCallBack(CEvents.GameInitEvent, function()
    CommonMain:onGameInit()
    if GameType == "g1049" then
        require "mine_hole.listener.GameListener"
        require "mine_hole.listener.DataListener"
        require "mine_hole.config.GameConfig"
        require "mine_hole.packet.GamePacketSender"
        ClientHelper.putBoolPrefs("IsCreatureBloodBar", true)
    elseif GameType == "g1050" then
        require "mine_field.listener.GameListener"
        require "mine_field.listener.DataListener"
        require "mine_field.config.GameConfig"
        require "mine_field.packet.GamePacketSender"
        ClientHelper.putFloatPrefs("EntityPlayerCollideBoxSize", 3.2)
    else
        require "main.events.HandleEvents"
        require "main.listener.GameListener"
        require "main.listener.DataListener"
        require "main.listener.BlockListener"
        require "main.config.GameConfig"
        require "main.packet.GamePacketSender"
        require "main.web.SkyBlockWeb"
        require "main.data.GameData"
        require "main.data.MultiBuildData"
        require "main.data.RankData"
        require "main.data.GMSkyBlock"
        GameData:init()
        RankData:init()
        BlockListener:init()
        ClientHelper.putBoolPrefs("IsShowCrafting", true)
        ClientHelper.putBoolPrefs("BlockCustomMeta", true)
    end
    GameListener:init()
    DataListener:init()
    ClientHelper.putBoolPrefs("IsUseCustomArmor", true)
    ClientHelper.putBoolPrefs("IsShowItemDurability", true)
end)