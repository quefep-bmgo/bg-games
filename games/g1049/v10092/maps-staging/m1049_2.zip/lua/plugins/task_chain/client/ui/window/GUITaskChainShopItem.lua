---@class GUITaskChainShopItemWindow : IGUIWindow
local GUITaskChainShopItemWindow = class("GUITaskChainShopItemWindow", IGUIWindow)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")

---@private
function GUITaskChainShopItemWindow:ctor(...)
    self.super.ctor(self, "TaskChainShopItem.json", ...)
end

---@private
function GUITaskChainShopItemWindow:onLoad()
    self.llRoot = DynamicCast.dynamicCastWindow(GUIType.Layout, self.root)
    self.siIcon = self:getChildWindowByName("TaskChainShopItem-Icon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("TaskChainShopItem-Limit", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUITaskChainShopItemWindow:initView()
    self.taskChain = PlayerManager:getClientPlayer().taskChain
end

---@private
function GUITaskChainShopItemWindow:initEvent()
    self.llRoot:registerEvent(GUIEvent.Click, function()
        ---@type UITaskChainShopLayout
        local GUITaskChainShop = UIHelper.newGameGUILayout("GUITaskChainShop")
        GUITaskChainShop:showShopItemDetail(self.data)
    end)
end

---@private
function GUITaskChainShopItemWindow:getBuyTimes()
    return self.taskChain:getShopBuyTimes(self.data.id)
end

---@param data TaskChainShopItemConfigData
function GUITaskChainShopItemWindow:onDataChanged(data)
    self.data = data
    local reward = data.reward
    RewardConfig:setRewardQuality(self.llRoot, reward, true)
    RewardConfig:setRewardImage(self.siIcon, reward)
    self.stLimit:SetVisible(data.limit > 0)
    local times = self:getBuyTimes()
    if times >= data.limit then
        self.stLimit:SetText(TextFormat.colorRed .. times .. "/" .. data.limit)
    else
        self.stLimit:SetText(times .. "/" .. data.limit)
    end
end

return GUITaskChainShopItemWindow
