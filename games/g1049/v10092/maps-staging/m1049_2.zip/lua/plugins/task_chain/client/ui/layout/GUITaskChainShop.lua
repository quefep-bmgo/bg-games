---@class UITaskChainShopLayout : IGUILayout
local UITaskChainShopLayout = class("UITaskChainShopLayout", IGUILayout)
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")
---@type TaskChainConfig
local TaskChainConfig = T(Global, "TaskChainConfig")

---@private
function UITaskChainShopLayout:ctor(parent)
    self.super.ctor(self, "TaskChainShop.json", parent)
end

---@private
function UITaskChainShopLayout:isDelayLoad()
    return true
end

---@private
function UITaskChainShopLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UITaskChainShopLayout:initCreateEvent()

end

---@private
function UITaskChainShopLayout:isShowAnim()
    return false
end

---@private
function UITaskChainShopLayout:onLoad()
    self.stTitleText = self:getChildWindow("TaskChainShop-TitleText", GUIType.StaticText)
    self.siClose = self:getChildWindow("TaskChainShop-Close", GUIType.StaticImage)
    self.stRefresh = self:getChildWindow("TaskChainShop-Refresh", GUIType.StaticText)
    self.siRefreshIcon = self:getChildWindow("TaskChainShop-RefreshIcon", GUIType.StaticImage)
    self.stTimeText = self:getChildWindow("TaskChainShop-TimeText", GUIType.StaticText)
    self.siImage = self:getChildWindow("TaskChainShop-Image", GUIType.StaticImage)
    self.stName = self:getChildWindow("TaskChainShop-Name", GUIType.StaticText)
    self.stDesc = self:getChildWindow("TaskChainShop-Desc", GUIType.StaticText)
    self.llGoods = self:getChildWindow("TaskChainShop-Goods", GUIType.Layout)
    self.btnShopBuy = self:getChildWindow("TaskChainShop-ShopBuy", GUIType.Button)
    self.siPriceIcon = self:getChildWindow("TaskChainShop-PriceIcon", GUIType.StaticImage)
    self.stPriceText = self:getChildWindow("TaskChainShop-PriceText", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UITaskChainShopLayout:initView()
    self.taskChain = PlayerManager:getClientPlayer().taskChain
    self.stTitleText:SetText(Lang:getString("gui.task.chain.shop.title"))
    self.stRefresh:SetText(Lang:getString("gui.task.chain.refresh"))
    self.stRefresh:SetWidth({ 0, self.stRefresh:GetTextWidth() })
    self.btnShopBuy:SetText(Lang:getString("gui.task.chain.shop.buy"))
    self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(CurrencyId.TaskChainScore))
    ---@type GUICurrencyWindow
    self.wScore = UIHelper.newGameGUIWindow("GUICurrency")
    self.wScore:onDataChanged(CurrencyId.TaskChainScore)
    self.root:AddChildWindow(self.wScore.root)
    self:initShopItemList()
end

---@private
function UITaskChainShopLayout:initEvent()
    self.siClose:registerEvent(GUIEvent.Click, function()
        self:hide()
        SoundUtil.clickUI()
    end)
    self.btnShopBuy:registerEvent(GUIEvent.ButtonClick, function()
        if self.curShopItem then
            self.taskChain:tryBuyShopItem(self.curShopItem.id, 1)
        end
    end)
    self.stRefresh:registerEvent(GUIEvent.Click, function()
        self.taskChain:tryRefreshShop()
    end)
    self.siRefreshIcon:registerEvent(GUIEvent.Click, function()
        self.taskChain:tryRefreshShop()
    end)
end

---@private
function UITaskChainShopLayout:initShopItemList()
    self.gvShopItemList = IGUIGridView.new("TaskChainShop-ShopItems", self.llGoods)
    self.gvShopItemList:setConfig(11, 11, 4)
    self.gvShopItemList:setArea({ 0, 11 }, { 0, 11 }, { 1, -22 }, { 1, -22 })
    ---@type TaskChainShopItemAdapter
    self.shopItemAdapter = UIHelper.newGameAdapter("TaskChainShopItemAdapter")
    self.gvShopItemList:setAdapter(self.shopItemAdapter)
end

---@private
function UITaskChainShopLayout:onTick()
    self.wScore:onTick()
    self:updateRefreshTime()
end

function UITaskChainShopLayout:updateRefreshTime()
    local curTime = os.time()
    local tag = math.floor(curTime / TaskChainConfig.config.shopRefreshTime)
    local endTime = (tag + 1) * TaskChainConfig.config.shopRefreshTime
    self.stTimeText:SetText(DateUtil.getFormatTime(endTime - curTime))
end

function UITaskChainShopLayout:show(...)
    RootGuiLayout.Instance():hideAllChildren()
    self.super.show(self, ...)
    self:updateList()
    self.taskChain.info:addKeyObserver(Define.TaskChainInfoKey.ShopRecord, function()
        self:updateList()
    end)
end

---@private
function UITaskChainShopLayout:onHide()
    RootGuiLayout.Instance():showMainControl()
    self.taskChain.info:clearObserver(Define.TaskChainInfoKey.ShopRecord)
end

---@param data TaskChainShopItemConfigData
function UITaskChainShopLayout:showShopItemDetail(data)
    if data.limit > 0 then
        self.btnShopBuy:SetEnabled(self.taskChain:getShopBuyTimes(data.id) < data.limit)
    else
        self.btnShopBuy:SetEnabled(true)
    end
    if self.curShopItem == data then
        return
    end
    self.curShopItem = data
    RewardConfig:setRewardDetailUI(data.reward, self.siImage, self.stName, self.stDesc)
    self.stPriceText:SetText(data.price)
end

---@private
function UITaskChainShopLayout:updateList()
    local cfgs = self.taskChain:getShopItemCfgs()
    if not TableUtil.tableContain(cfgs, self.curShopItem) then
        self.curShopItem = nil
    end
    self.shopItemAdapter:setData(cfgs)
    if self.curShopItem then
        self:showShopItemDetail(self.curShopItem)
    elseif cfgs[1] then
        self:showShopItemDetail(cfgs[1])
    end
end

return UITaskChainShopLayout
