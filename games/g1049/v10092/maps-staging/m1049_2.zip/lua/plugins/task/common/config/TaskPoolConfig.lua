---@class TaskPoolConfig
local TaskPoolConfig = T(Global, "TaskPoolConfig")
---@type table<number, TaskPoolData>
local TaskPoolList = {}

---@class TaskPoolData
---@field weights number
---@field nextPool number
---@field tasks TaskPoolSettingData[]

---@private
function TaskPoolConfig:init()
    local config = FileUtil.getGameConfigFromCsv("task/TaskPoolSetting.csv", 2, true)
    for _, item in pairs(config) do
        local poolId = tonumber(item.poolId)
        ---@class TaskPoolSettingData
        local data = {
            taskId = tonumber(item.taskId),
            weight = tonumber(item.weight),
        }
        local pool = TaskPoolList[poolId] or { weights = 0, tasks = {}, nextPool = tonumber(item.nextPool) }
        pool.weights = pool.weights + data.weight
        table.insert(pool.tasks, data)
        TaskPoolList[poolId] = pool
    end
end

function TaskPoolConfig:randomTask(poolId, nextPool)
    local pool = TaskPoolList[poolId]
    if not pool then
        return nil
    end
    if nextPool then
        return self:randomTask(pool.nextPool), pool.nextPool
    end
    local random = math.random(1, pool.weights)
    local weights = 0
    for _, task in pairs(pool.tasks) do
        weights = weights + task.weight
        if weights >= random then
            return task.taskId, poolId
        end
    end
    return nil
end

function TaskPoolConfig:getPoolSize(poolId, size)
    size = size or 0
    local pool = TaskPoolList[poolId]
    if not pool then
        return size
    end
    size = size + 1
    return self:getPoolSize(pool.nextPool, size)
end

TaskPoolConfig:init()

return TaskPoolConfig