---@class GUIBackpackPanelWindow : IGUIWindow
local GUIBackpackPanelWindow = class("GUIBackpackPanelWindow", IGUIWindow)
---@type SellItemConfig
local SellItemConfig = T(Global, "SellItemConfig")
---@type CustomArmorConfig
local CustomArmorConfig = T(Global, "CustomArmorConfig")
---@type EquipmentSuitConfig
local EquipmentSuitConfig = T(Global, "EquipmentSuitConfig")
---@type CInventoryPkSender
local InventoryPkSender = T(Global, "PidPacketSender")
---@type ItemContainerMgr
local ItemContainerMgr = T(Global, "ItemContainerMgr")
---@type ItemSlot
local ItemSlot = Plugins.Require("item_container", "common.data.ItemSlot")

local ItemType = {
    All = { "All" },
    ItemArmor = { "ItemArmor", "ItemSword", "ItemPickaxe", "ItemAxe", "ItemSpade", "ItemBow", "ItemArrow", "ItemHoe" },
    ItemBlock = { "ItemBlock", "ItemCloth", "ItemStone", "ItemPiston", "ItemBlockImp", "ItemMultiTextureTile", "ItemSign" },
    ItemCustom = { "ItemCustom", "ItemProp" },
}

local ItemTypeLang = {
    { type = ItemType.All, lang = "backpack.item.type.all" },
    { type = ItemType.ItemArmor, lang = "backpack.item.type.armor" },
    { type = ItemType.ItemBlock, lang = "backpack.item.type.block" },
    { type = ItemType.ItemCustom, lang = "backpack.item.type.custom" },
}

---@private
function GUIBackpackPanelWindow:ctor(...)
    self.super.ctor(self, "BackpackPanel.json", ...)
end

---@private
function GUIBackpackPanelWindow:onLoad()
    self.llEquipmentInv = self:getChildWindowByName("BackpackPanel-EquipmentInv", GUIType.Layout)
    self.awActor = self:getChildWindowByName("BackpackPanel-Actor", GUIType.ActorWindow)
    self.stSuitTip = self:getChildWindowByName("BackpackPanel-SuitTip", GUIType.StaticText)
    self.llActorTouch = self:getChildWindowByName("BackpackPanel-ActorTouch", GUIType.Layout)
    self.stPlayerName = self:getChildWindowByName("BackpackPanel-PlayerName", GUIType.StaticText)
    self.siSwitchEquipment = self:getChildWindowByName("BackpackPanel-SwitchEquipment", GUIType.StaticImage)
    self.stSwitchEquipmentText = self:getChildWindowByName("BackpackPanel-SwitchEquipmentText", GUIType.StaticText)
    self.stHealth = self:getChildWindowByName("BackpackPanel-Health", GUIType.StaticText)
    self.stAttack = self:getChildWindowByName("BackpackPanel-Attack", GUIType.StaticText)
    self.stDefense = self:getChildWindowByName("BackpackPanel-Defense", GUIType.StaticText)
    self.llSwitchType = self:getChildWindowByName("BackpackPanel-SwitchType", GUIType.Layout)
    self.stSwitchTypeText = self:getChildWindowByName("BackpackPanel-SwitchTypeText", GUIType.StaticText)
    self.siSwitchTypeArrow = self:getChildWindowByName("BackpackPanel-SwitchTypeArrow", GUIType.StaticImage)
    self.llSwitchTypeClose = self:getChildWindowByName("BackpackPanel-SwitchTypeClose", GUIType.Layout)
    self.ltSwitchTypeList = self:getChildWindowByName("BackpackPanel-SwitchTypeList", GUIType.List)
    self.llBackpackInv = self:getChildWindowByName("BackpackPanel-BackpackInv", GUIType.Layout)
    self.btnSplit = self:getChildWindowByName("BackpackPanel-Split", GUIType.Button)
    self.btnSort = self:getChildWindowByName("BackpackPanel-Sort", GUIType.Button)
    self.stNoSelectTip = self:getChildWindowByName("BackpackPanel-NoSelectTip", GUIType.StaticText)
    self.llDesc = self:getChildWindowByName("BackpackPanel-Desc", GUIType.Layout)
    self.stItemName = self:getChildWindowByName("BackpackPanel-ItemName", GUIType.StaticText)
    self.stItemDesc = self:getChildWindowByName("BackpackPanel-ItemDesc", GUIType.StaticText)
    self.siItemImage = self:getChildWindowByName("BackpackPanel-ItemImage", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("BackpackPanel-Count", GUIType.StaticText)
    self.siCountSub = self:getChildWindowByName("BackpackPanel-CountSub", GUIType.StaticImage)
    self.siCountAdd = self:getChildWindowByName("BackpackPanel-CountAdd", GUIType.StaticImage)
    self.stItemPriceText = self:getChildWindowByName("BackpackPanel-ItemPriceText", GUIType.StaticText)
    self.btnSell = self:getChildWindowByName("BackpackPanel-Sell", GUIType.Button)
    self.btnThrow = self:getChildWindowByName("BackpackPanel-Throw", GUIType.Button)
    self.llEquipBackpack = self:getChildWindowByName("BackpackPanel-EquipBackpack", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function GUIBackpackPanelWindow:initView()
    self:initShowItemType()
    self.stSuitTip:SetText(Lang:getString("backpack.not.suit.tip"))
    self.btnSell:SetText(Lang:getString("gui_armor_bag_selle_btn_txt"))
    self.btnSplit:SetText(Lang:getString("backpack.split.btn"))
    self.btnSort:SetText(Lang:getString("backpack.sort.btn"))
    self.btnThrow:SetText(Lang:getString("backpack.throw.btn"))
    self.stNoSelectTip:SetText(Lang:getString("backpack.not.select.tip"))
    local info = UserInfoCache:GetCache(Game:getPlatformUserId())
    if info then
        self.stPlayerName:SetText(info.nickName)
    end
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    ---@type GUIItemContainerWindow
    self.wBackpack = UIHelper.newGameGUIWindow("GUIItemContainer", self.llBackpackInv)
    self.wBackpack:initContainer({ 1, 0 }, { 1, 0 }, 62, 1)
    self:setBackpackContainer()
    ---@type GUIItemContainerWindow
    self.wEquipment = UIHelper.newGameGUIWindow("GUIItemContainer", self.llEquipmentInv)
    self.wEquipment:initContainer({ 1, 0 }, { 1, 0 }, 70, 225, 22)
    for _, slot in pairs(inv.equipment.slots) do
        slot.hideBG = true
    end
    self.wEquipment:setItemContainer(inv.equipment)
    ---@type GUIItemContainerWindow
    self.wEquipmentBp = UIHelper.newGameGUIWindow("GUIItemContainer", self.llEquipBackpack)
    self.wEquipmentBp:initContainer({ 0, 71 }, { 0, 213 }, 71, 0, 0)
    self.wEquipmentBp:setYPosition({ 0, 71 })
    for _, slot in pairs(inv.equipmentBp.slots) do
        slot.hideBG = true
    end
    self.wEquipmentBp:setItemContainer(inv.equipmentBp)
    self.btnSplit:SetVisible(false)
    self:onSwitchEquipment()
end

---@private
function GUIBackpackPanelWindow:initShowItemType()
    self.showItemType = ItemType.All
    self.stSwitchTypeText:SetText(Lang:getString(ItemTypeLang[1].lang))
    local lvSwitchTypeList = IGUIListView.new(nil, self.llSwitchType, self.ltSwitchTypeList, Orientation.Vertical)
    lvSwitchTypeList:setItemSpace(4)
    for _, data in pairs(ItemTypeLang) do
        ---@type GUISwitchItemTypeItemWindow
        local item = UIHelper.newGameGUIWindow("GUISwitchItemTypeItem")
        item:setOnClickListener(function()
            self.showItemType = data.type
            self.stSwitchTypeText:SetText(Lang:getString(data.lang))
            self:setBackpackContainer()
            self.ltSwitchTypeList:SetVisible(false)
            self.llSwitchTypeClose:SetVisible(false)
            self.siSwitchTypeArrow:SetImage("set:buttons.json image:img_0_down")
        end)
        item:onDataChanged(data.lang)
        lvSwitchTypeList:addItem(item)
    end
end

---@private
function GUIBackpackPanelWindow:checkUpdateActor()
    local inventory = PlayerManager:getClientPlayer():getInventory()
    if not inventory then
        return
    end
    local itemIds = {}
    for slot = 100, 105 do
        local info = inventory:getItemStackInfo(slot)
        table.insert(itemIds, info.id)
    end
    local equipmentStr = table.concat(itemIds, ",")
    if self.curEquipmentStr == equipmentStr then
        return
    end
    self.curEquipmentStr = equipmentStr
    self.awActor:SetActorByUserId(Game:getPlatformUserId(), 0, false, function()
        self:checkEquipmentSuit()
    end)
end

---@private
function GUIBackpackPanelWindow:setBackpackContainer()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    local maxSize = 45
    self.backpack = ItemContainerMgr:createContainer("backpack:clone", 0)
    for i = 1, maxSize do
        local slot = inv.backpack.slots[i]
        if not slot then
            slot = ItemSlot.new(inv.backpack, i)
            slot.itemId = -1
            table.insert(self.backpack.slots, slot)
        else
            if self.showItemType == ItemType.All then
                table.insert(self.backpack.slots, slot)
                goto CONTINUE
            end
            local item = Item.getItemById(slot.itemId)
            if not item then
                table.insert(self.backpack.slots, slot)
                goto CONTINUE
            end
            if TableUtil.tableContain(self.showItemType, item:getClassName()) then
                table.insert(self.backpack.slots, slot)
                goto CONTINUE
            end
        end
        :: CONTINUE ::
    end
    if self.showItemType ~= ItemType.All then
        table.sort(self.backpack.slots, function(slot1, slot2)
            if slot1.itemId > 0 and slot2.itemId > 0 then
                return slot1.index < slot2.index
            end
            if slot1.itemId == slot2.itemId then
                return slot1.index < slot2.index
            end
            return slot1.itemId > slot2.itemId
        end)
    end
    self.wBackpack:setItemContainer(self.backpack)
end

---@private
function GUIBackpackPanelWindow:initEvent()
    self.llActorTouch:registerEvent(GUIEvent.TouchDown, function(events)
        self.awActor:TouchDown(events.position)
    end)
    self.llActorTouch:registerEvent(GUIEvent.TouchMove, function(events)
        self.awActor:TouchMove(events.position)
    end)
    self.llActorTouch:registerEvent(GUIEvent.TouchUp, function(events)
        self.awActor:TouchUp(events.position)
    end)
    self.btnSplit:registerEvent(GUIEvent.ButtonClick, function()
        self:trySplitInventoryItem()
    end)
    self.btnSort:registerEvent(GUIEvent.ButtonClick, function()
        local inv = PlayerManager:getClientPlayer():getPlayerInventory()
        InventoryPkSender:trySortInventoryItem(inv.backpack.key)
    end)
    self.btnSell:registerEvent(GUIEvent.ButtonClick, function()
        self:trySellInventoryItem()
    end)
    self.btnThrow:registerEvent(GUIEvent.ButtonClick, function()
        self:tryDropInventoryItem()
    end)
    self.siSwitchEquipment:registerEvent(GUIEvent.Click, function()
        InventoryPkSender:trySwitchEquipment()
    end)
    self.llSwitchType:registerEvent(GUIEvent.Click, function()
        self.ltSwitchTypeList:SetVisible(not self.ltSwitchTypeList:IsVisible())
        self.llSwitchTypeClose:SetVisible(self.ltSwitchTypeList:IsVisible())
        if self.ltSwitchTypeList:IsVisible() then
            self.siSwitchTypeArrow:SetImage("set:buttons.json image:img_0_on")
        else
            self.siSwitchTypeArrow:SetImage("set:buttons.json image:img_0_down")
        end
    end)
    self.stCount:registerEvent(GUIEvent.Click, function()
        self:showItemCountInput()
    end)
    self.siCountSub:registerEvent(GUIEvent.Click, function()
        self:updateItemCount(-1)
    end)
    self.siCountAdd:registerEvent(GUIEvent.Click, function()
        self:updateItemCount(1)
    end)
    self.wBackpack:setItemClickListener(function(slot, event)
        if event == GUIEvent.DoubleClick then
            if PlayerManager:getClientPlayer():getPlayerInventory():tryEquipSlot(slot.slot) then
                self:addTimer(LuaTimer:scheduleTicker(function()
                    ---@type UIPlayerInventoryLuaLayout
                    local GUIPlayerInventoryLua = UIHelper.newGameGUILayout("GUIPlayerInventoryLua")
                    GUIPlayerInventoryLua:clearSelectSlot()
                end, 2, 1))
            end
        elseif event == GUIEvent.Click then
            ---@type UIPlayerInventoryLuaLayout
            local GUIPlayerInventoryLua = UIHelper.newGameGUILayout("GUIPlayerInventoryLua")
            GUIPlayerInventoryLua:onClickSlot(slot)
        end
    end)
    self.wEquipment:setItemClickListener(function(slot, event)
        if event == GUIEvent.Click then
            PlayerManager:getClientPlayer():getPlayerInventory():tryUnEquipSlot(slot.slot)
        end
    end)
    self.wEquipmentBp:setItemClickListener(function(slot, event)
        if event == GUIEvent.Click then
            PlayerManager:getClientPlayer():getPlayerInventory():tryUnEquipSlot(slot.slot)
        end
    end)
    local info = PlayerManager:getClientPlayer().info
    if info then
        info:addKeyObserver(Define.PlayerInfoKey.ShowEquipment, function()
            self:onSwitchEquipment()
        end)
    end
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    inv.equipmentBp:addObserver(function()
        self:setBackpackContainer()
    end)
end

function GUIBackpackPanelWindow:onDataChanged(frameTime)
    local player = PlayerManager:getClientPlayer().Player
    if not player then
        return
    end
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    local health = player:getMaxHealth()
    local attack = player:getAttackDamage()
    local defense = 0
    for _, slot in pairs(inventory.equipment.slots) do
        local cfg = CustomArmorConfig:getCfgById(slot.itemId)
        if cfg then
            defense = defense + cfg.defense
        end
    end
    local cfg = CustomArmorConfig:getCfgById(inventory:getHandItemId())
    if cfg then
        attack = attack + cfg.attack
        defense = defense + cfg.defense
    end
    self.stHealth:SetText(math.floor(health))
    self.stAttack:SetText(math.floor(attack))
    self.stDefense:SetText(math.floor(defense))
    self:checkUpdateActor()
end

function GUIBackpackPanelWindow:onShow()
    self.wBackpack:show()
    self.wEquipment:show()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    ---@param slot ItemSlot
    self.observer = function(_, slot)
        if slot == self.curSelectSlot then
            if slot.itemId == 0 then
                ---@type UIPlayerInventoryLuaLayout
                local GUIPlayerInventoryLua = UIHelper.newGameGUILayout("GUIPlayerInventoryLua")
                GUIPlayerInventoryLua:clearSelectSlot()
            else
                self:showItemDesc(slot)
            end
        end
        if slot.container == inv.backpack then
            self.backpack:onItemChange(slot)
        end
    end
    inv.hotbar:addObserver(self.observer)
    inv.backpack:addObserver(self.observer)
    self:setBackpackContainer()
end

function GUIBackpackPanelWindow:onHide()
    self.wBackpack:hide()
    self.wEquipment:hide()
    local inv = PlayerManager:getClientPlayer():getPlayerInventory()
    inv.hotbar:clearObserver(self.observer)
    inv.backpack:clearObserver(self.observer)
end

---@private
function GUIBackpackPanelWindow:updateItemCount(change)
    if self.curSelectSlot == nil then
        return
    end
    local count = tonumber(self.stCount:GetText())
    count = math.min(math.max(1, count + change), self.curSelectSlot.count)
    self.stCount:SetText(count)
    local money = SellItemConfig:getItemMoney(self.curSelectSlot.itemId, self.curSelectSlot.meta)
    self.stItemPriceText:SetText(money * count)
end

---@private
function GUIBackpackPanelWindow:showItemCountInput()
    if self.curSelectSlot == nil then
        return
    end
    local count = tonumber(self.stCount:GetText())
    local max = self.curSelectSlot.count
    ---@type UIDigitalInputLayout
    local UIDigitalInputLayout = UIHelper.showGameGUILayout("GUIDigitalInput", self.stCount)
    UIDigitalInputLayout:setNumberData(count, 1, max)
    UIDigitalInputLayout:setInputListener(function(number)
        self.stCount:SetText(math.min(number, max))
        self:updateItemCount(0)
    end)
end

---@private
function GUIBackpackPanelWindow:trySellInventoryItem()
    if self.curSelectSlot == nil then
        return
    end
    local count = tonumber(self.stCount:GetText())
    if count <= 0 then
        return
    end
    InventoryPkSender:trySellInventoryItem(self.curSelectSlot, count)
end

---@private
function GUIBackpackPanelWindow:tryDropInventoryItem()
    if self.curSelectSlot == nil then
        return
    end
    local count = tonumber(self.stCount:GetText())
    if count <= 0 then
        return
    end
    InventoryPkSender:tryDropInventoryItem(self.curSelectSlot, count)
end

---@private
function GUIBackpackPanelWindow:trySplitInventoryItem()
    if self.curSelectSlot == nil then
        return
    end
    InventoryPkSender:trySplitInventoryItem(self.curSelectSlot)
end

---@private
function GUIBackpackPanelWindow:clearSelectSlot()
    self.llDesc:SetVisible(false)
    self.btnSplit:SetVisible(false)
    self.stNoSelectTip:SetVisible(true)
    self.curSelectSlot = nil
end

---@param slot ItemSlot
function GUIBackpackPanelWindow:showItemDesc(slot)
    if not slot or slot.itemId <= 0 then
        self:clearSelectSlot()
        return
    end
    local item = Item.getItemById(slot.itemId)
    if not item then
        self:clearSelectSlot()
        return
    end
    self.curSelectSlot = slot
    self.llDesc:SetVisible(true)
    self.stNoSelectTip:SetVisible(false)
    self.stItemName:SetText(Lang:getItemName(slot.itemId, slot.meta))
    local cfg = SellItemConfig:getCfg(slot.itemId, slot.meta)
    if cfg then
        self.stItemPriceText:SetText(cfg.money * slot.count)
        self.stItemDesc:SetText(Lang:getString(cfg.desc))
    else
        self.stItemPriceText:SetText("0")
        self.stItemDesc:SetText("")
    end
    self.stCount:SetText(slot.count)
    self.siItemImage:SetHexagonImage("", "")
    self.siItemImage:SetRenderAsBlock(false)
    self.btnSplit:SetVisible(slot.count > 1 and slot.container:getEmptySlotCount() > 0)
    GuiItemStack.showItemIcon(self.siItemImage, slot.itemId, slot.meta, "")
end

---@private
function GUIBackpackPanelWindow:onSwitchEquipment()
    local info = PlayerManager:getClientPlayer().info
    local player = PlayerManager:getClientPlayer().Player
    if info and info:getBoolValue(Define.PlayerInfoKey.ShowEquipment) then
        self.siSwitchEquipment:SetImage("set:backpack.json image:btn_0_visible01")
        self.stSwitchEquipmentText:SetText(Lang:getString("backpack.equipment.on"))
        self.stSwitchEquipmentText:SetHorizontalAlignment(HorizontalAlignment.Right)
        self.stSwitchEquipmentText:SetXPosition({ 0, -3 })
        player.m_showClothes = false
    else
        self.siSwitchEquipment:SetImage("set:backpack.json image:btn_0_visible02")
        self.stSwitchEquipmentText:SetText(Lang:getString("backpack.equipment.off"))
        self.stSwitchEquipmentText:SetHorizontalAlignment(HorizontalAlignment.Left)
        self.stSwitchEquipmentText:SetXPosition({ 0, 3 })
        player.m_showClothes = true
    end
    player:setOutLooksChanged(true)
    self.awActor:SetActorByUserId(Game:getPlatformUserId(), 0, false, function()
        self:checkEquipmentSuit()
    end)
end

---@private
function GUIBackpackPanelWindow:checkEquipmentSuit()
    local inventory = PlayerManager:getClientPlayer():getPlayerInventory()
    local suit = EquipmentSuitConfig:getEquipmentSuit(inventory.equipment)
    if not next(suit) then
        self.stSuitTip:SetText(Lang:getString("backpack.not.suit.tip"))
    else
        local nameList = {}
        for _, suitId in pairs(suit) do
            local cfg = EquipmentSuitConfig:getCfgById(suitId)
            table.insert(nameList, Lang:getString(cfg.name))
            self.awActor:UseBodyPart(cfg.masterName, cfg.slaveName)
        end
        self.stSuitTip:SetText(table.concat(nameList, "\n"))
    end
end

return GUIBackpackPanelWindow
