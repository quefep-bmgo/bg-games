require "mine_hole.data.GamePlayer"

PlayerListener = {}

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)
end

function PlayerListener.onPlayerLogin(clientPeer)
    local player = GamePlayer.new(clientPeer)
    player:init()
    return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerReady(player)
    player:teleInitPos()
    HostApi.sendPlaySound(player.rakssid, 10042)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(TextFormat:getTipType(1049001)))
end

function PlayerListener.onPlayerMove(movePlayer)
    return PlayerManager:getPlayerByPlayerMP(movePlayer) ~= nil
end

return PlayerListener
--endregion
