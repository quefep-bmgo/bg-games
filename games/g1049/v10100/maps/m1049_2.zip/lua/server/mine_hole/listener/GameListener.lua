--region *.lua
GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameInitEvent, self.onGameInit)
end

function GameListener.onGameInit(config)
    GameConfig = {}
    PlayerManager:setMaxPlayer(100)
end

return GameListener
--endregion