--region *.lua

require "main.messages.Messages"
require "main.data.GamePlayer"
require "main.Match"
---@type MultiBuildMgr
local MultiBuildMgr = T(Global, "MultiBuildMgr")

PlayerListener = {}

function PlayerListener:init()

    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerRespawnEvent, self.onPlayerRespawn)
    BaseListener.registerCallBack(CEvents.PlayerDynamicAttrEvent, self.onDynamicAttrInit)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerCallOnTargetManorEvent:registerCallBack(self.onPlayerCallOnTargetManor)
    CEvents.BlockStationaryNotStationaryEvent:registerCallBack(self.onBlockStationaryNotStationary)
    CEvents.PlayerPlaceBlockBoxJudgeEvent:registerCallBack(self.onPlayerPlaceBlockBoxJudgeEvent)
    CEvents.PlayerUseInitSpawnPositionEvent:registerCallBack(self.onPlayerUseInitSpawnPosition)
    CEvents.UserManorReleaseEvent:registerCallBack(self.onUserManorRelease)

    CEvents.SkyBlockPartyAlmostOverEvent:registerCallBack(self.onSkyBlockPartyAlmostOver)
    CEvents.SkyBlockPartyOverEvent:registerCallBack(self.onSkyBlockPartyOver)
end

function PlayerListener.onPlayerLogin(clientPeer)
    local player = GamePlayer.new(clientPeer)
    player:init()
    return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerLogout(player)
    GameMatch:onPlayerQuit(player)
end

---@param player SBasePlayer
function PlayerListener.onPlayerReady(player)
    if player:visitorCheckCanGetBlockData() == false then
        player.isReady = false
        HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
        return 0
    end

    if player.manorIndex <= 0 or player.manorIndex > #GameConfig.manorStart then
        player.isReady = false
        HostApi.log("PlayerListener.onPlayerReady manorIndex error userId: " .. tostring(player.userId) .. " " .. player.manorIndex)
        HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
        return 0
    end

    local manorInfo = GameMatch:getUserManorInfo(player.userId)
    if manorInfo ~= nil then
        manorInfo:masterLogin()
        manorInfo:refreshTime()
        manorInfo:initAllTree()
        DbUtil.getPlayerData(player.userId, DbUtil.TAG_MANOR)
        player:teleInitPos()
        player.manorIsExistWhenReady = true
    else
        player.manorIsExistWhenReady = false
    end

    HostApi.sendPlaySound(player.rakssid, 10041)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))

    -- go home
    if GameMatch:isMaster(player.userId) then
        HostApi.log("PlayerListener.onPlayerReady go home isMaster" .. tostring(player.userId))
        if GameMatch:hasErrorDataInManor(player.userId) then
            HostApi.log("PlayerListener.onPlayerReady master: other has the same manorIndex sendGameover " .. tostring(player.userId))
            HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
            return 0
        end

        local selfManorInfo = GameMatch:getUserManorInfo(player.userId)
        if selfManorInfo and selfManorInfo.isNotInPartyCreateOrOver == false then
            HostApi.log("PlayerListener.onPlayerReady go home manor is in partyCreateOrOver " .. tostring(player.userId))
            HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
            return 0
        end
    else
        HostApi.log("PlayerListener.onPlayerReady is vistor" .. tostring(player.userId) .. " " .. tostring(player.target_user_id))
        if GameMatch:hasErrorDataInManor(player.target_user_id) then
            HostApi.log("PlayerListener.onPlayerReady vistor: other has the same manorIndex sendGameover " .. tostring(player.target_user_id))
            HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
            return 0
        end

        local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
        if targetManorInfo then
            if targetManorInfo.isNotInPartyCreateOrOver == false then
                HostApi.log("PlayerListener.onPlayerReady vistor targetManor is in partyCreateOrOver " .. tostring(player.userId) .. " manorId: " .. tostring(targetManorInfo.userId))
                HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
                return 0
            else
                DbUtil.getPlayerData(player.target_user_id, DbUtil.TAG_MANOR)
                player.info:setValue(Define.PlayerInfoKey.TargetId, player.target_user_id)
                targetManorInfo:visitorInHouse(player.userId)
                player:teleInitPos()
                HostApi.log("PlayerListener.onPlayerReady visitorInHouse userId: " .. tostring(player.userId) .. " manorId: " .. tostring(targetManorInfo.userId))
            end
        end
    end
    Plugins.CallTargetPluginFunc("vf_app_activity", "addGameBadge", player)
end

function PlayerListener.onPlayerRespawn(player)
    player:teleInitPos()
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return false
    end
    if y <= GameConfig.deathLineY then
        if VectorUtil.distance(player:getPosition(), VectorUtil.newVector3(x, y, z)) < 5 then
            player:setHealth(0)
        end
        return false
    end
    player:onMove(x, y, z)
    return true
end

function PlayerListener.onDynamicAttrInit(attr)
    if attr.manorId < 0 then
        return
    end
    local platformId = attr.userId
    local targetUserId = attr.targetUserId
    local manorIndex = attr.manorId
    HostApi.log("==== LuaLog: PlayerListener.onDynamicAttrInit  --- start --- : platformId = "
            .. tostring(platformId) .. ", targetUserId = " .. tostring(targetUserId) .. ", manorIndex = " .. manorIndex)
    if tostring(targetUserId) ~= "0" and manorIndex > 0 then
        GameMatch:initCallOnTarget(platformId, targetUserId)

        local userManorInfo = GameMatch.userManorInfo[tostring(targetUserId)]
        if userManorInfo == nil then

            local isRepeatManor, repeatManor = GameMatch:isRepeatManorIndex(manorIndex)
            if isRepeatManor == true then
                if repeatManor and repeatManor.isInRoomForceRelease == false then
                    HostApi.log("it may be exist repeat manorIndex when a new manor is create check it !")
                end
            end

            HostApi.log("==== LuaLog: GameManor.new : " .. tostring(targetUserId))
            local manorInfo = GameManor.new(manorIndex, targetUserId)
            GameMatch:initUserManorInfo(targetUserId, manorInfo)
            manorInfo:initChunkIndex()

        else
            HostApi.log("==== LuaLog: userManorInfo:refreshTime : " .. tostring(targetUserId) .. " " .. userManorInfo.release_status)

            userManorInfo:refreshTime()
            if userManorInfo.release_status ~= Define.manorRelese.Not then
                userManorInfo:initChunkIndex()
            end

            --if tostring(platformId) ~= tostring(targetUserId) then
            --    userManorInfo:visitorInHouse(platformId)
            --end
        end
    else
        HostApi.log("==== LuaLog: PlayerListener.onDynamicAttrInit [targetUserId == 0] or [manorIndex <= 0] ")
    end
end

function PlayerListener.onPlayerCallOnTargetManor(userId, targetId, from, isFriend, score)
    HostApi.log("onPlayerCallOnTargetManor userId: " .. tostring(userId) .. " targetId: " .. tostring(targetId) .. " from: " .. from)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return true
    end

    if tostring(userId) == tostring(targetId) then
        HostApi.log("onPlayerCallOnTargetManor self " .. tostring(userId))
        return true
    end

    if player.isNotInPartyCreateOrOver == false then
        return true
    end

    local targetPlayer = PlayerManager:getPlayerByUserId(targetId)
    -- target player is not online, see as target manor is not in this server,
    -- because target player may be in party server, but his common manor is in this server
    -- if targetPlayer == nil then
    --     EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", targetId)
    --     return true
    -- end

    if targetPlayer and targetPlayer.isNotInPartyCreateOrOver == false then
        return true
    end

    local manorInfo = GameMatch:getUserManorInfo(targetId)
    if not manorInfo then
        -- vistor is not in this server
        player.info:onJumpGame()
        EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", targetId)
        return true
    else
        if manorInfo.isNotInPartyCreateOrOver == false then
            HostApi.log("onPlayerCallOnTargetManor manor is in createPartyOrOver userId: " .. tostring(player.userId) .. " targetId: " .. tostring(targetId))
            player.info:onJumpGame()
            EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", targetId)
            return true
        end
    end

    player.info:setValue(Define.PlayerInfoKey.TargetId, 0)
    -- out of vistors list of current manor
    GameMatch:leaveCurrentManor(userId)
    local notSameTarget = true
    if tostring(player.target_user_id) == tostring(targetId) then
        notSameTarget = false
    end

    -- vistor is in this server
    local pos = GameConfig:getInitPosByManorIndex(manorInfo.manorIndex)
    if pos then
        HostApi.log("callon in this server userId: " .. tostring(player.userId) .. " targetId: " .. tostring(manorInfo.userId))
        GameMatch:initCallOnTarget(userId, targetId)
        player.isGenisland = false
        player.manorIndex = manorInfo.manorIndex
        player.target_user_id = manorInfo.userId
        player:initChunkIndex()
        player:teleInitPos(pos)
        manorInfo:refreshTime()
        if manorInfo.release_status ~= Define.manorRelese.Not then
            manorInfo:initChunkIndex()
        end
        manorInfo:visitorInHouse(userId)
        MultiBuildMgr:checkUseItemBucketState(player)
        player.info:setValue(Define.PlayerInfoKey.TargetId, targetId)
        player.privilege:onBackHome(player)
    end
    -- end

    return true

end

function PlayerListener.onBlockStationaryNotStationary(blockId)
    return false
end

function PlayerListener.onPlayerPlaceBlockBoxJudgeEvent(blockId)
    return false
end

function PlayerListener.onPlayerUseInitSpawnPosition(userId, position)
    local targetUserId = GameMatch:getTargetByUid(userId)
    if targetUserId ~= nil then
        local targetManorInfo = GameMatch:getUserManorInfo(targetUserId)
        if targetManorInfo ~= nil and targetManorInfo.manorIndex >= 1 and targetManorInfo.manorIndex <= #GameConfig.manorStart then
            local pos = GameConfig:getInitPosByManorIndex(targetManorInfo.manorIndex)
            position.x = pos.x
            position.y = pos.y
            position.z = pos.z
            return false
        end
    end

    return true
end

function PlayerListener.onUserManorRelease(userId)
    HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease packet start " .. tostring(userId))

    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is not online " .. tostring(userId))
        local targetManorInfo = GameMatch:getUserManorInfo(userId)
        if targetManorInfo then
            HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is not online releaseManor " .. tostring(userId) .. " manorIndex: " .. targetManorInfo.manorIndex)
            GameMatch:releaseManor(userId)
            targetManorInfo.isInRoomForceRelease = true
        end
    else
        HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is online " .. tostring(userId))
        local targetManorInfo = GameMatch:getUserManorInfo(userId)
        if targetManorInfo then
            HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is online releaseManor " .. tostring(userId) .. " manorIndex: " .. targetManorInfo.manorIndex)
            GameMatch:releaseManor(userId)
            targetManorInfo.isInRoomForceRelease = true
        end
        HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is online kickout " .. tostring(userId))
        HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
    end
end

function PlayerListener.onSkyBlockPartyOver(userId)
    print("onSkyBlockPartyOver userId == " .. tostring(userId))
    local manorInfo = GameMatch:getUserManorInfo(userId)
    if manorInfo then
        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            player.info:setLoginTip("party_is_over")
            player.info:onJumpGame()
            player.isNotInPartyCreateOrOver = false
            EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", player.userId)
        end

        for _, visitorId in pairs(manorInfo.visitor) do
            local visitor_player = PlayerManager:getPlayerByUserId(visitorId)
            if visitor_player and tostring(visitor_player.userId) ~= tostring(userId) then
                visitor_player.info:setLoginTip("party_is_over")
                if visitor_player:checkBackHome() then
                    visitor_player.isNotInPartyCreateOrOver = false
                    GameMatch:partyGameOverToPlayer(visitorId)
                end
            end
        end

        manorInfo.time = Define.startReleaseTime
        manorInfo.isNotInPartyCreateOrOver = false
        manorInfo:masterLogout()
        GameMatch:releaseManor(userId)
        GameMatch:partyGameOverToPlayer(userId)
    end
end

function PlayerListener.onSkyBlockPartyAlmostOver(userId)
    print("onSkyBlockPartyAlmostOver userId == " .. tostring(userId))
    local manorInfo = GameMatch:getUserManorInfo(userId)
    if manorInfo then
        for _, visitorId in pairs(manorInfo.visitor) do
            local player = PlayerManager:getPlayerByUserId(visitorId)
            if player then
                HostApi.sendCommonTip(player.rakssid, "party_almost_over")
            end
        end
    end

    local player = PlayerManager:getPlayerByUserId(userId)
    if player then
        HostApi.sendCommonTip(player.rakssid, "party_almost_over")
    end
end

return PlayerListener
--endregion
