---@type ItemChestConfig
local ItemChestConfig = T(Global, "ItemChestConfig")
---@type ReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type ItemContainerMgr
local ItemContainerMgr = T(Global, "ItemContainerMgr")
---@type BlockSignGroup
local BlockSignGroup = Plugins.Require("block_sign", "server.data.BlockSignGroup")
---@type HomeActorGroup
local HomeActorGroup = Plugins.Require("home_actor", "server.data.HomeActorGroup")
---@class GameManor
GameManor = class()

function GameManor:ctor(manorIndex, userId)
    self.userId = userId
    self.manorIndex = manorIndex or 0
    self:reset()
    self.release_status = Define.manorRelese.Not
    self.ownerVersion = 0
end

function GameManor:reset()
    self.time = 0
    self.visitor = {}
    self.manorBlock = {}
    self.updateBlock = {}
    self.updateBlockHash = {}
    self.attachUpdateBlock = {}
    self.blockSubKeyDirty = {}
    self.delayReleaseBlock = {}
    self.treeInfo = {}
    self.dirtInfo = {}
    self.cropsInfo = {}
    self.forceChests = {}
    self.posOriginX = 0
    self.posOriginY = 0
    self.posOriginZ = 0
    self.originPos = VectorUtil.ZERO
    self.flowingHigh = {}
    self.waterSource = {}
    self.loading = false
    self.logBlock = {}
    self.isNotInPartyCreateOrOver = true
    self.isInRoomForceRelease = false
    self.respawnPos1 = VectorUtil.newVector3(102, 100, 100)
    self.respawnPos2 = self.respawnPos1
end

function GameManor:clearMem()
    self.visitor = {}
    self.manorBlock = nil
    self.updateBlock = nil
    self.treeInfo = nil
    self.dirtInfo = nil
    self.cropsInfo = nil
    self.flowingHigh = nil
    self.waterSource = nil
    self.attachUpdateBlock = nil
    self.logBlock = nil
end

function GameManor:addTime(time)
    self.time = self.time + time
end

function GameManor:refreshTime()
    if self.isNotInPartyCreateOrOver == true then
        self.time = 0
    else
        HostApi.log("GameManor refreshTime isNotInPartyCreateOrOver manorId: " .. tostring(self.userId))
    end
end

function GameManor:getTime()
    return self.time
end

function GameManor:masterLogin()
    HostApi.log("masterLogin " .. tostring(self.userId))
    local master = self:getMaster()
    if master then
        master.home:setValue(Define.HomeInfoKey.MasterId, self.userId)
        master.home:setValue(Define.HomeInfoKey.OriginPos, self.originPos)
        master.home:setValue(Define.HomeInfoKey.Visitors, self.visitor)
        master.home:setValue(Define.HomeInfoKey.Loading, self.loading)
    end
    for _, visitorId in pairs(self.visitor) do
        local visitor = PlayerManager:getPlayerByUserId(visitorId)
        if visitor then
            visitor.home:setMaster(self.userId, master and master.home or nil)
        end
    end
end

function GameManor:masterLogout()
    HostApi.log("masterLogout " .. tostring(self.userId))
    for _, visitorId in pairs(self.visitor) do
        local visitor = PlayerManager:getPlayerByUserId(visitorId)
        if visitor then
            visitor.home:reset()
        end
    end
end

function GameManor:getMaster()
    return PlayerManager:getPlayerByUserId(self.userId)
end

function GameManor:getMasterState()
    return self:getMaster() ~= nil
end

function GameManor:visitorInHouse(userId)
    if TableUtil.tableContain(self.visitor, userId) then
        return
    end
    table.insert(self.visitor, userId)
    local visitor = PlayerManager:getPlayerByUserId(userId)
    if visitor then
        local master = self:getMaster()
        visitor.home:setMaster(self.userId, master and master.home or nil)
        visitor.home:setValue(Define.HomeInfoKey.Loading, self.loading)
        visitor.home:setValue(Define.HomeInfoKey.OriginPos, self.originPos)
    end
    self:syncVisitors()
    HostApi.log("visitorInHouse selfUserId: " .. tostring(self.userId) .. "vistor: " .. tostring(userId))
end

function GameManor:visitorLeaveHouse(userId)
    if not TableUtil.tableContain(self.visitor, userId) then
        return
    end
    TableUtil.tableRemove(self.visitor, userId)
    self:syncVisitors()
    HostApi.log("visitorLeaveHouse selfUserId: " .. tostring(self.userId) .. "vistor: " .. tostring(userId))
end

function GameManor:checkVisitor()
    local removes = {}
    for _, visitorId in pairs(self.visitor) do
        local player = PlayerManager:getPlayerByUserId(visitorId)
        if player == nil then
            HostApi.log("checkVisitor visitorLeaveHouse info1: " .. tostring(visitorId))
            table.insert(removes, visitorId)
        else
            if player.isNotInPartyCreateOrOver == false then
                HostApi.log("checkVisitor visitorLeaveHouse info2: " .. tostring(visitorId))
                table.insert(removes, visitorId)
            end
        end
    end
    if next(removes) == nil then
        return
    end
    for _, remove in pairs(removes) do
        TableUtil.tableRemove(self.visitor, remove)
    end
    self:syncVisitors()
end

function GameManor:syncVisitors()
    local master = self:getMaster()
    if master then
        master.home:setValue(Define.HomeInfoKey.Visitors, self.visitor)
    end
    --for _, visitorId in pairs(self.visitor) do
    --    local visitor = PlayerManager:getPlayerByUserId(visitorId)
    --    if visitor then
    --        visitor.home:setValue(Define.HomeInfoKey.Visitors, self.visitor)
    --    end
    --end
end

function GameManor:isEmptyVisitor()
    return next(self.visitor) == nil
end

-- pos start

function GameManor:initChunkIndex()
    if self.isNotInPartyCreateOrOver == false then
        HostApi.log("GameManor:initChunkIndex manor is in partyCreateOrOver manorId: " .. tostring(self.userId))
        return
    end

    self.release_status = Define.manorRelese.Not
    self.isInRoomForceRelease = false

    HostApi.log("GameManor:initChunkIndex manorId: " .. tostring(self.userId))

    local target_pos = GameConfig:getInitPosByManorIndex(self.manorIndex)
    local origin_pos = GameConfig:getOriginPosByManorIndex(self.manorIndex)
    if origin_pos and target_pos then
        self.posOriginX = origin_pos.x - GameConfig.manorMax / 2
        self.posOriginY = origin_pos.y - GameConfig.manorMax / 2
        self.posOriginZ = origin_pos.z - GameConfig.manorMax / 2
        self.originPos = VectorUtil.newVector3i(math.floor(self.posOriginX), math.floor(self.posOriginY), math.floor(self.posOriginZ))
        if not self.blockSign then
            self.blockSign = BlockSignGroup.new(self.userId, self.originPos)
        end
        if not self.homeActor then
            self.homeActor = HomeActorGroup.new(self.userId, self.originPos)
        end
        origin_pos.x = origin_pos.x - GameConfig.initSchematicOffset
        origin_pos.y = origin_pos.y - GameConfig.initSchematicOffset
        origin_pos.z = origin_pos.z - GameConfig.initSchematicOffset

        EngineWorld:createSchematic(GameConfig.initSchemetic, origin_pos, false, false, true, 0, 0, 0, self.manorIndex)
        self.isInitSchematic = false
    end
end

function GameManor:isIn(vec3)
    local rPos = self:aPosToRPos(vec3)
    return rPos.x >= 0 and rPos.x < GameConfig.manorMax
            and rPos.y >= 0 and rPos.y < GameConfig.manorMax
            and rPos.z >= 0 and rPos.z < GameConfig.manorMax
end

function GameManor:isNormal(vec3)
    local rPos = self:aPosToRPos(vec3)
    return rPos.x >= 0 and rPos.x <= GameConfig.manorMax
            and vec3.y <= 255
            and rPos.z >= 0 and rPos.z <= GameConfig.manorMax
end

-- pos end

-- GameManorUtil start

function GameManor:rPosToAPos(vec3)
    local x = self.posOriginX + vec3.x
    local y = self.posOriginY + vec3.y
    local z = self.posOriginZ + vec3.z

    return VectorUtil.newVector3i(x, y, z)
end

function GameManor:aPosToRPos(vec3)
    local x = vec3.x - self.posOriginX
    local y = vec3.y - self.posOriginY
    local z = vec3.z - self.posOriginZ

    return VectorUtil.newVector3i(x, y, z)
end

function GameManor:generateSubKey(pos)
    if type(pos) == "table" then
        local posX, posY, posZ = pos.x, pos.y, pos.z
        local curXChunkIndex = math.floor(posX / GameConfig.manorChunk)
        local curYChunkIndex = math.floor(posY / GameConfig.manorChunk)
        local curZChunkIndex = math.floor(posZ / GameConfig.manorChunk)
        return DbUtil.TAG_BLOCK_PRE .. "_" .. curXChunkIndex .. "_" .. curYChunkIndex .. "_" .. curZChunkIndex .. "v2"
    else
        local posX, posY, posZ = GameConfig:decodeHash(pos)
        local curXChunkIndex = math.floor(posX / GameConfig.manorChunk)
        local curYChunkIndex = math.floor(posY / GameConfig.manorChunk)
        local curZChunkIndex = math.floor(posZ / GameConfig.manorChunk)
        return DbUtil.TAG_BLOCK_PRE .. "_" .. curXChunkIndex .. "_" .. curYChunkIndex .. "_" .. curZChunkIndex .. "v2"
    end
end

function GameManor:getBlockDbData(subKey)
    local chunkStr = string.gsub(subKey, DbUtil.TAG_BLOCK_PRE .. "_", "")
    chunkStr = string.gsub(chunkStr, "v2", "")
    local chunkIndex = StringUtil.split(chunkStr, "_", nil, true)
    if #chunkIndex < 3 then
        LogUtil.logScriptException("GameManor:getBlockDbData(subKey) failed, subKey=" .. subKey)
        return
    end
    local cache = DBManager:getCache(self.userId, subKey)
    local data
    if cache and cache.block and next(cache.block) ~= nil then
        data = TableUtil.copyTable1(cache.block)
    else
        data = {}
    end
    local dirty = self.blockSubKeyDirty[subKey]
    for hash, value in pairs(dirty) do
        data[hash] = value
    end
    return data
end

-- GameManorUtil end

-- block start

function GameManor:update()
    local target_pos = GameConfig:getInitPosByManorIndex(self.manorIndex)
    if self.release_status == Define.manorRelese.Start and target_pos then
        local startDeleteBlockTime = tonumber(HostApi.curTimeString())
        for hash, block in pairs(self.manorBlock) do
            if block ~= nil then
                local blockId, _ = GameConfig:decodeValue(block)
                if blockId == BlockID.WATER_MOVING or blockId == BlockID.WATER_STILL or
                        blockId == BlockID.LAVA_MOVING or blockId == BlockID.LAVA_STILL then
                    self.delayReleaseBlock[hash] = block
                    self.manorBlock[hash] = ""
                else
                    local x, y, z = GameConfig:decodeHash(hash)
                    local vec3i = VectorUtil.newVector3i(x, y, z)
                    local aPos = self:rPosToAPos(vec3i)
                    EngineWorld:setBlock(aPos, 0, 0, 0)
                    self.manorBlock[hash] = ""
                end
                local endDeleteBlockTime = tonumber(HostApi.curTimeString())
                if endDeleteBlockTime - startDeleteBlockTime > 50 then
                    break
                end
            end
        end
        self.manorBlock = TableUtil.removeElementByFun(self.manorBlock, function(key, value)
            return value == ""
        end)
        if next(self.manorBlock) ~= nil then
            return
        end

        startDeleteBlockTime = tonumber(HostApi.curTimeString())
        for hash, _ in pairs(self.delayReleaseBlock) do
            local x, y, z = GameConfig:decodeHash(hash)
            local vec3i = VectorUtil.newVector3i(x, y, z)
            local aPos = self:rPosToAPos(vec3i)
            EngineWorld:setBlock(aPos, 0, 0, 0)
            self.delayReleaseBlock[hash] = ""
            local endDeleteBlockTime = tonumber(HostApi.curTimeString())
            if endDeleteBlockTime - startDeleteBlockTime > 200 then
                break
            end
        end
        self.delayReleaseBlock = TableUtil.removeElementByFun(self.delayReleaseBlock, function(key, value)
            return value == ""
        end)
        if next(self.delayReleaseBlock) ~= nil then
            return
        end
        HostApi.log("Define.manorRelese.End " .. tostring(self.userId))
        self.release_status = Define.manorRelese.End
    end

    if self.release_status == Define.manorRelese.Not then
        local startUpdateBlockTime = tonumber(HostApi.curTimeString())
        for key, block in pairs(self.updateBlock) do
            if block.sync == false then
                local aPos = self:rPosToAPos(block.pos)
                if GameConfig:isAttachmentBlock(block.id)
                        or CropsConfig:checkCropsByBlockId(block.id)
                        or GameConfig:isDoorBlock(block.id) then
                    local item = {}
                    item.aPos = aPos
                    item.id = block.id
                    item.meta = block.meta
                    item.sync = false
                    self.attachUpdateBlock[key] = item
                else
                    local set = true
                    if block.id == BlockID.CHEST
                            or block.id == BlockID.FURNACE_IDLE
                            or block.id == BlockID.FURNACE_BURNING
                            or block.id == BlockID.DOOR_WOOD
                            or block.id == BlockID.DOOR_IRON
                            or block.id == BlockID.WHITE_WOOD_DOOR then
                        if GameConfig:checkPosHasBlock(block.id, aPos) then
                            set = false
                        end
                    end

                    if set then
                        EngineWorld:setBlock(aPos, block.id, block.meta, 3)
                    end
                    self:recordBlock(aPos, block.id, block.meta)
                end

                if block.id == BlockID.DIRT then
                    self:initDirtTimeByPos(block.pos)
                end

                if (block.id == BlockID.WATER_MOVING or block.id == BlockID.WATER_STILL) and block.meta == 0 then
                    self:recordWaterSource(aPos)
                end

                block.sync = true
                local endUpdateBlockTime = tonumber(HostApi.curTimeString())
                if endUpdateBlockTime - startUpdateBlockTime > 50 then
                    break
                end
            end
        end
        self.updateBlock = TableUtil.removeElementByFun(self.updateBlock, function(key, value)
            return value.sync == true
        end)
        self.updateBlockHash = TableUtil.removeElementByFun(self.updateBlockHash, function(key, value)
            return value.sync == true
        end)
        self:tryForceSetSchematicChestBlock()
    end
end

function GameManor:tryForceSetSchematicChestBlock()
    if self.ownerVersion ~= 1 then
        return
    end
    if next(self.forceChests) == nil then
        return
    end
    local master = self:getMaster()
    if not master or not master:checkReady() then
        return
    end
    if self:isLoadingBlock() then
        return
    end
    local pre = tostring(self.userId) .. ":chest:"
    local containers = ItemContainerMgr:findItemContainer(pre)
    for index = #self.forceChests, 1, -1 do
        local chestPos = self.forceChests[index]
        local containerHash = pre .. VectorUtil.hashVector3(chestPos, ",")
        if not containers[containerHash] then
            ---没有箱子容器
            table.remove(self.forceChests, index)
            goto CONTINUE
        end
        local subKey = self:generateSubKey(chestPos)
        if not DBManager:isLoadDataFinished(self.userId, subKey) then
            ---箱子所在区域还未被加载
            if master.initBlockCd[subKey] == nil or master.initBlockCd[subKey] == 0 then
                ---加载区域方块，以便加速数据转换
                DbUtil.getPlayerData(self.userId, subKey)
                master.initBlockCd[subKey] = 30
            end
            goto CONTINUE
        end
        local hash = VectorUtil.hashVector3(chestPos, ":")
        if self.updateBlockHash[hash] or self.manorBlock[hash] then
            ---已经被玩家修改过了，换成了任意方块或破坏
            table.remove(self.forceChests, index)
        else
            ---箱子没有任何改动，强制存储
            self:recordBlock(self:rPosToAPos(chestPos), BlockID.CHEST, 0, true)
            EngineWorld:setBlock(self:rPosToAPos(chestPos), BlockID.CHEST, 0, 1, true)
            table.remove(self.forceChests, index)
            ReportEvent.reportEvent(self.userId, "force_save_chest_block", false, {
                source = subKey,
            })
        end
        :: CONTINUE ::
    end
end

function GameManor:delayRecordBlockDirty(rPos, hash, newValue, oldValue, retry)
    if self.release_status ~= Define.manorRelese.Not then
        return
    end
    retry = retry or 10
    local master = self:getMaster()
    if not master then
        ---主人不存在，尝试等待主人进入，每隔3秒重试，重试10次
        LuaTimer:schedule(function()
            self:delayRecordBlockDirty(rPos, hash, newValue, oldValue, retry - 1)
        end, 3000)
        return
    end
    if not master:checkReady() then
        ---主人存在，但是还没ready，在主人ready前无限重试
        LuaTimer:schedule(function()
            self:delayRecordBlockDirty(rPos, hash, newValue, oldValue, retry)
        end, 3000)
    end
    if not self.manorBlock then
        return
    end
    local value = self.manorBlock[hash]
    if value and value ~= oldValue then
        ---方块已经被改变了，情况很少见
        return
    end
    self:recordBlockDirty(rPos, hash, newValue)
    self.manorBlock[hash] = newValue
end

function GameManor:updateAttachBlock()
    if next(self.updateBlock) == nil and self.release_status == Define.manorRelese.Not then
        for _, block in pairs(self.attachUpdateBlock) do
            if block.sync == false then
                block.sync = true

                if block.id == BlockID.SIGN_POST or block.id == BlockID.SIGN_WALL then
                    ---旧告示牌方块数据转换方法，并删除方块数据
                    self.blockSign:initBlockSign(block.aPos, block.id, block.meta)
                    local rPos = self:aPosToRPos(block.aPos)
                    local hash = VectorUtil.hashVector3(rPos)
                    local value = block.id .. ":" .. block.meta
                    self:delayRecordBlockDirty(rPos, hash, "0:0", value)
                else
                    EngineWorld:setBlock(block.aPos, block.id, block.meta, 0)
                end

                if CropsConfig:checkCropsByBlockId(block.id) then
                    self:insertCropsInfo(block.aPos, block.id, block.meta)
                end

                self:recordBlock(block.aPos, block.id, block.meta)

                if block.id == BlockID.SAPLING then
                    local rPos = self:aPosToRPos(block.aPos)
                    self:initTreeTimeByPos(rPos, block.meta)
                end
            end
        end

        self.attachUpdateBlock = TableUtil.removeElementByFun(self.attachUpdateBlock, function(key, value)
            return value.sync == true
        end)

        if next(self.attachUpdateBlock) == nil then
            if self.loading then
                self.loading = false
                self:checkGameLoading()
            end

            self:initCropsTime()
        end
    end
end

function GameManor:checkGameLoading()
    local master = self:getMaster()
    if master then
        master.home:setValue(Define.HomeInfoKey.Loading, self.loading)
    end

    for _, userId in pairs(self.visitor) do
        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            player.home:setValue(Define.HomeInfoKey.Loading, self.loading)
        end
    end
end

function GameManor:initBlockFromDB(data, subKey)
    if self.loading == false and data.block and next(data.block) ~= nil then
        self.loading = true
        self:checkGameLoading()
    end
    local blockCount = 0
    for key, block in pairs(data.block or {}) do
        local dataKeyString = StringUtil.split(key, ":")
        local dataValueString = StringUtil.split(block, ":")
        if dataKeyString and dataValueString then
            local x = tonumber(dataKeyString[1])
            local y = tonumber(dataKeyString[2])
            local z = tonumber(dataKeyString[3])
            local blockId = tonumber(dataValueString[1])
            local blockMeta = tonumber(dataValueString[2])
            local vec3 = VectorUtil.newVector3i(x, y, z)
            local item = {}
            item.pos = vec3
            item.id = blockId
            item.meta = blockMeta
            item.sync = false
            table.insert(self.updateBlock, item)
            self.updateBlockHash[key] = item
            blockCount = blockCount + 1
        end
    end
    self.logBlock[subKey] = blockCount
    HostApi.log("initBlockFromDB userId: " .. tostring(self.userId) .. " subkey: " .. subKey .. " blockCount: " .. blockCount)
end

function GameManor:isLoadingBlock()
    if self.updateBlock and next(self.updateBlock) == nil and self.attachUpdateBlock and next(self.attachUpdateBlock) == nil then
        return false
    end
    return true
end

function GameManor:recordBlockDirty(rPos, hash, value)
    local master = self:getMaster()
    if not master or not master:checkReady() then
        return
    end
    local subKey = self:generateSubKey(rPos)
    if not DBManager:isLoadDataFinished(self.userId, subKey) then
        return
    end
    local dirty = self.blockSubKeyDirty[subKey]
    if dirty then
        dirty[hash] = value
    else
        self.blockSubKeyDirty[subKey] = { [hash] = value }
    end
end

function GameManor:recordBlock(vec3, blockId, blockMeta, dirty)
    blockId = blockId or 0
    blockMeta = blockMeta or 0
    local rPos = self:aPosToRPos(vec3)
    local hash = VectorUtil.hashVector3(rPos)
    local value = blockId .. ":" .. blockMeta
    if blockMeta == 0 and (blockId == BlockID.WATER_MOVING or blockId == BlockID.WATER_STILL or
            blockId == BlockID.LAVA_MOVING or blockId == BlockID.LAVA_STILL) then
        self.flowingHigh[hash] = true
    end
    if dirty and not self:isLoadingBlock() and self.release_status == Define.manorRelese.Not then
        local block = self.manorBlock[hash] or self.attachUpdateBlock[hash] or self.updateBlockHash[hash]
        if block then
            if type(block) == "string" then
                if value ~= block then
                    self:recordBlockDirty(rPos, hash, value)
                end
            else
                if block.id ~= blockId or block.meta ~= blockMeta then
                    self:recordBlockDirty(rPos, hash, value)
                end
            end
        else
            self:recordBlockDirty(rPos, hash, value)
        end
    end
    self.manorBlock[hash] = value
end

function GameManor:recordWaterSource(vec3)

    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z

    self.waterSource[hash] = true
end

function GameManor:checkNewWaterSource(vec3)
    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z

    if self.waterSource and next(self.waterSource) ~= nil and self.waterSource[hash] == nil then
        return true
    end

    return false
end

function GameManor:checkFlowHigh(vec3)
    local rPos = self:aPosToRPos(vec3)
    for x = rPos.x - 1, rPos.x + 1 do
        for y = rPos.y, rPos.y + 1 do
            for z = rPos.z - 1, rPos.z + 1 do
                local hash = x .. ":" .. y .. ":" .. z
                if self.flowingHigh[hash] == true then
                    return true
                end
            end
        end
    end
    return false
end

function GameManor:clearBlockDb()
    self.release_status = Define.manorRelese.Start

    local origin_pos = GameConfig:getOriginPosByManorIndex(self.manorIndex)
    local startPos = VectorUtil.newVector3i(origin_pos.x - GameConfig.manorMax / 2, origin_pos.y - GameConfig.manorMax / 2, origin_pos.z - GameConfig.manorMax / 2)
    local endPos = VectorUtil.newVector3i(origin_pos.x + GameConfig.manorMax / 2, origin_pos.y + GameConfig.manorMax / 2, origin_pos.z + GameConfig.manorMax / 2)
    HostApi.log("clearBlockDb " .. startPos.x .. " " .. startPos.y .. " " .. startPos.z .. " " .. endPos.x .. " " .. endPos.y .. " " .. endPos.z)

    local target_pos = GameConfig:getInitPosByManorIndex(self.manorIndex)

    if origin_pos and target_pos then
        self.posOriginX = origin_pos.x - GameConfig.manorMax / 2
        self.posOriginY = origin_pos.y - GameConfig.manorMax / 2
        self.posOriginZ = origin_pos.z - GameConfig.manorMax / 2

        origin_pos.x = origin_pos.x - GameConfig.initSchematicOffset
        origin_pos.y = origin_pos.y - GameConfig.initSchematicOffset
        origin_pos.z = origin_pos.z - GameConfig.initSchematicOffset
        EngineWorld:destroySchematic(GameConfig.initSchemetic, origin_pos, false, false, 0, 0, -1)
    end

    if self.blockSign then
        self.blockSign:destroy()
        self.blockSign = nil
    end
end

function GameManor:clearActors()
    if self.homeActor then
        self.homeActor:destroy()
        self.homeActor = nil
    end
end

function GameManor:checkBoxLimit()
    local master = PlayerManager:getPlayerByUserId(self.userId)
    if not master then
        return false
    end
    return master.chestController:getContainerCount() >= ItemChestConfig:getChestLimit()
end

function GameManor:checkFurnaceLimit()
    local master = PlayerManager:getPlayerByUserId(self.userId)
    if not master then
        return false
    end
    return master.furnaceController:getContainerCount() >= GameConfig.furnaceLimit
end

function GameManor:checkCropsLimit()
    return TableUtil.getTableSize(self.cropsInfo) >= 200
end

-- manorinfo start

function GameManor:initManorInfoFromDB(data)
    if self.isInitManorData then
        return
    end
    self.isInitManorData = true
    if not data.__first then
        self.treeInfo = data.treeInfo or {}
        self.dirtInfo = data.dirtInfo or {}
        self.cropsInfo = data.cropsInfo or {}
        self.respawnPos1 = data.respawnPos1 or VectorUtil.newVector3(102, 100, 100)
        self.respawnPos2 = data.respawnPos2 or VectorUtil.newVector3(102, 100, 100)
        if not data.ownerVersion or data.ownerVersion == 0 then
            self.ownerVersion = 1
        else
            self.ownerVersion = data.ownerVersion
        end
        if self.ownerVersion == 1 then
            self.forceChests = data.forceChests or TableUtil.copyTable(ItemChestConfig.oldChests)
        end
        if data.respawnPos1 == nil then
            ---出生点坐标数据转换
            DBManager:getPlayerData(self.userId, "player", function(_, _, player)
                self.respawnPos1 = player.respawnPos or self.respawnPos1
                local master = self:getMaster()
                if master and master:checkReady() then
                    master:teleInitPos()
                end
            end)
        else
            local master = self:getMaster()
            if master and master:checkReady() then
                master:teleInitPos()
            end
        end
        for _, visitorId in pairs(self.visitor) do
            local visitor = PlayerManager:getPlayerByUserId(visitorId)
            if visitor and visitor:checkReady() then
                visitor:teleInitPos()
            end
        end
    else
        self.ownerVersion = 2
    end
    HostApi.log("initManorInfoFromDB manorId: " .. tostring(self.userId))
    self:initAllTree()
    --self:initAllDirt()
end

function GameManor:initAllTree()
    if self.treeInfo then
        for hash, meta in pairs(self.treeInfo) do
            local x, y, z = GameConfig:decodeHash(hash)
            local rPos = VectorUtil.newVector3i(x, y, z)
            self:initTreeTimeByPos(rPos, meta)
        end
    end
end

function GameManor:initTreeTimeByPos(vec3, bMeta)
    local master = PlayerManager:getPlayerByUserId(self.userId)
    if master == nil then
        return
    end

    local hash = vec3.x .. ":" .. vec3.y .. ":" .. vec3.z
    local dataString = StringUtil.split(hash, ":")
    if dataString then
        local x = tonumber(dataString[1])
        local y = tonumber(dataString[2])
        local z = tonumber(dataString[3])

        local vec3r = VectorUtil.newVector3i(x, y, z)
        local vec3a = self:rPosToAPos(vec3r)
        local vec3Hash = vec3a.x .. ":" .. vec3a.y .. ":" .. vec3a.z
        local blockMeta = bMeta
        local time = TreeSectionConfig:getTimeByBlockMeta(blockMeta)
        local nowId = EngineWorld:getBlockId(vec3a)
        if nowId == BlockID.SAPLING then
            if GameMatch.treeTime[tostring(master.userId)] == nil then
                GameMatch.treeTime[tostring(master.userId)] = {}
            end

            if GameMatch.treeTime[tostring(master.userId)][vec3Hash] == nil then
                GameMatch.treeTime[tostring(master.userId)][vec3Hash] = LuaTimer:scheduleTimer(function(userId)
                    local master = PlayerManager:getPlayerByUserId(userId)
                    if master then
                        local masterManor = GameMatch:getUserManorInfo(master.userId)
                        if masterManor then
                            TreeSectionConfig:theSchematicReplaceBlock(master.rakssid, blockMeta, vec3a)
                            masterManor:removeTreeInfo(vec3a)
                        end

                        if GameMatch.treeTime[tostring(master.userId)][vec3Hash] then
                            LuaTimer:cancel(GameMatch.treeTime[tostring(master.userId)][vec3Hash])
                            GameMatch.treeTime[tostring(master.userId)][vec3Hash] = nil
                        end

                    end
                end, time * 1000, 1, tostring(master.userId))
            end
        end
    end
end

function GameManor:initAllDirt()
    if self.dirtInfo then
        for hash, meta in pairs(self.dirtInfo) do
            local x, y, z = GameConfig:decodeHash(hash)
            local rPos = VectorUtil.newVector3i(x, y, z)
            self:initDirtTimeByPos(rPos, meta)
        end
    end
end

function GameManor:initDirtTimeByPos(vec3)
    local master = PlayerManager:getPlayerByUserId(self.userId)
    if master == nil then
        return
    end

    local hash = vec3.x .. ":" .. vec3.y .. ":" .. vec3.z
    local dataString = StringUtil.split(hash, ":")
    if dataString then
        local x = tonumber(dataString[1])
        local y = tonumber(dataString[2])
        local z = tonumber(dataString[3])

        local vec3r = VectorUtil.newVector3i(x, y, z)
        local vec3a = self:rPosToAPos(vec3r)
        local vec3Hash = vec3a.x .. ":" .. vec3a.y .. ":" .. vec3a.z
        local time = GameConfig.dirtTime

        if GameMatch.dirtTime[tostring(master.userId)] == nil then
            GameMatch.dirtTime[tostring(master.userId)] = {}
        end

        if GameMatch.dirtTime[tostring(master.userId)][vec3Hash] == nil then
            GameMatch.dirtTime[tostring(master.userId)][vec3Hash] = LuaTimer:scheduleTimer(function(userId)
                local master = PlayerManager:getPlayerByUserId(userId)
                if master then
                    local masterManor = GameMatch:getUserManorInfo(master.userId)
                    if masterManor then
                        EngineWorld:setBlock(vec3a, BlockID.GRASS, 0, 0, true)
                        masterManor:recordBlock(vec3a, BlockID.GRASS, 0, true)
                        masterManor:removeDirtInfo(vec3a)
                    end

                    if GameMatch.dirtTime[tostring(master.userId)][vec3Hash] then
                        LuaTimer:cancel(GameMatch.dirtTime[tostring(master.userId)][vec3Hash])
                        GameMatch.dirtTime[tostring(master.userId)][vec3Hash] = nil
                    end
                end
            end, time * 1000, 1, tostring(master.userId))
        end
    end
end

function GameManor:initCropsTime()
    local player = PlayerManager:getPlayerByUserId(self.userId)
    if player == nil then
        return
    end

    if not DbUtil.CanSavePlayerData(player, DbUtil.TAG_MANOR) then
        return
    end

    for hash, value in pairs(self.cropsInfo) do
        local dataString = StringUtil.split(hash, ":")
        local data = StringUtil.split(value, ":")
        if dataString then
            local x = tonumber(dataString[1])
            local y = tonumber(dataString[2])
            local z = tonumber(dataString[3])
            local vec3 = VectorUtil.newVector3i(x, y, z)
            vec3 = self:rPosToAPos(vec3)
            if data then
                local blockId = tonumber(data[1])
                local state = tonumber(data[2])
                local lastUpdateTime = tonumber(data[3])
                EngineWorld:getWorld():setCropsBlock(self.userId, vec3, blockId, state, 0, 0, lastUpdateTime, 1)
            end
        end
    end
end

function GameManor:insertTreeInfo(vec3, meta)
    if EngineWorld:getBlockId(vec3) == BlockID.CHEST then
        return
    end
    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z
    if self.treeInfo[hash] == nil then
        self.treeInfo[hash] = meta
    end
end

function GameManor:removeTreeInfo(vec3)
    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z
    if self.treeInfo[hash] ~= nil then
        self.treeInfo[hash] = nil
    end
end

function GameManor:insertDirtInfo(vec3, blockId)
    if EngineWorld:getBlockId(vec3) == BlockID.CHEST then
        return
    end
    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z
    if self.dirtInfo[hash] == nil then
        self.dirtInfo[hash] = blockId
    end
end

function GameManor:removeDirtInfo(vec3)
    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z
    if self.dirtInfo[hash] ~= nil then
        self.dirtInfo[hash] = nil
    end
end

function GameManor:insertCropsInfo(vec3, blockId, blockMeta, lastUpdateTime)
    if EngineWorld:getBlockId(vec3) == BlockID.CHEST then
        return
    end
    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z
    local value = self.cropsInfo[hash]
    if value then
        if not lastUpdateTime then
            lastUpdateTime = StringUtil.split(value, ":", nil, true)[3]
        end
        value = blockId .. ":" .. blockMeta .. ":" .. lastUpdateTime
        self.cropsInfo[hash] = value
    else
        value = blockId .. ":" .. blockMeta .. ":" .. os.time()
        self.cropsInfo[hash] = value
    end
end

function GameManor:removeCropsInfo(vec3)
    local rPos = self:aPosToRPos(vec3)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z
    if self.cropsInfo[hash] ~= nil then
        self.cropsInfo[hash] = nil
        LuaTimer:scheduleTicker(function()
            HostApi.deleteBlockCrops(vec3)
        end, 1, 1)
    end
end

function GameManor:clearCrops()
    for hash, crop in pairs(self.cropsInfo) do
        local x, y, z = GameConfig:decodeHash(hash)
        local aPos = self:rPosToAPos(VectorUtil.newVector3i(x, y, z))
        HostApi.deleteBlockCrops(aPos)
    end
end

function GameManor:clearCache()

end

function GameManor:checkPower(userId, pos, extra)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return false
    end

    if player:checkReady() == false then
        return false
    end

    local master = PlayerManager:getPlayerByUserId(self.userId)
    if master == nil then
        return false
    end

    if master:checkReady() == false then
        return false
    end

    if not player:checkAreaNormal() then
        return false
    end

    if player:canPlaceBlock(pos or self.originPos) then
        return true
    end
    -- MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
    return false
end
-- manorinfo end

function GameManor:canPlaceChest(blockPos)
    local rPos = self:aPosToRPos(blockPos)
    local hash = rPos.x .. ":" .. rPos.y .. ":" .. rPos.z
    if self.treeInfo[hash] or self.dirtInfo[hash] or self.cropsInfo[hash]
    then
        return false
    end
    return true
end