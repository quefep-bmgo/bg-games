local time1 = os.clock()
local function md5sum(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*a")
        file:close()
        local misc = require("misc")
        return misc.md5(content) .. tostring(randomseed)
    else
        return ""
    end
end
local packet = {
    globals = { "isTest" },
    engines = {
        "/lua/engine_base/connector/interceptor/IConnectorInterceptor.lua",
        "/lua/engine_base/connector/service/IConnectorService.lua",
        "/lua/engine_base/connector/ConnectorInterceptor.lua",
        "/lua/engine_base/connector/IConnectorCenter.lua",
        "/lua/engine_base/connector/IConnectorDispatch.lua",
        "/lua/engine_base/connector/IConnectorMsgHandler.lua",
        "/lua/engine_base/connector/IConnectorMsgInterceptor.lua",
        "/lua/engine_client/connector/service/PreventCheatService.lua",
        "/lua/engine_client/connector/ConnectorCenter.lua",
        "/lua/engine_client/connector/ConnectorDispatch.lua",
        "/lua/engine_client/event/CommonDataEvents.lua",
        "/lua/engine_client/packet/PacketSender.lua",
        "/lua/engine_client/packet/PidPacketHandler.lua",
        "/lua/engine_client/packet/PidPacketSender.lua",
    },
    games = {},
}
local globals = {}
local engines = {}
local games = {}
for _, key in pairs(packet.globals) do
    globals[key] = _G[key]
end
local engineRoot = FileUtil:getRootPath() .. "Media/Scripts/Engine"
for _, engine in pairs(packet.engines) do
    local path = engineRoot .. engine
    local content = md5sum(path)
    engines[engine] = content
end
for _, game in pairs(packet.games) do
    local path = FileUtil:getMapPath() .. game
    local file = io.open(path, "r")
    if not file then
        path = FileUtil:getScriptPath() .. game
    else
        file:close()
    end
    local content = md5sum(path)
    games[game] = content
end
local sandboxol = {}
local path = FileUtil:getRootPath() .. "Media/sandboxol"
sandboxol.engine = md5sum(path)
path = FileUtil:getMapPath() .. "/sandboxol"
local file = io.open(path, "r")
if not file then
    path = FileUtil:getScriptPath() .. "/sandboxol"
else
    file:close()
end
sandboxol.game = md5sum(path)
local function dir_exist(dir)
    local lfs = require "lfs"
    local attr = lfs.attributes(dir)
    if not attr then
        return false
    end
    if Platform.isWindow() then
        return attr.mode == "directory"
    else
        return attr.size and attr.size > 0
    end
end
local function file_exist(pth)
    if Platform.isMacIOS() then
        return false
    end
    local f = io.open(pth)
    if f then
        f:close()
        return true
    else
        return false
    end
end
local paths = StringUtil.split(FileUtil:getMapPath(), "/")
local last = paths[#paths]
while last and last ~= "map" do
    table.remove(paths)
    last = paths[#paths]
end
table.insert(paths, "Media")
local hacker = dir_exist(table.concat(paths, "/"))
hacker = hacker or file_exist(FileUtil:getRootPath() .. "GMHelper.lua")
local data = serialize.encode({
    globals = globals,
    engines = engines,
    games = games,
    sandboxol = sandboxol,
    hacker = hacker,
})
local time2 = os.clock()
PlayerManager:getClientPlayer():sendPacket({
    pid = "SyncClientVerify",
    data = data,
    time = (time2 - time1) * 1000,
})