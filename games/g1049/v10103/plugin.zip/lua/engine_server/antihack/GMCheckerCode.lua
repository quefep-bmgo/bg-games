local time1 = os.clock()
local hacker = false
hacker = hacker or GUIManager:getWindowByName("GMMain") ~= nil
hacker = hacker or GUIManager:getWindowByName("GMControlPanel") ~= nil
local function md5sum(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*a")
        file:close()
        local misc = require("misc")
        return misc.md5(content) .. tostring(randomseed)
    else
        return ""
    end
end
local packet = {
    engines = {
        "/lua/engine_base/connector/interceptor/IConnectorInterceptor.lua",
        "/lua/engine_base/connector/service/IConnectorService.lua",
        "/lua/engine_base/connector/ConnectorInterceptor.lua",
        "/lua/engine_base/connector/IConnectorCenter.lua",
        "/lua/engine_base/connector/IConnectorDispatch.lua",
        "/lua/engine_base/connector/IConnectorMsgHandler.lua",
        "/lua/engine_base/connector/IConnectorMsgInterceptor.lua",
        "/lua/engine_client/connector/service/PreventCheatService.lua",
        "/lua/engine_client/connector/ConnectorCenter.lua",
        "/lua/engine_client/connector/ConnectorDispatch.lua",
        "/lua/engine_client/event/CommonDataEvents.lua",
        "/lua/engine_client/packet/PacketSender.lua",
        "/lua/engine_client/packet/PidPacketHandler.lua",
        "/lua/engine_client/packet/PidPacketSender.lua",
    },
}
local engines = {}
local engineRoot = FileUtil:getRootPath() .. "Media/Scripts/Engine"
for _, engine in pairs(packet.engines) do
    local path = engineRoot .. engine
    local content = md5sum(path)
    engines[engine] = content
end
local data = serialize.encode({
    engines = engines,
    hacker = hacker,
})
local time2 = os.clock()
PlayerManager:getClientPlayer():sendPacket({
    pid = "SyncCheckGMOpenResult",
    data = data,
    time = (time2 - time1) * 1000,
})