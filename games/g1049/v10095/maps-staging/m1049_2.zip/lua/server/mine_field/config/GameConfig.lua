---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:16
---
require "mine_field.config.Define"
require "mine_field.config.AppShopConfig"
require "mine_field.config.IslandLevelConfig"
require "mine_field.config.IslandAreaConfig"
require "mine_field.config.Area"
require "mine_field.config.AppShopConfig"
require "mine_field.config.PrivilegeConfig"
require "mine_field.config.NotificationConfig"

GameConfig = {}

function GameConfig:init(config)

    self.initHP = tonumber(config.initHP or 20)
    self.hungerValue = tonumber(config.hungerSubHP[1] or 1)
    self.hungerInterval = tonumber(config.hungerSubHP[2] or 2)
    self.maxFoodAddHp = config.maxFoodAddHp
    self.deathLineY = tonumber(config.deathLineY or 2)
    self.moonName = tostring(config.moonName) or "moon_phases.png"
    self.sunName = tostring(config.sunName) or "sun.png"
    self.miningAreaCD = tonumber(config.miningAreaCD or 5)
    self.maxMillNum = tonumber(config.maxMillNum or 1000)

    IslandAreaConfig:init(FileUtil.getConfigFromCsv("IslandAreaConfig.csv"))
    IslandLevelConfig:init(FileUtil.getConfigFromCsv("IslandLevelConfig.csv"))
    AppShopConfig:initConfig(FileUtil.getConfigFromCsv("setting/AppShopSetting.csv", 3))
    AppShopConfig:initSortConfig(FileUtil.getConfigFromCsv("setting/AppShopSortSetting.csv", 3))
    PrivilegeConfig:initPrivilege(FileUtil.getConfigFromCsv("PrivilegeConfig.csv"))
    PrivilegeConfig:initItem(FileUtil.getConfigFromCsv("PrivilegeItemConfig.csv"))
    NotificationConfig:initConfig(FileUtil.getConfigFromCsv("Notification.csv"))
end

return GameConfig