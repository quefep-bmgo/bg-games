---@type HomeMgr
local HomeMgr = T(Global, "HomeMgr")
---@type HomeConfig
local HomeConfig = T(Global, "HomeConfig")
---@type GameUtil
local GameUtil = T(Global, "GameUtil")

require "mine_field.messages.Messages"
require "mine_field.data.GamePlayer"
require "mine_field.Match"

PlayerListener = {}

function PlayerListener:init()

    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerBackHallEvent:registerCallBack(self.onPlayerBackSkyBlock)
    CEvents.PlayerCurrencyChangeEvent:registerCallBack(self.onPlayerCurrencyChange)
    CEvents.PlayerPlaceBlockBoxJudgeEvent:registerCallBack(self.onPlayerPlaceBlockBoxJudgeEvent)
    CEvents.PlayerUseInitSpawnPositionEvent:registerCallBack(self.onPlayerUseInitSpawnPosition)

    PlayerSkyBlocShopOperateEvent:registerCallBack(self.onPlayerSkyBlocBuyGoods)
    PlayerClickResourceIslandEvent:registerCallBack(self.onPlayerLeaveForMiningArea)
    Events.ReceiveSumRechargeEvent:registerCallBack(self.onReceiveSumRecharge)
    Events.ReceiveSumRechargeEndEvent:registerCallBack(self.onReceiveSumRechargeEnd)
end

function PlayerListener.onPlayerLogin(clientPeer)
    local player = GamePlayer.new(clientPeer)
    player:init()
    HomeMgr:enterHome(player.userId)
    player:teleHomeWithYaw()
    return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerLogout(player)
    GameMatch:onPlayerQuit(player)
end

function PlayerListener.onPlayerReady(player)
    player:addNightVisionPotionEffect(99999)
    DbUtil:getPlayerData(player.userId, DbUtil.TAG_SHAREDATA)
    HostApi.sendPlaySound(player.rakssid, 10043)
    NotificationConfig:onPlayerReady(player)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))
    return 4320000
end

function PlayerListener.onPlayerPlaceBlockBoxJudgeEvent(blockId)
    return false
end

function PlayerListener.onPlayerBackSkyBlock(rakssid)
    HostApi.log("onPlayer leave for SkyBlock")
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return
    end
    MsgSender.sendTopTipsToTarget(player.rakssid, 1000, Messages:msgTransmitting())
    GameUtil:resetGame(player.userId, "g1048")
end

function PlayerListener.onPlayerLeaveForMiningArea(userId, data)
    HostApi.log("onPlayer leave for SkyBlockMiningArea")

    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil or player.backMiningAreaTime == nil then
        return
    end

    if not DbUtil:CanSavePlayerData(player, DbUtil.TAG_SHAREDATA) then
        return
    end
    MsgSender.sendTopTipsToTarget(player.rakssid, 1000, Messages:msgTransmitting())
    -- local interval = os.time() - player.backMiningAreaTime
    -- if  interval < GameConfig.miningAreaCD then
    --     MsgSender.sendTopTipsToTarget(player.rakssid, 1, Messages:msgUIButtonCountDown(GameConfig.miningAreaCD - interval))
    --     HostApi.log("GameConfig.miningAreaCD - interval :"..GameConfig.miningAreaCD - interval)
    --     return
    -- end
    player.backMiningAreaTime = os.time()
    GameUtil:resetGame(player.userId, "g1049")
end

function PlayerListener.onPlayerSkyBlocBuyGoods(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    if player.isLife == false then
        print("onPlayerSkyBlocBuyGoods player is die userid == " .. tostring(userId))
        return
    end

    local builder = DataBuilder.new():fromData(data)
    local num = builder:getNumberParam("num")
    local indexId = builder:getNumberParam("indexId")
    local type = builder:getNumberParam("type")

    if not DbUtil:CanSavePlayerData(player, DbUtil.TAG_SHAREDATA) then
        return
    end

    if type == AppShopConfig.OperateType.BUY_GOOD then
        HostApi.log("SkyBlocBuyGoodsEvent goodId == " .. indexId .. " num == " .. num)
        if num >= 1 and num <= 64 then
            AppShopConfig:BuyGoods(player.rakssid, indexId, num)
        end
    elseif type == AppShopConfig.OperateType.UPDATE_DATA then
        player:sendSkyBlockShopInfo()
    end
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return false
    end
    if y <= GameConfig.deathLineY then
        player:teleHomeWithYaw()
        local maxHp = player:getMaxHealth()
        player:setHealth(maxHp)
        player:setFoodLevel(20)
        return false
    end
    return true
end

function PlayerListener.onPlayerUseInitSpawnPosition(userId, position)
    local attr = GameServer:getRoomManager():getUserAttrInfo(userId)
    if not attr then
        return true
    end
    local cfg = HomeConfig:getCfgByLocationId(attr.manorId)
    if cfg then
        position.x = cfg.initPos.x
        position.y = cfg.initPos.y
        position.z = cfg.initPos.z
        return false
    end
    return true
end

function PlayerListener.onPlayerCurrencyChange(rakssid, currency)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        player:onMoneyChange()
    end
end

function PlayerListener.onReceiveSumRecharge(player, type, id, count, meta)
    print("onReceiveSumRecharge userId == " .. tostring(player.userId))
    RechargeUtil:doSumRechargeRewards(player, type, id, count, meta)
end

function PlayerListener.onReceiveSumRechargeEnd(player, id)
    print("onReceiveSumRechargeEnd userId == " .. tostring(player.userId))
end

return PlayerListener
--endregion
