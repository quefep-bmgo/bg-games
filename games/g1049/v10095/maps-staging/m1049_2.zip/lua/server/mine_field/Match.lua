--Match.lua
require "mine_field.util.DbUtil"
require "mine_field.util.RechargeUtil"

GameMatch = {}

GameMatch.gameType = "g1050"
GameMatch.curTick = 0

function GameMatch:initMatch()
    GameTimeTask:start()
end

function GameMatch:onTick(ticks)
    self.curTick = ticks
    self:addPlayerScore()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        player:onTick()
    end
end

function GameMatch:onPlayerQuit(player)
    player:reward()
    player.off_lineTime = os.time()
    GameAnalytics:design(player.userId, 0, { "g1050StayTime", player.stay_time })
    DBManager:removeCache(player.userId)
end

function GameMatch:getPlayerByPos(vec3)
    local players = PlayerManager:getPlayers()
    for i, player in pairs(players) do
        if player:isIn(vec3) then
            return player
        end
    end
    return nil
end

function GameMatch:addPlayerScore()
    if self.curTick == 0 or self.curTick % 60 ~= 0 then
        return
    end
    local players = PlayerManager:getPlayers()
    for i, v in pairs(players) do
        v:addScore(10)
    end
end

return GameMatch