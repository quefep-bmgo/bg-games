---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:11
---

Messages = {}

function Messages:gamename()
    return TextFormat:getTipType(1050001)
end

function Messages:msgTransmitting()
    return 1050005
end

return Messages