---
--- Created by longxiang.
--- DateTime: 2018/11/9  16:15

DBDataListener = {}

function DBDataListener:init()
    Events.GetDataFromDBEvent:registerCallBack(self.onGetDataFromDB)
    DBManager:setPlayerDBSaveFunction(function(player, immediate)
        DbUtil:savePlayerData(player, immediate)
    end)
end

function DBDataListener.onGetDataFromDB(userId, subKey, data)
    DbUtil:initDataFromDB(userId, subKey, data)
end

return DBDataListener

--endregion
