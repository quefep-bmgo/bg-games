--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

require "mine_field.Match"
require "mine_field.messages.Messages"

BlockListener = {}

function BlockListener:init()
    CEvents.BlockBreakEvent:registerCallBack(self.onBlockBreak)
    CEvents.BlockBreakWithMetaEvent:registerCallBack(self.onBlockBreakWithMeta)
    CEvents.PlayerPlaceBlockEvent:registerCallBack(self.onBlockPlace)
    CEvents.BlockBreakWithGunEvent:registerCallBack(self.onBlockBreakWithGun)
    CEvents.BlockTNTExplodeEvent:registerCallBack(self.onBlockTNTExplode)
end

function BlockListener.onBlockBreak(rakssid, blockId, vec3)
    return false
end

function BlockListener.onBlockBreakWithMeta(rakssid, blockId, blockMeta, vec3, itemID)
    return false
end

function BlockListener.onBlockPlace(rakssid, itemId, meta, toPlacePos)
    return false
end

function BlockListener.onBlockBreakWithGun(rakssid, blockId, blockPos, gunId)
    return false
end

function BlockListener.onBlockTNTExplode(entityId, pos, attr)
    attr.isBreakBlock = false
    return false
end

return BlockListener
--endregion
