---
--- Created by Jimmy.
--- DateTime: 2018/6/8 0008 11:51
---
CustomListener = {}

function CustomListener:init()
    CEvents.ConsumeTipMsgEvent:registerCallBack(self.onConsumeTipMsg)
end

function CustomListener.onConsumeTipMsg(rakssid, extra, isRight)
    if isRight == false then
        return
    end
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return
    end
    local info = StringUtil.split(extra, "#")
    if #info == 2 then
        local extra1 = tostring(info[1])
        local extra2 = tonumber(info[2])

        if extra1 == "BuyExArea" then
            player:getExtendArea()
        end
    end
end

return CustomListener
--endregion