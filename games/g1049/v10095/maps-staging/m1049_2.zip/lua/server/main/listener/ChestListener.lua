require "main.Match"
ChestListener = {}

function ChestListener:init()
    CEvents.ChestOpenSpHandleEvent:registerCallBack(self.onChestOpenSpHandle)
    CEvents.FurnaceOpenSpHandleEvent:registerCallBack(self.onFurnaceOpenSpHandle)
end

function ChestListener.onChestOpenSpHandle(vec3, entityId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if player == nil then
        return false
    end

    if not GameMatch:isMaster(player.userId) then
        HostApi.sendCommonTip(player.rakssid, "plase_not_steal")
        return false
    end

    local selfManor = GameMatch:getUserManorInfo(player.userId)
    if selfManor == nil then
        return false
    end

    if not selfManor:isIn(vec3) then
        HostApi.log("onChestOpenSpHandle Weak net back home bug. userId: " .. tostring(player.userId) .. " " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
        return false
    end
    player.chestController:tryOpenContainer(vec3)
    HostApi.log("onChestOpenSpHandle userId: " .. tostring(player.userId) .. " " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
    return false
end

function ChestListener.onFurnaceOpenSpHandle(vec3, entityId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if player == nil then
        return false
    end

    local master = PlayerManager:getPlayerByUserId(player.target_user_id)
    if master == nil then
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
        return false
    end

    local masterManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if masterManorInfo == nil then
        return false
    end

    if not master.furnaceController:isCanOperate(player.userId) then
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
        return false
    end

    if not masterManorInfo:isIn(vec3) then
        HostApi.log("onFurnaceOpenSpHandle Weak net back home bug. userId: " .. tostring(player.userId) .. " targetId: " .. tostring(player.target_user_id)
                .. " " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
        return false
    end

    HostApi.log("onFurnaceOpenSpHandle userId: " .. tostring(player.userId) .. " targetId: " .. tostring(player.target_user_id)
            .. " " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
    player:logPlayerBuildGroup("onFurnaceOpenSpHandle")
    master.furnaceController:tryOpenContainer(vec3, player)
    return false
end

return ChestListener