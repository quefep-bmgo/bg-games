--Match.lua
require "mine_hole.util.DbUtil"

GameMatch = {}

GameMatch.gameType = "g1049"
GameMatch.curTick = 0

function GameMatch:initMatch()

end

function GameMatch:onTick(ticks)
    self.curTick = ticks
    self:addPlayerScore()
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        player:onTick()
    end
end

function GameMatch:onPlayerQuit(player)
    player:reward()
end

function GameMatch:addPlayerScore()
    if self.curTick == 0 or self.curTick % 60 ~= 0 then
        return
    end
    local players = PlayerManager:getPlayers()
    for i, v in pairs(players) do
        v:addScore(10)
    end
end

return GameMatch