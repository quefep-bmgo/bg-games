--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

require "mine_hole.Match"

BlockListener = {}

function BlockListener:init()
    CEvents.BlockSwitchEvent:registerCallBack(self.onBlockSwitch)
    CEvents.BlockSwitchPlusEvent:registerCallBack(self.onBlockSwitchPlus)
end

function BlockListener.onBlockSwitch(entityId, downOrUp, blockId, vec3i)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if player == nil or player.entityPlayerMP == nil then
        return true
    end

    if downOrUp and blockId == BlockID.PRESSURE_PLATE_STONE then

        if FlipFrontConfig.font then
            for i = 1, #FlipFrontConfig.font do
                local pos = VectorUtil.newVector3(tonumber(FlipFrontConfig.font[i].pos.x), tonumber(FlipFrontConfig.font[i].pos.y), tonumber(FlipFrontConfig.font[i].pos.z))
                if pos.x == vec3i.x and pos.y == vec3i.y and pos.z == vec3i.z then
                    player.entityPlayerMP:specialJump(0.5, 1, 1)
                    return false
                end
            end
        end
        if FlipBackConfig.back then
            for i = 1, #FlipBackConfig.back do
                local pos = VectorUtil.newVector3(tonumber(FlipBackConfig.back[i].pos.x), tonumber(FlipBackConfig.back[i].pos.y), tonumber(FlipBackConfig.back[i].pos.z))
                if pos.x == vec3i.x and pos.y == vec3i.y and pos.z == vec3i.z then
                    player.entityPlayerMP:specialJump(0.5, -1.7, -1.7)
                    return false
                end
            end
        end
    end

    return true
end

function BlockListener.onBlockSwitchPlus(vec3i)
    return false
end

return BlockListener
--endregion
