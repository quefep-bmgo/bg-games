---
--- Created by Yang.
--- DateTime: 2018/7/5 15:30
---
LogicListener = {}

function LogicListener:init()
    CEvents.EntityItemSpawnEvent:registerCallBack(self.onEntityItemSpawn)
    CEvents.UseCustomItemEvent:registerCallBack(self.onUseCustomItem)

end

function LogicListener.onEntityItemSpawn(itemId, itemMeta, behavior, discard)
    if behavior == "break.block" then
        return false
    end
    return true
end

function LogicListener.onUseCustomItem(userId, itemID)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return false
    end
    return false
end

return LogicListener