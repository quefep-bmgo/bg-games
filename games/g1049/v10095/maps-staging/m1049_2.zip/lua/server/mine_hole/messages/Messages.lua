---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:11
---

Messages = {}

function Messages:gamename()
    return TextFormat:getTipType(1049001)
end

function Messages:msgResetMapCountDown(seconds)
    return 1049003, seconds
end

return Messages