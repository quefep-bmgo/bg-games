ChestListener = {}

function ChestListener:init()
    CEvents.ChestOpenSpHandleEvent:registerCallBack(self.onChestOpenSpHandle)
end

function ChestListener.onChestOpenSpHandle(vec3, entityId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if player == nil then
        return false
    end
    HostApi.log("onChestOpen " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
    return true
end

return ChestListener