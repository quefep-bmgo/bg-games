---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
require "mine_hole.Match"
---@type SSkyBlockPlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type ProductDataInit
local ProductDataInit = T(Global, "ProductDataInit")
---@type ExpConfig
local ExpConfig = T(Global, "ExpConfig")
---@type CommonConfig
local CommonConfig = T(Global, "CommonConfig")
---@type SSkyBlockPlayer
GamePlayer = class("GamePlayer", SSkyBlockPlayer)

function GamePlayer:init()
    SSkyBlockPlayer.init(self)
    self.isLife = true
    self.products = {}
    self.privilege = {}
    self.cur_pri_item = {}
    self.inHandItemId = 0
    self.diedPos = VectorUtil.ZERO
    self:initStaticAttr(0)
    self.has_ad = false
    self.canSendCostDiamond = true
    self.needRecivePri = false
end

function GamePlayer:initShareDataFromDB(data)
    if not data.__first then
        self.hp = data.hp or Define.InitHP
        self.money = data.money or 0
        self.exp = data.exp or 0
        self.level = data.level or 1
        self.area = data.area or "20*20*20"
        self.products = data.products or {}
        self.privilege = data.privilege or {}
        self.isSky = data.isSky or false
    else
        HostApi.log("initShareDataFromDB the data.__first is true ")
    end
    if not data.__first then
        self:setHealth(self.hp)
        self:setFoodLevel(data.foodLevel or 20)
    end
    self:teleInitPos()
    PrivilegeConfig:setplayerPrivilege(self)
    self:syncListInfo()
    self:setCurrency(self.money)
    PrivilegeConfig:checkUnlockThreeNpc(self)
    self:sendSkyBlockShopInfo()
    ProductDataInit:initProductData(self)
    self:checkShowPriSign()
end

function GamePlayer:onMoneyChange()
    self.money = self:getCurrency()
    if self.money then
        HostApi.log("onMoneyChange " .. tostring(self.userId) .. " money: " .. self.money)
    end
end

function GamePlayer:onTick()

end

function GamePlayer:teleInitPos()
    CommonConfig:teleportInitPos(self)
end

function GamePlayer:getListInfo()
    local lv = self.level or 1
    local cur_exp = self.exp or 0
    local max_exp, is_max = ExpConfig:getMaxExp(self.level)
    local area = self.area or "20*20*20"
    local sortType = AppShopConfig:getSortTypeByScore(self.level)
    return lv, cur_exp, max_exp, area, is_max, sortType
end

function GamePlayer:syncListInfo()
    local lv, cur_exp, max_exp, area, is_max, sortType = self:getListInfo()
    self:sendPacket({
        pid = "syncListInfo",
        data = {
            lv = lv,
            exp = cur_exp,
            maxExp = max_exp,
            area = area,
            userId = self.userId
        }
    })
    self:sendSkyBlockShopInfo()
end

function GamePlayer:sendSkyBlockShopInfo()
    local data = {}
    data.priData = self:getpriData()
    data.npcData = self:getnpcData()
    data.priItemData = self:getPriItemData()

    local sortType = AppShopConfig:getSortTypeByScore(self.level)
    PrivilegeConfig:checkSpePri(self)
    HostApi.sendSkyBlockShopInfo(self.rakssid, sortType, self.level, json.encode(data))
end

function GamePlayer:getPriItemData()
    local priItemData = {}
    for k, v in pairs(self.cur_pri_item) do
        local data = {}
        data.id = v.Id
        data.priType = v.PriType
        data.detail = v.Detail
        data.have = v.Forever
        if v.Time >= os.time() then
            data.have = true
        end

        table.insert(priItemData, data)
    end
    return priItemData
end

function GamePlayer:getpriData()
    local priData = {}
    for k, v in pairs(self.privilege) do
        local data = {}
        data = {
            id = v.id,
            itemId = v.itemId,
            forever = v.forever,
            time = v.time,
        }
        table.insert(priData, data)
    end

    for k, v in pairs(priData) do
        v.time = v.time - os.time()
        if v.time < 0 then
            v.time = 0
        end
    end
    return priData
end

function GamePlayer:getnpcData()
    local npcdata = {}
    for k, v in pairs(self.products) do
        local data = {}
        data = {
            id = v.ShopId,
            itemId = v.Id,
            forever = v.Time == -1 and true or false,
            time = v.EndTime
        }
        table.insert(npcdata, data)
    end

    for k, v in pairs(npcdata) do
        v.time = v.time - os.time()
        if v.time < 0 then
            v.time = 0
        end
    end
    return npcdata
end

function GamePlayer:insertProductsInfo(id, shopId, num)
    if self.productData then
        self.productData:unlockProduct(id, shopId)
    end
end

function GamePlayer:checkIsHAvePri(priId)
    for k, pri in pairs(self.cur_pri_item) do
        if priId == pri.PriType then
            if pri.Forever then
                return true
            elseif pri.Time >= os.time() then
                return true
            end
        end
    end

    return false
end

function GamePlayer:checkIsCanBuyPri(priId)
    for k, pri in pairs(self.privilege) do
        if pri.itemId == priId then
            if pri.forever then
                return false
            end
        end
    end
    return true
end

function GamePlayer:addScore(score)
    self.score = self.score + score
end

function GamePlayer:reward()
    RewardManager:getUserGoldReward(self.userId, self.score, function(data)

    end)
end

function GamePlayer:CanSavePlayerShareData()
    return DbUtil:CanSavePlayerData(self, DbUtil.TAG_SHAREDATA)
end

function GamePlayer:checkShowPriSign()
    if not PrivilegeConfig:checkPlayerShowPri(self) then
        return
    end
    self:changeClothes("custom_crown", 10)
end

function GamePlayer:checkIsCanUnlockByOther(priId)
    for k, pri in pairs(self.privilege) do
        if pri.itemId == priId then
            return false
        end
    end
    return true
end

return GamePlayer

--endregion


