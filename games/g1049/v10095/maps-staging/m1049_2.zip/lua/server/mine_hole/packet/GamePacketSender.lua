GamePacketSender = {}

function GamePacketSender:sendCanReciveNewPri(rakssid, isShow)
    local params = {
        isShowIcon = isShow
    }
    local data = DataBuilder.new():fromTable(params):getData()
    PacketSender:sendServerCommonData(rakssid, "MainControlData", "ReviveNewPri", data)
end

function GamePacketSender:sendSkyBlockPriImg(rakssid, info)
    local data = {
        priList = info
    }
    PacketSender:sendServerCommonData(rakssid, "SkyBlockMainData", "SupemePrivilegeImg", json.encode(data))
end

function GamePacketSender:sendShowGuideArrowBtn(rakssid, data)
    PacketSender:sendLuaCommonData(rakssid, "showGuideArrowBtn", data)
end

function GamePacketSender:sendShowLackMoney(rakssid)
    local data = {}
    PacketSender:sendLuaCommonData(rakssid, "ShowLackMoney", json.encode(data))
end

function GamePacketSender:sendShowLackDiamond(rakssid)
    PacketSender:sendServerCommonData(rakssid, "SkyBlockMainData", "ShowLackDiamondPanel", json.encode(data))
end

function GamePacketSender:sendShowSwitchRed(rakssid, data)
    PacketSender:sendLuaCommonData(rakssid, "SwitchShowRedPoint", json.encode(data))
end

function GamePacketSender:sendShowRichRed(rakssid, data)
    PacketSender:sendLuaCommonData(rakssid, "RichShowRedPoint", json.encode(data))
end

return GamePacketSender