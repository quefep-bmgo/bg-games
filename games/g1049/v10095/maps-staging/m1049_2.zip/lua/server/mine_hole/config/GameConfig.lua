---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:16
---
require "common.config.AppShopConfig"
require "common.config.PrivilegeConfig"
require "mine_hole.config.BlockSettingConfig"
require "mine_hole.config.Define"
require "mine_hole.config.FlipFrontConfig"
require "mine_hole.config.FlipBackConfig"

GameConfig = {}

function GameConfig:init(config)
    BlockSettingConfig:initConfig(FileUtil.getConfigFromCsv("setting/BlockSetting.csv", 3))
    AppShopConfig:initConfig(FileUtil.getConfigFromCsv("setting/AppShopSetting.csv", 3))
    AppShopConfig:initSortConfig(FileUtil.getConfigFromCsv("setting/AppShopSortSetting.csv", 3))
    PrivilegeConfig:initPrivilege(FileUtil.getConfigFromCsv("PrivilegeConfig.csv"))
    PrivilegeConfig:initItem(FileUtil.getConfigFromCsv("PrivilegeItemConfig.csv"))
    FlipFrontConfig:initConfig(config.flipFront)
    FlipBackConfig:initConfig(config.flipBack)
end

return GameConfig