require "mine_hole.messages.Messages"
require "mine_hole.data.GamePlayer"
require "mine_hole.Match"

PlayerListener = {}

function PlayerListener:init()

    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)

    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerCurrencyChangeEvent:registerCallBack(self.onPlayerCurrencyChange)
    CEvents.PlayerChangeItemInHandEvent:registerCallBack(self.onChangeItemInHandEvent)

    PlayerSkyBlocShopOperateEvent:registerCallBack(self.onPlayerSkyBlocBuyGoods)
end

function PlayerListener.onPlayerLogin(clientPeer)
    local player = GamePlayer.new(clientPeer)
    player:init()
    return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerLogout(player)
    GameMatch:onPlayerQuit(player)
end

function PlayerListener.onPlayerReady(player)
    DbUtil:getPlayerData(player.userId)
    HostApi.sendPlaySound(player.rakssid, 10042)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))
    return 4320000
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return false
    end
    return true
end

function PlayerListener.onPlayerSkyBlocBuyGoods(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    if player.isLife == false then
        print("onPlayerSkyBlocBuyGoods player is die userid == " .. tostring(userId))
        return
    end

    local builder = DataBuilder.new():fromData(data)
    local num = builder:getNumberParam("num")
    local indexId = builder:getNumberParam("indexId")
    local type = builder:getNumberParam("type")

    if not DbUtil:CanSavePlayerData(player, DbUtil.TAG_SHAREDATA) then
        return
    end

    if type == AppShopConfig.OperateType.BUY_GOOD then
        HostApi.log("SkyBlocBuyGoodsEvent goodId == " .. indexId .. " num == " .. num)
        if num >= 1 and num <= 64 then
            AppShopConfig:BuyGoods(player.rakssid, indexId, num)
        end
    elseif type == AppShopConfig.OperateType.UPDATE_DATA then
        player:sendSkyBlockShopInfo()
    end
end

function PlayerListener.onChangeItemInHandEvent(rakssid, itemId, itemMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        player.inHandItemId = itemId
    end
end

function PlayerListener.onPlayerCurrencyChange(rakssid, currency)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        player:onMoneyChange()
    end
end

return PlayerListener
--endregion
