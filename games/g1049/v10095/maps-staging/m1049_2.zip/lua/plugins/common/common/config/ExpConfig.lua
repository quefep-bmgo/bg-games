---@class ExpConfig
local ExpConfig = T(Global, "ExpConfig")
---@type ExpConfigItem[]
local Settings = {}
---@type ExpConfigItem[]
local LvUpRewardSettings = {}

function ExpConfig:initConfig()
    local config = FileUtil.getGameConfigFromCsv("common/ExpConfig.csv")
    for _, exp in pairs(config or {}) do
        ---@class ExpConfigItem
        local data = {}
        data.level = tonumber(exp.level) or 0
        data.minExp = tonumber(exp.minExp)
        data.maxExp = tonumber(exp.maxExp)
        if exp.rewardIds ~= "#" then
            ---@type ExpConfigRewardItem[]
            local rewards = {}
            local rewardIds = StringUtil.split(exp.rewardIds, "#", nil, true)
            local rewardNum = StringUtil.split(exp.rewardNum, "#", nil, true)
            for i, rewardId in pairs(rewardIds) do
                ---@class ExpConfigRewardItem
                local rewardItem = {
                    rewardId = rewardId,
                    count = rewardNum[i] or 1
                }
                table.insert(rewards, rewardItem)
            end
            data.rewards = rewards
            table.insert(LvUpRewardSettings, data)
        end
        table.insert(Settings, data)
    end

    table.sort(Settings, function(a, b)
        return a.level < b.level
    end)
    table.sort(LvUpRewardSettings, function(a, b)
        return a.level < b.level
    end)
end

function ExpConfig:getPlayerInitLv(level)
    local max_lv = 1
    for _, exp in pairs(LvUpRewardSettings) do
        if max_lv < exp.level then
            max_lv = exp.level
        end
    end
    if level > max_lv then
        return max_lv
    end
    return math.max(level, 1)
end

---@param lv number
---@return ExpConfigItem
function ExpConfig:getLvSetting(lv)
    for _, exp in pairs(LvUpRewardSettings) do
        if tonumber(exp.exp_lv) == tonumber(lv) then
            return exp
        end
    end
end

function ExpConfig:getLvRewardSettings()
    local setting = {}
    for _, exp in pairs(LvUpRewardSettings) do
        if #exp.rewards > 0 then
            table.insert(setting, exp)
        end
    end
    return setting
end

function ExpConfig:getRewardMinLv()
    return LvUpRewardSettings[1].level or 1
end

function ExpConfig:getRewardMaxLv()
    return LvUpRewardSettings[#LvUpRewardSettings].level or 9999
end

function ExpConfig:getIndex(lv)
    local index = 1
    for _, exp in pairs(LvUpRewardSettings) do
        if #exp.rewards > 0 then
            if lv == exp.level or exp.level > lv then
                return index
            else
                index = index + 1
            end
        end
    end
    return 1
end

function ExpConfig:getLevelReward(lv)
    for _, exp in pairs(LvUpRewardSettings) do
        if lv == exp.level then
            return exp.rewards
        end
    end
    return {}
end

function ExpConfig:getLevelByExp(exp)
    for i, k in pairs(Settings) do
        if k.minExp <= exp and k.maxExp >= exp then
            return k.level
        end
    end
    if exp < Settings[1].minExp then
        return Settings[1].level
    end
    return Settings[#Settings].level
end

function ExpConfig:getMaxExp(exp_lv)
    for _, exp in pairs(Settings) do
        if tonumber(exp.level) == tonumber(exp_lv) then
            if tonumber(exp.level) == 9999 then
                return 99999999999, true
            else
                return tonumber(exp.maxExp), false
            end
        end
    end
    return 99999999999, true
end

function ExpConfig:hasLevelReward(lv)
    for _, exp in pairs(LvUpRewardSettings) do
        if lv == exp.level then
            return true
        end
    end
    return false
end

ExpConfig:initConfig()

return ExpConfig