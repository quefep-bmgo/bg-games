GMSetting:addTab("好友测试")
GMSetting:addItem("好友测试", "打开好友", "openFriendWin")
GMSetting:addItem("好友测试", "刷新好友信息", "updateUserInfo")

---@type FriendManager
local FriendManager = T(Global, "FriendManager")
function GMHelper:openFriendWin()
    UIHelper.showGameGUILayout("GUIFriends")
end

function GMHelper:updateUserInfo()
    FriendManager.UpdateUserInfo()
end