GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
end

function GameListener.onGameReady()
    GameConfig:init()
    require "ui.GUISkyBlockItemDetail"
    require "ui.GUISkyBlockMoneyDetail"
    require "ui.GUITipDialog"

    if GUISumRechargeLayout ~= nil then
        GUISumRechargeLayout:setRewardWidth(77)
    end
    ClientHelper.putStringPrefs("RechargeGameType", "g1048")
end

return GameListener
