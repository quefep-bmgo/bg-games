GamePacketSender = {}

function GamePacketSender:sendCancelGuideArrow()
    PacketSender:sendLuaCommonData("CancelGuideArrow", "{}")
end

return GamePacketSender