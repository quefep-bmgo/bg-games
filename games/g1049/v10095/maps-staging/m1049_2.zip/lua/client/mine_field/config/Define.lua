Define.ItemIcon = {
    Common = 0,
    Christmas = 1,
    Gift_reward = 2
}