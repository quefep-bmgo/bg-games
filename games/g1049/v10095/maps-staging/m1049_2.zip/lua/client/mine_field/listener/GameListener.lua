GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
end

function GameListener.onGameReady()
    for blockId = 1, 256 do
        local block = BlockManager.getBlockById(blockId)
        if block then
            block:setHardness(10000)
        end
    end
    GameConfig:init()
    require "ui.GUISkyBlockItemDetail"
    require "ui.GUISkyBlockMoneyDetail"
    require "ui.GUITipDialog"

    if GUISumRechargeLayout ~= nil then
        GUISumRechargeLayout:setRewardWidth(77)
    end
    ClientHelper.putStringPrefs("RechargeGameType", "g1048")
end

return GameListener