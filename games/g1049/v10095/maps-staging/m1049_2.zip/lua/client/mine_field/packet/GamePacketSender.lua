GamePacketSender = {}

return GamePacketSender