DataListener = {}
function DataListener:init()
    Listener.registerCallBack(CEvents.SkyBlockShowPriDetailEvent, self.onShowPriDetail)
end

function DataListener.onShowPriDetail(name, detail, icon)
    local data = GameConfig:getItemIconData()
    data.Name = name
    data.Detail = detail
    data.Icon = icon
    GUISkyBlockItemDetail:onSetData(data)
    GUISkyBlockItemDetail:show()
end

return DataListener