require "mine_field.config.Define"

GameConfig = {}

function GameConfig:init()

end

function GameConfig:getItemIconData()
    local data = {
        Id = 0,
        ItemId = 0,
        Meta = 0,
        Num = 1,
        Icon = "",
        Name = "",
        Detail = "",
        DataType = Define.ItemIcon.Common,
    }
    return data
end

return GameConfig
