DataListener = {}

function DataListener:init()
    Listener.registerCallBack(CEvents.SkyBlockOpenRankEvent, self.onOpenRankPanel)
    Listener.registerCallBack(CEvents.UpdateUserListEvent, self.onUpdateUserList)
    Listener.registerCallBack(CEvents.SkyBlockShowPriDetailEvent, self.onShowPriDetail)
end

function DataListener.onOpenRankPanel()
    GUIRank:show()
end

function DataListener.onUpdateUserList(type)
    -- type
    -- 1 addUser
    -- 2 removeUser
    -- 3 friend operator
    -- 4 user info change

    print("onUpdateUserList " .. type)
    local userIds = UserManager.Instance():getAllUser()
    MultiBuildData.NearPlayerData = {}
    for k, v in pairs(userIds) do
        local user = UserManager.Instance():findUser(v)
        if user then
            local data = {}
            data.isFriend = user.isFriend
            data.sex = user.sex
            data.userId = user.userId
            data.nickName = user.userName
            data.picUrl = user.picUrl
            table.insert(MultiBuildData.NearPlayerData, data)
        end
    end
    if GUIFriend and GUIFriend.nearPlayersBtn and GUIFriend.nearPlayersBtn:IsSelected() then
        GUIFriend:onUpdateUserNearFriend(MultiBuildData.NearPlayerData)
    end
end

function DataListener.onShowPriDetail(name, detail, icon)
    local data = GameConfig:getItemIconData()
    data.Name = name
    data.Detail = detail
    data.Icon = icon
    if GUISkyBlockItemDetail then
        GUISkyBlockItemDetail:onSetData(data)
        GUISkyBlockItemDetail:show()
    end
end

return DataListener