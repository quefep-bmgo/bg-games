require "main.config.PartyConfig"
require "main.config.BulletinConfig"
require "main.config.Define"
GameConfig = {}

function GameConfig:init()
    local config = FileUtil.getConfigFromYml("setting/luaconfig")
    self.giveLoveNumLevel = config.giveLoveNumLevel or 1
    self.lightConfig = config.lightConfig
    self.bloomBlurDeviation = tonumber(config.bloomBlurDeviation or 7)
    self.bloomBlurMultiplier = tonumber(config.bloomBlurMultiplier or 1)
    self.blockLightEnhancement = tonumber(config.blockLightEnhancement or 0)

    PartyConfig:initConfig(FileUtil.getConfigFromCsv("setting/PartySetting.csv"))
    BulletinConfig:initConfig(FileUtil.getConfigFromCsv("setting/BulletinSetting.csv"))
end

function GameConfig:getItemIconData()
    local data = {
        Id = 0,
        ItemId = 0,
        Meta = 0,
        Num = 1,
        Icon = "",
        Name = "",
        Detail = "",
        DataType = Define.ItemIcon.Common,
    }
    return data
end

return GameConfig
