local CommonMain = require "common.CommonMain"

BaseListener.registerCallBack(CEvents.GameInitEvent, function()
    CommonMain:onGameInit()
    if GameType ~= "g1048" then
        require "mine_hole.listener.GameListener"
        require "mine_hole.listener.DataListener"
        require "mine_hole.config.GameConfig"
    else
        require "main.events.HandleEvents"
        require "main.listener.GameListener"
        require "main.listener.DataListener"
        require "main.config.GameConfig"
        require "main.packet.GamePacketSender"
        require "main.web.SkyBlockWeb"
        require "main.data.GameData"
        require "main.data.MultiBuildData"
        require "main.data.RankData"
        GameData:init()
        RankData:init()
        ClientHelper.putBoolPrefs("BlockCustomMeta", true)
    end
    GameListener:init()
    DataListener:init()
end)