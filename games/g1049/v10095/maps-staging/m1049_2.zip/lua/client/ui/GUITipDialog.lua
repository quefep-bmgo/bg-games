local UITipDialog = {}

UITipDialog.TipType = {
    COMMON = 1,
}

function UITipDialog:onShowTipDialog(msg, tipType, smallTips, callBack)
    CustomDialog.builder()
                .setContentText(msg)
                .setLeftClickListener(function()
        if callBack then
            callBack(false)
        end
    end)        .setRightClickListener(function()
        if callBack then
            callBack(true)
        end
    end)        .setCloseClickListener(function()
        if callBack then
            callBack(false)
        end
    end)
    if smallTips then
        CustomDialog.setExtraInfo("", smallTips)
    end
    CustomDialog.show()
end

GUITipDialog = UITipDialog