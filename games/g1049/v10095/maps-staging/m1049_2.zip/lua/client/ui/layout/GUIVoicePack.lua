---@class UIVoicePackLayout : IGUILayout
local UIVoicePackLayout = class("UIVoicePackLayout", IGUILayout)

---@private
function UIVoicePackLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIVoicePackLayout:initCreateEvent()

end

---@private
function UIVoicePackLayout:onLoad()
    self.siBg = self:getChildWindow("VoicePack-Bg", GUIType.StaticImage)
    self.siTag = self:getChildWindow("VoicePack-Tag", GUIType.StaticImage)
    self.llContent = self:getChildWindow("VoicePack-Content", GUIType.Layout)
    self.btnBtn = self:getChildWindow("VoicePack-Btn", GUIType.Button)
    self:initView()
    self:initEvent()
end

---@private
function UIVoicePackLayout:initView()
    self.gvItemList = IGUIGridView.new("VoicePack-List", self.llContent)
    self.gvItemList:setConfig(0, 5, 1)
    ---@type VoicePackItemAdapter
    self.listAdapt = UIHelper.newGameAdapter("VoicePackItemAdapter")
    local itemWidth = self.gvItemList:getWidth()
    self.listAdapt:setItemSize(itemWidth, 40)
    self.gvItemList:setAdapter(self.listAdapt)
end

---@private
function UIVoicePackLayout:initEvent()
    self.btnBtn:registerEvent(GUIEvent.ButtonClick, function()
        local isShow = self.siBg:IsVisible()
        if not self.isInit then
            self:initList()
            return
        end
        self.siBg:SetVisible(not isShow)
    end)
end

function UIVoicePackLayout:initList()
    self.isInit = true
    local player = PlayerManager:getClientPlayer()
    local configs = player.voicePackData:getVoiceCfgList()
    self.listAdapt:setData(configs)
    self.siBg:SetVisible(true)
end

return UIVoicePackLayout
