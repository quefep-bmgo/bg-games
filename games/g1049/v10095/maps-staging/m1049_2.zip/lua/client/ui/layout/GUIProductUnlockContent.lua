---@class UIProductUnlockContentLayout : IGUILayout
local UIProductUnlockContentLayout = class("UIProductUnlockContentLayout", IGUILayout)

---@private
function UIProductUnlockContentLayout:ctor(name, parent)
	self.super.ctor(self, name, parent)
end

---@private
function UIProductUnlockContentLayout:isDelayLoad()
	return true
end

---@private
function UIProductUnlockContentLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIProductUnlockContentLayout:initCreateEvent()

end

---@private
function UIProductUnlockContentLayout:onLoad()
	self.siIcon = self:getChildWindow("ProductUnlockContent-Icon", GUIType.StaticImage)
	self.stName = self:getChildWindow("ProductUnlockContent-Name", GUIType.StaticText)
	self.stDetail = self:getChildWindow("ProductUnlockContent-Detail", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIProductUnlockContentLayout:initView()

end

---@private
function UIProductUnlockContentLayout:initEvent()

end

---@param cfg ProductUnlockConfigData
function UIProductUnlockContentLayout:showProduct(cfg)
	self:show()
	self.siIcon:SetImage(cfg.Icon)
	self.stName:SetText(Lang:getString(cfg.Name))
	self.stDetail:SetText(Lang:getString(cfg.UnlockDetail))
end

---@type UIProductUnlockContentLayout
ProductUnlockContent = buildCustomDialogContent(UIProductUnlockContentLayout, "ProductUnlockContent.json")

return UIProductUnlockContentLayout
