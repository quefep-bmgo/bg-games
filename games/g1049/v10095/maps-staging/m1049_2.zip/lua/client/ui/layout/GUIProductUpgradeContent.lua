---@class UIProductUpgradeContentLayout : IGUILayout
local UIProductUpgradeContentLayout = class("UIProductUpgradeContentLayout", IGUILayout)

---@private
function UIProductUpgradeContentLayout:ctor(name, parent)
    self.super.ctor(self, name, parent)
end

---@private
function UIProductUpgradeContentLayout:isDelayLoad()
    return true
end

---@private
function UIProductUpgradeContentLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIProductUpgradeContentLayout:initCreateEvent()

end

---@private
function UIProductUpgradeContentLayout:onLoad()
    self.stCurrentText = self:getChildWindow("ProductUpgradeContent-CurrentText", GUIType.StaticText)
    ---@type table<number, table<string, CGUIWindow>>
    self.current = {
        {
            icon = self:getChildWindow("ProductUpgradeContent-CurrentItemIcon1", GUIType.StaticImage),
            text = self:getChildWindow("ProductUpgradeContent-CurrentItemText1", GUIType.StaticText),
        },
        {
            icon = self:getChildWindow("ProductUpgradeContent-CurrentItemIcon2", GUIType.StaticImage),
            text = self:getChildWindow("ProductUpgradeContent-CurrentItemText2", GUIType.StaticText),
        },
        {
            icon = self:getChildWindow("ProductUpgradeContent-CurrentItemIcon3", GUIType.StaticImage),
            text = self:getChildWindow("ProductUpgradeContent-CurrentItemText3", GUIType.StaticText),
        }
    }
    ---@type table<number, table<string, CGUIWindow>>
    self.next = {
        {
            icon = self:getChildWindow("ProductUpgradeContent-NextItemIcon1", GUIType.StaticImage),
            text = self:getChildWindow("ProductUpgradeContent-NextItemText1", GUIType.StaticText),
        },
        {
            icon = self:getChildWindow("ProductUpgradeContent-NextItemIcon2", GUIType.StaticImage),
            text = self:getChildWindow("ProductUpgradeContent-NextItemText2", GUIType.StaticText),
        },
        {
            icon = self:getChildWindow("ProductUpgradeContent-NextItemIcon3", GUIType.StaticImage),
            text = self:getChildWindow("ProductUpgradeContent-NextItemText3", GUIType.StaticText),
        }
    }
    self.siArrow = self:getChildWindow("ProductUpgradeContent-Arrow", GUIType.StaticImage)
    self.stNextText = self:getChildWindow("ProductUpgradeContent-NextText", GUIType.StaticText)
    self.stCapacityText = self:getChildWindow("ProductUpgradeContent-CapacityText", GUIType.StaticText)
    self.stCurrentCapacity = self:getChildWindow("ProductUpgradeContent-CurrentCapacity", GUIType.StaticText)
    self.stNextCapacity = self:getChildWindow("ProductUpgradeContent-NextCapacity", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function UIProductUpgradeContentLayout:initView()
    self.stCurrentText:SetText(Lang:getString("gui_skyblock_update_current_name"))
    self.stNextText:SetText(Lang:getString("gui_skyblock_update_next_name"))
    self.stCapacityText:SetText(Lang:getString("gui_skyblock_update_capacity_name"))
end

---@private
function UIProductUpgradeContentLayout:initEvent()

end

---@param
---@param current ProductResourceConfigData
---@param next ProductResourceConfigData
function UIProductUpgradeContentLayout:showProduct(current, next)
    self:show()
    local timeText = "  " .. Lang:getString("gui_skyblock_update_time_title")
    for i = 1, 3 do
        local currentItem = current.outputItems[i]
        local nextItem = next.outputItems[i]
        if currentItem then
            self.current[i].icon:SetVisible(true)
            self.current[i].icon:SetHexagonImage("", "")
            self.current[i].icon:SetRenderAsBlock(false)
            GuiItemStack.showItemIcon(self.current[i].icon, currentItem.itemId, 0, "")
            if not nextItem or currentItem.output ~= nextItem.output then
                self.current[i].text:SetText(TextFormat.colorRed .. currentItem.output .. timeText)
            else
                self.current[i].text:SetText(currentItem.output .. timeText)
            end
        else
            self.current[i].icon:SetVisible(false)
        end
        if nextItem then
            self.next[i].icon:SetVisible(true)
            self.next[i].icon:SetHexagonImage("", "")
            self.next[i].icon:SetRenderAsBlock(false)
            GuiItemStack.showItemIcon(self.next[i].icon, nextItem.itemId, 0, "")
            if not currentItem or currentItem.output ~= nextItem.output then
                self.next[i].text:SetText(TextFormat.colorRed .. nextItem.output .. timeText)
            else
                self.next[i].text:SetText(nextItem.output .. timeText)
            end
        else
            self.next[i].icon:SetVisible(false)
        end
    end
    if current.highestNum ~= next.highestNum then
        self.stCurrentCapacity:SetText(TextFormat.colorRed .. current.highestNum)
        self.stNextCapacity:SetText(TextFormat.colorRed .. next.highestNum)
    else
        self.stCurrentCapacity:SetText(current.highestNum)
        self.stNextCapacity:SetText(next.highestNum)
    end
end

---@type UIProductUpgradeContentLayout
ProductUpgradeContent = buildCustomDialogContent(UIProductUpgradeContentLayout, "ProductUpgradeContent.json")

return UIProductUpgradeContentLayout
