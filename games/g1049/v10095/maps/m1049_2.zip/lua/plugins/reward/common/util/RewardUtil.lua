---@class RewardUtil
local RewardUtil = T(Global, "RewardUtil")
---@type RewardConfig
local RewardConfig = T(Global, "RewardConfig")
---@type GiftBagRewardConfig
local GiftBagRewardConfig = T(Global, "GiftBagRewardConfig")
---@type SRewardPkSender
local RewardPkSender = T(Global, "PidPacketSender")
---@type SItemContainerPkSender
local ItemContainerPkSender = T(Global, "PidPacketSender")
---@type LuckyChestHelper
local LuckyChestHelper = T(Global, "LuckyChestHelper")
---玩家获得奖励待同步记录
local RewardSyncRecord = {}

if isServer then
    LuaTimer:scheduleTicker(function()
        RewardUtil:onTick()
    end, 1)
end

---@private
function RewardUtil:onTick()
    for userId, record in pairs(RewardSyncRecord) do
        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            RewardPkSender:sendPlayerGetReward(player, record)
        end
    end
    RewardSyncRecord = {}
end

---@param player SBasePlayer
local function doReward(player, rewardId, count, showUI)
    local cfg = RewardConfig:getCfgById(rewardId)
    if not cfg then
        return
    end
    count = count or cfg.count
    if cfg.type == Define.RewardType.Item then
        local inventory = player:getPlayerInventory()
        inventory:tryAddItem(cfg.realId, cfg.extraId, count)
    elseif cfg.type == Define.RewardType.Currency then
        player:addCurrency(count)
    elseif cfg.type == Define.RewardType.PassExp then
        player.pass:addPassExp(count)
    elseif cfg.type == Define.RewardType.PassScore then
        player.pass:addPassScore(count, "Reward:" .. rewardId)
    elseif cfg.type == Define.RewardType.TaskChainScore then
        player.taskChain:addTaskChainScore(count, "Reward:" .. rewardId)
    elseif cfg.type == Define.RewardType.LuckyChest then
        LuckyChestHelper:openLuckyChest(player, cfg.realId, count)
        return
    elseif cfg.type == Define.RewardType.GiftBag then
        RewardUtil:doRewards(player, GiftBagRewardConfig:getCfgById(cfg.realId))
        return
    end
    if showUI then
        local record = RewardSyncRecord[player.userId] or {}
        table.insert(record, { cfg.id, count })
        RewardSyncRecord[player.userId] = record
    end
end

---@param player SBasePlayer
function RewardUtil:doRewards(player, rewards, showUI)
    if showUI == nil then
        showUI = true
    end
    for _, reward in pairs(rewards) do
        doReward(player, reward[1], reward[2], showUI)
    end
end

---@param player SBasePlayer | CBasePlayer
local function showInventoryFullTip(player)
    if isClient then
        LuaTimer:scheduleTicker(function()
            CustomDialog.hide()
            CustomDialog.builder()
                        .setContentText(Lang:getString("gui_str_app_shop_inventory_is_full"))
                        .setHideLeftButton()
                        .show()
        end, 1, 1)
    else
        ItemContainerPkSender:sendShowToast(player.rakssid, "gui_str_app_shop_inventory_is_full")
    end
end

---计算奖励占用背包格子的信息
local function calculateRewardOccupyInfo(rewards, items, slots)
    for _, reward in pairs(rewards) do
        local cfg = RewardConfig:getCfgById(reward[1])
        if cfg then
            local count = reward[2] or cfg.count
            if cfg.type == Define.RewardType.Item then
                table.insert(items, { cfg.realId, cfg.extraId, count })
            elseif cfg.type == Define.RewardType.LuckyChest then
                slots = slots + 1
            elseif cfg.type == Define.RewardType.GiftBag then
                slots = calculateRewardOccupyInfo(GiftBagRewardConfig:getCfgById(cfg.realId), items, slots)
            end
        end
    end
    return slots
end

---@param player SBasePlayer | CBasePlayer
function RewardUtil:canRewards(player, rewards)
    local inventory = player:getPlayerInventory()
    local items = {}
    local slots = calculateRewardOccupyInfo(rewards, items, 0)
    if next(items) ~= nil or slots > 0 then
        local hotbar = inventory.hotbar:clone()
        local backpack = inventory.backpack:clone()
        local inv = { hotbar = hotbar, backpack = backpack }
        for _, item in pairs(items) do
            if not inventory.tryAddItem(inv, item[1], item[2], item[3]) then
                showInventoryFullTip(player)
                return false
            end
        end
        if slots > 0 then
            local empty = inv.backpack:getEmptySlotCount() + inv.hotbar:getEmptySlotCount()
            if empty < slots then
                showInventoryFullTip(player)
                return false
            end
        end
    end
    return true
end

return RewardUtil