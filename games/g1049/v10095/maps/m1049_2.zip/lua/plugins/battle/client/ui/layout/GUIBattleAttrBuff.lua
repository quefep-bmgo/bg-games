---@class UIBattleAttrBuffLayout : IGUILayout
local UIBattleAttrBuffLayout = class("UIBattleAttrBuffLayout", IGUILayout)

---@private
function UIBattleAttrBuffLayout:ctor(parent)
    self.super.ctor(self, "BattleAttrBuff.json", parent)
end

---@private
function UIBattleAttrBuffLayout:isDelayLoad()
    return true
end

---@private
function UIBattleAttrBuffLayout:onCreate()
    self:initCreateEvent()
end

---@private
function UIBattleAttrBuffLayout:isShowAnim()
    return false
end

---@private
function UIBattleAttrBuffLayout:initCreateEvent()

end

---@private
function UIBattleAttrBuffLayout:onLoad()
    self.stExtraAttr = self:getChildWindow("BattleAttrBuff-ExtraAttr", GUIType.StaticText)
    self.stMaxHealth = self:getChildWindow("BattleAttrBuff-MaxHealth", GUIType.StaticText)
    self.stAttack = self:getChildWindow("BattleAttrBuff-Attack", GUIType.StaticText)
    self.stDefense = self:getChildWindow("BattleAttrBuff-Defense", GUIType.StaticText)
    self.stCrit = self:getChildWindow("BattleAttrBuff-Crit", GUIType.StaticText)
    self.stCritDamage = self:getChildWindow("BattleAttrBuff-CritDamage", GUIType.StaticText)
    self.stDamageAddition = self:getChildWindow("BattleAttrBuff-DamageAddition", GUIType.StaticText)
    self.stDamageReduce = self:getChildWindow("BattleAttrBuff-DamageReduce", GUIType.StaticText)
    self.stMoveSpeed = self:getChildWindow("BattleAttrBuff-MoveSpeed", GUIType.StaticText)
    self.stSpecialAttr = self:getChildWindow("BattleAttrBuff-SpecialAttr", GUIType.StaticText)
    self.stRealDamage = self:getChildWindow("BattleAttrBuff-RealDamage", GUIType.StaticText)
    self.stSuckBlood = self:getChildWindow("BattleAttrBuff-SuckBlood", GUIType.StaticText)
    self.stDamageRebound = self:getChildWindow("BattleAttrBuff-DamageRebound", GUIType.StaticText)
    self.stKnockBack = self:getChildWindow("BattleAttrBuff-KnockBack", GUIType.StaticText)
    self.stSwordDamage = self:getChildWindow("BattleAttrBuff-SwordDamage", GUIType.StaticText)
    self.stBowDamage = self:getChildWindow("BattleAttrBuff-BowDamage", GUIType.StaticText)
    self.stSuitBuff = self:getChildWindow("BattleAttrBuff-SuitBuff", GUIType.StaticText)
    self.stSuitBuffDesc = self:getChildWindow("BattleAttrBuff-SuitBuffDesc", GUIType.StaticText)
    self.stWeaponBuff = self:getChildWindow("BattleAttrBuff-WeaponBuff", GUIType.StaticText)
    self.stWeaponBuffDesc = self:getChildWindow("BattleAttrBuff-WeaponBuffDesc", GUIType.StaticText)
    self.siClose = self:getChildWindow("BattleAttrBuff-Close", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function UIBattleAttrBuffLayout:initView()
    self.attrInfo = PlayerManager:getClientPlayer().attrInfo
    self.buff = PlayerManager:getClientPlayer().buff
    self.stExtraAttr:SetText(Lang:getString("gui.extra.attr"))
    self.stSpecialAttr:SetText(Lang:getString("gui.special.attr"))
    self.stSuitBuff:SetText(Lang:getString("gui.suit.buff"))
    self.stWeaponBuff:SetText(Lang:getString("gui.weapon.buff"))
    for _, key in pairs(Define.AttrInfoKey) do
        self:setAttrInfoUI(key, self.attrInfo:getValue(key))
    end
end

---@private
function UIBattleAttrBuffLayout:initEvent()
    self.attrInfo:addAllObserver(function(_, key, value)
        self:setAttrInfoUI(key, value)
    end)
    self.siClose:registerEvent(GUIEvent.Click, function()
        self:hide()
    end)
end

function UIBattleAttrBuffLayout:setAttrInfoUI(key, value)
    ---@type GUIStaticText
    local tvAttr = self["st" .. key]
    if not tvAttr then
        return
    end
    if key == Define.AttrInfoKey.DamageReduce
            or key == Define.AttrInfoKey.DamageAddition
            or key == Define.AttrInfoKey.DamageRebound
            or key == Define.AttrInfoKey.MoveSpeed
            or key == Define.AttrInfoKey.Crit
            or key == Define.AttrInfoKey.CritDamage
            or key == Define.AttrInfoKey.SuckBlood
            or key == Define.AttrInfoKey.BlockDoubleDrop
    then
        value = "+" .. value .. "%"
    else
        value = "+" .. value
    end
    local text = Lang:getString("gui.attr." .. key) .. "：" .. TextFormat.colorGreen .. value
    tvAttr:SetText(text)
end

function UIBattleAttrBuffLayout:onTick()
    local none = Lang:getString("gui.attr.buff.none")
    self.stSuitBuffDesc:SetText(none)
    self.stWeaponBuffDesc:SetText(none)
    for _, trigger in pairs(self.buff.triggers) do
        if trigger.cfg.displayLoc == 1 then
            self.stSuitBuffDesc:SetText(Lang:getString(trigger.cfg.displayText))
        elseif trigger.cfg.displayLoc == 2 then
            self.stWeaponBuffDesc:SetText(Lang:getString(trigger.cfg.displayText))
        end
    end
end

return UIBattleAttrBuffLayout
