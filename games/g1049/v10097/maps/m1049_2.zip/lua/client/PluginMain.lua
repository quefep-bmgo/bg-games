local CommonMain = require "common.CommonMain"

BaseListener.registerCallBack(CEvents.GameInitEvent, function()
    CommonMain:onGameInit()
    if GameType == "g1048" then
        require "main.listener.GameListener"
        require "main.config.GameConfig"
        require "main.packet.GamePacketSender"
        require "main.data.GameData"
        require "main.data.RankData"
        GameData:init()
        RankData:init()
        GameListener:init()
        ClientHelper.putBoolPrefs("BlockCustomMeta", true)
    end
end)