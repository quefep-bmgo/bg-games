GameConfig = {}

function GameConfig:init()
    local config = FileUtil.getConfigFromYml("setting/luaconfig")
    self.giveLoveNumLevel = config.giveLoveNumLevel or 1
    self.lightConfig = config.lightConfig
    self.bloomBlurDeviation = tonumber(config.bloomBlurDeviation or 7)
    self.bloomBlurMultiplier = tonumber(config.bloomBlurMultiplier or 1)
    self.blockLightEnhancement = tonumber(config.blockLightEnhancement or 0)
end

return GameConfig
