Define.BuildGroupId = ""
Define.TargetUserId = ""