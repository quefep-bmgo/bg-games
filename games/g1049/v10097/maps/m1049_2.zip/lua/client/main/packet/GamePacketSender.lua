GamePacketSender = {}

function GamePacketSender:sendApplySignPost(data)
    PacketSender:sendLuaCommonData("ApplySignPost", data)
end

return GamePacketSender