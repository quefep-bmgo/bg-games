--region *.lua

require "mine_hole.config.GameConfig"

GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameInitEvent, self.onGameInit)
end

function GameListener.onGameInit(config)
    GameConfig:init(config)
    PlayerManager:setMaxPlayer(100)
end

return GameListener
--endregion