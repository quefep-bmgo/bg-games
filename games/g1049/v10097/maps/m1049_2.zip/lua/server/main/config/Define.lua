Define.manorRelese = {
    Not = 1,
    Start = 2,
    End = 3,
}

Define.visitMasterTips = {
    onShow = "onShow",
    notShow = "notShow",
}

Define.startReleaseTime = 120

Define.SchematicCreateOrDestroyNum = 2