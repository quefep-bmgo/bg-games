SkyBlockWeb = {}

----BuildGet
SkyBlockWeb.buildMemberApi = "/gameaide/api/v1/inner/game/build/member"
SkyBlockWeb.buildGroupApi = "/gameaide/api/v1/inner/my/game/build"

function SkyBlockWeb:init()
    self.RewardAddr = WebService.ServerHttpHost
end

function SkyBlockWeb:getbuildMember(userId, targetUserId, isShowTips)
    print("web getbuildMember userId == " .. tostring(userId) .. " targetUserId == " .. tostring(targetUserId))
    local path = self.RewardAddr .. self.buildMemberApi

    local params = {
        { "userId", tostring(targetUserId) },
        { "gameId", GameMatch.gameType },
    }
    WebService.asyncGet(path, params, function(data, code)
        local player = PlayerManager:getPlayerByUserId(userId)
        if not player then
            return
        end
        print("onGetBuildMember code = " .. tostring(code) .. " extra = " .. tostring(userId) .. ":" .. tostring(isShowTips))
        if code == 1 and data then
            GameMultiBuild:onBuildGroupData(userId, isShowTips, data)
        end
    end)
end

function SkyBlockWeb:getbuildGroup(userId, isShowTips)
    print("web getbuildGroup userId == " .. tostring(userId))
    local path = self.RewardAddr .. self.buildGroupApi

    local params = {
        { "userId", tostring(userId) },
        { "gameId", GameMatch.gameType },
    }
    WebService.asyncGet(path, params, function(data, code)
        local player = PlayerManager:getPlayerByUserId(userId)
        if not player then
            return
        end
        print("onGetBuildGroup code = " .. tostring(code) .. " mark = " .. tostring(userId) .. ":" .. tostring(isShowTips))
        if code == 1 and data then
            GameMultiBuild:onBuildGroupUserId(userId, isShowTips, data)
        end
    end)
end

