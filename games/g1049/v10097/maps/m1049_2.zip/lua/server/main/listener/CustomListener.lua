---
--- Created by Jimmy.
--- DateTime: 2018/6/8 0008 11:51
---
CustomListener = {}

function CustomListener:init()

end

function CustomListener.onConsumeTipMsg(rakssid, extra, isRight)

end

return CustomListener
--endregion