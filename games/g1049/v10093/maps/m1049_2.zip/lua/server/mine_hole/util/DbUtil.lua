--DbUtil.lua
DbUtil = {}
DbUtil.TAG_SHAREDATA = "ShareData"

DBManager:addMustLoadSubKey(DbUtil.TAG_SHAREDATA)

function DbUtil:getPlayerData(userId)
    DBManager:getPlayerData(userId, DbUtil.TAG_SHAREDATA)
end

function DbUtil:onPlayerGetDataFinish(player, data, subKey)
    if subKey == DbUtil.TAG_SHAREDATA then
        player:initShareDataFromDB(data)
    end
end

function DbUtil:savePlayerData(player, immediate)
    if player == nil then
        return
    end
    DbUtil:SavePlayerShareData(player, immediate)
end

function DbUtil:SavePlayerShareData(player, immediate)
    local subKey = DbUtil.TAG_SHAREDATA
    if not DBManager:isLoadDataFinished(player.userId, subKey) then
        return
    end
    local data = {}
    if player.isLife then
        data.hp = player:getHealth()
        data.maxHp = player:getMaxHealth()
        data.foodLevel = player:getFoodLevel()
    else
        data.hp = Define.InitHP
        data.maxHp = Define.InitHP
        data.foodLevel = 20
    end
    data.money = player.money
    if data.money < 0 then
        data.money = 0
    end
    data.score = player.score
    data.exp = player.exp
    data.level = player.level
    data.area = player.area
    data.products = player.products
    data.privilege = player.privilegeData
    DBManager:savePlayerData(player.userId, DbUtil.TAG_SHAREDATA, data, immediate)
end

function DbUtil:CanSavePlayerData(player, subKey)
    return DBManager:isLoadDataFinished(player.userId, subKey)
end

return DbUtil