---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
require "mine_hole.Match"
---@type SSkyBlockPlayer
local SSkyBlockPlayer = require "common.entity.SSkyBlockPlayer"
---@type ProductDataInit
local ProductDataInit = T(Global, "ProductDataInit")
---@type ExpConfig
local ExpConfig = T(Global, "ExpConfig")
---@type CommonConfig
local CommonConfig = T(Global, "CommonConfig")
---@type SSkyBlockPlayer
GamePlayer = class("GamePlayer", SSkyBlockPlayer)

function GamePlayer:init()
    SSkyBlockPlayer.init(self)
    self.isLife = true
    self.products = {}
    self.privilegeData = {}
    self.cur_pri_item = {}
    self.inHandItemId = 0
    self.diedPos = VectorUtil.ZERO
    self:initStaticAttr(0)
    self.has_ad = false
    self.canSendCostDiamond = true
    self.needRecivePri = false
end

function GamePlayer:initShareDataFromDB(data)
    if not data.__first then
        self.hp = data.hp or Define.InitHP
        self.money = data.money or 0
        self.exp = data.exp or 0
        self.level = data.level or 1
        self.area = data.area or "20*20*20"
        self.products = data.products or {}
        self.privilegeData = data.privilege or {}
    else
        HostApi.log("initShareDataFromDB the data.__first is true ")
    end
    if not data.__first then
        self:setHealth(self.hp)
        self:setFoodLevel(data.foodLevel or 20)
    end
    self:teleInitPos()
    self:syncListInfo()
    self:setCurrency(self.money)
    ProductDataInit:initProductData(self)
end

function GamePlayer:onMoneyChange()
    self.money = self:getCurrency()
    if self.money then
        HostApi.log("onMoneyChange " .. tostring(self.userId) .. " money: " .. self.money)
    end
end

function GamePlayer:onTick()

end

function GamePlayer:teleInitPos()
    CommonConfig:teleportInitPos(self)
end

function GamePlayer:getListInfo()
    local lv = self.level or 1
    local cur_exp = self.exp or 0
    local max_exp, is_max = ExpConfig:getMaxExp(self.level)
    local area = self.area or "20*20*20"
    return lv, cur_exp, max_exp, area, is_max
end

function GamePlayer:syncListInfo()
    local lv, cur_exp, max_exp, area, is_max = self:getListInfo()
    self:sendPacket({
        pid = "syncListInfo",
        data = {
            lv = lv,
            exp = cur_exp,
            maxExp = max_exp,
            area = area,
            userId = self.userId
        }
    })
end

function GamePlayer:addScore(score)
    self.score = self.score + score
end

function GamePlayer:reward()
    RewardManager:getUserGoldReward(self.userId, self.score, function(data)

    end)
end

function GamePlayer:CanSavePlayerShareData()
    return DbUtil:CanSavePlayerData(self, DbUtil.TAG_SHAREDATA)
end

return GamePlayer

--endregion


