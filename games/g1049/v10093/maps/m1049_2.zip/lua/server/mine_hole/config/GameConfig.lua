---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:16
---
require "mine_hole.config.Define"
require "mine_hole.config.FlipFrontConfig"
require "mine_hole.config.FlipBackConfig"

GameConfig = {}

function GameConfig:init(config)
    FlipFrontConfig:initConfig(config.flipFront)
    FlipBackConfig:initConfig(config.flipBack)
end

return GameConfig