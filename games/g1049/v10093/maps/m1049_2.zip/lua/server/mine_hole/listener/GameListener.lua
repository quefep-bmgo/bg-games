--region *.lua

require "mine_hole.config.GameConfig"

GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameInitEvent, self.onGameInit)
end

function GameListener.onGameInit(config)
    GameConfig:init(config)
    GameMatch:initMatch()
    DBManager:setGameType("g1048")
    PlayerManager:setMaxPlayer(100)
end

return GameListener
--endregion