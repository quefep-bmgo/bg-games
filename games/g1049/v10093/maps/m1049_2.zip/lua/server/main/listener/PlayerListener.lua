--region *.lua

require "main.messages.Messages"
require "main.data.GamePlayer"
require "main.Match"

PlayerListener = {}

function PlayerListener:init()

    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerRespawnEvent, self.onPlayerRespawn)
    BaseListener.registerCallBack(CEvents.PlayerDynamicAttrEvent, self.onDynamicAttrInit)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerCallOnTargetManorEvent:registerCallBack(self.onPlayerCallOnTargetManor)
    CEvents.PlayerChangeItemInHandEvent:registerCallBack(self.onChangeItemInHandEvent)
    CEvents.BlockStationaryNotStationaryEvent:registerCallBack(self.onBlockStationaryNotStationary)
    CEvents.PlayerPlaceBlockBoxJudgeEvent:registerCallBack(self.onPlayerPlaceBlockBoxJudgeEvent)
    CEvents.PlayerCurrencyChangeEvent:registerCallBack(self.onPlayerCurrencyChange)
    CEvents.PlayerCloseContainerEvent:registerCallBack(self.onPlayerCloseContainer)
    CEvents.PlayerUseInitSpawnPositionEvent:registerCallBack(self.onPlayerUseInitSpawnPosition)
    CEvents.UserManorReleaseEvent:registerCallBack(self.onUserManorRelease)

    PlayerExtendAreaEvent:registerCallBack(self.onPlayerExtendArea)
    PlayerSetHomeEvent:registerCallBack(self.onPlayerSetHome)

    SkyBlockCreatePartyEvent:registerCallBack(self.SkyBlockCreateParty)
    SkyBlockApplyPartyEvent:registerCallBack(self.SkyBlockApplyParty)
    SkyBlockGiveLoveEvent:registerCallBack(self.SkyBlockGiveLove)
    ToolBarGiveLoveEvent:registerCallBack(self.ToolBarGiveLove)
    ApplySignPostEvent:registerCallBack(self.onApplySignPost)

    GetTogetherBuildDataEvent:registerCallBack(self.onGetTogetherBuildData)
    KickOutPlayerEvent:registerCallBack(self.onKickOutPlayer)
    OtherPlayerUpdateDataEvent:registerCallBack(self.onOtherPlayerUpdateData)
    PlayerShowTipsEvent:registerCallBack(self.onPlayerShowTips)
    PlayerClickBulletinEvent:registerCallBack(self.onClickBulletin)

    CEvents.SkyBlockPartyAlmostOverEvent:registerCallBack(self.onSkyBlockPartyAlmostOver)
    CEvents.SkyBlockPartyOverEvent:registerCallBack(self.onSkyBlockPartyOver)
    CEvents.SkyBlockFriendUpdateEvent:registerCallBack(self.SkyBlockFriendUpdate)
end

function PlayerListener.onPlayerLogin(clientPeer)
    local player = GamePlayer.new(clientPeer)
    player:init()
    GameParty:partyAddPlayer(player.userId)
    GameMultiBuild:onPlayerLogin(player)
    return GameOverCode.Success, player, 1
end

function PlayerListener.onPlayerLogout(player)
    GameMatch:onPlayerQuit(player)
end

function PlayerListener.onPlayerReady(player)
    if player:visitorCheckCanGetBlockData() == false then
        player.isReady = false
        HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
        return 0
    end

    if player.manorIndex <= 0 or player.manorIndex > #GameConfig.manorStart then
        player.isReady = false
        HostApi.log("PlayerListener.onPlayerReady manorIndex error userId: " .. tostring(player.userId) .. " " .. player.manorIndex)
        HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
        return 0
    end

    local manorInfo = GameMatch:getUserManorInfo(player.userId)
    if manorInfo ~= nil then
        manorInfo:masterLogin()
        manorInfo:refreshTime()
        manorInfo:initAllTree()
        DbUtil.getPlayerData(player.userId, DbUtil.TAG_MANOR)

        player.manorIsExistWhenReady = true
    else
        player.manorIsExistWhenReady = false
    end

    DbUtil.getPlayerData(player.userId, DbUtil.TAG_SHAREDATA)
    DbUtil.getPlayerData(player.userId, DbUtil.TAG_PLAYER)
    DbUtil.getPlayerData(player.userId, DbUtil.DIALOG_TIPS)
    RankConfig:getPlayerRankData(player)

    HostApi.sendPlaySound(player.rakssid, 10041)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))

    -- go home
    if GameMatch:isMaster(player.userId) then
        HostApi.log("PlayerListener.onPlayerReady go home isMaster" .. tostring(player.userId))
        if GameMatch:hasErrorDataInManor(player.userId) then
            HostApi.log("PlayerListener.onPlayerReady master: other has the same manorIndex sendGameover " .. tostring(player.userId))
            HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
            return 0
        end

        local selfManorInfo = GameMatch:getUserManorInfo(player.userId)
        if selfManorInfo and selfManorInfo.isNotInPartyCreateOrOver == false then
            HostApi.log("PlayerListener.onPlayerReady go home manor is in partyCreateOrOver " .. tostring(player.userId))
            HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
            return 0
        end
    else
        HostApi.log("PlayerListener.onPlayerReady is vistor" .. tostring(player.userId) .. " " .. tostring(player.target_user_id))
        if GameMatch:hasErrorDataInManor(player.target_user_id) then
            HostApi.log("PlayerListener.onPlayerReady vistor: other has the same manorIndex sendGameover " .. tostring(player.target_user_id))
            HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
            return 0
        end

        local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
        if targetManorInfo then
            if targetManorInfo.isNotInPartyCreateOrOver == false then
                HostApi.log("PlayerListener.onPlayerReady vistor targetManor is in partyCreateOrOver " .. tostring(player.userId) .. " manorId: " .. tostring(targetManorInfo.userId))
                HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
                return 0
            else
                local targetPlayer = PlayerManager:getPlayerByUserId(player.target_user_id)
                if targetPlayer then
                    local data = {}
                    data.targetName = targetPlayer.name
                    GamePacketSender:sendWelcomeVisitorTip(player.rakssid, json.encode(data))
                else
                    local items = {}
                    local key = ""
                    local userIds = {}
                    table.insert(userIds, player.target_user_id)
                    UserInfoCache:GetCacheByUserIds(userIds, function()
                        local targetPlayer = UserInfoCache:GetCache(player.target_user_id)
                        if targetPlayer then
                            local data = {}
                            data.targetName = targetPlayer.name
                            GamePacketSender:sendWelcomeVisitorTip(player.rakssid, json.encode(data))
                        end
                    end, key, items)
                end
                player:sendPacket({
                    pid = "syncListInfo",
                    data = {
                        userId = player.target_user_id
                    }
                })
                GameParty:sendPlayerPartyData(player.userId, player.target_user_id)
                HostApi.log("PlayerListener.onPlayerReady visitorInHouse userId: " .. tostring(player.userId) .. " manorId: " .. tostring(targetManorInfo.userId))
                targetManorInfo:visitorInHouse(player.userId)
            end
        end
    end

    GameParty:getPartyInfo(player.userId)
    GameParty:getLoveNum(player.userId)
    GameParty:getFriendPartyList(player.userId)
    GameParty:sendAllPartyData(player.rakssid)
    GameParty:getFreeCreateNum(player.userId)
    GameMultiBuild:upDataBuildGroupData(player.userId, Define.visitMasterTips.onShow)
    player:getOwnPicUrl()
    Plugins.CallTargetPluginFunc("vf_app_activity", "addGameBadge", player)
    return 4320000
end

function PlayerListener.onPlayerRespawn(player)
    player.isLife = true
    player:teleInitPos()
    return 4320000
end

function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return false
    end
    if y <= GameConfig.deathLineY then
        local maxHp = player:getMaxHealth()
        player:setHealth(maxHp)
        player:setFoodLevel(20)
        player:teleInitPos()
        return false
    end
    player:onMove(x, y, z)
    return true
end

function PlayerListener.onDynamicAttrInit(attr, gamePartyUserId)
    if attr.manorId < 0 then
        return
    end
    local platformId = attr.userId
    local targetUserId = attr.targetUserId
    local manorIndex = attr.manorId
    HostApi.log("==== LuaLog: PlayerListener.onDynamicAttrInit  --- start --- : platformId = "
            .. tostring(platformId) .. ", targetUserId = " .. tostring(targetUserId) .. ", manorIndex = " .. manorIndex .. ", gamePartyUserId = " .. tostring(gamePartyUserId))
    if tostring(targetUserId) ~= "0" and manorIndex > 0 then
        GameMatch:initCallOnTarget(platformId, targetUserId)

        local userManorInfo = GameMatch.userManorInfo[tostring(targetUserId)]
        if userManorInfo == nil then

            local isRepeatManor, repeatManor = GameMatch:isRepeatManorIndex(manorIndex)
            if isRepeatManor == true then
                if repeatManor and repeatManor.isInRoomForceRelease == false then
                    HostApi.log("it may be exist repeat manorIndex when a new manor is create check it !")
                end
            end

            HostApi.log("==== LuaLog: GameManor.new : " .. tostring(targetUserId))
            local manorInfo = GameManor.new(manorIndex, targetUserId)
            GameMatch:initUserManorInfo(targetUserId, manorInfo)
            manorInfo:initChunkIndex()

        else
            HostApi.log("==== LuaLog: userManorInfo:refreshTime : " .. tostring(targetUserId) .. " " .. userManorInfo.release_status)

            userManorInfo:refreshTime()
            if userManorInfo.release_status ~= Define.manorRelese.Not then
                userManorInfo:initChunkIndex()
            end

            --if tostring(platformId) ~= tostring(targetUserId) then
            --    userManorInfo:visitorInHouse(platformId)
            --end
        end
    else
        HostApi.log("==== LuaLog: PlayerListener.onDynamicAttrInit [targetUserId == 0] or [manorIndex <= 0] ")
    end

    if tostring(platformId) == tostring(targetUserId) and tostring(platformId) == tostring(gamePartyUserId) then
        GameParty:getAllPartyList()
    end
end

function PlayerListener.onPlayerCallOnTargetManor(userId, targetId, from, isFriend, score)
    HostApi.log("onPlayerCallOnTargetManor userId: " .. tostring(userId) .. " targetId: " .. tostring(targetId) .. " from: " .. from)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return true
    end

    if tostring(userId) == tostring(targetId) then
        HostApi.log("onPlayerCallOnTargetManor self " .. tostring(userId))
        return true
    end

    if player.isNotInPartyCreateOrOver == false then
        return true
    end

    local targetPlayer = PlayerManager:getPlayerByUserId(targetId)
    if targetPlayer then
        local data = {}
        data.targetName = targetPlayer.name
        GamePacketSender:sendWelcomeVisitorTip(player.rakssid, json.encode(data))
    end
    -- target player is not online, see as target manor is not in this server,
    -- because target player may be in party server, but his common manor is in this server
    -- if targetPlayer == nil then
    --     EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", targetId)
    --     return true
    -- end

    if targetPlayer and targetPlayer.isNotInPartyCreateOrOver == false then
        return true
    end

    local manorInfo = GameMatch:getUserManorInfo(targetId)
    if not manorInfo then
        -- vistor is not in this server
        player.info:onJumpGame()
        EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", targetId)
        return true
    else
        if manorInfo.isNotInPartyCreateOrOver == false then
            HostApi.log("onPlayerCallOnTargetManor manor is in createPartyOrOver userId: " .. tostring(player.userId) .. " targetId: " .. tostring(targetId))
            player.info:onJumpGame()
            EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", targetId)
            return true
        end
    end

    -- out of vistors list of current manor
    GameMatch:leaveCurrentManor(userId)
    local notSameTarget = true
    if tostring(player.target_user_id) == tostring(targetId) then
        notSameTarget = false
    end

    -- vistor is in this server
    local manorIndex = 0
    local targetManorInfo = GameMatch:getUserManorInfo(targetId)
    if targetManorInfo ~= nil then
        manorIndex = targetManorInfo.manorIndex
        local pos = GameConfig:getInitPosByManorIndex(targetManorInfo.manorIndex)
        if pos then
            HostApi.log("callon in this server userId: " .. tostring(player.userId) .. " targetId: " .. tostring(targetManorInfo.userId))
            if notSameTarget then
                GameParty:partySubPlayer(userId)
            end
            GameMatch:initCallOnTarget(userId, targetId)
            player:teleportPos(pos)
            GameMultiBuild:upDataBuildGroupData(userId, Define.visitMasterTips.onShow)
            player:setRespawnPos(pos)
            player.isGenisland = false
            player.privilege:onBackHome(player)
            player.manorIndex = targetManorInfo.manorIndex
            player.target_user_id = targetManorInfo.userId
            player:initChunkIndex()
            targetManorInfo:refreshTime()
            if targetManorInfo.release_status ~= Define.manorRelese.Not then
                targetManorInfo:initChunkIndex()
            end
            targetManorInfo:visitorInHouse(userId)
            if notSameTarget then
                GameParty:partyAddPlayer(userId)
            end
            GameParty:getLoveNum(userId)
            player:changeShowData()
            player:sendPacket({
                pid = "syncListInfo",
                data = {
                    userId = targetId
                }
            })
        end
    end
    -- end

    return true

end

function PlayerListener.onChangeItemInHandEvent(rakssid, itemId, itemMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        player.inHandItemId = itemId
    end
end

function PlayerListener.onBlockStationaryNotStationary(blockId)
    return false
end

function PlayerListener.onPlayerPlaceBlockBoxJudgeEvent(blockId)
    return false
end

function PlayerListener.onPlayerExtendArea(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    player:checkExtendArea()
end

function PlayerListener.onPlayerSetHome(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    if not player.isLife then
        HostApi.log("onPlayerSetHome player.userId : .." .. tostring(player.userId) .. " player.isLife == false ")
        return
    end
    if player.isGenisland then
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgSetHomeFailed())
        return
    end
    if not DbUtil.CanSavePlayerData(player, DbUtil.TAG_PLAYER) then
        return
    end

    if not GameMatch:isMaster(player.userId) then
        HostApi.sendCommonTip(player.rakssid, "you_must_back_to_use")
        return
    end

    if player:getEntityPlayer() ~= nil then
        if not player:getEntityPlayer():canFall() then
            local Pos = player:getPosition()
            local underBlockPos = VectorUtil.toBlockVector3(Pos.x, Pos.y - 1, Pos.z)
            local blockId = EngineWorld:getBlockId(underBlockPos)
            if blockId ~= BlockID.AIR and blockId ~= 916 then
                local manorInfo = GameMatch:getUserManorInfo(player.userId)
                local Pos = manorInfo:aPosToRPos(VectorUtil.newVector3(underBlockPos.x + 0.5, underBlockPos.y + 1, underBlockPos.z + 0.5))
                if Pos then
                    player.respawnPos = Pos
                    -- HostApi.log("onPlayerSetHome respawnPos aPos  " .. tostring(player.userId) .. " " .. underBlockPos.x .. " " .. underBlockPos.y .. " " .. underBlockPos.z )
                    -- HostApi.log("onPlayerSetHome respawnPos rPos  " .. tostring(player.userId) .. " " .. player.respawnPos.x .. " " .. player.respawnPos.y .. " " .. player.respawnPos.z )
                    MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgSetHomeSuccess())
                    player.yaw = player:getYaw()
                    if player.enableIndie then
                        GameAnalytics:design(player.userId, 0, { "g1048set_home_indie", "g1048set_home_indie" })
                    else
                        GameAnalytics:design(player.userId, 0, { "g1048set_home", "g1048set_home" })
                    end
                    return
                end
            end
        end
    end
    MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgForbidSetHome())
end

function PlayerListener.onPlayerCloseContainer(rakssid, vec3)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    return true
end

function PlayerListener.onPlayerUseInitSpawnPosition(userId, position)
    local targetUserId = GameMatch:getTargetByUid(userId)
    if targetUserId ~= nil then
        local targetManorInfo = GameMatch:getUserManorInfo(targetUserId)
        if targetManorInfo ~= nil and targetManorInfo.manorIndex >= 1 and targetManorInfo.manorIndex <= #GameConfig.manorStart then
            local pos = GameConfig:getInitPosByManorIndex(targetManorInfo.manorIndex)
            position.x = pos.x
            position.y = pos.y
            position.z = pos.z
            return false
        end
    end

    return true
end

function PlayerListener.onUserManorRelease(userId)
    HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease packet start " .. tostring(userId))

    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is not online " .. tostring(userId))
        local targetManorInfo = GameMatch:getUserManorInfo(userId)
        if targetManorInfo then
            HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is not online releaseManor " .. tostring(userId) .. " manorIndex: " .. targetManorInfo.manorIndex)
            GameMatch:releaseManor(userId)
            targetManorInfo.isInRoomForceRelease = true
        end
    else
        HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is online " .. tostring(userId))
        local targetManorInfo = GameMatch:getUserManorInfo(userId)
        if targetManorInfo then
            HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is online releaseManor " .. tostring(userId) .. " manorIndex: " .. targetManorInfo.manorIndex)
            GameMatch:releaseManor(userId)
            targetManorInfo.isInRoomForceRelease = true
        end
        HostApi.log("==== LuaLog: PlayerListener.onUserManorRelease is online kickout " .. tostring(userId))
        HostApi.sendGameover(player.rakssid, IMessages:msgGameOverByDBDataError(), GameOverCode.LoadDBDataError)
    end
end

function PlayerListener.onPlayerCurrencyChange(rakssid, currency)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player ~= nil then
        player:onMoneyChange()
    end
end

function PlayerListener.SkyBlockCreateParty(userId, data)
    print("SkyBlockCreateParty userId == " .. tostring(userId))
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    if player.createPartyTag then
        return
    end

    if not GameMatch:isMaster(userId) then
        HostApi.sendCommonTip(player.rakssid, "please_back_home_try_again")
        return
    end

    if player.isGenisland == true then
        HostApi.sendCommonTip(player.rakssid, "please_back_home_try_again")
        return
    end

    local curTable = json.decode(data)
    if curTable then
        if curTable.index == 1 and curTable.createType == Define.CreatePartyType.FREE
                and player.freeCreatePartyTimes < Define.freeCreateTimes and player.freeCreatePartyTimes >= 0 then
            local cfg = PartyConfig:getPriceDataById(curTable.index)
            if cfg then
                player.msgTips = curTable.msgTips or "0"
                local info = {
                    userId = userId,
                    currency = Define.Money.GOLD_DIAMOND,
                    quantity = 0,
                    partyName = curTable.partyName,
                    partyDesc = curTable.partyDesc,
                    time = cfg.Time,
                    maxPlayerNum = GameConfig.partyMaxPlayer,
                    index = cfg.Id,
                    createType = Define.CreatePartyType.FREE,
                }
                player.createPartyTag = true
                GameParty:createParty(info)
                return
            end
        end

        if curTable.createType == Define.CreatePartyType.NOT_FREE then
            local cfg = PartyConfig:getPriceDataById(curTable.index)
            if cfg then
                if player:getDiamond() + player.gameCashCoupon >= cfg.Price then
                    player.msgTips = curTable.msgTips or "0"
                    local info = {
                        userId = userId,
                        currency = Define.Money.GOLD_DIAMOND,
                        quantity = cfg.Price,
                        partyName = curTable.partyName,
                        partyDesc = curTable.partyDesc,
                        time = cfg.Time,
                        maxPlayerNum = GameConfig.partyMaxPlayer,
                        index = cfg.Id,
                        createType = Define.CreatePartyType.NOT_FREE,
                    }
                    player.createPartyTag = true
                    GameParty:createParty(info)
                else
                    HostApi.sendCommonTip(player.rakssid, "lack_of_money")
                end
            end
        end
    end
end

function PlayerListener.SkyBlockApplyParty(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    local curTable = json.decode(data)
    if curTable then
        GameParty:applyParty(userId, curTable.partyName, curTable.partyDesc)
    end
end

function PlayerListener.SkyBlockGiveLove(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    if DbUtil.CanSavePlayerData(player, DbUtil.TAG_PLAYER) and DbUtil.CanSavePlayerData(player, DbUtil.TAG_SHAREDATA) then
        local builder = DataBuilder.new():fromData(data)
        local targetUserId = builder:getParam("targetUserId")
        if player:checkCanGiveLove(targetUserId) then
            GameParty:giveLoveInfo(player.userId, targetUserId)
        end
    end
end

function PlayerListener.ToolBarGiveLove(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local targetUserId = GameMatch:getTargetByUid(userId)
    if player:checkCanGiveLove(targetUserId) then
        GameParty:giveLoveInfo(userId, targetUserId)
    end
end

function PlayerListener.onSkyBlockPartyOver(userId)
    print("onSkyBlockPartyOver userId == " .. tostring(userId))
    local manorInfo = GameMatch:getUserManorInfo(userId)
    if manorInfo then
        for k, v in pairs(manorInfo.visitor) do
            local visitor_player = PlayerManager:getPlayerByUserId(v)
            if visitor_player and tostring(visitor_player.userId) ~= tostring(userId) then
                visitor_player.tipsUserId = tostring(visitor_player.userId)
                visitor_player.tips = "party_is_over"
                -- HostApi.sendCommonTip(visitor_player.rakssid, "party_is_over_goto_home")
                if GameMultiBuild:checkIsMember(v, userId) then
                    visitor_player.tips = "party_over_back_master_islang"
                    visitor_player.tipsUserId = tostring(userId)
                    visitor_player.info:onJumpGame()
                    EngineUtil.sendEnterOtherGame(visitor_player.rakssid, "g1048", userId)
                    visitor_player.isNotInPartyCreateOrOver = false
                    GameMatch:partyGameOverToPlayer(v)
                elseif visitor_player:checkBackHome() then
                    visitor_player.isNotInPartyCreateOrOver = false
                    GameMatch:partyGameOverToPlayer(v)
                end
            end
        end

        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            DbUtil.savePlayerData(player, true)
            player.tips = "party_is_over"
            player.tipsUserId = tostring(userId)
            player.isNotInPartyCreateOrOver = false
        end

        manorInfo.time = Define.startReleaseTime
        manorInfo.isNotInPartyCreateOrOver = false
        manorInfo:masterLogout()
        GameMatch:releaseManor(userId)
        if player then
            player.info:onJumpGame()
            EngineUtil.sendEnterOtherGame(player.rakssid, "g1048", player.userId)
            -- HostApi.sendCommonTip(player.rakssid, "party_is_over_goto_home")
        end

        GameMatch:partyGameOverToPlayer(userId)
    end
end

function PlayerListener.onSkyBlockPartyAlmostOver(userId)
    print("onSkyBlockPartyAlmostOver userId == " .. tostring(userId))
    local manorInfo = GameMatch:getUserManorInfo(userId)
    if manorInfo then
        for k, v in pairs(manorInfo.visitor) do
            local player = PlayerManager:getPlayerByUserId(v)
            if player then
                HostApi.sendCommonTip(player.rakssid, "party_almost_over")
            end
        end
    end

    local player = PlayerManager:getPlayerByUserId(userId)
    if player then
        HostApi.sendCommonTip(player.rakssid, "party_almost_over")
    end
end

function PlayerListener.onApplySignPost(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local tab = json.decode(data)
    print("onApplySignPost tab.editText 1 : " .. tostring(tab.editText))
    print("onApplySignPost tab.cur_pos  2 : " .. tostring(tab.cur_pos))
    if tab and tab.editText and tab.cur_pos then
        local x, y, z = GameConfig:decodeHash(tab.cur_pos)
        local vec3i = VectorUtil.newVector3i(x, y, z)
        local blockId = EngineWorld:getBlockId(vec3i)
        if blockId == BlockID.SIGN_POST or blockId == BlockID.SIGN_WALL then
            if not player:checkChunkLoad() then
                return
            end
            local master = PlayerManager:getPlayerByUserId(player.target_user_id)
            if master == nil then
                return
            end
            if master.isNotInPartyCreateOrOver == false then
                return false
            end
            if not DbUtil.CanSavePlayerData(master, DbUtil.TAG_SIGN) then
                return
            end
            local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
            if targetManorInfo == nil then
                return
            end
            if targetManorInfo:isLoadingBlock() then
                return
            end
            -- do not have power
            if not targetManorInfo:checkPower(player.userId, vec3i, "onApplySignPost") then
                return
            end
            if targetManorInfo:checkSignPostTextLimit() and targetManorInfo:checkSignPostIsNew(vec3i) == nil and tab.editText ~= "" then
                MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgSignPostTextLimit(GameConfig.signPostNum))
            else
                targetManorInfo:recordSignPostText(vec3i, tostring(tab.editText), false)
                if player.enableIndie then
                    GameAnalytics:design(player.userId, 0, { "g1048write_sign_indie", "g1048write_sign_indie" })
                else
                    GameAnalytics:design(player.userId, 0, { "g1048write_sign", "g1048write_sign" })
                end
            end
        else
            print("onApplySignPost userId and blockId : " .. tostring(userId) .. tostring(blockId))
        end
    end
end

function PlayerListener.onGetTogetherBuildData(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    HostApi.log("onGetTogetherBuildData userId: " .. tostring(player.userId))
    GameMultiBuild:upDataBuildGroupData(userId, Define.visitMasterTips.notShow)
end

function PlayerListener.onOtherPlayerUpdateData(userId, data)
    print("OtherPlayerUpdateDataEvent userId == " .. tostring(userId))
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    local curTable = json.decode(data)
    if curTable then
        local player = PlayerManager:getPlayerByUserId(curTable.targetUserId)
        if player then
            GamePacketSender:sendMultiBuildUpdate(player.rakssid, data)
        else
            WebService:SendMsg({ tostring(curTable.targetUserId) }, data, 104803, "user", "g1048")
        end
    end
end

function PlayerListener.SkyBlockFriendUpdate(userId, data)
    print("SkyBlockFriendUpdate userId == " .. tostring(userId))
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    if data then
        GamePacketSender:sendMultiBuildUpdate(player.rakssid, data)
    end
end

function PlayerListener.onKickOutPlayer(userId, data)
    print("onKickOutPlayer  userId == " .. tostring(userId))
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local curTable = json.decode(data)
    if curTable then
        local targetPlayer = PlayerManager:getPlayerByUserId(curTable.targetUserId)
        if targetPlayer == nil then
            return
        end

        if tostring(targetPlayer.target_user_id) == tostring(userId) then
            if curTable.tips ~= "" then
                targetPlayer.tips = curTable.tips
                targetPlayer.tipsUserId = tostring(targetPlayer.userId)
                targetPlayer:checkBackHome()
            end
        end
    end
end

function PlayerListener.onPlayerShowTips(userId, data)
    print("onPlayerShowTips  userId == " .. tostring(userId))
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local curTable = json.decode(data)
    if curTable then
        local targetPlayer = PlayerManager:getPlayerByUserId(curTable.targetUserId)
        if targetPlayer == nil then
            return
        end

        if tostring(targetPlayer.target_user_id) == tostring(userId) then
            HostApi.sendCommonTip(targetPlayer.rakssid, curTable.tips)
        end
    end
end

function PlayerListener.onClickBulletin(userId, data)
    print("onClickBulletin  userId == " .. tostring(userId))
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    local curTable = json.decode(data)
    if curTable then
        player:CheckClickBulletin(curTable)
    end
end

return PlayerListener
--endregion
