---@type TaskUtil
local TaskUtil = T(Global, "TaskUtil")
---@type BlockConfig
local BlockConfig = T(Global, "BlockConfig")

require "main.Match"
require "main.messages.Messages"

BlockListener = {}

function BlockListener:init()
    CEvents.BlockBreakWithMetaEvent:registerCallBack(self.onBlockBreakWithMeta)
    CEvents.PlayerPlaceBlockEvent:registerCallBack(self.onBlockPlace)
    CEvents.BlockTNTExplodeEvent:registerCallBack(self.onBlockTNTExplode)
    CEvents.BlockStationaryNotStationaryEvent:registerCallBack(self.onBlockStationaryNotStationary)
    CEvents.SchemeticPlaceBlockEvent:registerCallBack(self.onSchemeticPlaceBlock)
    CEvents.BlockCropsPlaceEvent:registerCallBack(self.onBlockCropsPlace)
    CEvents.BlockCropsUpdateEvent:registerCallBack(self.onBlockCropsUpdate)
    CEvents.PlaceDoorBlockEvent:registerCallBack(self.onPlaceDoorBlock)
    CEvents.BlockFLowingHighControlEvent:registerCallBack(self.onBlockFLowingHighControl)
    CEvents.BlockNeighborChangeEvent:registerCallBack(self.onBlockNeighborChange)
    CEvents.PlaceSlabBlockEvent:registerCallBack(self.onPlaceSlabBlock)
    CEvents.BlockCropsNotDropEvent:registerCallBack(self.onBlockCropsNotDrop)
    CEvents.PlaceFarmlandEvent:registerCallBack(self.onPlaceFarmland)
    CEvents.BlockCropsStealDeleteEvent:registerCallBack(self.onBlockCropsStealDelete)
    CEvents.PlaceSignPostEvent:registerCallBack(self.onPlaceSignPost)
    CEvents.CropsNotChangeNeighborEvent:registerCallBack(self.onCropsNotChangeNeighbor)
    CEvents.PlaceItemBlockEvent:registerCallBack(self.onPlaceItemBlock)
    CEvents.PlayerUseFlowerPotEvent:registerCallBack(self.onPlayerUseFlowerPot)
end

local function calcPistonMeta(yaw, pitch)
    if pitch >= -90 and pitch < -45 then
        return 0
    elseif pitch <= 90 and pitch > 45 then
        return 1
    end
    yaw = yaw % 360
    yaw = yaw < 0 and 360 + yaw or yaw
    if yaw > 315 or yaw <= 45 then
        return 2
    elseif yaw > 45 and yaw <= 135 then
        return 5
    elseif yaw > 135 and yaw <= 225 then
        return 3
    elseif yaw > 225 and yaw <= 315 then
        return 4
    end
end

local function calcBlockMeat(yaw, meta)
    yaw = yaw % 360
    yaw = yaw < 0 and 360 + yaw or yaw
    if yaw > 315 or yaw <= 45 then
        return meta
    elseif yaw > 45 and yaw <= 135 then
        return meta == 0 and 3 or 11
    elseif yaw > 135 and yaw <= 225 then
        return meta == 0 and 1 or 9
    elseif yaw > 225 and yaw <= 315 then
        return meta == 0 and 2 or 10
    end
end

local function doExplode(entityId, pos)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return
    end
    player.inTNTExplode = true
    for x = -5, 5 do
        for y = -5, 5 do
            for z = -5, 5 do
                if math.random() < 0.5 then
                    goto CONTINUE
                end
                local blockPos = VectorUtil.toBlockVector3(pos.x + x, pos.y + y, pos.z + z)
                if player.obInfo:isOneBlockPos(blockPos) then
                    goto CONTINUE
                end
                local blockId = EngineWorld:getBlockId(blockPos)
                if blockId > 0 then
                    local meta = EngineWorld:getBlockMeta(blockPos)
                    if BlockListener.onBlockBreakWithMeta(player.rakssid, blockId, meta, blockPos) then
                        EngineWorld:setBlockToAir(blockPos)
                    end
                end
                :: CONTINUE ::
            end
        end
    end
    player.inTNTExplode = nil
end

local lastIsBed = false
function BlockListener.onBlockBreakWithMeta(rakssid, blockId, blockMeta, blockPos)
    local integral = BlockConfig:getBlockIntegral(blockId, blockMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    -- in the main hall
    if player.isGenisland then
        HostApi.log("onBlockBreak info1 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        return false
    end

    if player.isLife == false then
        return false
    end

    if player.isNotInPartyCreateOrOver == false then
        return false
    end

    -- bed rock
    if blockId == BlockID.BEDROCK then
        HostApi.log("onBlockBreak info2 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        return false
    end

    -- masterManor is not exist
    local masterManor = GameMatch:getUserManorInfo(player.target_user_id)
    if masterManor == nil then
        HostApi.log("onBlockBreak info3 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        return false
    end

    -- master is not exist
    local master = PlayerManager:getPlayerByUserId(player.target_user_id)
    if master == nil then
        HostApi.log("onBlockBreak info4 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
        return false
    end

    -- do not have power
    if not masterManor:checkPower(player.userId, blockPos, "onBlockBreakWithMeta") then
        HostApi.log("onBlockBreak info5 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
        return false
    end

    -- block is loading
    if masterManor:isLoadingBlock() then
        HostApi.log("onBlockBreak info6 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        return false
    end

    -- subkey is not load
    if not player:checkChunkLoad() then
        HostApi.log("onBlockBreak info7 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        return false
    end

    if blockId == BlockID.CHEST then
        -- just master can break
        if not GameMatch:isMaster(player.userId) then
            MsgSender.sendCenterTipsToTarget(rakssid, 1, Messages:msgBlockPlaceTip())
            HostApi.log("onBlockBreak info8 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                    .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
            return false
        else
            local manorInfo = GameMatch:getUserManorInfo(player.userId)
            if not manorInfo then
                return false
            end
        end
    end

    if not masterManor:isIn(blockPos) then
        HostApi.log("onBlockBreak error : Weak net back home bug. userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
        return false
    end

    if master ~= player and master.obInfo:isOneBlockPos(blockPos) then
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
        return false
    end

    if (blockId == BlockID.FURNACE_IDLE or blockId == BlockID.FURNACE_BURNING) then
        -- just master can break
        if not GameMatch:isMaster(player.userId) then
            MsgSender.sendCenterTipsToTarget(rakssid, 1, Messages:msgBlockPlaceTip())
            HostApi.log("onBlockBreak info10 userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                    .. " blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
            return false
        end
    end
    if blockId == BlockID.SIGN_POST or blockId == BlockID.SIGN_WALL then
        if not DbUtil.CanSavePlayerData(master, DbUtil.TAG_SIGN) then
            return false
        end
        masterManor:recordSignPostText(blockPos, "", true)
        integral = BlockConfig:getBlockIntegral(blockId, 0)
    end

    if CropsConfig:checkCropsByBlockId(blockId) and blockMeta < 4 then
        ---果实必须成熟了才可以破坏
        return false
    end

    HostApi.log("onBlockBreak suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockId ..
            " blockMeta: " .. blockMeta .. " pos: " .. blockPos.x .. " " .. blockPos.y .. " " .. blockPos.z)
    player:logPlayerBuildGroup("onBlockBreak suc")

    master:addExp(-integral)
    if blockId == BlockID.BED then
        if lastIsBed then
            lastIsBed = false
        else
            lastIsBed = true
            BlockConfig:onBreakBlock(master, blockId, blockMeta, blockPos)
        end
    else
        BlockConfig:onBreakBlock(master, blockId, blockMeta, blockPos)
    end
    masterManor:recordBlock(blockPos, 0, 0)

    -- remove crops info
    if CropsConfig:checkCropsByBlockId(blockId) then
        masterManor:removeCropsInfo(blockPos)
    end

    -- remove chest info
    if blockId == BlockID.CHEST then
        player.chestController:tryDestroyContainer(blockPos)
    end

    -- remove furnace info
    if blockId == BlockID.FURNACE_IDLE or blockId == BlockID.FURNACE_BURNING then
        player.furnaceController:tryDestroyContainer(blockPos)
    end

    -- remove tree timer and tree info
    if blockId == BlockID.SAPLING then
        local vec3Hash = blockPos.x .. ":" .. blockPos.y .. ":" .. blockPos.z
        if GameMatch.treeTime[tostring(master.userId)] and GameMatch.treeTime[tostring(master.userId)][vec3Hash] then
            LuaTimer:cancel(GameMatch.treeTime[tostring(master.userId)][vec3Hash])
            GameMatch.treeTime[tostring(master.userId)][vec3Hash] = nil
            masterManor:removeTreeInfo(blockPos)
        end
    end

    -- remove dirt timer and dirt info
    if blockId == BlockID.DIRT then
        local vec3Hash = blockPos.x .. ":" .. blockPos.y .. ":" .. blockPos.z
        if GameMatch.dirtTime[tostring(master.userId)] and GameMatch.dirtTime[tostring(master.userId)][vec3Hash] then
            LuaTimer:cancel(GameMatch.dirtTime[tostring(master.userId)][vec3Hash])
            GameMatch.dirtTime[tostring(master.userId)][vec3Hash] = nil
            masterManor:removeDirtInfo(blockPos)
        end
    end

    -- home may change
    master:moveHome(blockPos, false)
    if not player.inTNTExplode then
        TaskUtil:breakBlock(player, blockId, blockMeta)
    end
    return true
end

function BlockListener.onBlockPlace(rakssid, itemId, meta, toPlacePos)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player or not player.isLife then
        return false
    end
    if player.isNotInPartyCreateOrOver == false then
        return false
    end
    -- in the main hall
    if player.isGenisland then
        MsgSender.sendCenterTipsToTarget(rakssid, 1, Messages:msgBlockPlaceTip())
        HostApi.log("onBlockPlace info1[isGenisland] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end
    -- masterManor is not exist
    local masterManor = GameMatch:getUserManorInfo(player.target_user_id)
    if masterManor == nil then
        HostApi.log("onBlockPlace info2[masterManor] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end
    -- master is not exist
    local master = PlayerManager:getPlayerByUserId(player.target_user_id)
    if master == nil then
        HostApi.log("onBlockPlace info3[master] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
        return false
    end
    -- do not have power
    if not masterManor:checkPower(player.userId, toPlacePos, "onBlockPlace") then
        HostApi.log("onBlockPlace info4[checkPower] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        MsgSender.sendCenterTipsToTarget(player.rakssid, 1, Messages:msgCannotOperatorVistor())
        return false
    end
    -- block is loading
    if masterManor:isLoadingBlock() then
        HostApi.log("onBlockPlace info5[isLoadingBlock] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end
    -- subkey is not load
    if not player:checkChunkLoad() then
        HostApi.log("onBlockPlace info6[checkChunkLoad] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end
    if not masterManor:isIn(toPlacePos) then
        HostApi.log("onBlockPlace error : Weak net back home bug. userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end
    local item = Item.getItemById(itemId)
    if not item then
        return false
    end
    local blockId = itemId < 1000 and itemId or itemId - 1000
    local name = item:getClassName()
    if name ~= "ItemSign"
            and name ~= "ItemBed"
            and name ~= "ItemDoor"
    then
        if not BlockManager.getBlockById(blockId) then
            if name == "ItemHoe" then
                return true
            end
            if CropsConfig:checkCropsByItemId(itemId) then
                HostApi.log("onBlockPlace info17[checkCropsByItemId] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                        .. " blockId: " .. itemId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
                TaskUtil:placeBlock(player, itemId, meta)
                return player:removeCurItem(1)
            end
            return false
        end
    end
    local integral = BlockConfig:getBlockIntegral(blockId, meta)
    local yaw = player:getYaw()
    if blockId == BlockID.TNT then
        if master ~= player then
            return false
        end
        if player:removeCurItem(1) then
            EngineWorld:setBlock(toPlacePos, blockId, 0, 0, false)
            EngineWorld:getWorld():fireTNT(toPlacePos, player:getEntityId())
        end
        return false
    end

    -- tool
    if GameConfig:isTool(blockId) then
        HostApi.log("onBlockPlace info8[isTool] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end

    if blockId == BlockID.CHEST then
        -- just master can place
        if not GameMatch:isMaster(player.userId) then
            HostApi.log("onBlockPlace info9[CHEST Not Master] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                    .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
            return false
        else
            if masterManor:checkBoxLimit() then
                HostApi.log("onBlockPlace info10[checkBoxLimit] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                        .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
                MsgSender.sendCenterTipsToTarget(rakssid, 1, Messages:msgBoxLimit())
                return false
            end

            if not masterManor:canPlaceChest(toPlacePos) then
                HostApi.log("onBlockPlace info12[checkActorExistByPos] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                        .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
                return false
            end
        end
    end

    if (blockId == BlockID.FURNACE_IDLE or blockId == BlockID.FURNACE_BURNING) then
        -- just master can place
        if not GameMatch:isMaster(player.userId) then
            HostApi.log("onBlockPlace info12[FURNACE Not Master] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                    .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
            return false
        else
            if masterManor:checkFurnaceLimit() then
                HostApi.log("onBlockPlace info13[checkFurnaceLimit] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                        .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
                MsgSender.sendCenterTipsToTarget(rakssid, 1, Messages:msgFurnaceLimit())
                return false
            end

            if not masterManor:canPlaceChest(toPlacePos) then
                HostApi.log("onBlockPlace info15[CanSavePlayerData TAG_FURNACE] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                        .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
                return false
            end
        end
    end

    -- area
    local isInArea = GameConfig:checkBlockInArea(toPlacePos, master, masterManor)
    if isInArea == false then
        player:checkExtendAreaTip()
        HostApi.log("onBlockPlace info15[isInArea] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return false
    end

    -- door
    if GameConfig:isDoorItemBlock(blockId) then
        HostApi.log("onBlockPlace info16[isDoorItemBlock] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    -- sign
    if blockId == ItemID.SIGN then
        HostApi.log("onBlockPlace info18[ItemID.SIGN] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    --custom item
    if name == "ItemCustom" then
        HostApi.log("onBlockPlace info19[isCustomItem] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        return true
    end

    --half slab block less than 1000
    if GameConfig:isCommonHalfSlab(blockId) then
        HostApi.log("onBlockPlace isCommonHalfSlab " .. blockId)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    --half slab block more than 1000
    if GameConfig:isMoreThan1000HalfSlabItem(blockId) then
        HostApi.log("onBlockPlace isMoreThan1000HalfSlabItem " .. blockId)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    if blockId == ItemID.BED then
        HostApi.log("onBlockPlace info18[ItemID.BED] userId: " .. tostring(player.userId) .. " masterId: " .. tostring(player.target_user_id)
                .. " blockId: " .. blockId .. " blockMeta: " .. meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        TaskUtil:placeBlock(player, itemId, meta)
        return player:removeCurItem(1)
    end

    if blockId == BlockID.TRAPDOOR and (meta == 0 or meta == 8) then
        meta = calcBlockMeat(yaw, meta)
    end

    -- BoneMeal for the moment blockId is 1500
    if blockId == BlockID.BONEMEAL then
        if player:removeCurItem(1) then

            local item = LotteryUtil:get(BoneMealConfig.ORDINARY_WEIGHTS_GROUP)
            local blockNewId = BoneMealConfig:getFlowerBlockIDById(item)
            local blockNewMeta = BoneMealConfig:getFlowerBlockMetaById(item)
            LuaTimer:scheduleTimer(function()
                EngineWorld:setBlock(toPlacePos, blockNewId, blockNewMeta)
            end, 1000, 1)
            masterManor:recordBlock(toPlacePos, blockNewId, blockNewMeta)

            HostApi.log("onBlockPlace suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockNewId
                    .. " blockMeta: " .. blockNewMeta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
            player:logPlayerBuildGroup("onBlockPlace suc BlockID.BONEMEAL")
            TaskUtil:placeBlock(player, itemId, meta)
        end

        return false
    end

    -- blockId more than 1000 handle
    if GameConfig:isMoreThan1000Block(blockId) then
        if player:removeCurItem(1) then

            local new_meta_1000 = meta
            if GameConfig:isStairsBlock(blockId) then
                new_meta_1000 = GameConfig:metaHandleStairs(yaw, new_meta_1000)
            end

            EngineWorld:setBlock(toPlacePos, blockId, new_meta_1000, 3)

            masterManor:recordBlock(toPlacePos, blockId, new_meta_1000)
            local exp = BlockConfig:getBlockIntegral(blockId, meta)
            master:addExp(exp)
            HostApi.log("onBlockPlace suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockId
                    .. " blockMeta: " .. new_meta_1000 .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
            player:logPlayerBuildGroup("onBlockPlace suc isMoreThan1000Block")
            TaskUtil:placeBlock(player, itemId, meta)
        end

        return false
    end

    if player:removeCurItem(1) then
        -- sapling handle
        if blockId == BlockID.SAPLING then

            local time = TreeSectionConfig:getTimeByBlockMeta(meta)
            if time then
                local vec3Hash = toPlacePos.x .. ":" .. toPlacePos.y .. ":" .. toPlacePos.z
                if GameMatch.treeTime[tostring(master.userId)] == nil then
                    GameMatch.treeTime[tostring(master.userId)] = {}
                end
                if GameMatch.treeTime[tostring(master.userId)][vec3Hash] == nil then
                    GameMatch.treeTime[tostring(master.userId)][vec3Hash] = LuaTimer:scheduleTimer(function(rakssid)
                        local master = PlayerManager:getPlayerByRakssid(rakssid)
                        if master then
                            TreeSectionConfig:theSchematicReplaceBlock(master.rakssid, meta, toPlacePos)
                            LuaTimer:cancel(GameMatch.treeTime[tostring(master.userId)][vec3Hash])
                            GameMatch.treeTime[tostring(master.userId)][vec3Hash] = nil

                            local masterManor = GameMatch:getUserManorInfo(master.userId)
                            if masterManor then
                                masterManor:removeTreeInfo(toPlacePos)
                            end
                        end
                    end, time * 1000, 1, master.rakssid)

                    masterManor:insertTreeInfo(toPlacePos, meta)
                end
            end
        end

        -- dirt handle
        if blockId == BlockID.DIRT then
            local time = GameConfig.dirtTime
            local vec3Hash = toPlacePos.x .. ":" .. toPlacePos.y .. ":" .. toPlacePos.z
            if GameMatch.dirtTime[tostring(master.userId)] == nil then
                GameMatch.dirtTime[tostring(master.userId)] = {}
            end
            if GameMatch.dirtTime[tostring(master.userId)][vec3Hash] == nil then
                GameMatch.dirtTime[tostring(master.userId)][vec3Hash] = LuaTimer:scheduleTimer(function(rakssid)
                    local master = PlayerManager:getPlayerByRakssid(rakssid)
                    if master then

                        local masterManor = GameMatch:getUserManorInfo(master.userId)
                        if masterManor then
                            EngineWorld:setBlock(toPlacePos, BlockID.GRASS)
                            masterManor:recordBlock(toPlacePos, BlockID.GRASS, 0)
                            masterManor:removeDirtInfo(toPlacePos)
                        end

                        if GameMatch.dirtTime[tostring(master.userId)][vec3Hash] then
                            LuaTimer:cancel(GameMatch.dirtTime[tostring(master.userId)][vec3Hash])
                            GameMatch.dirtTime[tostring(master.userId)][vec3Hash] = nil
                        end
                    end
                end, time * 1000, 1, master.rakssid)

                masterManor:insertDirtInfo(toPlacePos, blockId)
            end
        end

        -- block meta handle
        local new_meta = meta

        if blockId == BlockID.FURNACE_IDLE or blockId == BlockID.FURNACE_BURNING then
            new_meta = GameConfig:metaHandleFurnace(yaw, new_meta)
            player.furnaceController:tryCreateContainer(toPlacePos)
        end

        if blockId == BlockID.FENCE_GATE
                or blockId == BlockID.WHITE_FENCE_GATE then
            new_meta = GameConfig:metaHandleGate(yaw, new_meta)
        end

        if GameConfig:isStairsBlock(blockId) then
            new_meta = GameConfig:metaHandleStairs(yaw, new_meta)
        end

        if blockId == BlockID.CHEST then
            -- just master can place
            --masterManor:recordChest(toPlacePos)
            player.chestController:tryCreateContainer(toPlacePos)
        end

        if blockId == BlockID.PISTON_BASE or blockId == BlockID.PISTON_STICKY_BASE then
            new_meta = calcPistonMeta(player:getYaw(), player:getPitch())
        end

        HostApi.log("onBlockPlace suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockId
                .. " blockMeta: " .. new_meta .. " pos: " .. toPlacePos.x .. " " .. toPlacePos.y .. " " .. toPlacePos.z)
        player:logPlayerBuildGroup("onBlockPlace suc")

        EngineWorld:setBlock(toPlacePos, blockId, new_meta, 3)

        masterManor:recordBlock(toPlacePos, blockId, new_meta)
        master:addExp(integral)

        master:moveHome(toPlacePos, true)
        TaskUtil:placeBlock(player, itemId, new_meta)
    end
    return false
end

function BlockListener.onBlockCropsPlace(userId, blockId, vec3, residueHarvestNum)

    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    local masterManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if masterManorInfo == nil then
        return false
    end

    local master = PlayerManager:getPlayerByUserId(player.target_user_id)
    if master == nil then
        return false
    end

    -- do not have power
    if not masterManorInfo:checkPower(player.userId, vec3, "onBlockCropsPlace") then
        return false
    end

    local lastUpdateTime = os.time()

    if masterManorInfo.release_status == Define.manorRelese.Not then
        masterManorInfo:insertCropsInfo(vec3, blockId, 1, lastUpdateTime)
        masterManorInfo:recordBlock(vec3, blockId, 1)

        HostApi.log("onBlockCropsPlace suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockId
                .. " blockMeta: " .. 1 .. " pos: " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
        player:logPlayerBuildGroup("onBlockCropsPlace")
    end

end

function BlockListener.onBlockCropsUpdate(userId, blockId, curState, curStateTime, fruitNum, vec3, residueHarvestNum)

    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end

    local masterManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if masterManorInfo == nil then
        return false
    end

    local master = PlayerManager:getPlayerByUserId(player.target_user_id)
    if master == nil then
        return false
    end

    -- do not have power
    if not masterManorInfo:checkPower(player.userId, vec3, "onBlockCropsUpdate") then
        return false
    end

    local lastUpdateTime = os.time()

    if masterManorInfo.release_status == Define.manorRelese.Not then
        masterManorInfo:insertCropsInfo(vec3, blockId, curState, lastUpdateTime)
        masterManorInfo:recordBlock(vec3, blockId, curState)

        HostApi.log("onBlockCropsUpdate suc userId: " .. tostring(player.userId) .. " target_user_id: " .. tostring(player.target_user_id) .. " blockId: " .. blockId
                .. " blockMeta: " .. curState .. " pos: " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
        player:logPlayerBuildGroup("onBlockCropsUpdate")
    end

end

function BlockListener.onBlockTNTExplode(entityId, pos, attr)
    attr.isCanHurt = false
    attr.isBreakBlock = false
    doExplode(entityId, pos)
    return false
end

function BlockListener.onBlockStationaryNotStationary(blockId)
    return false
end

function BlockListener.onSchemeticPlaceBlock(rakssid, vec3, blockId, meta, placeBlockParam)
    -- clear block
    if placeBlockParam == -1 then
        return true
    end

    -- init schmetic
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        -- HostApi.log("onSchemeticPlaceBlock " .. blockId .. " " .. meta .. " " .. placeBlockParam)
        if (blockId == BlockID.WATER_MOVING or blockId == BlockID.WATER_STILL) and meta == 0 then
            local targetManorInfo = GameMatch:getUserManorInfoByIndex(placeBlockParam)
            if targetManorInfo ~= nil then
                targetManorInfo:recordWaterSource(vec3)
            end
        end
        return true
    else
        if player.isNotInPartyCreateOrOver == false then
            return true
        end

        local masterManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
        if masterManorInfo then
            masterManorInfo:recordBlock(vec3, blockId, meta)
        end
    end

    return true
end

function BlockListener.onPlaceDoorBlock(userId, blockId, blockMeta, vec3)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end

    if player.isNotInPartyCreateOrOver == false then
        return
    end

    local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if targetManorInfo then
        -- do not have power
        if not targetManorInfo:checkPower(player.userId, vec3, "onPlaceDoorBlock") then
            return
        end
        targetManorInfo:recordBlock(vec3, blockId, blockMeta)
    end
end

function BlockListener.onBlockFLowingHighControl(blockId, pos, posDown)

    for k, v in pairs(GameMatch.userManorInfo) do
        if v:isIn(pos) then
            if v:checkFlowHigh(pos) then
                return true
            end
        end
    end

    return false
end

function BlockListener.onBlockNeighborChange(vec3, id, meta, m_blockID)
    local master = GameMatch:getMasterByPos(VectorUtil.toVector3(vec3))
    if master then
        local masterManorInfo = GameMatch:getUserManorInfo(master.userId)

        if masterManorInfo.release_status ~= Define.manorRelese.Not then
            HostApi.log("onBlockNeighborChange masterManorInfo status may be error" .. masterManorInfo.release_status
                    .. " userId: " .. tostring(master.userId) .. " masterManorInfo status: " .. masterManorInfo.release_status .. " info: "
                    .. vec3.x .. " " .. vec3.y .. " " .. vec3.z .. " " .. id .. " " .. meta .. " " .. m_blockID)
        end

        if masterManorInfo and masterManorInfo.loading == false and masterManorInfo.release_status == Define.manorRelese.Not then
            HostApi.log("onBlockNeighborChange userId: " .. tostring(master.userId) .. " info: "
                    .. vec3.x .. " " .. vec3.y .. " " .. vec3.z .. " " .. id .. " " .. meta .. " " .. m_blockID)
            masterManorInfo:recordBlock(vec3, 0, 0)

            local integral = BlockConfig:getBlockIntegral(id, meta)
            -- remove crops info
            if CropsConfig:checkCropsByBlockId(id) then
                masterManorInfo:removeCropsInfo(vec3)
            end

            -- remove signpost
            if id == BlockID.SIGN_POST or id == BlockID.SIGN_WALL then
                masterManorInfo:recordSignPostText(vec3, "", true)
                HostApi.log("onBlockNeighborChange ---------- recordSignPostText")
                integral = BlockConfig:getBlockIntegral(id, 0)
            end
            -- remove tree timer and tree info
            if id == BlockID.SAPLING then
                local vec3Hash = vec3.x .. ":" .. vec3.y .. ":" .. vec3.z
                if GameMatch.treeTime[tostring(master.userId)] and GameMatch.treeTime[tostring(master.userId)][vec3Hash] then
                    LuaTimer:cancel(GameMatch.treeTime[tostring(master.userId)][vec3Hash])
                    GameMatch.treeTime[tostring(master.userId)][vec3Hash] = nil
                    masterManorInfo:removeTreeInfo(vec3)
                end
            end
            master:addExp(-integral)
        end
    end
end

function BlockListener.onPlaceSlabBlock(userId, blockId, blockMeta, vec3, halfBlockId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end

    if player.isNotInPartyCreateOrOver == false then
        return
    end

    local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if targetManorInfo then
        -- do not have power
        if not targetManorInfo:checkPower(player.userId, vec3, "onPlaceSlabBlock") then
            return
        end

        --targetManorInfo:recordBlock(vec3, blockId, blockMeta)
        --targetManorInfo:recordBlock(VectorUtil.newVector3i(vec3.x, vec3.y + 1, vec3.z), 0, 0)

        if GameConfig:isCommonHalfSlab(halfBlockId) or GameConfig:isMoreThan1000HalfSlabBlock(halfBlockId) then
            HostApi.log("onPlaceSlabBlock blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " halfBlockId: " .. halfBlockId
                    .. " pos: " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)

            -- add single half slab exp
            local expSlab = BlockConfig:getBlockIntegral(halfBlockId, blockMeta)
            local master = PlayerManager:getPlayerByUserId(player.target_user_id)
            if master then
                master:addExp(expSlab)
                targetManorInfo:recordBlock(vec3, blockId, blockMeta)
            end
        end
    end
end

function BlockListener.onPlaceItemBlock(userId, blockId, blockMeta, vec3)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end

    if player.isNotInPartyCreateOrOver == false then
        return
    end

    local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if targetManorInfo then
        -- do not have power
        if not targetManorInfo:checkPower(player.userId, vec3, "onPlaceItemBlock") then
            return
        end

        if GameConfig:isCommonHalfSlab(blockId) or GameConfig:isMoreThan1000HalfSlabBlock(blockId) then

            HostApi.log("onPlaceItemBlock blockId: " .. blockId .. " blockMeta: " .. blockMeta .. " pos: " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)

            local expSlab = BlockConfig:getBlockIntegral(blockId, blockMeta)
            local master = PlayerManager:getPlayerByUserId(player.target_user_id)
            if master then
                master:addExp(expSlab)
                targetManorInfo:recordBlock(vec3, blockId, blockMeta)
            end
        end
    end
end

function BlockListener.onPlayerUseFlowerPot(entityId, blockPos)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return
    end

    if player.isNotInPartyCreateOrOver == false then
        return
    end

    local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if targetManorInfo then
        -- do not have power
        if not targetManorInfo:checkPower(player.userId, blockPos, "onPlaceItemBlock") then
            return
        end
        targetManorInfo:recordBlock(blockPos, EngineWorld:getBlockId(blockPos), EngineWorld:getBlockMeta(blockPos))
    end
end

function BlockListener.onBlockCropsNotDrop(rakssid, blockId, meta, vec3, owner_user_id)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end

    local owner = PlayerManager:getPlayerByUserId(owner_user_id)
    if owner == nil then
        return true
    end

    local master = PlayerManager:getPlayerByUserId(player.target_user_id)
    if master == nil then
        return true
    end

    if tostring(owner.userId) ~= tostring(master.userId) then
        return true
    end

    local ownerManorInfo = GameMatch:getUserManorInfo(owner.userId)
    if ownerManorInfo == nil then
        return true
    end

    if not ownerManorInfo:checkPower(player.userId, vec3, "onBlockCropsNotDrop") then
        return true
    end
    HostApi.log("onBlockCropsNotDrop blockId: " .. blockId .. " " .. tostring(player.userId) .. " " .. tostring(owner_user_id))
    player:logPlayerBuildGroup("onBlockCropsNotDrop")

    return false
end

function BlockListener.onPlaceFarmland(userId, blockId, blockMeta, vec3)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end

    if player.isNotInPartyCreateOrOver == false then
        return
    end

    local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if targetManorInfo then
        -- do not have power
        if not targetManorInfo:checkPower(player.userId, vec3, "onPlaceFarmland") then
            return
        end
        targetManorInfo:recordBlock(vec3, blockId, blockMeta)
    end
end

function BlockListener.onBlockCropsStealDelete(userId, blockId, productionId, quantity, vec3, residueHarvestNum)
    HostApi.log("onBlockCropsSteal " .. tostring(userId) .. blockId)
    return false
end

function BlockListener.onPlaceSignPost(userId, blockId, blockMeta, vec3)
    -- 这里仅判断留言板放置成功后的操作
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end

    local master = PlayerManager:getPlayerByUserId(player.target_user_id)
    if master == nil then
        return
    end

    local targetManorInfo = GameMatch:getUserManorInfo(player.target_user_id)
    if not targetManorInfo then
        return
    end

    if not targetManorInfo:checkPower(player.userId, vec3, "onPlaceSignPost") then
        return
    end

    targetManorInfo:recordBlock(vec3, blockId, blockMeta)
    local data = {
        hashVec3i = vec3.x .. ":" .. vec3.y .. ":" .. vec3.z,
        oldText = ""
    }
    GamePacketSender:sendSignPostData(player.rakssid, json.encode(data))
    HostApi.log("onPlaceSignPost userId: " .. tostring(player.userId) .. " targetId: " .. tostring(player.target_user_id)
            .. " " .. blockId .. " " .. blockMeta .. " " .. vec3.x .. " " .. vec3.y .. " " .. vec3.z)
    player:logPlayerBuildGroup("onPlaceSignPost")

    local exp = BlockConfig:getBlockIntegral(blockId, 0)
    master:addExp(exp)
end

function BlockListener.onCropsNotChangeNeighbor(rakssid, blockId, pos)
    return false
end

return BlockListener
--endregion
