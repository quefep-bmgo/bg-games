GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
end

function GameListener.onGameReady()
    GameConfig:init()
    GUIManager:registerQueue(function()
        require "ui.GUIParty"
        require "ui.GUICreateParty"
        require "ui.GUIBulletin"
    end)

    GUIManager:registerQueue(function()
        require "ui.GUIFriend"
        require "ui.GUIFriendItem"
        require "ui.GUIFriendApplyItem"
        require "ui.GUINearFriendItem"
        require "ui.GUIFriendBuiltItem"
        require "ui.GUIFriendBuildApplyItem"
        require "ui.GUIFriendInvitation"
        require "ui.GUIInvitationFriendItem"
    end)

    GUIManager:registerQueue(function()
        require "ui.GUIApplyParty"
        require "ui.GUISign"
    end)

    GUIManager:registerQueue(function()
        require "ui.GUIRank"
        require "ui.GUIRankItem"
        require "ui.GUIRankTip"
    end)

    GUIManager:registerQueue(function()
        require "ui.GUIPlayerOperation"
        require "ui.GUICenterTips"
        require "ui.GUISkyBlockItemDetail"
        require "ui.GUIBulletinDetailItem"
        require "ui.GUIBulletinTabItem"
    end)

    GUIManager:registerQueue(function()
        require "ui.GUISkyBlockMoneyDetail"
        require "ui.GUITipDialog"
        if GUISumRechargeLayout ~= nil then
            GUISumRechargeLayout:setRewardWidth(77)
        end
    end)

    if GameConfig.lightConfig then
        local threshold = GameConfig.lightConfig[1] or 0
        local saturation = GameConfig.lightConfig[2] or 0.6
        local intensity = GameConfig.lightConfig[3] or 3
        local blurMultiplier = GameConfig.bloomBlurMultiplier or 1
        local blurDeviation = GameConfig.bloomBlurDeviation or 7
        local blockLightEnhancement = GameConfig.blockLightEnhancement or 0
        HostApi.log("bloom threshold " .. threshold)
        HostApi.log("bloom saturation " .. saturation)
        HostApi.log("bloom intensity " .. intensity)
        HostApi.log("bloom blur multiplier " .. blurMultiplier)
        HostApi.log("bloom blur deviation " .. blurDeviation)
        HostApi.log("block light enhancement " .. blockLightEnhancement)
        local bm = Blockman.Instance()
        bm:setBloomThreshold(threshold)
        bm:setBloomSaturation(saturation)
        bm:setBloomIntensity(intensity)
        bm:setBloomBlurMultiplier(blurMultiplier)
        bm:setBloomBlurDeviation(blurDeviation)
        bm:setBlockLightEnhancement(blockLightEnhancement)
    end

end

return GameListener