require "mine_hole.messages.Messages"
require "mine_hole.data.GamePlayer"

PlayerListener = {}

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)
end

function PlayerListener.onPlayerLogin(clientPeer)
    return GameOverCode.GameOver
end

function PlayerListener.onPlayerReady(player)
    HostApi.sendPlaySound(player.rakssid, 10042)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))
end

function PlayerListener.onPlayerMove(movePlayer)
    return PlayerManager:getPlayerByPlayerMP(movePlayer) ~= nil
end

return PlayerListener
--endregion
