local function hideEngineWindow(name)
    local window = GUIManager:getWindowByName(name)
    if not window then
        return
    end
    window:SetXPosition({ 0, 6000 })
    window:SetVisible(false)
end

GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
end

function GameListener.onGameReady()
    GameConfig:init()
    require "ui.GUIMain"
    require "ui.GUISkyBlockMiningAreaItemDetail"
    require "ui.GUISkyBlockMiningAreaSellPreciousTip"
    require "ui.GUISkyBlockMiningAreaItemDetail"
    require "ui.GUIChristmas"
    require "ui.GUIToolBar"


    require "ui.GUISkyBlockMiningAreaMoneyDetail"
    require "ui.GUISkyBlockMiningAreaBuyMoneyTips"
    require "ui.GUITipDialog"
    
    if GUISumRechargeLayout ~= nil then
        GUISumRechargeLayout:setRewardWidth(77)
    end
    ClientHelper.putStringPrefs("RechargeGameType", "g1048")
    hideEngineWindow("Main-Watch-Battle-Text")
    hideEngineWindow("Main-Player-Exp")
    hideEngineWindow("PlayerInfo-Armor")

    if isArraignmentApp then
        hideEngineWindow("SkyBlockMiningAreaMoneyDeatil-Party-Btn")
        hideEngineWindow("SkyBlockMiningAreaLuaToolBar-Rich-Btn")
        hideEngineWindow("SkyBlockMain-Option-Btn")
        hideEngineWindow("SkyBlockMain-Privilege-Btn")
        hideEngineWindow("SkyBlockMain-Resource-Appshop-Button")
        hideEngineWindow("SkyBlockMiningAreaLuaToolBar-Christmas-Btn")
        hideEngineWindow("ToolBar-Currency-Money-Add")
    end
end

return GameListener
