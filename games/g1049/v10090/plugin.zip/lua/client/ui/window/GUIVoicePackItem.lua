---@class GUIVoicePackItemWindow : IGUIWindow
local GUIVoicePackItemWindow = class("GUIVoicePackItemWindow", IGUIWindow)

---@private
function GUIVoicePackItemWindow:ctor(...)
	self.super.ctor(self, "VoicePackItem.json", ...)
end

---@private
function GUIVoicePackItemWindow:onLoad()
	self.stName = self:getChildWindowByName("VoicePackItem-Name", GUIType.StaticText)
	self.btnPlay = self:getChildWindowByName("VoicePackItem-Play", GUIType.Button)
	self:initView()
	self:initEvent()
end

---@private
function GUIVoicePackItemWindow:initView()

end

---@private
function GUIVoicePackItemWindow:initEvent()
	self.btnPlay:registerEvent(GUIEvent.ButtonClick, function()
		Plugins.CallTargetPluginFunc("voice_pack", "playVoicePack", PlayerManager:getClientPlayer(), self.data.id)
	end)
end

---@param data table
function GUIVoicePackItemWindow:onDataChanged(data)
	self.data = data
	self.stName:SetText(Lang:getString(self.data.name))
end

return GUIVoicePackItemWindow
