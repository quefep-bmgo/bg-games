---@class IllegalGunConfig
local IllegalGunConfig = T(Global, "CannonConfig")
local Items = {}

function IllegalGunConfig:init()
    local config = FileUtil.getConfigFromCsv("setting/IllegalGunItem.csv", 3, true)
    for _, item in pairs(config) do
        Items[item.ItemId] = true
    end
end

function IllegalGunConfig:checkItemIllegal(itemId)
    return Items[tostring(itemId)]
end

IllegalGunConfig:init()

return IllegalGunConfig

