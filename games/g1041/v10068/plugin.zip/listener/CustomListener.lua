
require "manager.ConsumeDiamondsManager"
CustomListener = {}

function CustomListener:init()
    ConsumeDiamondsEvent.registerCallBack(self.onConsumeDiamonds)
    WatchAdvertFinishedEvent.registerCallBack(self.onWatchAdvertFinished)
end

function CustomListener.onConsumeDiamonds(rakssid, isSuccess, message, extra, payId)
    if isSuccess == false then
        return ConsumeDiamondsManager.OnConsumeFail(rakssid, message, extra, payId)
    end

    return ConsumeDiamondsManager.OnConsumeSuccess(rakssid, message, extra, payId)
end

function CustomListener.onWatchAdvertFinished(rakssid, type, params, code)
    if code ~= 1 then
        return
    end

    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return
    end

    if type == 104101 then
        local operateType = DataBuilder.new():fromData(params):getNumberParam("operateType")
        local param1 = DataBuilder.new():fromData(params):getNumberParam("param1")
        local param2 = DataBuilder.new():fromData(params):getNumberParam("param2")
        VideoAdHelper:doGetMoneyAdReward(player, operateType, param1, param2)
        return
    end

    if type == 104102 then
        VideoAdHelper:doGetEggTicketAdReward(player, params)
        return
    end

    if type == 104103 then
        VideoAdHelper:doGetChestCDAdReward(player, params)
        return
    end

    if type == 104104 then
        VideoAdHelper:doGetVipChestAdReward(player)
        return
    end

    if type == 104105 then
        VideoAdHelper:doGetFeedAdReward(player, params)
        return
    end
end

return CustomListener
