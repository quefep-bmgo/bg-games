--GameConfig.lua
require "config.MerchantConfig"
require "config.TeamConfig"
require "config.MoneyConfig"
require "config.BridgeConfig"
require "config.TeleportConfig"
require "config.ShopConfig"
require "config.RespawnConfig"
require "config.BlockConfig"
require "config.SkillConfig"
require "config.KeepItemConfig"
require "config.AppPropConfig"
require "config.CenterMerchantConfig"
---@type TeamConfig
local TeamConfig = T(Global, "TeamConfig")
---@type MerchantConfig
local MerchantConfig = T(Global, "MerchantConfig")
---@type MoneyConfig
local MoneyConfig = T(Global, "MoneyConfig")
---@type BlockConfig
local BlockConfig = T(Global, "BlockConfig")
---@type TeleportConfig
local TeleportConfig = T(Global, "TeleportConfig")
---@type ShopConfig
local ShopConfig = T(Global, "ShopConfig")
---@type CenterMerchantConfig
local CenterMerchantConfig = T(Global, "CenterMerchantConfig")

GameConfig = {}

GameConfig.waitingPlayerTime = 0
GameConfig.prepareTime = 0
GameConfig.gameTime = 0
GameConfig.gameOverTime = 0

GameConfig.maxLevel = 0
GameConfig.updateSuccess = ""
GameConfig.updateFailed = ""
GameConfig.updateSound = 0
GameConfig.standUpTime = 0

function GameConfig:init(config)

    self.waitingPlayerTime = tonumber(config.waitingPlayerTime)
    self.prepareTime = tonumber(config.prepareTime)
    self.gameTime = tonumber(config.gameTime)
    self.gameOverTime = tonumber(config.gameOverTime)
    self.maxLevel = tonumber(config.maxLevel)
    self.updateSuccess = tostring(config.updateSuccess)
    self.updateFailed = tostring(config.updateFailed)
    self.updateSound = tonumber(config.updateSound)
    self.standTime = tonumber(config.standTime)
    self.enchantmentEquip = config.enchantmentEquip
    self.enchantmentEffect = config.enchantmentEffect
    self.enchantmentConsume = tonumber(config.enchantmentConsume)
    self.enchantmentOpenTime = tonumber(config.enchantmentOpenTime)
    self.enchantmentQuickMoney = tonumber(config.enchantmentQuickMoney)
    self.newBgm = config.newBgm or false
    self.outOfAreaHurt = tonumber(config.outOfAreaHurt) or 5
    if config.areaStartPos and config.areaEndPos then
        self.MovementArea = IArea.new()
        local startPos = VectorUtil.newVector3(config.areaStartPos[1], config.areaStartPos[2], config.areaStartPos[3])
        local endPos = VectorUtil.newVector3(config.areaEndPos[1], config.areaEndPos[2], config.areaEndPos[3])
        self.MovementArea:initByPos(startPos, endPos)
    end

    TeamConfig:initTeams()
    MerchantConfig:initGoods()
    MerchantConfig:initShopTruck()
    MoneyConfig:initMoney()
    MoneyConfig:initCoinMapping(config.coinMapping)
    BridgeConfig:init(config.bridge)
    TeleportConfig:init(FileUtil.getConfigFromCsv("setting/TeleportConfig.csv", 2, true))
    ShopConfig:init()
    RespawnConfig:init(config.respawn)
    BlockConfig:initBlock(FileUtil.getConfigFromCsv("setting/BlockSetting.csv", 2, true))
    CenterMerchantConfig:initStores()

    SkillConfig:init(FileUtil.getConfigFromCsv("SkillConfig.csv"))
    KeepItemConfig:init(FileUtil.getConfigFromCsv("KeepItem.csv"))
    AppPropConfig:init(FileUtil.getConfigFromCsv("AppProps.csv"))
    EnchantMentNpcConfig:init(FileUtil.getConfigFromCsv("EnchantmentNpc.csv"))

end

function GameConfig:canEnchantment(id)
    for _, item in pairs(self.enchantmentEquip) do
        if tonumber(item) == id then
            return true
        end
    end
    return false
end

function GameConfig:getEnchantmentEffect(index)
    for idx, item in pairs(self.enchantmentEffect) do
        if index == idx then
            return item.id, item.level
        end
    end
    return 0, 0
end

function GameConfig:getEnchantmentEffectDes(index)
    for idx, item in pairs(self.enchantmentEffect) do
        if index == idx then
            return item.title, item.des
        end
    end
    return "", ""
end

return GameConfig