require "data.CenterMerchant"
---@class CenterMerchantConfig
local CenterMerchantConfig = T(Global, "CenterMerchantConfig")
local CenterMerchantNpcs = {}
local Goods = {}
local Index = 30

function CenterMerchantConfig:initStores()
    local goods = FileUtil.getConfigFromCsv("setting/CenterMerchantGoods.csv", 2, true)
    local configs = FileUtil.getConfigFromCsv("setting/CenterMerchant.csv", 2, true)
    for _, good in pairs(goods) do
        local data = {
            id = tonumber(good.id),
            type = tonumber(good.type),
            itemId = tonumber(good.itemId),
            itemMeta = tonumber(good.itemMeta),
            itemNum = tonumber(good.itemNum),
            coinId = tonumber(good.coinId),
            price = tonumber(good.price),
            desc = good.desc or nil,
            notify = tonumber(good.notify) or 0,
            image = good.image or nil,
        }
        Goods[tostring(data.id)] = data
    end

    local beginIndex = 30
    for _, config in pairs(configs) do
        local data = {}
        local pos = StringUtil.split(config.initPos, ",")
        data.id = tonumber(config.id)
        data.initPos = VectorUtil.newVector3(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]))
        data.storeYaw = tonumber(pos[4])
        data.storeName = config.name
        data.effect = config.effect or "#"
        CenterMerchantNpcs[data.id] = CenterMerchant.new(beginIndex, data.initPos, data.storeYaw, data.storeName, data.effect)
        local ids = StringUtil.split(config.goods, "#")
        for i, id in pairs(ids) do
            local item = Goods[tostring(id)]
            if item then
                MerchantUtil:addCommodity(beginIndex, item.type, CenterMerchantConfig:newCommodity(item))
                Index = Index + 1
            end
        end
        beginIndex = beginIndex + 1
    end
end

function CenterMerchantConfig:newCommodity(item)
    local commodity = Commodity.new()
    commodity.itemId = item.itemId
    commodity.itemMeta = item.itemMeta
    commodity.itemNum = item.itemNum
    commodity.coinId = item.coinId
    commodity.price = item.price
    commodity.desc = item.desc
    commodity.notify = item.notify
    commodity.image = item.image or ""
    return commodity
end

function CenterMerchantConfig:prepareStore(rakssid)
    for i, v in pairs(CenterMerchantNpcs) do
        v:syncPlayer(rakssid)
    end
end

function CenterMerchantConfig:addEffect()
    for i, v in pairs(CenterMerchantNpcs) do
        if v.effect ~= "#" then
            EngineWorld:addSimpleEffect(v.effect, v.pos, v.yaw)
        end
    end
end

return CenterMerchantConfig