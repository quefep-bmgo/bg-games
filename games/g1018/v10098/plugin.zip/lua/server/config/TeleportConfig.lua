---
--- Created by Jimmy.
--- DateTime: 2018/2/27 0027 11:10
---
---@class TeleportConfig
local TeleportConfig = T(Global, "TeleportConfig")
local Settings = {}

function TeleportConfig:init(configs)
    for _, config in pairs(configs) do
        local teamId = tonumber(config.teamId)
        local id = tonumber(config.id)
        local pos = StringUtil.split(config.pos, ",")
        local _pos = VectorUtil.newVector3(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]))
        if not Settings[teamId] then
            Settings[teamId] = {}
        end
        if not Settings[teamId][id] then
            Settings[teamId][id] = {
                pos = {}
            }
        end
        table.insert(Settings[teamId][id].pos, _pos)
    end
end

function TeleportConfig:getRandomPosition(teamId, tpItemId)
    if Settings[teamId][tpItemId] ~= nil then
        if #Settings[teamId][tpItemId].pos > 0 then
            math.randomseed(os.clock()*1000000)
            local ramdomNum = math.random(1, #Settings[teamId][tpItemId].pos)
            for i, v in pairs(Settings[teamId][tpItemId].pos) do
                if i == ramdomNum then
                    return v
                end
            end
        end
    end
    return nil
end

return TeleportConfig

