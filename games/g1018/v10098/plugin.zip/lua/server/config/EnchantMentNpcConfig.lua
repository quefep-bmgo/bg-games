EnchantMentNpcConfig = {}
EnchantMentNpcConfig.npc = {}

function EnchantMentNpcConfig:init(config)
    self:initNpc(config)
end

function EnchantMentNpcConfig:initNpc(config)
    for i, v in pairs(config) do
        local item = {}
        item.position = VectorUtil.newVector3(v.PosX, v.PosY, v.PosZ)
        item.yaw = tonumber(v.PosYaw) or 0
        item.actorName = tostring(v.ActorName) or ""
        item.name = tostring(v.Name) or ""
        item.type = tonumber(v.Type) or 0
        self.npc[i] = item
    end
end

function EnchantMentNpcConfig:prepareNpc()
    for i, v in pairs(self.npc) do
        if v.actorName ~= nil then
            local entityId = EngineWorld:addSessionNpc(v.position, v.yaw, v.type, v.actorName, function(entity)
                entity:setNameLang(v.name or "")
            end)
            v.entityId = entityId
        end
    end
end

function EnchantMentNpcConfig:addLightColumnEffect()
    for k, v in pairs(EnchantMentNpcConfig.npc) do
        EngineWorld:addSimpleEffect("g1018_effect_enchantment.effect", v.position, 0)
    end
end

return EnchantMentNpcConfig