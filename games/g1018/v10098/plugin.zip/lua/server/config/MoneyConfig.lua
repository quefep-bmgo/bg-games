---
--- Created by Jimmy.
--- DateTime: 2017/11/21 0021 10:52
---
---@class MoneyConfig
local MoneyConfig = T(Global, "MoneyConfig")
local Minerals = {}
local Money = {}
local CoinMapping = {}

function MoneyConfig:initMoney()
    local mineralSettings = FileUtil.getConfigFromCsv("setting/MineralLevelSetting.csv", 2, true)
    for _, mineral in pairs(mineralSettings) do
        local data = {}
        data.id = tonumber(mineral.id)
        data.itemId = tonumber(mineral.itemId)
        data.level = tonumber(mineral.level)
        data.life = tonumber(mineral.life)
        data.time = tonumber(mineral.time)
        data.num = tonumber(mineral.num)
        data.costItem = tonumber(mineral.costItem)
        data.costNum = tonumber(mineral.costNum)
        data.itemName = tonumber(mineral.itemName)
        Minerals[tostring(data.id)] = data
    end

    local configs = FileUtil.getConfigFromCsv("setting/MoneySetting.csv", 2, true)
    for _, v in pairs(configs) do
        local data = {}
        local pos = StringUtil.split(v.position, ",")
        local npcPos = StringUtil.split(v.npcPosition, ",")
        local minerals = StringUtil.split(v.meneralId, "#")
        data.id = tonumber(v.id)
        data.position = VectorUtil.newVector3(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]))
        data.npcPosition = VectorUtil.newVector3(tonumber(npcPos[1]), tonumber(npcPos[2]), tonumber(npcPos[3]))
        data.npcYaw = tonumber(npcPos[4])
        data.actorName = tostring(v.actorName) or "#"
        data.name = tostring(v.name or " ")
        data.mineral = {}
        for _, id in pairs(minerals) do
            local item = Minerals[tostring(id)]
            if item then
                table.insert(data.mineral, item)
            end
        end
        table.sort(data.mineral, function(a, b)
            return a.level < b.level
        end)
        Money[data.id] = data
    end
end

function MoneyConfig:getMoneyConfigByIdAndLevel(id, level)
    for i, v in pairs(Money) do
        if id == v.id then
            for j, k in pairs(v.mineral) do
                if k.level == level then
                    return k
                end
            end
        end
    end
    return nil
end

function MoneyConfig:initCoinMapping(coinMapping)
    for i, v in pairs(coinMapping) do
        CoinMapping[i] = {}
        CoinMapping[i].coinId = v.coinId
        CoinMapping[i].itemId = v.itemId
    end
end

function MoneyConfig:getCoinMapping()
    return CoinMapping
end

function MoneyConfig:prepareNpc()
    for i, v in pairs(Money) do
        GameMatch.money[v.id] = {}
        GameMatch.money[v.id].id = v.id
        GameMatch.money[v.id].mineral = v.mineral[1]
        GameMatch.money[v.id].position = v.position
        if v.actorName and v.actorName ~= "#" then
            local entityId = EngineWorld:addActorNpc(v.npcPosition, v.npcYaw, v.actorName, function(entity)
                entity:setHeadName(v.name or " ")
                entity:setSkillName("idle")
            end)
            GameMatch.money[v.id].entityId = entityId
        end
    end
end

return MoneyConfig