---
--- Created by Jimmy.
--- DateTime: 2017/10/20 0020 14:49
---

---@class TeamConfig
local TeamConfig = T(Global, "TeamConfig")
local Settings = {}

function TeamConfig:initTeams()
    local teams = FileUtil.getConfigFromCsv("setting/TeamConfig.csv", 2, true)
    for i, v in pairs(teams) do
        local data = {
            id = tonumber(v.id),
            name = v.name,
            storeName = v.storeName,
            eggActor = v.eggActor
        }
        local initPos = StringUtil.split(v.initPos, ",")
        local storePos = StringUtil.split(v.storePos, ",")
        local eggPos = StringUtil.split(v.eggPos, ",")
        data.initPos = VectorUtil.newVector3(tonumber(initPos[1]), tonumber(initPos[2]), tonumber(initPos[3]))
        data.initYaw = tonumber(initPos[4])
        data.storePos = VectorUtil.newVector3(tonumber(storePos[1]), tonumber(storePos[2]), tonumber(storePos[3]))
        data.storeYaw = tonumber(storePos[4])
        data.eggPos = VectorUtil.newVector3(tonumber(eggPos[1]), tonumber(eggPos[2]), tonumber(eggPos[3]))
        data.eggYaw = tonumber(eggPos[4])
        Settings[data.id] = data
    end
end

function TeamConfig:getTeam(id)
    local team = Settings[id]
    if team == nil then
        team = Settings[1]
    end
    return team
end

function TeamConfig:getTeamColor(id)
    if id == 1 then
        return TextFormat.colorRed
    elseif id == 2 then
        return TextFormat.colorBlue
    elseif id == 3 then
        return TextFormat.colorGreen
    else
        return TextFormat.colorYellow
    end
end

function TeamConfig:prepareEgg()
    for i, v in pairs(Settings) do
        local entityId = EngineWorld:addActorNpc(v.eggPos, v.eggYaw, v.eggActor, function(entity)
            --local text = "text=" .. v.name .. "&offset=0:" .. entity:getHeight() + 0.5 .. ":0"
            --entity:addCustomText("Name", text, -1, 3.5)
        end)
        GameMatch.egg[v.id] = {}
        GameMatch.egg[v.id].id = v.id
        GameMatch.egg[v.id].entityId = entityId
        GameMatch.egg[v.id].name = v.name
    end
end

return TeamConfig