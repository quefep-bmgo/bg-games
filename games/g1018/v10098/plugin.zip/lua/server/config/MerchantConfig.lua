---
--- Created by Jimmy.
--- DateTime: 2017/10/19 0019 11:32
---
require "messages.Messages"

---@class MerchantConfig
local MerchantConfig = T(Global, "MerchantConfig")
local Store = {}
local StoreGoods = {}
local ShopTruck = {}
local Equipment = {}
local TabSort = {
    ["1"] = 1,
    ["2"] = 2,
    ["3"] = 3,
    ["0"] = 4,
    ["5"] = 5,
}

function MerchantConfig:initGoods()
    local goods = FileUtil.getConfigFromCsv("setting/StoreGoodConfig.csv", 2, true)
    local stores = FileUtil.getConfigFromCsv("setting/StoreConfig.csv", 2, true)
    for _, good in pairs(goods) do
        local item = MerchantConfig:newCommodity(good)
        StoreGoods[good.id] = {
            item = item,
            sort = tonumber(good.sort)
        }
    end

    for _, store in pairs(stores) do
        local team = tonumber(store.teamId)
        local level = tonumber(store.level)
        local type = store.type
        local teamKey = (team - 1) * 2 + level
        if not Store[teamKey] then
            Store[teamKey] = {}
        end
        if not TableUtil.findElementByFun(Store[teamKey], function(v)
            return v.type == type
        end) then
            table.insert(Store[teamKey], {
                type = type,
                goods = {}
            })
        end
        local item = StoreGoods[store.id]
        if item then
            for _, group in pairs(Store[teamKey]) do
                if group.type == type then
                    table.insert(group.goods, item)
                    break
                end
            end
            if tonumber(type) == 1 or tonumber(type) == 2 then
                if Equipment[item.item.itemId] == nil then
                    Equipment[item.item.itemId] = 1
                end
            end
        end
    end

    for teamKey, groups in pairs(Store) do
        table.sort(groups, function(a, b)
            return TabSort[tostring(a.type)] < TabSort[tostring(b.type)]
        end)
        for i, group in pairs(groups) do
            table.sort(group.goods, function(a, b)
                return a.sort < b.sort
            end)
            for j, good in pairs(group.goods) do
                MerchantUtil:addCommodity(teamKey, tonumber(group.type), good.item)
            end
        end
    end
end

function MerchantConfig:newCommodity(item)
    local commodity = Commodity.new()
    commodity.itemId = tonumber(item.itemId)
    commodity.itemMeta = tonumber(item.itemMeta)
    commodity.itemNum = tonumber(item.itemNum)
    commodity.coinId = tonumber(item.coinId)
    commodity.price = tonumber(item.price)
    commodity.desc = item.desc
    commodity.notify = tonumber(item.notify) or 0
    commodity.image = item.image or ""
    return commodity
end

function MerchantConfig:initShopTruck()
    local config = FileUtil.getConfigFromCsv("setting/ShopTruck.csv", 2, true)
    for i, v in pairs(config) do
        local pos = StringUtil.split(v.position, ",")
        local truck = {}
        truck.position = VectorUtil.newVector3(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]))
        truck.yaw = tonumber(pos[4])
        truck.actorName = v.actorName
        ShopTruck[i] = truck
    end
end

function MerchantConfig:prepareShopTruck()
    for i, v in pairs(ShopTruck) do
        if v.actorName ~= nil then
            EngineWorld:addActorNpc(v.position, v.yaw, v.actorName, function(entity)
                entity:setHeadName(v.name or "")
            end)
        end
    end
end

function MerchantConfig:getEquipmentItemId(id)
    return Equipment[id]
end

return MerchantConfig