---
--- Created by Jimmy.
--- DateTime: 2018/1/16 0016 11:14
---
---@class ShopConfig
local ShopConfig = T(Global, "ShopConfig")
local Shop = {}

function ShopConfig:init()
    local groupSetting = FileUtil.getConfigFromCsv("setting/ShopGroup.csv", 2, true)
    local goods = FileUtil.getConfigFromCsv("setting/ShopConfig.csv", 2, true)
    for _, group in pairs(groupSetting) do
        local goodsGroup = {}
        goodsGroup.type = tonumber(group.type)
        goodsGroup.icon = group.icon
        goodsGroup.name = group.name
        goodsGroup.goods = {}
        Shop[tostring(goodsGroup.type)] = goodsGroup
    end

    for _, good in pairs(goods) do
        local data = {
            id = tonumber(good.id),
            groupType = tonumber(good.groupType),
            itemId =  tonumber(good.itemId),
            itemMeta =  tonumber(good.itemMeta),
            itemNum =  tonumber(good.itemNum),
            coinId =  tonumber(good.coinId),
            blockymodsPrice =  tonumber(good.blockymodsPrice),
            blockmanPrice =  tonumber(good.blockmanPrice),
            limit =  tonumber(good.limit),
            desc =  good.desc,
            sort = tonumber(good.sort) or 0
        }
        local group = Shop[tostring(data.groupType)]
        if group then
            table.insert(group.goods, data)
        end
    end
end

function ShopConfig:prepareShop()
    for groupIndex, group in pairs(Shop) do
        EngineWorld:addGoodsGroupToShop(group.type, group.icon, group.name)
        table.sort(group.goods, function(a, b)
            return a.sort < b.sort
        end)
        for goodsIndex, goods in pairs(group.goods) do
            EngineWorld:addGoodsToShop(group.type, ShopConfig.newGoods(goods))
        end
    end
end

function ShopConfig.newGoods(item)
    local goods = Goods.new()
    goods.itemId =  item.itemId
    goods.itemMeta =  item.itemMeta
    goods.itemNum =  item.itemNum
    goods.coinId =  item.coinId
    goods.blockymodsPrice =  item.blockymodsPrice
    goods.blockmanPrice =  item.blockmanPrice
    goods.limit =  item.limit
    goods.desc =  item.desc
    return goods
end

return ShopConfig