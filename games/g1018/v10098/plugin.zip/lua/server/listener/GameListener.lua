--region *.lua
require "config.MoneyConfig"
require "config.TeamConfig"
require "config.BlockConfig"
require "config.MerchantConfig"
require "config.EnchantMentNpcConfig"
---@type TeamConfig
local TeamConfig = T(Global, "TeamConfig")
GameListener = {}
---@type MerchantConfig
local MerchantConfig = T(Global, "MerchantConfig")
---@type MoneyConfig
local MoneyConfig = T(Global, "MoneyConfig")
---@type BlockConfig
local BlockConfig = T(Global, "BlockConfig")
---@type ShopConfig
local ShopConfig = T(Global, "ShopConfig")

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameInitEvent, GameListener.onGameInit)
end

function GameListener.onGameInit(config)
    GameConfig:init(config)
    ShopConfig:prepareShop()
    GameServer:setInitPos(TeamConfig:getTeam(1).initPos)
    EngineWorld:stopWorldTime()
    WalletUtils:addCoinMappings(MoneyConfig:getCoinMapping())
    RespawnConfig:prepareRespawnGoods()
    MoneyConfig:prepareNpc()
    TeamConfig:prepareEgg()
    MerchantConfig:prepareShopTruck()
    BlockConfig:prepareBlock()
    EnchantMentNpcConfig:prepareNpc()
end

return GameListener
--endregion
