--region *.lua

require "Match"
require "messages.Messages"

BlockListener = {}

function BlockListener:init()
    CEvents.BlockBreakEvent:registerCallBack(self.onBlockBreak)
    CEvents.PlayerPlaceBlockEvent:registerCallBack(self.onBlockPlace)
    CEvents.BlockTNTExplodeEvent:registerCallBack(self.onBlockTNTExplode)
    CEvents.PlayerPlaceBlockBoxJudgeEvent:registerCallBack(self.onPlayerPlaceBlockBoxJudge)
    CEvents.BlockTNTExplodeBreakBlockEvent:registerCallBack(self.onBlockTNTExplodeBreakBlockEnd)
end

function BlockListener.onBlockBreak(rakssid, blockId, blockPos)
    return EngineWorld:isBlockChange(blockPos)
end

function BlockListener.onBlockPlace(rakssid, itemId, meta, toPlacePos)
    if GameMatch:isGameStart() then
        local player = PlayerManager:getPlayerByRakssid(rakssid)
        if player ~= nil then
            if itemId == BlockID.TNT then
                LuaTimer:scheduleTimer(function(pos)
                    EngineWorld:getWorld():fireTNT(pos)
                end, 100, nil, toPlacePos)
            end
            return true
        end
    end
    return false
end

function BlockListener.onBlockTNTExplode(entityId, pos, attr)
    attr.isBreakBlock = true
    return false
end

function BlockListener.onPlayerPlaceBlockBoxJudge(rakssid, blockId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end

    return false
end

function BlockListener.onBlockTNTExplodeBreakBlockEnd(blockPos, blockId, sourceItemId)
    return EngineWorld:isBlockChange(blockPos)
end

return BlockListener
--endregion
