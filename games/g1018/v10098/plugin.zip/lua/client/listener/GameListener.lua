local GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
end

function GameListener.onGameReady()
    GameConfig:init()
    local window1 = GUIWindowManager.Instance():GetGUIWindow("ArmorPanel-Inventory-Radio-Armor")
    if window1 then
        window1:SetWidth({ 0, 145 })
    end
    local window2 = GUIWindowManager.Instance():GetGUIWindow("FinalSummary-Self-Name")
    if window2 then
        window2:SetXPosition({ 0, 30 })
    end
end

GameListener:init()