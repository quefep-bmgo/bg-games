---@class CustomSceneConfig
local CustomSceneConfig = T(Global, "CustomSceneConfig")

---@type CustomSceneItem[]
local CustomSceneItems = {}
local SceneType = {
    NoType = 0,
    Effect = 1,
    Image = 2,
    Actor = 3,
    WallText = 4,
    Mesh = 5,
}

local ChunkStatus = {
    Loading = 1,
    Unloaded = 2
}

local ChunkSideLength = 5
---@type CustomSceneChunk[]
local CustomSceneChunks = {}
local JsonMap = {}

local WallTextAlignment = 5

local function getChunkKey(pos)
    return tostring(math.floor(pos.x / ChunkSideLength) * ChunkSideLength) .. "#" ..
            tostring(math.floor(pos.z / ChunkSideLength) * ChunkSideLength)
end

----------------------------------- 2 ---------------------------------------
function CustomSceneConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/CustomScene.csv", 2, true)
    for _, config in pairs(configs) do
        local pos = StringUtil.split(config.pos or "", ",")
        ---@class CustomSceneItem
        local item = {
            Id = tonumber(config.Id) or 0,
            type = tonumber(config.type) or 0,
            pos = VectorUtil.newVector3(pos[1] or 0, pos[2] or 0, pos[3] or 0),
            scale = tonumber(config.scale or 0),
            yaw = tonumber(config.yaw or 0),
            param1 = tostring(config.param1 or "#"),
            param2 = tostring(config.param2 or "#"),
            param3 = tostring(config.param3 or "#"),
            param4 = tostring(config.param4 or "#")
        }

        self:addItemToChunk(item)
        CustomSceneItems[item.Id] = item
        if item.type == SceneType.Image then
            JsonMap[item.param1] = 1
        end
        if item.type == SceneType.Mesh then
            WorldMeshRender.Instance():addMesh("CustomMesh#" .. item.Id, item.param1, item.pos, item.yaw, 90, item.scale)
        end
    end
    CustomSceneConfig:gameReady()
end

---@type CustomSceneItem
function CustomSceneConfig:addItemToChunk(item)
    if item.type == SceneType.Mesh then
        return
    end
    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        if CustomSceneChunks[chunkKey].status == ChunkStatus.Loading then
            CustomSceneConfig:addItemToLoadingChunk(chunkKey, item)
        elseif CustomSceneChunks[chunkKey].status == ChunkStatus.Unloaded then
            table.insert(CustomSceneChunks[chunkKey].items, item)
        end
    else
        ---@class CustomSceneChunk
        local newChunk = {
            status = ChunkStatus.Unloaded,
            ---@type CustomSceneItem[]
            items = {},
            centerPos = VectorUtil.newVector3(math.floor(item.pos.x / ChunkSideLength) * ChunkSideLength + ChunkSideLength / 2, 0,
                    math.floor(item.pos.z / ChunkSideLength) * ChunkSideLength + ChunkSideLength / 2)
        }
        table.insert(newChunk.items, item)
        CustomSceneChunks[chunkKey] = newChunk
    end
end

---@return CustomSceneItem
function CustomSceneConfig:getConfigById(id)
    return CustomSceneItems[tonumber(id)]
end

function CustomSceneConfig:gameReady()
    for jsonName, _ in pairs(JsonMap) do
        TextureAtlasRegister.Instance():addTextureAtlas(jsonName, "", function(r, name) end)
    end

    self.frameTimes = 0
    Listener.registerCallBack(CEvents.GameMainTickEvent, function(frameTime)
        self:onUpdate(frameTime)
    end)
end

function CustomSceneConfig:onUpdate(frameTime)
    self.frameTimes = self.frameTimes + frameTime
    if self.frameTimes < 1000 then
        return
    end
    self.frameTimes = 0
    local playerPos = PlayerManager:getClientPlayer():getPosition()
    playerPos.y = 0
    for key, chunk in pairs(CustomSceneChunks) do
        local distance = VectorUtil.distance(playerPos, chunk.centerPos)
        if chunk.status == ChunkStatus.Unloaded and distance < GameConfig.CustomSceneLoadRadius then
            self:createScene(key)
            chunk.status = ChunkStatus.Loading
        elseif chunk.status == ChunkStatus.Loading and distance > GameConfig.CustomSceneLoadRadius then
            self:destroyScene(key)
            chunk.status = ChunkStatus.Unloaded
        end
    end
end

function CustomSceneConfig:createScene(chunkKey)
    for _, config in pairs(CustomSceneChunks[chunkKey].items or {}) do
        if config.type == SceneType.Effect then
            config.targetEffect = EngineWorld:addSimpleEffect(config.param1, config.pos, config.yaw, -1, config.scale, config.scale, config.scale)
            CustomSceneItems[config.Id].targetEffect = config.targetEffect
        elseif config.type == SceneType.Image then
            WorldImageRender.Instance():addStaticImage("CustomImage#" .. config.Id, config.param1, config.param2, config.pos, config.scale, false, config.yaw)
        elseif config.type == SceneType.Actor then
            config.targetEntityId = EngineWorld:addActorNpc(config.pos, config.yaw, config.param1, function(entity)
                entity:setSkillName(config.param2 ~= "#" and config.param2 or "idle")
                if config.param3 ~= "#" and tonumber(config.param3) > 0 then
                    LuaTimer:cancel(config.animKey or 0)
                    config.animKey = LuaTimer:scheduleTimer(function()
                        local animEntity = EntityCache:getEntity(config.targetEntityId)
                        if animEntity and animEntity.entity then
                            animEntity.entity:setSkillName(config.param2 ~= "#" and config.param2 or "idle")
                        end
                    end, tonumber(config.param3))
                end
                entity:setIgnoreFrustumCheck(true)
                entity:setRenderDistanceWeight(100)
                entity:setScale(config.scale)
                entity:setCanCollided(false)
                if tonumber(config.param4) == 1 then
                    entity:setFlying(true)
                end
            end)

            CustomSceneItems[config.Id].targetEntityId = config.targetEntityId
        elseif config.type == SceneType.WallText then
            local globalRender = Blockman.Instance().m_globalRender
            if globalRender then
                local rgba = StringUtil.split(config.param3, "#", false, true)
                globalRender:luaAddWallText(WallTextAlignment, -1, config.param1, config.pos,
                        config.scale, config.yaw, config.param2, { rgba[1] / 255, rgba[2] / 255, rgba[3] / 255, rgba[4] / 255 })
            end
        end
    end
end

function CustomSceneConfig:destroyScene(chunkKey)
    for _, config in pairs(CustomSceneChunks[chunkKey].items or {}) do
        if config.type == SceneType.Effect then
            if config.targetEffect then
                EngineWorld:removeSimpleEffect(config.targetEffect.mEffectName)
            end
            config.targetEffect = nil
            CustomSceneItems[config.Id].targetEffect = nil
        elseif config.type == SceneType.Image then
            WorldImageRender.Instance():removeStaticImage("CustomImage#" .. config.Id)
        elseif config.type == SceneType.Actor then
            LuaTimer:cancel(config.animKey or 0)
            EngineWorld:removeEntity(config.targetEntityId)
            EntityCache:removeEntityCache(config.targetEntityId)
            config.targetEntityId = nil
            CustomSceneItems[config.Id].targetEntityId = nil
        elseif config.type == SceneType.WallText then
            local globalRender = Blockman.Instance().m_globalRender
            if globalRender then
                globalRender:deleteWallText(config.pos or VectorUtil.ZERO, 0.1)
            end
        end
    end
end

function CustomSceneConfig:addItemToLoadingChunk(chunkKey, item)
    if item.type == SceneType.Effect then
        item.targetEffect = EngineWorld:addSimpleEffect(item.param1, item.pos, item.yaw, -1, item.scale, item.scale, item.scale)
        CustomSceneItems[item.Id].targetEffect = item.targetEffect
    elseif item.type == SceneType.Image then
        WorldImageRender.Instance():addStaticImage("CustomImage#" .. item.Id, item.param1, item.param2, item.pos, item.scale, false, item.yaw)
    elseif item.type == SceneType.Actor then
        item.targetEntityId = EngineWorld:addActorNpc(item.pos, item.yaw, item.param1, function(entity)
            entity:setSkillName(item.param2 ~= "#" and item.param2 or "idle")
            if item.param3 ~= "#" and tonumber(item.param3) > 0 then
                LuaTimer:cancel(item.animKey or 0)
                item.animKey = LuaTimer:scheduleTimer(function()
                    local animEntity = EntityCache:getEntity(item.targetEntityId)
                    if animEntity and animEntity.entity then
                        animEntity.entity:setSkillName(item.param2 ~= "#" and item.param2 or "idle")
                    end
                end, tonumber(item.param3))
            end
            entity:setIgnoreFrustumCheck(true)
            entity:setRenderDistanceWeight(100)
            entity:setScale(item.scale)
            entity:setCanCollided(false)
            if tonumber(item.param4) == 1 then
                entity:setFlying(true)
            end
        end)

        CustomSceneItems[item.Id].targetEntityId = item.targetEntityId
    elseif item.type == SceneType.WallText then
        local globalRender = Blockman.Instance().m_globalRender
        if globalRender then
            local rgba = StringUtil.split(item.param3, "#", false, true)
            globalRender:luaAddWallText(WallTextAlignment, -1, item.param1, item.pos,
                    item.scale, item.yaw, item.param2, { rgba[1] / 255, rgba[2] / 255, rgba[3] / 255, rgba[4] / 255 })
        end
    end
    if item.type == SceneType.Mesh then
        return
    end
    table.insert(CustomSceneChunks[chunkKey].items, item)
end