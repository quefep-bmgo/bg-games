--GameConfig.lua
require "config.CustomSceneConfig"

GameConfig = {}
GameConfig.CustomSceneLoadRadius = 50
---@type CustomSceneConfig
local CustomSceneConfig = T(Global, "CustomSceneConfig")

function GameConfig:init()
    local config = FileUtil.getConfigFromYml("setting/ClientConfig.yml", true)
    GameConfig.CustomSceneLoadRadius = config.CustomSceneLoadRadius or 50
    GameConfig.BlockRenderDistance = config.BlockRenderDistance or 50
    WorldMeshRender.Instance():setRenderDistance(GameConfig.CustomSceneLoadRadius)
    ClientHelper.putIntPrefs("BlockRenderDistance", GameConfig.BlockRenderDistance)
    CustomSceneConfig:init()
end

return GameConfig