local time1 = os.clock()
local function md5sum(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*a")
        file:close()
        local len = #content
        if len <= 2048 then
            return content
        else
            local size = math.floor(len / 2048)
            if size <= 1 then
                return content
            end
            local result = ""
            for i = 1, 2048 do
                local start = (i - 1) * size + 1
                if start <= len then
                    result = result .. content:sub(start, start)
                end
            end
            return result
        end
    else
        return ""
    end
end
local packet = {
    globals = { "isTest" },
    engines = {},
    games = {},
}
local globals = {}
local engines = {}
local games = {}
for _, key in pairs(packet.globals) do
    globals[key] = _G[key]
end
local engineRoot = FileUtil:getRootPath() .. "Media/Scripts/Engine"
for _, engine in pairs(packet.engines) do
    local path = engineRoot .. engine
    local content = md5sum(path)
    engines[engine] = content
end
for _, game in pairs(packet.games) do
    local path = FileUtil:getMapPath() .. game
    local file = io.open(path, "r")
    if not file then
        path = FileUtil:getScriptPath() .. game
    else
        file:close()
    end
    local content = md5sum(path)
    games[game] = content
end
local sandboxol = {}
local path = FileUtil:getRootPath() .. "Media/sandboxol"
sandboxol.engine = md5sum(path)
path = FileUtil:getMapPath() .. "/sandboxol"
local file = io.open(path, "r")
if not file then
    path = FileUtil:getScriptPath() .. "/sandboxol"
else
    file:close()
end
sandboxol.game = md5sum(path)
local paths = StringUtil.split(FileUtil:getMapPath(), "/")
local last = paths[#paths]
while last and last ~= "map" do
    table.remove(paths)
    last = paths[#paths]
end
table.insert(paths, "Media")
local function dir_exist(dir)
    local lfs = require "lfs"
    local attr = lfs.attributes(dir)
    if not attr then
        return false
    end
    if Platform.isWindow() then
        return attr.mode == "directory"
    else
        return attr.size and attr.size > 0
    end
end
local hacker = dir_exist(table.concat(paths, "/"))
local time2 = os.clock()
PlayerManager:getClientPlayer():sendPacket({
    pid = "SyncClientVerify",
    globals = globals,
    engines = engines,
    games = games,
    sandboxol = sandboxol,
    time = (time2 - time1) * 1000,
    hacker = hacker
})