---@class HackReport
local HackReport = T(Global, "HackReport")
HackReport.actionType = {}
HackReport.actionName = {}

local HackActionType = HackReport.actionType
HackActionType.lowVersion = 0
HackActionType.useFakeApp = 1
HackActionType.modifyScript = 2
HackActionType.inTheAirCheat = 3
HackActionType.addTimeSpeedCheat = 4
HackActionType.slowDownTimeCheat = 5
HackActionType.blockDestroyDisUnLimit = 6
HackActionType.noBloodLossCheat = 7
HackActionType.attackDisUnLimit = 8
HackActionType.addMoveSpeedCheat = 9
HackActionType.useFakeAppBySo = 10

local HackActionName = HackReport.actionName
HackActionName[0] = "游戏服务器检测到版本号低于10086"
HackActionName[1] = "游戏服务器检测到使用破解包"
HackActionName[2] = "游戏服务器检测到修改游戏脚本"----暂时没实现 留空位
HackActionName[3] = "游戏服务器检测到飞天作弊"
HackActionName[4] = "游戏服务器检测到时间加速作弊"
HackActionName[5] = "游戏服务器检测到时间减速作弊"
HackActionName[6] = "游戏服务器检测到方块破坏无限距离作弊"
HackActionName[7] = "游戏服务器检测到不掉血作弊" -- 暂时没实现。留空位。
HackActionName[8] = "游戏服务器检测到攻击无限距离作弊"
HackActionName[9] = "游戏服务器检测到移动加速作弊"
HackActionName[10] = "游戏服务器检测到非法SO"
HackActionName[11] = "游戏服务器检测到非法尝试使用GM指令"
HackActionName[12] = "新反外挂-检测到移动作弊"
HackActionName[13] = "新反外挂-检测到飞天作弊"
HackActionName[14] = "新反外挂-检测到加速作弊"
HackActionName[15] = "反外挂2.0-检测到移动作弊"
HackActionName[16] = "反外挂2.0-检测到飞天作弊"
HackActionName[17] = "反外挂2.0-检测到加速作弊"

function HackReport:init()
    local this = self
    CEvents.HackReportEvent:registerCallBack(
            function(userId, actionType, desc)
                this:Report(userId, actionType, desc or "")
            end)
end

function HackReport:Report(userId, actionType, desc)
    local os = "unknown"
    local clientInfo = GameAnalyticsCache:getClientInfo(userId)
    if clientInfo ~= nil and clientInfo.os_platform ~= nil then
        os = clientInfo.os_platform
    end
    local cheatSource = self.actionName[actionType] or string.format("未知类型[%s]", tostring(actionType))
    WebService:uploadCheatInfo(userId, os, cheatSource, desc)
    GameAnalytics:reportCheatDetect(userId, actionType)
end

HackReport:init()
