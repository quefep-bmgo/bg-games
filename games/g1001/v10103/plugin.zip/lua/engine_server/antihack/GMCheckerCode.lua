local isGMOpen = false
isGMOpen = isGMOpen or _G["QHPanelActive"] ~= nil
isGMOpen = isGMOpen or GUIManager:getWindowByName("GMMain") ~= nil
isGMOpen = isGMOpen or GUIManager:getWindowByName("GMControlPanel") ~= nil
for i = 1, 12 do
    isGMOpen = isGMOpen or _G[i >= 10 and ("ScriptQH00" .. i) or ("ScriptQH000" .. i)] ~= nil
end
PlayerManager:getClientPlayer():sendPacket({
    pid = "onCheckGMOpenResult",
    isGMOpen = isGMOpen,
})