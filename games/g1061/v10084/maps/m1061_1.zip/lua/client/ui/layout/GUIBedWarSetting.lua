---@class UIBedWarSettingLayout : IGUILayout
local UIBedWarSettingLayout = class("UIBedWarSettingLayout", IGUILayout)
---@type ReconnectUtil
local ReconnectUtil = T(Global, "ReconnectUtil")
---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")

local DefaultTabs = {
    Define.SettingTabType.Screen,
    Define.SettingTabType.Buttons,
    Define.SettingTabType.Sound,
    Define.SettingTabType.Account,
    Define.SettingTabType.System
}

SystemSettingRecord = {}

function onSaveSetting()
    if GUIBedWarSetting then
        ClientHelper.putStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_SystemSettings", json.encode(GUIBedWarSetting:getSystemSettingRecord()))
    end
end

---@private
function UIBedWarSettingLayout:ctor(parent)
    self.super.ctor(self, "BedWarSetting.json", parent)
end

function UIBedWarSettingLayout:isDelayLoad()
    return true
end

---@private
function UIBedWarSettingLayout:onCreate()
    self.defaultSetting = FileUtil.getConfigFromYml("setting/DefaultSettings")
    self.poleMove = GUIManager:getWindowByName("Main-PoleControl-Move")
    self.poleControl = GUIManager:getWindowByName("Main-PoleControl")
    self.poleBG = GUIManager:getWindowByName("Main-PoleControl-BG", GUIType.StaticImage)
    self.poleWidth = self.poleControl:GetPixelSize().x
    self.poleHeight = self.poleControl:GetPixelSize().y
    self.tabSetting = self.defaultSetting.SettingButton or DefaultTabs
    for i = #self.tabSetting, 1, -1 do
        if not TableUtil.include(Define.SettingTabType, tonumber(self.tabSetting[i])) then
            table.remove(self.tabSetting, i)
        else
            self.tabSetting[i] = tonumber(self.tabSetting[i])
        end
    end
    self.tabs = {}
    ---@type GUISettingBasic[] | GUISettingSound[] |  GUISettingOperation[] |  GUIBedWarSettingPlayerListWindow[]
    self.layouts = {}
    self:initCacheSetting()
    ---视角默认选择{ 1, 2, 3 }
    self:changeCamera(GameType == "g1046" and 2 or 1)
end

---@private
function UIBedWarSettingLayout:onLoad()
    local needRemove = not isGarena or isSandboxApp
    if needRemove then
        if TableUtil.include(self.tabSetting, Define.SettingTabType.Binding) then
            TableUtil.tableRemove(self.tabSetting, Define.SettingTabType.Binding)
        end
    end
    if GameType ~= "g1063" and not TableUtil.tableContain(self.tabSetting, Define.SettingTabType.PlayerList) then
        table.insert(self.tabSetting, 1, Define.SettingTabType.PlayerList)
    end
    if not isTest and Platform.isWindow() then
        TableUtil.tableRemove(self.tabSetting, Define.SettingTabType.Buttons)
    end
    if Game:isEnableIndie() then
        TableUtil.tableRemove(self.tabSetting, Define.SettingTabType.Exit)
    else
        TableUtil.tableRemove(self.tabSetting, Define.SettingTabType.Account)
        TableUtil.tableRemove(self.tabSetting, Define.SettingTabType.System)
        if not TableUtil.tableContain(self.tabSetting, Define.SettingTabType.Exit) then
            table.insert(self.tabSetting, Define.SettingTabType.Exit)
        end
        if TableUtil.include(self.tabSetting, Define.SettingTabType.Language) then
            TableUtil.tableRemove(self.tabSetting, Define.SettingTabType.Language)
        end
        if TableUtil.include(self.tabSetting, Define.SettingTabType.Binding) then
            TableUtil.tableRemove(self.tabSetting, Define.SettingTabType.Binding)
        end
    end

    self.llContent = self:getChildWindow("BedWarSetting-Content", GUIType.Layout)
    self.llTabs = self:getChildWindow("BedWarSetting-Tabs", GUIType.Layout)
    self.lhTabList = self:getChildWindow("BedWarSetting-Tab-List", GUIType.ListHorizontal)
    ---@type GUIBedWarUIReturnControlWindow
    local llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "gui_setting_title", function()
        SoundUtil.clickUI()
        GUIBedWarSetting:hide()
    end)

    self.root:AddChildWindow(llReturn.root)
    self:initView()
    self:setTabSelect(self.tabSetting[1])
    self:initSystemSetting(SystemSettingRecord)
end

---@private
function UIBedWarSettingLayout:initView()
    self:initLayouts()
    self:initTabs()
end

---@private
function UIBedWarSettingLayout:initLayouts()
    for index, tabType in pairs(self.tabSetting) do
        tabType = tonumber(tabType)
        local content
        if tabType == Define.SettingTabType.PlayerList then
            ---@type GUIBedWarSettingPlayerListWindow
            content = UIHelper.newGameGUIWindow("GUIBedWarSettingPlayerList")
        elseif tabType == Define.SettingTabType.Screen then
            ---@type GUISettingBasic
            content = UIHelper.newGameGUIWindow("GUISettingBasic")
        elseif tabType == Define.SettingTabType.Sound then
            ---@type GUISettingSound
            content = UIHelper.newGameGUIWindow("GUISettingSound")
        elseif tabType == Define.SettingTabType.Buttons then
            ---@type GUISettingOperation
            content = UIHelper.newGameGUIWindow("GUISettingOperation")
        end
        if content then
            self.llContent:AddChildWindow(content.root)
            content.root:SetVisible(false)
            self.layouts[tabType] = content
        end
    end
end

---@private
function UIBedWarSettingLayout:initTabs()
    for index, tabType in ipairs(self.tabSetting) do
        tabType = tonumber(tabType)
        local btn = GUIManager:createGUIWindow(GUIType.Button, " -Tab-" .. tabType)
        local line = GUIManager:createGUIWindow(GUIType.StaticImage, "BedWarSetting-Tab-Line" .. tabType)
        self.lhTabList:AddChildWindow(btn)
        btn:AddChildWindow(line)
        btn:SetHorizontalAlignment(HorizontalAlignment.Center)
        line:SetHorizontalAlignment(HorizontalAlignment.Center)
        line:SetVerticalAlignment(VerticalAlignment.Bottom)
        btn:SetArea({ 0, 0 }, { 0.131757 * (index - 1), 0 }, { 1, -4 }, { 0.103041, 0 })
        line:SetArea({ 0, 0 }, { 0, -10 }, { 0.527675, 0 }, { 0, 2 })
        line:SetBackgroundColor({ 179 / 255, 176 / 255, 241 / 255, 1 })
        btn:SetText(Lang:getString(Define.SettingTabText[tabType]))
        btn:SetNormalImage("")
        btn:SetPushedImage("")
        btn:SetTextColor(Define.TabTextColor.Normal)
        line:SetVisible(true)
        btn:registerEvent(GUIEvent.ButtonClick, function()
            SoundUtil.clickUI()
            self:setTabSelect(tabType)
        end)
        self.tabs[tabType] = {
            btn = btn,
            line = line
        }

        if tabType == Define.SettingTabType.Back or tabType == Define.SettingTabType.Exit then
            btn:SetVerticalAlignment(VerticalAlignment.Bottom)
            local _index = #self.tabSetting - index + 1
            btn:SetArea({ 0, 0 }, { -0.131757 * (_index - 1), 0 }, { 1, -4 }, { 0.103041, 0 })
        end
    end
end

---@private
---@param type number
function UIBedWarSettingLayout:setTabSelect(type)
    if self.selectTab and self.selectTab ~= 0 then
        local oldTab = self.tabs[self.selectTab]
        if self.layouts[self.selectTab] then
            self.layouts[self.selectTab].root:SetVisible(false)
        else
            ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_CLOSE_SINGLE_SETTING)
        end
        oldTab.btn:SetNormalImage("")
        oldTab.btn:SetPushedImage("")
        oldTab.btn:SetTextColor(Define.TabTextColor.Normal)
        oldTab.line:SetVisible(true)
    end

    local newTab = self.tabs[type]
    if self.layouts[type] then
        self.layouts[type].root:SetVisible(true)
        self.layouts[type]:onDataChanged()
    elseif type == Define.SettingTabType.Account then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ACCOUNT)
    elseif type == Define.SettingTabType.System then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_VERSION)
    elseif type == Define.SettingTabType.Binding then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_BINDING)
    elseif type == Define.SettingTabType.Language then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_LANGUAGE)
    elseif type == Define.SettingTabType.Exit then
        self:hide()
        if isGameEnd or GameType == "g1046" or GameType == "g1063" or not isGameStart then
            GUIBedWarSetting:onClickExit()
        else
            self:showExitOrBackHallDialog("gui_bed_war_menu_exit_tip", function()
                if Game:isEnableIndie() then
                    GamePacketSender:sendBackHall()
                else
                    Game:exitGame()
                end
            end)
        end
    elseif type == Define.SettingTabType.Back then
        self:hide()
        if isGameEnd or not isGameStart then
            GamePacketSender:sendBackHall()
        else
            self:showExitOrBackHallDialog("gui_bed_war_mane_back_hall_tip", function()
                GamePacketSender:sendBackHall()
            end)
        end
    end
    newTab.btn:SetNormalImage("set:bed_war_3_button.json image:btn_0_current01")
    newTab.btn:SetPushedImage("set:bed_war_3_button.json image:btn_0_current01")
    newTab.btn:SetTextColor(Define.TabTextColor.Select)
    newTab.line:SetVisible(false)
    self.selectTab = type
end

function UIBedWarSettingLayout:initCacheSetting()
    SystemSettingRecord = {}
    local SettingJson = ClientHelper.getStringForKey(tostring(Game:getPlatformUserId()) .. "g1008_SystemSettings", "")
    if string.sub(SettingJson, 1, 1) == "{" then
        SystemSettingRecord = json.decode(SettingJson)
    end
    SystemSettingRecord.defaultCamera = SystemSettingRecord.defaultCamera or (Blockman.Instance():getCurrPersonView() + 1)
    self:initSystemSetting(SystemSettingRecord)
end

function UIBedWarSettingLayout:initSystemSetting(setting)
    local oldSetting = TableUtil.copyTable(setting)
    ---帧数默认选择{ 1, 2 ,3}
    local defaultFPS = setting.defaultFPS or self.defaultSetting.defaultFPS
    ---亮度进度条 [0-1]
    local defaultLuminance = setting.defaultLuminance or self.defaultSetting.defaultLuminance
    ---按钮大小进度条 [0-1]
    local defaultButtonSize = setting.defaultButtonSize or self.defaultSetting.defaultButtonSize
    ---灵敏度进度条 [0-1]
    local defaultSensitivity = setting.defaultSensitivity or self.defaultSetting.defaultSensitivity
    ---视野距离进度条 [0-1]
    local defaultHorizon = setting.defaultHorizon or self.defaultSetting.defaultHorizon
    ---操作遥感选择{ 1, 2, 3, 4 } 1是旧按键 2是旧摇杆, 3是灵活摇杆, 4是跳跃前进按键
    local defaultOperation = setting.defaultOperation or self.defaultSetting.defaultOperation
    ---背景音乐开关{ 0, 1} 2是关 1是开
    local defaultBackGroundSwitch = setting.defaultBackGroundSwitch or self.defaultSetting.defaultBackGroundSwitch
    ---背景音乐大小进度条 [0-1]
    local defaultBackGroundVolume = setting.defaultBackGroundVolume or self.defaultSetting.defaultBackGroundVolume
    ---音效开关{ 0, 1} 2是关 1是开
    local defaultEffectSwitch = setting.defaultEffectSwitch or self.defaultSetting.defaultEffectSwitch
    ---音效大小进度条 [0-1]
    local defaultEffectVolume = setting.defaultEffectVolume or self.defaultSetting.defaultEffectVolume
    SystemSettingRecord = oldSetting

    if not self:isLoad() then
        SystemSettingRecord.defaultFPS = defaultFPS
        CGame.Instance():SetMaxFps((defaultFPS + 1) * 15)
        Blockman.Instance().m_gameSettings.gammaSetting = defaultLuminance
        Blockman.Instance().m_gameSettings.playerActivityGuiSize = 0.5 + 0.5 * defaultButtonSize
        local minSensitivity = 1.0
        local maxSensitivity = 9.0
        local sensitivity = minSensitivity + (maxSensitivity - minSensitivity) * defaultSensitivity
        Blockman.Instance().m_gameSettings:setCameraSensitive(sensitivity)
        Blockman.Instance().m_gameSettings:setFovSetting(defaultHorizon)
        if defaultOperation == 1 or defaultOperation == 4 then
            Blockman.Instance().m_gameSettings.usePole = 0
            ClientHelper.putBoolPrefs("UseCenterJumpButton", defaultOperation == 4)
        elseif defaultOperation == 2 then
            Blockman.Instance().m_gameSettings.usePole = 1
            self.poleMove:SetArea({ 0, 50 }, { 0, -70 }, { 0, self.poleWidth }, { 0, self.poleHeight })
            self.poleBG:SetImage("set:pole.json image:pole_bg")
        else
            Blockman.Instance().m_gameSettings.usePole = 2
            self.poleMove:SetArea({ 0, 0 }, { 0, 0 }, { 0, self.poleWidth * 1.8 }, { 0, self.poleHeight * 2.0 })
            self.poleBG:SetImage("set:pole.json image:pole_bg_2")
        end
        SoundSystem.Instance():setBackgroundMusicSwitch(defaultBackGroundSwitch == 1)
        SoundSystem.Instance():setBackgroundMusicVolume(defaultBackGroundVolume)
        ClientHelper.putBoolPrefs("SoundEffectSwitch", defaultEffectSwitch == 1)
        SoundSystem.Instance():setEffectsVolume(defaultEffectVolume)
        return
    end

    self.layouts[Define.SettingTabType.Screen].fpsGroup:selectIndex(defaultFPS)
    self.layouts[Define.SettingTabType.Screen]:refreshLuminance(defaultLuminance)
    if self.layouts[Define.SettingTabType.Buttons] then
        self.layouts[Define.SettingTabType.Buttons]:refreshSize(defaultButtonSize)
    end
    self.layouts[Define.SettingTabType.Screen]:refreshSensitive(defaultSensitivity)
    self.layouts[Define.SettingTabType.Screen]:refreshHorizon(defaultHorizon)
    if self.layouts[Define.SettingTabType.Buttons] then
        self.layouts[Define.SettingTabType.Buttons].opGroup:selectIndex(defaultOperation)
    end
    self.layouts[Define.SettingTabType.Sound].bgGroup:selectIndex(defaultBackGroundSwitch)
    self.layouts[Define.SettingTabType.Sound]:refreshBackGround(defaultBackGroundVolume)
    self.layouts[Define.SettingTabType.Sound].soundGroup:selectIndex(defaultEffectSwitch)
    self.layouts[Define.SettingTabType.Sound]:refreshEffect(defaultEffectVolume)
end

function UIBedWarSettingLayout:getSystemSettingRecord()
    local setting = {}
    for key, value in pairs(SystemSettingRecord) do
        setting[key] = math.floor(value * 10) / 10
    end
    return setting
end

function UIBedWarSettingLayout:show(playSound)
    if playSound then
        SoundUtil.playSound(SoundConfig.openSetting)
    end
    self.super.show(self)
end

function UIBedWarSettingLayout:hide(playSound)
    if playSound then
        SoundUtil.playSound(SoundConfig.closeSetting)
    end
    self.super.hide(self)
end

function UIBedWarSettingLayout:onHide()
    ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_CLOSE_SINGLE_SETTING)
end

function UIBedWarSettingLayout:onShow()
    if not self.first and Game:isEnableIndie() then
        local appPos = {
            minX = self.llContent:GetXPosition()[1],
            minY = self.llContent:GetYPosition()[1],
            maxX = (self.llContent:GetXPosition()[1] + self.llContent:GetWidth()[1]),
            maxY = (self.llContent:GetYPosition()[1] + self.llContent:GetHeight()[1])
        }
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_SETTING_VIEW_SIZE, json.encode(appPos))
        self.first = true
    end
    if self.selectTab == Define.SettingTabType.Account then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_ACCOUNT)
    elseif self.selectTab == Define.SettingTabType.System then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_VERSION)
    elseif self.selectTab == Define.SettingTabType.Binding then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_BINDING)
    elseif self.selectTab == Define.SettingTabType.Language then
        ClientHelper.onAppActionTrigger(CDefine.AppActionType.APP_ACTION_LANGUAGE)
    elseif self.selectTab == Define.SettingTabType.Exit or self.selectTab == Define.SettingTabType.Back then
        self:setTabSelect(self.tabSetting[1])
    else
        if self.layouts[self.selectTab] then
            self.layouts[self.selectTab]:onDataChanged()
        end
    end
end

function UIBedWarSettingLayout:onClickExit()
    CustomDialog.builder()
                .setContentText(Lang:getString("gui.message.exit.game"))
                .setLeftText("gui.cancel")
                .setRightText("gui.sure.exit")
                .setLeftClickListener(function()

    end)
                .setRightClickListener(function()
        Game:exitGame()
    end)        .show()
end

---判断是否是第一视角
function UIBedWarSettingLayout:isFirstPerspective()
    if SystemSettingRecord.defaultCamera == nil then
        SystemSettingRecord.defaultCamera = 1
    end
    if not self:isLoad() then
        return SystemSettingRecord.defaultCamera == 1
    end
    return self.layouts[Define.SettingTabType.Screen].cameraGroup:getCurIndex() == 1
end

function UIBedWarSettingLayout:changeCamera(index)
    if not self:isLoad() then
        Blockman.Instance():setPersonView(index - 1)
        SystemSettingRecord.defaultCamera = index
        if GUIBedWarToolBar then
            GUIBedWarToolBar:cameraChange()
        end
        if GUIMain then
            GUIMain:cameraChange()
        end
        return
    end
    self.layouts[Define.SettingTabType.Screen].cameraGroup:selectIndex(index)
end

function UIBedWarSettingLayout:refreshCamera()
    if SystemSettingRecord.defaultCamera == nil then
        SystemSettingRecord.defaultCamera = 1
    end
    Blockman.Instance():setPersonView(SystemSettingRecord.defaultCamera - 1)
end

function UIBedWarSettingLayout:showExitOrBackHallDialog(tip, sureCallback)
    LuaTimer:cancel(self.timerKer)
    local times = 5
    self.timerKer = LuaTimer:scheduleTimer(function()
        times = times - 1
        if times == 0 then
            CustomDialog.setRightText(Lang:getString("gui.sure.exit")).setRightDisable(true)
        else
            CustomDialog.setRightText(Lang:getString("gui.sure.exit") .. "(" .. times .. "s)")
        end
    end, 1000, 5)
    CustomDialog.builder()
                .setRightText(Lang:getString("gui.sure.exit") .. "(5s)")
                .setContentText(Lang:getString(tip))
                .setRightClickListener(function()
        ReconnectUtil:clearGameServerData(Game:getPlatformUserId())
        if sureCallback then
            sureCallback()
        end
    end)        .setRightDisable(false)
                .setHideListener(function()
        LuaTimer:cancel(self.timerKer)
    end)
                .show()
end

return UIBedWarSettingLayout
