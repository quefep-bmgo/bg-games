---@class GUICustomGoodsTicketItemWindow : IGUIWindow
local GUICustomGoodsTicketItemWindow = class("GUICustomGoodsTicketItemWindow", IGUIWindow)

---@private
function GUICustomGoodsTicketItemWindow:ctor(...)
    self.super.ctor(self, "CustomGoodsTicketItem.json", ...)
end

---@private
function GUICustomGoodsTicketItemWindow:onLoad()
    self.siBorder = self:getChildWindowByName("CustomGoodsTicketItem", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("CustomGoodsTicketItem-Image", GUIType.StaticImage)
    self.siTag = self:getChildWindowByName("CustomGoodsTicketItem-Tag", GUIType.StaticImage)
    self.stTime = self:getChildWindowByName("CustomGoodsTicketItem-Time", GUIType.StaticText)
    self.stCount = self:getChildWindowByName("CustomGoodsTicketItem-Count", GUIType.StaticText)
    self:initView()
    self:initEvent()
end

---@private
function GUICustomGoodsTicketItemWindow:initView()

end

---@private
function GUICustomGoodsTicketItemWindow:initEvent()
    self.siBorder:registerEvent(GUIEvent.Click, function()
        GUICustomGoodsTicketBagLayout:showCurrentTicket(self.data)
    end)
end

---@param data CustomGoodsTicketData
function GUICustomGoodsTicketItemWindow:onDataChanged(data)
    self.data = data
    self.siBorder:SetImage("set:bed_war_3_dress_store.json image:img_0_ticket_" .. tostring(data.level))
    self.siTag:SetImage("set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(data.level))
    self.stTime:SetText(data.day .. Lang:getString("gui.day"))
    self.stCount:SetText(data.count)
    local config = CustomShopConfig:getGoodsConfig(data.customGoodsId)
    if config then
        self.siImage:SetImage(config.Image)
    end
end

return GUICustomGoodsTicketItemWindow
