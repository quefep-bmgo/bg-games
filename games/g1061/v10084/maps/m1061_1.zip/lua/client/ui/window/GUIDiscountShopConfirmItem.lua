---@class GUIDiscountShopConfirmItemWindow : IGUIWindow
local GUIDiscountShopConfirmItemWindow = class("GUIDiscountShopConfirmItemWindow", IGUIWindow)
---@type CustomGoodsTicketConfig
local CustomGoodsTicketConfig = T(Global, "CustomGoodsTicketConfig")

---@private
function GUIDiscountShopConfirmItemWindow:ctor(...)
    self.super.ctor(self, "DiscountShopConfirmItem.json", ...)
end

---@private
function GUIDiscountShopConfirmItemWindow:onLoad()
    self.siImage = self:getChildWindowByName("DiscountShopConfirmItem-Image", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("DiscountShopConfirmItem-Effect", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("DiscountShopConfirmItem-Count", GUIType.StaticText)
end

---@param data DiscountShopGoodsData | ScoreActivityRewardData
function GUIDiscountShopConfirmItemWindow:onDataChanged(data)
    self.data = data
    self.siImage:SetImage(data.reward.image)
    self.siEffect:SetVisible(data.showBorder)
    if data.showBorder then
        self.siImage:SetWidth({ 0, 60 })
        self.siImage:SetHeight({ 0, 60 })
    else
        self.siImage:SetWidth({ 0, 77 })
        self.siImage:SetHeight({ 0, 77 })
    end
    if data.reward.numLang ~= "#" then
        self.stCount:SetText(Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    self:onSetTag(self.data.reward)
end

---@param reward CommonActivityRewardData
function GUIDiscountShopConfirmItemWindow:onSetTag(reward)
    if self.llTag then
        self.llTag.root:SetVisible(false)
    end
    if reward.type ~= "RewardSetting" then
        return
    end
    local realReward = RewardConfig:getRewardById(reward.realId)
    if not realReward or realReward.RewardType ~= Define.RewardType.CustomGoodsTicket then
        return
    end
    local item = CustomGoodsTicketConfig:getTicketConfig(realReward.RewardId)
    if item then
        if not self.llTag then
            ---@type GUIBedWarItemTagWindow
            self.llTag = UIHelper.newGameGUIWindow("GUIBedWarItemTag", "BedWarItemTag.json")
            self.root:AddChildWindow(self.llTag.root)
        end
        self.llTag.root:SetVisible(true)
        self.llTag:onDataChanged({
            bg = "set:bed_war_3_dress_store.json image:img_0_label_" .. tostring(item.level),
            text = item.day .. Lang:getString("gui.day")
        })
    end
end

return GUIDiscountShopConfirmItemWindow
