---@class GUIBedWarQualifyingSeasonChallengePanel2Window : IGUIWindow
local GUIBedWarQualifyingSeasonChallengePanel2Window = class("GUIBedWarQualifyingSeasonChallengePanel2Window", IGUIWindow)

---@type CQualifyingController
local CQualifyingController = T(Global, "CQualifyingController")
---@type QualifyingSeasonChallengeRewardConfig
local QualifyingSeasonChallengeRewardConfig = T(Global, "QualifyingSeasonChallengeRewardConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")

local ShowType = {
    Icon = 1,
    Actor = 2
}

---@private
function GUIBedWarQualifyingSeasonChallengePanel2Window:ctor(...)
    self.super.ctor(self, "BedWarQualifyingSeasonChallengePanel2.json", ...)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel2Window:onLoad()
    self.maxShowScore = 99999999
    self.iconMovePos = 0
    self.iconMoveGap = 2
    self.btnQuestion = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Question", GUIType.Button)
    self.awActor = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Actor", GUIType.ActorWindow)
    self.llActorTouch = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-ActorTouch", GUIType.Layout)
    self.llRewardLayout = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Reward-Layout", GUIType.Layout)
    self.stScoreText = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Score-Text", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Score", GUIType.StaticText)
    self.stHint = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Hint", GUIType.StaticText)
    self.llRewardContent = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Reward-Content", GUIType.Layout)
    self.pbScoreLine = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-ScoreLine", GUIType.ProgressBar)
    self.siImage = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Image", GUIType.StaticImage)
    self.siImageBack = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Image-Top", GUIType.StaticImage)
    self.llDesc = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Desc", GUIType.Layout)
    self.tvDescName = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Desc-Name", GUIType.StaticText)
    self.tvDescText = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-Desc-Text", GUIType.StaticText)

    self.siEndRewardImage = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-EndReward-Image", GUIType.StaticImage)
    self.siEndRewardScoreBg = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-EndReward-Score-Bg", GUIType.StaticImage)
    self.stEndRewardScore = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-EndReward-Score", GUIType.StaticText)
    self.siEndRewardEffect = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-EndReward-Effect", GUIType.StaticImage)
    self.siEndRewardMask = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-EndReward-Mask", GUIType.StaticImage)
    self.siEndRewardSelected = self:getChildWindowByName("BedWarQualifyingSeasonChallengePanel2-EndReward-Selected", GUIType.StaticImage)

    self:initView()
    self:initEvent()
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel2Window:initView()
    self.stScoreText:SetText(Lang:getString("gui.qualifying.challenge.score"))
    self.stScore:SetText("0")
    self.stHint:SetText(Lang:getString("gui.qualifying.challenge.score.hint"))
    self.siImage:SetVisible(false)
    self.llDesc:SetVisible(false)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel2Window:initEvent()
    self.btnQuestion:registerEvent(GUIEvent.ButtonClick, function()
        CustomDialog.builder()
                    .setTitleText("gui.qualifying.challenge.rule.title")
                    .setContentText(Lang:getString("gui.qualifying.challenge.rule.content"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .setContentAlign(HorizontalAlignment.Left)
                    .show()
    end)
    self:registerEvent(Events.UpdateChallengeReceiveRecordEvent, function()
        if not self.root:IsVisible() or not self.rewardAdapter then
            return
        end
        if self.curRewardDetailId then
            self:showRewardDetail(self.curRewardDetailId)
        else
            self.rewardAdapter:notifyDataChange()
        end
        self.stScore:SetText(CQualifyingController:getChallengeScore(Define.GameMode.Qualifying))
        local qualifyingData = CQualifyingController:getQualifyingData()
        if not qualifyingData then
            return
        end
        local items = QualifyingSeasonChallengeRewardConfig:getCfgBySeason(qualifyingData.quarter)
        self:updateScoreLineUI(items)
    end)

    self.siEndRewardImage:registerEvent(GUIEvent.Click, function()
        local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
        if score >= self.endReward.Score then
            if not CQualifyingController:sendReceiveChallengeReward(Define.GameMode.Qualifying, self.endReward.Id) then
                self.lvRewardList:getItemByIndex(1):setSelectId(self.endReward.ShowDetailId)
                GUIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(self.endReward.ShowDetailId)
            end
        else
            self.lvRewardList:getItemByIndex(1):setSelectId(self.endReward.ShowDetailId)
            GUIBedWarQualifyingSeasonChallengeLayout:showRewardDetail(self.endReward.ShowDetailId)
        end
    end)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel2Window:onShow()
    self.stScore:SetText(math.min(self.maxShowScore, CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)))
    self:initRewardList()
end

function GUIBedWarQualifyingSeasonChallengePanel2Window:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

---@private
function GUIBedWarQualifyingSeasonChallengePanel2Window:initRewardList()
    if self.lvRewardList ~= nil then
        if #self.rewardAdapter.data > 0 then
            self.lvRewardList:getItemByIndex(1):setSelectId(-1)
            self:showRewardDetail(6020003)
        end
        self:showFirstCanReceiveRewardPosition()
        return
    end
    self.lvRewardList = IGUIListView.new("BedWarQualifyingSeasonChallenge-Reward-List", self.llRewardContent, nil, Orientation.Horizontal)
    ---@type BedWarQualifyingSeasonChallengeRewardAdapter2
    self.rewardAdapter = UIHelper.newGameAdapter("BedWarQualifyingSeasonChallengeRewardAdapter2")

    self.lvRewardList:setAdapter(self.rewardAdapter)
    local qualifyingData = CQualifyingController:getQualifyingData()
    if not qualifyingData then
        return
    end
    local items = QualifyingSeasonChallengeRewardConfig:getCfgBySeason(qualifyingData.quarter)
    self.rewardAdapter:setData(items)

    self.siEndRewardSelected:SetVisible(false)
    ---@type QualifyingSeasonChallengeRewardData[]
    self.rewards = items
    if #self.rewards > 0 then
        self.endReward = self.rewards[#self.rewards]
        local showDetail = RewardItemShowDetailConfig:getConfigById(self.endReward.ShowDetailId)
        if showDetail then
            self.siEndRewardImage:SetImage(showDetail.image)
        end
        self.stEndRewardScore:SetText(self.endReward.Score)
    end

    self.curOffset = 0
    self.lineLength = self.lvRewardList:getItemCount() * 136
    self.maxOffset = self.lineLength - 68 - self.lvRewardList.root:GetPixelSize().x
    self.lvRewardList.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
        if math.abs(args.offset) > self.maxOffset then
            self.lvRewardList.root:SetScrollOffset(-self.maxOffset)
            return
        end
        if self.curOffset == args.offset then
            return
        end
        self.curOffset = args.offset
        self:updateScoreLineUI(items)
    end)
    if #items > 0 then
        self.maxShowScore = items[#items].Score
        self.lvRewardList:getItemByIndex(1):setSelectId(items[#items].Id)
        self:showRewardDetail(items[#items].ShowDetailId)
    end
    self.stScore:SetText(math.min(self.maxShowScore, CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)))
    self.pbScoreLine:SetWidth({ 0, self.lineLength })
    self:updateScoreLineUI(items)
    self:showFirstCanReceiveRewardPosition()
end

function GUIBedWarQualifyingSeasonChallengePanel2Window:showFirstCanReceiveRewardPosition()
    local firstReceivedIndex = -1
    for index, reward in pairs(self.rewards) do
        if not CQualifyingController:isChallengeRewardReceived(Define.GameMode.Qualifying, reward.Id) then
            firstReceivedIndex = index
            break
        end
    end
    if firstReceivedIndex == -1 then
        firstReceivedIndex = #self.rewards - 1
    else
        firstReceivedIndex = firstReceivedIndex - 1
    end
    local offset = -math.min(firstReceivedIndex * 136, self.maxOffset)
    local times = math.floor(math.abs((offset - self.curOffset) / 300))
    if times <= 0 then
        return
    end
    LuaTimer:scheduleTickerWithEnd(function()
        self.rewardAdapter:setScrollOffset(self.curOffset - 300)
    end, function()
        local scoreOffset = self.lvRewardList.root:GetScrollOffset()
        if scoreOffset > offset then
            self.rewardAdapter:setScrollOffset(scoreOffset + 78)
            self.rewardAdapter:setScrollOffset(offset)
        else
            self.rewardAdapter:setScrollOffset(offset)
        end
    end, 1, times)

end

---@private
---@param items QualifyingSeasonChallengeRewardData[]
function GUIBedWarQualifyingSeasonChallengePanel2Window:updateScoreLineUI(items)
    self.pbScoreLine:SetXPosition({ 0, math.min(self.curOffset, 0) })
    local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
    if score == 0 then
        self.pbScoreLine:SetProgress(0)
        return
    end
    local count = #items
    local percent = 1 / count
    local progress = -percent / 2
    if self.curOffset > 0 then
        progress = progress + (self.curOffset / 136) * percent
    end
    for i, item in pairs(items) do
        if item.Score <= score then
            progress = progress + percent
        else
            if i == 1 then
                progress = progress + (score / item.Score) * percent
            else
                local pre = items[i - 1]
                progress = progress + ((score - pre.Score) / (item.Score - pre.Score)) * percent
            end
            break
        end
    end
    self.pbScoreLine:SetProgress(progress)
end

function GUIBedWarQualifyingSeasonChallengePanel2Window:showRewardDetail(rewardDetailId)
    self.curRewardDetailId = rewardDetailId
    local reward = RewardItemShowDetailConfig:getConfigById(rewardDetailId)
    if not reward then
        self:hide()
        return
    end
    if self.endReward then
        local score = CQualifyingController:getChallengeScore(Define.GameMode.Qualifying)
        local isRewardReceived = CQualifyingController:isChallengeRewardReceived(Define.GameMode.Qualifying, self.endReward.Id)
        self.siEndRewardEffect:SetVisible(false)
        if score >= self.endReward.Score then
            self.siEndRewardScoreBg:SetImage("set:game_activity_score_1.json image:img_0_bardot_get")
            self.stEndRewardScore:SetText("▢FF481705" .. self.endReward.Score)
            self.siEndRewardEffect:SetVisible(true)
        else
            self.siEndRewardScoreBg:SetImage("set:game_activity_score_1.json image:img_0_bardot_normal")
            self.stEndRewardScore:SetText(self.endReward.Score)
        end
        if isRewardReceived then
            self.siEndRewardMask:SetVisible(true)
            self.siEndRewardEffect:SetVisible(false)
        else
            self.siEndRewardMask:SetVisible(false)
        end
        self.siEndRewardSelected:SetVisible(rewardDetailId == self.endReward.ShowDetailId)
    end

    self.llDesc:SetVisible(true)
    self.tvDescName:SetText(Lang:getString(reward.name))
    self.tvDescText:SetText(Lang:getString(reward.desc))
    self.siImage:SetVisible(reward.showType == ShowType.Icon)
    self.awActor:SetVisible(reward.showType == ShowType.Actor)
    if reward.showType == ShowType.Icon then
        self:setIcon(reward)
    elseif reward.showType == ShowType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, reward, self.llActorTouch)
    end
    self.rewardAdapter:notifyDataChange()
end

function GUIBedWarQualifyingSeasonChallengePanel2Window:setIcon(reward)
    self.siImage:SetYPosition({ -0.05, self.iconMovePos })
    if reward.scale and reward.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageTop, reward.image, 200, 200, reward.scale)
        UIHelper:setImageAdjustSize(self.siImageBack, reward.image, 200, 200, reward.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageTop, reward.image, 200, 200)
        UIHelper:setImageAdjustSize(self.siImageBack, reward.image, 200, 200)
    end

    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ -0.05, self.iconMovePos })
    end, 100)
end

return GUIBedWarQualifyingSeasonChallengePanel2Window
