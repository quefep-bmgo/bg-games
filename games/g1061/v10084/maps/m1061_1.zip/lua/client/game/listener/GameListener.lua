---@type WeakGuideControl
local WeakGuideControl = T(Global, "WeakGuideControl")

local function setPlayerMPCanUpdate(times)
    local player = Blockman.Instance():getPlayer()
    if not player then
        return
    end
    if not Blockman.Instance():isGameReady() then
        player:setCanUpdate(false)
        LuaTimer:schedule(function()
            setPlayerMPCanUpdate(times)
        end, 0)
        return
    end
    local position = player:getPosition()
    position.y = position.y - player:getYOffset() + 0.5
    position = VectorUtil.toVector3i(position)
    for i = 0, 3 do
        local blockPos = VectorUtil.newVector3i(position.x, position.y - i, position.z)
        if EngineWorld:getBlockId(blockPos) ~= BlockID.AIR then
            player:setCanUpdate(true)
            return
        end
    end
    player:setCanUpdate(false)
    LuaTimer:schedule(function()
        if times < 10 then
            setPlayerMPCanUpdate(times + 1)
        else
            Blockman.Instance():getPlayer():setCanUpdate(true)
        end
    end, 1000)
end

GameListener = {}

function GameListener:init()
    BaseListener.registerCallBack(CEvents.GameReadyEvent, self.onGameReady)
    BaseListener.registerCallBack(CEvents.GameActionTriggerEvent, self.onGameActionTriggerEvent)
    BaseListener.registerCallBack(CEvents.GameMainTickEvent, function(frameTime)
        if isGameStart then
            WeakGuideControl:onTick(frameTime)
        end
    end)
    BaseListener.registerCallBack(CEvents.LuaLoadWorldEndEvent, self.onLuaLoadWorldEnd)

    CommonDataEvents:registerCallBack("MapId", function(mapId)
        GameConfig.mapId = tonumber(mapId)
        if ResourcePointConfig and PublicResourceConfig then
            PublicResourceConfig:init(FileUtil.getConfigFromCsv("setting/PublicResource.csv"))
            ResourcePointConfig:init(FileUtil.getConfigFromCsv("setting/ResourcePoint.csv"))
        end
    end)

    CommonDataEvents:registerCallBack("GameStart", self.onGameStart, DataBuilderProcessor)
    CommonDataEvents:registerCallBack("BuyKeepItem", self.onBuyKeepItem, DataBuilderProcessor)
    CommonDataEvents:registerCallBack("BuyRespawn", self.onBuyRespawn, DataBuilderProcessor)
    CommonDataEvents:registerCallBack("synWatcherResource", self.onSynResource, JsonBuilderProcessor)
end

function GameListener.onGameReady()
    BaseGameConfig:init()
    GameConfig:loadConfig()
    ---@type CustomSceneConfig
    local CustomSceneConfig = T(Global, "CustomSceneConfig")
    CustomSceneConfig:gameReady()
    require "common.data.ClientRecharge"
    require "common.listener.PluginListener"
    require "game.data.ClientTeamResource"
    require "ui.GUIFactory"
    require "game.data.GMBedWar"
    TreasureChallenge:init()
    ClientHelper.putFloatPrefs("BowPullingSpeedMultiplier", GameConfig.bowSpeedMultiplier)
    ClientHelper.putFloatPrefs("BowPullingFOVMultiplier", GameConfig.bowFOVMultiplier)
end

function GameListener.onGameActionTriggerEvent(type)
    if type == CDefine.GameActionType.GAME_ACTION_SHARE_FINISHED
            or type == CDefine.GameActionType.GAME_ACTION_SHARE_CANCEL then
        GUIResult:onShare(false)
        GUIResult8P:onShare(false)
        GUISettlementSingle:onShare(false)
    end
end

---@param data DataBuilder
function GameListener.onGameStart(data)
    local gameTime = data:getNumberParam("gameTime") or 0
    isGameStart = true
    --GUIBattleInfo:onGameStart()
    GUIBedWarToolBar:onGameStart()
    ClientStore:onGameStart()
    ResourcePointConfig:onGameStart(gameTime)
    local userTeam = json.decode(data:getParam("userTeam") or "{}")
    local gameId = data:getParam("gameId") or ""
    Events.StartGameEvent:invoke(userTeam, gameId)

    local useHollowBlockHeight = data:getNumberParam("useHollowBlockHeight")
    local startGlideHeight = data:getNumberParam("startGlideHeight")
    local glideDuration = data:getNumberParam("glideDuration")
    if useHollowBlockHeight and startGlideHeight and glideDuration then
        GameConfig.useHollowBlockHeight = useHollowBlockHeight
        GameConfig.startGlideHeight = startGlideHeight
        GameConfig.glideDuration = glideDuration
        LuaTimer:scheduleTimer(function()
            ---@type ClientPlayer
            local player = PlayerManager:getClientPlayer()
            player:checkHollowBlock()
        end, 250)
    end
end

function GameListener.onBuyKeepItem(data)
    local time = data:getNumberParam("time")
    local price = data:getNumberParam("price")
    local timer = LuaTimer:schedule(function()
        CustomDialog.hide()
    end, time * 1000)
    LuaTimer:schedule(function()
        CustomDialog.setRightDisable(true)
    end, 700)
    local havePrivilege = Privilege.checkHavePrivilege(105)
    CustomDialog.builder()
    if havePrivilege then
        CustomDialog.setContentText(Lang:getString("gui_dialog_tip_keep_item_and_revive_sure"))
                    .setLeftText("gui_bed_war_anon_revive")
                    .setRightText("gui_dialog_tip_revive_privilege_sure")
    else
        CustomDialog.setContentText(Lang:getString("gui_dialog_tip_keep_item_msg"))
                    .setLeftText("gui_dialog_tip_keep_item_cancel")
                    .setRightText("gui_dialog_tip_keep_item_sure")
    end
    CustomDialog.setExtraInfo(PayHelper.getMoneyIcon(Define.Money.DIAMOND), tostring(price))
                .setLeftClickListener(function()
        LuaTimer:cancel(timer)
        GamePacketSender:sendBuyKeepItem(false)
    end)        .setCloseClickListener(function()
        LuaTimer:cancel(timer)
        GamePacketSender:sendBuyKeepItem(false)
    end)
                .setRightClickListener(function()
        LuaTimer:cancel(timer)
        local canBuyKeepItem = true
        PayHelper.checkMoney(Define.Money.DIAMOND, price, function(canBuy)
            if canBuy then
                GamePacketSender:sendBuyKeepItem(true)
            end
            canBuyKeepItem = canBuy
        end)
        return not canBuyKeepItem
    end)
                .setRightDisable(false)
                .show()
end

function GameListener.onBuyRespawn(data)
    local time = data:getNumberParam("time")
    local price = data:getNumberParam("price")
    local timer = LuaTimer:schedule(function()
        CustomDialog.hide()
    end, time * 1000)
    LuaTimer:schedule(function()
        CustomDialog.setRightDisable(true)
    end, 700)
    CustomDialog.builder()
                .setContentText(Lang:getString("gui_dialog_tip_keep_item_and_revive_sure"))
                .setLeftText("gui_dialog_tip_revive_cancel")
                .setRightText("gui_dialog_tip_revive_privilege_sure")
                .setExtraInfo(PayHelper.getMoneyIcon(Define.Money.DIAMOND), tostring(price))
                .setLeftClickListener(function()
        LuaTimer:cancel(timer)
        GamePacketSender:sendBuyRespawn(false)
    end)
                .setCloseClickListener(function()
        LuaTimer:cancel(timer)
        GamePacketSender:sendBuyRespawn(false)
    end)
                .setRightClickListener(function()
        LuaTimer:cancel(timer)
        local canBuySpawn = true
        PayHelper.checkMoney(Define.Money.DIAMOND, price, function(canBuy)
            if canBuy then
                GamePacketSender:sendBuyRespawn(true)
            end
            canBuySpawn = canBuy
        end)
        return not canBuySpawn
    end)
                .setRightDisable(false)
                .show()
end

function GameListener.onSynResource(data)
    ResourcePointConfig:setWatcherResource(data)
end

function GameListener.onLuaLoadWorldEnd()
    setPlayerMPCanUpdate(0)
end

