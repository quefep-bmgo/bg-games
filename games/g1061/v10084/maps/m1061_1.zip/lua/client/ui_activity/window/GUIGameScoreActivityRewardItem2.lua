---@class GUIGameScoreActivityRewardItem2Window : IGUIWindow
local GUIGameScoreActivityRewardItem2Window = class("GUIGameScoreActivityRewardItem2Window", IGUIWindow)

local QualityBgImage = {
    [1] = "set:game_activity_score_2.json image:img_0_itembd_blue",
    [2] = "set:game_activity_score_2.json image:img_0_itembd_purple",
    [3] = "set:game_activity_score_2.json image:img_0_itembd_yellow",
}

---@private
function GUIGameScoreActivityRewardItem2Window:ctor(_, mgr)
    self.super.ctor(self, "GameScoreActivityRewardItem2.json", mgr)
end

---@private
---@param mgr CScoreActivityMgr
function GUIGameScoreActivityRewardItem2Window:onLoad(mgr)
    self.mgr = mgr
    self.siBg = self:getChildWindowByName("GameScoreActivityRewardItem2", GUIType.StaticImage)
    self.siImage = self:getChildWindowByName("GameScoreActivityRewardItem2-Image", GUIType.StaticImage)
    self.stCount = self:getChildWindowByName("GameScoreActivityRewardItem2-Count", GUIType.StaticText)
    self.siLimitIcon = self:getChildWindowByName("GameScoreActivityRewardItem2-LimitIcon", GUIType.StaticImage)
    self.stLimit = self:getChildWindowByName("GameScoreActivityRewardItem2-Limit", GUIType.StaticText)
    self.stScore = self:getChildWindowByName("GameScoreActivityRewardItem2-Score", GUIType.StaticText)
    self.stPriceAdd = self:getChildWindowByName("GameScoreActivityRewardItem2-Add", GUIType.StaticText)
    self.siPriceIcon = self:getChildWindowByName("GameScoreActivityRewardItem2-PriceIcon", GUIType.StaticImage)
    self.stPrice = self:getChildWindowByName("GameScoreActivityRewardItem2-Price", GUIType.StaticText)
    self.llMask = self:getChildWindowByName("GameScoreActivityRewardItem2-Mask", GUIType.Layout)
    self.siSelected = self:getChildWindowByName("GameScoreActivityRewardItem2-Selected", GUIType.StaticImage)
    self:initView()
    self:initEvent()
end

---@private
function GUIGameScoreActivityRewardItem2Window:initView()
    self.stPriceAdd:SetText("+")
end

---@private
function GUIGameScoreActivityRewardItem2Window:initEvent()
    self.siBg:registerEvent(GUIEvent.Click, function()
        if not self.data then
            return
        end
        Events.ShowScoreActivityRewardDetailEvent:invoke(self.mgr.mainConfig.activityId, self.data)
    end)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityRewardItem2Window:onDataChanged(data)
    self.data = data
    UIHelper:setImageAdjustSize(self.siImage, data.reward.image, 80, 80, tonumber(data.reward.imageScale))
    if data.reward.imageXOffset ~= "#" then
        self.siImage:SetXPosition({ 0, data.reward.imageXOffset })
    end
    if data.reward.imageYOffset ~= "#" then
        self.siImage:SetYPosition({ 0, data.reward.imageYOffset })
    end
    if data.reward.numLang ~= "#" then
        self.stCount:SetText("x" .. Lang:getString(data.reward.numLang))
    else
        self.stCount:SetText("")
    end
    self.stScore:SetText(data.score)
    if data.price <= 0 then
        self.siPriceIcon:SetVisible(false)
        self.stPriceAdd:SetVisible(false)
    else
        self.stPriceAdd:SetVisible(true)
        self.siPriceIcon:SetVisible(true)
        local width = self.stScore:GetTextWidth()
        self.stPriceAdd:SetXPosition({ 0, 32 + width })
        self.siPriceIcon:SetXPosition({ 0, 52 + width })
        self.siPriceIcon:SetImage(PayHelper.getMoneyIcon(data.priceType))
        self.stPrice:SetText(data.price)
    end
    if data.limit <= 0 then
        self.siLimitIcon:SetVisible(false)
    else
        self.siLimitIcon:SetVisible(data.limit > 1)
        local limit = self.mgr:getRewardLimit(data)
        if limit > 0 then
            self.stLimit:SetText(limit .. "/" .. data.limit)
            self.llMask:SetVisible(false)
        else
            self.llMask:SetVisible(true)
            self.stLimit:SetText(TextFormat.colorRed .. "0" .. TextFormat.colorWrite .. "/" .. data.limit)
        end
        self.siLimitIcon:SetXPosition({ 0, -self.stLimit:GetTextWidth() - 8 })
    end
    self.siBg:SetImage(QualityBgImage[self.data.quality] or QualityBgImage[1])
    self.siSelected:SetVisible(self.mgr.curShowRewardId == data.id)
end

return GUIGameScoreActivityRewardItem2Window
