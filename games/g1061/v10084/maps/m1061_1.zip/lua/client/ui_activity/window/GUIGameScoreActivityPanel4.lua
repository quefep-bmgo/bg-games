---@class GUIGameScoreActivityPanel4Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameScoreActivityPanel4Window = class("GUIGameScoreActivityPanel4Window", GUICommonActivityPanel)
---@type ScoreActivityConfig
local ScoreActivityConfig = T(Global, "ScoreActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

local ShowType = {
    Icon = 1,
    Actor = 2
}

---@private
function GUIGameScoreActivityPanel4Window:ctor(...)
    self.json_name = "GameScoreActivityPanel4.json"
    self.super.ctor(self, "GameScoreActivityPanel4.json", ...)
end

---@private
function GUIGameScoreActivityPanel4Window:onChildLoad()
    ---@type CScoreActivityMgr
    self.mgr = self.mgr
    self.iconMovePos = 0
    self.iconMoveGap = 2
    self.siTitleImage = self:getChildWindowByName("GameScoreActivityPanel4-TitleImage", GUIType.StaticImage)
    self.siQuestion = self:getChildWindowByName("GameScoreActivityPanel4-Question", GUIType.StaticImage)
    self.llTaskPanelClip = self:getChildWindowByName("GameScoreActivityPanel4-TaskPanel-Clip", GUIType.Layout)
    self.siTaskPanel = self:getChildWindowByName("GameScoreActivityPanel4-TaskPanel", GUIType.StaticImage)
    self.llTaskPanelTouch = self:getChildWindowByName("GameScoreActivityPanel4-TaskPanel-Touch", GUIType.Layout)
    self.stDailyTaskText = self:getChildWindowByName("GameScoreActivityPanel4-DailyTaskText", GUIType.StaticText)
    self.stTaskTimeText = self:getChildWindowByName("GameScoreActivityPanel4-Task-Time-Text", GUIType.StaticText)
    self.llTaskContent = self:getChildWindowByName("GameScoreActivityPanel4-TaskContent", GUIType.Layout)
    self.btnExchange = self:getChildWindowByName("GameScoreActivityPanel4-Exchange", GUIType.Button)
    self.siImage = self:getChildWindowByName("GameScoreActivityPanel4-Image", GUIType.StaticImage)
    self.siImageBack = self:getChildWindowByName("GameScoreActivityPanel4-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindowByName("GameScoreActivityPanel4-Image-Top", GUIType.StaticImage)
    self.stScoreText = self:getChildWindowByName("GameScoreActivityPanel4-ScoreText", GUIType.StaticText)
    ---@type GUIGameScoreActivityRewardItem4Window[]
    self.rewardItems = {}
    self:initView()
    self:initEvent()
end

function GUIGameScoreActivityPanel4Window:onShow()
    GUIGameActivityLayout:hideTitle()
    self.btnExchange:SetEnabled(false)
    self.siImage:SetVisible(false)
    self.awActor:SetVisible(false)
    self.super.showRewardDetail(self)
    self:refreshUI()
    ReportEvent.display_discount_shop_panel(self.mgr.config.id)
end

---@private
function GUIGameScoreActivityPanel4Window:initView()
    self.isTaskPanelOpen = false
    self.siTaskPanel:SetImage("")
    self.siImage:SetVisible(false)
    self.stDailyTaskText:SetText(Lang:getString("gui.daily.task"))
    self.btnExchange:SetText(Lang:getString("gui.exchange"))
    self.siTitleImage:SetImage(UIUtils.GetLangImage("set:game_activity_score_4.json image:text"))

    local tasks = TaskConfig:getTaskByGroupId(self.mgr.config.taskGroupId) or {}
    table.sort(tasks, function(t1, t2)
        return t1.Id < t2.Id
    end)
    for i = #tasks, 1, -1 do
        local task = tasks[i]
        task.Image = Define.DailyTaskIcon[task.TaskTypeId]
    end
    local count = math.min(#tasks, 6)
    self.llTaskPanelClip:SetHeight({ 0, count * 62 - 2 })
    self.siTaskPanel:SetHeight({ 0, count * 62 + 42 })
    self.lvTaskList = IGUIListView.new("GameScoreActivityPanel4-TaskList" .. self.activity.activityId, self.llTaskContent)
    self.lvTaskList:setItemSpace(4)
    for _, task in pairs(tasks) do
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = UIHelper.requireGUIWindow("GUIGameScoreActivityTaskItem", false, "ui_activity").new(self)
        item:setUIStyle(
                "set:game_activity_score_4.json image:img_0_snow", VectorUtil.newVector2(36, 37),
                "set:game_activity_score_4.json image:img_0_iconbd", VectorUtil.newVector2(54, 60),
                nil, "set:game_activity_score_4.json image:img_9_listbd")
        item.siRight:SetVerticalAlignment(VerticalAlignment.Top)
        item.stDesc:SetTextColor({ 13 / 255, 60 / 255, 110 / 255, 1 })
        item.stDesc:SetProperty("Font", "HT12")
        item.stTaskProgress:SetTextColor({ 13 / 255, 60 / 255, 110 / 255, 1 })
        item.siScoreIcon:SetXPosition({ 0, 9 })
        item.siTaskIcon:SetArea({ 0, 0 }, { 0, 0 }, { 0, 40 }, { 0, 40 })
        item.stScore:SetXPosition({ 0, 30 })
        item.stScore:SetTextColor({ 1, 1, 1, 1 })
        item.stScore:SetBordered(true)
        item.stScore:SetProperty("TextBorderColor", "0.05098 0.23529 0.43137 1")
        item.root:SetHeight({ 0, 56 })
        item:onDataChanged(task)
        self.lvTaskList:addItem(item)
    end
    local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
    self.rewards = rewards
    ---@type GUIGameScoreActivityRewardItem4Window
    local GUIGameScoreActivityRewardItem4 = UIHelper.requireGUIWindow("GUIGameScoreActivityRewardItem4", false, "ui_activity")
    for index, reward in pairs(self.rewards) do
        if index > 10 then
            return
        end
        local llReward = self:getChildWindowByName("GameScoreActivityPanel4-Reward" .. index, GUIType.Layout)
        if llReward then
            local item = GUIGameScoreActivityRewardItem4.new("", self.mgr)
            item:onDataChanged(reward)
            llReward:AddChildWindow(item.root)
            self.rewardItems[index] = item
        end
    end
end

---@private
function GUIGameScoreActivityPanel4Window:initEvent()
    self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
        if not self.curShowReward then
            return
        end
        if self.mgr:getScore() < self.curShowReward.score then
            CustomDialog.builder()
                        .setContentText(Lang:getString("gui.lack.of.score." .. self:getActivityById()))
                        .setHideLeftButton()
                        .show()
            return
        end
        local function tryGetReward()
            DiscountShopConfirmContent:setGoodsList({ self.curShowReward }, self.curShowReward.score, "set:game_activity_score_4.json image:img_0_snow")
            CustomDialog.builder()
                        .setTitleText("discount.shop.buy.title")
                        .setContentView(DiscountShopConfirmContent)
                        .setRightClickListener(function()
                self.mgr:tryGetReward(self.curShowReward.id)
            end)        .show()
        end
        if self.curShowReward.price > 0 then
            PayHelper.checkMoney(self.curShowReward.priceType, self.curShowReward.price, function(success)
                if success then
                    tryGetReward()
                end
            end)
        else
            tryGetReward()
        end
    end)

    self.llTaskPanelTouch:registerEvent(GUIEvent.Click, function(events)
        if self.isTaskPanelOpen then
            self:changeTaskPanel()
            Game:handleTouchClick(events.position.x, events.position.y)
        end
    end)

    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("score.activity.help.title.4")
                    .setContentText(Lang:getString("score.activity.help.content.4"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self.mgr:registerCacheChange(function()
        if self:isShow() then
            self:refreshUI()
        else
            self:updateRedPoint()
        end
    end)
    self:registerEvent(Events.ShowScoreActivityRewardDetailEvent, function(activityId, data)
        if self:getActivityById() ~= activityId then
            return
        end
        self:showCurRewardDetail(data)
    end)
    self:registerEvent(Events.ScoreActivityTaskUpdateEvent, function(activityId, taskId, progress, status)
        if self:getActivityById() ~= activityId then
            return
        end
        ---@type GUIGameScoreActivityTaskItemWindow
        local item = self.lvTaskList:getItem("taskId", taskId)
        if item then
            item:setTaskInfo(progress, status)
        end
    end)
end

---@private
function GUIGameScoreActivityPanel4Window:refreshUI()
    if self.curShowReward then
        self:showCurRewardDetail(self.curShowReward)
    else
        for _, item in pairs(self.rewardItems) do
            item:onDataChanged(item.data)
        end
    end
    self:updateRedPoint()
    self.stScoreText:SetText(self.mgr:getScore())
    self.lvTaskList:setItemSpace(4)
end

---@private
function GUIGameScoreActivityPanel4Window:updateRedPoint()
    local count = 0
    for _, reward in pairs(self.rewards) do
        local limit = self.mgr:getRewardLimit(reward)
        if (limit > 0 or limit < 0)
                and self.mgr:getScore() >= reward.score
                and reward.price <= 0 then
            count = count + 1
        end
    end
    UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityPanel4Window:showCurRewardDetail(data)
    self.curShowReward = data
    self.btnExchange:SetVisible(true)
    self.btnExchange:SetEnabled(self.mgr:getRewardLimit(self.curShowReward) > 0)
    self.mgr.curShowRewardId = self.curShowReward.id
    for _, item in pairs(self.rewardItems) do
        item:onDataChanged(item.data)
    end
    local rewardDetail = RewardItemShowDetailConfig:getConfigById(data.reward.showDetailId)
    if not rewardDetail then
        self:setIcon(data.reward)
        self.tvName:SetText(Lang:getString(data.reward.name))
        self.siImage:SetVisible(true)
        self.awActor:SetVisible(false)
        return
    end
    self.tvName:SetText(Lang:getString(rewardDetail.name))
    self.siImage:SetVisible(rewardDetail.showType == ShowType.Icon)
    self.awActor:SetVisible(rewardDetail.showType == ShowType.Actor)
    if rewardDetail.showType == ShowType.Icon then
        self:setIcon(rewardDetail)
    elseif rewardDetail.showType == ShowType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, rewardDetail, self.llSlideBlock)
    end
end

---@private
---@param rewardDetail RewardItemShowDetailItem
function GUIGameScoreActivityPanel4Window:setIcon(rewardDetail)
    self.siImage:SetYPosition({ 0, self.iconMovePos })
    self.siImage:SetImage("")
    if rewardDetail.scale and rewardDetail.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180, rewardDetail.scale)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180, rewardDetail.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180)
    end
    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ 0, self.iconMovePos })
    end, 100)
    self:addTimer(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel4Window:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel4Window:onTick()
    if not self.isTaskPanelOpen then
        return
    end
    local lastTime = DateUtil.getDayLeftSeconds()
    self.stTaskTimeText:SetText(DateUtil.getFormatTime(lastTime))
end

function GUIGameScoreActivityPanel4Window:changeTaskPanel()
    if self.locked then
        return
    end
    self.locked = true
    self.isTaskPanelOpen = not self.isTaskPanelOpen
    self.llTaskPanelTouch:SetVisible(self.isTaskPanelOpen)
    local count = math.min(self.lvTaskList:getChildCount(), 6)
    local startW, endW, startH, endH
    if self.isTaskPanelOpen then
        startW = 85
        endW = 352
        startH = count * 62 - 2
        endH = count * 62 + 42
        self.llTaskPanelClip:SetXPosition({ 0, -18 })
        self.llTaskPanelClip:SetYPosition({ 0, 81 })
        self.siTaskPanel:SetXPosition({ 0, 0 })
        self.siTaskPanel:SetYPosition({ 0, 0 })
        self:updateTaskUI()
    else
        startW = 352
        endW = 85
        startH = count * 62 + 42
        endH = count * 62 - 2
    end
    local offsetW = (endW - startW) / 8
    local offsetH = (endH - startH) / 8
    self:addTimer(LuaTimer:scheduleTickerWithEnd(function()
        startW = startW + offsetW
        startH = startH + offsetH
        self.llTaskPanelClip:SetWidth({ 0, startW })
        self.llTaskPanelClip:SetHeight({ 0, startH })
    end, function()
        self.locked = false
        if not self.isTaskPanelOpen then
            self.siTaskPanel:SetImage("")
            self.llTaskPanelClip:SetXPosition({ 0, -28 })
            self.llTaskPanelClip:SetYPosition({ 0, 91 })
            self.siTaskPanel:SetXPosition({ 0, 10 })
            self.siTaskPanel:SetYPosition({ 0, -10 })
            self.llSlideBlock:SetTouchable(true)
            self.lvTaskList.root:SetScrollOffset(0)
            self:updateTaskUI()
        else
            self.llSlideBlock:SetTouchable(false)
            self.siTaskPanel:SetImage("set:game_activity_score_4.json image:img_9_taskbd")
        end
    end, 1, 8))
end

function GUIGameScoreActivityPanel4Window:updateTaskUI()
    ---@param item GUIGameScoreActivityTaskItemWindow
    for _, item in pairs(self.lvTaskList.items) do
        item:updateUI()
    end
end

return GUIGameScoreActivityPanel4Window
