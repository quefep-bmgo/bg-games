---@class GUIGameScoreActivityPanel5Window : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIGameScoreActivityPanel5Window = class("GUIGameScoreActivityPanel5Window", GUICommonActivityPanel)
---@type ScoreActivityConfig
local ScoreActivityConfig = T(Global, "ScoreActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")
---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

local ShowType = {
    Icon = 1,
    Actor = 2
}

---@private
function GUIGameScoreActivityPanel5Window:ctor(...)
    self.json_name = "GameScoreActivityPanel5.json"
    self.super.ctor(self, "GameScoreActivityPanel5.json", ...)
end

---@private
function GUIGameScoreActivityPanel5Window:onChildLoad()
    ---@type CScoreActivityMgr
    self.mgr = self.mgr
    self.iconMovePos = 35
    self.iconMoveGap = 2
    self.siTitleImage = self:getChildWindowByName("GameScoreActivityPanel5-TitleImage", GUIType.StaticImage)
    self.siQuestion = self:getChildWindowByName("GameScoreActivityPanel5-Question", GUIType.StaticImage)
    self.btnExchange = self:getChildWindowByName("GameScoreActivityPanel5-Exchange", GUIType.Button)
    self.siImage = self:getChildWindowByName("GameScoreActivityPanel5-Image", GUIType.StaticImage)
    self.siImageBack = self:getChildWindowByName("GameScoreActivityPanel5-Image-Back", GUIType.StaticImage)
    self.siImageTop = self:getChildWindowByName("GameScoreActivityPanel5-Image-Top", GUIType.StaticImage)
    self.stScoreText = self:getChildWindowByName("GameScoreActivityPanel5-ScoreText", GUIType.StaticText)
    ---@type GUIGameScoreActivityRewardItem5Window[]
    self.rewardItems = {}
    self:initEvent()
    self:initView()
end

function GUIGameScoreActivityPanel5Window:onShow()
    GUIGameActivityLayout:hideTitle()
    self.btnExchange:SetEnabled(false)
    self.siImage:SetVisible(false)
    self.awActor:SetVisible(false)
    self.super.showRewardDetail(self)
    self:refreshUI()
    ReportEvent.display_discount_shop_panel(self.mgr.config.id)
end

---@private
function GUIGameScoreActivityPanel5Window:initView()
    self.siImage:SetVisible(false)
    self.btnExchange:SetText(Lang:getString("gui.exchange"))
    self.siTitleImage:SetImage(UIUtils.GetLangImage("set:game_activity_score_5.json image:text"))

    local rewards = ScoreActivityConfig:getRewardGroup(self.mgr.config.rewardGroupId)
    self.rewards = rewards
    ---@type GUIGameScoreActivityRewardItem5Window
    local GUIGameScoreActivityRewardItem5 = UIHelper.requireGUIWindow("GUIGameScoreActivityRewardItem5", false, "ui_activity")
    for index, reward in pairs(self.rewards) do
        if index > 6 then
            return
        end
        local llReward = self:getChildWindowByName("GameScoreActivityPanel5-Reward" .. index, GUIType.Layout)
        if llReward then
            local item = GUIGameScoreActivityRewardItem5.new("", self.mgr)
            item:onDataChanged(reward)
            llReward:AddChildWindow(item.root)
            self.rewardItems[index] = item
        end
    end
end

---@private
function GUIGameScoreActivityPanel5Window:initEvent()
    self.btnExchange:registerEvent(GUIEvent.ButtonClick, function()
        if not self.curShowReward then
            return
        end
        local function tryGetReward()
            DiscountShopConfirmContent:setGoodsList({ self.curShowReward }, self.curShowReward.price, PayHelper.getMoneyIcon(self.curShowReward.priceType))
            CustomDialog.builder()
                        .setTitleText("discount.shop.buy.title")
                        .setContentView(DiscountShopConfirmContent)
                        .setRightClickListener(function()
                self.mgr:tryGetReward(self.curShowReward.id)
            end)        .show()
        end
        if self.curShowReward.price > 0 then
            PayHelper.checkMoney(self.curShowReward.priceType, self.curShowReward.price, function(success)
                if success then
                    tryGetReward()
                else
                    if self.mgr.config.lackTipType ~= 0 then
                        CustomDialog.builder()
                                    .setContentText(Lang:getString("gui_score_lack_money_" .. self.mgr.mainConfig.moneyType))
                                    .setHideLeftButton()
                                    .setRightText("gui_score_lack_money_go_tip")
                                    .setRightClickListener(function()
                            if Plugins.CallTargetPluginFunc("cable_car", "checkPlayerOnCableCar", Game:getPlatformUserId()) then
                                return
                            end
                            if self.mgr.config.lackTipType ~= 0 then
                                PlayerManager:getClientPlayer():sendPacket({
                                    pid = "PlayerTicketTipGo",
                                    type = self.mgr.config.lackTipType,
                                    param = self.mgr.config.lackTipParam
                                })
                                GUIGameActivityLayout:hide(true)
                            end
                        end)
                                    .show()
                    else
                        CustomDialog.builder()
                                    .setContentText(Lang:getString("gui.lack.of.score." .. self:getActivityById()))
                                    .setHideLeftButton()
                                    .show()
                        return
                    end
                end
            end)
        else
            tryGetReward()
        end
    end)

    self.siQuestion:registerEvent(GUIEvent.Click, function()
        CustomDialog.builder()
                    .setContentAlign(HorizontalAlignment.Left, VerticalAlignment.Top)
                    .setTitleText("score.activity.help.title.5")
                    .setContentText(Lang:getString("score.activity.help.content.5"))
                    .setHideLeftButton()
                    .setHideRightButton()
                    .show()
    end)
    self.mgr:registerCacheChange(function()
        if self:isShow() then
            self:refreshUI()
        else
            self:updateRedPoint()
        end
    end)
    self:registerEvent(Events.ShowScoreActivityRewardDetailEvent, function(activityId, data)
        if self:getActivityById() ~= activityId then
            return
        end
        self:showCurRewardDetail(data)
    end)
end

---@private
function GUIGameScoreActivityPanel5Window:refreshUI()
    if self.curShowReward then
        self:showCurRewardDetail(self.curShowReward)
    else
        for _, item in pairs(self.rewardItems) do
            item:onDataChanged(item.data)
        end
    end
    self:updateRedPoint()
end

---@private
function GUIGameScoreActivityPanel5Window:updateRedPoint()
    local count = 0
    local money = PlayerWallet.getMoneyByCoinId(self.mgr.mainConfig.moneyType)
    for _, reward in pairs(self.rewards) do
        local limit = self.mgr:getRewardLimit(reward)
        if (limit > 0 or limit < 0)
                and money >= reward.price then
            count = count + 1
        end
    end
    UIUtils.updateRedDotCount(Define.RedDotKey.GameActivity .. "_" .. self.mgr.mainConfig.id, count)
end

---@param data ScoreActivityRewardData
function GUIGameScoreActivityPanel5Window:showCurRewardDetail(data)
    self.curShowReward = data
    self.btnExchange:SetVisible(true)
    self.btnExchange:SetEnabled(self.mgr:getRewardLimit(self.curShowReward) > 0)
    self.mgr.curShowRewardId = self.curShowReward.id
    for _, item in pairs(self.rewardItems) do
        item:onDataChanged(item.data)
    end
    local rewardDetail = RewardItemShowDetailConfig:getConfigById(data.reward.showDetailId)
    if not rewardDetail then
        self:setIcon(data.reward)
        self.siImage:SetVisible(true)
        self.awActor:SetVisible(false)
        return
    end
    self.siImage:SetVisible(rewardDetail.showType == ShowType.Icon)
    self.awActor:SetVisible(rewardDetail.showType == ShowType.Actor)
    if rewardDetail.showType == ShowType.Icon then
        self:setIcon(rewardDetail)
    elseif rewardDetail.showType == ShowType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awActor, rewardDetail, self.llSlideBlock)
    end
end

---@private
---@param rewardDetail RewardItemShowDetailItem
function GUIGameScoreActivityPanel5Window:setIcon(rewardDetail)
    self.siImage:SetYPosition({ 0, self.iconMovePos })
    self.siImage:SetImage("")
    if rewardDetail.scale and rewardDetail.scale ~= "#" then
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180, rewardDetail.scale)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180, rewardDetail.scale)
    else
        UIHelper:setImageAdjustSize(self.siImageBack, rewardDetail.image, 180, 180)
        UIHelper:setImageAdjustSize(self.siImageTop, rewardDetail.image, 180, 180)
    end
    LuaTimer:cancel(self.iconMoveTimer)
    self.iconMoveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos - 35) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siImage:SetYPosition({ 0, self.iconMovePos })
    end, 100)
    self:addTimer(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel5Window:onHide()
    LuaTimer:cancel(self.iconMoveTimer)
end

function GUIGameScoreActivityPanel5Window:onTick()
    self.stScoreText:SetText(tostring(PlayerWallet.getMoneyByCoinId(self.mgr.mainConfig.moneyType)))
end

return GUIGameScoreActivityPanel5Window
