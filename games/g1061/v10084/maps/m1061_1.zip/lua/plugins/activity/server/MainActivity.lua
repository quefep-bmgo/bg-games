---@type CommonActivityConfig
local CommonActivityConfig = Plugins.Require("activity", "common.config.CommonActivityConfig")

---@type ServerReportEvent
local ServerReportEvent = T(Global, "ReportEvent")

---@type SBaseActivityMgr
local BaseActivityMgr = Plugins.Require("activity", "server.mode.BaseActivityMgr")
Plugins.Require("activity", "server.mode.LuckyLotteryMgr")
Plugins.Require("activity", "server.mode.MustLotteryMgr")
Plugins.Require("activity", "server.mode.BlindBoxMgr")
Plugins.Require("activity", "server.mode.ScoreActivityMgr")
Plugins.Require("activity", "server.mode.AtLessLotteryMgr")
Plugins.Require("activity", "server.mode.DiscountShopActivityMgr")
Plugins.Require("activity", "server.mode.LimitDiscountShopMgr")
Plugins.Require("activity", "server.mode.CardLotteryMgr")

local PlayerActivityCache = {}

---@class SMainActivity
local MainActivity = {}
---@type SBaseActivityMgr[]
local CurrentActivity = {}
local PlayerMoneyCache = {}

function MainActivity:init(initFunc)
    DBManager:addMustLoadSubKey("PluginActivityData")
    local nowTime = os.time()
    for _, activity in pairs(CommonActivityConfig:getAllCommonActivity()) do
        if activity.endTime > nowTime then

            if activity.startTime < nowTime then
                self:addActivity(activity)
            else
                LuaTimer:schedule(function()
                    self:addActivity(activity)
                end, (activity.startTime - nowTime) * 1000)
            end
        end
    end
    for _, moneyConfig in pairs(CommonActivityConfig:getAllCommonMoney()) do
        self:registerPayFunction(moneyConfig.moneyType, function(player, uniqueId, coinId, price)
            local count = self:getMoney(player, coinId)
            if count < price then
                return false
            end
            self:setMoney(player, coinId, count - price)
            return true
        end)
    end
    if initFunc then
        initFunc(self)
    end
end

---@param activity CommonActivityData
function MainActivity:addActivity(activity)
    local mgr = BaseActivityMgr.createMgr(activity)
    CurrentActivity[tostring(activity.id)] = mgr
    local endSecond = activity.endTime - os.time()
    LuaTimer:schedule(function()
        self:removeActivity(activity.id)
    end, endSecond * 1000)
    for _, player in pairs(PlayerManager:getPlayers()) do
        player:sendPacket({
            pid = "PluginAddActivity",
            activityId = activity.id
        })
        mgr:onPlayerReady(player, {})
    end
end

function MainActivity:removeActivity(activityId)
    local mgr = CurrentActivity[tostring(activityId)]
    ---活动结束, 所有玩家对该活动完成最后一次存储.
    for _, player in pairs(PlayerManager:getPlayers()) do
        local activityCache = PlayerActivityCache[tostring(player.userId)]
        if activityCache then
            local activityData = mgr:getPlayerMainCache(player)
            TableUtil.mergeTable(activityData, mgr:getPlayerCache(player), activityData)
            activityCache.activity[activityId] = activityData
        end
    end
    CurrentActivity[tostring(activityId)] = nil
    for _, player in pairs(PlayerManager:getPlayers()) do
        player:sendPacket({
            pid = "PluginRemoveActivity",
            activityId = activityId
        })
    end
end

function MainActivity:getActivity(activityId)
    return CurrentActivity[tostring(activityId)]
end

---@param player SBasePlayer
function MainActivity:onPlayerReady(player)
    DBManager:getPlayerData(player.userId, "PluginActivityData", function(userId, subKey, data)
        if not player:checkReady() then
            return
        end
        if not DBManager:isAutoCache() then
            DBManager:addCache(userId, subKey, data)
        end
        local activityData = data.activity or {}
        for activityId, mgr in pairs(CurrentActivity) do
            player:sendPacket({
                pid = "PluginAddActivity",
                activityId = tonumber(activityId)
            })
            if activityData[tostring(activityId)] == nil then
                activityData[tostring(activityId)] = {}
            end
            mgr:onPlayerReady(player, activityData[tostring(activityId)])
        end
        PlayerActivityCache[tostring(player.userId)] = activityData
        PlayerMoneyCache[tostring(player.userId)] = {}
        for coinId, count in pairs(data.money or {}) do
            self:setMoney(player, coinId, count)
        end
    end)
end

---@param player SBasePlayer
function MainActivity:onPlayerSaveDB(player)
    if not PlayerActivityCache[tostring(player.userId)] or not PlayerMoneyCache[tostring(player.userId)] then
        return
    end
    local cache = {
        activity = PlayerActivityCache[tostring(player.userId)],
        money = PlayerMoneyCache[tostring(player.userId)],
    }
    for activityId, mgr in pairs(CurrentActivity) do
        local activityData = mgr:getPlayerMainCache(player)
        TableUtil.mergeTable(activityData, mgr:getPlayerCache(player), activityData)
        cache.activity[activityId] = activityData
    end
    DBManager:savePlayerData(player.userId, "PluginActivityData", cache, true)
end

function MainActivity:onPlayerLogout(player)
    PlayerActivityCache[tostring(player.userId)] = nil
    PlayerMoneyCache[tostring(player.userId)] = nil
end

function MainActivity:registerPayFunction(coinId, func)
    BaseActivityMgr.registerPayFunction(coinId, func)
end

---@param player SBasePlayer
function MainActivity:setMoney(player, coinId, count)
    local cache = PlayerMoneyCache[tostring(player.userId)]
    local diff = count - (cache[tostring(coinId)] or 0)
    cache[tostring(coinId)] = count
    ServerReportEvent.activity_coin_change(player, count, diff)
    player:sendPacket({
        pid = "SetActivityMoney",
        coinId = coinId,
        count = count
    })
end

---@param player SBasePlayer
function MainActivity:getMoney(player, coinId)
    local cache = PlayerMoneyCache[tostring(player.userId)]
    return cache[tostring(coinId)] or 0
end

function MainActivity:addScoreActivityScore(player, score)
    local activity = self:getActivityByClass("SScoreActivityMgr")
    for _, mgr in pairs(activity) do
        mgr:addScore(player, score)
    end
end

function MainActivity:getActivityByClass(class)
    local activity = {}
    for _, mgr in pairs(CurrentActivity) do
        if mgr.__cname == class then
            table.insert(activity, mgr)
        end
    end
    return activity
end

function MainActivity:triggerCondition(player, type)
    for _, mgr in pairs(CurrentActivity) do
        if mgr:triggerCondition(player, type) then
            ServerReportEvent.activity_trigger_condition(player, mgr.mainConfig.id, type)
        end
    end
end

function MainActivity:nextDay(player)
    for _, mgr in pairs(CurrentActivity) do
        mgr:nextDay(player)
    end
end

return MainActivity
