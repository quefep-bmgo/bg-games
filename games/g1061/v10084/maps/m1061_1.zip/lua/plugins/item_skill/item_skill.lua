---起床专属插件 ， 为了功能模块化
local handlers = {}

Plugins.Require("item_skill", "common.define.ItemSkillDefine")
Plugins.Require("item_skill", "common.config.MonsterConfig")
Plugins.Require("item_skill", "common.config.MountConfig")
Plugins.Require("item_skill", "common.config.SkillConfig")

if isClient then
    Plugins.Require("item_skill", "client.listener.Listener")
    Plugins.Require("item_skill", "client.entity.ClientMonster")
    Plugins.Require("item_skill", "client.packet.PacketHandler")
else
    Plugins.Require("item_skill", "server.packet.PacketHandler")
    Plugins.Require("item_skill", "server.listener.Listener")
    Plugins.Require("item_skill", "server.manager.SkillManager")
    Plugins.Require("item_skill", "server.manager.MonsterManager")
    Plugins.Require("item_skill", "server.manager.MountManager")
    Plugins.Require("item_skill", "server.manager.CollisionManager")
end

function handlers.enable()
    Plugins.Require("item_skill", "server.packet.Sender")
    SkillManager:init()
    MonsterManager:init()
end

return function(name, ...)
    if type(handlers[name]) ~= "function" then
        return
    end
    handlers[name](...)
end