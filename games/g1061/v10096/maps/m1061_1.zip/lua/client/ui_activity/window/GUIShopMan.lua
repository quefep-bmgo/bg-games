---@class GUIShopManWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIShopManWindow = class("GUIShopManWindow", GUICommonActivityPanel)
---@type ShopManConfig
local ShopManConfig = Plugins.Require("activity", "common.config.ShopManConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIShopManWindow:ctor(...)
	self.super.ctor(self, "ShopMan.json", ...)
end

---@private
function GUIShopManWindow:onChildLoad()
	self.siTitle = self:getChildWindowByName("ShopMan-TitleIcon", GUIType.StaticImage)
	self.stActivityCountDown = self:getChildWindowByName("ShopMan-ActivityCountDownIcon", GUIType.StaticText)

	self.stItemName = self:getChildWindowByName("ShopMan-ItemName", GUIType.StaticText)
	self.stItemDesc = self:getChildWindowByName("ShopMan-ItemDesc", GUIType.StaticText)

	self.stTimeCountDown = self:getChildWindowByName("ShopMan-TimeCountDown", GUIType.StaticText)
	self.btnBuy = self:getChildWindowByName("ShopMan-BuyButton", GUIType.Button)
	self.btnTip = self:getChildWindowByName("ShopMan-TipButton", GUIType.Button)
	self.llPanel = self:getChildWindowByName("ShopMan-GoodsLayout", GUIType.Layout)

	self.lvRewards = IGUIGridView.new("ShopMan-Items" .. self.activity.activityId, self.llPanel)
	self.lvRewards:setConfig(15, 5, 4)
	---@type ShopManItemAdapter
	self.rewardAdapter = UIHelper.requireAdapter("ShopManItemAdapter", false, "ui_activity").new()
	self.lvRewards:setAdapter(self.rewardAdapter)

	self:initView()
	self:initEvent()
end

---@private
function GUIShopManWindow:initView()
	self.siTitle:SetImage(UIUtils.GetLangImage("set:random_store.json image:text"))
	self.btnBuy:SetText(Lang:getString("bed.war.super.player.buy"))

end

---@private
function GUIShopManWindow:initEvent()
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		local info = self.mgr.dataCache.storeList[self.selectId]
		if not info then
			LogUtil.logError("buy random store error, no info")
			return
		end
		local cfg = ShopManConfig:getRewardById(info.id)
		if info.buyCount >= cfg.limitCount then
			LogUtil.logError("buy random store error, count limit")
			return
		end
		CustomDialog.builder()
					.setTitleText("gui.store.purchase.title")
					.setContentText(Lang:getString("gui.store.purchase.tip"))
					.setRightIcon(PayHelper.getMoneyIcon(cfg.moneyType))
					.setRightText(tostring(cfg.price))
					.setRightClickListener(function()
			LuaTimer:schedule(function()
				PayHelper.checkMoney(cfg.moneyType, cfg.price, function(success)
					if success then
						self.mgr:onBuyPrivilege(info.id)
					end
				end).setRechargeFunc(function()
					ClientHelper.onRecharge(1, "activity_randomStore" .. self.mgr.mainConfig.id)
				end)
			end, 50)
		end).show()
	end)

	self.mgr:registerCacheChange(function()
		if self:isShow() then
			if #self.mgr.dataCache.storeList ~= self.rewardAdapter:getItemCount() then
				for key, item in pairs(self.mgr.dataCache.storeList) do
					item.index = key
				end
				self.rewardAdapter:setData(self.mgr.dataCache.storeList)
			else
				Events.ShopManClick:invoke(self.selectId)
			end
		else
		end
	end)

	self:registerEvent(Events.ShopManClick, function(index, forceRefresh)
		self:refreshUI(index, forceRefresh)
	end)
end

function GUIShopManWindow:onSecondTick()
	if not self:isShow() then
		return
	end
	self.super.onSecondTick(self)
	local dayEndTime = DateUtil.getGreenwichDayLastTime()
	local leftTime = dayEndTime - os.time()
	self.stTimeCountDown:SetText(DateUtil.getFormatTimeWithDay(leftTime))
end

function GUIShopManWindow:refreshUI(index, forceRefresh)
	self.super.refreshUI(self)
	if not index then
		return
	end
	if not self.mgr.dataCache.storeList then
		return
	end

	self.selectId = index

	--主奖励展示
	local info = self.mgr.dataCache.storeList[self.selectId]
	if not info then
		LogUtil.logError("no shop man info", self.selectId)
		return
	end
	local cfg = ShopManConfig:getRewardById(info.id)
	local reward = self.mgr:getRewardById(cfg.rewardId)
	self.stItemName:SetText(Lang:getString(reward.name))
	self.stItemDesc:SetText(Lang:getString(reward.desc))
	if self.mgr.mainConfig.mainRewardId ~= cfg.rewardId or forceRefresh then
		self.mgr.mainConfig.mainRewardId = cfg.rewardId
		local detailRef = RewardItemShowDetailConfig:getConfigById(reward.showDetailId)
		local detailBak = TableUtil.copyTable(detailRef)
		detailRef.scale = tonumber(cfg.scale) or detailRef.scale
		detailRef.actorRotate = tonumber(cfg.actorRotate) or detailRef.actorRotate
		detailRef.actorYOffset = tonumber(cfg.actorYOffset) or detailRef.actorYOffset
		detailRef.actorXRotate = tonumber(cfg.actorXRotate) or detailRef.actorXRotate
		self.super.showRewardDetail(self)
		detailRef = detailBak
	end
	if info.buyCount >= cfg.limitCount then
		self.btnBuy:SetEnabled(false)
	else
		self.btnBuy:SetEnabled(true)
	end
end

function GUIShopManWindow:onShow()
	for key, item in pairs(self.mgr.dataCache.storeList) do
		item.index = key
	end
	self.rewardAdapter:setActivityMgr(self.mgr)
	self.rewardAdapter:setData(self.mgr.dataCache.storeList)
	Events.ShopManClick:invoke(1, true)
	self.mgr:updateLastOpenUIDate()
end

function GUIShopManWindow:onDestroy()
	self:unregisterEvent(Events.ShopManClick)
end

return GUIShopManWindow
