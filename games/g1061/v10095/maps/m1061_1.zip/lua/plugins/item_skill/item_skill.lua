---起床专属插件 ， 为了功能模块化
local handlers = {}

Plugins.Require("item_skill", "common.define.ItemSkillDefine")
Plugins.Require("item_skill", "common.event.ItemSkillEvents")
Plugins.Require("item_skill", "common.config.MonsterConfig")
Plugins.Require("item_skill", "common.config.MountConfig")
Plugins.Require("item_skill", "common.config.SkillConfig")

if isClient then
    handlers = Plugins.Require("item_skill", "client.item_skill_client")
    GMSetting:addTab("测试", 5)
    GMSetting:addItem("测试", "防护套装铁", "addPropPacketItem", 650)
    GMSetting:addItem("测试", "防护套装金", "addPropPacketItem", 651)
    GMSetting:addItem("测试", "金剑", "addPropPacketItem", 283)
else
    handlers = Plugins.Require("item_skill", "server.item_skill_server")
end

return function(name, ...)
    if type(handlers[name]) ~= "function" then
        return
    end
    handlers[name](...)
end