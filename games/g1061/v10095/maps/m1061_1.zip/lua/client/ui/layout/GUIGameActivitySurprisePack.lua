---@class UIGameActivitySurprisePackLayout : IGUILayout
local UIGameActivitySurprisePackLayout = class("UIGameActivitySurprisePackLayout", IGUILayout)

---@type ClientReportEvent
local ReportEvent = T(Global, "ReportEvent")

---@type SurprisePackConfig
local SurprisePackConfig = T(Global, "SurprisePackConfig")

---@private
function UIGameActivitySurprisePackLayout:ctor(parent)
	self.super.ctor(self, "GameActivitySurprisePack.json", parent)
end

---@private
function UIGameActivitySurprisePackLayout:isDelayLoad()
	return true
end

---@private
function UIGameActivitySurprisePackLayout:onCreate()
	self:initCreateEvent()
end

---@private
function UIGameActivitySurprisePackLayout:initCreateEvent()

end

---@private
function UIGameActivitySurprisePackLayout:onLoad()
	self.siBg = self:getChildWindow("GameActivitySurprisePack-Bg", GUIType.StaticImage)
	self.siTitle = self:getChildWindow("GameActivitySurprisePack-Title", GUIType.StaticImage)
	self.siTimeIcon = self:getChildWindow("GameActivitySurprisePack-Time-Icon", GUIType.StaticImage)
	self.stTimeTxt = self:getChildWindow("GameActivitySurprisePack-Time-Txt", GUIType.StaticText)
	self.btnClose = self:getChildWindow("GameActivitySurprisePack-Close", GUIType.Button)
	self.btnBtn1 = self:getChildWindow("GameActivitySurprisePack-Btn1", GUIType.Button)
	self.btnBtn2 = self:getChildWindow("GameActivitySurprisePack-Btn2", GUIType.Button)
	self.btnBtn3 = self:getChildWindow("GameActivitySurprisePack-Btn3", GUIType.Button)
	self.stBtn1Text1 = self:getChildWindow("GameActivitySurprisePack-Btn1-Text1", GUIType.StaticText)
	self.stBtn1Text2 = self:getChildWindow("GameActivitySurprisePack-Btn1-Text2", GUIType.StaticText)
	self.stBtn2Text1 = self:getChildWindow("GameActivitySurprisePack-Btn2-Text1", GUIType.StaticText)
	self.stBtn2Text2 = self:getChildWindow("GameActivitySurprisePack-Btn2-Text2", GUIType.StaticText)
	self.stBtn3Text1 = self:getChildWindow("GameActivitySurprisePack-Btn3-Text1", GUIType.StaticText)
	self.stBtn3Text2 = self:getChildWindow("GameActivitySurprisePack-Btn3-Text2", GUIType.StaticText)
	self.pbProgress = self:getChildWindow("GameActivitySurprisePack-Progress", GUIType.ProgressBar)
	self.siDiamond = self:getChildWindow("GameActivitySurprisePack-Diamond", GUIType.StaticImage)
	self.stProgressText = self:getChildWindow("GameActivitySurprisePack-Progress-Text", GUIType.StaticText)
	self.stDesc = self:getChildWindow("GameActivitySurprisePack-desc", GUIType.StaticText)
	self:initView()
	self:initEvent()
end

---@private
function UIGameActivitySurprisePackLayout:initView()
	self.stBtn1Text1:SetText(Lang:getString("gui.activity.surprise.pack.btn.free.receive"))
	self.stBtn2Text1:SetText(Lang:getString("gui.activity.surprise.pack.btn.free.receive"))
	self.stBtn3Text1:SetText(Lang:getString("gui.activity.surprise.pack.btn.free.receive"))
	self.stBtn1Text2:SetText(Lang:getString("gui.activity.surprise.pack.btn.free.receive"))
	self.stBtn2Text2:SetText(Lang:getString("gui.activity.surprise.pack.btn.free.receive"))
	self.stBtn3Text2:SetText(Lang:getString("gui.activity.surprise.pack.btn.free.receive"))
	self.btnList = {
		self.btnBtn1,
		self.btnBtn2,
		self.btnBtn3,
	}
	self.btnText1List = {
		self.stBtn1Text1,
		self.stBtn2Text1,
		self.stBtn3Text1,
	}
	self.btnText2List = {
		self.stBtn1Text2,
		self.stBtn2Text2,
		self.stBtn3Text2,
	}
end

local function buildDialog(self, index)
	local isHave = false
	local name = ""
	local rewards = SurprisePackConfig:getRewardGroup(self.mgr.config.rewardGroupId)
	for id, reward in pairs(rewards) do
		if id == index then
			local realId = reward.reward.realId
			isHave = CustomShop:isGoodsHas(realId)
			local goods = CustomShopConfig:getGoodsConfig(realId)
			name = goods.Name or ""
		end
	end
	if isHave then
		CustomDialog.builder()
			.setContentText(Lang:format("gui.surprise.pack.already.have", Lang:getString(name)))
			.setHideLeftButton()
			.show()
	else
		CustomDialog.builder()
			.setTitleText("gui.surprise.pack.title")
			.setContentText(Lang:format("gui.surprise.pack.receive.confirm", Lang:getString(name)))
			.setRightText(Lang:getString("gui_dialog_tip_btn_sure"))
			.setRightClickListener(function()
				if not self.mgr then
					return
				end
				self.mgr:tryGetReward(index)
			end).show()
	end
end

---@private
function UIGameActivitySurprisePackLayout:initEvent()
	self.btnClose:registerEvent(GUIEvent.ButtonClick, function()
		self:hide()
	end)
	self.btnBtn1:registerEvent(GUIEvent.ButtonClick, function()
		if not self.mgr then
			return
		end
		if self.mgr.dataCache.consumeDiamond < self.mgr.config.consumeDiamond then
			return
		end
		buildDialog(self, 1)
	end)
	self.btnBtn2:registerEvent(GUIEvent.ButtonClick, function()
		if not self.mgr then
			return
		end
		if self.mgr.dataCache.consumeDiamond < self.mgr.config.consumeDiamond then
			return
		end
		buildDialog(self, 2)
	end)
	self.btnBtn3:registerEvent(GUIEvent.ButtonClick, function()
		if not self.mgr then
			return
		end
		if self.mgr.dataCache.consumeDiamond < self.mgr.config.consumeDiamond then
			return
		end
		buildDialog(self, 3)
	end)
end

function UIGameActivitySurprisePackLayout:onShow()
	-- id = 909 在配置表 CommonActivity.csv 里
	self.mgr = PluginMainActivity:getActivity(909)
	for _, v in pairs(self.btnList) do
		v:SetEnabled(false)
	end
	for i, v in pairs(self.btnText1List) do
		v:SetVisible(false)
	end
	for i, v in pairs(self.btnText2List) do
		v:SetVisible(true)
	end
	if not self.mgr or not next(self.mgr) then
		return
	end
	self.mgr:registerCacheChange(function()
		if self.mgr.dataCache.haveReceive then
			Events.ShowSurprisePackIconEvent:invoke(self.mgr.mainConfig.activityId, false)
			self:hide()
		end
	end)
	local endTime = self.mgr.mainConfig.endTime
	local totalDiamond = self.mgr.config.consumeDiamond
	local curDiamond = self.mgr.dataCache.consumeDiamond
	local time = endTime - os.time()
	if time < 0 then
		self:hide()
		return
	end
	self.stDesc:SetText(Lang:format("gui.activity.surprise.pack.desc", totalDiamond))
	local rewards = SurprisePackConfig:getRewardGroup(self.mgr.config.rewardGroupId)
	local consumeDiamondEnough = curDiamond >= totalDiamond
	for id, reward in pairs(rewards) do
		self.btnList[id]:SetEnabled(consumeDiamondEnough)
		self.btnText1List[id]:SetVisible(consumeDiamondEnough)
		self.btnText2List[id]:SetVisible(not consumeDiamondEnough)
	end
	local text = DateUtil.getFormatTime(time)
	self.stTimeTxt:SetText(text)
	self.stProgressText:SetText(curDiamond  .. "/" ..totalDiamond)
	self.pbProgress:SetProgress(curDiamond / totalDiamond)
	self.timer = LuaTimer:scheduleTicker(function()
		time = endTime - os.time()
		if time < 0 then
			self:hide()
		end
		self.stTimeTxt:SetText(DateUtil.getFormatTime(time))
	end, 20)

	--埋点
	ReportEvent.limited_gift_click(self.mgr.config.id, consumeDiamondEnough and 1 or 0)
end

function UIGameActivitySurprisePackLayout:onHide()
	if self.timer then
		LuaTimer:cancel(self.timer)
		self.timer = nil
	end

	if self.mgr then
		self.mgr.cacheCallBack = nil
		self.mgr = nil
	end
end

return UIGameActivitySurprisePackLayout
