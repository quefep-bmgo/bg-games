---@class UINewStore : IGUILayout
local UIBedWarNewStore = class("GUIBedWarNewStore", IGUILayout)

---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type AdUtil
local AdUtil = T(Global, "AdUtil")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function UIBedWarNewStore:isDelayLoad()
    return true
end

---@private
function UIBedWarNewStore:onCreate()
    self:initCreateEvent()
end

---@private
function UIBedWarNewStore:initCreateEvent()

end

---@private
function UIBedWarNewStore:onLoad()
    self.llTop = self:getChildWindow("BedWarNewStore-Top", GUIType.Layout)
    self.llMoney = self:getChildWindow("BedWarNewStore-Money", GUIType.Layout)
    self.siTabsBg = self:getChildWindow("BedWarNewStore-Tabs-Bg", GUIType.StaticImage)
    self.llTabs = self:getChildWindow("BedWarNewStore-Tabs", GUIType.Layout)
    self.llCenter = self:getChildWindow("BedWarNewStore-Center", GUIType.Layout)
    self.stTitle = self:getChildWindow("BedWarNewStore-Title", GUIType.StaticText)
    self.llCenterContent = self:getChildWindow("BedWarNewStore-Center-Content", GUIType.Layout)
    self.siDisplayImage = self:getChildWindow("BedWarNewStore-Display-Image", GUIType.StaticImage)
    self.ivImageTop = self:getChildWindow("BedWarNewStore-Image-Top", GUIType.StaticImage)
    self.ivImageBack = self:getChildWindow("BedWarNewStore-Image-Back", GUIType.StaticImage)
    self.awDisplayActor = self:getChildWindow("BedWarNewStore-Display-Actor", GUIType.ActorWindow)
    self.llBoxDsc = self:getChildWindow("BedWarNewStore-Box-Dsc", GUIType.Layout)
    self.siBoxItemBg = self:getChildWindow("BedWarNewStore-Box-Item-Bg", GUIType.StaticImage)
    self.stBoxItemTitle = self:getChildWindow("BedWarNewStore-Box-Item-Title", GUIType.StaticText)
    self.llBoxItemList = self:getChildWindow("BedWarNewStore-Box-Item-List", GUIType.Layout)
    self.siBoxDscBg = self:getChildWindow("BedWarNewStore-Box-Dsc-Bg", GUIType.StaticImage)
    self.stBoxDscText = self:getChildWindow("BedWarNewStore-Box-Dsc-Text", GUIType.StaticText)
    self.stOtherDsc = self:getChildWindow("BedWarNewStore-Other-Dsc", GUIType.StaticText)
    self.llRight = self:getChildWindow("BedWarNewStore-Right", GUIType.Layout)
    self.llNormal = self:getChildWindow("BedWarNewStore-Normal", GUIType.Layout)
    self.llRightGoodsList = self:getChildWindow("BedWarNewStore-Right-Goods-List", GUIType.Layout)
    self.btnBuy = self:getChildWindow("BedWarNewStore-Buy", GUIType.Button)
    self.stBuyText = self:getChildWindow("BedWarNewStore-Buy-Text", GUIType.StaticText)
    self.stBuyText:SetText(Lang:getString("gui_buy_text"))
    self.btnBuyFree = self:getChildWindow("BedWarNewStore-Buy_Free", GUIType.Button)
    self.stFreeText = self:getChildWindow("BedWarNewStore-Free-Text", GUIType.StaticText)
    self.stFreeText:SetText(Lang:getString("gui_bed_war_free_gift_free"))
    self.siFreeIcon = self:getChildWindow("BedWarNewStore-Free-Icon", GUIType.StaticImage)
    self.stRefreshTime = self:getChildWindow("BedWarNewStore-Refresh-Time", GUIType.StaticText)
    self.stRefreshTimeGiftGoods = self:getChildWindow("BedWarNewStore-TimeGoodsTime", GUIType.StaticText)
    self.llActorSlide = self:getChildWindow("BedWarNewStore-Actor-Slide", GUIType.Layout)
    self.stLimitText = self:getChildWindow("BedWarNewStore-Limit-Text", GUIType.StaticText)
    self.llTimeGoodsList = self:getChildWindow("BedWarNewStore-TimeGoodsList", GUIType.Layout)
    self.llMonthCard = self:getChildWindow("BedWarNewStore-MonthCard", GUIType.Layout)
    self:initView()
    self:initEvent()
end

---@private
function UIBedWarNewStore:initView()
    ---@type GUIBedWarNewStoreTab[]
    self.tabs = {}
    self.refreshTimer = nil
    self.selectInfo = {
        tabId = nil,
        ---@type GoodsInfo
        curSelectGoods = nil,
        curColumn = 0,
    }
    self.iconMovePos = 0
    self.iconMoveGap = 2

    ---加载通用关闭按钮
    ---@type GUIBedWarUIReturnControlWindow
    self.llReturn = UIHelper.newGameGUIWindow("GUIBedWarUIReturnControl", "LicenseTab_3", function()
        GUINewStore:hide()
    end)
    self.root:AddChildWindow(self.llReturn.root)

    ---加载左侧4个按钮
    local config = StoreConfig:getStoreConfig(StoreId.CubeStore)
    for index, data in pairs(config.Tabs) do
        ---@type GUIBedWarNewStoreTab
        local tab = UIHelper.newGameGUIWindow("GUIBedWarNewStoreTab", "BedWarNewStoreTab.json")
        local ySpace = 14
        local itemHeight = tab.root:GetPixelSize().y
        tab.root:SetYPosition({ 0, (index - 1) * (ySpace + itemHeight) })
        tab.root:SetXPosition({ 0, 0 })
        UIUtils.addRedDot(tab.root, Define.RedDotKey.Store .. "_tabId" .. data.Id,
                Define.RedDotKey.Store, { offset = VectorUtil.newVector2(-4, 3) })
        tab:onDataChanged(data)
        tab:setSelected(index == 1)
        self.llTabs:AddChildWindow(tab.root)
        table.insert(self.tabs, tab)
    end

    --- 货币list
    local currencyCount = #config.CurrencyList
    self.llMoney:SetWidth({ 0, 73 * currencyCount + 10 * (currencyCount - 1) })
    self.lvMoney = IGUIListView.new("BedWarNewStore-Money-List", self.llMoney, nil, Orientation.Horizontal)
    self.lvMoney:setItemSpace(10)
    self.lvMoney.root:SetClipChild(false)
    self.lvMoney:clearItems()
    for _, data in pairs(config.CurrencyList) do
        ---@type GUICurrency
        local item = UIHelper.newGameGUIWindow("GUICurrency", "BedWarCurrency.json")
        item:onDataChanged(data)
        self.lvMoney:addItem(item)
    end

    --- 商品grid
    self.gvGoodsList = IGUIGridView.new("BedWarNewStore-Goods-List-Gird", self.llRightGoodsList)
    self.gvGoodsList:setArea({ 0, 0 }, { 0, 0 }, { 1, -42 }, { 1, -21 })
    self.gvGoodsList.root:SetClipChild(false)
    self.gvGoodsList.root:SetVerticalAlignment(VerticalAlignment.Bottom)
    self.gvGoodsList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    ---@type NewStoreGoodsAdapter
    self.goodsAdapter = UIHelper.newGameAdapter("NewStoreGoodsAdapter")
    self.gvGoodsList:setAdapter(self.goodsAdapter)

    --- 商品grid
    self.gvTimeGoodsList = IGUIGridView.new("BedWarNewStore-TimeGoods-List-Gird", self.llTimeGoodsList)
    self.gvTimeGoodsList:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.gvTimeGoodsList.root:SetClipChild(true)
    self.gvTimeGoodsList.root:SetVerticalAlignment(VerticalAlignment.Bottom)
    self.gvTimeGoodsList.root:SetHorizontalAlignment(HorizontalAlignment.Center)
    ---@type NewStoreTimeGoodsAdapter
    self.goodsTimeAdapter = UIHelper.newGameAdapter("NewStoreTimeGoodsAdapter")
    self.gvTimeGoodsList:setAdapter(self.goodsTimeAdapter)

    ---@type UIBedWarNewStorePurchase
    self.purchasePanel = UIHelper.newGameGUILayout("GUIBedWarNewStorePurchase", "BedWarNewStorePurchase.json")

    ---宝箱展示grid
    self.gvBoxItemList = IGUIListView.new("BedWarNewStore-Box-Item-List-Gird", self.llBoxItemList, nil, Orientation.Horizontal)
    self.gvBoxItemList:setArea({ 0, 10 }, { 0, 0 }, { 1, -20 }, { 1, 0 })
    self.gvBoxItemList:setItemSpace(10)
    self.gvBoxItemList.root:SetClipChild(false)
    self.llBoxItemList:SetClipChild(true)
    ---@type NewStoreBoxItemAdapter
    self.boxItemAdapter = UIHelper.newGameAdapter("NewStoreBoxItemAdapter")
    local itemWidth = math.floor(self.gvBoxItemList:getHeight() / 1.6)
    self.boxItemAdapter:setItemSize(itemWidth, itemWidth)
    self.gvBoxItemList:setAdapter(self.boxItemAdapter)

    -- 月卡
    self.monthCard = UIHelper.newGameGUIWindow("GUIMonthCard")
    self.llMonthCard:AddChildWindow(self.monthCard.root)
end

---@private
function UIBedWarNewStore:initEvent()
    self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
        self.purchasePanel:show(self.selectInfo.curSelectGoods)
    end)

    self.btnBuyFree:registerEvent(GUIEvent.ButtonClick, function()
        if self.btnBuyFree:IsEnabled() then
            ClientStore:onWatchAd(self.selectInfo.curSelectGoods.goodsId)
        end
    end)

    self:registerEvent(Events.StoreBuySuccessEvent, function(goods, count)
        self:onBuyGoodsSuccess(goods, count)
    end)

    self:registerEvent(Events.StoreGoodsChangeEvent, function(tabId)
        if self.selectInfo.tabId == tabId then
            self:ShowGoodsList(tabId)
        end
    end)
end

---@param goods StoreGoodsData
function UIBedWarNewStore:onBuyGoodsSuccess(goods, count)
    local totalCount = GoodsStorePrivilege:onBuyGoods(goods) * count
    if goods.Type == GoodsType.Privilege then
        totalCount = count
    end
    if #goods.showDetail.image > 10 then
        HostApi.notifyGetGoods(goods.showDetail.image, totalCount)
    else
        HostApi.notifyGetItem(goods.ItemId, 0, totalCount)
    end
end

---@private
function UIBedWarNewStore:isShowAnim()
    return false
end

function UIBedWarNewStore:onHide()
    self.purchasePanel:hide()
end

function UIBedWarNewStore:onShow(storeId, tabId)
    AdUtil:checkAdStatus(Define.AdType.StoreGoods)
    if not self.selectInfo.tabId and not tabId then
        self:onSelectTab(self.tabs[1].tabId)
        return
    end
    self:onSelectTab(tabId or self.selectInfo.tabId)
end

function UIBedWarNewStore:onTick()
    for _, item in pairs(self.lvMoney.items) do
        item:onTick()
    end
end

function UIBedWarNewStore:onSelectTab(tabId)
    -- report
    ClientReportEvent.open_shop_tab(tabId)

    if not tabId or tabId == self.selectInfo.tabId then
        return
    end
    self.selectInfo.tabId = tabId
    for _, tab in pairs(self.tabs) do
        tab:setSelected(tab.tabId == tabId)
    end
    self:ShowGoodsList(tabId)
end

function UIBedWarNewStore:ShowGoodsList(tabId)
    ---@type GUIBedWarNewStoreTab
    local curTab = nil
    for _, tab in pairs(self.tabs) do
        if tab.tabId == tabId then
            curTab = tab
            break
        end
    end
    if not curTab then
        self:onSelectTab(self.tabs[1].tabId)
        return
    end
    ---@type GoodsInfo[]
    local goodList = ClientStore:getGoodsList(StoreId.CubeStore, tabId)
    if not self.selectInfo.curSelectGoods or self.selectInfo.curSelectGoods.config.TabId ~= tabId then
        self.selectInfo.curSelectGoods = goodList[1]
    end

    if curTab.data.ShowType == ShowType.OldStyle then
        self.llMonthCard:SetVisible(false)
        self.llTimeGoodsList:SetVisible(false)
        self.llRight:SetVisible(true)
        self.llCenter:SetVisible(true)
        if self.selectInfo.curColumn ~= curTab.data.Column then
            self.selectInfo.curColumn = curTab.data.Column
            self.gvGoodsList:setConfig(14, 13, curTab.data.Column)
            local itemWidth = (self.gvGoodsList:getWidth() - 14 * (curTab.data.Column - 1)) / curTab.data.Column
            local itemHeight = (itemWidth / 141) * 150
            self.goodsAdapter:setItemSize(itemWidth, itemHeight)
            local count = self.gvGoodsList.root:GetItemCount()
            for index = 1, count do
                local item = self.gvGoodsList.root:GetItem(index - 1)
                item:SetWidth({ 0, itemWidth })
                item:SetHeight({ 0, itemHeight })
            end
        end
        self.goodsAdapter:setData(goodList)
        if self.selectInfo.curSelectGoods then
            self:showGoodsDetail(self.selectInfo.curSelectGoods)
        else
            LogUtil.logError("no detail config", tabId)
        end
    elseif curTab.data.ShowType == ShowType.WeekAndMonth then
        local curGroupCfg = StoreTimeGroupConfig:getCurrentGoodsByTab(curTab.data.Id)
        local timeGoodsList = StoreTimeGroupConfig:getGoodsList(curGroupCfg.GroupId)
        local player = PlayerManager:getClientPlayer()
        if not player.storeDataMap then
            LogUtil.logError("no store data map")
            return
        end
        local buyData = player.storeDataMap[curGroupCfg.key]
        for _, goods in pairs(timeGoodsList) do
            if buyData and buyData[tostring(goods.Id)] then
                goods.canBuyCount = goods.LimitCount - buyData[tostring(goods.Id)]
            else
                goods.canBuyCount = goods.LimitCount
            end
        end
        --todo 取玩家的购买次数，算出剩余次数
        self.llMonthCard:SetVisible(false)
        self.llTimeGoodsList:SetVisible(true)
        self.llRight:SetVisible(false)
        self.llCenter:SetVisible(true)
        table.sort(timeGoodsList, function(a, b)
            if a.canBuyCount <= 0 then
                return false
            end
            if b.canBuyCount <= 0 then
                return true
            end
            return a.Sort < b.Sort
        end)
        self.goodsTimeAdapter:setData(timeGoodsList)
        self.goodsTimeAdapter.view.items[1]:updateDetail(1)
    elseif curTab.data.ShowType == ShowType.MonthCard then
        self.monthCard:showPage()
        self.llMonthCard:SetVisible(true)
        self.llTimeGoodsList:SetVisible(false)
        self.llRight:SetVisible(false)
        self.llCenter:SetVisible(false)
    end
    self.selectInfo.tabId = tabId
end

---@param goodsInfo GoodsInfo
function UIBedWarNewStore:showGoodsDetail(goodsInfo)
    --- 刷新右侧商品列表
    local oldGoods = self.selectInfo.curSelectGoods
    self.selectInfo.curSelectGoods = nil
    self.goodsAdapter:notifyItemDataChange(oldGoods)
    self.selectInfo.curSelectGoods = goodsInfo
    self.goodsAdapter:notifyItemDataChange(goodsInfo)

    self.btnBuy:SetVisible(not goodsInfo.config.AdGoods)
    self.btnBuyFree:SetVisible(goodsInfo.config.AdGoods)
    self.btnBuyFree:SetEnabled(goodsInfo.LimitCount > 0)
    self.stRefreshTime:SetVisible(goodsInfo.LimitCount == 0)
    if goodsInfo.RefreshTime then
        local refreshTime = goodsInfo.RefreshTime - os.time()
        if refreshTime > 0 then
            self:CancelRefreshTimer()
            self.stRefreshTime:SetText(Lang:getString("bed_war_new_store_free_goods_refresh") .. ": " .. DateUtil.getTimeByTwoPara(refreshTime))
            self.stRefreshTimeGiftGoods:SetText(DateUtil.getTimeByTwoPara(refreshTime))
            self.refreshTimer = LuaTimer:scheduleTimer(function()
                local seconds = goodsInfo.RefreshTime - os.time()
                self.stRefreshTime:SetText(Lang:getString("bed_war_new_store_free_goods_refresh") .. ": " .. DateUtil.getTimeByTwoPara(seconds))
                self.stRefreshTimeGiftGoods:SetText(DateUtil.getTimeByTwoPara(seconds))
            end, 1000, refreshTime)
        end
    end
    --- 物品标题
    self.stTitle:SetText(Lang:getString(goodsInfo.config.showDetail.name))

    --- 展示图片、模型、特效
    self.siDisplayImage:SetVisible(goodsInfo.config.showDetail.showType == Define.ShowDetailType.Icon)
    self.awDisplayActor:SetVisible(goodsInfo.config.showDetail.showType == Define.ShowDetailType.Actor)
    if goodsInfo.config.showDetail.showType == Define.ShowDetailType.Icon then
        self:setIcon(goodsInfo.config.showDetail)
    elseif goodsInfo.config.showDetail.showType == Define.ShowDetailType.Actor then
        RewardItemShowDetailConfig:showActorSkill(self.awDisplayActor, goodsInfo.config.showDetail, self.llActorSlide)
        self.awDisplayActor:SetVisible(true)
    end

    self.stLimitText:SetVisible(goodsInfo.LimitCount ~= -1)
    if goodsInfo.LimitCount ~= -1 then
        self.stLimitText:SetText(goodsInfo.LimitCount .. "/" .. goodsInfo.config.LimitCount)
        self.stLimitText:SetWidth({ 0, self.stLimitText:GetTextWidth() })
    end

    --- type=9 宝箱
    self.llBoxItemList:SetVisible(goodsInfo.config.Type == GoodsType.UseChest)
    self.stOtherDsc:SetVisible(goodsInfo.config.Type ~= GoodsType.UseChest)
    self.siBoxDscBg:SetVisible(false)
    if goodsInfo.config.Type == 9 then
        self.stBoxItemTitle:SetText(Lang:getString("bed_war_new_store_bix_title"))
        self.stBoxDscText:SetText(Lang:getString(goodsInfo.config.showDetail.desc))
        local lotteryBox = GUIBoxLotteryConfig:findLotteryBoxById(goodsInfo.config.ItemId)
        local lotteryBoxReward = GUIBoxLotteryConfig:findLotteryBoxRewardByType(lotteryBox.Type)
        table.sort(lotteryBoxReward, function(a, b)
            return a.Id < b.Id
        end)
        self.boxItemAdapter:setData(lotteryBoxReward)
    else
        self.stOtherDsc:SetText(Lang:getString(goodsInfo.config.showDetail.desc))
        if goodsInfo.config.CountText ~= "#" then
            self.stBoxItemTitle:SetText(Lang:getString(goodsInfo.config.CountText))
        else
            self.stBoxItemTitle:SetText(Lang:getString("bed_war_new_store_count") .. goodsInfo.config.Count)
        end
    end
end

---@param data RewardItemShowDetailItem
function UIBedWarNewStore:setIcon(data)
    self:CancelMoveTimer()
    self.siDisplayImage:SetYPosition({ 0, self.iconMovePos })

    self.ivImageTop:SetImage(data.image)
    self.ivImageBack:SetImage(data.image)
    --UIHelper:setImageAdjustSize(self.ivImageTop, data.image, 200, 200, data.scale)
    --UIHelper:setImageAdjustSize(self.ivImageBack, data.image, 200, 200, data.scale)

    self.moveTimer = LuaTimer:scheduleTimer(function()
        if math.abs(self.iconMovePos) >= 15 then
            self.iconMoveGap = self.iconMoveGap * -1
        end
        self.iconMovePos = self.iconMovePos + self.iconMoveGap
        self.siDisplayImage:SetYPosition({ 0, self.iconMovePos })
    end, 100)
end

function UIBedWarNewStore:getCurrentGoodsId()
    if self.selectInfo.curSelectGoods then
        return self.selectInfo.curSelectGoods.goodsId
    end
    return 0
end

---@param data RewardData
function UIBedWarNewStore:UpdateBoxDesc(data)
    self.siBoxDscBg:SetVisible(true)
    self.siDisplayImage:SetVisible(true)
    self.awDisplayActor:SetVisible(false)
    self.ivImageTop:SetImage(data.ShowDetail.image)
    self.ivImageBack:SetImage(data.ShowDetail.image)
    self.stBoxDscText:SetText(Lang:getString(data.ShowDetail.desc))
    --- 物品标题
    self.stTitle:SetText(Lang:getString(data.ShowDetail.name))
end

function UIBedWarNewStore:CancelMoveTimer()
    if self.moveTimer then
        LuaTimer:cancel(self.moveTimer or 0)
    end
    self.moveTimer = nil
end

function UIBedWarNewStore:CancelRefreshTimer()
    if self.refreshTimer then
        LuaTimer:cancel(self.refreshTimer or 0)
    end
    self.refreshTimer = nil
end

return UIBedWarNewStore
