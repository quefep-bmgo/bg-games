---@class GUIRandomStoreWindow : GUIGameActivityPanel
---@field super GUIGameActivityPanel
local GUIRandomStoreWindow = class("GUIRandomStoreWindow", GUICommonActivityPanel)
---@type RandomStoreConfig
local RandomStoreConfig = Plugins.Require("activity", "common.config.RandomStoreConfig")
---@type CommonActivityConfig
local CommonActivityConfig = T(Global, "CommonActivityConfig")
---@type RewardItemShowDetailConfig
local RewardItemShowDetailConfig = T(Global, "RewardItemShowDetailConfig")
---@type UIUtils
local UIUtils = T(Global, "UIUtils")

---@private
function GUIRandomStoreWindow:ctor(...)
	self.super.ctor(self, "RandomStore.json", ...)
end

---@private
function GUIRandomStoreWindow:onChildLoad()
	self.siTitle = self:getChildWindowByName("RandomStore-TitleIcon", GUIType.StaticImage)
	self.stActivityCountDown = self:getChildWindowByName("RandomStore-ActivityCountDownIcon", GUIType.StaticText)

	self.stItemName = self:getChildWindowByName("RandomStore-ItemName", GUIType.StaticText)
	self.stItemDesc = self:getChildWindowByName("RandomStore-ItemDesc", GUIType.StaticText)

	self.stTimeCountDown = self:getChildWindowByName("RandomStore-TimeCountDown", GUIType.StaticText)
	self.btnBuy = self:getChildWindowByName("RandomStore-BuyButton", GUIType.Button)
	self.btnTip = self:getChildWindowByName("RandomStore-TipButton", GUIType.Button)

	self.itemList = {}
	for i=1, 6 do
		self.itemList[i] = {
			bg = self:getChildWindowByName("RandomStore-Item" .. i .. "Bg", GUIType.StaticImage),
			quality = self:getChildWindowByName("RandomStore-Item" .. i .. "Quality", GUIType.StaticImage),
			mask = self:getChildWindowByName("RandomStore-Mask" .. i, GUIType.StaticImage),
			icon = self:getChildWindowByName("RandomStore-Item" .. i .. "Icon", GUIType.StaticImage),
			count = self:getChildWindowByName("RandomStore-Item" .. i .. "Count", GUIType.StaticText),
			offIcon = self:getChildWindowByName("RandomStore-Item" .. i .. "OffIcon", GUIType.StaticImage),
			discount = self:getChildWindowByName("RandomStore-Item" .. i .. "Discount", GUIType.StaticText),
			priceIcon = self:getChildWindowByName("RandomStore-Item" .. i .. "PriceIcon", GUIType.StaticImage),
			priceCount = self:getChildWindowByName("RandomStore-Item" .. i .. "PriceCount", GUIType.StaticText),
			oriPrice = self:getChildWindowByName("RandomStore-Item" .. i .. "OriPrice", GUIType.StaticText),
			limitCount = self:getChildWindowByName("RandomStore-LimitCount" .. i, GUIType.StaticText),
		}
	end
	self:initView()
	self:initEvent()
end

---@private
function GUIRandomStoreWindow:initView()
	self.siTitle:SetImage(UIUtils.GetLangImage("set:random_store.json image:text"))
	self.btnBuy:SetText(Lang:getString("bed.war.super.player.buy"))
end

---@private
function GUIRandomStoreWindow:initEvent()
	self.btnBuy:registerEvent(GUIEvent.ButtonClick, function()
		local info = self.mgr.dataCache.storeList[self.selectId]
		if not info then
			LogUtil.logError("buy random store error, no info")
			return
		end
		local cfg = RandomStoreConfig:getRewardById(info.id)
		if info.buyCount >= cfg.limitCount then
			LogUtil.logError("buy random store error, count limit")
			return
		end
		CustomDialog.builder()
					.setTitleText("gui.store.purchase.title")
					.setContentText(Lang:getString("gui.store.purchase.tip"))
					.setRightIcon(PayHelper.getMoneyIcon(cfg.moneyType))
					.setRightText(tostring(cfg.price))
					.setRightClickListener(function()
			LuaTimer:schedule(function()
				PayHelper.checkMoney(cfg.moneyType, cfg.price, function(success)
					if success then
						self.mgr:onBuyPrivilege(info.id)
					end
				end).setRechargeFunc(function()
					ClientHelper.onRecharge(1, "activity_randomStore" .. self.mgr.mainConfig.id)
				end)
			end, 50)
		end).show()
	end)
	for i=1, 6 do
		self.itemList[i].bg:registerEvent(GUIEvent.Click, function()
			self:refreshUI(i)
		end)
	end

	self.mgr:registerCacheChange(function()
		if self:isShow() then
			self:refreshUI(self.selectId)
		else
		end
	end)
end

function GUIRandomStoreWindow:onSecondTick()
	if not self:isShow() then
		return
	end
	self.super.onSecondTick(self)
	local dayEndTime = DateUtil.getGreenwichDayLastTime()
	local leftTime = dayEndTime - os.time()
	self.stTimeCountDown:SetText(DateUtil.getFormatTimeWithDay(leftTime))
end

function GUIRandomStoreWindow:refreshUI(index, forceRefresh)
	self.super.refreshUI(self)
	if not index then
		return
	end
	for i=1, 6 do
		local info = self.mgr.dataCache.storeList[i]
		local item = self.itemList[i]
		if info then
			local cfg = RandomStoreConfig:getRewardById(info.id)
			item.bg:SetVisible(true)
			local reward = self.mgr:getRewardById(cfg.rewardId)
			if not reward then
				return
			end
			--local reward = RewardConfig.findRewardById(cfg.rewardId)
			if index == i then
				item.bg:SetImage("set:random_store.json image:img_0_flag_selected")
				--主奖励展示
				self.stItemName:SetText(Lang:getString(reward.name))
				self.stItemDesc:SetText(Lang:getString(reward.desc))
				if self.mgr.mainConfig.mainRewardId  ~= cfg.rewardId or forceRefresh then
					self.mgr.mainConfig.mainRewardId = cfg.rewardId
					local detailRef = RewardItemShowDetailConfig:getConfigById(reward.showDetailId)
					local detailBak = TableUtil.copyTable(detailRef)
					detailRef.scale = tonumber(cfg.scale) or detailRef.scale
					detailRef.actorRotate = tonumber(cfg.actorRotate) or detailRef.actorRotate
					detailRef.actorYOffset = tonumber(cfg.actorYOffset) or detailRef.actorYOffset
					detailRef.actorXRotate = tonumber(cfg.actorXRotate) or detailRef.actorXRotate
					self.super.showRewardDetail(self)
					detailRef = detailBak
				end
				if info.buyCount >= cfg.limitCount then
					self.btnBuy:SetEnabled(false)
				else
					self.btnBuy:SetEnabled(true)
				end
			else
				item.bg:SetImage("set:random_store.json image:img_0_flag_normal")
			end
			item.limitCount:SetText((cfg.limitCount - info.buyCount) .. "/" ..cfg.limitCount)
			local activityReward = CommonActivityConfig:getRewardById(cfg.rewardId)
			item.quality:SetImage("set:game_activity.json image:img_0_grade_" .. activityReward.quality)
			if activityReward.needMask then
				item.mask:SetImage("set:game_activity.json image:img_0_mask_" .. activityReward.quality)
			else
				item.mask:SetImage("")
			end
			item.icon:SetImage(reward.image)
			if cfg.rewardCount > 1 then
				item.count:SetText("x" .. cfg.rewardCount)
			else
				item.count:SetText("")
			end
			local discount = math.floor((cfg.originPrice - cfg.price) * 100 / cfg.originPrice)
			if discount > 0 then
				item.offIcon:SetVisible(true)
				item.oriPrice:SetVisible(true)
				item.discount:SetText("-" .. discount .. "%")
				item.oriPrice:SetText(cfg.originPrice)
			else
				item.offIcon:SetVisible(false)
				item.oriPrice:SetVisible(false)
			end
			item.priceCount:SetText(cfg.price)
			item.priceIcon:SetImage(PayHelper.getMoneyIcon(cfg.moneyType))
		else
			item.bg:SetVisible(false)
		end
	end
	self.selectId = index
end

function GUIRandomStoreWindow:onShow()
	self:refreshUI(1, true)
	self.mgr:updateLastOpenUIDate()
end

return GUIRandomStoreWindow
