---@class GUIGameTreasureBoxItem1Window : IGUIWindow
local GUIGameTreasureBoxItem1Window = class("GUIGameTreasureBoxItem1Window", IGUIWindow)

---@type TreasureBoxConfig
local TreasureBoxConfig = Plugins.Require("activity", "common.config.TreasureBoxConfig")

---@private
function GUIGameTreasureBoxItem1Window:ctor(...)
    self.super.ctor(self, "GameTreasureBoxItem1.json", ...)
end

---@private
function GUIGameTreasureBoxItem1Window:onLoad()
    self.siIcon = self:getChildWindowByName("GameTreasureBoxItem1-Icon", GUIType.StaticImage)
    self.siEffect = self:getChildWindowByName("GameTreasureBoxItem1-Effect", GUIType.StaticImage)
    self.siLock = self:getChildWindowByName("GameTreasureBoxItem1-Lock", GUIType.StaticImage)

    self:initView()
    self:initEvent()
end

---@private
function GUIGameTreasureBoxItem1Window:initView()

end

---@private
function GUIGameTreasureBoxItem1Window:initEvent()
    self.siIcon:registerEvent(GUIEvent.Click, function()
        if self.data then
            local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
            if cache.haveBuy then
                if not self.data.haveUse then
                    self.mgr:onUseBox(self.index)
                else
                    GUIBoxDetail:showDetail(self.boxItem.boxSettingId)
                end
            else
                GUIBoxDetail:showDetail(self.boxItem.boxSettingId)
            end
        end
    end)
end

---@param mgr CTreasureBoxMgr
---@param data TreasureBoxItemDBData
function GUIGameTreasureBoxItem1Window:onDataChanged(data, mgr, index)
    if not data then
        return
    end
    self.mgr = mgr
    self.data = data
    self.index = index
    self.siIcon:SetVisible(data.status ~= 0)
    self.siEffect:SetVisible(data.status == 1)
    local cache = self.mgr:getPlayerCache(PlayerManager:getClientPlayer())
    self.siLock:SetVisible(data.status ~= 0 and not cache.haveBuy)
    self.boxItem = TreasureBoxConfig:getBoxItem(data.boxId)
    self.siIcon:SetImage(TreasureBoxConfig:getBoxImage(data.boxId, data.status == 2))
end

return GUIGameTreasureBoxItem1Window
