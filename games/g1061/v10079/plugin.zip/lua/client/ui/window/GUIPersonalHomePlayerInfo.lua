---@type FriendManager
local FriendManager = T(Global, "FriendManager")

---@class GUIPersonalHomePlayerInfoWindow : IGUIWindow
local GUIPersonalHomePlayerInfoWindow = class("GUIPersonalHomePlayerInfoWindow", IGUIWindow)

function GUIPersonalHomePlayerInfoWindow:ctor(...)
    self.super.ctor(self, "PersonalHomePlayerInfo.json", ...)
end

function GUIPersonalHomePlayerInfoWindow:onLoad()
    self.llPlayerInfo = self:getChildWindowByName("PersonalHomePlayerInfo-Player-Info", GUIType.Layout)
    self.llHead = self:getChildWindowByName("PersonalHomePlayerInfo-Head", GUIType.Layout)
    self.stLv = self:getChildWindowByName("PersonalHomePlayerInfo-Lv", GUIType.StaticText)
    self.stName = self:getChildWindowByName("PersonalHomePlayerInfo-Name", GUIType.StaticText)
    self.siCountryIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Country-Icon", GUIType.StaticImage)
    self.stCountry = self:getChildWindowByName("PersonalHomePlayerInfo-Country", GUIType.StaticText)
    self.siSex = self:getChildWindowByName("PersonalHomePlayerInfo-Sex", GUIType.StaticImage)
    self.siVip = self:getChildWindowByName("PersonalHomePlayerInfo-Vip", GUIType.StaticImage)
    self.siHot = self:getChildWindowByName("PersonalHomePlayerInfo-Hot", GUIType.StaticImage)
    self.stHotCount = self:getChildWindowByName("PersonalHomePlayerInfo-Hot-Count", GUIType.StaticText)
    self.siLike = self:getChildWindowByName("PersonalHomePlayerInfo-Like", GUIType.StaticImage)
    self.stLikeCount = self:getChildWindowByName("PersonalHomePlayerInfo-Like-Count", GUIType.StaticText)
    self.llIconList = self:getChildWindowByName("PersonalHomePlayerInfo-Icon-List", GUIType.Layout)
    self.llActors = self:getChildWindowByName("PersonalHomePlayerInfo-Actors", GUIType.Layout)
    self.siActorDecor = self:getChildWindowByName("PersonalHomePlayerInfo-Actor-Decor", GUIType.StaticImage)
    self.awPlayer = self:getChildWindowByName("PersonalHomePlayerInfo-Player", GUIType.ActorWindow)
    self.awPet = self:getChildWindowByName("PersonalHomePlayerInfo-Pet", GUIType.ActorWindow)
    self.llVisitors = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors", GUIType.Layout)
    self.siVisitorsIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors-Icon", GUIType.StaticImage)
    self.stVisitorsText = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors-Text", GUIType.StaticText)
    self.llVisitorsList = self:getChildWindowByName("PersonalHomePlayerInfo-Visitors-List", GUIType.Layout)
    self.llStatisticsData = self:getChildWindowByName("PersonalHomePlayerInfo-StatisticsData", GUIType.Layout)
    self.stRecordGameCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Game-Count", GUIType.StaticText)
    self.stRecordGameDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Game-Desc", GUIType.StaticText)
    self.stRecordBattleLikeCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Battle-Like-Count", GUIType.StaticText)
    self.stRecordBattleLikeDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Battle-Like-Desc", GUIType.StaticText)
    self.stRecordCreditCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Credit-Count", GUIType.StaticText)
    self.stRecordCreditDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Credit-Desc", GUIType.StaticText)
    self.stRecordRuneCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Rune-Count", GUIType.StaticText)
    self.stRecordRuneDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Rune-Desc", GUIType.StaticText)
    self.stRecordDressCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Dress-Count", GUIType.StaticText)
    self.stRecordDressDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Dress-Desc", GUIType.StaticText)
    self.stRecordFriendCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Friend-Count", GUIType.StaticText)
    self.stRecordFriendDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Friend-Desc", GUIType.StaticText)
    self.stRecordFollowCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Follow-Count", GUIType.StaticText)
    self.stRecordFollowDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Follow-Desc", GUIType.StaticText)
    self.stRecordPlayDayCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Play-Day-Count", GUIType.StaticText)
    self.stRecordPlayDayDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Play-Day-Desc", GUIType.StaticText)
    self.stRecordRankGameCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Rank-Game-Count", GUIType.StaticText)
    self.stRecordRankGameDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Rank-Game-Desc", GUIType.StaticText)
    self.stRecordFunGameCount = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Fun-Game-Count", GUIType.StaticText)
    self.stRecordFunGameDesc = self:getChildWindowByName("PersonalHomePlayerInfo-Record-Fun-Game-Desc", GUIType.StaticText)
    self.btnAddFriend = self:getChildWindowByName("PersonalHomePlayerInfo-Add-Friend", GUIType.Button)
    self.btnFollow = self:getChildWindowByName("PersonalHomePlayerInfo-Follow", GUIType.Button)
    self.llDressShow = self:getChildWindowByName("PersonalHomePlayerInfo-Dress-Show", GUIType.Layout)
    self.llRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Rank", GUIType.Layout)
    self.siRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Rank-Icon", GUIType.StaticImage)
    self.stRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Rank-Text", GUIType.StaticText)
    self.llMaxRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Max-Rank", GUIType.Layout)
    self.siMaxRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Max-Rank-Icon", GUIType.StaticImage)
    self.stMaxRankIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Max-Rank-Text", GUIType.StaticText)
    self.stKingIcon = self:getChildWindowByName("PersonalHomePlayerInfo-King-Text", GUIType.StaticText)
    self.stAristocratIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Aristocrat-Text", GUIType.StaticText)
    self.stPointsIcon = self:getChildWindowByName("PersonalHomePlayerInfo-Points-Text", GUIType.StaticText)
    self.stCurrentTitle = self:getChildWindowByName("PersonalHomePlayerInfo-Title-Current", GUIType.StaticText)
    self.btnTitleSet = self:getChildWindowByName("PersonalHomePlayerInfo-Title-Set", GUIType.Button)

    self:initView()
    self:initEvent()
end

function GUIPersonalHomePlayerInfoWindow:initView()
    self.stVisitorsText:SetText(Lang:getString("gui.personal.visitors"))
    self.stRecordGameDesc:SetText(Lang:getString("gui.personal.record.game"))
    self.stRecordBattleLikeDesc:SetText(Lang:getString("gui.personal.record.like"))
    self.stRecordCreditDesc:SetText(Lang:getString("gui.personal.record.credit"))
    self.stRecordRuneDesc:SetText(Lang:getString("gui.personal.record.rune"))
    self.stRecordDressDesc:SetText(Lang:getString("gui.personal.record.dress"))
    self.stRecordFriendDesc:SetText(Lang:getString("gui.personal.record.friend"))
    self.stRecordFollowDesc:SetText(Lang:getString("gui.personal.record.follow"))
    self.stRecordPlayDayDesc:SetText(Lang:getString("gui.personal.record.playDay"))
    self.stRecordRankGameDesc:SetText(Lang:getString("gui.personal.record.rank"))
    self.stRecordFunGameDesc:SetText(Lang:getString("gui.personal.record.fun"))
    self.btnAddFriend:SetText(Lang:getString("gui.personal.btn.addFriend"))
    self.btnFollow:SetText(Lang:getString("gui.personal.btn.follow"))
    self.stRankIcon:SetText(Lang:getString("gui.personal.icon.rank"))
    self.stMaxRankIcon:SetText(Lang:getString("gui.personal.icon.maxRank"))
    self.stKingIcon:SetText(Lang:getString("gui.personal.icon.King"))
    self.stAristocratIcon:SetText(Lang:getString("gui.personal.icon.Aristocrat"))
    self.stPointsIcon:SetText(Lang:getString("gui.personal.icon.Points"))
    self.stCurrentTitle:SetText(Lang:getString("gui.personal.notOpen"))

    ---@type GUIBedWarHead
    self.headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
    self.headItem:setArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.llHead:AddChildWindow(self.headItem.root)

    self.lvDressList = IGUIGridView.new("VisitorsListContent-Dress-Show-List", self.llDressShow)
    self.lvDressList.root:SetArea({ 0, 0 }, { 0, 0 }, { 1, 0 }, { 1, 0 })
    self.lvDressList:setConfig(10, 10, 3)
    ---@type DressShowAdapter
    self.dressAdapter = UIHelper.newGameAdapter("DressShowAdapter")
    self.dressAdapter:setItemSize(88, 92)
    self.lvDressList:setAdapter(self.dressAdapter)
end

function GUIPersonalHomePlayerInfoWindow:initEvent()
    self.btnAddFriend:registerEvent(GUIEvent.ButtonClick, function()
        if Game:getPlatformUserId() ~= self.curUserId then
            if FriendManager.IsFriend(self.curUserId) then
                ---打开聊天
                GUIPersonalHomePageLayout:closePersonalHomePage(true)
                GUIBedWarHallChatLayout:hide()
                GUIBedWarHallChatLayout:show(Define.ChatTabType.Friend, self.curUserId)
            else
                ---加好友
                local msg = Lang:getString("gui_friend_request_default_msg")
                GUICustomInputContentLayout:setTipText(Lang:getString("gui_add_friend_msg_text"))
                GUICustomInputContentLayout:setDefaultContentText(msg)
                GUICustomInputContentLayout:setContentChangeListener(function(content)
                    msg = content
                end)
                CustomDialog.builder()
                            .setTitleText("gui_add_friend_msg_title")
                            .setContentView(GUICustomInputContentLayout)
                            .setRightClickListener(function()
                    FriendManager.FriendOperation(Define.FriendOperationType.Request, self.curUserId, msg)
                    UIHelper.showToast(Lang:getString("gui.send.success"))
                end)        .show()
            end
        end
    end)

    self.btnFollow:registerEvent(GUIEvent.ButtonClick, function()
        if Game:getPlatformUserId() ~= self.curUserId then
            local curUserInfo = UserInfoCache:GetCache(self.curUserId)
            if curUserInfo.followStatus == Define.FollowStatus.None or curUserInfo.followStatus == Define.FollowStatus.Fan then
                WebService:FollowOtherPlayer(Game:getPlatformUserId(), self.curUserId, function(code, data)
                    self:showPersonalInfo()
                    Events.PlayerFollowEvent:invoke(self.curUserId, Define.FollowOperationType.Follow)
                end)
            else
                CustomDialog.builder()
                            .setTitleText("gui_dialog_tip_title_tip")
                            .setContentText(Lang:getString("gui.personal.popularity.cancel"))
                            .setRightText("gui_dialog_tip_btn_sure")
                            .setLeftText("gui_dialog_tip_btn_cancel")
                            .setRightClickListener(function()
                    WebService:CancelFollowOtherPlayer(Game:getPlatformUserId(), self.curUserId, function(code, data)
                        self:showPersonalInfo()
                        Events.PlayerFollowEvent:invoke(self.curUserId, Define.FollowOperationType.CancelFollow)
                    end)
                end)
                            .show()
            end
        end
    end)

    self.siHot:registerEvent(GUIEvent.Click, function()
        PopularityValueContentLayout:setData(UserInfoCache:GetCache(self.curUserId))
        PopUpWindows.builder()
                    .setTitleText("gui.personal.popularity.title")
                    .setContentView(PopularityValueContentLayout)
                    .show()
    end)

    self.stHotCount:registerEvent(GUIEvent.Click, function()
        PopularityValueContentLayout:setData(UserInfoCache:GetCache(self.curUserId))
        PopUpWindows.builder()
                    .setTitleText("gui.personal.popularity.title")
                    .setContentView(PopularityValueContentLayout)
                    .show()
    end)

    self.llVisitors:registerEvent(GUIEvent.Click, function()
        VisitorsListContentLayout:setData(UserInfoCache:GetCache(self.curUserId))
        PopUpWindows.builder()
                    .setTitleText("gui.personal.visitors.title")
                    .setContentView(VisitorsListContentLayout)
                    .show()
    end)

    self.siLike:registerEvent(GUIEvent.Click, function()
        if Game:getPlatformUserId() ~= self.curUserId then
            WebService:GivePlayerPageLike(self.curUserId, Game:getPlatformUserId(), function(code)
                ---播一个特效
                if code == 17001 then
                    UIHelper.showToast(Lang:getString("gui.personal.popularity.limit"))
                elseif code == 17002 then
                    UIHelper.showToast(Lang:getString("gui.personal.popularity.once"))
                else
                    WebService:GetPlayerPageLikeCount(self.curUserId, function(code, data)
                        self:showPersonalInfo()
                    end)
                end
            end)
        end
    end)

    local awSlide = self:getChildWindowByName("PersonalHomePlayerInfo-Slide", GUIType.ActorWindow)
    awSlide:registerEvent(GUIEvent.TouchDown, function(events)
        self.awPlayer:TouchDown(events.position)
        self.awPet:TouchDown(events.position)
    end)
    awSlide:registerEvent(GUIEvent.TouchMove, function(events)
        self.awPlayer:TouchMove(events.position)
        self.awPet:TouchMove(events.position)
    end)

    self.llHead:registerEvent(GUIEvent.Click, function()
        if self.curUserId == Game:getPlatformUserId() then
            GUIBedWarPictureFrameShopLayout:show()
        end
    end)
end

---@param userId number
function GUIPersonalHomePlayerInfoWindow:setShowPlayerUserId(userId)
    if not userId then
        return
    end
    self.curUserId = userId
    ---@type BedWarUserInfo
    local userInfo = UserInfoCache:GetCache(userId)
    self:showPersonalInfo()
    self.awPlayer:SetActorByUserId(userId)

    if not userInfo.pageLike then
        WebService:GetPlayerPageLikeCount(userId, function(code, data)
            self:showPersonalInfo()
        end)
    end

    if not userInfo.fansNum then
        WebService:GetFollowPlayerCount(userId, function(code, data)
            self:showPersonalInfo()
        end)
    end

    if self.curUserId ~= Game:getPlatformUserId() then
        self.btnAddFriend:SetVisible(true)
        if userInfo.friend then
            self.btnAddFriend:SetText(Lang:getString("gui.personal.btn.chat"))
        else
            self.btnAddFriend:SetText(Lang:getString("gui.personal.btn.addFriend"))
        end

        self.btnFollow:SetVisible(true)
        if userInfo.followStatus then
            if userInfo.followStatus == Define.FollowStatus.Follow or userInfo.followStatus == Define.FollowStatus.EachFollow then
                self.btnFollow:SetText(Lang:getString("gui.personal.btn.followed"))
            else
                self.btnFollow:SetText(Lang:getString("gui.personal.btn.follow"))
            end
        else
            self:updateFollowStatus()
        end
        self.llVisitors:SetVisible(false)
    else
        self.btnAddFriend:SetVisible(false)
        self.btnFollow:SetVisible(false)

        if not userInfo.visitorInfos then
            local getVisitorList = function(code, data)
                local visitorIds = {}
                for _, visitor in pairs(data.visitorInfos) do
                    table.insert(visitorIds, visitor.visitorId)
                end
                UserInfoCache:GetCacheByUserIds(visitorIds, function()
                    self.llVisitors:SetVisible(true)
                    ---展示拜访者头像
                    local itemNum = 0
                    for _, visitor in pairs(data.visitorInfos) do
                        local visitorInfo = UserInfoCache:GetCache(visitor.visitorId)
                        if visitorInfo then
                            ---@type GUIBedWarHead
                            local headItem = UIHelper.newGameGUIWindow("GUIBedWarHead")
                            headItem:setArea({ 0, (50) * (itemNum - 1) }, { 0, 0 }, { 0, 40 }, { 0, 40 })
                            headItem:setUserInfo(visitorInfo)
                            headItem:setCanOpenPersonalHome(false)
                            self.llVisitorsList:AddChildWindow(headItem.root)
                            itemNum = itemNum + 1
                            if itemNum >= 3 then
                                break
                            end
                        end
                    end
                end)
            end
            WebService:getVisitorListInfo(userId, getVisitorList)
        else
            self.llVisitors:SetVisible(true)
        end
    end
end

function GUIPersonalHomePlayerInfoWindow:showPersonalInfo()
    ---@type BedWarUserInfo
    local userInfo = UserInfoCache:GetCache(self.curUserId)

    if userInfo.sex then
        self.siSex:SetImage(Define.SexIcon[userInfo.sex])
    end
    if userInfo.curOldHonorId then
        self.siRankIcon:SetAlpha(1)
        self.siRankIcon:SetImage(Define.RankIcon[userInfo.curOldHonorId + 1])
    else
        self.siRankIcon:SetAlpha(0.5)
    end

    if userInfo.maxOldHonorId then
        self.siMaxRankIcon:SetAlpha(1)
        self.siMaxRankIcon:SetImage(Define.RankIcon[userInfo.maxOldHonorId + 1])
    else
        self.siMaxRankIcon:SetAlpha(0.5)
    end

    self.awPet:SetVisible(false)
    if userInfo.pet ~= 0 then
        local goods = CustomShopConfig:getGoodsConfig(userInfo.currentPet)
        if goods then
            local pet = CustomShopPet.Settings[tostring(goods.SettingId)]
            if pet then
                self.awPet:SetActor1(pet.ActorName, "idle", 0)
                self.awPet:SetWidth({ pet.scale, 0 })
                self.awPet:SetVisible(true)
            end
        end
    end

    if userInfo.valuableDress then
        local dress = StringUtil.split(userInfo.valuableDress, "#")
        self.dressAdapter:setData(dress)
    else
        self.dressAdapter:clearItems()
    end
    if not userInfo.vip or userInfo.vip == 0 then
        self.siVip:SetVisible(false)
    else
        self.siVip:SetVisible(true)
        self.siVip:SetImage(Define.VipIcon[userInfo.vip])
    end

    if userInfo.followStatus == Define.FollowStatus.Follow or userInfo.followStatus == Define.FollowStatus.EachFollow then
        self.btnFollow:SetText(Lang:getString("gui.personal.btn.followed"))
    else
        self.btnFollow:SetText(Lang:getString("gui.personal.btn.follow"))
    end

    self.headItem:setUserInfo(userInfo)
    self.headItem:setCanOpenPersonalHome(false)
    self.stLv:SetText("Lv." .. (userInfo.playerLevel or 1))
    self.stName:SetText(userInfo.name)
    local country = userInfo.country and CGame.Instance():getShellInterface():getCountryDetail(userInfo.country) or Lang:getString("gui_unknown_country")
    self.stCountry:SetText(country)
    self.stLikeCount:SetText(userInfo.pageLike or 0)
    self.stHotCount:SetText((userInfo.pageLike or 0) + (userInfo.fansNum or 0) + 100)
    self.stRecordRuneCount:SetText(userInfo.runeLevel or 0)
    self.stRecordDressCount:SetText(userInfo.dressCount or 0)
    self.stRecordGameCount:SetText(userInfo.totalGameTimes or 0)
    self.stRecordBattleLikeCount:SetText(userInfo.battleLikeCount or 0)
    self.stRecordPlayDayCount:SetText((tonumber(userInfo.playDays) or 0) + 1)
    self.stRecordRankGameCount:SetText(userInfo.totalRankTimes or 0)
    self.stRecordFunGameCount:SetText(userInfo.totalFunTimes or 0)
    self.stRecordFollowCount:SetText(userInfo.fansNum or 0)
    self.stRecordFriendCount:SetText(userInfo.friendCount or 0)
    --TODO
    self.stRecordCreditCount:SetText(userInfo.creditLevel or 0)
end

function GUIPersonalHomePlayerInfoWindow:updateFollowStatus()
    WebService:EnquiryFollowRelations(Game:getPlatformUserId(), { self.curUserId }, function(code, data)
        WebService:GetFollowPlayerCount(self.curUserId, function(code, data)
            self:showPersonalInfo()
        end)
    end)
end

return GUIPersonalHomePlayerInfoWindow
