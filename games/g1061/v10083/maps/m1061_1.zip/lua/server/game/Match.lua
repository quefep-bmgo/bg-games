---@type RecentPlayUtil
local RecentPlayUtil = T(Global, "RecentPlayUtil")
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")
---@type SRankUtil
local SRankUtil = T(Global, "SRankUtil")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type SGameLicense
local SGameLicense = T(Global, "SGameLicense")

GameMatch = {}

GameMatch.Status = {}
GameMatch.Status.Init = 0
GameMatch.Status.WaitingPlayer = 1
GameMatch.Status.GameTime = 2
GameMatch.Status.GameOver = 3

GameMatch.curStatus = GameMatch.Status.Init
GameMatch.hasStartGame = false
GameMatch.hasEndGame = false
GameMatch.startServerTime = os.time()
GameMatch.startGameTime = os.time()
GameMatch.startGamePlayer = 0

---@type GameTeam[]
GameMatch.Teams = {}
---@type Vector3[]
GameMatch.cannotPlaceBlock = {}

function GameMatch:init()
    ---init teams
    local teams = TeamConfig:getTeams()
    for _, config in pairs(teams) do
        local team = GameTeam.new(config, TeamConfig:getTeamColor(config.id))
        GameMatch.Teams[config.id] = team
    end
    WaitingPlayerTask:start()
    TreasureChallenge:setSeasonRefreshTimer()
    GameMatch.startServerTime = os.time()
end

---创建出未成功登陆的AI玩家暂时先代替玩家
function GameMatch:createUnLoginPlayerAI()
    local infoList = GameInfoManager:getAllPlayerInfo()
    for userId, info in pairs(infoList) do
        userId = tonumber(userId)
        if not PlayerManager:getPlayerByUserId2(userId) and PlayerManager:getPlayerCount2() < PlayerManager:getRoomMaxPlayer() then
            local attr = GameServer:getRoomManager():getUserAttrInfo(userId)
            if attr then
                local teamId = info:getValue("teamId", true)
                AITeamManager:newAi(0, teamId, userId, attr.name)
            end
        end
    end
end

function GameMatch:startMatch()
    ServerHelper.putBoolPrefs("DisableRemovePlayer", true)

    self.hasStartGame = true
    self.startGameTime = os.time()
    self.startGamePlayer = SettlementManager:getPlayerCount()
    self.startAIPlayer = 0
    for _, player in pairs(PlayerManager:getPlayers()) do
        if PlayerManager:isAIPlayer(player) then
            self.startAIPlayer = self.startAIPlayer + 1
        end
    end

    self:createUnLoginPlayerAI()
    ---初始化数据站 数据. 包括队伍创建
    GameInfoManager.Instance():initInfo()
    GainsConfig:onGameStart()

    local players = PlayerManager:getPlayers2()
    for _, player in pairs(players) do
        player:setShowName(player:buildShowName())
        ---回满血
        player:setHealth(player:getMaxHealth())
        player:sendPacket({
            pid = "SyncStartGameTime",
            startGameTime = self.startGameTime
        })
        if player:checkReady() then
            player:onSpawnInGame()
            CommonPacketSender:sendGameStart(player)
        end
        CreditScoreUtil:onMatchStart(player, self.startGameTime)
    end

    RewardManager:startGame()
    RecentPlayUtil:recordGamePlayer()

    if GameMatch:getLifeTeams() <= 1 then
        MessagesManage:sendSystemTipsToAll(IMessages:msgGameOverByLittle())
        self:endMatch()
    else
        MessagesManage:sendSystemTipsToAll(IMessages:msgGameStart())
        GameTimeTask:start()
    end

    PropBlockConfig:createBedProtect()

    if PlayerManager:getPlayerCount() ~= 16 or GameConfig.startPlayers ~= 16 or SettlementManager:getPlayerCount() ~= 16 then
        print("PlayerManager:getPlayerCount()", PlayerManager:getPlayerCount())
        print("GameConfig.startPlayers", GameConfig.startPlayers)
        print("SettlementManager:getPlayerCount()", SettlementManager:getPlayerCount())
    end

end

function GameMatch:endMatch()
    self.hasEndGame = true
    if GameConfig and GameConfig.gameTime then
        HostApi.log("endMatch " .. GameConfig.gameTime)
    end

    GameTimeTask:pureStop()

    local finalWin = true
    local winner = 0

    if GameMatch:getLifeTeams() > 1 then
        finalWin = false
    end

    local winTeam

    for _, team in pairs(self.Teams) do
        if finalWin and team:isDeath() == false then
            winTeam = team
            winner = team.id
        end
    end
    SettlementManager:updateFinalSettlement(winner)

    if finalWin and winTeam ~= nil then
        local players = PlayerManager:getPlayers()
        for _, player in pairs(players) do
            MessagesManage:sendSystemTipsToPlayer(player.rakssid, IMessages:msgWinnerInfo(winTeam:getDisplayName(player:getLanguage())))
            if player.teamId == winner then
                SurveyManager:onGameEnd(player)
            end
        end
    else
        MessagesManage:sendSystemTipsToAll(IMessages:msgNoWinner(1))
    end
    AIManager:onGameOver()
    HostApi.sendPlaySound(0, 10003)
    GameOverTask:start()
    ServerReportEvent.server_game_end()
end

function GameMatch:cleanPlayer()
    self:doReport()
    ---@type GamePlayer[]
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        player:overGame()
    end
end

function GameMatch:doReport()
    ---@type GamePlayer[]
    local players = PlayerManager:getPlayers()
    for _, player in pairs(players) do
        player:onQuit()
    end
    SRankUtil:tryReport()
    GameServer:closeServer()
end

function GameMatch:getLifeTeams()
    local lifeTeam = 0
    for _, team in pairs(self.Teams) do
        if team:isDeath() == false then
            lifeTeam = lifeTeam + 1
        end
    end
    return lifeTeam
end

function GameMatch:getRealLifeTeams()
    local lifeTeam = 0
    for _, team in pairs(self.Teams) do
        if team.realLife then
            lifeTeam = lifeTeam + 1
        end
    end
    return lifeTeam
end

function GameMatch:ifGameOver()
    if not self.hasStartGame or self.hasEndGame then
        return
    end
    local lifeTeam = self:getLifeTeams()
    if lifeTeam <= 1 then
        self:endMatch()
    end
end

---@param player GamePlayer
function GameMatch:onPlayerDie(player)
    player.isKeepItem = false
    if not player.team or not player.isLife then
        return
    end
    if player.team.isHaveBed then
        RespawnPrivilege:onShowBuyKeepItem(player)
        return
    end
    player.realLife = false
    if player.team:getRealLifePlayerCount() == 0 then
        ---没有队友存活，直接死亡，同时杀死弹出弹窗等待复活中的对友
        for _, teammate in pairs(player.team.playerList) do
            teammate:onDie()
        end
    else
        ---有队友存活，弹出购买复活弹窗
        local ai = AIManager:getAIByRakssid(player.rakssid)
        if ai ~= nil then
            ---AI不选择复活
            ai.luaPlayer:onDie()
        else
            if player.isDisconnect then
                ---掉线直接选择死亡
                player:onDie()
            else
                RespawnPrivilege:onShowBuyRespawn(player)
            end
        end
    end
    GameMatch:ifGameOver()
end

function GameMatch:isGameStart()
    return self.hasStartGame
end

function GameMatch:isGameEnd()
    return self.hasEndGame
end

---@param player GamePlayer
function GameMatch:onPlayerQuit(player)
    RecentPlayUtil:updateRecentPlayRecord(player)
    QualifyingHelper:onPlayerLogout(player)
    TreasureChallenge:onPlayerLogout(player)
    SGameLicense:onPlayerLogout(player)
    player:onLogout()
    player:onQuit()
    local ai = AIManager:getAIByRakssid(player.rakssid)
    if ai then
        ai:onLogout()
    end
end

function GameMatch:checkInArea()
    if not GameConfig.MovementArea then
        return
    end
    local players = PlayerManager:getPlayers2()
    ---@param player GamePlayer
    for _, player in pairs(players) do
        if not player:isDead() and not GameConfig.MovementArea:inArea(player:getPosition()) then
            ---提示
            MessagesManage:sendSystemTipsToPlayer(player.rakssid, Messages:msgOutOfArea())
            player:subHealth(GameConfig.outOfAreaHurt)
        end
    end
end

return GameMatch

--endregion
