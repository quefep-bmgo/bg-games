PlayerListener = {}
---@type PropPacketManager
local PropPacketManager = require "common.manager.PropPacketManager"
---@type ReconnectUtil
local ReconnectUtil = T(Global, "ReconnectUtil")
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")

function PlayerListener:init()
    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerAttackedEvent, self.onPlayerHurtForSettlement)
    BaseListener.registerCallBack(CEvents.PlayerDieEvent, self.onPlayerDied)
    BaseListener.registerCallBack(CEvents.PlayerDieTipEvent, self.onPlayerDiedTip)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)

    CEvents.PlayerUseCommonItemEvent:registerCallBack(self.onPlayerUseCommonItem)
    CEvents.PlayerDropItemEvent:registerCallBack(self.onPlayerDropItem)
    CEvents.PlayerExchangeItemEvent:registerCallBack(self.onPlayerExchangeItem)
    CEvents.PlayerPickupItemEndEvent:registerCallBack(self.onPlayerPickupItemEnd)
    CEvents.PotionCustomEvent:registerCallBack(self.onPotionCustom)
    CEvents.ItemSkillNeedCustomSpeedEvent:registerCallBack(self.onItemSkillNeedCustomSpeed)
    CEvents.KnockBackExtraStrengthEvent:registerCallBack(self.onKnockBackExtraStrength)
    CEvents.PlayerBackHallEvent:registerCallBack(self.onPlayerBackHall)
    CEvents.PlayerAttackCreatureEvent:registerCallBack(self.onPlayerAttackCreature)
    CEvents.UseFishHookHitEntityEvent:registerCallBack(self.onUseFishHookHitEntity)
    CEvents.OnLaunchArrowEvent:registerCallBack(self.onLaunchArrow)
    CEvents.OnArrowHitEntityEvent:registerCallBack(self.onArrowHitEntity)
    CEvents.OnArrowHitGroundEvent:registerCallBack(self.onArrowHitGround)
    CEvents.InventoryStackChange:registerCallBack(self.onInventoryStackChange)
    CEvents.PlayerChangeItemInHandEvent:registerCallBack(self.onChangeItemInHand)
    CEvents.PlayerCheatEvent:registerCallBack(self.onPlayerCheat)
    CEvents.PlayerMovementInputEvent:registerCallBack(self.onPlayerMovementInput)

    Events.PlayerBuyGoodEvent:registerCallBack(self.onPlayerBuyGood)
    Events.PlayerBackBedWarHallEvent:registerCallBack(self.onPlayerBackHall)

    Events.PlayerClickMainControlEvent:registerCallBack(self.onPlayerClickMainControl)

    Events.PlayerUseActionEvent:registerCallBack(self.onPlayerUseAction)
    Events.PlayerIntoFollowModeEvent:registerCallBack(self.onPlayerIntoFollowMode)
end

function PlayerListener.onPlayerExchangeItem(rakssid, type, itemId, itemMeta, itemNum, bullets, vec3)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    if type == 1 then
        return ItemHelper:canDropItem(player, itemId)
    elseif type == 2 then
        local item = Item.getItemById(itemId)
        if item and item:getClassName() == "ItemSword" then
            player:removeWoodSword()
        end
        return true
    end
end

---@param clientPeer ClientPeer
function PlayerListener.onPlayerLogin(clientPeer)
    local userId = clientPeer:getPlatformUserId()
    local player = ReconnectUtil:findDroppedPlayer(userId)
    if GameMatch:isGameEnd() then
        if player then
            player.entityPlayerMP = nil
        end
        return GameOverCode.GameEnd
    end
    if SettlementManager:getPlayerCount() >= PlayerManager:getRoomMaxPlayer() and not SettlementManager:isInGame(userId) then
        if player then
            player.entityPlayerMP = nil
        end
        return GameOverCode.GameEnd
    end
    local attr = GameServer:getRoomManager():getUserAttrInfo(userId)
    local info = GameInfoManager:getPlayerInfo(userId)
    if attr and not info then
        GameInfoManager:newPlayerInfo(userId)
        info = GameInfoManager:getPlayerInfo(userId)
        info:setValue("teamId", attr and attr.team or 1)
    end
    if GameMatch:isGameStart() and not info:getBoolValue("isLogin") and clientPeer:getRakssid() > 100 then
        ReconnectUtil:clearGameServerData(userId)
        if player then
            player.entityPlayerMP = nil
        end
        return GameOverCode.GameStarted
    end
    info:setValue("isLogin", true)
    local isReconnect = false
    local logoutPos
    if attr and not attr.isRobot then
        local aiPlayer = AIManager:getAIByUserId(userId)
        if aiPlayer and PlayerManager:getPlayerByUserId(userId) then
            logoutPos = aiPlayer:getPosition()
            aiPlayer:logout(true)
        end
    end
    ---@type GamePlayer
    if not player then
        if info:getValue("rank", true) ~= 0 then
            ---游戏已结束
            return GameOverCode.GameOver
        end
        player = GamePlayer.new(clientPeer)
        if logoutPos then
            player.logoutPos = logoutPos
            player:teleportPos(logoutPos)
        end
    else
        isReconnect = true
        player:ctor(clientPeer)
        player.isKeepItem = true
        player:setInventory()
    end
    player:init(info)
    SettlementManager:initPlayer(player)
    GamePacketSender:sendMapId(player.rakssid, GameConfig.mapId)
    HostApi.sendGameStatus(player.rakssid, 1)
    ServerReportEvent.player_login(player)
    if attr then
        GameServer:getRoomManager():sendUserIn(attr.userId, attr.requestId)
    end
    SettlementManager:addPlayerInfo(player.userId, player.info)
    return GameOverCode.Success, player, nil, nil, (isReconnect and 3000 or -1)
end

---@param player GamePlayer
function PlayerListener.onPlayerLogout(player)
    CreditScoreUtil:onPlayerLogout(player)
    PropPacketManager:onPlayerDied(player)
    if not GameMatch:isGameStart() then
        ---游戏没开始，正常退出
        ReconnectUtil:clearGameServerData(player.userId)
        local attr = GameServer:getRoomManager():getUserAttrInfo(player.userId)
        if attr then
            GameServer:getRoomManager():sendUserOut(attr.userId, attr.requestId)
        end
        SettlementManager:removePlayerInfo(player)
        GameLottery:removePlayerLotteryInfo(player.userId)
    else
        if player.isLife then
            ReconnectUtil:addDroppedPlayer(player)
        end
    end
    GameMatch:onPlayerQuit(player)
    PlayerCustomInfoUtil:reportOnQuit(player)
    ServerReportEvent.player_logout(player)
    if player.isNew then
        ServerReportEvent.new_player_logout(player)
    end
end

---@param player GamePlayer
function PlayerListener.onPlayerReady(player)
    HostApi.sendPlaySound(player.rakssid, 10000)
    DbUtil:getPlayerData(player)
    player:checkParty()
    if GameConfig.openLotterySwitch == 1 then
        GamePacketSender:sendBedWarOpenLottery(player.rakssid)
    end
    if GameMatch:isGameStart() then
        GameResourceManager:synTeamResource(player)
        HostApi.setAllowUseItemStatus(player.rakssid, 1)
    else
        HostApi.setAllowUseItemStatus(player.rakssid, 0)
    end
    GameInfoManager.Instance():onPlayerReady(player)
    player.info:setValue("lifeStatus", player.isLife)
    GamePacketSender:sendMoveLimitCheck(player.rakssid)
    GameLottery:addPlayerLotteryInfo(player.userId)
    ServerReportEvent.player_ready(player)
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerHurtForSettlement(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---@type GamePlayer
    local needHurt = PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    if needHurt then
        ---@type GamePlayer
        local _player = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
        ---@type GamePlayer
        local fromer = PlayerManager:getPlayerByPlayerMP(hurtFrom)
        if _player and fromer then
            SettlementManager:onPlayerHurt(hurtPlayer:getPlatformUserId(), hurtFrom:getPlatformUserId(), tonumber(hurtValue.value))
            if _player.gameDataController then
                _player.gameDataController:have_be_attacked()
            end
            if fromer.gameDataController then
                fromer.gameDataController:have_attack_player()
            end
        else
            SettlementManager:onPlayerHurt(hurtPlayer:getPlatformUserId(), nil, tonumber(hurtValue.value))
        end
        local hurter = PlayerManager:getPlayerByPlayerMP(hurtPlayer)
        if hurter and hurter.mount then
            hurter.mount:onHurt(hurtValue.value)
            needHurt = false
        end
    end
    return needHurt
end

function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    ---@type GamePlayer
    local hurter = PlayerManager:getPlayerByPlayerMP2(hurtPlayer)
    if hurter == nil then
        return false
    end
    if hurter.isInvincible then
        ---无敌时间
        return false
    end
    if hurter.hurtLock then
        ---受伤保护时间
        return false
    end
    hurter.hurtLock = LuaTimer:schedule(function()
        hurter.hurtLock = nil
    end, 250)
    ---@type GamePlayer
    local fromer = PlayerManager:getPlayerByPlayerMP(hurtFrom)
    if fromer ~= nil then
        if damageType == "explosion.player" and fromer.onWithered then
            hurtValue.value = 0
            hurter:subHealth(GameConfig.tntExplosionDamageFactor)
        end
        hurter.damageType = "player"
    end
    if (fromer and AIManager:isAI(fromer.rakssid)) and not AIManager:isAI(hurter.rakssid or 0) then
        hurtValue.value = hurtValue.value * GameConfig.aiDamageCoefficient
    end

    if AIManager:isAI(hurter.rakssid) then
        local ai = AIManager:getAIByRakssid(hurter.rakssid)
        if ai then
            ai:onHurt()
        end
    end
    -- HostApi.log("onPlayerHurt " .. damageType)

    if not GameMatch:isGameStart() then
        if damageType == "outOfWorld" then
            hurter:teleWaitPos()
        end
        return false
    end

    if damageType == "fall" then
        local blockId = EngineWorld:getBlockId(VectorUtil.getNegY(hurtPlayer:getPosition()))
        if blockId == 0 or blockId == 165 then
            return false
        end
        if InventoryUtil:getPlayerHasEquipItem(hurter, Define.ItemId.NinjaShoes) then
            return false
        end
        if InventoryUtil:getPlayerHasEquipItem(hurter, Define.ItemId.NinjaShoes) then
            return false
        end
        if hurter.ignoreOnceFall then
            return false
        end
        hurter.damageType = "fall"
    end

    if damageType == "explosion.player" or damageType == "explosion" then
        hurtValue.value = hurter:subApple(hurtValue.value)
        hurter.damageType = "explosion"
        return true
    end

    if damageType == "outOfWorld" then
        if hurter.isLife == false and hurter.realLife == false then
            hurter:teleWatchPos()
            return false
        end
        hurter.damageType = damageType
        hurtValue.value = hurter:subApple(hurtValue.value)
        hurter.damageType = "outOfWorld"
        return true
    end

    if damageType == "arrow" then
        hurter.damageType = "arrow"
    end

    if damageType == "onFire" then
        hurter.damageType = "onFire"
    end

    if hurtFrom == nil then
        hurtValue.value = hurter:subApple(hurtValue.value)
        return true
    end

    if fromer ~= nil then
        if hurter.team and fromer.team and hurter.team.id == fromer.team.id then
            return false
        end
        CreditScoreUtil:onPlayerActive(fromer)
        RuneManager:onAttack(fromer, hurtValue, damageType, hurter)
    end

    if damageType ~= "fall" and damageType ~= "explosion.player" and damageType ~= "explosion"
            and damageType ~= "outOfWorld" then
        hurter:addCustomEffect("beAttackEffect" .. tostring(hurter.userId), GameConfig.beAttackEffect, GameConfig.beAttackEffectTime * 1000)
    end

    RuneManager:onHurted(hurter, hurtValue)
    if hurtValue.value < 1 then
        hurtValue.value = 1
    end
    hurtValue.value = hurter:subApple(hurtValue.value)
    BuffManager:onPlayerByInterrupt(hurter.userId)
    return true
end

function PlayerListener.onPlayerDiedTip(diePlayer, killPlayer)
    return false
end

function PlayerListener.onPlayerDied(diePlayer, _, killPlayer)
    ---@type GamePlayer
    local dier = PlayerManager:getPlayerByPlayerMP2(diePlayer)
    if not dier then
        return true
    end
    PropPacketManager:onPlayerDied(dier)
    if not dier.isLife then
        return true
    end
    if not GameMatch:isGameStart() then
        dier:setInventory()
        dier:clearInv()
        RespawnHelper.addRespawnCountdown(dier, 0)
        return true
    end
    dier.lastDieTime = os.time()

    ---@type GamePlayer
    local killer = PlayerManager:getPlayerByPlayerMP(killPlayer)
    if killer then
        killer:onKill(dier)
    end

    dier:clearEffects()
    dier:clearArmorInfo()
    dier:setInventory()
    dier:setEnderInventory()
    LuaTimer:schedule(function()
        dier:teleWatchPos()
    end, 0)
    dier:resetApple()
    dier.curApple = 0
    dier.maxApple = 0
    dier:updateApple()
    dier.deathNum = dier.deathNum + 1
    dier:resetHollowBlock()
    if killer then
        local useItemId = killer:getHeldItemId()
        if not killer.itemKillRecord[tostring(useItemId)] then
            killer.itemKillRecord[tostring(useItemId)] = 0
        end
        killer.itemKillRecord[tostring(useItemId)] = killer.itemKillRecord[tostring(useItemId)] + 1
    end
    if dier.damageType == "outOfWorld" then
        if dier.gameDataController then
            dier.gameDataController:hollow_die_count()
        end
    end
    GameMatch:onPlayerDie(dier)
    dier.multiKill = 0
    dier.info:setValue("lifeStatus", false)
    local ai = AIManager:getAIByRakssid(dier.rakssid)
    if ai ~= nil then
        ai:refreshInv()
        ai.isLife = false
    end
    if dier.backPearTimer ~= 0 and dier.backPearTimer ~= nil then
        LuaTimer:cancel(dier.backPearTimer)
        dier.backPearTimer = 0
    end
    return true
end

---@param player GamePlayer
function PlayerListener.onPlayerRespawn(player)
    if GameMatch:isGameStart() == false then
        AddMaxHPPrivilege:onPlayerRespawn(player)
        player:fillInvetory(player.inventory)
        player:teleWaitPos()
        PropPacketManager:onPlayerRespawn(player)
        return GameConfig.isNightPotion and 43200 or 0
    end

    RuneManager:onRespawn(player)
    AddMaxHPPrivilege:onPlayerRespawn(player)
    player:onSpawnInGame()
    PropPacketManager:onPlayerRespawn(player)
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerUseCommonItem(rakssId, itemId)

    local player = PlayerManager:getPlayerByRakssid(rakssId)
    if player == nil then
        return
    end

    if itemId >= 467 and itemId <= 471 then
        local pos = player:getPosition()
        if BridgeConfig:buildBridge(itemId, player:getYaw(), VectorUtil.toBlockVector3(pos.x, pos.y - 1, pos.z)) then
            SettlementManager:addBuildScore(player.userId, Define.BuildType.Egg)
        end
    end
end

function PlayerListener.onPlayerDropItem(rakssid, itemId, itemMeta)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end
    BuffManager:onPlayerByInterrupt(player.userId)
    return ItemHelper:canDropItem(player, itemId)
end
----------------------------------------------------------------------------
-----------------------------  临时  ----------------------------------------
local iceTime = 3
local range = 1
function PlayerListener.changeBlockToIce(old_blockId, position, userId)
    if EngineWorld:getBlockId(position) ~= BlockID.PACKED_ICE then
        EngineWorld:setBlock(position, BlockID.PACKED_ICE)
    end
    LuaTimer:schedule(function()
        if EngineWorld:getBlockId(position) == BlockID.PACKED_ICE then
            local player = PlayerManager:getPlayerByUserId(userId)
            if not player then
                EngineWorld:setBlock(position, old_blockId)
                return
            end
            local newPos = player:getPosition()
            if math.abs(newPos.x - position.x) < range + 1 and
                    math.floor(newPos.y - 0.5) == position.y and
                    math.abs(newPos.z - position.z) < range + 1 then
                PlayerListener.changeBlockToIce(old_blockId, position, userId)
                return
            end
            EngineWorld:setBlock(position, old_blockId)
        end
    end, iceTime * 1000)
end

function PlayerListener.canBeIce(blockId)
    return blockId ~= BlockID.AIR
            and blockId ~= BlockID.PACKED_ICE
            and blockId ~= BlockID.OBSIDIAN
            and blockId ~= BlockID.WATER_MOVING
            and blockId ~= BlockID.WATER_STILL
            and blockId ~= BlockID.FIRE
            and blockId ~= BlockID.WOOL_CARPET
end
---@param player GamePlayer
function PlayerListener.checkSkatingShoes(player, pos)
    if player.equip_iec then
        local cur_block_pos = VectorUtil.toBlockVector3(pos.x, pos.y, pos.z)
        local cur_block_id = EngineWorld:getBlockId(cur_block_pos)
        if cur_block_id == BlockID.FIRE then
            EngineWorld:setBlock(cur_block_pos, BlockID.AIR)
        end
        for i = pos.x - range, pos.x + range do
            for j = pos.z - range, pos.z + range do
                local position = VectorUtil.toBlockVector3(i, pos.y - 1, j)
                local floor_block_id = EngineWorld:getBlockId(position)
                if PlayerListener.canBeIce(floor_block_id) and EngineWorld:isBlockChange(position) then
                    PlayerListener.changeBlockToIce(floor_block_id, position, player.userId)
                end
            end
        end
    end
end
-----------------------------  临时  ----------------------------------------
----------------------------------------------------------------------------
function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return true
    end

    if y <= GameConfig.useHollowBlockHeight and GameMatch:isGameStart() and not player.useHollowBlock then
        player:canUseHollowBlock()
        player.last_pos_y = y
        player.fall_times = 0
        player.up_times = 0
    end
    if player.useHollowBlock and not player:isGlide() then
        if player.last_pos_y < y then
            player.fall_times = 0
            player.up_times = player.up_times + 1
        else
            player.fall_times = player.fall_times + 1
        end
        player.last_pos_y = y
        if (player.fall_times > 5 and player.fall_times < player.up_times) or y >= GameConfig.startGlideHeight then
            player:setGlide(true)
            player.ignoreOnceFall = true
            player:startSinging(GameConfig.glideDuration * 1000, false, Define.SingingIcon.HollowBlock)
            LuaTimer:cancel(player.cancelGlideKey or 0)
            player.cancelGlideKey = LuaTimer:schedule(function(userId)
                local c_player = PlayerManager:getPlayerByUserId(userId)
                if c_player then
                    c_player:setGlide(false)
                    c_player:resetHollowBlock()
                end
            end, GameConfig.glideDuration * 1000, nil, tostring(player.userId))
        end
    end

    if y <= GameConfig.deathLineY then
        if (GameMatch:isGameStart() == false) then
            player:teleWaitPos()
        else
            player.damageType = "outOfWorld"
            player:subHealth(99999)
        end

    end
    if GameResourceManager:onPlayerMove(player, x, y, z) then
        if player.gameDataController then
            player.gameDataController:have_pick_resource_in_point()
        end
    end
    TeamConfig:onPlayerMove(player, x, y, z)

    local curPos = VectorUtil.newVector3(math.floor(x), math.floor(y), math.floor(z))
    if player.gameDataController and player.lastPos then
        if curPos.x ~= player.lastPos.x or curPos.z ~= player.lastPos.z then
            player.gameDataController:move_block_count()
        end
    end
    if player.realLife and movePlayer.onGround == true then
        if player:isGlide() then
            player:resetHollowBlock()
        end
        player.ignoreOnceFall = false
        if not player.lastGroundPos or VectorUtil.hashVector3(curPos) ~= VectorUtil.hashVector3(player.lastGroundPos) then
            player.lastGroundPos = curPos
        end
    end
    PlayerListener.checkSkatingShoes(player, VectorUtil.newVector3(x, y, z))
    player.lastPos = curPos
    return true
end

function PlayerListener.onPlayerMovementInput(rakssid, forward, strafe)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    CreditScoreUtil:onPlayerMoveInput(player)
    return true
end

function PlayerListener.onPlayerPickupItemEnd(rakssid, itemId, itemNum, _, entityId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    GameResourceManager:onPickUpItem(player, entityId, itemId, itemNum)
    ItemHelper:tryChangePickUpItem(player, itemId)
end

function PlayerListener.onPotionCustom(entityId, itemId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return true
    end
    local effect = ItemPotionEffect:getPotionEffect(itemId)
    if not effect then
        return true
    end
    Plugins.CallTargetPluginFunc("trigger_gift", "recordPlayerUseItem", player, itemId, 1)
    player:addEffect(effect.Type, effect.Duration, effect.Level)
    return false
end

function PlayerListener.onItemSkillNeedCustomSpeed(rakssid, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return true
    end

    if ItemID.FLARE_BOMB == itemId then
        return false
    end

    return true
end

function PlayerListener.onKnockBackExtraStrength(hurterEntityId, attackerEntityId, knockBackValue)
    local hurter = PlayerManager:getPlayerByEntityId(hurterEntityId)
    local attacker = PlayerManager:getPlayerByEntityId(attackerEntityId)

    if hurter and attacker then
        knockBackValue.value = knockBackValue.value + tonumber(attacker.info:getValue("runeAddKnockBackValue"))
    end
    return true
end

function PlayerListener.onPlayerBackHall(id)
    local player = PlayerManager:getPlayerByRakssid(id)
    if player == nil then
        player = PlayerManager:getPlayerByUserId(id)
        if player == nil then
            return
        end
    end
    BackHallManager:addPlayer(player)
end

function PlayerListener.onPlayerUseAction(userId, actionId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    CommonPacketSender:sendUseActionToAll(player:getEntityId(), actionId)
end

function PlayerListener.onPlayerClickMainControl(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    BuffManager:onPlayerByInterrupt(userId)
end

function PlayerListener.onPlayerIntoFollowMode(player, follower)
    GamePacketSender:sendMapId(player.rakssid, GameConfig.mapId)
    if GameMatch:isGameStart() then
        GameResourceManager:synTeamResource(player)
    end
end

function PlayerListener.onPlayerAttackCreature(rakssid, entityId, attackType, position, damage, itemId)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end

    local monster = MonsterManager:getMonster(entityId)
    if monster == nil then
        return false
    end
    return monster:onAttacked(player, damage)
end

function PlayerListener.onUseFishHookHitEntity(anglerId, targetId)
    local angler = PlayerManager:getPlayerByEntityId(anglerId)
    local target = PlayerManager:getPlayerByEntityId(targetId)
    if not target or not angler then
        return true
    end

    if angler.isInvincible or target.isInvincible then
        return false
    end

    local anglerInfo = GameInfoManager:getPlayerInfo(angler.userId)
    local targetInfo = GameInfoManager:getPlayerInfo(target.userId)
    if not anglerInfo or not targetInfo then
        return true
    end

    if anglerInfo:getValue("teamId") == targetInfo:getValue("teamId") then
        return false
    end
    return true
end

function PlayerListener.onLaunchArrow(pos)
    GamePacketSender:broadcastSound(SoundConfig.launchArrow, pos)
end

function PlayerListener.onArrowHitGround(pos)
    if SoundConfig.hitGround ~= -1 then
        GamePacketSender:broadcastSound(SoundConfig.hitGround, pos)
        return false
    end
    return true
end

function PlayerListener.onArrowHitEntity(entityId)
    local player = PlayerManager:getPlayerByEntityId(entityId)
    if not player then
        return
    end
    GamePacketSender:sendPlaySound(player.rakssid, SoundConfig.hitEntity)
end

function PlayerListener.onInventoryStackChange(rakssid, slot)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player then
        PropPacketManager:updateLuaPacket(player, slot)
    end
end

function PlayerListener.onChangeItemInHand(rakssid, itemId, itemMeta)
    ---@type GamePlayer
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player and player.gameDataController then
        player.gameDataController:have_hand_item_change()
    end
    return true
end

function PlayerListener.onPlayerCheat(rakssid, code)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if not player then
        return
    end
    ReconnectUtil:clearGameServerData(player.userId)
end

return PlayerListener
--endregion
