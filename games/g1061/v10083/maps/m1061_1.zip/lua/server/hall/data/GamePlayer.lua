---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:20
---
local TrackerGroupId = 0
local function newTrackerGroupId()
    TrackerGroupId = TrackerGroupId + 1
    return TrackerGroupId
end

---@class HallPlayer : SBasePlayer
local GamePlayer = class("GamePlayer", BasePlayer)
---@type RecentPlayUtil
local RecentPlayUtil = T(Global, "RecentPlayUtil")
---@type ServerHeadFrameShop
local HeadFrameShop = T(Global, "HeadFrameShop")
---@type RuneHelper
local RuneHelper = T(Global, "RuneHelper")
---@type SRankUtil
local SRankUtil = T(Global, "SRankUtil")
---@type GameModeUtil
local GameModeUtil = T(Global, "GameModeUtil")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type ScoreActivityTaskMgr
local ScoreActivityTaskMgr = T(Global, "ScoreActivityTaskMgr")
---@type SGameLicense
local SGameLicense = T(Global, "SGameLicense")

function GamePlayer:init()
    self:initStaticAttr(0)
    self.level = 1
    self.cur_exp = 0
    self.yaoshi = 0
    self.chest_integral = 0
    self.fragment_jindu = {}
    self.chests = {}
    self.rewards = {}
    self.running_guides = {}
    self.finish_ids = {}
    self.addHealth = 0
    self.addDefense = 0
    self.maxHealth = 0
    self.spDays = 0
    self.spGetAway = false
    self.init_rune_trough = false
    self.unlock_level = {}
    self.dress = {}
    self.equip_dress = {}
    self.custom_goods = {}
    self.block_goods = {}
    self.skin_order = {}
    self.wall_order = {}
    self.equip_action = {}
    self.command_list = {}

    self.expDoubleTime = 0
    self.privilegeCard = {}
    self.init_reward_finished = false
    self.activity_data = {
        first_recharge = false,
        super_player_daily = 0,
    }
    self.video_ad_data = {
        box_lottery_key = 0
    }

    self.play_days = 0
    self.play_day_key = 0
    self.play_week_key = 0
    self.props_rewards = {}

    self.free_cube_data = {
        day_key = 0,
        times = 0
    }
    self.challenges = {}
    self.needNewChallengeTip = false
    self.challenge_ad = false

    self.license_season = 0
    self.license_buy = 0
    self.license_exp = 0
    self.license_level = 1
    self.had_horn = 0
    self.get_free_reward = {}
    self.get_pay_reward = {}
    self.exchange_reward = {}
    self.refresh_times = 1
    self.license_week_exp = 0
    self.license_week = 0
    self.free_upgrade_time = 0
    self.show_effect_task = {}

    self.free_gift_refresh_time = DateUtil.getYearDay()
    self.ticket_num = 0
    self.free_gift = {}

    self.changeTaskId = -1

    self.commonChip = 0
    self.fakeDiamonds = 0

    self.headFrameData = {}
    self.curGuideNodeId = 0

    self.goodsValue = 0
    self.skinNum = 0
    self.keyConsume = 0
    self.diamondConsume = 0

    self.isNew = false
    self.consecutiveLoginDays = 1
    self.newBattleRecord = {}
    self.aiGameRecord = {}
    self.lastFiveRecord = {}

    self.rechargeReportKey = ""

    self.firstLogin = false

    self.lv_up_rewards = {}
    self.old_lv_info = {}

    GameInfoManager.Instance():newPlayerInfo(self.userId)
    self.info = GameInfoManager.Instance():getPlayerInfo(self.userId)

    self.taskController = GameTaskController.new(self)

    if GameModeUtil:isEnableIndie() then
        self.entityPlayerMP:setIntProperty("TrackerGroupId", newTrackerGroupId())
    end
end

function GamePlayer:initDBDataFinished()
    CreditScoreUtil:onPlayerLogin(self)
    CustomShop:transformOldDress(self)
    CustomShop:transformOldBlockSkin(self)
    CustomShop:onSyncPlayerAllGoods(self)
    TreasureChallenge:onPlayerReady(self)
    self.taskController:init()
    TreasureChallenge:refreshChallengeTask(self)
    ScoreActivityTaskMgr:initPlayerTask(self)
    SGameLicense:updatePlayerData(self)
    if self.play_days == 0 then
        self.isNew = true
    end
    if tonumber(self.play_week_key) < tonumber(DateUtil.getYearWeek()) then
        SRankUtil:clearWeeklyData(self)
        self.play_week_key = DateUtil.getYearWeek()
    end
    if tonumber(self.play_day_key) < tonumber(DateUtil.getYearDay()) then
        if tonumber(self.play_day_key) ~= 0 and self.isNew then
            if tonumber(DateUtil.getYearDay()) - tonumber(self.play_day_key) > 1 then
                self.isNew = false
            else
                self.consecutiveLoginDays = self.consecutiveLoginDays + 1
            end
        end
        self.firstLogin = true
        self.play_days = self.play_days + 1
        self.play_day_key = DateUtil.getYearDay()
        self.taskController:packingProgressData(Define.TaskType.GrowUp.DailyLogin, nil, 1)
        GamePacketSender:sendIndieDailyLogin(self.rakssid)
        TreasureChallenge:resetTreasureAd(self)
        CreditScoreUtil:addLoginCreditScore(self)
        self.dailyOnlineTime = 0
        self.dailyCreditScore = 0
    end
    if #self.chests == 0 then
        GameChestLottery:initChestLotteryData(self)
    end
    self:setShowName(self:buildShowName())
    self:syncLevelInfo()
    GameChestLottery:syncChestLotteryData(self)
    VideoAdHelper:syncBoxLotteryAd(self)
    InitRewardConfig:initPlayer(self)
    GameGuide:sendDataToClient(self)
    RewardUtil:tryConsumeRewards(self)
    local todayKey = DateUtil.getYearDay()
    if self.free_cube_data.day_key ~= todayKey then
        self.free_cube_data.day_key = todayKey
        self.free_cube_data.times = 0
    end
    if self.free_cube_data.times >= 2 then
        GamePacketSender:sendBedWarFreeCubeLimit(self.rakssid)
    end
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level)
    self:checkTriggerGift()
    SGameLicense:getHadDress(self)
    Privilege.syncPrivilegeTime(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
    RecentPlayUtil:sendPlayRecord(self)
    HeadFrameShop:onSyncPlayerAllGoods(self)
    ServerReportEvent.player_login_db_finished(self)
    self:syncLvUpInfo()
    SRankUtil:syncRankScore(self)
    SRankUtil:reportKeyRank(self.userId, self.yaoshi)
    ReportUtil.reportKeyNum(self, self.yaoshi)
    SRankUtil:calculateCustomRankData(self)
end

function GamePlayer:buildShowName()
    local nameList = {}
    local namePrefix = TextFormat.colorGreen .. "LV" .. self.level .. "  "
    local disName = self.name
    PlayerIdentityCache:buildNameList(self.userId, nameList, disName, namePrefix)
    return table.concat(nameList, "\n")
end

function GamePlayer:getLevelInfo()
    local lv = self.level or 1
    local cur_exp = self.cur_exp or 0
    local max_exp, is_max = ExpConfig:getMaxExp(self.level)
    return lv, cur_exp, max_exp, is_max
end

function GamePlayer:syncLevelInfo()
    local lv, cur_exp, max_exp, is_max = self:getLevelInfo()
    GamePacketSender:sendBedWarLevelInfo(self.rakssid, lv, cur_exp, max_exp, is_max)
end

function GamePlayer:addExp(exp)
    local cur_max, is_max = ExpConfig:getMaxExp(self.level)
    if not is_max then
        self.cur_exp = self.cur_exp + exp
    end

    while not is_max and self.cur_exp >= cur_max do
        if TableUtil.isEmpty(self.old_lv_info) then
            self.old_lv_info = {
                lv = self.level,
                exp = self.cur_exp - exp
            }
        end
        self.level = self.level + 1
        self.cur_exp = self.cur_exp - cur_max
        cur_max, is_max = ExpConfig:getMaxExp(self.level)
        table.insert(self.lv_up_rewards, self.level)
        GameGuide:sendDataToClient(self)
        RuneHelper:levelUpUnlockRuneTrough(self, self.level)
    end

    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level)

    if self.hasReport == true then
        GameAnalytics:design(self.userId, 1, { "Player_Lv", self.level })
        GameAnalytics:design(self.userId, -1, { "Player_Lv", self.level - 1 })
    end

    self:syncLevelInfo()
    self:setShowName(self:buildShowName())
    self:syncLvUpInfo()
end

function GamePlayer:onUseCustomProp(propId, itemId)
    local reward = RewardConfig:getRewardById(itemId)
    if not reward then
        if not self:checkReady() then
            table.insert(self.props_rewards, reward)
            return
        end
        local rewardId = GameReward:onPlayerGetReward(self, reward)
        if not rewardId then
            return
        end
        CommonPacketSender:sendBedWarRewardResult(self.rakssid, rewardId)
    end
end

---@param yaoshi number 钥匙数量
---@param source string 钥匙来源类型
---@param extraInfo string 钥匙来源额外信息
function GamePlayer:addYaoShi(yaoshi, source, extraInfo)
    LogUtil.logInfo("[BedWar.Yaoshi]", "addYaoShi num = " .. yaoshi .. ", source: " .. tostring(source or "nil") .. ", extraInfo: " .. tostring(extraInfo or "nil"))
    self.yaoshi = self.yaoshi + yaoshi
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
    ReportUtil.reportGetKey(self, source, yaoshi, extraInfo)
end

function GamePlayer:addTicket(count)
    self.ticket_num = self.ticket_num + count
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
end

function GamePlayer:addHorn(count)
    self.had_horn = self.had_horn + count
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.HORN, self.had_horn)
end

function GamePlayer:addFakeDiamonds(addNum)
    self.fakeDiamonds = self.fakeDiamonds + addNum
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
end

function GamePlayer:addCommonChip(count)
    self.commonChip = self.commonChip + count
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
end

function GamePlayer:subYaoShi(yaoshi, source, itemId)
    LogUtil.logInfo("[BedWar.Yaoshi]", "subYaoShi num = " .. yaoshi .. ", source: " .. tostring(source or "nil") .. ", itemId : " .. tostring(itemId or "0"))
    if yaoshi >= 0 and self.yaoshi - yaoshi >= 0 then
        self.yaoshi = self.yaoshi - yaoshi
        self.keyConsume = self.keyConsume + yaoshi
        self.taskController:packingProgressData(Define.TaskType.GrowUp.CostCoin, Define.Money.KEY, yaoshi)
        ReportUtil.reportCostKey(self, source, yaoshi, itemId)
        CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
        return true
    end
    return false
end

function GamePlayer:subTicket(count)
    if count > 0 and self.ticket_num - count >= 0 then
        self.ticket_num = self.ticket_num - count
        CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
        return true
    end
    return false
end

function GamePlayer:subFakeDiamonds(addNum)
    if addNum > 0 then
        self.fakeDiamonds = self.fakeDiamonds - addNum
    end
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
end

function GamePlayer:subCommonChip(count)
    if count > 0 and self.commonChip - count >= 0 then
        self.commonChip = self.commonChip - count
        CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
        return true
    end
    return false
end

function GamePlayer:doPlayerQuit()
    BaseListener.onPlayerLogout(self.userId)
    HostApi.sendGameover(self.rakssid, IMessages:msgGameOver(), GameOverCode.GameOver)
end

function GamePlayer:reportRankOnQuit()
    if self:checkReady() then
        SRankUtil:reportHornLvRank(self.userId, self.license_level)
        SRankUtil:reportKeyConsumeRank(self.userId, self.keyConsume)
        SRankUtil:reportDiamondConsumeRank(self.userId, self.diamondConsume)
    end
    RuneHelper:onPlayerLogout(self)
end

function GamePlayer:checkTriggerGift()
    if not self.trigger_gift_game_record then
        return
    end

    local winTimes = 0
    local loseTimes = 0
    local playTimes = 0

    for index, record in pairs(self.trigger_gift_game_record) do
        if index == 1 and record.result ~= Define.GameResult.WIN then
            break
        end
        if record.result == Define.GameResult.WIN then
            winTimes = winTimes + 1
        else
            break
        end
    end

    for index, record in pairs(self.trigger_gift_game_record) do
        if index == 1 and record.result ~= Define.GameResult.LOSE then
            break
        end
        if record.result == Define.GameResult.LOSE then
            loseTimes = loseTimes + 1
        else
            break
        end
    end

    for _, record in pairs(self.trigger_gift_game_record) do
        if os.time() - record.time < Define.TriggerGiftContinuePlayTime then
            playTimes = playTimes + 1
        else
            break
        end
    end

    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Win, winTimes)
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Lose, loseTimes)
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Play, playTimes)
end

function GamePlayer:syncLvUpInfo()
    local data = {}
    if not TableUtil.isEmpty(self.old_lv_info) then
        data.oldLv = self.old_lv_info.lv
        data.oldExp = self.old_lv_info.exp
        self.old_lv_info = {}
    end
    data.lvUpRewards = self.lv_up_rewards
    GamePacketSender:sendBedWarPlayerLvUpInfo(self.rakssid, data)
end

function GamePlayer:receiveLvUpReward(lv)
    if lv > self.level or not TableUtil.include(self.lv_up_rewards, lv) then
        return
    end
    local rewards = ExpConfig:getLevelReward(lv)
    local ids = {}
    for _, reward in pairs(rewards) do
        local _reward = RewardConfig:getRewardById(reward.RewardId)
        if _reward then
            _reward = TableUtil.copyTable(_reward)
            _reward.Count = reward.Count
            GameReward:onPlayerGetReward(self, _reward)
            table.insert(ids, reward.RewardId)
        end
    end
    CommonPacketSender:sendBedWarRewardResult(self.rakssid, table.concat(ids, "#"))
    TableUtil.tableRemove(self.lv_up_rewards, lv)
    self:syncLvUpInfo()
end

return GamePlayer

--endregion


