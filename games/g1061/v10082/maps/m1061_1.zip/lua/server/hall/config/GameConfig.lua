---
--- Created by Jimmy.
--- DateTime: 2018/1/25 0025 10:16
---
require "hall.config.ExpConfig"
require "common.config.ChestRewardConfig"
require "common.config.ChestConfig"
require "common.config.DressConfig"
require "hall.config.GuideConfig"
require "hall.config.InitRewardConfig"
require "hall.config.FirstRechargeRewardConfig"
require "hall.config.SuperPlayerRewardConfig"
require "common.config.PrivilegeConfig"
require "common.config.CustomShopIdTransformConfig"
require "hall.config.CannonConfig"

function GameConfig:init(config)
    self.initExp = tonumber(config.initExp) or 0
    self.deathLineY = tonumber(config.deathLineY) or 0
    self.unlockRuneTroughPrice = tonumber(config.unlockRuneTroughPrice or "10")
    require "common.config.MapConfig"
    GameConfig.initPosRange = tonumber(config.initPosRange) or 1

    self.runeMapping = config.RuneMapping

    self.taskGiveUpCD = tonumber(config.taskGiveUpCD or "72")

    self.challengeAdProgress = tonumber(config.challengeAdProgress or 10)

    self.loginRewardList = config.loginRewardList or {}

    self.enableTriggerGiftMgr = config.enableTriggerGiftMgr or false

    ChestRewardConfig:initConfig(FileUtil.getConfigFromCsv("setting/BoxRewardSetting.csv", 3))
    ChestConfig:initConfig(FileUtil.getConfigFromCsv("setting/BoxSetting.csv", 3))
    DressConfig:initConfig(FileUtil.getConfigFromCsv("setting/DressSetting.csv", 3))
    GuideConfig:initGuideConfig(FileUtil.getConfigFromCsv("setting/GuideSetting.csv", 3))
    GuideConfig:initConditionConfig(FileUtil.getConfigFromCsv("setting/ConditionSetting.csv", 3))
    GuideConfig:initEventConfig(FileUtil.getConfigFromCsv("setting/EventSetting.csv", 3))
    LuaTimer:schedule(function()
        InitRewardConfig:initConfig(FileUtil.getConfigFromCsv("InitReward.csv"))
    end, 0)


    HostApi.setToolDurable(false)
end

return GameConfig