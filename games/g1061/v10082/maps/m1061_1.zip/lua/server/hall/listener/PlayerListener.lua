---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")

PlayerListener = {}

function PlayerListener:init()

    BaseListener.registerCallBack(CEvents.PlayerLoginEvent, self.onPlayerLogin)
    BaseListener.registerCallBack(CEvents.PlayerLogoutEvent, self.onPlayerLogout)
    BaseListener.registerCallBack(CEvents.PlayerReadyEvent, self.onPlayerReady)
    BaseListener.registerCallBack(CEvents.PlayerAttackedEvent, self.onPlayerHurt)
    BaseListener.registerCallBack(CEvents.PlayerMoveEvent, self.onPlayerMove)
    BaseListener.registerCallBack(CEvents.PlayerDynamicAttrEvent, self.onDynamicAttrInit)

    CEvents.PlayerUseInitSpawnPositionEvent:registerCallBack(self.onPlayerUseInitSpawnPosition)
    CEvents.SendGuideInfoEvent:registerCallBack(self.onSendGuideInfo)
    CEvents.PlayerDropItemEvent:registerCallBack(function()
        return false
    end)
    CEvents.ToolDurableEvent:registerCallBack(function()
        return false
    end)
    Events.PlayerLicenseReceiveRewardEvent:registerCallBack(self.onPlayerReceiveReward)
    Events.PlayerLicenseBuyLevelEvent:registerCallBack(self.onPlayerBuyLevel)
    Events.PlayerBuyLicenseEvent:registerCallBack(self.onPlayerBuyLicense)
    Events.PlayerExchangeRewardEvent:registerCallBack(self.onPlayerExchangeReward)
    Events.PlayerReceiveTaskReward:registerCallBack(self.onPlayerReceiveTaskReward)
    Events.PlayerUseActionEvent:registerCallBack(self.onPlayerUseAction)
    Events.PlayerSendChatEvent:registerCallBack(self.onPlayerSendChat)
end

function PlayerListener.onDynamicAttrInit(attr)
    if Platform.isLinux() and attr.isTest then
        return
    end
    if attr.followEnterType ~= 2 then
        ReportEvent.player_attr(attr)
    end
end

function PlayerListener.onPlayerUseInitSpawnPosition(userId, pos, yaw)
    local randomPos = MathUtil:randomDoubleInCircle(GameConfig.waitPos, GameConfig.initPosRange)
    if yaw then
        yaw.value = GameConfig.waitYaw
    end
    pos.x = math.floor(randomPos.x)
    pos.y = math.floor(randomPos.y)
    pos.z = math.floor(randomPos.z)
end

function PlayerListener.onPlayerLogin(clientPeer)
    local player = GamePlayer.new(clientPeer)
    player:init()
    ServerReportEvent.player_login(player)
    return GameOverCode.Success, player, 1
end

---@param player HallPlayer
function PlayerListener.onPlayerLogout(player)
    CreditScoreUtil:onPlayerLogout(player)
    player:reportRankOnQuit()
    if player.isNew then
        ServerReportEvent.new_player_logout(player)
    end
    PlayerCustomInfoUtil:reportOnQuit(player)
    GameMatch:onPlayerQuit(player)
    GameInfoManager:clearInfo("PlayerInfo", player.userId)
    ServerReportEvent.player_logout(player)
end

---@param player HallPlayer
function PlayerListener.onPlayerReady(player)
    DbUtil:getPlayerData(player)
    HostApi.sendPlaySound(player.rakssid, 10039)
    HostApi.setDisarmament(player.rakssid, true)
    GameInfoManager.Instance():onPlayerReady(player)
    MsgSender.sendMsgToTarget(player.rakssid, IMessages:msgWelcomePlayer(Messages:gamename()))
    HostApi.setAllowUseItemStatus(player.rakssid, 0)
    AddMaxHPPrivilege:onPlayerRespawn(player)
    ServerReportEvent.player_ready(player)
    return GameConfig.isNightPotion and 43200 or 0
end

function PlayerListener.onPlayerHurt(hurtPlayer, hurtFrom, damageType, hurtValue)
    return false
end

---@param movePlayer EntityPlayerMP
function PlayerListener.onPlayerMove(movePlayer, x, y, z)
    local player = PlayerManager:getPlayerByPlayerMP(movePlayer)
    if player == nil then
        return true
    end
    if y <= GameConfig.deathLineY then
        player:teleportPos(GameConfig.waitPos)
    end
    return true
end

function PlayerListener.onSendGuideInfo(rakssid, guideId, guideStatus)
    local player = PlayerManager:getPlayerByRakssid(rakssid)
    if player == nil then
        return false
    end
    local guide = { Id = guideId, Status = guideStatus }
    GameGuide:updateStatus(player, guide)
end

function PlayerListener.onPlayerStartGame(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local _ = builder:getParam("gameType")
end

function PlayerListener.onPlayerReceiveReward(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local Lv = builder:getNumberParam("Lv")
    local rewardId = builder:getNumberParam("rewardId")
    local rewardType = builder:getParam("rewardType")
    local getAll = builder:getBoolParam("getAll")
    local season = builder:getNumberParam("season")
    GameLicense:onPlayerGetReward(userId, Lv, getAll, season, rewardId, rewardType)
end

function PlayerListener.onPlayerBuyLevel(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local season = builder:getNumberParam("season")
    local level = builder:getNumberParam("level")
    local free = builder:getNumberParam("free")
    GameLicense:onPlayerBuyLevel(player, season, level, free)
end

function PlayerListener.onPlayerBuyLicense(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local season = builder:getNumberParam("season")
    local buyType = builder:getNumberParam("buyType")
    GameLicense:onPlayerBuy(player, season, buyType)
end

function PlayerListener.onPlayerExchangeReward(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local season = builder:getNumberParam("season")
    local itemId = builder:getNumberParam("itemId")
    local rewardNum = builder:getNumberParam("rewardNum")
    GameLicense:onPlayerExchange(userId, itemId, season, rewardNum)
end

function PlayerListener.onPlayerUseAction(userId, actionId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    CommonPacketSender:sendUseActionToAll(player:getEntityId(), actionId)
end

function PlayerListener.onPlayerReceiveTaskReward(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local taskId = DataBuilder.new():fromData(data):getNumberParam("taskId")
    GameLicense:onPlayerReceiveSeasonTaskReward(player, taskId)
end

function PlayerListener.onPlayerSendChat(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local text = DataBuilder.new():fromData(data):getNumberParam("text")
    GamePacketSender:sendChatToAll(userId, text)
end

return PlayerListener
--endregion
