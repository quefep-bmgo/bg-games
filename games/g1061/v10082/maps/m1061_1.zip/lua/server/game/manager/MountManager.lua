---@type GameMount[]
local Mounts = {}

EntityManager = {}

function EntityManager:addMount(entity)
    Mounts[tostring(entity.entityId)] = entity
end

function EntityManager:getMount(entityId)
    return Mounts[tostring(entityId)]
end

function EntityManager:removeMount(entity)
    Mounts[tostring(entity.entityId)] = nil
end

function EntityManager:onTick()
    for _, entity in pairs(Mounts) do
        entity:onTick()
    end
end