---@class PlayerActionServer
local PlayerActionServer = {}

return PlayerActionServer