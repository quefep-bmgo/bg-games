LotteryListener = {}

function LotteryListener:init()
    Events.LotteryRefreshEvent:registerCallBack(self.onPlayerRequestLotteryRefresh)
    Events.LotteryEvent:registerCallBack(self.onPlayerRequestLottery)
    Events.LotteryReplaceEvent:registerCallBack(self.onLotteryReplace)
    Events.LotteryEffectEndEvent:registerCallBack(self.onLotteryEffectEnd)
end

function LotteryListener.onPlayerRequestLotteryRefresh(userId)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    GameLottery:RefreshLotteryPool(userId)
end

function LotteryListener.onPlayerRequestLottery(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local seq = DataBuilder.new():fromData(data):getNumberParam("seq")
    GameLottery:onPlayerLottery(userId, seq)
end

function LotteryListener.onLotteryReplace(userId, data)
    local builder = DataBuilder.new():fromData(data)
    local isReplace = builder:getBoolParam("isReplace")
    GameLottery:onLotteryReplace(userId, isReplace)
end

function LotteryListener.onLotteryEffectEnd(userId)
    GameLottery:onLotteryEffectEnd(userId)
end