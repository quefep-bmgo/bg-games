local CWaitPlayerTask = class("WaitingPlayerTask", ITask)

function CWaitPlayerTask:onCreate()
    GameMatch.curStatus = self.status
    self.isEnoughPlayer = false
    self.enoughPlayerTick = 0
end

function CWaitPlayerTask:onTick(ticks)
    local curPlayerCount = SettlementManager:getPlayerCount()
    if curPlayerCount < GameConfig.startPlayers then
        if ticks % 30 == 0 then
            MessagesManage:sendSystemTipsToAll(IMessages:msgWaitPlayer())
            MessagesManage:sendSystemTipsToAll(IMessages:msgGamePlayerNum(curPlayerCount, GameConfig.startPlayers))
        end
        return
    else
        if not self.isEnoughPlayer then
            self.enoughPlayerTick = ticks
            self.isEnoughPlayer = true
        end
    end

    local isGamePlayerFull = curPlayerCount >= PlayerManager:getRoomMaxPlayer()
    if isGamePlayerFull then
        self:stop()
        return
    end

    local waitTime = 0
    if ticks > GameConfig.waitingPlayerTime then
        waitTime = GameConfig.waitingPlayerTime2 - (ticks - self.enoughPlayerTick)
    else
        waitTime = GameConfig.waitingPlayerTime - ticks + GameConfig.waitingPlayerTime2
    end

    if waitTime <= 0 then
        self:stop()
        return
    end

    local seconds = waitTime
    if seconds >= 60 and seconds % 60 == 0 then
        MessagesManage:sendSystemTipsToAll(IMessages:msgWaitPlayerEnough(seconds / 60, IMessages.UNIT_MINUTE, false))
    elseif seconds >= 60 and seconds % 30 == 0 then
        if seconds % 60 == 0 then
            MessagesManage:sendSystemTipsToAll(IMessages:msgWaitPlayerEnough(seconds / 60, IMessages.UNIT_MINUTE, false))
        else
            MessagesManage:sendSystemTipsToAll(IMessages:msgWaitPlayerEnough(seconds / 60, IMessages.UNIT_MINUTE, true))
        end
    elseif seconds <= 10 and seconds > 0 then
        MessagesManage:sendSystemTipsToAll(IMessages:msgWaitPlayerEnough(seconds, IMessages.UNIT_SECOND, false))
        if seconds <= 3 then
            HostApi.sendPlaySound(0, 12)
        else
            HostApi.sendPlaySound(0, 11)
        end
    end
end

function CWaitPlayerTask:stop()
    SecTimer.stopTimer(self.timer)
    HostApi.setAllowUseItemStatus(0, 1)
    GameMatch:startMatch()
end

WaitingPlayerTask = CWaitPlayerTask.new(GameMatch.Status.WaitingPlayer)

return WaitingPlayerTask