---@type GameDataController
local GameDataController = require "game.data.GameDataController"

---@class GamePlayer : SBasePlayer
---@field super SBasePlayer
local GamePlayer = class("GamePlayer", BasePlayer)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")
---@type SRankUtil
local SRankUtil = T(Global, "SRankUtil")
---@type PropPacketManager
local PropPacketManager = require "common.manager.PropPacketManager"
---@type CreditScoreUtil
local CreditScoreUtil = T(Global, "CreditScoreUtil")
---@type QualifyingHelper
local QualifyingHelper = T(Global, "QualifyingHelper")
---@type ScoreActivityTaskMgr
local ScoreActivityTaskMgr = T(Global, "ScoreActivityTaskMgr")

---@param info PlayerInfo
function GamePlayer:init(info)
    if self.teamId == nil then
        ---@type GameTeam
        self.team = nil
        self.teamId = info:getValue("teamId", true)
        self.isLife = true
        self.realLife = true
        self.initItems = {}
        self.itemKillRecord = {}
        self.multiKill = 0
        self.lastKillTime = 0
        self.kills = 0
        self.killAIs = 0
        self.standTime = 0
        self.deathNum = 0
        self.initLevel = 1
        self.curApple = 0
        self.maxApple = 0
        self.useHollowBlockTime = nil
        self.useBridgeEggTime = nil
        self.placeBlockNumByButton = 0
        self.placeBlockNum = 0
        self.addSpeed = 0
        self.inventory = {}
        self.enderInventory = {}
        ReportManager:reportUserEnter(self.userId)
    end

    self.isDisconnect = false
    self.dress = {}
    self.equip_dress = {}
    self.custom_goods = {}
    self.block_goods = {}
    self.skin_order = {}
    self.wall_order = {}
    self.equip_action = {}
    self.command_list = {}

    self:initStaticAttr(0)

    self.rewards = {}

    self.level = 1
    self.yaoshi = 0
    self.cur_exp = 0
    self.commonChip = 0

    self.expDoubleTime = 0
    self.privilegeCard = {}
    self.chest_integral = 0
    self.chests = {}

    self.limit_item = {}

    self.isRespawn = true
    self.isStartMinute = true
    self.isRewardDoubleKey = false
    self.isPartyUser = false
    self.unlock_level = {}

    self.play_days = 0
    self.play_day_key = 0
    self.play_week_key = 0

    self.license_season = 0
    self.license_buy = 0
    self.license_exp = 0
    self.license_level = 1
    self.hadOpenLicense = false
    self.had_horn = 0
    self.get_free_reward = {}
    self.get_pay_reward = {}
    self.exchange_reward = {}
    self.refresh_times = 1
    self.license_week_exp = 0
    self.license_week = 0
    self.free_upgrade_time = 0
    self.show_effect_task = {}

    self.challenges = {}
    self.needNewChallengeTip = false
    self.changeTaskId = -1
    self.challenge_ad = false

    self.banCureBuff = false
    self.useHollowBlock = false
    ---@type DoubleDummy
    self.double_dummy = nil

    self.fakeDiamonds = 0
    self.resultDayKey = 0
    self.resultGameFirst = true
    self.shareDayKey = 0
    self.shareGameFirst = true
    self.info = info

    self.battleRecord = nil
    --每周清
    self.keyConsume = 0
    self.diamondConsume = 0

    self.curGuideNodeId = 0

    self.isNew = false
    self.consecutiveLoginDays = 1
    self.newBattleRecord = {}
    self.aiGameRecord = {}
    self.lastFiveRecord = {}

    self.rechargeReportKey = ""

    self.firstLogin = false

    self.singleGameUseItemRecord = {}
    self.old_lv_info = {}
    self.lv_up_rewards = {}

    self:setFoodLevel(20)
    self:initTeam()
    self:teleWaitPos()
    self.taskController = GameTaskController.new(self)
    self:setFlyWing(true, GameConfig.glideMoveAddition, GameConfig.glideDropResistance)
end

function GamePlayer:onPlayerLogout()
    self.clientPeer = nil
    self.isReady = false
    ReportManager:onPlayerLogout(self)
end

function GamePlayer:getRespawnPos()
    if self.team then
        return self.team.initPos
    end
    return self.super.getRespawnPos(self)
end

function GamePlayer:initDBDataFinished()
    CreditScoreUtil:onPlayerLogin(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
    local oldHp = self:getHealth()
    self:changeMaxHealth(20)
    Privilege.syncPrivilegeTime(self)
    AddMaxHPPrivilege:onPlayerRespawn(self)
    RuneManager:onPlayerInitRune(self)
    if oldHp < 20 then
        self:setHealth(oldHp)
    end
    self:initItem()
    CustomShop:transformOldDress(self)
    CustomShop:transformOldBlockSkin(self)
    CustomShop:onSyncPlayerAllGoods(self)
    TreasureChallenge:onPlayerReady(self)
    self.taskController:init()
    TreasureChallenge:refreshChallengeTask(self)
    ScoreActivityTaskMgr:initPlayerTask(self)
    GameLicense:updatePlayerData(self)
    if self.play_days == 0 then
        self.isNew = true
    end
    if tonumber(self.play_week_key) < tonumber(DateUtil.getYearWeek()) then
        SRankUtil:clearWeeklyData(self)
        self.play_week_key = DateUtil.getYearWeek()
    end
    if tonumber(self.play_day_key) < tonumber(DateUtil.getYearDay()) then
        if tonumber(self.play_day_key) ~= 0 and self.isNew then
            if tonumber(DateUtil.getYearDay()) - tonumber(self.play_day_key) > 1 then
                self.isNew = false
            else
                self.consecutiveLoginDays = self.consecutiveLoginDays + 1
            end
        end
        self.firstLogin = true
        self.play_days = self.play_days + 1
        self.play_day_key = DateUtil.getYearDay()
        self.taskController:packingProgressData(Define.TaskType.GrowUp.DailyLogin, nil, 1)
        TreasureChallenge:resetTreasureAd(self)
        CreditScoreUtil:addLoginCreditScore(self)
        self.dailyOnlineTime = 0
        self.dailyCreditScore = 0
    end
    self.initLevel = self.level
    GamePacketSender:sendBedWarPlayerLevel(self.rakssid, self.level)
    if #self.chests == 0 then
        GameChestLottery:initChestLotteryData(self)
    end
    GameChestLottery:syncChestLotteryData(self)
    GameCommandShop:onSyncPlayerCommandList(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
    self:changeClothes("custom_hat", 0)
    SurveyManager:onPlayerLogin(self)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
    AnalyticsReportUtil.initNewItemRecord(self)
    if AIManager:isAI(self.rakssid) == false then
        Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level)
        SRankUtil:initBattleRecord(self)
    end
    ServerReportEvent.player_login_db_finished(self)
    if GameMatch:isGameStart() then
        self:setShowName(self:buildShowName())
    end
    SRankUtil:reportKeyRank(self.userId, self.yaoshi)
    ReportUtil.reportKeyNum(self, self.yaoshi)
    SRankUtil:calculateCustomRankData(self)
end

---检查玩家连接成功后是否真实活着
function GamePlayer:checkConnectSuccessPlayerLife()
    if not self.isLife then
        SettlementManager:sendSingleSettlement(self, GameMatch:isGameEnd())
    end
    if self.realLife then
        if self:isDead() then
            return false
        end
    else
        if self:isDead() then
            self.entityPlayerMP:rebirth(self.rakssid, self.userId, StringUtil.getRealName(self.name), self.team.initPos)
        end
        self:subHealth(10000)
        return false
    end
    return true
end

function GamePlayer:onSpawnInGame()
    if not self.isLife then
        return
    end
    if not PlayerManager:isAIPlayer(self) and self.game_start_times and self.game_start_times < 5 then
        if self.gameDataController == nil then
            self.gameDataController = GameDataController.new(self)
        else
            self.gameDataController:have_respawn()
        end
    end
    self:teleInitPos()
    self.damageType = nil
    self.lastGroundPos = nil
    self.isRespawn = true
    self.info:setValue("lifeStatus", true)
    self:fillEnderInvetory(self.enderInventory)
    self:initItem()
    self.logoutPos = nil
    local ai = AIManager:getAIByRakssid(self.rakssid)
    if ai ~= nil then
        ai:onRespawn()
    end
    CustomShopCloth:onPlayerRespawn(self)
    GameStore:checkAllUpgradeGoods(self)
    self:addCustomEffect("InvincibleEffect" .. tostring(self.userId), GameConfig.InvincibleEffect, GameConfig.invincibleTime * 1000)
    self.isInvincible = true
    LuaTimer:schedule(function()
        self.isInvincible = false
    end, GameConfig.invincibleTime * 1000)
end

function GamePlayer:addExp(exp)
    local cur_max, is_max = ExpConfig:getMaxExp(self.level)
    if not is_max then
        self.cur_exp = self.cur_exp + exp
    end
    while not is_max and self.cur_exp >= cur_max do
        if TableUtil.isEmpty(self.old_lv_info) then
            self.old_lv_info = {
                lv = self.level,
                exp = self.cur_exp - exp
            }
        end
        self.level = self.level + 1
        self.cur_exp = self.cur_exp - cur_max
        cur_max, is_max = ExpConfig:getMaxExp(self.level)
        table.insert(self.unlock_level, self.level)
        table.insert(self.lv_up_rewards, self.level)
    end
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Level, self.level)
end

function GamePlayer:checkParty()
    local manager = GameServer:getRoomManager()
    if manager:isUserAttrExisted(self.userId) then
        local attr = manager:getUserAttrInfo(self.userId)
        self.isPartyUser = attr.privateParty
    end
    if self.isPartyUser then
        GamePacketSender:sendBedWarKeyAdDeadSummary(self.rakssid, 0)
    end
end

function GamePlayer:buildShowName()
    local nameList = {}
    local disName = self.name
    if self.team ~= nil then
        if BaseMain:isChina() then
            disName = disName .. self.team:getDisplayName("zh_CN")
        else
            disName = disName .. self.team:getDisplayName("en_US")
        end
    end
    PlayerIdentityCache:buildNameList(self.userId, nameList, disName)
    return table.concat(nameList, "\n")
end

function GamePlayer:getDisplayName()
    self.name = string.gsub(self.name, "#", "")
    if self.team ~= nil then
        return self.team:getDisplayName(self:getLanguage()) .. TextFormat.colorWrite .. self.name
    else
        return self.name
    end
end

function GamePlayer:getTeamColorName()
    self.name = string.gsub(self.name, "#", "")
    if self.team ~= nil then
        return self.team:getTeamColor() .. self.name
    else
        return self.name
    end
end

function GamePlayer:initTeam()
    local teamId = self.info:getValue("teamId", true)
    if teamId ~= 0 then
        self.teamId = teamId
    end
    for _, team in pairs(GameMatch.Teams) do
        if team.id == self.teamId then
            self.team = team
            break
        end
    end
    if self.team then
        self.teamId = self.team.id
        self.dynamicAttr.team = self.teamId
    else
        self.teamId = math.max(1, self.teamId)
        self.dynamicAttr.team = self.teamId
        self.team = GameMatch.Teams[self.teamId]
    end
    if self.isLife then
        self.team:addPlayer(self)
    end
    self.info:setValue("teamId", self.teamId)
    local respawnPos = VectorUtil.newVector3i(self.team.initPos.x, self.team.initPos.y, self.team.initPos.z)
    self:setRespawnPos(respawnPos)
    self.team.info:addPlayer(self.userId)
end

function GamePlayer:getTeamId()
    if self.team ~= nil then
        return self.team.id
    end
    return self.teamId
end

function GamePlayer:teleInitPos()
    self.realLife = self.isLife
    if self.logoutPos then
        return
    end
    if self.team ~= nil and self.team.initPos ~= nil then
        self:teleportPosWithYaw(self.team.initPos, self.team.initYaw or 0)
    end
end

function GamePlayer:teleWaitPos()
    if GameMatch:isGameStart() then
        self:teleInitPos()
        return
    end
    if self.logoutPos then
        return
    end
    local randomPos = MathUtil:randomDoubleInCircle(GameConfig.waitPos, GameConfig.initPosRange)
    if self:checkReady() then
        self:teleportPos(randomPos)
    else
        self:teleportPosWithYaw(randomPos, GameConfig.waitYaw)
    end
end

function GamePlayer:teleWatchPos()
    self:setAllowFlying(true)
    HostApi.sendSetFlying(self.rakssid)
    local vec = VectorUtil.newVector3(GameConfig.watchPoint[1], GameConfig.watchPoint[2], GameConfig.watchPoint[3])
    self:setPositionAndRotation(vec, tonumber(GameConfig.watchPoint[4]), tonumber(GameConfig.watchPoint[5]))

    if self.entityPlayerMP then
        self.entityPlayerMP:setPositionAndUpdate(tonumber(GameConfig.watchPoint[1]), tonumber(GameConfig.watchPoint[2]), tonumber(GameConfig.watchPoint[3]))
    end
end

function GamePlayer:onLogout()
    self.logoutTime = os.time()
    if self.isPartyUser then
        self.appIntegral = 0
    end
    if self:ifOnMount() and self.mount then
        self.mount:onDead()
    end
    self.isDisconnect = true
    if self.realLife then
        self:setInventory()
        self:setEnderInventory()
        self.isKeepItem = true
        if GameMatch:isGameStart() and self:checkReady() then
            self.logoutPos = self:getPosition()
        end
    end
    if GameMatch:isGameEnd() or self.alreadyReward then
        if not AIManager:isAI(self.rakssid) then
            ReportUtil.reportPlaceBlock(self)
        end
    else
        if not self.realLife and not self.team.isHaveBed then
            ---购买复活中退出游戏判为死亡
            self:onDie()
        end
        GameMatch:ifGameOver()
    end
end

---@param dier GamePlayer
function GamePlayer:onKill(dier)
    self.kills = self.kills + 1
    self.appIntegral = self.appIntegral + 1

    if AIManager:isAI(dier.rakssid) == true then
        self.killAIs = self.killAIs + 1
    end

    if self.multiKill == 0 then
        self.multiKill = 1
    else
        if os.time() - self.lastKillTime <= 30 then
            self.multiKill = self.multiKill + 1
        else
            self.multiKill = 1
        end
    end

    if self:ifOnMount() and self.mount then
        self.mount:onKillPlayer()
    end
    ---@param _player GamePlayer
    for _, _player in pairs(PlayerManager:getPlayers()) do
        if _player ~= dier and _player.teamId == dier.teamId and _player.gameDataController then
            _player.gameDataController:have_teammate_killed()
        end
    end

    if dier.gameDataController then
        dier.gameDataController:have_died()
        dier.gameDataController:die_count()
    end

    if self.gameDataController then
        self.gameDataController:kill_player_count()
    end
    SettlementManager:onPlayerDied(dier.userId, self.userId, self.multiKill)
    self.lastKillTime = os.time()
    RuneManager:onKill(self)
    self:updateBattleInfo({ kill = 1 })
end

function GamePlayer:onDestroyBed(team)
    MessagesManage:sendSystemTipsToTeam(team.id, Messages:msgBedHasBreak())
    local players = PlayerManager:getPlayers()
    for _, _player in pairs(players) do
        MessagesManage:sendSystemTipsToPlayer(_player.rakssid, Messages:breakBedTip(self:getTeamColorName(), team:getDisplayName(_player:getLanguage())))
        if _player.teamId == self.teamId then
            GamePacketSender:sendPlaySound(_player.rakssid, SoundConfig.breakOtherBed)
        end
    end

    local destroy_bed = self.info:getValue("destroy_bed")
    self.taskController:packingProgressData(Define.TaskType.Fright.DestroyBed, nil, 1)
    self.info:setValue("destroy_bed", destroy_bed .. team.id)
    self:updateBattleInfo({ bed = 1 })
end

function GamePlayer:onDie()
    if self.isLife then
        self.isLife = false
        self.realLife = false
        self.team:subPlayer(self.userId)
        SettlementManager:onPlayerLose(self)
        HostApi.sendPlaySound(self.rakssid, 10002)
        SurveyManager:onGameEnd(self)
        if AIManager:isAI(self.rakssid) == true then
            AITeamManager:onAIDie(self)
        else
            if self.gameDataController then
                self.gameDataController:have_weed_out()
            end
        end
        ---@param _player GamePlayer
        for _, _player in pairs(PlayerManager:getPlayers()) do
            if _player ~= self and _player.teamId == self.teamId then
                if _player.gameDataController then
                    _player.gameDataController:have_teammate_weed_out()
                end
            end
        end
    end
end

function GamePlayer:overGame()
    BackHallManager:addPlayer(self)
end

---@param yaoshi number 钥匙数量
---@param source string 钥匙来源类型
---@param extraInfo string 钥匙来源额外信息
function GamePlayer:addYaoShi(yaoshi, source, extraInfo)
    LogUtil.logInfo("[BedWar.Yaoshi]", "addYaoShi num = " .. yaoshi .. ", source: " .. tostring(source or "nil")..", extraInfo: " .. tostring(extraInfo or "nil"))
    self.yaoshi = self.yaoshi + yaoshi
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
    ReportUtil.reportGetKey(self, source, yaoshi, extraInfo)
end

function GamePlayer:addCommonChip(count)
    self.commonChip = self.commonChip + count
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
end

function GamePlayer:addHorn(count)
    self.had_horn = self.had_horn + count
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.HORN, self.had_horn)
end

function GamePlayer:addTicket(count)
    self.ticket_num = self.ticket_num + count
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
end

function GamePlayer:addFakeDiamonds(addNum)
    self.fakeDiamonds = self.fakeDiamonds + addNum
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
end

function GamePlayer:subYaoShi(yaoshi, source, itemId)
    LogUtil.logInfo("[BedWar.Yaoshi]", "subYaoShi num = " .. yaoshi .. ", source: " .. tostring(source or "nil")..", itemId : " .. tostring(itemId or "0"))
    if yaoshi >= 0 and self.yaoshi - yaoshi >= 0 then
        self.yaoshi = self.yaoshi - yaoshi
        self.keyConsume = self.keyConsume + yaoshi
        CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.KEY, self.yaoshi)
        self.taskController:packingProgressData(Define.TaskType.GrowUp.CostCoin, Define.Money.KEY, yaoshi)
        ReportUtil.reportCostKey(self, source, yaoshi, itemId)
        return true
    end
    return false
end

function GamePlayer:subFakeDiamonds(addNum)
    if addNum > 0 then
        self.fakeDiamonds = self.fakeDiamonds - addNum
    end
    CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.FAKE_DIAMOND, self.fakeDiamonds)
end

function GamePlayer:subTicket(count)
    if count > 0 and self.ticket_num - count >= 0 then
        self.ticket_num = self.ticket_num - count
        CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.TICKET, self.ticket_num)
        return true
    end
    return false
end

function GamePlayer:subCommonChip(count)
    if count > 0 and self.commonChip - count >= 0 then
        self.commonChip = self.commonChip - count
        CommonPacketSender:sendBedWarPlayerMoneyCount(self.rakssid, Define.Money.COMMON_CHIP, self.commonChip)
        return true
    end
    return false
end

function GamePlayer:onUseCustomProp(propId)
    local maxhp = self:getMaxHealth()
    local extraHp = AppPropConfig:getRewardHp(propId)
    self:changeMaxHealth(maxhp + extraHp)
end

function GamePlayer:onQuit()
    if not PlayerManager:isAIPlayer(self) and self:checkReady() then
        SRankUtil:reportKeyConsumeRank(self.userId, self.keyConsume)
        SRankUtil:reportDiamondConsumeRank(self.userId, self.diamondConsume)
    end
    if self.isReport then
        return
    end
    self.isReport = true
    local isCount = RewardManager:isUserRewardFinish(self.userId) and 1 or 0
    ReportManager:reportUserData(self.userId, self.info:getValue("kill", true), self.info:getValue("rank", true), isCount)
end

function GamePlayer:fillInvetory(inventory)
    self:clearInv()
    if inventory == nil then
        return
    end
    local items = inventory.item or {}
    for _, item in pairs(items) do
        if item.id > 0 and item.id < 10000 then
            self:tryAddItem(item.id, item.num)
        end
    end
    local armors = inventory.armor or {}
    for _, armor in pairs(armors) do
        if armor.id > 0 and armor.id < 10000 then
            self:tryAddItem(armor.id, armor.num)
        end
    end
    local guns = inventory.gun or {}
    for _, gun in pairs(guns) do
        if gun.id > 0 and gun.id < 10000 then
            self:tryAddItem(gun.id, gun.num)
        end
    end
end

function GamePlayer:setInventory()
    local inv = self:getInventory()
    if not inv then
        return
    end
    self.inventory = InventoryUtil:getPlayerInventoryInfo(self, nil, 36)
    local hotbarFlag = {}
    for index, stack in pairs(self.inventory.item) do
        self.inventory.item[index].hotBarIndex = 1000
        for hotbarIndex = 0, 8 do
            local data = inv:getHotBarInventory(hotbarIndex)
            if data and hotbarFlag[hotbarIndex] == nil and data.id == stack.id
                    and data.num == stack.num and data.meta == stack.meta then
                hotbarFlag[hotbarIndex] = true
                self.inventory.item[index].hotBarIndex = hotbarIndex
                break
            end
        end
    end
    table.sort(self.inventory.item, function(a, b)
        if a.hotBarIndex ~= b.hotBarIndex then
            return a.hotBarIndex < b.hotBarIndex
        end
    end)
end

function GamePlayer:setEnderInventory()
    local inv = self:getEnderInventory()
    if not inv then
        return
    end
    self.enderInventory = InventoryUtil:getPlayerEnderInventoryInfo(self)
    for index, stack in pairs(self.enderInventory.item) do
        if inv then
            self.enderInventory.item[index].enchantList = ItemEnchantment:getItemEnchantmentList(inv, stack.stackIndex)
        end
    end
end

function GamePlayer:addMaxApple(apple)
    self.maxApple = self.maxApple + apple
    self.curApple = self.maxApple
    self:updateApple()
end

function GamePlayer:addApple(apple)
    self.curApple = self.curApple + apple
    self.curApple = math.min(self.curApple, self.maxApple)
    self:updateApple()
end

function GamePlayer:subApple(damage)
    if self.curApple == nil or self.curApple <= 0 then
        return damage
    end
    if self.curApple - damage > 0 then
        self.curApple = self.curApple - damage
        self:updateApple()
        return 0
    else
        local result = damage - self.curApple
        self.curApple = 0
        self.maxApple = 0
        self:updateApple()
        return result
    end
end

function GamePlayer:updateApple()
    if self.entityPlayerMP == nil then
        return
    end
    self.entityPlayerMP:changeApple(math.ceil(self.curApple), self.maxApple)
end

function GamePlayer:resetApple()

    for hash, timeId in pairs(LogicListener.goldAppleAddHpTimeId) do
        local findHash = string.find(hash, tostring(self.userId))
        if findHash ~= nil and findHash > 0 then
            if timeId ~= nil then
                LuaTimer:cancel(timeId)
                timeId = nil
            end
            LogicListener.goldAppleAddHpTimeId[hash] = nil
            break
        end
    end

    for hash, timeId in pairs(LogicListener.goldAppleTimeId) do
        local findHash = string.find(hash, tostring(self.userId))
        if findHash ~= nil and findHash > 0 then
            if timeId ~= nil then
                LuaTimer:cancel(timeId)
                timeId = nil
            end
            LogicListener.goldAppleTimeId[hash] = nil
            break
        end
    end

    for hash, timeId in pairs(LogicListener.goldAppleFreshTimeId) do
        local findHash = string.find(hash, tostring(self.userId))
        if findHash ~= nil and findHash > 0 then
            if timeId ~= nil then
                LuaTimer:cancel(timeId)
                timeId = nil
            end
            LogicListener.goldAppleFreshTimeId[hash] = nil
            break
        end
    end
end

function GamePlayer:hasSameArmor(itemId)
    local inv = self:getInventory()
    local index = inv:getArmorSlotById(itemId)
    if index >= 100 and index < 104 then
        local info = inv:getItemStackInfo(index)
        return info.id ~= 0
    end
    return false
end

function GamePlayer:hasSameTool(itemId)
    local item = Item.getItemById(itemId)
    if not item then
        return false
    end
    local inv = self:getInventory()
    local class = item:getClassName()
    if class == "ItemPickaxe" or class == "ItemAxe" or class == "ItemShears" then
        for index = 1, 36 do
            local info = inv:getItemStackInfo(index - 1)
            if info.id ~= 0 then
                local _item = Item.getItemById(info.id)
                if _item then
                    local _class = _item:getClassName()
                    if _class == class then
                        return true
                    end
                end
            end
        end
    end
    return false
end

function GamePlayer:initItem()
    if self.isKeepItem then
        PropPacketManager:onPlayerDied(self)
        self:fillInvetory(self.inventory)
        PropPacketManager:onPlayerRespawn(self)
        self.entityPlayerMP:inventoryForceUpdate()
        self.entityPlayerMP:markInventoryDirty()
        if self.gameDataController then
            self.gameDataController:have_respawn_with_cube()
        end
    else
        if GameMatch:isGameStart() then
            self:removeWoodSword()
        else
            self:tryAddItem(ItemID.SWORD_WOOD, 1)
        end
        for _, itemId in ipairs(self.initItems) do
            if not self:hasSameArmor(itemId) and not self:hasSameTool(itemId) then
                self:tryAddItem(itemId, 1)
            end
        end
        self:setInventory()
    end
    self.isKeepItem = false
end

function GamePlayer:tryItemId2DressId(itemId)
    local oldItemId = ItemMapping:getOldItemId(itemId) ---获取原始ItemId
    local newItemId, dressId
    if oldItemId == ItemID.HELMET_LEATHER then
        dressId = CustomShopSuit:getSuitableHeadDressId(self)
        if dressId == oldItemId then
            dressId = itemId
        end
    else
        dressId = self.equip_dress[tostring(oldItemId)] or itemId ---原始ItemId映射成装扮Id
    end
    newItemId = ItemMapping:getItemIdByDressId(itemId, dressId) ---装扮ID转换成真正的ItemId
    return newItemId
end

function GamePlayer:addEnchantItem(itemId, count, damage, enchantList)
    if enchantList and #enchantList > 0 then
        self:addEnchantmentsItem(itemId, count, damage, enchantList)
    else
        self:addItem(itemId, count, damage)
    end
end

function GamePlayer:removeWoodSword()
    self:removeItem(ItemID.SWORD_WOOD, 1)
    local itemId = self:tryItemId2DressId(ItemID.SWORD_WOOD)
    self:removeItem(itemId, 1)
end

function GamePlayer:tryAddItem(itemId, count, damage, enchantList)
    SurveyManager:onPlayerGetItem(self, itemId)
    damage = damage or 0
    local item = Item.getItemById(itemId)
    if not item then
        ---尝试添加自定义方块
        itemId = self:tryItemId2DressId(itemId)
        self:addEnchantItem(itemId, count, damage, enchantList)
        return
    end
    if itemId == BlockID.CLOTH then
        itemId = self:getClothBlockId()
    end
    if itemId == ItemID.DOUBLE_DUMMY then
        itemId = self:getDoubleDummyId()
    end
    local class = item:getClassName()
    if class == "ItemBlock" and itemId > 2000 then
        ---自定义方块需要-1000
        itemId = self:tryItemId2DressId(itemId - 1000)
    else
        itemId = self:tryItemId2DressId(itemId)
    end
    if class == "ItemArmor" then
        self:tryEquipArmor(itemId, damage, enchantList)
    elseif class == "ItemPickaxe" or class == "ItemAxe" then
        enchantList = ToolItemGain:onPlayerGetTool(self, enchantList)
        self:tryAddToolItem(itemId, count, damage, enchantList, class)
    elseif class == "ItemSword" then
        self:removeWoodSword()
        ---删除木剑
        enchantList = FireSwordPrivilege:onPlayerGetSword(self, enchantList)
        enchantList = SwordItemGain:onPlayerGetSword(self, enchantList)
        self.info:setValue(class, itemId)
        self:addEnchantItem(itemId, count, damage, enchantList)
    elseif class == "ItemBow" then
        self.info:setValue(class, itemId)
        self:addEnchantItem(itemId, count, damage, enchantList)
    elseif class == "ItemShears" then
        ---检测是否有剪刀
        if self:getInventory():getItemNum(itemId) <= 0 then
            enchantList = ToolItemGain:onPlayerGetTool(self, enchantList)
            self:addEnchantItem(itemId, count, damage, enchantList)
        end
    elseif class == "ItemGun" then
        self:addGunItem(itemId, 1, 0, 1000)
    else
        self:addEnchantItem(itemId, count, damage, enchantList)
    end
    return itemId
end

function GamePlayer:tryAddToolItem(itemId, count, damage, enchantList, class)
    ---工具类型的道具需要替换原来旧的道具
    local oldItemId = tonumber(self.info:getValue(class))
    if oldItemId ~= 0 then
        self:removeItem(oldItemId, count)
    end
    self.info:setValue(class, itemId)
    self:addEnchantItem(itemId, count, damage, enchantList)
end

function GamePlayer:tryEquipArmor(itemId, damage, enchantList)
    local inv = self:getInventory()
    local index = inv:getArmorSlotById(itemId)
    enchantList = enchantList or {}
    if index >= 100 then
        ---只针对衣服，裤子，鞋子
        self.info:setValue("ItemArmor" .. index, itemId)
        if index == 103 then
            self.equip_iec = itemId == 1000
            self.entityPlayerMP:setBoolProperty("ignoreFire", self.equip_iec)
            self:equipNinjaShoes(itemId == Define.ItemId.NinjaShoes)
        end
    end
    enchantList = ArmorItemGain:onPlayerGetArmor(self, enchantList)
    self.entityPlayerMP:replaceArmorItemWithEnchant(itemId, 1, damage, enchantList)
    if index == 101 then
        if not PlayerManager:isAIPlayer(self) then
            CustomShopSuit:onChestChange(self, itemId)
        end
    end
end
function GamePlayer:equipNinjaShoes(isEquip)
    self:setSpeedAddition(isEquip and GameConfig.NinjaShoesSpeedLevel or 0)
    GamePacketSender:sendIsEquipNinjaShoes(self.rakssid, isEquip)
end

function GamePlayer:addInitItems(newItemId)
    for _, itemId in pairs(self.initItems) do
        if itemId == newItemId then
            return
        end
    end
    table.insert(self.initItems, newItemId)
end

function GamePlayer:clearArmorInfo()
    self.info:setValue("ItemSword", 0)
    self.info:setValue("ItemBow", 0)
    self.info:setValue("ItemArmor101", 0)
    self.info:setValue("ItemArmor102", 0)
    self.info:setValue("ItemArmor103", 0)
end

function GamePlayer:getClothBlockId()
    if self.team then
        return self.team.clothBlockId
    end
    return BlockID.CLOTH
end

function GamePlayer:getDoubleDummyId()
    if self.team then
        return self.team.doubleDummyId
    end
    return ItemID.DOUBLE_DUMMY
end

function GamePlayer:onSendCommand(commandConfig)
    local effectConfig = MessageEffectConfig:getConfigById(commandConfig.effectId)
    if not effectConfig then
        return
    end
    local getFountPosition = function(footPos, yaw)
        local leftYaw = yaw
        local x = -math.sin(leftYaw * MathUtil.DEG2RAD)
        local z = math.cos(leftYaw * MathUtil.DEG2RAD)
        return VectorUtil.newVector3(footPos.x + x * 0.3, footPos.y, footPos.z + z * 0.3)
    end

    -----设置特效
    local leftHandPos = getFountPosition(self:getPosition(), self:getYaw())
    GamePacketSender:sendSignalBomb(self:getEntityId(), leftHandPos, effectConfig.id, self.teamId)
end

function GamePlayer:subHealth(damage, fromMount)
    local value = self:subApple(damage)
    if value == 0 then
        return
    end
    if not fromMount and self.mount then
        self.mount:onHurt(value)
        return
    end
    return self.entityPlayerMP:heal(-value)
end

function GamePlayer:changeSpeed(speed)
    self.addSpeed = self.addSpeed + speed
    self.entityPlayerMP:setSpeedAdditionLevel(self.addSpeed)
end

function GamePlayer:recordGameResult(resultType)
    if QualifyingHelper.inQualifyingGame then
        self.taskController:packingProgressData(Define.TaskType.Fright.Qualifying, nil, 1)
    end
    PlayerCustomInfoUtil:reportGameTimes(self)
    if not self.last_game_record then
        ---没有 拉成功DB数据
        return
    end

    if self.isNew then
        self:recordNewBattleInfo()
    end

    self:reportBattleInfo(resultType == Define.GameResult.QUIT)

    table.insert(self.last_game_record, 1, resultType)
    if #self.last_game_record > Define.GameRecordSaveCount then
        table.remove(self.last_game_record)
    end

    self.game_start_times = self.game_start_times + 1
    self.gameResultType = resultType
    if self.gameDataController then
        self.gameDataController:report_end()
    end
    ServerReportEvent.player_game_end(self)
    self.game_start_times = self.game_start_times + 1
    if resultType == Define.GameResult.QUIT then
        if self.gameDataController then
            self.gameDataController:have_escape()
        end
        ---@param _player GamePlayer
        for _, _player in pairs(PlayerManager:getPlayers()) do
            if _player ~= self and _player.teamId == self.teamId then
                if _player.gameDataController then
                    _player.gameDataController:have_teammate_escape()
                end
            end
        end
        return
    end
    self.game_complete_times = self.game_complete_times + 1
    if resultType == Define.GameResult.WIN then
        self.game_victory_times = self.game_victory_times + 1
    end

    table.insert(self.trigger_gift_game_record, 1, { result = resultType, time = os.time() })
    if #self.trigger_gift_game_record > Define.TriggerGiftGameRecordSaveCount then
        table.remove(self.trigger_gift_game_record)
    end
end

function GamePlayer:canUseHollowBlock()
    if BuffManager:checkBuff(self.userId, BuffManager.BuffType.LockHollowBlock) then
        return
    end
    local num = self:getItemNumById(590)
    if num == 0 then
        return
    end

    BuffManager:createBuff(self.userId, BuffManager.BuffType.LockHollowBlock)
    AnalyticsReportUtil.onPlayerUseItem(self, 590)
    self:usingHollowBlock()
end

function GamePlayer:resetHollowBlock()
    if self.useHollowBlock then
        self.entityPlayerMP:setInTheAirCheatCheck(true)
        self.useHollowBlock = false
        HostApi.setAllowUseItemStatus(self.rakssid, 1)
        self.info:setValue("isGliding", false)
        self:endSinging()
    end
end

function GamePlayer:usingHollowBlock()
    local position = self:getPosition()

    self:setGlide(false)
    self.info:setValue("isGliding", true)
    HostApi.setAllowUseItemStatus(self.rakssid, 0)
    self.useHollowBlock = true
    self.useHollowBlockTime = os.time()
    local dest = GameConfig.startGlideHeight - position.y + 10
    local totle = 0
    local motion = 0
    while (true) do
        motion = ((motion / 0.98) + 0.08) / 0.98

        totle = totle + motion
        if totle >= dest then
            break
        end
    end

    self.entityPlayerMP:setInTheAirCheatCheck(false)
    self:sendPacket({
        pid = "BedWarPlayerMotion",
        motion = VectorUtil.newVector3(0, motion, 0)
    })

    self:removeItem(590, 1)
end

function GamePlayer:startSinging(singingTime, isCanBreak, icon, successCallBack)
    self:sendPacket({
        pid = "StartSinging",
        time = singingTime,
        icon = icon,
    })
    LuaTimer:cancel(self.singingKey or 0)
    self.singingKey = LuaTimer:schedule(function()
        self.singingKey = 0
        if successCallBack then
            successCallBack()
        end
    end, singingTime)
    if not isCanBreak then
        self.singingKey = 0
    end
end

function GamePlayer:breakSinging()
    if self.singingKey == 0 then
        return
    end
    LuaTimer:cancel(self.singingKey or 0)
    self.singingKey = 0
    self:endSinging()
end

function GamePlayer:endSinging()
    self:sendPacket({
        pid = "BreakSinging",
    })
end

function GamePlayer:teleportPos(position)
    if self:ifOnMount() then
        return
    end
    self.super.teleportPos(self, position)
end

function GamePlayer:ifOnMount()
    if not self.entityPlayerMP then
        return false
    end
    return self.entityPlayerMP:isOnFlyingMount() or self.entityPlayerMP:isOnFloatingMount()
end

local WinLimit = {
    g1008 = 8,
    g1061 = 4,
    g1062 = 8
}
function GamePlayer:reportBattleInfo(isQuit)
    local updateInfo = {}
    local playerInfo = GameInfoManager:getPlayerInfo(self.userId)
    if not playerInfo or not self.battleRecord then
        return
    end
    local type = QualifyingHelper.inQualifyingGame and "qualifying" or GameType
    local rank = tonumber(playerInfo:getValue("rank"))
    local isWin = rank > 0 and rank <= WinLimit[GameType]
    updateInfo.play = isQuit and 0 or 1
    updateInfo.win = (not isQuit and isWin) and 1 or 0
    updateInfo.comboWin = (not isQuit and isWin) and 1 or 0

    self:updateBattleInfo(updateInfo, true)

    local info = self.battleRecord[type]
    if not isQuit then
        local score = SRankUtil:win2Score(info.win, info.play)
        SRankUtil:reportWinRank(self.userId, score)
    end
    if isWin then
        SRankUtil:reportWinTimesRank(self.userId, info.win)
    end
    SRankUtil:reportWinningRank(self.userId, info.comboWin.max)
    SRankUtil:reportKillRank(self.userId, info.kill)
    SRankUtil:reportDestroyBedRank(self.userId, info.bed)
end

function GamePlayer:updateBattleInfo(data, needReportCustomInfo)
    if not self.battleRecord then
        return
    end
    local type = QualifyingHelper.inQualifyingGame and "qualifying" or GameType
    if not self.battleRecord[type] then
        self.battleRecord[type] = {
            win = 0,
            play = 0,
            kill = 0,
            bed = 0,
            comboWin = {
                max = 0,
                cur = 0
            }
        }
    end
    for key, value in pairs(data) do
        if self.battleRecord[type][key] then
            if key == "comboWin" then
                local comboWinInfo = self.battleRecord[type][key]
                comboWinInfo.cur = value == 0 and 0 or comboWinInfo.cur + 1
                comboWinInfo.max = math.max(comboWinInfo.max, comboWinInfo.cur)
                self.battleRecord[type][key] = comboWinInfo
            else
                self.battleRecord[type][key] = self.battleRecord[type][key] + value
            end
        end
    end
    if needReportCustomInfo then
        PlayerCustomInfoUtil:reportCustomInfo(self.userId, "string", Define.PlayerCustomInfo.BattleRecord, json.encode(self.battleRecord), "2")
    end
    return true
end

function GamePlayer:checkTriggerGift(gameRecord)
    local winTimes = 0
    local loseTimes = 0
    local playTimes = 0

    for index, record in pairs(gameRecord) do
        if index == 1 and record.result ~= Define.GameResult.WIN then
            break
        end
        if record.result == Define.GameResult.WIN then
            winTimes = winTimes + 1
        else
            break
        end
    end

    for index, record in pairs(gameRecord) do
        if index == 1 and record.result ~= Define.GameResult.LOSE then
            break
        end
        if record.result == Define.GameResult.LOSE then
            loseTimes = loseTimes + 1
        else
            break
        end
    end

    for _, record in pairs(gameRecord) do
        if os.time() - record.time < Define.TriggerGiftContinuePlayTime then
            playTimes = playTimes + 1
        else
            break
        end
    end
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Win, winTimes)
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Lose, loseTimes)
    Plugins.CallTargetPluginFunc("trigger_gift", "onPlayerDataChange", self, Define.TriggerGiftKey.Play, playTimes)
end

function GamePlayer:recordNewBattleInfo()
    local playerInfo = GameInfoManager:getPlayerInfo(self.userId)
    if not playerInfo then
        return
    end
    local rank = tonumber(playerInfo:getValue("rank"))
    local isWin = rank > 0 and rank <= WinLimit[GameType]
    local updateInfo = {
        kill = self.kills,
        die = tonumber(playerInfo:getValue("die")),
        time = RewardManager:getGameRunningTime(),
        play = 1,
        win = isWin and 1 or 0
    }

    if #self.lastFiveRecord >= 5 then
        table.remove(self.lastFiveRecord, #self.lastFiveRecord)
    end
    table.insert(self.lastFiveRecord, 1, IsAIGame)
    self:updateNewBattleInfo(updateInfo)
end

function GamePlayer:updateNewBattleInfo(data)
    if IsAIGame then
        for key, value in pairs(data) do
            self.aiGameRecord[key] = self.aiGameRecord[key] and self.aiGameRecord[key] + value or value
        end
    else
        if not self.newBattleRecord[GameType] then
            self.newBattleRecord[GameType] = {}
        end
        for key, value in pairs(data) do
            self.newBattleRecord[GameType][key] = self.newBattleRecord[GameType][key] and self.newBattleRecord[GameType][key] + value or value
        end
    end
end

function GamePlayer:updateDailyLastRecord()
    if not self.battleRecord then
        return
    end
    local type = QualifyingHelper.inQualifyingGame and "qualifying" or GameType
    if not self.battleRecord[type] then
        self.battleRecord[type] = {
            win = 0,
            play = 0,
            kill = 0,
            bed = 0,
            comboWin = {
                max = 0,
                cur = 0
            }
        }
    end
    self.battleRecord[type].lastRecord = {
        win = self.battleRecord[type].win,
        play = self.battleRecord[type].play
    }
    PlayerCustomInfoUtil:reportCustomInfo(self.userId, "string", Define.PlayerCustomInfo.BattleRecord, json.encode(self.battleRecord), "2")
end

return GamePlayer

--endregion
