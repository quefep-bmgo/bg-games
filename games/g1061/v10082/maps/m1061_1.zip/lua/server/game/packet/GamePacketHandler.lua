local handler = class("GamePacketHandler", EventObservable)

function handler:init()
    self:registerDataCallBack("SettlementGood", function(fromUserId, toUserId)
        SettlementManager:sendGood(fromUserId, toUserId)
    end)
    self:registerDataCallBack("PushSurveySuccess", function(userId)
        local player = PlayerManager:getPlayerByUserId(userId)
        if player then
            SurveyManager:onPlayerPushSurveySuccess(player)
        end
    end)
    self:registerDataCallBack("placeBlock", self.onPlayerPlaceBlock)
end

function handler.onPlayerPlaceBlock(userId, data)
    if not GameMatch:isGameStart() then
        return false
    end
    local builder = DataBuilder.new():fromData(data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local source = builder:getParam("source")
    local pos = VectorUtil.newVector3(builder:getNumberParam("posX"), builder:getNumberParam("posY"), builder:getNumberParam("posZ"))
    player:placeBlock(pos, VectorUtil.newVector3(0, 0, 0), builder:getNumberParam("face"))
    if source == "button" then
        player.placeBlockNumByButton = player.placeBlockNumByButton + 1
    end
    SettlementManager:addBuildScore(player.userId, Define.BuildType.Place)
end

handler:init()