---@class WitheredSkill : BaseSkill
local WitheredSkill = class("WitheredSkill", require "game.skill.BaseSkill")

local withered_hp = 40
local withered_duration = 30
local withered_mount_id = 2

function WitheredSkill:createSkillEffect(name, time)

end
---@param player GamePlayer
function WitheredSkill:onPlayerEffected(player)
    local mount_skill = SkillConfig:getSkillByType(SkillManager.SkillType.DropTNTSkill)
    if not mount_skill then
        return
    end
    local GameWithered = require "game.entity.mount.GameWithered"
    local position = VectorUtil.add3(player:getPosition(), VectorUtil.newVector3(0, 2, 0))
    GameWithered.new(withered_mount_id, position, withered_hp, self.duration, mount_skill.itemId, player)
    player:startSinging(self.duration * 1000, false, Define.SingingIcon.Withered)
end

return WitheredSkill