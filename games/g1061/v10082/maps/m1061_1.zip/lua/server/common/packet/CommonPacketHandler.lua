local handler = class("CommonPacketHandler", EventObservable)
---@type PlayerCustomInfoUtil
local PlayerCustomInfoUtil = T(Global, "PlayerCustomInfoUtil")

function handler:init()
    self:registerDataCallBack("OpenLotteryBox", self.onPlayerOpenLotteryBox)
    self:registerDataCallBack("UseMovieTicket", self.onPlayerUseMovieTicket)
    self:registerDataCallBack("ReportFriendCount", self.onReportFriendCount)
end

function handler.onPlayerOpenLotteryBox(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if player == nil then
        return
    end
    local builder = DataBuilder.new():fromData(data)
    local chestId = builder:getNumberParam("chestId")
    local num = builder:getNumberParam("num")
    GameChestLottery:onPlayerOpenLotteryChest(player, chestId, math.max(num, 1))
end

function handler.onPlayerUseMovieTicket(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    if player:subTicket(1) then
        local params = DataBuilder.new():fromData(data):getNumberParam("params")
        local type =DataBuilder.new():fromData(data):getNumberParam("type")
        CustomListener.onWatchAdvertFinished(player.rakssid, type, params, 1)
    end
end

function handler.onReportFriendCount(userId, data)
    local FriendCount = DataBuilder.new():fromData(data):getNumberParam("count")
    PlayerCustomInfoUtil:reportCustomInfo(userId, "int", Define.PlayerCustomInfo.FriendCount, FriendCount, "2")
end

handler:init()