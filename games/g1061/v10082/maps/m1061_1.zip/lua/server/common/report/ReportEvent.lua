---@param userId number userId [player userId]
---@param event number event [event name]
---@param event_map table event_map [eg {key1 = value1,key2 = value2, ...}]
local function newDesign(userId, event, event_map)
    if AIManager and AIManager:isAIByUserId(userId) then
        return
    end
    GameAnalytics:newDesign(userId, event, event_map)
end

local config = FileUtil.getConfigFromCsv("setting/StoreGoods.csv")
local allItemMap = {}
for _, item in pairs(config) do
    local Type = tonumber(item.Type)
    local ItemId = tonumber(item.ItemId)
    if Type == 0 then
        allItemMap[tostring(ItemId)] = true
    end
end
local BuyItemCache = {}

---@type ServerReportEvent
local ReportEvent = T(Global, "ReportEvent")
---@type ServerReportValue
local ReportValue = require "common.report.ReportValue"

---@param attr UserAttrInfo
---@return number
function ReportEvent.player_attr(attr)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    newDesign(attr.userId, "player_attr", event_map)
end

---@param player GamePlayer
---@return number
function ReportEvent.player_login(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    player.login_time = os.time()
    player.ready_time = player.login_time
    newDesign(player.userId, "player_login", event_map)
end
---@param player GamePlayer
---@return number
function ReportEvent.player_ready(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    player.ready_time = os.time()
    newDesign(player.userId, "player_ready", event_map)

    local cache = {}
    for itemId, _ in pairs(allItemMap) do
        cache[tostring(itemId)] = 0
    end
    BuyItemCache[tostring(player.userId)] = cache
    ReportEvent.player_recharge_ready(player)
end

---@param player GamePlayer
---@return number
function ReportEvent.player_recharge_ready(player)
    if player.total_recharge_cube == nil or player.have_cube_order == nil then
        LuaTimer:schedule(function()
            if player.entityPlayerMP then
                ReportEvent.player_recharge_ready(player)
            end
        end, 1000)
        return
    end
    local event_map = {}
    local key_list = {
        "total_recharge_cube",
        "have_cube_order",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_recharge_ready", event_map)
end

---@param player GamePlayer
---@return number
function ReportEvent.player_logout(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_hidden_score",
        "qualifying_score",
        "qualifying_brave_points",
        "qualifying_segment_grade_star",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_logout", event_map)
end

---@param player GamePlayer
---@return number
function ReportEvent.player_game_start(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_game_start", event_map)
end

---@param player GamePlayer
---@return number
function ReportEvent.player_game_end(player)
    local rank = tonumber(player.info:getValue("rank"))
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
        "game_result_type",
        "player_running_second",
        "game_running_second",
        "player_waiting_second",
        "server_running_second",
        "total_average_fps",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_is_in_pos_match",
        "qualifying_add_qualifying_score",
        "qualifying_add_brave_point",
        "qualifying_is_in_team",
        "qualifying_is_consume_brave_score",
        "qualifying_segment_grade_star",
        "g1008_loser_streak",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map["settlement_rank"] = rank

    local cache = BuyItemCache[tostring(player.userId)]
    if cache then
        local buy_ids = {}
        for itemId, count in pairs(cache) do
            if count > 0 then
                table.insert(buy_ids, tonumber(itemId))
            end
        end
        event_map["item_ids"] = "#" .. table.concat(buy_ids, "#")
    end

    newDesign(player.userId, "player_game_end", event_map)
end

---@return number
function ReportEvent.player_minute_fps(player)
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
        "player_running_minute",
        "minute_average_fps",
        "minute_min_fps",
        "minute_max_fps",
        "total_average_fps",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_minute_fps", event_map)
end

function ReportEvent.server_game_end()
    local event_map = {}
    local key_list = {
        "game_mode",
        "ai_game",
        "map_id",
        "game_running_second",
        "server_running_second",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key]()
    end
    newDesign(0, "server_game_end", event_map)
end

---@param player GamePlayer
---@param goodsId number
---@return number
function ReportEvent.buy_custom_goods(player, goodsId)
    newDesign(player.userId, "buy_custom_goods", { goodsId = goodsId })
end

---@param player GamePlayer
---@return number
function ReportEvent.player_login_db_finished(player)
    local event_map = {}
    local key_list = {
        "complete_guide",
        "new_player",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "player_login_db_finished", event_map)
end

---@param player GamePlayer
---@param itemId number
---@return number
function ReportEvent.buy_store_item(player, itemId)
    --newDesign(player.userId, "buy_store_item", {
    --    item_id = itemId,
    --    ai_game = ReportValue.ai_game(player),
    --    game_mode = ReportValue.game_mode(player),
    --})

    local cache = BuyItemCache[tostring(player.userId)]
    if cache and cache[tostring(itemId)] then
        cache[tostring(itemId)] = cache[tostring(itemId)] + 1
    end
end

---@param player GamePlayer
function ReportEvent.new_player_logout(player)
    local event_map = {}
    local key_list = {
        "consecutive_login_days",
        "segment_score",
        "player_lv",
        "play_times_g1008",
        "win_rate_g1008_d",
        "play_times_g1062",
        "win_rate_g1062_d",
        "play_times_g1061",
        "win_rate_g1061_d",
        "ai_game_times",
        "ai_game_win_rate_d",
        "ai_in_last_1",
        "ai_in_last_3",
        "ai_in_last_5",
        "kill_avg_times_g1008_d",
        "die_avg_times_g1008_d",
        "kill_avg_times_ai_d",
        "die_avg_times_ai_d",
        "avg_play_time_g1008_d",
        "avg_play_time_ai_d",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "new_player_logout", event_map)
end

---@param player GamePlayer
function ReportEvent.weekly_segment_score(player)
    local event_map = {}
    local key_list = {
        "is_new",
        "weekly_segment_score"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    newDesign(player.userId, "weekly_segment_score", event_map)
end

---@param player GamePlayer
function ReportEvent.recharge_success(player, reportKey, productId)
    local event_map = {}
    local key_list = {
        "total_recharge_cube"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.report_key = reportKey
    event_map.recharge_productId = productId
    newDesign(player.userId, "recharge_success", event_map)
end

---@param player SBasePlayer
function ReportEvent.activity_sign_in(player, id)
    local event_map = {}
    local key_list = {
        "cube_count",
        "total_recharge_cube"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.activity_sign_in_id = tonumber(id)
    newDesign(player.userId, "activity_sign_in", event_map)
end

function ReportEvent.qualifying_segment_change(player, isSegmentChange, isRise)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.qualifying_is_big_segment = isSegmentChange
    event_map.qualifying_is_rise = isRise   --- 段位变化，是否上升
    newDesign(player.userId, "qualifying_segment_change", event_map)
end

function ReportEvent.qualifying_quarter_grade_rise(player, gradeRiseTime)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.qualifying_grade_rise_time = gradeRiseTime
    newDesign(player.userId, "qualifying_quarter_grade_rise", event_map)
end

function ReportEvent.qualifying_quarter_Segment_rise(player, segmentRiseTime)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star"
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.qualifying_segment_rise_time = segmentRiseTime
    newDesign(player.userId, "qualifying_quarter_Segment_rise", event_map)
end

---@param player SBasePlayer
function ReportEvent.player_match_success(player, match_time, game_mode)
    local event_map = {}
    local key_list = {
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "qualifying_score",
        "server_time",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.match_time = tonumber(match_time)
    event_map.game_mode = tostring(game_mode)
    newDesign(player.userId, "player_match_success", event_map)
end

---@param player SBasePlayer
function ReportEvent.player_match_confirm(player, confirm_time)
    local event_map = {}
    local key_list = {
        "player_lv",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "qualifying_score",
        "server_time",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.confirm_time = tonumber(confirm_time)
    newDesign(player.userId, "player_match_confirm", event_map)
end

---@param player SBasePlayer
function ReportEvent.player_match_ready(player, ready_time)
    local event_map = {}
    local key_list = {
        "player_lv",
        "qualifying_segment",
        "qualifying_grade",
        "qualifying_star_number",
        "qualifying_segment_grade_star",
        "qualifying_score",
        "server_time",
    }
    for _, key in pairs(key_list) do
        event_map[key] = ReportValue[key](player)
    end
    event_map.ready_time = tonumber(ready_time)
    newDesign(player.userId, "player_match_ready", event_map)
end

function ReportEvent.reported_player(userId, report_id)
    local map = {
        report_id = tonumber(report_id),
    }
    newDesign(userId, "reported_player", map)
end

function ReportEvent.receive_qualifying_challenge(player, total_score, reward_score, total_streak)
    local map = {
        challenge_total_score = tonumber(total_score),
        challenge_reward_score = tonumber(reward_score),
        total_streak = tonumber(total_streak),
    }
    newDesign(player.userId, "receive_qualifying_challenge", map)
end

ServerReportEvent = ReportEvent
