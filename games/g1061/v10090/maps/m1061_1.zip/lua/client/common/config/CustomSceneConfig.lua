---@class CustomSceneConfig
local CustomSceneConfig = T(Global, "CustomSceneConfig")

---@type CustomSceneItem[]
local CustomSceneItems = {}
local SceneType = {
    NoType = 0,
    Effect = 1,
    Image = 2,
    Actor = 3,
    WallText = 4,
    Mesh = 5,
}

local ChunkStatus = {
    Loading = 1,
    Unloaded = 2
}

local ChunkSideLength = 5
---@type CustomSceneChunk[]
local CustomSceneChunks = {}
local JsonMap = {}
local CurIndex = 0

local WallTextAlignment = 5

---新增参数要修改三处代码
----------------------------------- 1 ---------------------------------------
local function getConfigTemplate()
    local template = {
        Id = #CustomSceneItems + 1,
        type = 0,
        showType = Define.SceneItemShowType.All,
        pos = PlayerManager:getClientPlayer():getPosition(),
        scale = 1,
        yaw = PlayerManager:getClientPlayer():getYaw(),
        createTime = 0,
        destroyTime = 0,
        param1 = "#",
        param2 = "#",
        param3 = "#",
        param4 = "#",
        param5 = "#",
        param6 = "#",
        param7 = "#",
    }

    return template
end

local function getChunkKey(pos)
    return tostring(math.floor(pos.x / ChunkSideLength) * ChunkSideLength) .. "#" ..
            tostring(math.floor(pos.z / ChunkSideLength) * ChunkSideLength)
end

----------------------------------- 2 ---------------------------------------
function CustomSceneConfig:init()
    local configs = FileUtil.getConfigFromCsv("setting/CustomScene.csv", 2, true)
    local curTime = os.time()
    for _, config in pairs(configs) do
        local pos = StringUtil.split(config.pos or "", ",")
        ---@class CustomSceneItem
        local item = {
            Id = tonumber(config.Id) or 0,
            type = tonumber(config.type) or 0,
            showType = tonumber(config.showType) or Define.SceneItemShowType.All,
            pos = VectorUtil.newVector3(pos[1] or 0, pos[2] or 0, pos[3] or 0),
            scale = tonumber(config.scale or 0),
            yaw = tonumber(config.yaw or 0),
            createTime = tonumber(config.createTime or 0),
            destroyTime = tonumber(config.destroyTime or 0),
            param1 = tostring(config.param1 or "#"),
            param2 = tostring(config.param2 or "#"),
            param3 = tostring(config.param3 or "#"),
            param4 = tostring(config.param4 or "#"),
            param5 = tostring(config.param5 or "#"),
            param6 = tostring(config.param6 or "#"),
            param7 = tostring(config.param7 or "#")
        }

        if item.destroyTime == 0 or curTime < item.destroyTime then
            self:addItemToChunk(item)
            CustomSceneItems[item.Id] = item
            if item.type == SceneType.Image then
                JsonMap[item.param1] = 1
            end
        end
        if item.type == SceneType.Mesh then
            WorldMeshRender.Instance():addMesh("CustomMesh#" .. item.Id, item.param1, item.pos, item.yaw, 90, item.scale)
        end
    end
end

---保存配置
----------------------------------- 3 ---------------------------------------
function CustomSceneConfig:saveConfig()
    local path = FileUtil.getConfigPath("setting/CustomScene.csv")
    local file = io.open(path, "w+")
    if file then
        file:write("Id\t场景类型(1:特效2:图片3:模型)\t坐标\t缩放\t朝向\t出现时间\t消失时间\t参数1\t参数2\t参数3\t参数4\t参数5\t参数6\t参数7\t" .. "\n")
        file:write("Id\ttype\tpos\tscale\tyaw\tcreateTime\tdestroyTime\tparam1\tparam2\tparam3\tparam4\tparam5\tparam6\tparam7\t" .. "\n")
        for index, item in pairs(CustomSceneItems) do
            local line = index .. "\t" .. item.type .. "\t" .. item.pos.x .. "," .. item.pos.y .. "," .. item.pos.z ..
                    "\t" .. item.scale .. "\t" .. item.yaw .. "\t" .. item.createTime .. "\t" .. item.destroyTime .. "\t" .. item.param1
                    .. "\t" .. item.param2 .. "\t" .. item.param3 .. "\t" .. item.param4 .. "\t" .. item.param5 .. "\t" .. item.param6
                    .. "\t" .. item.param7 .. "\t"
            file:write(line .. "\n")
        end
        file:close()
    end

    CustomSceneConfig:showSelectGuideArrow(nil)
end

---@type CustomSceneItem
function CustomSceneConfig:addItemToChunk(item)
    if item.type == SceneType.Mesh then
        return
    end
    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        if CustomSceneChunks[chunkKey].status == ChunkStatus.Loading then
            CustomSceneConfig:addItemToLoadingChunk(chunkKey, item)
        elseif CustomSceneChunks[chunkKey].status == ChunkStatus.Unloaded then
            table.insert(CustomSceneChunks[chunkKey].items, item)
        end
    else
        ---@class CustomSceneChunk
        local newChunk = {
            status = ChunkStatus.Unloaded,
            ---@type CustomSceneItem[]
            items = {},
            centerPos = VectorUtil.newVector3(math.floor(item.pos.x / ChunkSideLength) * ChunkSideLength + ChunkSideLength / 2, 0,
                    math.floor(item.pos.z / ChunkSideLength) * ChunkSideLength + ChunkSideLength / 2)
        }
        table.insert(newChunk.items, item)
        CustomSceneChunks[chunkKey] = newChunk
    end
end

---@return CustomSceneItem
function CustomSceneConfig:getConfigById(id)
    return CustomSceneItems[tonumber(id)]
end

function CustomSceneConfig:gameReady()
    for jsonName, _ in pairs(JsonMap) do
        TextureAtlasRegister.Instance():addTextureAtlas(jsonName, "")
    end

    self.frameTimes = 0
    Listener.registerCallBack(CEvents.GameMainTickEvent, function(frameTime)
        self:onUpdate(frameTime)
    end)
end

function CustomSceneConfig:onUpdate(frameTime)
    self.frameTimes = self.frameTimes + frameTime
    if self.frameTimes < 1000 then
        return
    end
    self.frameTimes = 0
    local playerPos = PlayerManager:getClientPlayer():getPosition()
    playerPos.y = 0
    for key, chunk in pairs(CustomSceneChunks) do
        local distance = VectorUtil.distance(playerPos, chunk.centerPos)
        if chunk.status == ChunkStatus.Unloaded and distance < GameConfig.CustomSceneLoadRadius then
            self:createScene(key)
            chunk.status = ChunkStatus.Loading
        elseif chunk.status == ChunkStatus.Loading and distance > GameConfig.CustomSceneLoadRadius then
            self:destroyScene(key)
            chunk.status = ChunkStatus.Unloaded
        end
    end
end

function CustomSceneConfig:createScene(chunkKey)
    local curTime = os.time()
    for _, config in pairs(CustomSceneChunks[chunkKey].items or {}) do
        if (config.createTime == 0 and config.destroyTime == 0) or (curTime > config.createTime and curTime < config.destroyTime) then
            if config.type == SceneType.Effect then
                config.targetEffect = EngineWorld:addSimpleEffect(config.param1, config.pos, config.yaw, -1, config.scale, config.scale, config.scale)
                CustomSceneItems[config.Id].targetEffect = config.targetEffect
            elseif config.type == SceneType.Image then
                WorldImageRender.Instance():addStaticImage("CustomImage#" .. config.Id, config.param1, config.param2, config.pos, config.scale, false, config.yaw)
            elseif config.type == SceneType.Actor then
                config.targetEntityId = EngineWorld:addActorNpc(config.pos, config.yaw, config.param1, function(entity)
                    entity:setSkillName(config.param2 ~= "#" and config.param2 or "idle")
                    if config.param3 ~= "#" and tonumber(config.param3) > 0 then
                        LuaTimer:cancel(config.animKey or 0)
                        config.animKey = LuaTimer:scheduleTimer(function()
                            local animEntity = EntityCache:getEntity(config.targetEntityId)
                            if animEntity and animEntity.entity then
                                animEntity.entity:setSkillName(config.param2 ~= "#" and config.param2 or "idle")
                            end
                        end, tonumber(config.param3))
                    end
                    entity:setScale(config.scale)
                    entity:setCanCollided(false)
                    if config.param5 ~= "#" then
                        local builder = DataBuilder.new()
                        builder:addParam("bodyName", "body")
                        builder:addParam("bodyId", config.param5)
                        entity:addCustomBodyPart("actor", builder:getData())
                    end
                    if config.param6 ~= "#" then
                        local param = StringUtil.split(config.param6, "#")
                        local text = "text=" .. param[1] .. "&offset=0:" .. entity:getHeight() + tonumber(param[2]) .. ":0"
                        entity:addCustomText("Name", text, -1, tonumber(param[3]))
                    end
                    if tonumber(config.param7) == 1 then
                        entity:setFlying(true)
                    end
                end)

                CustomSceneItems[config.Id].targetEntityId = config.targetEntityId
                if config.param4 ~= "#" then
                    local npc = EntityCache:getEntity(config.targetEntityId)
                    npc.type = tonumber(config.param4)
                end
            elseif config.type == SceneType.WallText then
                local globalRender = Blockman.Instance().m_globalRender
                if globalRender then
                    local rgba = StringUtil.split(config.param3, "#", false, true)
                    globalRender:luaAddWallText(WallTextAlignment, -1, config.param1, config.pos,
                            config.scale, config.yaw, config.param2, { rgba[1] / 255, rgba[2] / 255, rgba[3] / 255, rgba[4] / 255 })
                end
            end
        end
    end
end

function CustomSceneConfig:destroyScene(chunkKey)
    for _, config in pairs(CustomSceneChunks[chunkKey].items or {}) do
        if config.type == SceneType.Effect then
            if config.targetEffect then
                EngineWorld:removeSimpleEffect(config.targetEffect.mEffectName)
            end
            config.targetEffect = nil
            CustomSceneItems[config.Id].targetEffect = nil
        elseif config.type == SceneType.Image then
            WorldImageRender.Instance():removeStaticImage("CustomImage#" .. config.Id)
        elseif config.type == SceneType.Actor then
            LuaTimer:cancel(config.animKey or 0)
            EngineWorld:removeEntity(config.targetEntityId)
            EntityCache:removeEntityCache(config.targetEntityId)
            config.targetEntityId = nil
            CustomSceneItems[config.Id].targetEntityId = nil
        elseif config.type == SceneType.WallText then
            local globalRender = Blockman.Instance().m_globalRender
            if globalRender then
                globalRender:deleteWallText(config.pos or VectorUtil.ZERO, 0.1)
            end
        end
    end
end

function CustomSceneConfig:addItemToLoadingChunk(chunkKey, item)
    if item.type == SceneType.Effect then
        item.targetEffect = EngineWorld:addSimpleEffect(item.param1, item.pos, item.yaw, -1, item.scale, item.scale, item.scale)
        CustomSceneItems[item.Id].targetEffect = item.targetEffect
    elseif item.type == SceneType.Image then
        WorldImageRender.Instance():addStaticImage("CustomImage#" .. item.Id, item.param1, item.param2, item.pos, item.scale, false, item.yaw)
    elseif item.type == SceneType.Actor then
        item.targetEntityId = EngineWorld:addActorNpc(item.pos, item.yaw, item.param1, function(entity)
            entity:setSkillName(item.param2 ~= "#" and item.param2 or "idle")
            if item.param3 ~= "#" and tonumber(item.param3) > 0 then
                LuaTimer:cancel(item.animKey or 0)
                item.animKey = LuaTimer:scheduleTimer(function()
                    local animEntity = EntityCache:getEntity(item.targetEntityId)
                    if animEntity and animEntity.entity then
                        animEntity.entity:setSkillName(item.param2 ~= "#" and item.param2 or "idle")
                    end
                end, tonumber(item.param3))
            end
            entity:setScale(item.scale)
            entity:setCanCollided(false)
            if item.param5 ~= "#" then
                local builder = DataBuilder.new()
                builder:addParam("bodyName", "body")
                builder:addParam("bodyId", item.param5)
                entity:addCustomBodyPart("actor", builder:getData())
            end
            if item.param6 ~= "#" then
                local param = StringUtil.split(item.param6, "#")
                local text = "text=" .. param[1] .. "&offset=0:" .. entity:getHeight() + tonumber(param[2]) .. ":0"
                entity:addCustomText("Name", text, -1, tonumber(param[3]))
            end
            if tonumber(item.param7) == 1 then
                entity:setFlying(true)
            end
        end)

        CustomSceneItems[item.Id].targetEntityId = item.targetEntityId
        if item.param4 ~= "#" then
            local npc = EntityCache:getEntity(item.targetEntityId)
            npc.type = tonumber(item.param4)
        end
    elseif item.type == SceneType.WallText then
        local globalRender = Blockman.Instance().m_globalRender
        if globalRender then
            local rgba = StringUtil.split(item.param3, "#", false, true)
            globalRender:luaAddWallText(WallTextAlignment, -1, item.param1, item.pos,
                    item.scale, item.yaw, item.param2, { rgba[1] / 255, rgba[2] / 255, rgba[3] / 255, rgba[4] / 255 })
        end
    end
    if item.type == SceneType.Mesh then
        return
    end
    table.insert(CustomSceneChunks[chunkKey].items, item)
end

---新建特效
---@param effectName
function CustomSceneConfig:newSimpleEffect(effectName)
    if #effectName <= 7 then
        return
    end
    local item = getConfigTemplate()
    item.type = SceneType.Effect
    item.param1 = effectName or "#"

    table.insert(CustomSceneItems, item)
    self:addItemToChunk(item)
    CurIndex = #CustomSceneItems
end

---新建图片
function CustomSceneConfig:newSimpleImage(atlas, sprite)
    if not string.find(atlas, ".json") then
        atlas = atlas .. ".json"
    end
    if #atlas <= 4 or #sprite == 0 then
        return
    end
    local item = getConfigTemplate()
    item.type = SceneType.Image
    item.param1 = atlas
    item.param2 = sprite

    TextureAtlasRegister.Instance():addTextureAtlas(atlas, "")
    table.insert(CustomSceneItems, item)
    self:addItemToChunk(item)
    CurIndex = #CustomSceneItems
end

---新建Npc
function CustomSceneConfig:newActorNpc(actorName, action, cd)
    if not string.find(actorName, ".actor") then
        actorName = actorName .. ".actor"
    end
    if #actorName <= 6 then
        return
    end
    local item = getConfigTemplate()
    item.type = SceneType.Actor
    item.param1 = actorName or "#"
    item.param2 = action or "idle"
    item.param3 = tonumber(cd) or 0

    table.insert(CustomSceneItems, item)
    self:addItemToChunk(item)
    CurIndex = #CustomSceneItems
end

function CustomSceneConfig:newMesh(meshName)
    if #meshName <= 5 then
        return
    end
    local item = getConfigTemplate()
    item.type = SceneType.Mesh
    item.param1 = meshName or "#"
    item.pos.y = item.pos.y - 1.6
    WorldMeshRender.Instance():addMesh("CustomMesh#" .. item.Id, item.param1, item.pos, item.yaw, 90, item.scale)
    table.insert(CustomSceneItems, item)
    CurIndex = #CustomSceneItems
end

---给npc添加点击事件
function CustomSceneConfig:addActorNpcClickEvent(eventType)
    local item = CustomSceneItems[CurIndex]
    if not item then
        return
    end

    if item.type ~= SceneType.Actor then
        return
    end

    local npc = EntityCache:getEntity(item.targetEntityId)
    CustomSceneItems[CurIndex].param4 = tonumber(eventType)
    npc.type = tonumber(eventType)

    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        for _, _item in pairs(CustomSceneChunks[chunkKey].items) do
            if _item.Id == item.Id then
                _item.param4 = tonumber(eventType)
                break
            end
        end
    end
end

---给npc添加头顶文字
function CustomSceneConfig:addHeadText(headText, height, scale)
    local item = CustomSceneItems[CurIndex]
    if not item then
        return
    end

    local param = tostring(headText) .. "#" .. tostring(height) .. "#" .. tostring(scale)
    if item.type ~= SceneType.Actor then
        return
    end

    local entity = EngineWorld:getEntity(item.targetEntityId)
    CustomSceneItems[CurIndex].param6 = param
    local text = "text=" .. tostring(headText) .. "&offset=0:" .. entity:getHeight() + tonumber(height) .. ":0"
    entity:addCustomText("Name", text, -1, tonumber(scale))

    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        for _, _item in pairs(CustomSceneChunks[chunkKey].items) do
            if _item.Id == item.Id then
                _item.param6 = param
                break
            end
        end
    end
end

---给npc设置飞行
function CustomSceneConfig:setEntityFly()
    local item = CustomSceneItems[CurIndex]
    if not item then
        return
    end

    if item.type ~= SceneType.Actor then
        return
    end
    local npc = EntityCache:getEntity(item.targetEntityId)
    npc.entity:setFlying(true)
    CustomSceneItems[CurIndex].param7 = 1
    local chunkKey = getChunkKey(item.pos)

    if CustomSceneChunks[chunkKey] then
        for _, _item in pairs(CustomSceneChunks[chunkKey].items) do
            if _item.Id == item.Id then
                _item.param7 = 1
                break
            end
        end
    end
end

---添加场景文字
function CustomSceneConfig:addWallText(headText, scale, yaw, pitch, color)
    local item = getConfigTemplate()
    item.type = SceneType.WallText
    item.yaw = tonumber(yaw) or 0
    item.scale = scale or 1
    item.param1 = headText or "#"
    item.param2 = tonumber(pitch) or 0
    item.param3 = tostring(color) or "0#0#0#255"

    table.insert(CustomSceneItems, item)
    self:addItemToChunk(item)
    CurIndex = #CustomSceneItems
end

---移动坐标
---@param offset Vector3
function CustomSceneConfig:movePosition(offset)
    local item = CustomSceneItems[CurIndex]
    if not item then
        return
    end

    local oldPos = item.pos
    item.pos = VectorUtil.add3(item.pos, offset)

    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        for _, _item in pairs(CustomSceneChunks[chunkKey].items) do
            if _item.Id == item.Id then
                _item.pos = item.pos
                break
            end
        end
    end

    if item.type == SceneType.Effect then
        if item.targetEffect then
            item.targetEffect.mPosition = item.pos
        end
    elseif item.type == SceneType.Image then
        WorldImageRender.Instance():addStaticImage("CustomImage#" .. item.Id, item.param1, item.param2, item.pos, item.scale, false, item.yaw)
    elseif item.type == SceneType.Actor then
        local entity = EngineWorld:getEntity(item.targetEntityId)
        entity:setPosition(VectorUtil.add3(entity.position, offset))
    elseif item.type == SceneType.WallText then
        local globalRender = Blockman.Instance().m_globalRender
        if globalRender then
            globalRender:deleteWallText(oldPos or VectorUtil.ZERO, 0.1)
            local rgba = StringUtil.split(item.param3, "#", false, true)
            globalRender:luaAddWallText(WallTextAlignment, -1, item.param1, item.pos,
                    item.scale, item.yaw, item.param2, { rgba[1] / 255, rgba[2] / 255, rgba[3] / 255, rgba[4] / 255 })
        end
    elseif item.type == SceneType.Mesh then
        local name = "CustomMesh#" .. item.Id
        WorldMeshRender.Instance():removeMesh(name)
        LuaTimer:schedule(function()
            WorldMeshRender.Instance():addMesh(name, item.param1, item.pos, item.yaw, 90, item.scale)
        end, 1)
    end
end

---改变比例
function CustomSceneConfig:changeScale(scaleOffset)
    local item = CustomSceneItems[CurIndex]
    if not item then
        return
    end
    item.scale = item.scale + scaleOffset

    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        for _, _item in pairs(CustomSceneChunks[chunkKey].items) do
            if _item.Id == item.Id then
                _item.scale = item.scale
                break
            end
        end
    end

    if item.type == SceneType.Effect then
        if item.targetEffect then
            item.targetEffect.mScaling = item.scale
        end
    elseif item.type == SceneType.Image then
        WorldImageRender.Instance():addStaticImage("CustomImage#" .. item.Id, item.param1, item.param2, item.pos, item.scale, false, item.yaw)
    elseif item.type == SceneType.Actor then
        local entity = EngineWorld:getEntity(item.targetEntityId)
        entity:setScale(item.scale)
    elseif item.type == SceneType.WallText then
        local globalRender = Blockman.Instance().m_globalRender
        if globalRender then
            globalRender:deleteWallText(item.pos, 0.1)
            LuaTimer:scheduleTimer(function()
                local rgba = StringUtil.split(item.param3, "#", false, true)
                globalRender:luaAddWallText(WallTextAlignment, -1, item.param1, item.pos,
                        item.scale, item.yaw, item.param2, { rgba[1] / 255, rgba[2] / 255, rgba[3] / 255, rgba[4] / 255 })
            end, 1, 1)
        end
    elseif item.type == SceneType.Mesh then
        local name = "CustomMesh#" .. item.Id
        WorldMeshRender.Instance():removeMesh(name)
        LuaTimer:schedule(function()
            WorldMeshRender.Instance():addMesh(name, item.param1, item.pos, item.yaw, 90, item.scale)
        end, 1)
    end
end

---改变Yaw值
function CustomSceneConfig:changeYaw(yawOffset)
    local item = CustomSceneItems[CurIndex]
    if not item then
        return
    end
    item.yaw = item.yaw + yawOffset

    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        for _, _item in pairs(CustomSceneChunks[chunkKey].items) do
            if _item.Id == item.Id then
                _item.yaw = item.yaw
                break
            end
        end
    end

    if item.type == SceneType.Effect then
        if item.targetEffect then
            item.targetEffect.mYaw = item.yaw
        end
    elseif item.type == SceneType.Image then
        WorldImageRender.Instance():addStaticImage("CustomImage#" .. item.Id, item.param1, item.param2, item.pos, item.scale, false, item.yaw)
    elseif item.type == SceneType.Actor then
        local entity = EngineWorld:getEntity(item.targetEntityId)
        entity.rotationYaw = item.yaw
    elseif item.type == SceneType.WallText then
        local globalRender = Blockman.Instance().m_globalRender
        if globalRender then
            globalRender:deleteWallText(item.pos, 0.1)
            LuaTimer:scheduleTimer(function()
                local rgba = StringUtil.split(item.param3, "#", false, true)
                globalRender:luaAddWallText(WallTextAlignment, -1, item.param1, item.pos,
                        item.scale, item.yaw, item.param2, { rgba[1] / 255, rgba[2] / 255, rgba[3] / 255, rgba[4] / 255 })
            end, 1, 1)
        end
    elseif item.type == SceneType.Mesh then
        local name = "CustomMesh#" .. item.Id
        WorldMeshRender.Instance():removeMesh(name)
        LuaTimer:schedule(function()
            WorldMeshRender.Instance():addMesh(name, item.param1, item.pos, item.yaw, 90, item.scale)
        end, 1)
    end
end

---选中引导箭头
function CustomSceneConfig:showSelectGuideArrow(ItemPos)
    PlayerManager:getClientPlayer().Player:deleteAllGuideArrow()
    if ItemPos then
        LuaTimer:scheduleTimer(function()
            PlayerManager:getClientPlayer().Player:addGuideArrow(ItemPos)
        end, 1, 1)
    end
end

---选中最近目标
function CustomSceneConfig:SelectedRecent()
    CurIndex = #CustomSceneItems
    local recentDistance = 1000
    local playerPos = PlayerManager:getClientPlayer():getPosition()
    for index, item in pairs(CustomSceneItems) do
        local distance = VectorUtil.distance(playerPos, item.pos)
        if distance < recentDistance then
            CurIndex = index
            recentDistance = distance
        end
    end

    if CustomSceneItems[CurIndex] then
        self:showSelectGuideArrow(CustomSceneItems[CurIndex].pos)
    end
end

---删除选中
function CustomSceneConfig:deleteConfig()
    local item = CustomSceneItems[CurIndex]
    if not item then
        return
    end
    CustomSceneConfig:showSelectGuideArrow(nil)

    if item.type == SceneType.Effect then
        if item.targetEffect then
            EngineWorld:removeSimpleEffect(item.targetEffect.mEffectName)
        end
    elseif item.type == SceneType.Image then
        WorldImageRender.Instance():removeStaticImage("CustomImage#" .. item.Id)
    elseif item.type == SceneType.Actor then
        LuaTimer:cancel(item.animKey)
        EngineWorld:removeEntity(item.targetEntityId)
        EntityCache:removeEntityCache(item.targetEntityId)
    elseif item.type == SceneType.WallText then
        local globalRender = Blockman.Instance().m_globalRender
        if globalRender then
            globalRender:deleteWallText(item.pos or VectorUtil.ZERO, 0.1)
        end
    elseif item.type == SceneType.Mesh then
        WorldMeshRender.Instance():removeMesh("CustomMesh#" .. item.Id)
    end

    local chunkKey = getChunkKey(item.pos)
    if CustomSceneChunks[chunkKey] then
        for index, _item in pairs(CustomSceneChunks[chunkKey].items) do
            if _item.Id == item.Id then
                table.remove(CustomSceneChunks[chunkKey].items, index)
                break
            end
        end
    end

    table.remove(CustomSceneItems, CurIndex)
    CurIndex = 0
end

CustomSceneConfig:init()