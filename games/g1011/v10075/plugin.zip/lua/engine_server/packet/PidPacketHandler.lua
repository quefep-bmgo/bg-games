local handler = T(Global, "PacketHandlers")

local observable = EventObservable.new()
observable:registerDataCallBack("pid", function(userId, data)
    local player = PlayerManager:getPlayerByUserId(userId)
    if not player then
        return
    end
    local success, res = pcall(json.decode, data)
    if not success then
        LogUtil.logError("[EventObservable:registerDataCallBack:pid]", res)
        return
    end
    local func = handler[res.pid]
    if not func then
        return
    end
    func(player, res)
end)

return handler
